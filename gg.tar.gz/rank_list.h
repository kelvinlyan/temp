#pragma once

#include "commom.h"

namespace gg
{
	/* template T
	class T
	{
		public:
			int id() const
			{
				return 0;
			}
			int value() const
			{
				return 0;
			}
	};
	*/

	template<typename T>
	class RankList1
	{
		public:
			typedef boost::function<void(const T&)> Handler;
			SHAREPTR(T, Ptr);

			int getRank(int id, int value) const;
			void update(const Ptr& p, int old_value);
			void clear();
			
			unsigned size() const;
			int minV() const;
			int maxV() const;

			void run(Handler h) const;
			void run(Handler h, unsigned begin, unsigned count) const;

		private:
			int getIndex(int id, int value) const;
			int binarySearch(int value) const;

		private:
			STDVECTOR(Ptr, RankList);
			RankList _rank_list;
	};

	/**/

	template<typename T>
	int RankList1<T>::getRank(int id, int value) const
	{
		return getIndex(id, value) + 1;
	}

	template<typename T>
	void RankList1<T>::update(const Ptr& t, int old_value)
	{
		if (t->value() == 0 || t->value() < old_value)
		{
			LogE << "update failed: " << t->id() << ", " << t->value() << ", " << old_value << LogEnd;
			return;
		}

		if (old_value == 0)
		{
			for (int i = _rank_list.size(); i > 0; --i)
			{
				if (_rank_list[i - 1]->value() > t->value())
				{
					_rank_list.insert(_rank_list.begin() + i, t);
					return;
				}
			}
			_rank_list.insert(_rank_list.begin(), t);
		}
		else
		{
			int idx = getIndex(t->id(), old_value);
			if (idx == -1)
			{
				LogE << "update failed: " << t->id() << ", " << old_value << LogEnd;
				return;
			}

			for (; idx > 0; --idx)
			{
				if (t->value() > _rank_list[idx - 1]->value())
					_rank_list[idx] = _rank_list[idx - 1];
				else
					break;
			}
			_rank_list[idx] = t;
		}
	}

	template<typename T>
	void RankList1<T>::clear()
	{
		_rank_list.clear();
	}
	
	template<typename T>
	unsigned RankList1<T>::size() const
	{
		return _rank_list.size();
	}

	template<typename T>
	int RankList1<T>::minV() const
	{
		if (_rank_list.empty())
			return -1;
		return _rank_list.back()->value();
	}

	template<typename T>
	int RankList1<T>::maxV() const
	{
		if (_rank_list.empty())
			return -1;
		return _rank_list.front()->value();
	}

	template<typename T>
	void RankList1<T>::run(Handler h) const
	{
		for (unsigned i = 0; i < _rank_list.size(); ++i)
			h(*_rank_list[i]);
	}

	template<typename T>
	void RankList1<T>::run(Handler h, unsigned begin, unsigned count) const
	{
		unsigned end = begin + count;
		if (end > _rank_list.size())
			end = _rank_list.size();
		
		for (unsigned i = begin; i < end; ++i)
			h(*_rank_list[i]);
	}
	
	template<typename T>
	int RankList1<T>::getIndex(int id, int value) const
	{
		int idx = binarySearch(value);
		if (idx == -1)
			return -1;

		if (_rank_list[idx]->id() == id)
			return idx;

		int tmp = idx;
		while(++tmp < _rank_list.size() 
			&& _rank_list[tmp]->value() == value)
		{
			if (_rank_list[tmp]->id() == id)
				return tmp;
		}
		tmp = idx;
		while(--tmp >= 0 
			&& _rank_list[tmp]->value() == value)
		{
			if (_rank_list[tmp]->id() == id)
				return tmp;
		}
		return -1;
	}

	template<typename T>
	int RankList1<T>::binarySearch(int value) const
	{
		int low = 0;
		int high = _rank_list.size() - 1;
		while (low <= high)
		{
			int mid = low + (high - low) / 2;
			if(_rank_list[mid]->value() == value)
				return mid;
			else if (_rank_list[mid]->value() < value)
				high = mid - 1;
			else
				low = mid + 1;
		}
		return -1;
	}
}

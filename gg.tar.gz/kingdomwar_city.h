#pragma once

#include "mongoDB.h"
#include "auto_base.h"
#include "battle_def.h"
#include "battle_system.h"
#include "kingdomwar_def.h"
#include "kingdomwar_helper.h"
#include "kingdomwar_npc.h"

namespace gg
{
	struct mapDataConfig;
	SHAREPTR(mapDataConfig, MapDataCfgPtr);

	namespace KingdomWar
	{
		const static int MainCity[] = {7, 20, 33};

		class CityItemBase;
		SHAREPTR(CityItemBase, CItemPtr);
		typedef std::deque<CItemPtr> CItemQueue;
		STDLIST(CItemPtr, CItemList);

		class City;
		SHAREPTR(City, CityPtr);
		
		class Path;
		SHAREPTR(Path, PathPtr);
		
		struct BattleInfo
		{
			sBattlePtr ptr;
			int max_hp;
			int pre_hp;
			int cur_hp;
			int win_streak;
		};

		class CityReportData
		{
			public:
				CityReportData(unsigned time, CItemPtr& atk_ptr, CItemPtr& def_ptr);

				void one2one();
				void done();
				void getInfo(qValue& q);

				unsigned time;
				O2ORes result;
				std::string path;
				BattleReportData data;

				BattleInfo atk_info;
				BattleInfo def_info;
		};

		class CityItemBase
		{
			public:
				CityItemBase(CityPtr& ptr)
					: _city(ptr){}

				virtual mongo::BSONObj toBSON() const = 0;
				virtual void getInfo(qValue& q) const = 0;
				virtual void getInfo2(qValue& q, int state) const = 0;

				virtual int type() const = 0;
				virtual std::string name() const = 0;
				virtual int nation() const = 0;
				virtual BattleInfo getBattleInfo() = 0;
				virtual void doneBattle(CityReportData& rep_data, CItemPtr& target, bool atk_side) = 0;
				virtual bool isDead() = 0;
				virtual void beDead(unsigned time, int reason) = 0;

			protected:
				CityPtr _city;
		};

		class CityItemPlayer
			: public CityItemBase
		{
			public:
				CityItemPlayer(playerDataPtr& d, int army_id, CityPtr& ptr);
				CityItemPlayer(const mongo::BSONElement& obj, CityPtr& ptr);

				virtual mongo::BSONObj toBSON() const;
				virtual void getInfo(qValue& q) const;
				virtual void getInfo2(qValue& q, int state) const;

				virtual int type() const { return Player; }
				virtual std::string name() const { return _name; }
				virtual int nation() const { return _nation; }
				virtual BattleInfo getBattleInfo();
				virtual void doneBattle(CityReportData& rep_data, CItemPtr& target, bool atk_side);
				virtual bool isDead();
				virtual void beDead(unsigned time, int reason);

				int pid() const { return _pid; }
				int armyId() const { return _army_id; } 
				void alterName(const std::string& name) { _name = name; }

			private:
				void resetHp(sBattlePtr& ptr);

			private:
				int _pid;
				int _army_id;
				std::string _name;
				int _lv;
				int _face;
				int _nation;
				BattleEquipList _equip;
		};

		SHAREPTR(CityItemPlayer, CItemPlayer);
		STDLIST(CItemPlayer, CItemPlayerList);
		STDVECTOR(CItemPlayer, CItemPlayerVec);

		class CityItemNpc
			: public CityItemBase
		{
			public:
				CityItemNpc(NpcDataPtr npc_data, CityPtr& ptr);
				CityItemNpc(const mongo::BSONElement& obj, CityPtr& ptr);

				virtual mongo::BSONObj toBSON() const;
				virtual void getInfo(qValue& q) const;
				virtual void getInfo2(qValue& q, int state) const;

				virtual int type() const { return _data->type(); }
				virtual std::string name() const { return _data->name(); }
				virtual int nation() const { return _data->nation(); }
				virtual BattleInfo getBattleInfo();
				virtual void doneBattle(CityReportData& rep_data, CItemPtr& target, bool atk_side);
				virtual bool isDead() { return _data->isDead(); }
				virtual void beDead(unsigned time, int reason);

				bool valid() const { return _data->valid(); }
				int id() const { return _data->id(); }
				const NpcDataPtr& npcData() const { return _data; }

			protected:
				inline int face() const;
				inline int lv() const;

			protected:
				NpcDataPtr _data;
		};

		SHAREPTR(CityItemNpc, CItemNpc);
		STDLIST(CItemNpc, CItemNpcList);

		class CItemCounter
		{
			public:
				STDMAP(int, CItemPlayerVec, CItemMap);
				STDVECTOR(int, NumVec);

				CItemCounter();

				void push(CItemPtr ptr);
				void pop(CItemPtr ptr);
				void updateName(playerDataPtr& d);
				void clear();

				const NumVec& num() const { return _num; }

			private:
				bool pushPlayer(CItemMap& cmap, CItemPlayer& ptr);
				bool popPlayer(CItemMap& cmap, CItemPlayer& ptr);

			private:
				NumVec _num;
				CItemMap _player_info;
		};

		SHAREPTR(CItemCounter, CCounter);

		class UpCItem
		{
			public:
				UpCItem(int type, int side, const CItemPtr& ptr)
					: _type(type), _side(side), _ptr(ptr){}

				int side() const { return _side; }
				inline void getInfo(qValue& q) const;

			private:
				int _type;
				int _side;
				CItemPtr _ptr;
		};

		struct UpData
		{
			STDVECTOR(UpCItem, UpCItems);

			UpCItems _up_items;
			qValue _up_reps;
		};
	
		class UpDataMgr
		{
			public:
				UpDataMgr();

				inline void push(int queue_id, int type, int side, const CItemPtr& ptr);
				inline void push(int queue_id, const qValue& rep);

				void getInfo(qValue& q);
				void clear();

			private:
				STDVECTOR(UpData, UpDatas);
				UpDatas _up_datas;
		};

		class BattleField
			: public _auto_meta
		{
			public:
				BattleField(CityPtr& ptr);

				void init();
				void tick();
				int state() const { return _state; }

				void handleAddNpc(unsigned tick_time);
				void handleAddPlayer(unsigned tick_time);

				void getInfo(qValue& q) const;
				void getCItemList(qValue& q, int side);
				bool onFight(playerDataPtr& d, int army_id);
				bool onFight(NpcDataPtr d);
				void clear(unsigned tick_time);
				
			private:
				void loadDB();
				virtual bool _auto_save();
				virtual void _sign_save();

				void tryGetPlayer(unsigned cur_time);
				bool tryGetAttacker(unsigned cur_time);
				bool tryGetDefender(unsigned cur_time);
				bool tryGetNpcDefender(int queue_id);

				void setBattleTimer(unsigned tick_time, int queue_id);
				void setStartWaitTimer();
				void setAttackerWaitTimer();
				void setDefenderWaitTimer();
				void changeState(int state, unsigned cur_time = 0);

				void tickStartWait(unsigned tick_time);
				void tickBattle(unsigned timer_id, unsigned tick_time, int queue_id);
				void tickAttackerWait(unsigned timer_id, unsigned tick_time);
				void tickDefenderWait(unsigned timer_id, unsigned tick_time);
				void tickAddPlayer(unsigned tick_time);
				void tickAddNpc(unsigned tick_time);
				void tickClose(bool result);
				void resetQueueState(unsigned tick_time);

				void releaseDefender(int queue_id, unsigned tick_time);

				int unfilledAttackerQueue();
				int unfilledDefenderQueue();
				bool noAttackers() const;
				bool noDefenders() const;

				int getWinNation();

				void reset();
				void clearBattleTimer();
				inline void clearAttackerWaitTimer();
				inline void clearDefenderWaitTimer();

				void push(int queue_id, bool is_attacker_queue, CItemPtr ptr);
				void pop(int queue_id, bool is_attacker_queue, int type);
				void clear(int queue_id, bool is_attacker_queue, CItemQueue& ret_q);

			private:
				CityPtr _city;
				int _state;
				bool _modified;
				std::vector<int> _queue_state;
				std::vector<CItemQueue> _defender_queue;
				std::vector<CItemQueue> _attacker_queue;
				std::vector<int> _wins;
				int _first_battle_nation;
				std::vector<qValue> _rep_backup;
				unsigned _next_tick_time;
				std::vector<unsigned> _next_battle_time;
				unsigned _atk_wait_timer;
				unsigned _def_wait_timer;
				std::vector<unsigned> _battle_timer;

				CCounter _counter;
				
				UpDataMgr _updater;
				mutable qValue _main_info;
		};

		SHAREPTR(BattleField, BattleFieldPtr);

		class City
			: public _auto_meta, public Observer
		{
			public:
				friend class BattleField;

				City(const Json::Value& info);

				void init();
				int id() const { return _id; }
				int state();

				static const vector<int>& num() { return Num; }
				static int unityNation();

				void reset(unsigned cur_time);
				void tryLoadPlayer(playerDataPtr& d, int army_id);
				void tryLoadNpc(NpcDataPtr& d);
				void addPath(const PathPtr& ptr) { _paths.push_back(ptr); }
				int nation() const { return _nation; }

				int enter(unsigned time, playerDataPtr d, int army_id, int reason);
				int enter(unsigned time, NpcDataPtr d);
				int leave(unsigned time, playerDataPtr d, int army_id, int to_city_id);

				void getMainInfo(qValue& q) const { _battle_field->getInfo(q); }
				void getMilitaryInfo(qValue& q);
				void getFighterList(qValue& q, int side);

				bool onFight(playerDataPtr d, int army_id);
				bool onFight(NpcDataPtr d);

				int getOutput(int nation) const { return _output[nation]; }
				int outputType() const { return _output_type; }
				int maxOutput() const { return _output_max; }

				void addBuff(playerDataPtr& d, sBattlePtr ptr);
				void addBuff(sBattlePtr ptr, int nation);

				unsigned getSup(unsigned cur_time);	
				void clear();

				CItemNpc createNpc(unsigned cur_time, int map_id);
				CItemNpc createNpc2(unsigned cur_time, int map_id);

				void updateName(playerDataPtr d) { _counter->updateName(d); }

			private:
				void loadDB();
				virtual bool _auto_save();
				void tickOutput();
				void tickCreateNpc();
				void tickCreateNpc2();
				void initNpc(unsigned cur_time);
				void initMaxNpc(unsigned cur_time);
				void alterNation(int nation);
				
				void noticeAddAttacker(unsigned tick_time);
				void noticeAddDefender(unsigned tick_time);
				void noticeAddNpc(unsigned tick_time);
				void handleBattleResult(unsigned tick_time, bool result, int nation = -1);

				CItemPtr getAttacker();
				CItemPtr getDefender();
				CItemPtr getNpcDefender();

				void releaseAttacker(CItemPtr& ptr, unsigned tick_time);
				void releaseDefender(CItemPtr& ptr, unsigned tick_time);

			private:
				int _id;
				int _nation;
				std::vector<PathPtr> _paths;

				CItemNpcList _npc_list;
				CItemList _attacker_backup;
				CItemList _defender_backup;
				BattleFieldPtr _battle_field;
				CCounter _counter;

				STDVECTOR(int, Output);
				Output _output;
				int _output_type;
				int _output_max;

				int _npc_add;
				int _npc_max;
				int _npc_start;

				int _buff_type;
				std::vector<int> _buff_value;

				unsigned _sup_base;
				unsigned _sup_time;
				double _sup_rate;

				static std::vector<int> Num;
		};

		class CityList
		{
			public:
				CityList();

				void loadDB();

				CityPtr getCity(int id);
				void push(const CityPtr& ptr);
				void update(bool is_first = false);	
				void tick();
				int size() const { return _citys.size(); }

				void getStateInfo(qValue& q) { q = _main_state_info.Copy(); }
				void getUpStateInfo(qValue& q) { q = _update_state_info; } 
				void getNationInfo(qValue& q) { q = _main_nation_info.Copy(); }
				void getUpNationInfo(qValue& q) { q = _update_nation_info; }

				void clear();

			private:
				STDVECTOR(CityPtr, Citys);
				Citys _citys;

				std::vector<int> _states;
				std::vector<int> _nations;
 
				qValue _main_state_info;
				qValue _update_state_info;
				qValue _main_nation_info;
				qValue _update_nation_info;
		};
	}
}

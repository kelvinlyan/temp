#pragma once

#include "kingdomwar_def.h"
#include "kingdomwar_helper.h"
#include "battle_def.h"
#include "mongoDB.h"
#include "auto_base.h"
#include "rank_list.h"
#include "battle_system.h"

namespace gg
{
	namespace KingdomWar
	{
		enum
		{
			ServerError = 0x7FFFFFFF,


			// state
			Closed = 0,
			Opened,
			AttackerWait,
			DefenderWait,
			StartWait,

			// prime state
			OrdinaryTime = 0,
			PrimeTime,

		};

		class RankItem
		{
			public:
				RankItem(playerDataPtr d);
				
				void getInfo(qValue& q) const;

				int id() const { return _pid; }
				int value() const { return _exploit; }

			private:
				int _pid;
				std::string _name;
				int _nation;
				int _exploit;
		};

		SHAREPTR(RankItem, RankItemPtr);

		class RankMgr
		{
			public:
				RankMgr();

				void update(playerDataPtr d, int old_value);
				void getInfo(playerDataPtr d, int begin, int end, qValue& q);
				int getRank(playerDataPtr d) const;
				void tickRank();
				void packageInfo(const RankItem& item);
				void tickRankItem(const RankItem& item);
				void tickClearItem(const RankItem& item);

			private:
				typedef RankList1<RankItem> RankList;
				RankList _rank;

				// temp
				qValue _info;
				int _rk;
		};

		class State
			: public _auto_meta
		{
			public:
				enum
				{
					Closed = 0,
					Opened,
				};

				State();
				void init();

				int get() const { return _state; }
				int primeState() const { return _prime_state; }
				unsigned next5MinTime() const { return _next_5_min_tick_time; }
				unsigned nextTickTime() const { return _next_tick_time; }
				unsigned nextClearTime() const { return _next_clear_time; }
				unsigned nextPrimeTime() const { return _next_prime_time; }

				void reset5MinTime();
				void resetClearTime();
				void resetPrimeTimeAndState();
				void resetTickTimeAndState();

			private:
				virtual bool _auto_save();

			private:
				unsigned _next_5_min_tick_time;
				unsigned _next_tick_time;
				unsigned _next_clear_time;
				int _state;

				int _prime_state;
				unsigned _next_prime_time;
				int _last_prime_state;
				unsigned _last_prime_time;
		};

		class Sign
			: public _auto_meta
		{
			public:
				Sign(int nation);
				void init(const mongo::BSONObj& obj);
				void getInfo(qValue& q);
				int setSign(playerDataPtr d, int id);
				void clear();

			private:
				virtual bool _auto_save();

			private:
				const int _nation;
				STDVECTOR(int, IDList);
				IDList _id_list;
		};

		SHAREPTR(Sign, SignPtr);
		STDVECTOR(SignPtr, Signs);

		class SignList
		{
			public:
				void init();
				int setSign(playerDataPtr d, int id);
				void getInfo(qValue& q, int nation);
				void clear();

			private:
				Signs _sign;
		};

		class KingdomBuff
			: public _auto_meta
		{
			public:
				KingdomBuff();
				void init();
				void reset(unsigned tick_time);
				void getInfo(qValue& q);
				int getBuff(int nation);

			private:
				virtual bool _auto_save();

			private:
				int _max;
				int _min;
				int _add;
				std::vector<int> _change;

				std::vector<int> _buff;
		};

		SHAREPTR(KingdomBuff, BuffPtr);

		struct NpcRule
		{
			NpcRule(const Json::Value& info);

			int _power_begin;
			int _power_end;
			int _npc_begin;
			int _npc_end;
		};

		struct HpDebuff
		{
			HpDebuff(int atk_debuff, int def_debuff)
				: _atk_debuff(atk_debuff), _def_debuff(def_debuff){}

			int _atk_debuff;
			int _def_debuff;
		};

		class GreatEvent
			: public _auto_meta
		{
			public:
				GreatEvent(qValue& q)
					: _q(qJson::qj_object)
				{
					_q = q;
				}

				void getInfo(qValue& q) { q = _q.Copy(); }

			private:
				virtual bool _auto_save();

			private:
				qValue _q;
		};
	}
}

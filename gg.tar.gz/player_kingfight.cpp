#include "player_kingfight.h"
#include "playerManager.h"
#include "kingfight_system.h"
#include "kingdom_def.h"
#include "kingdomwar_system.h"

namespace gg
{
	playerKingFight::playerKingFight(playerData* const own)
		: _auto_player(own), _cd(0), _open_time(0), _bet_pid(-1), _final_state(0), _title(Kingdom::PingMin), _title_time(0)
	{}

	void playerKingFight::loadDB()
	{
		mongo::BSONObj key = BSON(strPlayerID << Own().ID());
		mongo::BSONObj obj = db_mgr.FindOne(DBN::dbPlayerKingFight, key);
		
		if (obj.isEmpty()) 
			return;

		checkNotEoo(obj["ot"])
			_open_time = obj["ot"].Int();
		checkNotEoo(obj["cd"])
			_cd = obj["cd"].Int();
		checkNotEoo(obj["bp"])
			_bet_pid = obj["bp"].Int();
		checkNotEoo(obj["bn"])
			_bet_name = obj["bn"].String();
		checkNotEoo(obj["bsl"])
			_bet_silver = obj["bsl"].Int();
		checkNotEoo(obj["br"])
			_bet_rate = obj["br"].Int();
		checkNotEoo(obj["bs"])
			_bet_state = obj["bs"].Int();
		checkNotEoo(obj["fs"])
			_final_state = obj["fs"].Int();
		checkNotEoo(obj["fr"])
			_final_rewarded = obj["fr"].Int();
		checkNotEoo(obj["fsl"])
			_final_silver = obj["fsl"].Int();
		checkNotEoo(obj["tt"])
			_title_time = obj["tt"].Int();
		checkNotEoo(obj["tl"])
			_title = obj["tl"].Int();
	}

	bool playerKingFight::_auto_save()
	{
		mongo::BSONObj key = BSON(strPlayerID << Own().ID());
		mongo::BSONObjBuilder obj;
		obj << strPlayerID << Own().ID() << "ot" << _open_time << "cd" << _cd
			<< "bp" << _bet_pid << "bn" << _bet_name << "bsl" << _bet_silver
			<< "br" << _bet_rate << "bs" << _bet_state << "fs" << _final_state
			<< "fr" << _final_rewarded << "fsl" << _final_silver << "tt" << _title_time
			<< "tl" << _title;
		return db_mgr.SaveMongo(DBN::dbPlayerKingFight, key, obj.obj());
	}

	void playerKingFight::_auto_update()
	{
	
	}

	void playerKingFight::getInfo(Json::Value& info)
	{
		checkAndUpdate();

		info["ct"] = _cd;
		info["pi"] = Json::arrayValue;
		if (_bet_pid != -1)
		{
			info["pi"].append(_bet_name);
			info["pi"].append(_bet_silver);
			info["pi"].append(_bet_rate);
			info["pi"].append(_bet_state);
		}
		info["cam"] = Json::arrayValue;
		if (_final_state != 0)
		{
			info["cam"].append(_final_state);
			info["cam"].append(_final_rewarded);
			info["cam"].append(_final_silver);
		}
	}

	void playerKingFight::checkAndUpdate()
	{
		if (Own().Info->Nation() == Kingdom::null)
			return;

		const KingFightManager ptr = kingfight_sys.getData(Own().Info->Nation());
		
		if (_open_time != ptr->lastOpenTime())
		{
			_open_time = ptr->lastOpenTime();
			_bet_pid = -1;
			_final_state = 0;
			_sign_save();
		}
/*
		if (_title_time != ptr->lastCloseTime())
		{
			_title_time = ptr->lastCloseTime();
			_title = Kingdom::PingMin;
			Own().Info->motifyNationOf_(_title);
			_sign_save();
		}
*/
		if (_bet_pid != -1 && _bet_state == 1 
			&& ptr->state() == KingFight::Closed)
		{
			if (_bet_pid == ptr->getPidByTitle(Kingdom::GuoWang))
				_bet_state = 2;
			else
				_bet_state = 4;
		}
	}

	int playerKingFight::bet(int pid, const std::string& name, int silver, int rate)
	{
		checkAndUpdate();

		if (_bet_pid != -1)
			return err_illedge;
		if (Own().Res->getSilver() < silver)
			return err_silver_not_enough;

		Own().Res->alterSilver(0 - silver);
		_bet_pid = pid;
		_bet_name = name;
		_bet_silver = silver;
		_bet_rate = rate;
		_bet_state = 1;
		_sign_save();
		Log(DBLOG::strLogKingFight, Own().getOwnDataPtr(), 0, _bet_pid);
		return res_sucess;
	}

	int playerKingFight::getReward()
	{
		checkAndUpdate();

		if (_final_state > 1
			&& _final_rewarded == 1)
		{
			Own().Res->alterSilver(_final_silver);
			_final_rewarded = 2;
			_sign_save();
			return res_sucess;
		}
		if (_bet_pid != -1
			&& _bet_state == 2)
		{
			Own().Res->alterSilver(_bet_silver * _bet_rate);
			_bet_state = 3;
			_sign_save();
			Log(DBLOG::strLogKingFight, Own().getOwnDataPtr(), 1, _bet_pid);
			return res_sucess;
		}

		return err_illedge;
	}

	bool playerKingFight::inBattleCd()
	{
		unsigned cur_time = Common::gameTime();
		if (cur_time < _cd)
			return true;
		_cd = cur_time + 3 * MINUTE;
		return false;
	}

	void playerKingFight::setFinalState(int state, int silver)
	{
		checkAndUpdate();
		_final_state = state;
		if (silver > 0)
		{
			_final_silver = silver;
			_final_rewarded = 1;
		}
		_sign_save();
	}

	int playerKingFight::clearCd()
	{
		unsigned cur_time = Common::gameTime();
		if (cur_time >= _cd)
			return err_illedge;
		int cost = ((_cd - cur_time) + 60 - 1) / 60;
		if (Own().Res->getCash() < cost)
			return err_cash_not_enough;
		Own().Res->alterCash(0 - cost);
		_cd = 0;
		_sign_save();
		return res_sucess;
	}

	void playerKingFight::setTitle(int title)
	{
		//checkAndUpdate();
		int tmp = _title;
		_title = title;
		Own().Info->motifyNationOf_(title);
		kingdomwar_sys.updateTitle(Own().getOwnDataPtr(), tmp);
		_sign_save();
	}

	int playerKingFight::getTitle()
	{
		//checkAndUpdate();
		return _title;
	}
}

#include "fund_system.h"
#include "commom.h"
//#include "dbDriver.h"


namespace gg
{
	fund_system* const fund_system::_Instance = new fund_system();

	fund_system::fund_system()
	{
	}

	bool fund_system::isValidFundId(const int& id) const
	{
		return fund_config.cfg().reward_list.find(id) != fund_config.cfg().reward_list.end();
	}

	void fund_system::reqFundInfo(net::Msg& m, Json::Value& r)
	{
		playerDataPtr player = player_mgr.getPlayer(m.playerID);
		if (!player) Return(r, err_illedge);
		player->Fund->_auto_update();
	}

	void fund_system::reqFundBuy(net::Msg& m, Json::Value& r)
	{
		//1.parse the data.
		//2.business logic
		playerDataPtr player = player_mgr.getPlayer(m.playerID);
		if (!player)Return(r, err_illedge);//�Ƿ�����

		if (player->Info->VipLv() < fund_config.cfg().vip_lv)//vip�ȼ�
		{
			Return(r, err_fund_vip_lv_not_enough);
		}
		if (player->Res->getCash() < fund_config.cfg().gold)//���
		{
			Return(r, err_fund_gold_not_enough);
		}

		//����
		int res = player->Fund->buyFund();
		Return(r, res);
	}

	void fund_system::reqFundGetReward(net::Msg& m, Json::Value& r)
	{
		//1.parse the data.
		//2.business logic
		playerDataPtr player = player_mgr.getPlayer(m.playerID);
		if (!player)Return(r, err_illedge);//�Ƿ�����

		ReadJsonArray;

		const int reward_id = js_msg[0u]["reward_id"].asInt();
		if (!player->Fund->hasBoughtFund())
		{//δ�������
			Return(r, err_fund_do_not_buy);
		}
		if (!isValidFundId(reward_id))
		{//��Чid
			Return(r, err_fund_invalid_id);
		}
		if (fund_config.cfg().reward_list[reward_id].r_lv > player->Info->LV())
		{//�ȼ�����
			Return(r, err_fund_lv_not_enough);
		}

		//��ý���
		const int res = player->Fund->getReward(reward_id, r);
		Return(r, res);

	}


	fund_system::~fund_system()
	{
	}
}

#include "dbDriver.h"
#include "game_log_protocol.h"
#include "game_server.h"

namespace gg
{
	namespace MetaLog
	{
		static void sendLog(const short logReq, Json::Value& logData)
		{
			string logstr = logData.toIndentString();
			net::Msg mj(-1, service::process_id::GAME_NET_ID, logReq, logstr);
			game_svr->async_send_to_db(mj);
		}

		void Log(const string table, const int tag, string f1 /* = "" */, string f2 /* = "" */, string f3 /* = "" */, string f4 /* = "" */, string f5 /* = "" */, string f6 /* = "" */, string f7 /* = "" */, string f8 /* = "" */)
		{
			Json::Value LogData;
			LogData.append(table);
			LogData.append(State::getState());
			LogData.append(-1);
			LogData.append("system");
			LogData.append(-1);
			LogData.append(NumberCounter::getCounter());
			LogData.append(tag);
			LogData.append(Common::serverID());
			LogData.append(f1);
			LogData.append(f2);
			LogData.append(f3);
			LogData.append(f4);
			LogData.append(f5);
			LogData.append(f6);
			LogData.append(f7);
			LogData.append(f8);
			sendLog(game_log::mysql_log_system_req, LogData);
		}

		void Log(const string table, playerDataPtr player, const int tag, string f1 /* = "" */, string f2 /* = "" */, string f3 /* = "" */, string f4 /* = "" */, string f5 /* = "" */, string f6 /* = "" */, string f7 /* = "" */, string f8 /* = "" */)
		{
			if (!player){ Log(table, tag, f1, f2, f3, f4, f5, f6, f7, f8); return; }
			Json::Value LogData;
			LogData.append(table);
			LogData.append(State::getState());
			LogData.append(player->ID());
			LogData.append(player->Name());
			LogData.append(player->LV());
			LogData.append(NumberCounter::getCounter());
			LogData.append(tag);
			LogData.append(Common::serverID());
			LogData.append(f1);
			LogData.append(f2);
			LogData.append(f3);
			LogData.append(f4);
			LogData.append(f5);
			LogData.append(f6);
			LogData.append(f7);
			LogData.append(f8);
			sendLog(game_log::mysql_log_system_req, LogData);
		}
	}

}
//###################################
//create by Jim
//2015-11-16
//###################################

#pragma once

#include "quickjson.h"
#include "commom.h"
#include "battle_def.h"
#include "skill_def.h"

#define battle_sys  (*gg::battle_system::_Instance)

namespace gg
{
	extern void battleTest();
	const static std::string strRpDirRoot = "./report/";
	namespace typeBattle
	{
		enum TYPE
		{
			war_story,//ս��
			crown_fight,//�����������ᴢ��
			trade_pirate,//ó�״򺣵�
			hero_party,//ȺӢ��
			world_boss,//����BOSS
			warlords,//Ⱥ������
			kingdomwar,
			team_battle = 1000,
			team_war_story = 1001,//���ս �ַ�����

			child_battle = -1,
		};
	}

	namespace resBattle
	{
		enum RES
		{
			atk_win,
			def_win,
			res_unknown,//���ط�ʵ����Ϊ��
		};
	}

	struct O2ORes
	{
		O2ORes()
		{
			res = resBattle::def_win;
			star = 0;
		}
		O2ORes(const resBattle::RES r, const int s)
		{
			res = r;
			star = s;
		}
		resBattle::RES res;//ս�����
		int star;//�Ǽ�
	};

	namespace runBattle
	{
		enum RUN // << 0 -> << 9
		{
			hp_recovery = (0x0001 << 0),//ս��������ָ�hp
		};
	}

	namespace BattleData
	{
		class unit;
		SHAREPTR(unit, unitPtr);
		class environment;
		SHAREPTR(environment, envPtr);
		typedef vector<envPtr> EnvSeq;
	}

	class battle_system;
	class BattleReportData
	{
		friend class battle_system;
	public://������������
		BattleReportData();
		BattleReportData& addNotice(const int playerID);//����������
		BattleReportData& addCopyField(const string toPath);//���ӱ�ѡ�ļ���ַ
	public://���Ե�ս������
		inline unsigned getLastRound() { return LastRound; }
		void addReportdeclare(const string key, const int val);
		void addReportdeclare(const string key, const double val);
		void addReportdeclare(const string key, const unsigned val);
		void addReportdeclare(const string key, const string str);
		void addReportdeclare(const string key, Json::Value& json);
		void addReportdeclare(const string key, qValue& json);
		void Done(const typeBattle::TYPE type, Json::Value extra = Json::objectValue);
	public://��Զ�ս������
		void addReportdeclareT(const string key, const int val);
		void addReportdeclareT(const string key, const double val);
		void addReportdeclareT(const string key, const unsigned val);
		void addReportdeclareT(const string key, const string str);
		void addReportdeclareT(const string key, Json::Value& json);
		void addReportdeclareT(const string key, qValue& json);
		void DoneT(const typeBattle::TYPE type, Json::Value extra = Json::objectValue);
	private://����//ָ����һ�����ܻ���//Ϊ�˼���Ƕ��
		BattleData::EnvSeq seqENV_;//��ǰ�����ڵ�
		BattleData::envPtr PushEnv(BattleData::envPtr env);
		void jDoneAndClear(qValue& reportDelare);
		void ClearActionEnv();
	private:
		//���ò���
		STDVECTOR(string, strCV);
		strCV CVList;
		STDSET(int, SENDSET);
		SENDSET noticeList;
		//��Զ�غ�����Ч
		qValue reportTeam;//���ս���ڵ�
		//���Ե��غ�����Ч
		qValue reportRoot;//���ڵ�
		unsigned LastRound;//�����Ե��غ�����Ч
		UNORDERSET(mBattlePtr, ManDealList);
		ManDealList zeroBuffMan;
		//initial
		void resetT2TReport();
		void resetO2OReport();//����ȫ�ֱ���
	};

	class battle_system
	{

	public:
		static battle_system* const  _Instance;
		battle_system(){}
		~battle_system(){}
		void initData();

		//����ս�����Բ��ô���runType  Ĭ��ֵ����
		O2ORes One2One(BattleReportData& use_data, sBattlePtr atk, sBattlePtr def, typeBattle::TYPE type, const unsigned runType = 0);//0����ʤ�� �����ط�ʤ��
		resBattle::RES Team2Team(BattleReportData& use_data, teamSideBattle atk, teamSideBattle def, typeBattle::TYPE type, const unsigned step = 3, const unsigned runType = 0);//0����ʤ�� �����ط�ʤ��
	private:
		O2ORes impl_One2One(sBattlePtr atk, sBattlePtr def, typeBattle::TYPE type, const unsigned runType = 0);//0����ʤ�� �����ط�ʤ��
		BattleReportData* reportData;
	private:
		typedef boost::function<void(sBattlePtr, sBattlePtr)> dealPerFunc;
		typedef boost::unordered_map<int, dealPerFunc> perDealMap;
		perDealMap mapPerDeal;//ÿһ��ս��
		void per_hp_recovery(sBattlePtr atk, sBattlePtr def);
	private://������ѵ
		bool begin_attack(sBattlePtr atk, sBattlePtr def, const unsigned round);
		void on_attack(sBattlePtr atk, sBattlePtr def, const unsigned round, const unsigned sr, mBattlePtr sign_aim = mBattlePtr());//���������￪ʼ
		void on_detail_attack(BattleData::envPtr env, const SKILL::skillEntity& entity, 
			const unsigned sr, mBattlePtr sign_aim = mBattlePtr(), const bool is_main = false);//�Ӽ��ܴ����￪ʼ
		void run_attack(BattleData::envPtr env, BattleData::unitPtr uni, const SKILL::skillEntity::entityList& declare);
		void run_attack_no_aim(BattleData::envPtr env, BattleData::unitPtr uni, const SKILL::skillEntity::entityList& declare);
		void end_attack(BattleData::envPtr env, const unsigned sr);
	private://ѡ��Ŀ��

		//big big
		void find_aim(BattleData::envPtr env, BattleData::unitPtr uni, const AIM::structAIM& declare, mBattlePtr sign_aim = mBattlePtr());
		typedef boost::function<void(BattleData::envPtr, BattleData::unitPtr, const AIM::structAIM&)> FindAimF;
		typedef boost::unordered_map<int, FindAimF> aimDealMap;
		
		//new new
		void find_aim_new(BattleData::envPtr env, BattleData::unitPtr uni, const AIM::structAIM& declare);//�����ƶ�Ŀ��
		aimDealMap newAimDeal;
		void aim_follow_new(BattleData::envPtr ptr, BattleData::unitPtr uni, const AIM::structAIM& declare);
		void aim_single_new(BattleData::envPtr ptr, BattleData::unitPtr uni, const AIM::structAIM& declare);
		void aim_line_new(BattleData::envPtr ptr, BattleData::unitPtr uni, const AIM::structAIM& declare);
		void aim_row_new(BattleData::envPtr ptr, BattleData::unitPtr uni, const AIM::structAIM& declare);
		void aim_cross_new(BattleData::envPtr ptr, BattleData::unitPtr uni, const AIM::structAIM& declare);
		void aim_random_new(BattleData::envPtr ptr, BattleData::unitPtr uni, const AIM::structAIM& declare);
		void aim_current_new(BattleData::envPtr ptr, BattleData::unitPtr uni, const AIM::structAIM& declare);
		void aim_other_new(BattleData::envPtr ptr, BattleData::unitPtr uni, const AIM::structAIM& declare);
		void aim_all_new(BattleData::envPtr ptr, BattleData::unitPtr uni, const AIM::structAIM& declare);

		//sign sign
		void find_aim_sign(BattleData::envPtr env, BattleData::unitPtr uni, const AIM::structAIM& declare);//����Ŀ��
		aimDealMap signAimDeal;
		void aim_follow_sign(BattleData::envPtr ptr, BattleData::unitPtr uni, const AIM::structAIM& declare);
		void aim_single_sign(BattleData::envPtr ptr, BattleData::unitPtr uni, const AIM::structAIM& declare);
		void aim_line_sign(BattleData::envPtr ptr, BattleData::unitPtr uni, const AIM::structAIM& declare);
		void aim_row_sign(BattleData::envPtr ptr, BattleData::unitPtr uni, const AIM::structAIM& declare);
		void aim_cross_sign(BattleData::envPtr ptr, BattleData::unitPtr uni, const AIM::structAIM& declare);
		void aim_random_sign(BattleData::envPtr ptr, BattleData::unitPtr uni, const AIM::structAIM& declare);
		void aim_current_sign(BattleData::envPtr ptr, BattleData::unitPtr uni, const AIM::structAIM& declare);
		void aim_other_sign(BattleData::envPtr ptr, BattleData::unitPtr uni, const AIM::structAIM& declare);
		void aim_all_sign(BattleData::envPtr ptr, BattleData::unitPtr uni, const AIM::structAIM& declare);

	private://����Ч��
		typedef boost::function<void(BattleData::envPtr, BattleData::unitPtr, const SKILL::declare&)> RunDeclareF;
		typedef boost::unordered_map<int, RunDeclareF> SkillDealMap;
		SkillDealMap SkillDeal;
		void phy_attack(BattleData::envPtr ptr, BattleData::unitPtr uni, const SKILL::declare& declare);
		void war_attack(BattleData::envPtr ptr, BattleData::unitPtr uni, const SKILL::declare& declare);
		void rage_attack(BattleData::envPtr ptr, BattleData::unitPtr uni, const SKILL::declare& declare);
		void magic_attack(BattleData::envPtr ptr, BattleData::unitPtr uni, const SKILL::declare& declare);
		void mp_attack(BattleData::envPtr ptr, BattleData::unitPtr uni, const SKILL::declare& declare);
		void absorb_hp(BattleData::envPtr ptr, BattleData::unitPtr uni, const SKILL::declare& declare);
		void absorb_mp(BattleData::envPtr ptr, BattleData::unitPtr uni, const SKILL::declare& declare);
		void cure_hp(BattleData::envPtr ptr, BattleData::unitPtr uni, const SKILL::declare& declare);
		void cure_mp(BattleData::envPtr ptr, BattleData::unitPtr uni, const SKILL::declare& declare);
		void child_skill(BattleData::envPtr ptr, BattleData::unitPtr uni, const SKILL::declare& declare);
		void set_buff(BattleData::envPtr ptr, BattleData::unitPtr uni, const SKILL::declare& declare);
		void direct_attack(BattleData::envPtr ptr, BattleData::unitPtr uni, const SKILL::declare& declare);
		void clear_debuff(BattleData::envPtr ptr, BattleData::unitPtr uni, const SKILL::declare& declare);
		void add_shield(BattleData::envPtr ptr, BattleData::unitPtr uni, const SKILL::declare& declare);
		void mp_set(BattleData::envPtr ptr, BattleData::unitPtr uni, const SKILL::declare& declare);
		void mp_alter_formula_1(BattleData::envPtr ptr, BattleData::unitPtr uni, const SKILL::declare& declare);
	private://buff ����
		void effect_to_run(const unsigned round, sBattlePtr atk, sBattlePtr def, mBattlePtr user, const unsigned sr);//ִ��Ч��
	private://buff ʵ��Ч��ִ�� //�ж�ǰ �ж��� ÿ���ж�����һ����ʽ�Ļغ� // ������Ч����
		void effect_stun(BattleData::envPtr env, BattleData::unitPtr uni, mBattlePtr user, mEfPtr ef, const unsigned sr);
		void effect_alter_hp(BattleData::envPtr env, BattleData::unitPtr uni, mBattlePtr user, mEfPtr ef, const unsigned sr);
		void effect_alter_mp(BattleData::envPtr env, BattleData::unitPtr uni, mBattlePtr user, mEfPtr ef, const unsigned sr);

		typedef boost::function<void(BattleData::envPtr, BattleData::unitPtr, mBattlePtr, mEfPtr, const unsigned)> EffectRunF;
		UNORDERMAP(int, EffectRunF, EffectRunMap);
		EffectRunMap EffectRun;
	private://buff ע���¼�
		bool buff_regist(BattleData::envPtr env, BattleData::unitPtr uni, mBattlePtr user, mBattlePtr aim, mEfPtr ef);

		//���������¼�
		void stun_regist(BattleData::envPtr env, BattleData::unitPtr uni, mBattlePtr user, mBattlePtr aim, const BUFF::Data& entity);
		void bonus_attri_regist(BattleData::envPtr env, BattleData::unitPtr uni, mBattlePtr user, mBattlePtr aim, const BUFF::Data& entity);
		void bonus_attri_rate_regist(BattleData::envPtr env, BattleData::unitPtr uni, mBattlePtr user, mBattlePtr aim, const BUFF::Data& entity);
		void last_alter_regist(BattleData::envPtr env, BattleData::unitPtr uni, mBattlePtr user, mBattlePtr aim, const BUFF::Data& entity);

		typedef boost::function<void(BattleData::envPtr, BattleData::unitPtr, mBattlePtr, mBattlePtr, const BUFF::Data&)> RegEffectF;
		UNORDERMAP(int, RegEffectF, RegEffectMap);
		RegEffectMap RegEffect;
	private://buff ��ע���¼�
		void bonus_attri_antiregist(BattleData::envPtr env, mBattlePtr user, mEfPtr ef);
		void bonus_attri_rate_antiregist(BattleData::envPtr env, mBattlePtr user, mEfPtr ef);

		typedef boost::function<void(BattleData::envPtr, mBattlePtr, mEfPtr)> AntiRegEffectF;
		UNORDERMAP(int, AntiRegEffectF, AntiRegEffectMap);
		AntiRegEffectMap AntiRegEffect;
	private://ʩ��ִ������
		bool user_runOK(mBattlePtr user, mBattlePtr aim, const SKILL::declare& declare);

		bool user_alive(mBattlePtr user, mBattlePtr aim);
		bool aim_alive(mBattlePtr user, mBattlePtr aim);
		bool user_hp_greater(mBattlePtr user, mBattlePtr aim);
		bool user_hp_less(mBattlePtr user, mBattlePtr aim);
		bool user_hp_equal(mBattlePtr user, mBattlePtr aim);

		typedef boost::function<bool(mBattlePtr, mBattlePtr)> UserRunF;
		UNORDERMAP(int, UserRunF, UserRunMap);
		UserRunMap UserRun;
	private://�����¼���
		enum EventResult
		{
			adopt,//�¼�ͨ��
			intercept,//�¼�����
		};
		EventResult onRun(BattleData::envPtr ptr, BattleData::unitPtr uni, const SKILL::declare& declare, mBattlePtr user, mBattlePtr aim, const bool visible = true);//����ʹ��ʧ��
		EventResult onPhyAttack(BattleData::envPtr ptr, BattleData::unitPtr uni, mBattlePtr user, mBattlePtr aim);
		EventResult onWarAttack(BattleData::envPtr ptr, BattleData::unitPtr uni, mBattlePtr user, mBattlePtr aim);
		EventResult onRageAttack(BattleData::envPtr ptr, BattleData::unitPtr uni, mBattlePtr user, mBattlePtr aim);
		EventResult onMagicAttack(BattleData::envPtr ptr, BattleData::unitPtr uni, mBattlePtr user, mBattlePtr aim);
		EventResult onAttack(BattleData::envPtr ptr, BattleData::unitPtr uni, mBattlePtr user, mBattlePtr aim);
		EventResult onPhyDamage(BattleData::envPtr ptr, BattleData::unitPtr uni, mBattlePtr user, mBattlePtr aim, int& damage);
		EventResult onWarDamage(BattleData::envPtr ptr, BattleData::unitPtr uni, mBattlePtr user, mBattlePtr aim, int& damage);
		EventResult onRageDamage(BattleData::envPtr ptr, BattleData::unitPtr uni, mBattlePtr user, mBattlePtr aim, int& damage);
		EventResult onMagicDamage(BattleData::envPtr ptr, BattleData::unitPtr uni, mBattlePtr user, mBattlePtr aim, int& damage);
		EventResult onDamage(BattleData::envPtr ptr, BattleData::unitPtr uni, mBattlePtr user, mBattlePtr aim, int& damage, const bool common = true);
		EventResult onDodge(BattleData::envPtr ptr, BattleData::unitPtr uni, mBattlePtr user, mBattlePtr aim);
		EventResult onBlock(BattleData::envPtr ptr, BattleData::unitPtr uni, mBattlePtr user, mBattlePtr aim);
		EventResult onCrit(BattleData::envPtr ptr, BattleData::unitPtr uni, mBattlePtr user, mBattlePtr aim);
		EventResult onCounter(BattleData::envPtr ptr, BattleData::unitPtr uni, mBattlePtr user, mBattlePtr aim);
		//EventResult onDead(BattleData::envPtr ptr, BattleData::unitPtr uni, mBattlePtr who);
		//
		bool onRoundBegin();
		bool onRoundEnd();
	private://��ʽ����������
		int damageFM(
			BattleData::envPtr ptr, BattleData::unitPtr uni, const SKILL::declare& declare,
			mBattlePtr user, const AttributeIDX user_pro, const AttributeIDX user_atk, const AttributeIDX user_final, const AttributeIDX user_final_val, const ArmsModule user_midx,
			mBattlePtr aim, const AttributeIDX aim_pro, const AttributeIDX aim_def, const AttributeIDX aim_final, const AttributeIDX aim_final_val, const ArmsModule aim_midx,
			const double damageRate = 1.0);
	private://һЩ˽�еı���
		vector< vector<armsRestraint> > armsR;//���ֿ��ƹ�ϵ
		double calArmsRes(const int atk_type, const int aim_type);
	private://
	};
}

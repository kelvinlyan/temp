#include "player_affair.h"
#include "dbDriver.h"
#include "ownerland_system.h"
#include "despatch_task.h"
#include "task_mgr.h"

namespace gg
{
	static void staticClearAffair(const int playerID, const unsigned tickTime)
	{
		playerDataPtr player = player_mgr.getOnlinePlayer(playerID);
		if (!player)return;
		player->Affair->remove_async_event(tickTime);
		player->Affair->clearAffairs(tickTime);
	}

	static void staticAddAffair(const int playerID, const unsigned num, const unsigned tickTime)
	{
		playerDataPtr player = player_mgr.getOnlinePlayer(playerID);
		if (!player)return;
		player->Affair->remove_async_event(tickTime);
		player->Affair->addAffairs(num, tickTime);
	}

	void playerAffair::remove_async_event(const unsigned tickTime)
	{
		Event.erase(tickTime);
	}

	playerAffair::playerAffair(playerData* const own) :_auto_player(own)
	{
		lastAffair = Creator<AFFAIE::AffairData>::Create();
		affairList.clear();
		vector<unsigned> filter_vec;
		vector<AFFAIE::affairDataPtr> data_list = ownerland_sys.randomAffairs(10, filter_vec);
		for (unsigned i = 0; i < data_list.size(); ++i)
		{
			affairList.push_back(data_list[i]);
			if (affairList.size() > AFFAIE::MAX_AFFAIE_NUM)affairList.pop_front();
		}
		Event.clear();
		allTimes = 0;
	}

	void playerAffair::async_addAffairs(const unsigned num /* = 10 */, const unsigned tickTime /* = 0 */)
	{
		if (affairList.size() >= 20)return;
		if (tickTime > 0)Event.insert(tickTime);
		UserTask::Add(boostBind(staticAddAffair, Own().ID(), num, tickTime), State::getState());
	}

	void playerAffair::clearAffairs(const unsigned tickTime /* = 0 */)
	{
		if (tickTime > 0 && Event.find(tickTime) != Event.end())return;
		affairList.clear();
		_sign_auto();
	}

	void playerAffair::addAffairs(const unsigned num /* = 10 */, const unsigned tickTime /* = 0 */)
	{
		if (affairList.size() >= 20)return;
		if (tickTime > 0 && Event.find(tickTime) != Event.end())return;
		if (!Own().Builds->isBuildValid(LAND::idx_building_type_parliament))return;
		
		vector<unsigned> filter_vec;
		for (AFFAIE::AffairList::iterator itr = affairList.begin(); itr != affairList.end(); ++itr)
		{
			AFFAIE::affairDataPtr ptr = *itr;
			filter_vec.push_back(ptr->iFid);
		}

		const unsigned final_num = std::min(unsigned(20 - affairList.size()), num);
		vector<AFFAIE::affairDataPtr> data_list = ownerland_sys.randomAffairs(final_num, filter_vec);

		for (unsigned i = 0; i < data_list.size(); ++i)
		{
			affairList.push_back(data_list[i]);
			if (affairList.size() > AFFAIE::MAX_AFFAIE_NUM)affairList.pop_front();
		}

		_sign_auto();
	}

	void playerAffair::loadDB()
	{
		mongo::BSONObj keyFind = BSON(strPlayerID << Own().ID());
		mongo::BSONObj objFind = db_mgr.FindOne(DBN::dbPlayerAffair, keyFind);
		if (objFind.isEmpty())return;
		affairList.clear();
		vector<mongo::BSONElement> vec = objFind["arr"].Array();
		for (unsigned i = 0; i < vec.size(); ++i)
		{
			mongo::BSONElement& elem = vec[i];
			AFFAIE::affairDataPtr affair_ptr = Creator<AFFAIE::AffairData>::Create();
			affair_ptr->iFid = elem["fid"].Int();
			affair_ptr->isGold = elem["ig"].Bool();
			affair_ptr->choices = elem["cs"].Int();
			affair_ptr->freeType = elem["ft"].Int();
			affair_ptr->costType = elem["ct"].Int();
			affairList.push_back(affair_ptr);
		}
		lastAffair->iFid = objFind["lfid"].Int();
		lastAffair->isGold = objFind["lig"].Bool();
		lastAffair->choices = objFind["lcs"].Int();
		lastAffair->freeType = objFind["ft"].Int();
		lastAffair->costType = objFind["ct"].Int();
		lastAffair->freeVal = objFind["fv"].Int();
		lastAffair->costVal = objFind["cv"].Int();

		checkNotEoo(objFind["at"])
			allTimes = objFind["at"].Int();
	}

	bool playerAffair::_auto_save()
	{
		mongo::BSONObj key = BSON(strPlayerID << Own().ID());

		mongo::BSONArrayBuilder arr;
		for (AFFAIE::AffairList::iterator itr = affairList.begin(); itr != affairList.end(); ++itr)
		{
			AFFAIE::affairDataPtr ptr = *itr;
			arr << BSON("fid" << ptr->iFid << "ig" << ptr->isGold << "cs" << ptr->choices << "ft" << ptr->freeType << "ct" << ptr->costType);
		}
		mongo::BSONObj obj = BSON(strPlayerID << Own().ID() <<
			"arr" << arr.arr() << "lfid" << lastAffair->iFid <<
			"lig" << lastAffair->isGold << "lcs" << lastAffair->choices <<
			"ft" << lastAffair->freeType << "ct" << lastAffair->costType <<
			"fv" << lastAffair->freeVal << "cv" << lastAffair->costVal << "at" << allTimes);
		return db_mgr.SaveMongo(DBN::dbPlayerAffair, key, obj);
	}

	void playerAffair::_auto_update()
	{
		qValue json(qJson::qj_array), data_json(qJson::qj_array);
		AFFAIE::affairDataPtr ptr = lastAffair;
		if (!affairList.empty())
		{
			ptr = *affairList.begin();
		}
		data_json.append(ptr->iFid);
		data_json.append(ptr->isGold);
		data_json.append(ptr->choices);
		data_json.append(ptr->freeType);
		data_json.append(ptr->costType);
		if (ptr->choices != 0xFFFFFFFF)
		{
			data_json.append(ptr->freeVal);
			data_json.append(ptr->costVal);
		}
		else
		{
			data_json.append(ownerland_sys.getAffairReward(ptr->freeType, Own().LV(), false));
			data_json.append(ownerland_sys.getAffairReward(ptr->costType, Own().LV(), ptr->isGold));
		}
		json.append(res_sucess).append(data_json).append((unsigned)affairList.size());
		Own().sendToClientFillMsg(gate_client::building_affairs_update_resp, json);
	}

	AFFAIE::affairDataPtr playerAffair::getTop()
	{
		if (affairList.empty())return AFFAIE::affairDataPtr();
		return (*affairList.begin());
	}

	AFFAIE::affairDataPtr playerAffair::getShowTop()
	{
		if (affairList.empty())return lastAffair;
		return (*affairList.begin());
	}

	int playerAffair::setAffairs(const unsigned choices, const bool is_update /* = true */)
	{
		if (!Own().Builds->isBuildValid(LAND::idx_building_type_parliament))return err_illedge;
		AFFAIE::affairDataPtr ptr;
		if (!affairList.empty())
		{
			ptr = *affairList.begin();
		}
		if (!ptr)return err_illedge;

		ptr->choices = choices;
		ptr->freeVal = ownerland_sys.getAffairReward(ptr->freeType, Own().LV(), false);
		ptr->costVal = ownerland_sys.getAffairReward(ptr->costType, Own().LV(), ptr->isGold);
		lastAffair = ptr;
		affairList.pop_front();//ɾ����ǰ���
		++allTimes;
		TaskMgr::update(Own().getOwnDataPtr(), Task::AffairsAllTimes);
		TaskMgr::update(Own().getOwnDataPtr(), Task::AffairsTimes, 1);

		_auto_save();
		if (is_update)_sign_update();
		return res_sucess;
	}
}

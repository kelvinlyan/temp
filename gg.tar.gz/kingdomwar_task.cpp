#include "kingdomwar_task.h"

namespace gg
{
	namespace KingdomWar
	{
		namespace Task
		{

#define NCHECKER(name)\
	class name\
		: public ICheck2\
	{\
		public:\
			static CheckPtr2 create(const Json::Value& info)\
			{\
				LogE << "kingdom war task type not implement: " << #name << " (" << info["ty"].asInt() << ").." << LogEnd;\
				return Creator<name>::Create(info);\
			}\
			name(const Json::Value& info)\
				: ICheck(info["ty"].asInt())\
			{\
				ForEachC(Json::Value, it, info["arg"])\
					_args.push_back((*it).asInt());\
			}\
			virtual int update(ParamPtr& param, ArgPtr& arg);\
			virtual int init(int nation, ParamPtr& param);\
		protected:\
			std::vector<int> _args;\
	}
			
			NCHECKER(COccupySpecified);
			NCHECKER(CGetExploit2);
			NCHECKER(COccupyNum1);
			NCHECKER(COccupyNum2);

			int COccupySpecified::update(ParamPtr& param, ArgPtr& arg)
			{
				
			}

		}
	}
}

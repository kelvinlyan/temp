#include "map_war.h"
#include "kingdomwar_system.h"
#include "playerManager.h"
#include "man_system.h"
#include "heroparty_system.h"
#include "net_helper.hpp"
#include "chat.h"
#include "game_time.h"

namespace gg
{
	namespace KingdomWar
	{
		bool checkArmyID(playerDataPtr d, int army_id)
		{
			if (army_id < 0 || army_id >= ArmyNum)
				return false;
			if (army_id == 1 && d->LV() < 45)
				return false;
			if (army_id == 2 && d->LV() < 70)
				return false;
			return true;
		}

		bool checkLimit(playerDataPtr d)
		{
			return d->Info->Nation() != Kingdom::null 
				&& d->LV() >= 15;
		}
	}

#define CheckArmyID()\
	if (!KingdomWar::checkArmyID(d, army_id))\
		Return(r, err_illedge)

#define CheckState()\
	if (state() == KingdomWar::Closed)\
		Return(r, err_illedge)

#define LoadPlayer\
	playerDataPtr d = player_mgr.getPlayer(m.playerID);\
	if (!d || !KingdomWar::checkLimit(d))\
		Return(r, err_illedge)

	kingdomwar_system* const kingdomwar_system::_Instance = new kingdomwar_system();

	kingdomwar_system::kingdomwar_system()
	{
	}

	void kingdomwar_system::initData()
	{
		LogI << "kingdom war init start.." << LogEnd;
		addTimer();
		loadFile();
		_sign.init();
		_kingdom_buff = Creator<KingdomWar::KingdomBuff>::Create();
		_kingdom_buff->init();
		addUpdater(boostBind(kingdomwar_system::tick, this));
		_city_list.loadDB();
		loadPlayer();
		_city_list.update(true);
		_path_list.update(true);
		startTimer();
		KingdomWar::Timer::start();
		_npc_data.clear();
		LogI << "kingdom war init end.." << LogEnd;
	}

	void kingdomwar_system::timerTick()
	{
		update();
		startTimer();
	}

	void kingdomwar_system::tick()
	{
		_city_list.update();
		_path_list.update();
		if (!Observer::empty())
		{
			qValue state;
			qValue nation;
			qValue path;
			_city_list.getUpStateInfo(state);
			_city_list.getUpNationInfo(nation);
			_path_list.getUpdateInfo(path);
			if (state.isEmpty() && nation.isEmpty() && path.isEmpty())
				return;
			qValue q(qJson::qj_object);
			q.addMember("s", state);
			q.addMember("c", nation);
			q.addMember("p", path);
			qValue m(qJson::qj_object);
			qValue mm;
			mm.append(res_sucess);
			mm.append(q);
			m.addMember(strMsg, mm);
			detail::batchOnline(getObserver(), m, gate_client::kingdom_war_main_update_resp);
		}
	}
	
	static bool compareFunc1(const Json::Value& a, const Json::Value& b)
	{
		return a["id"].asInt() < b["id"].asInt();
	}

	void kingdomwar_system::loadFile()
	{
		FileJsonSeq vec;	
		vec = Common::loadFileJsonFromDir("./instance/kingdom_war/city");
		std::sort(vec.begin(), vec.end(), compareFunc1);
		ForEachC(FileJsonSeq, it, vec)
			_city_list.push(Creator<KingdomWar::City>::Create(*it));

		KingdomWar::Graph graph(vec.size());
		ForEachC(FileJsonSeq, it, vec)
		{
			const Json::Value& json = *it;
			int city_id = json["id"].asInt();
			const Json::Value& link_citys = json["relationship"];
			const Json::Value& path_types = json["relationship_type"];
			const Json::Value& cost_times = json["distance"];
			for (unsigned i = 0; i < link_citys.size(); ++i)
			{
				int link_city = link_citys[i].asInt();
				int left_city = city_id > link_city ? link_city : city_id;
				int right_city = city_id > link_city ? city_id : link_city;
				int path_id = left_city * 100 + right_city;
				KingdomWar::PathPtr ptr = getPath(path_id);
				if (!ptr)
				{
					ptr = Creator<KingdomWar::Path>::Create(path_id, city_id, link_city);
					_path_list.push(ptr);
					getCity(left_city)->addPath(ptr);
					getCity(right_city)->addPath(ptr);
				}
				ptr->setPathType(city_id, link_city, path_types[i].asInt(), cost_times[i].asInt());
				if (ptr->access(city_id, link_city))
					graph.set(city_id, link_city, cost_times[i].asInt());
			}

		}
		vector<KingdomWar::Lines> lines_list;
		for (unsigned i = 0; i < vec.size(); ++i)
		{
			KingdomWar::Lines lines;
			shortestPath_DIJ(graph, lines, i);
			lines_list.push_back(lines);
		}
		_shortest_path.load(lines_list);

		vec = Common::loadFileJsonFromDir("./instance/kingdom_war/npc");
		ForEach(FileJsonSeq, it, vec)
		{
			Json::Value& chapterMap = *it;

			MapDataCfgPtr mapDatePtr = Creator<mapDataConfig>::Create();

			mapDatePtr->mapId = chapterMap["mapId"].asInt();
			mapDatePtr->frontId = chapterMap["frontId"].asInt();
			mapDatePtr->background = chapterMap.isMember("background") ? chapterMap["background"].asInt() : 1;
			mapDatePtr->faceID = chapterMap["faceID"].asInt();
			mapDatePtr->mapName = chapterMap["mapName"].asString();
			mapDatePtr->mapLevel = chapterMap["mapLevel"].asInt();
			mapDatePtr->battleValue = chapterMap["battleValue"].asInt();
			mapDatePtr->needFood = chapterMap["needfood"].asInt();
			mapDatePtr->needAction = chapterMap["needAction"].asInt();
			mapDatePtr->chanllengeTimes = chapterMap["challengeTimes"].asInt();
			mapDatePtr->manExp = chapterMap["manExp"].asUInt();
			mapDatePtr->levelLimit = chapterMap["levelLimit"].asUInt();
			mapDatePtr->robotIDX = chapterMap["robotIDX"].asInt();
			const unsigned rwJsonID = chapterMap["winBox"].asUInt();
			mapDatePtr->winBox = actionFormat(rwJsonID);
			for (unsigned nn = 0; nn < chapterMap["army"].size(); ++nn)
			{
				Json::Value& npcJson = chapterMap["army"][nn];
				armyNPC npc;
				npc.npcID = npcJson["npcID"].asInt();
				npc.holdMorale = npcJson["holdMorale"].asBool();
				for (unsigned cn = 0; cn < characterNum; ++cn)
				{
					npc.initAttri[cn] = npcJson["initAttri"][cn].asInt();
				}
				npc.armsType = npcJson["armsType"].asInt();
				for (unsigned cn = 0; cn < armsModulesNum; ++cn)
				{
					npc.armsModule[cn] = npcJson["armsModule"][cn].asDouble();
				}
				npc.npcLevel = npcJson["npcLevel"].asInt();
				npc.npcPos = npcJson["npcPos"].asUInt() % 9;
				npc.battleValue = npcJson["battleValue"].asInt();
				npc.skill_1 = npcJson["skill_1"].asInt();
				npc.skill_2 = npcJson["skill_2"].asInt();
				for (unsigned eq_idx = 0; eq_idx < npcJson["equip"].size(); ++eq_idx)
				{
					npc.equipList.push_back(BattleEquip(npcJson["equip"][eq_idx][0u].asUInt(),
								npcJson["equip"][eq_idx][1u].asInt(),
								npcJson["equip"][eq_idx][2u].asUInt()));
				}
				mapDatePtr->npcList.push_back(npc);
			}
			sBattlePtr bptr = map_sys.npcSide(mapDatePtr);
			manList& ml = bptr->battleMan;
			for (unsigned i = 0; i < ml.size(); ++i)
				mapDatePtr->npcList[i].maxHp = ml[i]->currentHP;
			_npc_map[mapDatePtr->mapId] = mapDatePtr;
		}

		Json::Value json;
		json = Common::loadJsonFile("./instance/kingdom_war/npc_rule.json");
		ForEach(Json::Value, it, json)
			_npc_rule.push_back(KingdomWar::NpcRule(*it));
		_rand_begin = _npc_rule.front()._npc_begin;
		_rand_end = _npc_rule.front()._npc_end;

		json = Common::loadJsonFile("./instance/kingdom_war/rank_reward.json");
		ForEach(Json::Value, it, json)
			_rank_reward.push_back(actionFormatBox(*it));

		json = Common::loadJsonFile("./instance/kingdom_war/hp_cost.json");
		{
			Json::Value& ping = json["ping"];
			_win_hp_cost.push_back(ping[0u].asInt());
			_lose_hp_cost.push_back(ping[0u].asInt());
			Json::Value& win = json["win"];
			ForEach(Json::Value, it, win)
				_win_hp_cost.push_back((*it).asInt());
			Json::Value& lose = json["lose"];
			ForEach(Json::Value, it, lose)
				_lose_hp_cost.push_back((*it).asInt());
		}
		json = Common::loadJsonFile("./instance/kingdom_war/exploit.json");
		{
			Json::Value& ping = json["ping"];
			_win_exploit.push_back(ping[0u].asInt());
			_lose_exploit.push_back(ping[0u].asInt());
			Json::Value& win = json["win"];
			ForEach(Json::Value, it, win)
				_win_exploit.push_back((*it).asInt());
			Json::Value& lose = json["lose"];
			ForEach(Json::Value, it, lose)
				_lose_exploit.push_back((*it).asInt());
		}
		json = Common::loadJsonFile("./instance/kingdom_war/hp_debuff.json");
		ForEach(Json::Value, it, json)
		{
			int start = (*it)["start"].asInt();
			int end = (*it)["end"].asInt();
			int atk_debuff = (*it)["atk_debuff"].asInt();
			int def_debuff = (*it)["def_debuff"].asInt();
			for (unsigned i = start; i <= end; ++i)
			{
				if (i >= _hp_debuff.size())
					_hp_debuff.insert(_hp_debuff.end(), end + 1 - _hp_debuff.size(), KingdomWar::HpDebuff(0, 0));
				_hp_debuff[i]._atk_debuff = atk_debuff;
				_hp_debuff[i]._def_debuff = def_debuff;
			}
		}
		json = Common::loadJsonFile("./instance/kingdom_war/hp_exploit.json");
		ForEach(Json::Value, it, json)
			_hp_exploit.push_back((*it).asInt());
	}

	void kingdomwar_system::loadPlayer()
	{
		objCollection objs = db_mgr.Query(DBN::dbPlayerKingdomWarPos);
		ForEachC(objCollection, it, objs)
		{
			int pid = (*it)[strPlayerID].Int();
			int army_id = (*it)["a"].Int();
			playerDataPtr d = player_mgr.getPlayer(pid);
			if (!d) continue;
			const KingdomWar::Position& pos = d->KingDomWarPos->position(army_id);
			if (pos.type == KingdomWar::PosPath)
			{
				KingdomWar::PathPtr ptr = getPath(pos.id);
				if (!ptr) continue;
				int to_city_id = ptr->id() / 100;
				if (to_city_id == pos.from_id)
					to_city_id = ptr->id() % 100;
				addTimer(pos.time, boostBind(kingdomwar_system::loadPathPlayer, this, ptr, pos.time, pid, army_id, to_city_id));
			}
			else
			{
				KingdomWar::CityPtr ptr = getCity(pos.id);
				if (!ptr) continue;
				ptr->tryLoadPlayer(d, army_id);
			}
		}

		objs = db_mgr.Query(DBN::dbPlayerKingdomWar);
		ForEachC(objCollection, it, objs)
		{
			int pid = (*it)[strPlayerID].Int();
			playerDataPtr d = player_mgr.getPlayer(pid);
			if (!d) continue;
			if (d->KingDomWar->getExploit() > 0)
				_rank_mgr.update(d, 0);
		}
	}

	void kingdomwar_system::loadNpc()
	{
		objCollection objs = db_mgr.Query(DBN::dbKingdomWarNpc);
		ForEachC(objCollection, it, objs)
		{
			const mongo::BSONObj& obj = *it;
			int id = obj[KingdomWar::strNpcID].Int();
			if (id == 0)
				continue;
			KingdomWar::NpcDataPtr ptr = getNpc(id);
			const KingdomWar::Position& pos = ptr->position();
			if (pos.type == KingdomWar::PosPath)
			{
				KingdomWar::PathPtr p_ptr = getPath(pos.id);
				if (!p_ptr)	continue;
				int to_city_id = p_ptr->getLinkedId(pos.from_id);
				addTimer(pos.time, boostBind(kingdomwar_system::loadPathNpc, this, p_ptr, pos.time, ptr, to_city_id));
			}
			else
			{
				KingdomWar::CityPtr c_ptr = getCity(pos.id);
				if (!c_ptr) continue;
				c_ptr->tryLoadNpc(ptr);
			}
		}
	}

	sBattlePtr kingdomwar_system::getBattlePtr(playerDataPtr player, int army_id, int& max_hp, int& cur_hp)
	{
		sBattlePtr sb = Creator<sideBattle>::Create();
		sb->playerID = player->ID();
		sb->playerName = player->Name();
		sb->isPlayer = true;
		sb->playerLevel = player->LV();
		sb->playerNation = player->Info->Nation();
		sb->playerFace = player->Info->Face();
		sb->battleValue = player->KingDomWarFM->getBV(army_id);
		manList& ml = sb->battleMan;
		ml.clear();
		vector<playerManPtr> ownMan = player->KingDomWarFM->getFM(army_id);
		max_hp = 0;
		cur_hp = 0;
		for (unsigned i = 0; i < ownMan.size(); i++)
		{
			playerManPtr man = ownMan[i];
			if (!man)continue;
			mBattlePtr mbattle = Creator<manBattle>::Create();
			cfgManPtr config = man_sys.getConfig(man->mID());
			if (!config)continue;
			mbattle->manID = man->mID();
			mbattle->battleValue = man->battleValue();
			mbattle->holdMorale = config->holdMorale;
			mbattle->set_skill_1(config->skill_1);
			mbattle->set_skill_2(config->skill_2);
			mbattle->armsType = config->armsType;
			mbattle->manLevel = man->LV();
			mbattle->currentIdx = i % 9;
			memcpy(mbattle->armsModule, config->armsModules, sizeof(mbattle->armsModule));
			man->toInitialAttri(mbattle->initialAttri);
			man->toBattleAttri(player->KingDomWarFM->getFMId(army_id), mbattle->battleAttri);
			mbattle->currentHP = mbattle->getTotalAttri(idx_hp);
			max_hp += mbattle->currentHP;
			int man_hp = player->KingDomWar->manHp(man->mID());
			if (mbattle->currentHP >= man_hp)
				mbattle->currentHP = man_hp;
			else
				player->KingDomWar->setManHp(man->mID(), mbattle->currentHP);
			cur_hp += mbattle->currentHP;
			std::vector<itemPtr> equipList = man->getEquipList();
			for (unsigned pos = 0; pos < equipList.size(); ++pos)
			{
				itemPtr item = equipList[pos];
				if (item)
				{
					mbattle->equipList.push_back(BattleEquip(pos, item->itemID(), item->getLv()));
				}
			}
			if (0 == i)
			{
				sb->leaderMan = mbattle;
			}
			ml.push_back(mbattle);
		}

		/*ForEach(manList, it, sb->battleMan)
		{
			LogI << "1: " << (*it)->battleAttri[idx_phyHurtRate] << LogEnd;
			LogI << "2: " << (*it)->battleAttri[idx_phyCutRate] << LogEnd;
			LogI << "3: " << (*it)->battleAttri[idx_warHurtRate] << LogEnd;
			LogI << "4: " << (*it)->battleAttri[idx_warCutRate] << LogEnd;
			LogI << "5: " << (*it)->battleAttri[idx_magicHurtRate] << LogEnd;
			LogI << "6: " << (*it)->battleAttri[idx_magicCutRate] << LogEnd;
			LogI << "7: " << (*it)->battleAttri[idx_cureRate] << LogEnd;
		}*/

		int buff = _kingdom_buff->getBuff(player->Info->Nation());
		//LogI << "kingdom buff: " << buff << LogEnd;
		const KingdomWar::Position& pos = player->KingDomWarPos->position(army_id);
		if (pos.type != KingdomWar::PosPath)
		{
			KingdomWar::CityPtr ptr = getCity(pos.id);
			ptr->addBuff(player, sb);
		}

		ForEach(manList, it, sb->battleMan)
		{
			(*it)->battleAttri[idx_phyHurtRate] += buff;
			(*it)->battleAttri[idx_phyCutRate] += buff;
			(*it)->battleAttri[idx_warHurtRate] += buff;
			(*it)->battleAttri[idx_warCutRate] += buff;
			(*it)->battleAttri[idx_magicHurtRate] += buff;
			(*it)->battleAttri[idx_magicCutRate] += buff;
			(*it)->battleAttri[idx_cureRate] += buff;
		}

		int hp = player->KingDomWar->armyHp(army_id);
		addHpDebuff(sb, hp);

		/*ForEach(manList, it, sb->battleMan)
		{
			LogI << "1: " << (*it)->battleAttri[idx_phyHurtRate] << LogEnd;
			LogI << "2: " << (*it)->battleAttri[idx_phyCutRate] << LogEnd;
			LogI << "3: " << (*it)->battleAttri[idx_warHurtRate] << LogEnd;
			LogI << "4: " << (*it)->battleAttri[idx_warCutRate] << LogEnd;
			LogI << "5: " << (*it)->battleAttri[idx_magicHurtRate] << LogEnd;
			LogI << "6: " << (*it)->battleAttri[idx_magicCutRate] << LogEnd;
			LogI << "7: " << (*it)->battleAttri[idx_cureRate] << LogEnd;
		}*/

		return sb;
	}

	KingdomWar::CityPtr kingdomwar_system::getCity(int id)
	{
		return _city_list.getCity(id);
	}
	
	KingdomWar::PathPtr kingdomwar_system::getPath(int id)
	{
		return _path_list.getPath(id);
	}

	KingdomWar::CityPtr kingdomwar_system::getMainCity(int nation)
	{
		if (nation < 0 || nation >= Kingdom::nation_num)
			return KingdomWar::CityPtr();

		return getCity(KingdomWar::MainCity[nation]);
	}

	void kingdomwar_system::quitReq(net::Msg& m, Json::Value& r)
	{
		LoadPlayer;
		ReadJsonArray;
		int id = js_msg[0u].asInt();
		d->KingDomWar->detach(id);
		Return(r, res_sucess);
	}

	void kingdomwar_system::mainInfoReq(net::Msg& m, Json::Value& r)
	{
		LoadPlayer;
		d->KingDomWar->attach(-1);
		mainInfo(d);
	}

	void kingdomwar_system::moveReq(net::Msg& m, Json::Value& r)
	{
		CheckState();

		LoadPlayer;
		ReadJsonArray;
		int army_id = js_msg[0u].asInt();
		int to_city_id = js_msg[1u].asInt();

		CheckArmyID();

		int res = d->KingDomWarPos->move(Common::gameTime(), army_id, to_city_id, true);
		Return(r, res);
	}

	void kingdomwar_system::playerInfoReq(net::Msg& m, Json::Value& r)
	{
		LoadPlayer;
		d->KingDomWarPos->update();
	}

	void kingdomwar_system::formationReq(net::Msg& m, Json::Value& r)
	{
		LoadPlayer;
		d->KingDomWarFM->update();
	}

	void kingdomwar_system::setFormationReq(net::Msg& m, Json::Value& r)
	{
		LoadPlayer;
		ReadJsonArray;
		int army_id = js_msg[0u].asInt();
		int fm_id = js_msg[1u].asInt();
		int fm[9];
		for (unsigned i = 0; i < 9; ++i)
			fm[i] = js_msg[2u][i].asInt();

		CheckArmyID();

		int res = d->KingDomWarFM->setFormation(army_id, fm_id, fm);
		Return(r, res);
	}

	void kingdomwar_system::cityBattleInfoReq(net::Msg& m, Json::Value& r)
	{
		LoadPlayer;
		ReadJsonArray;
		int city_id = js_msg[0u].asInt();
		KingdomWar::CityPtr ptr = getCity(city_id);
		if (!ptr)
			Return(r, err_illedge);
		d->KingDomWar->attach(city_id);
		qValue rm;
		rm.append(res_sucess);
		qValue q;
		ptr->getMainInfo(q);
		rm.append(q);
		d->sendToClientFillMsg(gate_client::kingdom_war_city_battle_info_resp, rm);
	}

	void kingdomwar_system::retreatReq(net::Msg& m, Json::Value& r)
	{
		CheckState();
	
		LoadPlayer;
		ReadJsonArray;
		int army_id = js_msg[0u].asInt();

		CheckArmyID();

		int res = d->KingDomWarPos->retreat(army_id);
		r[strMsg][1u] = army_id;
		Return(r, res);
	}

	void kingdomwar_system::reportInfoReq(net::Msg& m, Json::Value& r)
	{
		LoadPlayer;
		d->KingDomWar->updateReport();
	}

	void kingdomwar_system::rankInfoReq(net::Msg& m, Json::Value& r)
	{
		LoadPlayer;
		ReadJsonArray;
		int begin = js_msg[0u].asInt();
		int end = js_msg[1u].asInt();
		qValue mq;
		mq.append(res_sucess);
		qValue q(qJson::qj_object);
		_rank_mgr.getInfo(d, begin, end, q);
		mq.append(q);
		d->sendToClientFillMsg(gate_client::kingdom_war_rank_info_resp, mq);
	}

	void kingdomwar_system::buyHpItemReq(net::Msg& m, Json::Value& r)
	{	
		LoadPlayer;
		ReadJsonArray;
		int num = js_msg[0u].asInt();
		int res = d->KingDomWar->buyHpItem(num);
		Return(r, res);
	}

	void kingdomwar_system::useHpItemReq(net::Msg& m, Json::Value& r)
	{
		CheckState();

		LoadPlayer;
		ReadJsonArray;
		int army_id = js_msg[0u].asInt();
		int res = d->KingDomWar->useHpItem(army_id, 1);
		if (res == res_sucess)
			updateHpInfo(d, army_id);
		Return(r, res);
	}

	void kingdomwar_system::outputInfoReq(net::Msg& m, Json::Value& r)
	{
		LoadPlayer;
		d->KingDomWarOutput->update();
	}

	void kingdomwar_system::getOutputReq(net::Msg& m, Json::Value& r)
	{
		LoadPlayer;
		ReadJsonArray;
		int id = js_msg[0u].asInt();
		int res = d->KingDomWarOutput->getOutput(id, r[strMsg][1u]);
		Return(r, res);
	}

	void kingdomwar_system::signGatherReq(net::Msg& m, Json::Value& r)
	{
		CheckState();

		LoadPlayer;
		ReadJsonArray;
		int id = js_msg[0u].asInt();
		int res = _sign.setSign(d, id);
		if (res == res_sucess)
		{
			updateSign(d->Info->Nation());
		}
		Return(r, res);
	}

	void kingdomwar_system::armyInfoReq(net::Msg& m, Json::Value& r)
	{
		LoadPlayer;
		ReadJsonArray;
		int army_id = js_msg[0u].asInt();
		CheckArmyID();
		updateHpInfo(d, army_id);
	}

	void kingdomwar_system::changeFormationReq(net::Msg& m, Json::Value& r)
	{
		LoadPlayer;
		ReadJsonArray;
		int army_id = js_msg[0u].asInt();
		int fm_id = js_msg[1u].asInt();
		int fm[9];
		for (unsigned i = 0; i < 9; ++i)
			fm[i] = js_msg[2u][i].asInt();
		CheckArmyID();
		int res = d->KingDomWarFM->setFormation(army_id, fm_id, fm);
		Return(r, res);
	}

	void kingdomwar_system::militaryInfoReq(net::Msg& m, Json::Value& r)
	{
		LoadPlayer;
		ReadJsonArray;
		int id = js_msg[0u].asInt();
		KingdomWar::CityPtr ptr = getCity(id);
		if (!ptr)
			Return(r, err_illedge);
		qValue mm;
		mm.append(res_sucess);
		qValue q(qJson::qj_object);
		ptr->getMilitaryInfo(q);
		mm.append(q);
		d->sendToClientFillMsg(gate_client::kingdom_war_military_info_resp, mm);
	}

	void kingdomwar_system::playerListReq(net::Msg& m, Json::Value& r)
	{
		LoadPlayer;
		ReadJsonArray;
		int id = js_msg[0u].asInt();
		int side = js_msg[1u].asInt();
		KingdomWar::CityPtr ptr = getCity(id);
		if (!ptr)
			Return(r, err_illedge);

		qValue mm;
		mm.append(res_sucess);
		qValue q(qJson::qj_object);
		ptr->getFighterList(q, side);
		mm.append(q);
		d->sendToClientFillMsg(gate_client::kingdom_war_city_player_list_resp, mm);
	}

	void kingdomwar_system::upManHpCostReq(net::Msg& m, Json::Value& r)
	{
		LoadPlayer;
		ReadJsonArray;
		Json::Value& army_id_list = js_msg[0u];
		int id = js_msg[1u].asInt();
		int cost = 0;
		ForEach(Json::Value, it, army_id_list)
		{
			int army_id = (*it).asInt();
			CheckArmyID();
			cost += d->KingDomWarFM->getUpHpCost(army_id);
		}
		r[strMsg][1u] = army_id_list;
		r[strMsg][2u] = id;
		r[strMsg][3u] = cost;
		r[strMsg][4u] = hpExploit(d->LV(), cost);
		Return(r, res_sucess);
	}

	void kingdomwar_system::upManHpReq(net::Msg& m, Json::Value& r)
	{
		CheckState();

		LoadPlayer;
		ReadJsonArray;
		Json::Value& army_id_list = js_msg[0u];
		int id = js_msg[1u].asInt();
		std::vector<int> army_id_vec;
		ForEach(Json::Value, it, army_id_list)
		{
			int army_id = (*it).asInt();
			CheckArmyID();
			army_id_vec.push_back(army_id);
		}

		int cost;
		int res = d->KingDomWarFM->upManHpByFood(army_id_vec, cost);
		if (res == res_sucess)
		{
			r[strMsg][1u] = army_id_list;
			r[strMsg][2u] = id;
			r[strMsg][3u] = cost;
			r[strMsg][4u] = hpExploit(d->LV(), cost);
		}
		Return(r, res);
	}

	void kingdomwar_system::lookUpPlayerReq(net::Msg& m, Json::Value& r)
	{
		LoadPlayer;
		ReadJsonArray;
		int pid = js_msg[0u].asInt();
		int army_id = js_msg[1u].asInt();
		playerDataPtr target = player_mgr.getPlayer(pid);
		if (!target || target->Info->Nation() == Kingdom::null
			|| target->LV() < 15)
			Return(r, err_illedge);
		if (!KingdomWar::checkArmyID(target, army_id))
			Return(r, err_illedge);
		qValue mm;
		mm.append(res_sucess);
		qValue q(qJson::qj_object);
		target->KingDomWarFM->getLookUpInfo(army_id, q);
		mm.append(q);
		d->sendToClientFillMsg(gate_client::kingdom_war_look_up_player_resp, mm);
	}

	void kingdomwar_system::getMainInfo(qValue& q)
	{
		qValue state_info;
		_city_list.getStateInfo(state_info);
		q.addMember("s", state_info);
		qValue nation_info;
		_city_list.getNationInfo(nation_info);
		q.addMember("c", nation_info);
		qValue path_info;
		_path_list.getMainInfo(path_info);
		q.addMember("p", path_info);
		qValue buff;
		_kingdom_buff->getInfo(buff);
		q.addMember("a", buff);
		q.addMember("st", _state->get());
		q.addMember("nt", _state->nextTickTime());
		q.addMember("sp", speedRate());
		q.addMember("sr", supRate());
		q.addMember("fr", foodRate());
	}

	void kingdomwar_system::mainInfo(playerDataPtr d)
	{
		qValue m;
		m.append(res_sucess);
		qValue q(qJson::qj_object);
		getMainInfo(q);
		m.append(q);
		d->sendToClientFillMsg(gate_client::kingdom_war_main_info_resp, m);

		updateSign(d);
	}

	void kingdomwar_system::mainInfo()
	{
		qValue m(qJson::qj_object);
		qValue mm;
		mm.append(res_sucess);
		qValue q(qJson::qj_object);
		getMainInfo(q);
		mm.append(q);
		m.addMember(strMsg, mm);
		detail::batchOnline(getObserver(), m, gate_client::kingdom_war_main_info_resp);
	}

	void kingdomwar_system::addTimer(unsigned tick_time, const KingdomWar::Timer::TickFunc& func)
	{
		KingdomWar::Timer::add(tick_time, func);
	}

	void kingdomwar_system::goBackMainCity(unsigned time, playerDataPtr d, int army_id, int reason)
	{
		KingdomWar::CityPtr ptr = getMainCity(d->Info->Nation());
		if (!ptr)
			return;
		ptr->enter(time, d, army_id, reason);
	}

	void kingdomwar_system::startTimer()
	{
		KingdomWar::Timer::add(Common::gameTime() + 2, boostBind(kingdomwar_system::timerTick, this));
	}

	int kingdomwar_system::getCostTime(int from_id, int to_id)
	{
		return 0;
	}

	const KingdomWar::LineInfo& kingdomwar_system::getLine(int from_id, int to_id) const
	{
		return _shortest_path.getLine(from_id, to_id);
	}

	void kingdomwar_system::updateRank(playerDataPtr d, int old_value)
	{
		_rank_mgr.update(d, old_value);
	}

	void kingdomwar_system::update()
	{
		ForEach(FuncList, it, _updaters)
			(*it)();
	}

	void kingdomwar_system::outputTick()
	{
		ForEach(Observer::IdList, it, getObserver())
		{
			playerDataPtr d = player_mgr.getOnlinePlayer(*it);
			if (!d) continue;
			d->KingDomWarOutput->update();
		}
	}

	void kingdomwar_system::tickEvery5Min()
	{
		_state->reset5MinTime();
		addTimer(_state->next5MinTime(), boostBind(kingdomwar_system::tickEvery5Min, this));

		resetRandomRange();
		ForEach(FuncList, it, _5_min_tickers)
			(*it)();
		outputTick();
	}

	void kingdomwar_system::addTimer()
	{
		_state = Creator<KingdomWar::State>::Create();
		_state->init();
		addTimer(_state->next5MinTime(), boostBind(kingdomwar_system::tickEvery5Min, this));
		addTimer(_state->nextTickTime(), boostBind(kingdomwar_system::tickState, this));
		addTimer(_state->nextClearTime(), boostBind(kingdomwar_system::tickClearTime, this));
		addTimer(_state->nextPrimeTime(), boostBind(kingdomwar_system::tickPrimeState, this));
	}

	void kingdomwar_system::addUpdater(const Func& func)
	{
		_updaters.push_back(func);
	}

	void kingdomwar_system::add5MinTicker(const Func& func)
	{
		_5_min_tickers.push_back(func);
	}

	void kingdomwar_system::resetRandomRange()
	{
		int power = heroparty_sys.getKingdomWarNpcBV();
		unsigned i = 0;
		for (; i < _npc_rule.size(); ++i)
		{
			if (power >= _npc_rule[i]._power_begin &&
				power <= _npc_rule[i]._power_end)
				break;
		}
		if (i == _npc_rule.size())
			i = _npc_rule.size() - 1;
		_rand_begin = _npc_rule[i]._npc_begin;
		_rand_end = _npc_rule[i]._npc_end;
	}

	int kingdomwar_system::randomNpcID() const
	{
		return Common::randomBetween(_rand_begin, _rand_end);
	}

	void kingdomwar_system::tickState()
	{
		unsigned tick_time = _state->nextTickTime();
		_state->resetTickTimeAndState();
		addTimer(_state->nextTickTime(), boostBind(kingdomwar_system::tickState, this));
		if (_state->get() == KingdomWar::Closed)
		{
			if (season_sys.getSeason(tick_time) == SEASON::Winter)
				tickUnity(tick_time);

			_kingdom_buff->reset(tick_time);
			_sign.clear();
			for (unsigned i = 0; i < Kingdom::nation_num; ++i)
				updateSign(i);
		}

		qValue q(qJson::qj_object);
		qValue buff;
		_kingdom_buff->getInfo(buff);
		q.addMember("a", buff);
		q.addMember("st", _state->get());
		q.addMember("nt", _state->nextTickTime());
		qValue m(qJson::qj_object);
		qValue mm;
		mm.append(res_sucess);
		mm.append(q);
		m.addMember(strMsg, mm);
		detail::batchOnline(getObserver(), m, gate_client::kingdom_war_main_update_resp);

		playerManager::playerDataVec vec = player_mgr.nationAllOnline();

		
		for (unsigned i = 0; i < vec.size(); ++i)
		{
			if (vec[i])
				vec[i]->KingDomWar->updateRedPoint();
		}
	}

	void kingdomwar_system::tickUnity(unsigned cur_time)
	{
		int nation = KingdomWar::City::unityNation();
		if (nation == -1)
			return;
		//_city_list.clear();
		//_path_list.clear();
	}

	void kingdomwar_system::tickClearTime()
	{
		_state->resetClearTime();
		addTimer(_state->nextClearTime(), boostBind(kingdomwar_system::tickClearTime, this));

		_rank_mgr.tickRank();
	}

	const ACTION::BoxList& kingdomwar_system::getRankReward(int rank) const
	{
		return rank > _rank_reward.size()? _rank_reward.back() : _rank_reward[rank - 1];
	}
	
	void kingdomwar_system::updateSign(playerDataPtr d)
	{
		qValue m;
		m.append(res_sucess);
		qValue q(qJson::qj_object);
		qValue qq;
		_sign.getInfo(qq, d->Info->Nation());
		q.addMember("c", qq);
		m.append(q);
		d->sendToClientFillMsg(gate_client::kingdom_war_sign_info_resp, m);
	}

	void kingdomwar_system::updateSign(int nation)
	{
		std::vector<int> id_list;
		ForEachC(KingdomWar::Observer::IdList, it, getObserver())
		{
			playerDataPtr d = player_mgr.getOnlinePlayer(*it);
			if (d && d->Info->Nation() == nation)
				id_list.push_back(*it);
		}
		
		qValue m(qJson::qj_object);
		qValue mm;
		mm.append(res_sucess);
		qValue q(qJson::qj_object);
		qValue qq;
		_sign.getInfo(qq, nation);
		q.addMember("c", qq);
		mm.append(q);
		m.addMember(strMsg, mm);
		detail::batchOnline(id_list, m, gate_client::kingdom_war_sign_info_resp);
	}

	void kingdomwar_system::updateHpInfo(playerDataPtr d, int army_id)
	{
		qValue m;
		m.append(res_sucess);
		qValue q(qJson::qj_object);
		d->KingDomWarFM->getHpInfo(army_id, q);
		m.append(q);
		d->sendToClientFillMsg(gate_client::kingdom_war_army_info_resp, m);
	}

	int kingdomwar_system::getCityNumOfNation(int nation)
	{
		int num = 0;
		for(unsigned i = 0; i < _city_list.size(); ++i)
		{
			KingdomWar::CityPtr ptr = getCity(i);
			if (ptr && ptr->nation() == nation)
				++num;
		}
		return num;
	}

	MapDataCfgPtr kingdomwar_system::getNpcData(int map_id)
	{
		MapDataMap::iterator it = _npc_map.find(map_id);
		return it == _npc_map.end()? MapDataCfgPtr() : it->second;
	}

	const KingdomWar::HpDebuff& kingdomwar_system::hpDebuff(int hp) const
	{
		if (hp < 0)
			hp = 0;
		if (hp >= _hp_debuff.size())
			hp = _hp_debuff.size() - 1;
		return _hp_debuff[hp];
	}

	void kingdomwar_system::addHpDebuff(sBattlePtr sb, int hp)
	{
		const KingdomWar::HpDebuff& hd = hpDebuff(hp);
		//LogI << "hp atk debuff: " << hd._atk_debuff << LogEnd;
		//LogI << "hp def debuff: " << hd._def_debuff << LogEnd;
		ForEach(manList, it, sb->battleMan)
		{
			(*it)->battleAttri[idx_phyHurtRate] -= hd._atk_debuff;
			(*it)->battleAttri[idx_phyCutRate] -= hd._def_debuff;
			(*it)->battleAttri[idx_warHurtRate] -= hd._atk_debuff;
			(*it)->battleAttri[idx_warCutRate] -= hd._def_debuff;
			(*it)->battleAttri[idx_magicHurtRate] -= hd._atk_debuff;
			(*it)->battleAttri[idx_magicCutRate] -= hd._def_debuff;
			(*it)->battleAttri[idx_cureRate] -= hd._atk_debuff;
		}
	}

	void kingdomwar_system::DoBroadcast(int nation, qValue& m)
	{
		if (nation == -1)
			chat_sys.despatchAll(CHAT::server_kingdom_war, m);
		else
			chat_sys.despatchKingdom(CHAT::server_kingdom_war, (Kingdom::NATION)nation, m);
	}

	void kingdomwar_system::updateName(playerDataPtr d)
	{
		if (!KingdomWar::checkLimit(d))
			return;

		for (unsigned i = 0; i < KingdomWar::ArmyNum; ++i)
		{
			const KingdomWar::Position& pos = d->KingDomWarPos->position(i);
			if (pos.type != KingdomWar::PosPath)
			{
				KingdomWar::CityPtr ptr = getCity(pos.id);
				if (ptr)
					ptr->updateName(d);
			}
		}
	}

	void kingdomwar_system::updateTitle(playerDataPtr d, int old_title)
	{
		if (!KingdomWar::checkLimit(d))
			return;
/*
		for (unsigned i = 0; i < KingdomWar::ArmyNum; ++i)
		{
			const KingdomWar::Position& pos = d->KingDomWarPos->position(i);
			if (pos._type != KingdomWar::PosPath)
			{
				KingdomWar::CityPtr ptr = getCity(pos._id);
				if (ptr)
					ptr->updateTitle(d, old_title);
			}
		}
*/
	}

	void kingdomwar_system::loadPathPlayer(KingdomWar::PathPtr& ptr, unsigned time, int pid, int army_id, int to_city_id)
	{
		playerDataPtr d = player_mgr.getPlayer(pid);
		if (d)
			ptr->enter(time, d, army_id, to_city_id);
	}

	void kingdomwar_system::loadPathNpc(KingdomWar::PathPtr& ptr, unsigned time, KingdomWar::NpcDataPtr d, int to_city_id)
	{
		ptr->enter(time, d, to_city_id);
	}

	void kingdomwar_system::tickPrimeState()
	{
		unsigned cur_time = _state->nextPrimeTime();
		_state->resetPrimeTimeAndState();
		addTimer(_state->nextPrimeTime(), boostBind(kingdomwar_system::tickPrimeState, this));

		_path_list.reset(cur_time);

		for (unsigned i = 0; i < Kingdom::nation_num; ++i)
		{
			KingdomWar::CityPtr ptr = getMainCity(i);
			if (ptr)
				ptr->reset(cur_time);
		}

		mainInfo();
		playerManager::playerDataVec vec = player_mgr.nationAllOnline();
		for (unsigned i = 0; i < vec.size(); ++i)
		{
			if (vec[i])
				vec[i]->KingDomWarPos->update();
		}
	}

	KingdomWar::NpcDataPtr kingdomwar_system::getNpc(int id)
	{
		NpcDataMap::iterator it = _npc_data.find(id);
		if (it != _npc_data.end())
			return it->second;
		
		mongo::BSONObj key = BSON(KingdomWar::strNpcID << id);
		mongo::BSONObj obj = db_mgr.FindOne(DBN::dbKingdomWarNpc, key);
		if (obj.isEmpty())
			return KingdomWar::NpcDataPtr();
		
		KingdomWar::NpcDataPtr ptr = Creator<KingdomWar::NpcData>::Create(obj);
		_npc_data[ptr->id()] = ptr;
		return ptr;
	}

}

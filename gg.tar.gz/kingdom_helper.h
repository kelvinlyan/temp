#pragma once

#include "auto_base.h"
#include "dbDriver.h"

namespace gg
{
	class KingdomConstructionConf
	{	
		public:
			KingdomConstructionConf(const Json::Value& info);
			
			int _id;
			int _open_lv;
			STDVECTOR(int, Vec);
			Vec _exp;
			Vec _add_num;
	};

	SHAREPTR(KingdomConstructionConf, KingdomConstructionConfPtr);
	STDMAP(int, KingdomConstructionConfPtr, KingdomConstructionConfMap);

	class KingdomContributionConf
	{
		public:
			STDVECTOR(int, Vec);

			void load(const Json::Value& info);

			int silverCost(unsigned times) const { return getValue(times, _silver_cost); }
			int silverCon(unsigned times) const { return getValue(times, _silver_con); }
			int silverConSelf(unsigned times) const { return getValue(times, _silver_con_self); }
			int goldCost(unsigned times) const { return getValue(times, _gold_cost); }
			int goldCon(unsigned times) const { return getValue(times, _gold_con); }
			int goldConSelf(unsigned times) const { return getValue(times, _gold_con_self); }
			int getConTimes(int vip) const { return getValue(vip, _actions); }
		
		private:
			int getValue(unsigned times, const Vec& vec) const
			{
				if (vec.empty())
					return 0;
				if (times >= vec.size())
					times = vec.size() - 1;
				return vec[times];
			}

			Vec _silver_cost;
			Vec _silver_con;
			Vec _silver_con_self;
			Vec _gold_cost;
			Vec _gold_con;
			Vec _gold_con_self;
			Vec _actions;
	};

	class KingdomShopConf
	{
		public:
			KingdomShopConf(const Json::Value& info);

			int _id;
			int	_consume_con;
			int _buy_times;
			int	_weight;
			Kingdom::NATION _kingdom_id;
			ACTION::BoxList _box;
	};

	SHAREPTR(KingdomShopConf, KingdomShopConfPtr);
	STDMAP(int, KingdomShopConfPtr, KingdomShopConfMap);
	STDVECTOR(KingdomShopConfPtr, KingdomShopConfList);

	class KingdomConstructionData
	{
		public:
			KingdomConstructionData(int id);
			void load(const mongo::BSONElement& obj);

			mongo::BSONObj toBSON() const;
			void getInfo(Json::Value& info) const;

			int id() const { return _id; }
			int lv() const { return _lv; }
			int addNum() const { return _add_num; }
			bool upgradeAble() const;
			void alterExp(int exp);

		private:
			void init();

		private:
			int _id;
			int _lv;
			int _exp;
			int _total_exp;
			int _add_num;
	};

	SHAREPTR(KingdomConstructionData, KingdomConstructionDataPtr);
	STDVECTOR(KingdomConstructionDataPtr, KingdomConstructionDatas);

	class KingdomConInfo
	{
		public:
			KingdomConInfo(playerDataPtr d);

			int id() const { return _pid; }
			int value() const { return _cons; } 

			void getInfo(Json::Value& info, int rk) const;

		private:
			int _pid;
			int _cons;
	};

	static bool compPlayerCon(const playerDataPtr& lft, const playerDataPtr& rhs)
	{
		if (lft->KingDom->getTotalCon() == rhs->KingDom->getTotalCon())
			return lft->ID() < rhs->ID();
		return lft->KingDom->getTotalCon() > rhs->KingDom->getTotalCon();
	}

	SHAREPTR(KingdomConInfo, KingdomConPtr);

	class KingdomConRank
	{
		public:
			KingdomConRank();
			void load(const mongo::BSONElement& obj);
			std::string toBSON() const;

			const Json::Value& getInfo() const { return _info; }

			void tick();
			void packageInfo(const KingdomConInfo& con);
			void update(playerDataPtr d, int old_con);

		private:
			typedef RankList1<KingdomConInfo> ConRank;
			ConRank _rank;
			Json::Value _info;
			// temp
			int _rk;
	};

	class KingdomInfo
		: public _auto_meta
	{
		public:
			KingdomInfo(Kingdom::NATION n);

			void init();

			void tick();
			int join(playerDataPtr d);
			int setAnnouncement(playerDataPtr d, const std::string& str);
			int playerCon(playerDataPtr d, int id, int type);
			int addConstuctionExp(int id, int con);
			void update(playerDataPtr d, int old_con);

			unsigned getPlayerNum() const { return _player_num; }
			void getConRank(Json::Value& info) const;
			void getHeroPartyRank(Json::Value& info) const;
			void getConstruction(Json::Value& info) const;
			void getBaseInfo(Json::Value& info) const;
			int getAddNum(int type) const;
			int getLevel() const;
			int getTotalLv() const;
			int getRate() const;

		private:
			virtual bool _auto_save();

			void loadInfo();
			void loadRank();
			void saveInfo();
			void saveRank();
		
			void tickHeroParty();

		private:
			Kingdom::NATION _nation;
			unsigned _player_num;
			std::string _announcement;
			KingdomConstructionDatas _constructions;
			
			int _strength_rank;
			KingdomConRank _con_rank;
			Json::Value _hero_party_info;
	};
}

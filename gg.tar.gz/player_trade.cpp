#include "player_trade.h"
#include "business.h"

namespace gg
{
	//pos
	playerCarPos::playerCarPos(playerData* const own) : _auto_player(own)
	{
		save_cd = Common::gameTime();
		move_tick = save_cd;
		last_tick = save_cd;
		p_x = 9;
		p_y = 9;
		t_x = p_x;
		t_y = p_y;
		is_dirty = false;
		force_save = false;
		mode = 0;
		been_end = true;
	}

	bool playerCarPos::_auto_save()
	{
		unsigned now = Common::gameTime();
		if (force_save || now > save_cd + 10)
		{
			force_save = false;
			return trySave();
		}
		return false;
	}

	void playerCarPos::forceSave()
	{
		force_save = true;
	}

	bool playerCarPos::setPos(const unsigned x, const unsigned y)
	{
		if (business_sys.availablePlace(x, y))
		{
			p_x = x;
			p_y = y;
			is_dirty = true;
			_sign_auto();
			return true;
		}
		return false;
	}

	bool  playerCarPos::trySave()
	{
		if (is_dirty)
		{
			save_cd = Common::gameTime();
			is_dirty = false;
			mongo::BSONObj key = BSON(strPlayerID << Own().ID());
			mongo::BSONObj obj = BSON(strPlayerID << Own().ID() <<
				"x" << p_x << "y" << p_y);
			return db_mgr.SaveMongo(DBN::dbPlayerCarPos, key, obj);
		}
		return true;
	}

	void playerCarPos::loadDB()
	{
		mongo::BSONObj key = BSON(strPlayerID << Own().ID());
		mongo::BSONObj obj = db_mgr.FindOne(DBN::dbPlayerCarPos, key);
		if (obj.isEmpty())return;
		p_x = (unsigned)obj["x"].Int();
		p_y = (unsigned)obj["y"].Int();
	}

	bool playerCarPos::set_aim(const unsigned x, const unsigned y, const int m)
	{
		if (x == p_x && y == p_y)return false;//Ŀ����ڵ�ǰλ��
		unsigned now = Common::gameTime();
		//�Ѿ������յ� ���� ����ʱ�� ���� ����5��û�з��͸�������
		if (been_end || now < move_tick || now >(last_tick + 3))
		{
			been_end = false;
			use_step = 0;
			move_tick = now;//Ŀ��ı����¼���
			last_tick = now;//�����ĸ���ʱ��ĳɵ�ǰʱ��
		}
		t_x = x;
		t_y = y;
		mode = m;
		return true;
	}

	void playerCarPos::end_move(const bool tick_area /* = true */)
	{
		t_x = p_x;
		t_y = p_y;
		use_step = 0;
		been_end = true;
		mode = 0;//�ƶ�ģʽ����
		if (tick_area)business_sys.updateMoveCar(Own().getOwnDataPtr());
	}

	int playerCarPos::update_move(const vector< std::pair<unsigned, unsigned> >& update_list)
	{
		unsigned now = Common::gameTime();
		//����ÿ8s����һ������
		if (now < move_tick || now > (last_tick + 3))
		{
			end_move();
			return err_illedge;
		}
		last_tick = now;
		const unsigned single_step = unsigned(Own().Trade->getSpeed() * 1000);//ÿ1000s�ĸ�������
		if (use_step > single_step)
		{
			move_tick += 1000;//����1000s ����������
			use_step -= single_step;//ʹ�ò�����������
		}
		const unsigned total_step = (now - move_tick + 1) * Own().Trade->getSpeed();//ʱ��/�ٶ�


		bool weishe_buff = Own().Trade->checkBuff(TradeBuff::weishe);
		int res = res_sucess;
		for (unsigned i = 0; i < update_list.size(); ++i)
		{
			const unsigned x = update_list[i].first;
			const unsigned y = update_list[i].second;
			if (x == p_x && y == p_y)continue;
			if (total_step <= use_step){ res = err_car_move_too_fast; break;}
			if ((x > p_x && x - p_x > 1) || (x < p_x && p_x - x > 1)){ res = err_car_move_too_far; break; }
			if ((y > p_y && y - p_y > 1) || (y < p_y && p_y - y > 1)){ res = err_car_move_too_far; break; }
			if (business_sys.availablePlace(x, y))
			{
				p_x = x;
				p_y = y;
				is_dirty = true;
				if (!weishe_buff && business_sys.inSharkArea(x, y))
				{
					Own().Trade->alterDurable(-5);
				}
				if (t_x == p_x && t_y == p_y)
				{
					end_move(false);
					break;
				}
				++use_step;
				continue;
			}
			res = err_car_move_forbidden;
			break;
		}
		if (is_dirty)
		{
			business_sys.updateMoveCar(Own().getOwnDataPtr());
			_sign_auto();
		}
		return res;
	}

	//trade
	static struct CfgCar
	{
		vector<double> speeds;
		vector<unsigned> exps;
		vector<int> durables;
		vector<unsigned> bags;
		vector<int> sales;
	}_cfg_Car;

	const CfgCar& staticCar()
	{
		return _cfg_Car;
	}

	playerTrade::playerTrade(playerData* const own) : _auto_player(own)
	{
		base_save = false;
		item_save = false;
		buff_save = false;
		base_update = false;
		item_update = false;
		buff_update = false;
		wares.clear();
		itemNum = 0;
		//��ֻ��Ϣ
		level = 1;
		exp = 0;
		durable = staticCar().durables[level];
		//durable = 0;
		//������Ϣ
		money = 0;
		completem = 0;
		tasktype = TradeType::null;
		tasktimes = 0;
		hitPirTimes = 0;
		totaltask = 0;
		historyMax = 0;
		totalMoney = 0;
		//buff
		Buffs.clear();
	}

	void playerTrade::initData()
	{
		Json::Value json = Common::loadJsonFile("./instance/business/car.json");
		_cfg_Car.speeds.clear();
		for (unsigned i = 0; i < json["speed"].size(); i++)
		{
			_cfg_Car.speeds.push_back(json["speed"][i].asDouble());
		}
		_cfg_Car.exps.clear();
		for (unsigned i = 0; i < json["exp"].size(); i++)
		{
			_cfg_Car.exps.push_back(json["exp"][i].asUInt());
		}
		_cfg_Car.durables.clear();
		for (unsigned i = 0; i < json["durable"].size(); i++)
		{
			_cfg_Car.durables.push_back(json["durable"][i].asInt());
		}
		_cfg_Car.bags.clear();
		for (unsigned i = 0; i < json["bag"].size(); i++)
		{
			_cfg_Car.bags.push_back(json["bag"][i].asUInt());
		}
		_cfg_Car.sales.clear();
		for (unsigned i = 0; i < json["sale"].size(); i++)
		{
			_cfg_Car.sales.push_back(json["sale"][i].asInt());
		}
	}

	void playerTrade::tickPirate()
	{
		++hitPirTimes;
		base_save = true;
		base_update = true;
		_sign_auto();
	}

	int playerTrade::acceptTask(const int m, const int t)
	{
		if (taskType() != TradeType::null)return err_trade_has_task;
		money = m;
		completem = t;
		tasktype = TradeType::runing;
		++tasktimes;
		base_save = true;
		base_update = true;
		_sign_auto();
		return res_sucess;
	}

	void playerTrade::cancelTask()
	{
		tasktype = TradeType::null;
		money = 0;
		completem = 0;
		base_save = true;
		base_update = true;
		wares.clear();
		item_update = true;
		item_save = true;
		_sign_auto();
	}

	int playerTrade::overTask()
	{
		if (taskType() == TradeType::null)return err_illedge;
		tasktype = TradeType::null;//����Ϊ��
		int max_money = std::max(money, completem);
		if (max_money > historyMax)
		{
			historyMax = max_money;
		}
		totalMoney += max_money;
		totalMoney = totalMoney > 2000000000 ? 2000000000 : totalMoney;
		++totaltask;//�ۼ���ɴ���
		business_sys.insertDayRich(Own().getOwnDataPtr(), max_money);
		business_sys.insertHisRich(Own().getOwnDataPtr(), historyMax);
		business_sys.insertTotalRich(Own().getOwnDataPtr(), totalMoney);
		money = 0;
		completem = 0;
		base_save = true;
		base_update = true;

		wares.clear();
		itemNum = 0;
		item_update = true;
		item_save = true;
 		_sign_auto();
		return res_sucess;
	}

	playerTrade::playerWarePtr playerTrade::getWare(const int wareID)
	{
		WareMap::iterator it = wares.find(wareID);
		if (it == wares.end())return playerWarePtr();
		return it->second;
	}

	bool playerTrade::checkWare(const int wareID, const unsigned num)
	{
		playerWarePtr ware = getWare(wareID);
		if (!ware || ware->wareNum < num)return false;
		return true;
	}

	int playerTrade::addWare(const int wareID, const unsigned num, const int unit_price)
	{
		if (num < 1)return err_illedge;
		if (num + itemNum > staticCar().bags[level])return err_trade_bag_full;
		playerWarePtr ware = getWare(wareID);
		if (!ware)
		{
			ware = Creator<Ware>::Create();
			ware->wareID = wareID;
			wares[ware->wareID] = ware;
		}
		ware->avPrice = (ware->avPrice * ware->wareNum + unit_price * num) / (ware->wareNum + num);
		ware->wareNum += num;
		itemNum += num;
		item_update = true;
		item_save = true;
		_sign_auto();
		return res_sucess;
	}

	int playerTrade::removeWare(const int wareID, const unsigned num)
	{
		if (!checkWare(wareID, num))return err_illedge;
		playerWarePtr ware = getWare(wareID);
		ware->wareNum -= num;
		if (ware->wareNum == 0)
		{
			wares.erase(ware->wareID);
		}
		itemNum -= num;
		item_update = true;
		item_save = true;
		_sign_auto();
		return res_sucess;
	}

	void playerTrade::updateBase()
	{
		Json::Value json;
		json[strMsg][0u] = res_sucess;
		Json::Value& data_json = json[strMsg][1u];
		data_json["lv"] = level;
		data_json["e"] = exp;
		data_json["d"] = durable;
		data_json["m"] = money;
		data_json["cm"] = completem;
		data_json["tk"] = tasktimes;
		data_json["tt"] = totaltask;
		data_json["hm"] = historyMax;
		data_json["tp"] = tasktype;
		data_json["tm"] = totalMoney;
		data_json["hpt"] = hitPirTimes;
		Own().sendToClient(gate_client::player_trade_base_resp, json);
	}

	void playerTrade::updateWare()
	{
		Json::Value json;
		json[strMsg][0u] = res_sucess;
		Json::Value& data_json = json[strMsg][1u] = Json::arrayValue;
		for (WareMap::iterator it = wares.begin(); it != wares.end(); ++it)
		{
			playerWarePtr ware = it->second;
			Json::Value item_json;
			item_json.append(ware->wareID);
			item_json.append(ware->wareNum);
			item_json.append(ware->avPrice);
			data_json.append(item_json);
		}
		Own().sendToClient(gate_client::player_trade_ware_resp, json);
	}

	void playerTrade::updateBuff()
	{
		Json::Value json;
		json[strMsg][0u] = res_sucess;
		Json::Value& data_json = json[strMsg][1u] = Json::arrayValue;
		const unsigned now = Common::gameTime();
		for (BuffMap::iterator it = Buffs.begin(); it != Buffs.end();)
		{
			const TradeBuff::ID id = it->first;
			const unsigned over = it->second;
			++it;
			if (now >= over)continue;
			Json::Value buff_json;
			buff_json.append(id);
			buff_json.append(over);
			data_json.append(buff_json);
		}
		Own().sendToClient(gate_client::player_trade_buff_resp, json);
	}

	bool playerTrade::checkBuff(const TradeBuff::ID id)
	{
		unsigned now = Common::gameTime();
		BuffMap::iterator it = Buffs.find(id);
		if (it == Buffs.end())return false;
		if (now >= it->second)
		{
			Buffs.erase(it);
			buff_save = true;
			buff_update = true;
			_sign_auto();
			return false;
		}
		return true;
	}

	bool playerTrade::insertBuff(const TradeBuff::ID id, const unsigned time)
	{
		if (!checkBuff(id))
		{
			Buffs[id] = Common::gameTime() + time;
			buff_save = true;
			buff_update = true;
			_sign_auto();
			return true;
		}
		return false;
	}

	void playerTrade::_auto_update()
	{
		if (base_update)
		{
			base_update = false;
			updateBase();
		}
		if (item_update)
		{
			item_update = false;
			updateWare();
		}
		if (buff_update)
		{
			buff_update = false;
			updateBuff();
		}
	}

	bool playerTrade::_auto_save()
	{
		mongo::BSONObj key = BSON(strPlayerID << Own().ID());
		if (base_save)
		{
			base_save = false;
			mongo::BSONObj obj = BSON(strPlayerID << Own().ID() <<
				"lv" << level << "e" << exp << "d" << durable << "m" <<
				money << "cm" << completem << "tk" << tasktimes <<
				"tt" << totaltask << "hm" << historyMax << "tp" <<
				tasktype << "tm" << totalMoney << "hpt" << hitPirTimes);
			db_mgr.SaveMongo(DBN::dbPlayerTrade, key, obj);
		}
		if (item_save)
		{
			item_save = false;
			mongo::BSONArrayBuilder arr;
			for (WareMap::iterator it = wares.begin(); it != wares.end(); ++it)
			{
				playerWarePtr ware = it->second;
				arr << BSON("i" << ware->wareID << "n" << ware->wareNum <<
					"p" << ware->avPrice);
			}
			mongo::BSONObj obj = BSON(strPlayerID << Own().ID() <<
				"v" << arr.arr());
			db_mgr.SaveMongo(DBN::dbPlayerTradeItem, key, obj);
		};
		if (buff_save)
		{
			buff_save = false;
			const unsigned now = Common::gameTime();
			mongo::BSONArrayBuilder arr;
			for (BuffMap::iterator it = Buffs.begin(); it != Buffs.end();)
			{
				const TradeBuff::ID id = it->first;
				const unsigned over = it->second;
				++it;
				if (now >= over)
				{
					Buffs.erase(id);
					continue;
				}
				arr << BSON("i" << id << "o" << over);
			}
			mongo::BSONObj obj = BSON(strPlayerID << Own().ID() <<
				"v" << arr.arr());
			db_mgr.SaveMongo(DBN::dbPlayerTradeBuff, key, obj);
		}
		return true;
	}

	//base
	int playerTrade::addExp(const unsigned num)
	{
		const vector<unsigned> exps = staticCar().exps;
		if (level >= exps.size())return err_trade_car_level_max;
		const unsigned old_level = level;
		this->exp += num;
		for (unsigned idx = level; idx < exps.size(); ++idx)
		{
			if (this->exp >= exps[idx])
			{
				this->exp -= exps[idx];
				level = idx + 1;
				continue;
			}
			break;
		}
		if (level >= exps.size())
		{
			this->exp = 0;
		}
		if (old_level != level)
		{
			Log(DBLOG::strLogBusiness, Own().getOwnDataPtr(), 5, old_level, level);
			durable = staticCar().durables[level];
		}
		base_update = true;
		base_save = true;
		_sign_auto();
		return 0;
	}
	double playerTrade::getSpeed()
	{
		return staticCar().speeds[level];
	}
	int playerTrade::getSaleRate()
	{
		return staticCar().sales[level];
	}

	void playerTrade::alterMoney(const int num)
	{
		money += num;
		money = money < 0 ? 0 : money;
		if (tasktype == TradeType::runing && money >= completem)
		{
			tasktype = TradeType::complete;
		}
		base_update = true;
		base_save = true;
		_sign_auto();
	}
	
	double playerTrade::getDurableRate()
	{
		const double md = staticCar().durables[level];
		return durable / md;
	}

	unsigned playerTrade::getDurableLimit()
	{
		const int md = staticCar().durables[level];
		if (md > durable)return md - durable;
		return 0;
	}

	void playerTrade::fullDurable()
	{
		durable = staticCar().durables[level];
		base_update = true;
		base_save = true;
		_sign_auto();
	}

	void playerTrade::alterDurable(const int num)
	{
		durable += num;
		durable = durable < 0 ? 0 : durable;
		base_update = true;
		base_save = true;
		_sign_auto();
	}

	void playerTrade::loadDB()
	{
		mongo::BSONObj key = BSON(strPlayerID << Own().ID());
		{//base
			mongo::BSONObj obj = db_mgr.FindOne(DBN::dbPlayerTrade, key);
			if (!obj.isEmpty())
			{
				level = (unsigned)obj["lv"].Int();
				exp = (unsigned)obj["e"].Int();
				durable = obj["d"].Int();
				money = obj["m"].Int();
				tasktimes = (unsigned)obj["tk"].Int();
				if (!obj["hpt"].eoo())hitPirTimes = obj["hpt"].Int();
				totaltask = (unsigned)obj["tt"].Int();
				historyMax = obj["hm"].Int();
				completem = obj["cm"].Int();
				tasktype = (TradeType::Type)obj["tp"].Int();
				totalMoney = obj["tm"].Int();
			}
		};//base
		{//item
			mongo::BSONObj obj = db_mgr.FindOne(DBN::dbPlayerTradeItem, key);
			if (!obj.isEmpty())
			{
				vector<mongo::BSONElement> elems = obj["v"].Array();
				for (unsigned i = 0; i < elems.size(); ++i)
				{
					mongo::BSONElement& elem = elems[i];
					playerWarePtr ware = Creator<Ware>::Create();
					ware->wareID = elem["i"].Int();
					ware->wareNum = (unsigned)elem["n"].Int();
					ware->avPrice = elem["p"].Int();
					wares[ware->wareID] = ware;
					itemNum += ware->wareNum;
				}
			}
		};//item
		{//buff
			mongo::BSONObj obj = db_mgr.FindOne(DBN::dbPlayerTradeBuff, key);
			if (!obj.isEmpty())
			{
				const unsigned now = Common::gameTime();
				vector<mongo::BSONElement> elems = obj["v"].Array();
				for (unsigned i = 0; i < elems.size(); ++i)
				{
					mongo::BSONElement& elem = elems[i];
					const TradeBuff::ID id = (TradeBuff::ID)elem["i"].Int();
					const unsigned over = (unsigned)elem["o"].Int();
					if (now >= over)continue;
					Buffs[id] = over;
				}
			}
		};//buff
	}
}
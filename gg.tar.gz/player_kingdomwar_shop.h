#pragma once

#include "auto_base.h"
#include "mongoDB.h"

namespace gg
{
	class playerKingdomWarShop
		: public _auto_player
	{
		public:
			playerKingdomWarShop(playerData* const own);

			void loadDB();
			virtual bool _auto_save();
			virtual void _auto_update();

			void update();
			int buy(int pos, int id, Json::Value& r);
			int flush();
			void dailyTick();
			int getUsedExploit() const { return _used_exploit; }
			void alterUsedExploit(int num);

		private:
			void checkShopRecord();

			struct Record
			{
				Record(int id, int buy_times)
					: _id(id), _buy_times(buy_times){}

				int _id;	
				int _buy_times;
			};

			std::vector<Record> _records;
			unsigned _flush_times;
			int _used_exploit;
	};
}

#pragma once

#include "kingdomwar_task.h"

namespace gg
{
	namespace KingdomWar
	{
		namespace Task
		{
			class PersonTaskConfig;
			
			class Record
			{
				public:
					Record(): _id(-1){}

					void load(const mongo::BSONElement& obj);
					void load(const PersonTaskConfig& config, playerDataPtr d);
					mongo::BSONObj toBSON() const;
					void getInfo(qValue& q) const;
					
					int id() const { return _id; }
					int state() const { return _state; }
					int type()
					{
						if (!_checker && !getChecker())
							return Empty;
						return _checker->type();
					}
					void setState(int s) { _state = s; }

					void update(playerDataPtr d, ArgPtr& arg);

				private:
					bool getChecker();

				private:
					int _id;
					int _state;
					ParamPtr _param;
					CheckPtr _checker;
			};
		}
	}

	class playerKingdomWarTask
		: public _auto_player
	{
		public:
			playerKingdomWarTask(playerData* const own);

			void loadDB();
			void update();

			void update(int type, KingdomWar::Task::ArgPtr& arg);
			int getPersonTaskReward();

		private:
			void checkAndUpdate();

			virtual bool _auto_save();
			virtual void _auto_update();
			
		private:
			KingdomWar::Task::Record _person_task;
			unsigned _next_update_time;
	};
}

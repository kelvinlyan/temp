#pragma once

#include "action_system.h"
#include "broadcast_check.h"
#include "dbDriver.h"
#include "commom.h"

#define search_sys (*gg::search_system::_Instance)

namespace gg
{
	namespace Search
	{
		enum
		{
			NotSet = 0,
			Servant,
			Athens,
			Counsellor,
			Clost,

			LvLimit = 26,
			ShopItemCount = 8,
		};

		struct Cost
		{
			Cost(const Json::Value& info);

			int get(int lv, int times) const;

			STDVECTOR(int, Times2Cost);
			STDVECTOR(Times2Cost, Lv2Cost);
			Lv2Cost _lv_cost;
		};

		struct Config
		{
			Config(const Json::Value& info);
			
			int _id;
			unsigned _need_time;
			std::vector<Cost> _silver;
			std::vector<Cost> _wood;
			std::vector<Cost> _iron;
			std::vector<Cost> _gold;
			std::vector<int> _vip;
			std::vector<acPtrList> _reward;
		};

		struct ShopData
		{	
			ShopData(Json::Value& info);

			int _id;
			int	_consume_con;
			int _buy_times;
			int	_weight;
			Kingdom::NATION _kingdom_id;
			ACTION::BoxList _box;
		};

	};
	
	SHAREPTR(Search::Config, SearchConfig);
	UNORDERMAP(int, SearchConfig, SearchConfigMap);
	SHAREPTR(Search::ShopData, SearchShopData);
	UNORDERMAP(int, SearchShopData, SearchShopMap);
	STDVECTOR(SearchShopData, SearchShopList);

	class search_system
		: public actionResCheck
	{
		public:
			STDVECTOR(int, IdList);

			static search_system* const _Instance;
			void initData();
			
			SearchConfig getConfig(int id);
			SearchShopData getShopData(int id);

			DeclareRegFunction(getData);
			DeclareRegFunction(searchFor);     
			DeclareRegFunction(getReward);
			DeclareRegFunction(cancelID);

			DeclareRegFunction(shopInfo);
			DeclareRegFunction(buy);
			DeclareRegFunction(flush);

			void getShopList(int nation, IdList& id_list);
			int getFlushCost(unsigned times);

		private:
			void loadFile();
			virtual void onItemBroadcast(playerDataPtr player, const unsigned channel, const Json::Value& info_json);

		private:
			SearchConfigMap _config_map;
			SearchShopMap _shop_map;

			SearchShopList _shopRd[Kingdom::nation_num + 1];
			SearchShopList _shopFix[Kingdom::nation_num + 1];
			unsigned _weight[Kingdom::nation_num + 1];
			std::vector<int> _flush_costs;
	};
}

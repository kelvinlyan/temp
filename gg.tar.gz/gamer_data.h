//###################################
//create by Jim
//2015-11-04
//###################################

#pragma once

#include "auto_do.h"

namespace gg
{
	namespace Gender
	{
		enum SEX
		{
			Other = -1,
			Male,
			Female,
		};
	}

	namespace Kingdom
	{
		enum NATION
		{
			null = -1,
			wei = 0,
			shu = 1,
			wu = 2,
			nation_num = 3, //��Ч�Ĺ�������
			nation_total = 4, //������Ч����Ч�Ĺ���
			nation_invaild_idx = 3,//������ʾ��Ч���ҵ�idx
		};
	}

	//
	const static string strPlayerName = "pn";
	const static string strPlayerLV = "plv";

	class playerBase :
		public _auto_player
	{
		friend class playerManager;
	public:
		static unsigned MAXLEVEL();
		static unsigned MAXVIPLEVEL();

		playerBase(playerData* const own, const int pID);
		playerBase(playerData* const own, const string pN);
		playerBase(playerData* const own, const int pID, const string pN);
		static void initData();
		inline int ID(){ return playerID; }
		inline string Name(){ return playerName; }
		inline unsigned LV(){ return playerLV; }
		inline unsigned EXP(){ return playerExp; }
		inline int Face(){ return playerFaceID; }
		inline int Official() { return playerOfficial; }
		inline bool Salary() { return bGetOfficialSalary; }
		inline Gender::SEX Sex(){ return playerGender; }
		inline unsigned NationIDX(){
			if (playerNation > Kingdom::null && playerNation < Kingdom::nation_num)return playerNation;
			return Kingdom::nation_invaild_idx;
		}
		inline Kingdom::NATION Nation(){ return playerNation; }
		inline unsigned renameTis(){ return renameTimes; }
		inline unsigned VipLv(){ return playerVipLv; }
		inline unsigned VipExp(){ return playerVipExp; }
		inline int RankNo_(){ return rankNo_; };
		//inline int NationOf_(){ return nationOfficial; }
		int NationOf_();
		inline unsigned CreateTime(){ return playerCreate; }
		inline unsigned LastOnline(){ return OnlineTime; }
		void Online();
		bool motifyName(const string name);
		void setSex(const Gender::SEX type);
		void setNation(const Kingdom::NATION type);
		void setFace(const int id);
		void setSalary(bool bGet);
		void setOfficial(const int officialAdd = 1);
		void tickRename();
		int addExp(const unsigned val);
		int addVipExp(const unsigned val);
		void setProcess(const unsigned pro);
		void motifyNo_(const int no);
		void motifyNationOf_(const int of);
		bool loadDB();
		bool isMaxLevel();
		virtual void _auto_update();
		virtual bool _auto_save();
		//gm �ӿ�
		void setLV_gm(const unsigned lv);
		void setExp_gm(const unsigned exp);
		void setDone_gm(const unsigned old);
	private:
		void onVipAlter(const unsigned old, const unsigned now);
		void onLevelAlter(const unsigned old, const unsigned now);
		void onOfficialAlter(const int now);
		void upgrade();
		void onNameMotify(const string oldName);
		void onSetNation(const Kingdom::NATION old);
		void onSetFace(const int iOld);
		void initial();
		int playerID;
		string playerName;
		unsigned playerLV;
		unsigned LVUpLast;
		unsigned playerCreate;
		unsigned playerExp;
		unsigned playerVipLv;
		unsigned playerVipExp;
		int playerFaceID;
		int playerOfficial;// ��ְ
		bool bGetOfficialSalary;// �Ƿ���ȡ��ְٺ»
		Gender::SEX playerGender;
		Kingdom::NATION playerNation;
		unsigned renameTimes;
		int playerProcess;//�ͻ�����������
		int rankNo_;//ȺӢ������//Ĭ��������
		//int nationOfficial;//���ҹ�λ
		unsigned OnlineTime;
	};
}

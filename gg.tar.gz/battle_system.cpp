#include "battle_system.h"
#include "playerManager.h"
#include "skill.h"
#include "net_helper.hpp"
#include "man_system.h"

namespace gg
{
	battle_system* const battle_system::_Instance = new battle_system();

	const static unsigned BigRound_ = 30;
	const static unsigned LittleRound_ = 9;
	const static unsigned PriorityXY_[3][3] = { { 0, 1, 2 }, { 1, 0, 2 }, { 2, 1, 0 } };//ս��˳��

	//���˵��Ĺؼ���
	UNORDERSET(string, KEYSET);
	static KEYSET ReserveKey, ReserveKeyT;

	namespace BattleData
	{
		//���ܵ�Ԫ
		class unit
		{
		public:
			unit(const unsigned idx_, const unsigned round_,
				const sBattlePtr atk_, const sBattlePtr def_,
				const bool bring, const unsigned counter)
				: envIdx_(idx_), currentRound_(round_), atkHand_(atk_), defHand_(def_),
				bring_(bring), counter_(counter),
				junit_(qJson::qj_array)
			{
				currentIdx = 0;
				aim.clear();
			}
			~unit(){}
			void nextAim()
			{
				++currentIdx;
			}
			inline unsigned currentIDX()
			{
				return currentIdx;
			}
			bool isLastAim()
			{
				return ((currentIdx + 1) == aim.size());
			}
			class aimData;
			SHAREPTR(aimData, aimPtr);
			class aimData
			{
			public:
				aimData(const unsigned pos, mBattlePtr aim) : pos_(pos)
				{
					aim_ = aim;
					state_ = 0;
					statusList_.clear();
					currentIdx_ = 0;
				}
				aimData(const unsigned pos, aimPtr aPtr) : pos_(pos)
				{
					aim_ = aPtr->aim_;
					state_ = aPtr->state_;
					statusList_ = aPtr->statusList_;
					currentIdx_ = 0;
				}
				bool satisfyGlobal(const unsigned require)
				{
					if (require == 0x0 || require == 0x10000000)return true;
					return (
						(bool((0x10000000 & require) != 0) && bool((state_ & require) != 0)) ||
						(!bool((0x10000000 & require) != 0) && bool((state_ & require) == require))
						);
				}
				bool satisfy(const int part, const unsigned require)
				{
					if (require == 0x0 || require == 0x10000000)return true;
					if (part < 0 || part >= (int)statusList_.size())return satisfyGlobal(require);
					return (
						(bool((0x10000000 & require) != 0) && bool((statusList_[part] & require) != 0)) ||
						(!bool((0x10000000 & require) != 0) && bool((statusList_[part] & require) == require))
						);
				}
				void setState(const int state)
				{
					state_ |= state;
					if (statusList_.empty())return;
					statusList_[currentIdx_] |= state;
				}
				void initialState(const unsigned size)
				{
					statusList_.resize(size);
					currentIdx_ = 0;
				}
				void nextState()
				{
					if (currentIdx_ + 1 < statusList_.size())return;
					++currentIdx_;
				}
				const unsigned pos_;//λ��
				mBattlePtr aim_;//Ŀ��
			private:
				unsigned currentIdx_;
				unsigned state_;//ȫ��״̬
				vector<int> statusList_;//���ܿ�״̬
			};
			void initialCurrentAim(const unsigned size)
			{
				aimPtr ptr = currenAim();
				if (!ptr)ptr->initialState(size);
			}
			bool satisfy(const int refaim, const int part, const unsigned require)
			{
				if (require == 0x0)return true;
				if (refaim < 0)return (currenAim() ? currenAim()->satisfy(part, require) : false);
				if (refaim >= (int)aim.size())return false;
				return aim[refaim]->satisfy(part, require);
			}
			aimPtr currenAim()
			{
				if (currentIdx < aim.size())return aim[currentIdx];
				return aimPtr();
			}
			aimPtr mainAim()
			{
				if (aim.empty())return aimPtr();
				return aim[0];
			}
			inline bool hasMainAim()
			{
				return !aim.empty();
			}
			inline void pushAim(aimPtr aPtr)
			{
				aim.push_back(Creator<aimData>::Create(aim.size(), aPtr));
			}
			inline void pushAim(mBattlePtr mPtr)
			{
				aim.push_back(Creator<aimData>::Create(aim.size(), mPtr));
			}
			inline void clearAim()
			{
				aim.clear();
			}
			inline unsigned sizeAim()
			{
				return aim.size();
			}
			inline bool noAim()
			{
				return aim.empty();
			}
			void copyAimTo(unitPtr uni, const bool nstate = true)
			{
				uni->clearAim();
				for (unsigned i = 0; i < aim.size(); ++i)
				{
					aimPtr c_aim = aim[i];
					if (nstate)uni->pushAim(c_aim->aim_);
					else uni->pushAim(c_aim);
				}
			}
			qValue toJaim()
			{
				qValue jaim(qJson::qj_array);
				for (unsigned i = 0; i < aim.size(); ++i)
				{
					jaim.append(aim[i]->aim_->currentIdx);
				}
				return jaim;
			}
			qValue junit_;//�����Ϣ//�ض����ڵ�
			const unsigned envIdx_;//��ǰ������idx
			const unsigned currentRound_;//��ǰ�غ�
			const sBattlePtr atkHand_, defHand_;//���ط�
			const unsigned counter_;//����������
			const bool bring_;//�Ƿ����������
		private:
			unsigned currentIdx;//��ǰĿ���IDX
			vector<aimPtr> aim;
		};

		class environment
		{
		public:
			environment(const unsigned round_, const sBattlePtr atk_,
				const sBattlePtr def_)
				:currentRound_(round_), atkHand_(atk_), defHand_(def_),
				jVal_(qJson::qj_array)
			{
				hpPool_ = 0;
				mpPool_ = 0;
				//scrap_ = false;
				unitList.clear();
			}
			~environment(){};
			unit::aimPtr FirstCounter()
			{
				for (unsigned i = 0; i < unitList.size(); ++i)
				{
					unitPtr ptr = unitList[i];
					unit::aimPtr aimMain = ptr->mainAim();
					if (!aimMain)continue;
					if (ptr->bring_ && aimMain->satisfyGlobal(ptr->counter_))return aimMain;
				}
				return unit::aimPtr();
			}
			inline mBattlePtr currentUser()
			{
				return atkHand_->currentHand();
			}
			inline unsigned unitLength(){ return unitList.size(); }
			inline bool unitEmpty(){ return unitList.empty(); }
			unitPtr newUnit(const bool bring = false, const unsigned counter = 0)//���ӻ���
			{
				unitPtr ptr = Creator<unit>::Create(unitList.size(), currentRound_, atkHand_, defHand_, bring, counter);
				unitList.push_back(ptr);
				return ptr;
			}
			unitPtr getEnv(const unsigned idx_)//��ȡ����
			{
				if (idx_ < unitList.size())return unitList[idx_];
				return unitPtr();
			}
			unitPtr getLast()
			{
				if (unitList.empty())return unitPtr();
				return unitList.back();
			}
			void jSkillDone()
			{
				for (unsigned i = 0; i < 1 && i < unitList.size(); ++i)
				{
					unitPtr uni = unitList[i];
					jVal_.append(uni->toJaim()).
						append(uni->junit_);
				}
			}
			void jEffectDone()
			{
				qValue roundjson(qJson::qj_array);
				for (unsigned i = 0; i < unitList.size(); ++i)
				{
					unitPtr uni = unitList[i];
					roundjson.append(uni->junit_);
				}
				jVal_.append(roundjson);
			}
			const unsigned currentRound_;//��ǰ�غ�
			const sBattlePtr atkHand_, defHand_;//���ط�
			int hpPool_;//Ѫ��
			int mpPool_;//����
			qValue jVal_;//һ����������������
		private:
			vector<unitPtr> unitList;
		};
	}

	//battle data recall
	const static std::string strRpUnify = "temp/";
	static unsigned rpLoopID = 0;
	const string writeToFile(const string& report)
	{
		const static unsigned long mlength = 3145728;
		static unsigned char* buffer = (unsigned char*)::GNew(mlength);//3m
		rpLoopID = ++rpLoopID % 3000;
		const string ePath = strRpUnify + Common::toString(rpLoopID);
		const string tofilePath = strRpDirRoot + ePath;
		try
		{
			std::ofstream f(tofilePath.c_str(), std::ios::out | std::ios::trunc | std::ios::binary);
			unsigned long lsize = mlength;
			int res = compress(buffer, &lsize, (const unsigned char*)report.c_str(), report.length());
			if (res != Z_OK){
				LogE << "zlib compress failed ... error code :" << res << LogEnd;
				f.close();
				return "";
			}
			else{
				f.write((const char*)buffer, lsize);
				f.flush();
				f.close();
			}
		}
		catch (std::exception& e)
		{
			LogE << e.what() << LogEnd;
			return "";
		}
		return ePath;
	}

	static void noticeClient(const int type, const string report, Json::Value extra, std::set<int> noticeList, std::vector<string> bkList)
	{
		string write_path = writeToFile(report);
		if (!write_path.empty())
		{
			const string fullPath_from = strRpDirRoot + write_path;
			Json::Value json;
			json[strMsg][0u] = res_sucess;
			json[strMsg][1u] = type;//ս������
			json[strMsg][2u] = write_path;//ս����ַ
			json[strMsg][3u] = extra;//��������
			Json::Value& bkjson = json[strMsg][4u] = Json::arrayValue;//���õ�ַ
			for (unsigned i = 0; i < bkList.size(); ++i)
			{
				const string fullPath_to = strRpDirRoot + bkList[i];
				boost::system::error_code code;
				boost::filesystem::copy_file(fullPath_from, fullPath_to, boost::filesystem::copy_option::overwrite_if_exists, code);
				if (!code)
				{
					if (bkjson.size() < 10)bkjson.append(bkList[i]);
				}
				else
				{
					LogW << fullPath_from << "\tto\t" << fullPath_to << "\t" <<
						code.message() << LogEnd;//����
				}
			}
			detail::batchOnline(noticeList, json, gate_client::report_notice_resp);
		}
	}

	//battle data collection
	BattleReportData::BattleReportData()
	{
		resetO2OReport();
		resetT2TReport();
	}

	BattleData::envPtr BattleReportData::PushEnv(BattleData::envPtr env)
	{
		seqENV_.push_back(env);
		return env;
	}

	void BattleReportData::jDoneAndClear(qValue& reportDelare)
	{
		qValue round(qJson::qj_array);
		for (unsigned i = 0; i < seqENV_.size(); ++i)
		{
			qValue& qVal = seqENV_[i]->jVal_;
			if (qVal.isEmpty())continue;
			round.append(qVal);
		}
		reportDelare.append(round);
		ClearActionEnv();
	}

	void BattleReportData::ClearActionEnv()
	{
		seqENV_.clear();
	}

	void BattleReportData::resetT2TReport()
	{
		reportTeam.toObject();
	}

	void BattleReportData::resetO2OReport()
	{
		LastRound = 0;
		reportRoot.toObject();
		zeroBuffMan.clear();
	}

	void BattleReportData::addReportdeclare(const string key, qValue& json)
	{
		if (ReserveKey.find(key) != ReserveKey.end())return;
		reportRoot.removeMember(key);
		reportRoot.addMember(key, json);
	}
	void BattleReportData::addReportdeclare(const string key, Json::Value& json)
	{
		if (ReserveKey.find(key) != ReserveKey.end())return;
		reportRoot.removeMember(key);
		string str_json = json.toIndentString();
		qValue toqV(str_json.c_str());
		reportRoot.addMember(key, toqV);
	}
	void BattleReportData::addReportdeclare(const string key, const int val)
	{
		if (ReserveKey.find(key) != ReserveKey.end())return;
		reportRoot.removeMember(key);
		reportRoot.addMember(key, val);
	}

	void BattleReportData::addReportdeclare(const string key, const unsigned val)
	{
		if (ReserveKey.find(key) != ReserveKey.end())return;
		reportRoot.removeMember(key);
		reportRoot.addMember(key, val);
	}

	void BattleReportData::addReportdeclare(const string key, const double val)
	{
		if (ReserveKey.find(key) != ReserveKey.end())return;
		reportRoot.removeMember(key);
		reportRoot.addMember(key, val);
	}
	void BattleReportData::addReportdeclare(const string key, const string str)
	{
		if (ReserveKey.find(key) != ReserveKey.end())return;
		reportRoot.removeMember(key);
		reportRoot.addMember(key, str);
	}

	void BattleReportData::addReportdeclareT(const string key, qValue& json)
	{
		if (ReserveKeyT.find(key) != ReserveKeyT.end())return;
		reportTeam.removeMember(key);
		reportTeam.addMember(key, json);
	}
	void BattleReportData::addReportdeclareT(const string key, Json::Value& json)
	{
		if (ReserveKeyT.find(key) != ReserveKeyT.end())return;
		reportTeam.removeMember(key);
		string str_json = json.toIndentString();
		qValue toqV(str_json.c_str());
		reportTeam.addMember(key, toqV);
	}
	void BattleReportData::addReportdeclareT(const string key, const int val)
	{
		if (ReserveKeyT.find(key) != ReserveKeyT.end())return;
		reportTeam.removeMember(key);
		reportTeam.addMember(key, val);
	}
	void BattleReportData::addReportdeclareT(const string key, const unsigned val)
	{
		if (ReserveKeyT.find(key) != ReserveKeyT.end())return;
		reportTeam.removeMember(key);
		reportTeam.addMember(key, val);
	}
	void BattleReportData::addReportdeclareT(const string key, const double val)
	{
		if (ReserveKeyT.find(key) != ReserveKeyT.end())return;
		reportTeam.removeMember(key);
		reportTeam.addMember(key, val);
	}
	void BattleReportData::addReportdeclareT(const string key, const string val)
	{
		if (ReserveKeyT.find(key) != ReserveKeyT.end())return;
		reportTeam.removeMember(key);
		reportTeam.addMember(key, val);
	}

	BattleReportData& BattleReportData::addNotice(const int playerID)
	{
		noticeList.insert(playerID);
		return *this;
	}

	BattleReportData& BattleReportData::addCopyField(const string toPath)
	{
		CVList.push_back(toPath);
		return *this;
	}

	void BattleReportData::Done(const typeBattle::TYPE type, Json::Value extra /* = Json::objectValue */)
	{
		const string str_report = reportRoot.toIndentString();
		reportPost(boostBind(noticeClient, type, str_report, extra, noticeList, CVList));
		CVList.clear();
		noticeList.clear();
	}

	void BattleReportData::DoneT(const typeBattle::TYPE type, Json::Value extra /* = Json::objectValue */)
	{
		const string str_report = reportTeam.toIndentString();
		reportPost(boostBind(noticeClient, type, str_report, extra, noticeList, CVList));
		CVList.clear();
		noticeList.clear();
	}


	//man to do
	void manBattle::set_skill_1(const int id)
	{
		skill_1 = const_cast<skillDeclare*>(skill_mgr.getSkill(id));
	}

	void manBattle::set_skill_2(const int id)
	{
		skill_2 = const_cast<skillDeclare*>(skill_mgr.getSkill(id));
	}

	sideBattle::sideBattle()
	{
		playerFace = -1;
		playerID = -1;
		isPlayer = false;
		playerName = "";
		playerLevel = 0;
		playerNation = Kingdom::null;
		sideID = 0;
		battleMan.clear();
		for (unsigned x = 0; x < 3; ++x)
			for (unsigned y = 0; y < 3; ++y)
				deployment[x][y] = mBattlePtr();//�յ�
		findIdx = InvalidBattleIDX;
		settingIdx = InvalidBattleIDX;
		priorityIdx = InvalidBattleIDX;
		winNum = 0;
		winMax = 0;
		battleValue = 0;
		leaderMan = mBattlePtr();
	}

	void sideBattle::initial(const int side)
	{
		for (unsigned x = 0; x < 3; ++x)
			for (unsigned y = 0; y < 3; ++y)
				deployment[x][y] = mBattlePtr();//�յ�
		useManList.clear();

		for (unsigned i = 0; i < battleMan.size(); ++i)
		{
			mBattlePtr ptr = battleMan[i];
			ptr->orderPos(side);
			ptr->resetInitial();
			if (ptr->isDead())continue;
			if (deployment[ptr->X()][ptr->Y()])continue;
			deployment[ptr->X()][ptr->Y()] = ptr;
			useManList.push_back(ptr);
		}
		sideID = side;
		resetHand();
	}

	void sideBattle::resetHand()
	{
		findIdx = 0;
		settingIdx = InvalidBattleIDX;
		priorityIdx = InvalidBattleIDX;
	}

	void battle_system::initData()
	{
		//ս���ؼ���
		{
			//���Ե�
			ReserveKey.insert("p");
			ReserveKey.insert("m");
			ReserveKey.insert("r");
			ReserveKey.insert("rl");
			ReserveKey.insert("t");
			ReserveKey.insert("st");
			ReserveKey.insert("al");
			ReserveKey.insert("dl");
			//��Զ�
			ReserveKeyT.insert("t");
			ReserveKeyT.insert("st");
			ReserveKeyT.insert("atk");
			ReserveKeyT.insert("def");
			ReserveKeyT.insert("rl");
			ReserveKeyT.insert("r");
		};

		rpLoopID = Common::randomBetween(0, 2999);
		//�����ļ���
		Common::createDirectories(strRpDirRoot + strRpUnify);

		cout << "load battle system" << endl;
		{//���ֿ��ƹ�ϵ��
			Json::Value json = Common::loadJsonFile("./instance/battle/soldier_restraint.json");
			for (unsigned i = 0; i < json.size(); ++i)
			{
				vector<armsRestraint> v_arms;
				for (unsigned n = 0; n < json[i].size(); ++n)
				{
					armsRestraint m;
					m.atkModule = json[i][n][0u].asDouble();
					m.defModule = json[i][n][1u].asDouble();
					v_arms.push_back(m);
				}
				armsR.push_back(v_arms);
			}
		};

		//Ŀ����Ѱ

		//���¶�λ
		newAimDeal[AIM::follow] = boostBind(battle_system::aim_follow_new, _Instance, _1, _2, _3);//�޷������ڵ�һ������//��Ϊʼ�ն��ǿյ�Ŀ�����
		newAimDeal[AIM::single] = boostBind(battle_system::aim_single_new, _Instance, _1, _2, _3);
		newAimDeal[AIM::line] = boostBind(battle_system::aim_line_new, _Instance, _1, _2, _3);
		newAimDeal[AIM::row] = boostBind(battle_system::aim_row_new, _Instance, _1, _2, _3);
		newAimDeal[AIM::cross] = boostBind(battle_system::aim_cross_new, _Instance, _1, _2, _3);
		newAimDeal[AIM::current] = boostBind(battle_system::aim_current_new, _Instance, _1, _2, _3);
		newAimDeal[AIM::all] = boostBind(battle_system::aim_all_new, _Instance, _1, _2, _3);
		newAimDeal[AIM::other] = boostBind(battle_system::aim_other_new, _Instance, _1, _2, _3);
		newAimDeal[AIM::random] = boostBind(battle_system::aim_random_new, _Instance, _1, _2, _3);
		//ָ����Ŀ��
		signAimDeal[AIM::follow] = boostBind(battle_system::aim_follow_sign, _Instance, _1, _2, _3);//�޷������ڵ�һ������//��Ϊʼ�ն��ǿյ�Ŀ�����
		signAimDeal[AIM::single] = boostBind(battle_system::aim_single_sign, _Instance, _1, _2, _3);
		signAimDeal[AIM::line] = boostBind(battle_system::aim_line_sign, _Instance, _1, _2, _3);
		signAimDeal[AIM::row] = boostBind(battle_system::aim_row_sign, _Instance, _1, _2, _3);
		signAimDeal[AIM::cross] = boostBind(battle_system::aim_cross_sign, _Instance, _1, _2, _3);
		signAimDeal[AIM::current] = boostBind(battle_system::aim_current_sign, _Instance, _1, _2, _3);
		signAimDeal[AIM::all] = boostBind(battle_system::aim_all_sign, _Instance, _1, _2, _3);
		signAimDeal[AIM::other] = boostBind(battle_system::aim_other_sign, _Instance, _1, _2, _3);
		signAimDeal[AIM::random] = boostBind(battle_system::aim_random_sign, _Instance, _1, _2, _3);


		//Ч��ִ��
		SkillDeal[SKILL::action_phy] = boostBind(battle_system::phy_attack, _Instance, _1, _2, _3);
		SkillDeal[SKILL::action_war] = boostBind(battle_system::war_attack, _Instance, _1, _2, _3);
		SkillDeal[SKILL::action_rage] = boostBind(battle_system::rage_attack, _Instance, _1, _2, _3);
		SkillDeal[SKILL::action_magic] = boostBind(battle_system::magic_attack, _Instance, _1, _2, _3);
		SkillDeal[SKILL::action_attack_mp] = boostBind(battle_system::mp_attack, _Instance, _1, _2, _3);
		SkillDeal[SKILL::action_cure_hp] = boostBind(battle_system::cure_hp, _Instance, _1, _2, _3);
		SkillDeal[SKILL::action_cure_mp] = boostBind(battle_system::cure_mp, _Instance, _1, _2, _3);
		SkillDeal[SKILL::action_absorb_hp] = boostBind(battle_system::absorb_hp, _Instance, _1, _2, _3);
		SkillDeal[SKILL::action_absorb_mp] = boostBind(battle_system::absorb_mp, _Instance, _1, _2, _3);
		SkillDeal[SKILL::action_child_skill] = boostBind(battle_system::child_skill, _Instance, _1, _2, _3);
		SkillDeal[SKILL::action_set_buff] = boostBind(battle_system::set_buff, _Instance, _1, _2, _3);
		SkillDeal[SKILL::action_direct_damage] = boostBind(battle_system::direct_attack, _Instance, _1, _2, _3);
		SkillDeal[SKILL::action_shield] = boostBind(battle_system::add_shield, _Instance, _1, _2, _3);
		SkillDeal[SKILL::action_mp_set] = boostBind(battle_system::mp_set, _Instance, _1, _2, _3);
		SkillDeal[SKILL::action_alter_mp_formula_1] = boostBind(battle_system::mp_alter_formula_1, _Instance, _1, _2, _3);

		//buffЧ��
		EffectRun[BUFF::stun] = boostBind(battle_system::effect_stun, _Instance, _1, _2, _3, _4, _5);
		EffectRun[BUFF::last_alter_hp] = boostBind(battle_system::effect_alter_hp, _Instance, _1, _2, _3, _4, _5);
		EffectRun[BUFF::last_alter_mp] = boostBind(battle_system::effect_alter_mp, _Instance, _1, _2, _3, _4, _5);

		//buffע��
		RegEffect[BUFF::stun] = boostBind(battle_system::stun_regist, _Instance, _1, _2, _3, _4, _5);
		RegEffect[BUFF::bonus_attri] = boostBind(battle_system::bonus_attri_regist, _Instance, _1, _2, _3, _4, _5);
		RegEffect[BUFF::bonus_attri_rate] = boostBind(battle_system::bonus_attri_rate_regist, _Instance, _1, _2, _3, _4, _5);
		RegEffect[BUFF::last_alter_hp] = boostBind(battle_system::last_alter_regist, _Instance, _1, _2, _3, _4, _5);
		RegEffect[BUFF::last_alter_mp] = boostBind(battle_system::last_alter_regist, _Instance, _1, _2, _3, _4, _5);

		//buff ��ע��
		AntiRegEffect[BUFF::bonus_attri] = boostBind(battle_system::bonus_attri_antiregist, _Instance, _1, _2, _3);
		AntiRegEffect[BUFF::bonus_attri_rate] = boostBind(battle_system::bonus_attri_rate_antiregist, _Instance, _1, _2, _3);

		//ʩ��ʱʩ��������
		UserRun[SKILL::limit_user_alive] = boostBind(battle_system::user_alive, _Instance, _1, _2);
		UserRun[SKILL::limit_aim_alive] = boostBind(battle_system::aim_alive, _Instance, _1, _2);
		UserRun[SKILL::limit_user_hp_greater] = boostBind(battle_system::user_hp_greater, _Instance, _1, _2);
		UserRun[SKILL::limit_user_hp_less] = boostBind(battle_system::user_hp_less, _Instance, _1, _2);
		UserRun[SKILL::limit_user_hp_equal] = boostBind(battle_system::user_hp_equal, _Instance, _1, _2);

		//����ս������
		mapPerDeal[runBattle::hp_recovery] = boostBind(battle_system::per_hp_recovery, _Instance, _1, _2);
	}

	void battle_system::per_hp_recovery(sBattlePtr atk, sBattlePtr def)
	{
		for (unsigned i = 0; i < atk->battleMan.size(); ++i)
		{
			mBattlePtr man = atk->battleMan[i];
			man->currentHP = man->getTotalAttri(idx_hp);
		}
		for (unsigned i = 0; i < def->battleMan.size(); ++i)
		{
			mBattlePtr man = def->battleMan[i];
			man->currentHP = man->getTotalAttri(idx_hp);
		}
	}

	sBattlePtr popToList(teamSideBattle& back)
	{
		if (!back.empty())
		{
			sBattlePtr sb = *back.begin();
			back.erase(back.begin());
			return sb;
		}
		return sBattlePtr();
	}

	resBattle::RES battle_system::Team2Team(BattleReportData& use_data, teamSideBattle atk, teamSideBattle def, 
		typeBattle::TYPE type, const unsigned step /* = 3 */, const unsigned runType /* = 0 */)
	{
		reportData = &use_data;
		resBattle::RES battleResult = resBattle::def_win;//ս�����
		reportData->resetT2TReport();
		qValue& reportTeam = reportData->reportTeam;
		reportTeam.addMember("t", type);
		{
			qValue jT(qJson::qj_array);
			for (unsigned i = 0; i < atk.size(); ++i)
			{
				qValue jM(qJson::qj_array);
				sBattlePtr sb = atk[i];
				jM.append(sb->playerID).append(sb->playerName).append(sb->isPlayer).
					append(sb->playerNation);
				qValue mainMan(qJson::qj_array);
				if (sb->leaderMan)
				{
					mBattlePtr man = sb->leaderMan;
					const BattleEquipList& equipList = man->equipList;
					qValue eqList_json(qJson::qj_array);
					for (unsigned pos = 0; pos < equipList.size(); ++pos)
					{
						qValue sg_eq_json(qJson::qj_array);
						const BattleEquip& def = equipList[pos];
						sg_eq_json.append(def.equipPos).append(def.equipID).append(def.equipLevel);
						eqList_json.append(sg_eq_json);
					}
					mainMan.append(man->manID);
					mainMan.append(eqList_json);
				}
				jM.append(mainMan);
				jT.append(jM);
			}
			reportTeam.addMember("atk", jT);
		};
		{
			qValue jT(qJson::qj_array);
			for (unsigned i = 0; i < def.size(); ++i)
			{
				qValue jM(qJson::qj_array);
				sBattlePtr sb = def[i];
				jM.append(sb->playerID).append(sb->playerName).append(sb->isPlayer).
					append(sb->playerNation);
				qValue mainMan(qJson::qj_array);
				if (sb->leaderMan)
				{
					mBattlePtr man = sb->leaderMan;
					const BattleEquipList& equipList = man->equipList;
					qValue eqList_json(qJson::qj_array);
					for (unsigned pos = 0; pos < equipList.size(); ++pos)
					{
						qValue sg_eq_json(qJson::qj_array);
						const BattleEquip& def = equipList[pos];
						sg_eq_json.append(def.equipPos).append(def.equipID).append(def.equipLevel);
						eqList_json.append(sg_eq_json);
					}
					mainMan.append(man->manID);
					mainMan.append(eqList_json);
				}
				jM.append(mainMan);
				jT.append(jM);
			}
			reportTeam.addMember("def", jT);
		};
		const unsigned real_run = runType;//��ʵִ��
		const unsigned real_step = step < 1 ? 1 : step;
		reportTeam.addMember("st", real_step);//n �� n
		teamSideBattle atkCopy = atk;
		teamSideBattle defCopy = def;
		teamSideBattle atkField;
		teamSideBattle defField;
		atkField.resize(real_step);
		defField.resize(real_step);
		vector<qValue> declareFiled;
		declareFiled.resize(real_step);
		for (unsigned i = 0; i < declareFiled.size(); ++i)
		{
			declareFiled[i].toArray();
		}
		while (true)
		{
			for (unsigned i = 0; i < real_step; i++)//���Ŀ��
			{
				if (!atkField[i])atkField[i] = popToList(atkCopy);
				if (!defField[i])defField[i] = popToList(defCopy);
			}
			for (unsigned i = 0; i < real_step; ++i)//����Ŀ��
			{
				if (atkField[i] && !defField[i])
				{
					for (unsigned di = 0; di < real_step; ++di)
					{
						if (defField[di] && !atkField[di])
						{
							defField[i] = defField[di];
							defField[di] = sBattlePtr();
							break;
						}
					}
				}
			}//Ŀ�����
			bool isBreak = true;
			for (unsigned i = 0; i < atkField.size(); ++i)
			{
				if (atkField[i])
				{
					isBreak = false;
					break;
				}
			}
			if (isBreak)
			{
				battleResult = resBattle::def_win;
				break;
			}
			isBreak = true;
			for (unsigned i = 0; i < defField.size(); ++i)
			{
				if (defField[i])
				{
					isBreak = false;
					break;
				}
			}
			if (isBreak)
			{
				battleResult = resBattle::atk_win;
				break;
			}
			for (unsigned idx = 0; idx < real_step; ++idx)//ս��
			{
				sBattlePtr c_atk = atkField[idx];
				sBattlePtr c_def = defField[idx];
				O2ORes res = impl_One2One(c_atk, c_def, typeBattle::child_battle, real_run);
				if (c_atk)reportData->addReportdeclare("akwn", c_atk->winNum);
				if (c_def)reportData->addReportdeclare("dfwn", c_def->winNum);
				if (c_atk || c_def)
				{
					if (resBattle::atk_win == res.res)
					{
						if (c_def)//���û�ж��ֲ���Ӯ
						{
							++c_atk->winNum;
						}
						if (c_atk->overWin())
						{
							atkField[idx] = sBattlePtr();
							reportData->addReportdeclare("tat", BATTLEEVENT::leave);
						}
						else
						{
							reportData->addReportdeclare("tat", BATTLEEVENT::nothing);
						}
						defField[idx] = sBattlePtr();
						reportData->addReportdeclare("tdt", BATTLEEVENT::lose);
					}
					else if (resBattle::def_win == res.res)
					{
						if (c_atk)//���û�ж��ֲ���Ӯ
						{
							++c_def->winNum;
						}
						if (c_def->overWin())
						{
							defField[idx] = sBattlePtr();
							reportData->addReportdeclare("tdt", BATTLEEVENT::leave);
						}
						else
						{
							reportData->addReportdeclare("tdt", BATTLEEVENT::nothing);
						}
						atkField[idx] = sBattlePtr();
						reportData->addReportdeclare("tat", BATTLEEVENT::lose);
					}
				}
				declareFiled[idx].append(reportData->reportRoot);
			}
		}
		qValue reportTeamR(qJson::qj_array);
		for (unsigned i = 0; i < declareFiled.size(); ++i)
		{
			reportTeamR.append(declareFiled[i]);
		}
		reportTeam.addMember("r", reportTeamR);//ս�����
		reportTeam.addMember("rl", battleResult);//ս�����
		return battleResult;
	}

	int getLoseHP(const manList& battleList)
	{
		int num = 0;
		for (manList::const_iterator it = battleList.begin(); it != battleList.end(); it++)
		{
			mBattlePtr m = *it;
			num += m->loseHP();
		}
		return num;
	}

	int getStar(const manList& battleList)
	{
		int deadT = 0;
		for (manList::const_iterator it = battleList.begin(); it != battleList.end(); it++)
		{
			const mBattlePtr m = *it;
			if (m->isDead()) ++deadT;
		}
		//if (deadT > 4)return 0;
		if (deadT > 3)return 1;//4,5,6,7...etc
		if (deadT > 2)return 2;
		if (deadT > 1)return 3;
		if (deadT > 0)return 4;
		return 5;
	}

	O2ORes battle_system::One2One(BattleReportData& use_data, sBattlePtr atk, sBattlePtr def, typeBattle::TYPE type, const unsigned runType /* = 0 */)
	{
		reportData = &use_data;
		return impl_One2One(atk, def, type, runType);
	}

	O2ORes battle_system::impl_One2One(sBattlePtr atk, sBattlePtr def, typeBattle::TYPE type, const unsigned runType /* = 0 */)
	{
		reportData->resetO2OReport();
		reportData->ClearActionEnv();
		qValue& reportRoot = reportData->reportRoot;
		if (!atk && !def)O2ORes(resBattle::res_unknown, 0);
		qValue jPlayer(qJson::qj_array);
		{
			qValue jSide(qJson::qj_array);
			if (atk)
				jSide.append(atk->playerID).
				append(atk->playerName).
				append(atk->playerLevel).
				append(atk->isPlayer).
				append(atk->battleValue).
				append(atk->playerFace);
			jPlayer.append(jSide);
		};
		{
			qValue jSide(qJson::qj_array);
			if(def)
				jSide.append(def->playerID).
				append(def->playerName).
				append(def->playerLevel).
				append(def->isPlayer).
				append(def->battleValue).
				append(def->playerFace);
			jPlayer.append(jSide);
		};
		reportRoot.addMember("p", jPlayer);
		reportRoot.addMember("t", type);

		qValue jDeployment(qJson::qj_array);
		//������
		if (atk)
		{
			atk->initial(0);//�����ʼ������ҵĶ�λ
			for (unsigned i = 0; i < atk->useManList.size(); ++i)
			{
				mBattlePtr man = atk->useManList[i];
				if (man->isDead())continue;
				qValue jMan(qJson::qj_array);
				jMan.append(man->currentIdx).append(man->manID).append(man->manLevel).append(man->currentHP).
					append(man->getTotalAttri(idx_hp)).append(man->holdMorale).append(man->irrelateMorale()).append(man->shield);
				const BattleEquipList& equipList = man->equipList;
				qValue eqList_json(qJson::qj_array);
				for (unsigned pos = 0; pos < equipList.size(); ++pos)
				{
					qValue sg_eq_json(qJson::qj_array);
					const BattleEquip& def = equipList[pos];
					sg_eq_json.append(def.equipPos).append(def.equipID).append(def.equipLevel);
					eqList_json.append(sg_eq_json);
				}
				jMan.append(man->battleValue);
				jMan.append(eqList_json);
				jDeployment.append(jMan);
			}
		}
		//���ط�
		if (def)
		{
			def->initial(1);
			for (unsigned i = 0; i < def->useManList.size(); ++i)
			{
				mBattlePtr man = def->useManList[i];
				if (man->isDead())continue;
				qValue jMan(qJson::qj_array);
				jMan.append(man->currentIdx).append(man->manID).append(man->manLevel).append(man->currentHP).
					append(man->getTotalAttri(idx_hp)).append(man->holdMorale).append(man->irrelateMorale()).append(man->shield);
				const BattleEquipList& equipList = man->equipList;
				qValue eqList_json(qJson::qj_array);
				for (unsigned pos = 0; pos < equipList.size(); ++pos)
				{
					qValue sg_eq_json(qJson::qj_array);
					const BattleEquip& def = equipList[pos];
					sg_eq_json.append(def.equipPos).append(def.equipID).append(def.equipLevel);
					eqList_json.append(sg_eq_json);
				}
				jMan.append(man->battleValue);
				jMan.append(eqList_json);
				jDeployment.append(jMan);
			}
		}
		reportRoot.addMember("m", jDeployment);
		if (!atk)return O2ORes(resBattle::def_win, 0);
		if (!def)return O2ORes(resBattle::atk_win, 0);

		qValue reportDelare(qJson::qj_array);//ս���������
		resBattle::RES battleResult = resBattle::def_win;//ս�����
		for (unsigned r = 0; ; ++r)
		{
			if (atk->isDeadAll())
			{
				battleResult = resBattle::def_win;
				break;
			}
			if (def->isDeadAll())
			{
				battleResult = resBattle::atk_win;
				break;
			}
			if (BigRound_ == r)break;
			reportData->LastRound = r + 1;
			atk->resetHand();//����
			def->resetHand();//����
			for (unsigned l = 0; l < LittleRound_; ++l)
			{
				//����ѭ��
				if (begin_attack(atk, def, r + 1))break;
				if (begin_attack(def, atk, r + 1))break;
			}
			reportData->jDoneAndClear(reportDelare);//�ѵ�ǰ�غϵ���Ϣд��ս��
		}
		reportRoot.addMember("r", reportDelare);//����û����ȸ���//
		reportRoot.addMember("rl", battleResult);
		for (unsigned i = 0; i < 10; ++i)
		{
			unsigned sign = (0x0001 << i) & runType;
			if (!sign)continue;
			perDealMap::iterator it = mapPerDeal.find(sign);
			if (it != mapPerDeal.end())
			{
				it->second(atk, def);
			}
		}
		int star = 0;
		if (resBattle::atk_win == battleResult)star = getStar(atk->useManList);
		if (resBattle::def_win == battleResult)star = -getStar(def->useManList);
		reportRoot.addMember("st", star);
		reportRoot.addMember("al", getLoseHP(atk->useManList));
		reportRoot.addMember("dl", getLoseHP(def->useManList));
		return O2ORes(battleResult, star);
	}

	void battle_system::effect_to_run(const unsigned round, sBattlePtr atk, sBattlePtr def, mBattlePtr user, const unsigned sr)
	{
		{//Ч��ִ��
			BattleData::envPtr run_env = Creator<BattleData::environment>::Create(round, atk, def);//ִ��run
			BattleData::envPtr clear_env = Creator<BattleData::environment>::Create(round, atk, def);//����run
			run_env->jVal_.append(user->currentIdx).append(BATTLEEVENT::effect_run);
			qValue jClear(qJson::qj_array);
			//Ҫ����map
			manBattle::EfMap& EffectMap = user->Effects;
			for (manBattle::EfMap::const_iterator it = EffectMap.begin(); it != EffectMap.end();)
			{
				mEfPtr ef = it->second;
				int buffID = ef->declare->buffID;
				int effectID = buffID % BUFF::BUFFOFFSET;
				
				//��ִ��
				const bool runOK = (sr > 0 && (ef->declare->runTick & sr) == sr);
				if (runOK)
				{
					EffectRunMap::iterator find_deal = EffectRun.find(effectID);
					if (find_deal != EffectRun.end())
					{
						BattleData::unitPtr uni = run_env->newUnit();
						uni->junit_.append(buffID);
						find_deal->second(run_env, uni, user, ef, sr);
					}
				}

				//������
				const bool reduceOK = (ef->declare->cleanTick & sr) > 0;
				if (reduceOK && ef->lastRound > 0)--ef->lastRound;
				if (ef->lastRound < 1)//ʧЧ ��ע��
				{
					EffectMap.erase(it++);
					jClear.append(buffID);
					AntiRegEffectMap::iterator ef_it = AntiRegEffect.find(effectID);//��ע��buff
					if (ef_it != AntiRegEffect.end())
					{
						ef_it->second(clear_env, user, ef);
					}
				}
				else
				{
					//ʲôҲ����
					++it;
				}
			}
			run_env->jEffectDone();
			if (!run_env->unitEmpty())//�Ż�����Ҫ������
			{
				reportData->PushEnv(run_env);
			}
			if (!jClear.isEmpty())
			{
				reportData->PushEnv(clear_env);
				clear_env->jVal_.append(user->currentIdx).append(BATTLEEVENT::effect_delete).append(jClear);
			}
		};

		{//���غ���ʱ��Ч��buff
			BattleReportData::ManDealList& dealMen = reportData->zeroBuffMan;
			for (BattleReportData::ManDealList::const_iterator it = dealMen.begin(); it != dealMen.end(); ++it)
			{
				mBattlePtr man = *it;
				BattleData::envPtr clear_env = Creator<BattleData::environment>::Create(round, atk, def);
				manBattle::EfMap& checkMap = man->Effects;
				//��ɾ��Ҫ�������Ѿ�����buff
				qValue jClear(qJson::qj_array);
				for (manBattle::EfMap::iterator ef_it = checkMap.begin(); ef_it != checkMap.end();)
				{
					mEfPtr ef = ef_it->second;
					const int buffID = ef->declare->buffID;
					const int effectID = buffID % BUFF::BUFFOFFSET;
					if (ef->lastRound < 1)//ʧЧ ��ע��
					{
						checkMap.erase(ef_it++);
						jClear.append(buffID);
						AntiRegEffectMap::iterator it = AntiRegEffect.find(effectID);//��ע��buff
						if (it != AntiRegEffect.end())
						{
							it->second(clear_env, man, ef);
						}
					}
					else
					{
						//ʲôҲ����
						++ef_it;
					}
				}
				if (!jClear.isEmpty())
				{
					reportData->PushEnv(clear_env);
					clear_env->jVal_.append(man->currentIdx).append(BATTLEEVENT::effect_delete).append(jClear);
				}
			}
			dealMen.clear();
		};
	}

	void battle_system::effect_stun(BattleData::envPtr env, BattleData::unitPtr uni, mBattlePtr user, mEfPtr ef, const unsigned sr)
	{
		const BUFF::Data& config = *(ef->declare);
		if (Common::randomOk(config.otherData._stun.effectRate))
		{
			user->beLock = true;
		}
	}

	void battle_system::effect_alter_hp(BattleData::envPtr env, BattleData::unitPtr uni, mBattlePtr user, mEfPtr ef, const unsigned sr)
	{
		const BUFF::Data& config = *(ef->declare);
		int alter_num = 0;
		if (config.otherData._alter.isDynamic)
		{
			if (config.otherData._alter.isCurrent && config.otherData._alter.idxAttri == idx_hp)
			{
				alter_num = user->currentHP * config.otherData._alter.rate
					+ config.otherData._alter.fixValue;
			}
			else
			{
				alter_num = user->getTotalAttri((AttributeIDX)config.otherData._alter.idxAttri) * config.otherData._alter.rate
					+ config.otherData._alter.fixValue;
			}
		}
		else
		{
			alter_num = ef->otherData._value.effectValue;
		}
		if (0 != alter_num)
		{
			user->alterHP(alter_num);
			qValue qVal(qJson::qj_array);
			qVal.append(user->currentIdx).append(BATTLEEVENT::hp_alter).append(BATTLEEVENT::hp_effect).
				append(alter_num).append(user->currentHP);
			uni->junit_.append(qVal);
		}
	}

	void battle_system::effect_alter_mp(BattleData::envPtr env, BattleData::unitPtr uni, mBattlePtr user, mEfPtr ef, const unsigned sr)
	{
		const BUFF::Data& config = *(ef->declare);
		int alter_num = 0;
		if (config.otherData._alter.isDynamic)
		{
			if (config.otherData._alter.isCurrent && config.otherData._alter.idxAttri == idx_hp)
			{
				alter_num = user->currentHP * config.otherData._alter.rate
					+ config.otherData._alter.fixValue;
			}
			else
			{
				alter_num = user->getTotalAttri((AttributeIDX)config.otherData._alter.idxAttri) * config.otherData._alter.rate
					+ config.otherData._alter.fixValue;
			}
		}
		else
		{
			alter_num = ef->otherData._value.effectValue;
		}
		if (0 != alter_num)
		{
			user->alterMorale(alter_num);
			qValue qVal(qJson::qj_array);
			qVal.append(user->currentIdx).append(BATTLEEVENT::mp_alter).append(BATTLEEVENT::mp_effect).
				append(alter_num).append(user->irrelateMorale());
			uni->junit_.append(qVal);
		}
	}

	bool battle_system::begin_attack(sBattlePtr atk, sBattlePtr def, const unsigned round)
	{
		if (atk->isDeadAll() || def->isDeadAll())return true;//��һ��������
		if (!atk->toNextHand())return false;//û����һ�����𹥻�ʩ������
		//mBattlePtr user = atk->currentHand();//ֻ��һ����ǰʩ����
		on_attack(atk, def, round, BUFF::attack_round);//ִ��
		return false;
	}

	void battle_system::on_attack(sBattlePtr atk, sBattlePtr def, const unsigned round, const unsigned sr, mBattlePtr sign_aim /* = mBattlePtr() */)//���������￪ʼ
	{
		mBattlePtr user = atk->currentHand();//ֻ��һ����ǰʩ����
		effect_to_run(round, atk, def, user, sr | BUFF::action_begin);//�������� ����Ҳ�����buff
		if (user->beLock)
		{
			user->beLock = false;
			BattleData::envPtr env = reportData->PushEnv(Creator<BattleData::environment>::Create(round, atk, def));
			env->jVal_.append(user->currentIdx).append(BATTLEEVENT::user_lock);
			effect_to_run(round, atk, def, user, sr | BUFF::action_end);
			return;
		}
		BattleData::envPtr env = reportData->PushEnv(Creator<BattleData::environment>::Create(round, atk, def));
		const skillDeclare* skill = user->useSkill();
		if (!skill)return;
		if (user->isDead())return;
		const bool useSkill = user->isUsePowerSkill();
		if (sr == BUFF::attack_round)
			env->jVal_.append(user->currentIdx).append(BATTLEEVENT::attack).append(skill->skillID).append(useSkill);
		else
			env->jVal_.append(user->currentIdx).append(BATTLEEVENT::counter_attack).append(skill->skillID).append(useSkill);
		on_detail_attack(env, skill->skillRun, sr, sign_aim, true);
// 		//����������Ϣ
// 		BattleData::unitPtr main_uni = env->getEnv(0);
// 		if (main_uni)
// 		{
// 			vector<mBattlePtr> dead_list;
// 			atk->clearDead(dead_list);
// 			def->clearDead(dead_list);
// 			for (unsigned i = 0; i < dead_list.size(); ++i)
// 			{
// 				mBattlePtr m = dead_list[i];
// 				qValue value(qJson::qj_array);
// 				value.append(m->currentIdx).append(BATTLEEVENT::dead);
// 				main_uni->junit_.append(value);
// 			}
// 		}
		env->jSkillDone();
	}

	void battle_system::on_detail_attack(BattleData::envPtr env, const SKILL::skillEntity& entity, 
		const unsigned sr, mBattlePtr sign_aim /* = mBattlePtr() */, const bool is_main /* = false */)
		//�Ӽ��ܴ����￪ʼ
	{
		BattleData::unitPtr uni = env->newUnit(entity.bringCounter, entity.counterLimit);
		find_aim(env, uni, entity.aim, sign_aim);//���ﱣ֤���ݶ�����Ч��
		mBattlePtr user = env->currentUser();
		if (is_main && user->isUsePowerSkill())
		{
			qValue val(qJson::qj_array);
			val.append(user->currentIdx).append(BATTLEEVENT::mp_alter).append(BATTLEEVENT::mp_power).
				append(-user->useSkillMorale()).append(user->irrelateMorale());
			uni->junit_.append(val);//ʿ������		
		}
		if (!uni->noAim())
		{
			run_attack(env, uni, entity.entity);//ֻ������������ִ��Ч��
		}
		else
		{
			run_attack_no_aim(env, uni, entity.entity);//����ֻ�Ǽ���Ƿ������������Ӽ��ܿ��Է���
		}
		end_attack(env, sr);//�����ͷŽ���
	}

	void battle_system::end_attack(BattleData::envPtr env, const unsigned sr)
	{
		//��������
		const bool attack_sr = ((sr & BUFF::attack_round) == BUFF::attack_round);
		const bool counter_sr = ((sr & BUFF::counter_round) == BUFF::counter_round);
		if (attack_sr || counter_sr)
		{
			mBattlePtr user = env->currentUser();//��ǰʩ����
			user->skillEnd();//ʹ�����Ǽ��ܵı仯
			effect_to_run(env->currentRound_, env->atkHand_, env->defHand_, user, sr | BUFF::action_end);//����ִ����Ч���ڵ�buffЧ��
			if (attack_sr)
			{
				do
				{
					if (env->atkHand_->isDeadAll() || env->defHand_->isDeadAll())break;
					BattleData::unit::aimPtr uni = env->FirstCounter();//��һ��������//�����Ѿ����˷����ж�
					if (!uni)break;
					mBattlePtr aim = uni->aim_;
					if (
						aim && !aim->isDead() && !aim->beLock &&//Ŀ�꽡��
						user && !user->isDead() && //ʩ���߽���
						Common::randomOk(aim->getTotalAttri(idx_counter))
						)
					{
						env->defHand_->setPriorityIDX(aim);
						on_attack(env->defHand_, env->atkHand_, env->currentRound_, BUFF::counter_round, user);
						env->defHand_->clearPriorityIDX();
					}
				} while (false);
			}
		}
	}

	void battle_system::run_attack_no_aim(BattleData::envPtr env, BattleData::unitPtr uni, const SKILL::skillEntity::entityList& declare)
	{
		mBattlePtr user = env->currentUser();
		for (unsigned n = 0; n < declare.size(); ++n)//�����Ӽ���
		{
			const SKILL::declare& decl = declare[n];//��ǰ���ܶ�
			const int runID = decl._Base.runID;
			if (runID == SKILL::action_child_skill)
			{
// 				const unsigned condition = decl._Base.condition;
// 				if (condition == SKILL::ref_null_or || condition == SKILL::ref_null_and)
				if (decl._Base.dependent)//�����ļ���
				{
					if (//�����ͷųɹ����
						onRun(env, uni, decl, user, mBattlePtr()) == intercept
						)continue;
					qValue qUser(qJson::qj_array);
					qUser.append(user->currentIdx).append(BATTLEEVENT::user_child).append(decl._Child.childID);//ʹ�ü���
					on_detail_attack(env, *decl._Child.child, 0);
					BattleData::unitPtr last = env->getLast();
					if (!last->junit_.isEmpty())
					{
						qUser.append(last->toJaim()).
							append(last->junit_);
						uni->junit_.append(qUser);
					}
				}
			}
		}
	}

	void battle_system::run_attack(BattleData::envPtr env, BattleData::unitPtr uni, const SKILL::skillEntity::entityList& declare)
	{
		sBattlePtr atk = env->atkHand_;
		sBattlePtr def = env->defHand_;
		mBattlePtr user = env->currentUser();
		while (uni->currenAim())
		{
			BattleData::unit::aimPtr aim = uni->currenAim();
			aim->initialState(declare.size());
			for (unsigned n = 0; n < declare.size(); ++n)
			{
				const SKILL::declare& decl = declare[n];
				mBattlePtr cr_aim = aim->aim_;
				if (!user_runOK(user, cr_aim, decl))continue;
//				if (aim->satisfyGlobal(SKILL::ref_dead) && SKILL::action_child_skill != decl._Base.runID)continue;
				if (
					!(
					(SKILL::aim_expect_main == decl._Base.sign && uni->currentIDX() != 0) ||
					(SKILL::aim_last == decl._Base.sign && uni->isLastAim()) ||
					(SKILL::aim_all == decl._Base.sign) ||
					(uni->currentIDX() == decl._Base.sign)
					)
					)
				{//��ЧĿ�긲��
					aim->setState(SKILL::ref_not_satisfy_sign);
					continue;
				}
				if (!uni->satisfy(decl._Base.refaim, decl._Base.refdelare, decl._Base.condition))//����������
				{
					aim->setState(SKILL::ref_not_satisfy);
					continue;
				}//�����ж��Ƿ��л���//�������ô�滻Ŀ��
				SkillDealMap::iterator it = SkillDeal.find(decl._Base.runID);
				if (it != SkillDeal.end())
				{
					it->second(env, uni, decl);
				}
				if (user->aliveToDead())
				{
					aim->setState(SKILL::ref_user_dead);
					qValue dead_value(qJson::qj_array);
					dead_value.append(user->currentIdx).append(BATTLEEVENT::dead);
					uni->junit_.append(dead_value);
				}
				if (cr_aim->aliveToDead())
				{
					aim->setState(SKILL::ref_dead);
					qValue dead_value(qJson::qj_array);
					dead_value.append(cr_aim->currentIdx).append(BATTLEEVENT::dead);
					uni->junit_.append(dead_value);
				}
				aim->nextState();
			}
			uni->nextAim();
		}
	}

	double battle_system::calArmsRes(const int atk_type, const int aim_type)
	{
		double atk_module = 0.0;
		double aim_module = 0.0;
		if (atk_type >= 0 && atk_type < (int)armsR.size() && aim_type < (int)armsR[atk_type].size())
		{
			atk_module = armsR[atk_type][aim_type].atkModule;
		}
		if (aim_type >= 0 && aim_type < (int)armsR.size() && atk_type < (int)armsR[aim_type].size())
		{
			aim_module = armsR[aim_type][atk_type].defModule;
		}
		double module = 1.0 + atk_module - aim_module;
		return module < 0.0 ? 0.0 : module;
	}

	int battle_system::damageFM( 
		BattleData::envPtr ptr, BattleData::unitPtr uni, const SKILL::declare& declare, 
		mBattlePtr user, const AttributeIDX user_pro, const AttributeIDX user_atk, const AttributeIDX user_final, const AttributeIDX user_final_val, const ArmsModule user_midx,
		mBattlePtr aim, const AttributeIDX aim_pro, const AttributeIDX aim_def, const AttributeIDX aim_final, const AttributeIDX aim_final_val, const ArmsModule aim_midx,
		const double damageRate /*= 1.0*/
		)
	{
		//1 45���� //2 67ս�� //3 89ħ�� //������
		double talent = (
			1 +
			(user->getTotalAttri(user_pro) - aim->getTotalAttri(aim_pro)) * 0.0045 +
			(user->getTalent(user_pro) - aim->getTalent(aim_pro))*0.0025
			);
		talent = talent < 0.1 ? 0.1 : talent;

		//���Բ�
		double atrr_diff = user->getTotalAttri(user_atk) * 0.5 -
			aim->getTotalAttri(aim_def) * 0.5 + 50.0;
		if (atrr_diff < 50.0)
			atrr_diff = (user->getTotalAttri(user_atk) * 0.5 + 50.0) * 50.0 /
			(aim->getTotalAttri(aim_def) * 0.5 + 50.0);
		//���ֲ�
		double arms_diff = user->getModule(user_midx) - aim->getModule(aim_midx);
		arms_diff = arms_diff < 0.0 ? 0.0 : arms_diff;
		//hp����Ӱ��
		double rm_percent = (0.5 + 0.5 * (double)user->currentHP / user->getTotalAttri(idx_hp));
		//�غ���Ӱ��
		double round_eff = (ptr->currentRound_ - 1)*0.03 + 1;
		//���ñ�//����ϵ��//����ϵ��
		const bool tick_cri = Common::randomOk(user->getTotalAttri(idx_crit));
		//���հٷֱ�ѪԽ���˺�Խ��
		double backHitModule = 1.0;
		if (0.0 != declare._Attack.againstModule)
		{
			backHitModule = 1.0 + int((double)user->loseHP() / user->getTotalAttri(idx_hp) * 100) * declare._Attack.againstModule;
		}
		//ʿ���˺�����
		double  moraleModule = 1.0;
		if (declare._Attack.moraleJoin)
		{
			moraleModule = 1.0 + (double)(user->totalMorale() - 100)*0.004;
		}
		//�����˺�
		double finalDamageModule = 1.0 + (user->getTotalAttri(user_final) - aim->getTotalAttri(aim_final)) / 10000.0;
		finalDamageModule = finalDamageModule < 0.0 ? 0.0 : finalDamageModule;
		int finalDamageVal = user->getTotalAttri(user_final_val) - aim->getTotalAttri(aim_final_val);
		finalDamageVal = finalDamageVal < 0 ? 0 : finalDamageVal;
		//������BUFF//�����

		//�������
		double armsR = calArmsRes(user->armsType, aim->armsType);

		//�ȼ�˥��
		double  damageDecay = 1.0;
		if (0.0 != declare._Attack.damageDecay)
		{
			damageDecay = 1.0 - user->manLevel * declare._Attack.damageDecay;
			damageDecay = damageDecay < 0.5 ? 0.5 : damageDecay;
			damageDecay = damageDecay > 1.0 ? 1.0 : damageDecay;
		}

		//����ϵ�� * hp����Ӱ�� * �غ���Ӱ�� * ����ϵ�� * ��ˮһսϵ�� * �������ϵ�� * ʿ��Ӱ��ϵ�� * �ȼ�˥��
		double final_module = finalDamageModule * rm_percent * round_eff * declare._Attack.module * backHitModule * armsR * moraleModule * damageDecay;
		if (tick_cri)
		{
			final_module *= declare._Attack.critModule;//����ϵ��
		}

		//����˺�
		int total_damage = (int)(pow(talent * atrr_diff, arms_diff) * final_module) + finalDamageVal;
		total_damage *= damageRate;//���յ�80%���˺�
		total_damage = total_damage < 0 ? 0 : total_damage;
		if (declare._Base.runID == SKILL::action_phy)
		{
			onPhyDamage(ptr, uni, user, aim, total_damage);
		}
		else if (declare._Base.runID == SKILL::action_war)
		{
			onWarDamage(ptr, uni, user, aim, total_damage);
		}
		else if (declare._Base.runID == SKILL::action_rage)
		{
			onRageDamage(ptr, uni, user, aim, total_damage);
		}
		else if (declare._Base.runID == SKILL::action_magic)
		{
			onMagicDamage(ptr, uni, user, aim, total_damage);
		}
		else
		{
			onDamage(ptr, uni, user, aim, total_damage, false);
		}
		//���ﴥ���¼�
		manBattle::damageRes res = aim->acceptDamage(-total_damage);
		if (declare._Attack.usePool)
		{
			ptr->hpPool_ += std::abs(res.totalDamage());
		}
		if (tick_cri)
		{
			onCrit(ptr, uni, user, aim);
		}
		if (0 != res.shp)
		{
			qValue value(qJson::qj_array);
			value.append(aim->currentIdx).append(BATTLEEVENT::shiled_alter).append(BATTLEEVENT::hp_attack).
				append(declare._Base.runID).append(res.shp).append(aim->shield).append(tick_cri);
			uni->junit_.append(value);//�Ƚ����˺�
		}

		qValue value(qJson::qj_array);
		if (aim == user)
		{
			value.append(aim->currentIdx).append(BATTLEEVENT::hp_alter).append(BATTLEEVENT::hp_block).
				append(declare._Base.runID).append(res.hp).append(aim->currentHP).append(tick_cri);
		}
		else
		{
			value.append(aim->currentIdx).append(BATTLEEVENT::hp_alter).append(BATTLEEVENT::hp_attack).
				append(declare._Base.runID).append(res.hp).append(aim->currentHP).append(tick_cri);
		}
		uni->junit_.append(value);//�Ƚ����˺�

		unsigned mMode = declare._Attack.moraleMode;
		if ((mMode & SKILL::morale_atk_create) == SKILL::morale_atk_create)
		{
			if (user->holdMorale)
			{
				user->alterMorale(declare._Attack.moraleNum);
				qValue userM(qJson::qj_array);
				userM.append(user->currentIdx).append(BATTLEEVENT::mp_alter).append(BATTLEEVENT::mp_natural).
					append(declare._Attack.moraleNum).append(user->irrelateMorale());
				uni->junit_.append(userM);//ʿ������
			}
		}
		if (aim != user)
		{
			if ((mMode & SKILL::morale_def_create) == SKILL::morale_def_create)
			{
				if (aim->holdMorale)
				{
					aim->alterMorale(declare._Attack.moraleNum);
					qValue aimM(qJson::qj_array);
					aimM.append(aim->currentIdx).append(BATTLEEVENT::mp_alter).append(BATTLEEVENT::mp_natural).
						append(declare._Attack.moraleNum).append(aim->irrelateMorale());
					uni->junit_.append(aimM);//ʿ������
				}
			}
		}
		return res.totalDamage();
	}

	void battle_system::phy_attack(BattleData::envPtr ptr, BattleData::unitPtr uni, const SKILL::declare& declare)
	{
		BattleData::unit::aimPtr aPtr = uni->currenAim();
		mBattlePtr user = ptr->currentUser();
		mBattlePtr aim = aPtr->aim_;
		do 
		{
			if (
				onPhyAttack(ptr, uni, user, aim) == intercept
				)break;
			if (//�����ͷųɹ����
				onRun(ptr, uni, declare, user, aim) == intercept
				)break;
			if (//����
				declare._Attack.dodge &&
				onDodge(ptr, uni, user, aim) == intercept
				)break;
			if (//��
				declare._Attack.block &&
				onBlock(ptr, uni, user, aim) == intercept
				)
			{
				damageFM(ptr, uni, declare,
					user, idx_tl_phy, idx_phy, idx_phyHurtRate, idx_phyHurt, idx_atkModule,
					user, idx_tl_phy_def, idx_phy_def, idx_phyCutRate, idx_phyCut, idx_defModule,
					0.8);
				break;
			}
			int damage = damageFM(ptr, uni, declare,
				user, idx_tl_phy, idx_phy, idx_phyHurtRate, idx_phyHurt, idx_atkModule,
				aim, idx_tl_phy_def, idx_phy_def, idx_phyCutRate, idx_phyCut, idx_defModule);
		} while (false);
	}

	void battle_system::war_attack(BattleData::envPtr ptr, BattleData::unitPtr uni, const SKILL::declare& declare)
	{
		BattleData::unit::aimPtr aPtr = uni->currenAim();
		mBattlePtr user = ptr->currentUser();
		mBattlePtr aim = aPtr->aim_;
		do
		{
			if (
				onWarAttack(ptr, uni, user, aim) == intercept
				)break;
			if (//�����ͷųɹ����
				onRun(ptr, uni, declare, user, aim) == intercept
				)break;
			if (//����
				declare._Attack.dodge &&
				onDodge(ptr, uni, user, aim) == intercept
				)break;
			if (//��
				declare._Attack.block &&
				onBlock(ptr, uni, user, aim) == intercept
				)			
			{
				damageFM(ptr, uni, declare,
					user, idx_tl_war, idx_war, idx_warHurtRate, idx_warHurt, idx_warModule,
					user, idx_tl_war_def, idx_war_def, idx_warCutRate, idx_warCut, idx_warDefModule,
					0.8);
				break;
			}
			int damage = damageFM(ptr, uni, declare,
				user, idx_tl_war, idx_war, idx_warHurtRate, idx_warHurt, idx_warModule,
				aim, idx_tl_war_def, idx_war_def, idx_warCutRate, idx_warCut, idx_warDefModule);
		} while (false);
	}

	void battle_system::rage_attack(BattleData::envPtr ptr, BattleData::unitPtr uni, const SKILL::declare& declare)
	{
		BattleData::unit::aimPtr aPtr = uni->currenAim();
		mBattlePtr user = ptr->currentUser();
		mBattlePtr aim = aPtr->aim_;
		do
		{
			if (
				onRageAttack(ptr, uni, user, aim) == intercept
				)break;
			if (//�����ͷųɹ����
				onRun(ptr, uni, declare, user, aim) == intercept
				)break;
			if (//����
				declare._Attack.dodge &&
				onDodge(ptr, uni, user, aim) == intercept
				)break;
			if (//��
				declare._Attack.block &&
				onBlock(ptr, uni, user, aim) == intercept
				)
			{
				damageFM(ptr, uni, declare,
					user, idx_tl_war, idx_war, idx_warHurtRate, idx_warHurt, idx_warModule,
					user, idx_tl_war_def, idx_war_def, idx_warCutRate, idx_warCut, idx_warDefModule,
					0.8);
				break;
			}
			int damage = damageFM(ptr, uni, declare,
				user, idx_tl_war, idx_war, idx_warHurtRate, idx_warHurt, idx_warModule,
				aim, idx_tl_war_def, idx_war_def, idx_warCutRate, idx_warCut, idx_warDefModule);
		} while (false);
	}

	void battle_system::magic_attack(BattleData::envPtr ptr, BattleData::unitPtr uni, const SKILL::declare& declare)
	{
		BattleData::unit::aimPtr aPtr = uni->currenAim();
		mBattlePtr user = ptr->currentUser();
		mBattlePtr aim = aPtr->aim_;
		do
		{
			if (
				onMagicAttack(ptr, uni, user, aim) == intercept
				)break;
			if (//�����ͷųɹ����
				onRun(ptr, uni, declare, user, aim) == intercept
				)break;
			if (//����
				declare._Attack.dodge &&
				onDodge(ptr, uni, user, aim) == intercept
				)break;
			if (//��
				declare._Attack.block &&
				onBlock(ptr, uni, user, aim) == intercept
				)
			{
				damageFM(ptr, uni, declare,
					user, idx_tl_magic, idx_magic, idx_magicHurtRate, idx_magicHurt, idx_magicModule,
					user, idx_tl_magic_def, idx_magic_def, idx_magicCutRate, idx_magicCut, idx_magicDefModule,
					0.8);
				break;
			}
			int damage = damageFM(ptr, uni, declare,
				user, idx_tl_magic, idx_magic, idx_magicHurtRate, idx_magicHurt, idx_magicModule,
				aim, idx_tl_magic_def, idx_magic_def, idx_magicCutRate, idx_magicCut, idx_magicDefModule);
		} while (false);
	}

	void battle_system::mp_attack(BattleData::envPtr ptr, BattleData::unitPtr uni, const SKILL::declare& declare)
	{
		BattleData::unit::aimPtr aPtr = uni->currenAim();
		mBattlePtr user = ptr->currentUser();
		mBattlePtr aim = aPtr->aim_;
		do
		{
			if (//�����ͷųɹ����
				onRun(ptr, uni, declare, user, aim) == intercept
				)break;
			const int mp = aim->irrelateMorale();
			aim->alterMorale(declare._MPAlter.num);
			if (declare._MPAlter.usePool && mp > aim->irrelateMorale())
			{
				ptr->mpPool_ += (mp - aim->irrelateMorale());
			}
			qValue val(qJson::qj_array);
			val.append(aim->currentIdx).append(BATTLEEVENT::mp_alter).append(BATTLEEVENT::mp_skill).
				append(declare._MPAlter.num).append(aim->irrelateMorale());
			uni->junit_.append(val);//ʿ������
		} while (false);
	}

	void battle_system::mp_alter_formula_1(BattleData::envPtr ptr, BattleData::unitPtr uni, const SKILL::declare& declare)
	{
		BattleData::unit::aimPtr aPtr = uni->currenAim();
		mBattlePtr user = ptr->currentUser();
		mBattlePtr aim = aPtr->aim_;
		do
		{
			if (//�����ͷųɹ����
				onRun(ptr, uni, declare, user, aim) == intercept
				)break;
			//�ı�ʿ��=�ж�������-Ŀ�귽����+20�������ֵΪ80������ֵΪ20��
			int num = user->getTotalAttri((AttributeIDX)declare._AlterMPF1.userIDX) -
				aim->getTotalAttri((AttributeIDX)declare._AlterMPF1.aimIDX) +
				declare._AlterMPF1.fixValue;
			num = std::min(num, declare._AlterMPF1.maxValue);
			num = std::max(num, declare._AlterMPF1.minValue);
			num = declare._AlterMPF1.reduce ? -num : num;
			if (aim->holdMorale && num != 0)
			{
				aim->alterMorale(num);
				qValue val(qJson::qj_array);
				val.append(aim->currentIdx).append(BATTLEEVENT::mp_alter).append(BATTLEEVENT::mp_skill).
					append(num).append(aim->irrelateMorale());
				uni->junit_.append(val);//ʿ������
			}
		} while (false);
	}

	void battle_system::mp_set(BattleData::envPtr ptr, BattleData::unitPtr uni, const SKILL::declare& declare)
	{
		BattleData::unit::aimPtr aPtr = uni->currenAim();
		mBattlePtr user = ptr->currentUser();
		mBattlePtr aim = aPtr->aim_;
		do
		{
			if (//�����ͷųɹ����
				onRun(ptr, uni, declare, user, aim) == intercept
				)break;
			const int old_num = aim->irrelateMorale();
			aim->setMorale(declare._MPAlter.num);
			const int alter_num = aim->irrelateMorale() - old_num;
			if (declare._MPAlter.usePool && old_num > aim->irrelateMorale())
			{
				ptr->mpPool_ += (old_num - aim->irrelateMorale());
			}
			qValue val(qJson::qj_array);
			val.append(aim->currentIdx).append(BATTLEEVENT::mp_alter).append(BATTLEEVENT::mp_skill).
				append(alter_num).append(aim->irrelateMorale());
			uni->junit_.append(val);//ʿ������
		} while (false);
	}

	void battle_system::absorb_hp(BattleData::envPtr ptr, BattleData::unitPtr uni, const SKILL::declare& declare)
	{
		BattleData::unit::aimPtr aPtr = uni->currenAim();
		mBattlePtr user = ptr->currentUser();
		mBattlePtr aim = aPtr->aim_;
		do
		{
			if (//�����ͷųɹ����
				onRun(ptr, uni, declare, user, aim) == intercept
				)break;
			int cure = declare._Absorb.rate * ptr->hpPool_ + declare._Absorb.fix;
			if (declare._Absorb.clear)
			{
				ptr->hpPool_ = 0;
			}
			if (cure > 0)
			{
				int cure_val = aim->alterHP(cure);
				qValue value(qJson::qj_array);
				value.append(aim->currentIdx).append(BATTLEEVENT::hp_alter).append(BATTLEEVENT::hp_absorb).append(declare._Base.runID).
					append(cure_val).append(aim->currentHP);
				uni->junit_.append(value);
			}
		} while (false);
	}

	void battle_system::absorb_mp(BattleData::envPtr ptr, BattleData::unitPtr uni, const SKILL::declare& declare)
	{
		BattleData::unit::aimPtr aPtr = uni->currenAim();
		mBattlePtr user = ptr->currentUser();
		mBattlePtr aim = aPtr->aim_;
		do
		{
			if (//�����ͷųɹ����
				onRun(ptr, uni, declare, user, aim) == intercept
				)break;
			int cure = declare._Absorb.rate * ptr->mpPool_ + declare._Absorb.fix;
			if (declare._Absorb.clear)
			{
				ptr->mpPool_ = 0;
			}
			if (cure > 0)
			{
				aim->alterMorale(cure);
				qValue val(qJson::qj_array);
				val.append(aim->currentIdx).append(BATTLEEVENT::mp_alter).append(BATTLEEVENT::mp_absorb).
					append(cure).append(aim->irrelateMorale());
				uni->junit_.append(val);//ʿ������
// 				RegEffectMap::iterator it = RegEffect.find(BUFF::last_alter_mp);
// 				if (it == RegEffect.end())break;
// 				const BUFF::Data& effect_ = declare._AbsorbMp._effect;
// 				memmove((void*)(&effect_.otherData._alter.fixValue), &cure, sizeof(effect_.otherData._alter.fixValue));
// 				it->second(ptr, uni, user, aim, effect_);
// 				memset((void*)(&effect_.otherData._alter.fixValue), 0x0, sizeof(effect_.otherData._alter.fixValue));
			}
		} while (false);
	}

	void battle_system::cure_hp(BattleData::envPtr ptr, BattleData::unitPtr uni, const SKILL::declare& declare)
	{
		BattleData::unit::aimPtr aPtr = uni->currenAim();
		mBattlePtr user = ptr->currentUser();
		mBattlePtr aim = aPtr->aim_;
		do
		{
			if (//�����ͷųɹ����
				onRun(ptr, uni, declare, user, aim) == intercept
				)break;
			int cure = int( 
				( aim->manLevel * declare._Cure.module_1 + 
				declare._Cure.module_2 + 
				user->getTotalAttri(idx_magic) * declare._Cure.module_3 )
				*
				( 1.0 + 
				user->getTotalAttri(idx_tl_magic) * declare._Cure.module_4 )
				);
			double module = (user->getTotalAttri(idx_cureRate) + aim->getTotalAttri(idx_beCureRate)) / 10000.0;
			int fix = user->getTotalAttri(idx_cure) + aim->getTotalAttri(idx_beCure);
			cure = int(cure * (1.0 + module) + fix);
			if (cure > 0)
			{
				aim->alterHP(cure);
				qValue value(qJson::qj_array);
				value.append(aim->currentIdx).append(BATTLEEVENT::hp_alter).append(BATTLEEVENT::hp_cure).append(declare._Base.runID).
					append(cure).append(aim->currentHP);
				uni->junit_.append(value);
			}
		} while (false);
	}

	void battle_system::cure_mp(BattleData::envPtr ptr, BattleData::unitPtr uni, const SKILL::declare& declare)
	{
		BattleData::unit::aimPtr aPtr = uni->currenAim();
		mBattlePtr user = ptr->currentUser();
		mBattlePtr aim = aPtr->aim_;
		do
		{
			if (//�����ͷųɹ����
				onRun(ptr, uni, declare, user, aim) == intercept
				)break;
			int cure = int(
				(aim->manLevel * declare._Cure.module_1 +
				declare._Cure.module_2 +
				user->getTotalAttri(idx_magic) * declare._Cure.module_3)
				*
				(1.0 +
				user->getTotalAttri(idx_tl_magic) * declare._Cure.module_4)
				);
			double module = (user->getTotalAttri(idx_cureRate) + aim->getTotalAttri(idx_beCureRate)) / 10000.0;
			int fix = user->getTotalAttri(idx_cure) + aim->getTotalAttri(idx_beCure);
			cure = int(cure * (1.0 + module) + fix);
			if (cure > 0)
			{
				aim->alterMorale(cure);
				qValue value(qJson::qj_array);
				value.append(aim->currentIdx).append(BATTLEEVENT::mp_alter).append(BATTLEEVENT::mp_cure).append(declare._Base.runID).
					append(cure).append(aim->irrelateMorale());
				uni->junit_.append(value);
			}
		} while (false);
	}

	void battle_system::bonus_attri_antiregist(BattleData::envPtr env, mBattlePtr user, mEfPtr ef)
	{
		const BUFF::Data& config = *(ef->declare);
		const int* ef_attri = config.otherData._attri.attri;
		int* attri_init = user->addAttri;
		for (unsigned i = 0; i < characterNum; ++i){ attri_init[i] -= ef_attri[i]; }
	}

	void battle_system::bonus_attri_rate_antiregist(BattleData::envPtr env, mBattlePtr user, mEfPtr ef)
	{
		const BUFF::Data& config = *(ef->declare);
		const int* ef_attri = config.otherData._attri.attri;
		int* attri_init = user->rateAttri;
		for (unsigned i = 0; i < characterNum; ++i){ attri_init[i] -= ef_attri[i]; }
	}

	bool battle_system::user_runOK(mBattlePtr user, mBattlePtr aim, const SKILL::declare& declare)
	{
		if (0x0 == declare._Base.userLimit || 0x8000000 == declare._Base.userLimit)return true;
		
		if ((0x8000000 & declare._Base.userLimit) == SKILL::limit_logic_and)
		{
			for (unsigned i = 0; i < SKILL::limit_user_num; ++i)
			{
				const unsigned limit_id = (0x0001 << i) & declare._Base.userLimit;
				UserRunMap::iterator it = UserRun.find(limit_id);
				if (it != UserRun.end())
				{
					if (!(it->second(user, aim)))return false;
				}
			}
			return true;
		}
		else
		{
			for (unsigned i = 0; i < SKILL::limit_user_num; ++i)
			{
				const unsigned limit_id = (0x0001 << i) & declare._Base.userLimit;
				UserRunMap::iterator it = UserRun.find(limit_id);
				if (it != UserRun.end())
				{
					if (it->second(user, aim))return true;
				}
			}
			return false;
		}
	}

	bool battle_system::user_alive(mBattlePtr user, mBattlePtr aim)
	{
		return !user->isDead();
	}

	bool battle_system::aim_alive(mBattlePtr user, mBattlePtr aim)
	{
		return !aim->isDead();
	}

	bool battle_system::user_hp_greater(mBattlePtr user, mBattlePtr aim)
	{
		return user->currentHP > aim->currentHP;
	}

	bool battle_system::user_hp_less(mBattlePtr user, mBattlePtr aim)
	{
		return user->currentHP < aim->currentHP;
	}

	bool battle_system::user_hp_equal(mBattlePtr user, mBattlePtr aim)
	{
		return user->currentHP == aim->currentHP;
	}

	bool battle_system::buff_regist(BattleData::envPtr env, BattleData::unitPtr uni, mBattlePtr user, mBattlePtr aim, mEfPtr ef)
	{
		const int buffID = ef->declare->buffID;
		const int effectID = buffID % BUFF::BUFFOFFSET;
		mEfPtr old_ef = aim->getEffect(buffID);
		if (old_ef && old_ef->declare->weight > ef->declare->weight)return false;
		//BATTLEEVENT::effect_reset 
		int set_event = BATTLEEVENT::effect_set;
		if (old_ef)
		{//��ע��
			set_event = BATTLEEVENT::effect_reset;
			AntiRegEffectMap::iterator it = AntiRegEffect.find(effectID);//��ע��buff
			if (it != AntiRegEffect.end())
			{
				it->second(env, aim, ef);
			}
		}
		qValue jVal(qJson::qj_array);
		jVal.append(aim->currentIdx).append(set_event).append(buffID);
		uni->junit_.append(jVal);

		//����buff����
		aim->Effects[buffID] = ef;//����buff
		if (user != aim && ef->lastRound < 1)//��������Լ� ���� ���غ���Ч��buff
		{
			reportData->zeroBuffMan.insert(aim);//��֪��buffҪ�����䶯���佫
		}

		return true;
	}

	void battle_system::stun_regist(BattleData::envPtr env, BattleData::unitPtr uni, mBattlePtr user, mBattlePtr aim, const BUFF::Data& entity)
	{
		mEfPtr new_ef = Creator<MANEFFECT::Data>::Create();
		new_ef->declare = &entity;
		new_ef->lastRound = entity.lastRound;
		buff_regist(env, uni, user, aim, new_ef);
	}

	void battle_system::bonus_attri_regist(BattleData::envPtr env, BattleData::unitPtr uni, mBattlePtr user, mBattlePtr aim, const BUFF::Data& entity)
	{
		mEfPtr new_ef = Creator<MANEFFECT::Data>::Create();
		new_ef->declare = &entity;
		new_ef->lastRound = entity.lastRound;
		if (buff_regist(env, uni, user, aim, new_ef))
		{
			//ע������
			const int* ef_attri = entity.otherData._attri.attri;
			int* attri_init = aim->addAttri;
			for (unsigned i = 0; i < characterNum; ++i){ attri_init[i] += ef_attri[i]; }
		}
	}

	void battle_system::bonus_attri_rate_regist(BattleData::envPtr env, BattleData::unitPtr uni, mBattlePtr user, mBattlePtr aim, const BUFF::Data& entity)
	{
		mEfPtr new_ef = Creator<MANEFFECT::Data>::Create();
		new_ef->declare = &entity;
		new_ef->lastRound = entity.lastRound;
		if (buff_regist(env, uni, user, aim, new_ef))
		{
			//ע������
			const int* ef_attri = entity.otherData._attri.attri;
			int* attri_init = aim->rateAttri;
			for (unsigned i = 0; i < characterNum; ++i){ attri_init[i] += ef_attri[i]; }
		}
	}

	void battle_system::last_alter_regist(BattleData::envPtr env, BattleData::unitPtr uni, mBattlePtr user, mBattlePtr aim, const BUFF::Data& entity)
	{
		mEfPtr new_ef = Creator<MANEFFECT::Data>::Create();
		new_ef->declare = &entity;
		new_ef->lastRound = entity.lastRound;
		if (buff_regist(env, uni, user, aim, new_ef))
		{
			new_ef->otherData._value.effectValue = 0;
			if (!entity.otherData._alter.isDynamic)//��̬��ֵ
			{
				if (entity.otherData._alter.isCurrent && entity.otherData._alter.idxAttri == idx_hp)
				{
					new_ef->otherData._value.effectValue = aim->currentHP * entity.otherData._alter.rate
						+ entity.otherData._alter.fixValue;
				}
				else
				{
					new_ef->otherData._value.effectValue = aim->getTotalAttri((AttributeIDX)entity.otherData._alter.idxAttri) * entity.otherData._alter.rate
						+ entity.otherData._alter.fixValue;
				}
			}
		}
	}

	void battle_system::set_buff(BattleData::envPtr ptr, BattleData::unitPtr uni, const SKILL::declare& declare)
	{
		BattleData::unit::aimPtr aPtr = uni->currenAim();
		mBattlePtr user = ptr->currentUser();
		mBattlePtr aim = aPtr->aim_;
		do
		{
			if (//�����ͷųɹ����
				onRun(ptr, uni, declare, user, aim, false) == intercept
				)break;
			int effectID = declare._Effect._effect.buffID % BUFF::BUFFOFFSET;
			RegEffectMap::iterator it = RegEffect.find(effectID);
			if (it == RegEffect.end())break;
			it->second(ptr, uni, user, aim, declare._Effect._effect);
		} while (false);
	}

	void battle_system::add_shield(BattleData::envPtr ptr, BattleData::unitPtr uni, const SKILL::declare& declare)
	{
		BattleData::unit::aimPtr aPtr = uni->currenAim();
		mBattlePtr user = ptr->currentUser();
		mBattlePtr aim = aPtr->aim_;
		do
		{
			if (//�����ͷųɹ����
				onRun(ptr, uni, declare, user, aim, false) == intercept
				)break;
			const int shield = declare._Shield.precentAttri * user->getTotalAttri((AttributeIDX)declare._Shield.idxAttri) + declare._Shield.fixValue;
			aim->alterShield(shield);
			qValue value(qJson::qj_array);
			value.append(aim->currentIdx).append(BATTLEEVENT::shield_alter).append(BATTLEEVENT::hp_effect).
				append(declare._Base.runID).append(shield).append(aim->shield);
		} while (false);
	}

	void battle_system::direct_attack(BattleData::envPtr ptr, BattleData::unitPtr uni, const SKILL::declare& declare)
	{
		BattleData::unit::aimPtr aPtr = uni->currenAim();
		mBattlePtr user = ptr->currentUser();
		mBattlePtr aim = aPtr->aim_;
		do
		{
			if (//�����ͷųɹ����
				onRun(ptr, uni, declare, user, aim) == intercept
				)break;
			int damage = declare._TrueDamage.fixDamage + declare._TrueDamage.precentTotalHP * aim->getTotalAttri(idx_hp) +
				declare._TrueDamage.precentHP * aim->currentHP + user->getTotalAttri((AttributeIDX)declare._TrueDamage.idxAttri) * declare._TrueDamage.precentAttri;
			if (damage > 0)
			{
				manBattle::damageRes res = aim->acceptDamage(-damage);
				if (0 != res.shp)
				{
					qValue value(qJson::qj_array);
					value.append(aim->currentIdx).append(BATTLEEVENT::shiled_alter).append(BATTLEEVENT::hp_direct).
						append(declare._Base.runID).append(res.shp).append(aim->shield);
					uni->junit_.append(value);//�Ƚ����˺�
				}
// 				if (0 != res.hp)
// 				{
					qValue value(qJson::qj_array);
					value.append(aim->currentIdx).append(BATTLEEVENT::hp_alter).append(BATTLEEVENT::hp_direct).
						append(declare._Base.runID).append(res.hp).append(aim->currentHP);
					uni->junit_.append(value);//�Ƚ����˺�
//				}
				int final_damage = res.totalDamage();
				onDamage(ptr, uni, user, aim, final_damage, false);
			}
		} while (false);
	}

	void battle_system::child_skill(BattleData::envPtr ptr, BattleData::unitPtr uni, const SKILL::declare& declare)
	{
		BattleData::unit::aimPtr aPtr = uni->currenAim();
		mBattlePtr user = ptr->currentUser();
		mBattlePtr aim = aPtr->aim_;
		do
		{
			if (//�����ͷųɹ����
				onRun(ptr, uni, declare, user, mBattlePtr()) == intercept
				)break;
			qValue qUser(qJson::qj_array);
			qUser.append(user->currentIdx).append(BATTLEEVENT::user_child).append(declare._Child.childID);//ʹ�ü���
			on_detail_attack(ptr, *declare._Child.child, 0);
			BattleData::unitPtr last = ptr->getLast();
			if (!last->junit_.isEmpty())
			{
				qUser.append(last->toJaim()).
					append(last->junit_);
				uni->junit_.append(qUser);
			}
		} while (false);
	}

	battle_system::EventResult battle_system::onRun(BattleData::envPtr ptr, BattleData::unitPtr uni, const SKILL::declare& declare, mBattlePtr user, mBattlePtr aim, const bool visible /* = true */)
	{
		if (!Common::randomOk(declare._Base.runRate))
		{
			if (visible)
			{
				qValue value(qJson::qj_array);
				if (aim)value.append(aim->currentIdx).append(BATTLEEVENT::run_failed).append(declare._Base.runID);
				else value.append(user->currentIdx).append(BATTLEEVENT::run_failed).append(declare._Base.runID);
				uni->junit_.append(value);
			}
			uni->currenAim()->setState(SKILL::ref_run_failed);
			return intercept;
		}
		if (aim)//Ŀ����Ч
		{

		}
		return adopt;
	}

	battle_system::EventResult battle_system::onPhyAttack(BattleData::envPtr ptr, BattleData::unitPtr uni, mBattlePtr user, mBattlePtr aim)
	{
		battle_system::EventResult res = onAttack(ptr, uni, user, aim);
		if (res != adopt)return res;
		return adopt;
	}

	battle_system::EventResult battle_system::onWarAttack(BattleData::envPtr ptr, BattleData::unitPtr uni, mBattlePtr user, mBattlePtr aim)
	{
		battle_system::EventResult res = onAttack(ptr, uni, user, aim);
		if (res != adopt)return res;
		return adopt;
	}

	battle_system::EventResult battle_system::onRageAttack(BattleData::envPtr ptr, BattleData::unitPtr uni, mBattlePtr user, mBattlePtr aim)
	{
		battle_system::EventResult res = onAttack(ptr, uni, user, aim);
		if (res != adopt)return res;
		return adopt;
	}

	battle_system::EventResult battle_system::onMagicAttack(BattleData::envPtr ptr, BattleData::unitPtr uni, mBattlePtr user, mBattlePtr aim)
	{
		battle_system::EventResult res = onAttack(ptr, uni, user, aim);
		if (res != adopt)return res;
		return adopt;
	}

	battle_system::EventResult battle_system::onAttack(BattleData::envPtr ptr, BattleData::unitPtr uni, mBattlePtr user, mBattlePtr aim)
	{
		return adopt;
	}

	battle_system::EventResult battle_system::onPhyDamage(BattleData::envPtr ptr, BattleData::unitPtr uni, mBattlePtr user, mBattlePtr aim, int& damage)
	{
		battle_system::EventResult res = onDamage(ptr, uni, user, aim, damage);
		if (res != adopt)return res;
		uni->currenAim()->setState(SKILL::ref_phy_hurt);
		return adopt;
	}

	battle_system::EventResult battle_system::onWarDamage(BattleData::envPtr ptr, BattleData::unitPtr uni, mBattlePtr user, mBattlePtr aim, int& damage)
	{
		battle_system::EventResult res = onDamage(ptr, uni, user, aim, damage);
		if (res != adopt)return res;
		uni->currenAim()->setState(SKILL::ref_war_hurt);
		return adopt;
	}

	battle_system::EventResult battle_system::onRageDamage(BattleData::envPtr ptr, BattleData::unitPtr uni, mBattlePtr user, mBattlePtr aim, int& damage)
	{
		battle_system::EventResult res = onDamage(ptr, uni, user, aim, damage);
		if (res != adopt)return res;
		uni->currenAim()->setState(SKILL::ref_rage_hurt);
		return adopt;
	}

	battle_system::EventResult battle_system::onMagicDamage(BattleData::envPtr ptr, BattleData::unitPtr uni, mBattlePtr user, mBattlePtr aim, int& damage)
	{
		battle_system::EventResult res = onDamage(ptr, uni, user, aim, damage);
		if (res != adopt)return res;
		uni->currenAim()->setState(SKILL::ref_magic_hurt);
		return adopt;
	}

	battle_system::EventResult battle_system::onDamage(BattleData::envPtr ptr, BattleData::unitPtr uni, mBattlePtr user, mBattlePtr aim, int& damage, const bool common /* = true */)
	{
		if (!common)
		{
			uni->currenAim()->setState(SKILL::ref_other_damage);
		}
		return adopt;
	}

// 	battle_system::EventResult battle_system::onDead(BattleData::envPtr ptr, BattleData::unitPtr uni, mBattlePtr who)
// 	{
// 		if (who->isDead())
// 		{
// 			qValue value(qJson::qj_array);
// 			value.append(who->currentIdx).append(BATTLEEVENT::dead);
// 			uni->junit_.append(value);
// 			return intercept;
// 		}
// 		return adopt;
// 	}

	battle_system::EventResult battle_system::onDodge(BattleData::envPtr ptr, BattleData::unitPtr uni, mBattlePtr user, mBattlePtr aim)
	{
		if (Common::randomOk(aim->getTotalAttri(idx_dodge)))
		{
			qValue value(qJson::qj_array);
			value.append(aim->currentIdx).append(BATTLEEVENT::dodge);
			uni->junit_.append(value);
			uni->currenAim()->setState(SKILL::ref_dodge);
			return intercept;
		}
		return adopt;
	}

	battle_system::EventResult battle_system::onBlock(BattleData::envPtr ptr, BattleData::unitPtr uni, mBattlePtr user, mBattlePtr aim)
	{
		if (Common::randomOk(aim->getTotalAttri(idx_block)))
		{
			qValue value(qJson::qj_array);
			value.append(aim->currentIdx).append(BATTLEEVENT::block);
			uni->junit_.append(value);
			uni->currenAim()->setState(SKILL::ref_block);
			return intercept;
		}
		return adopt;
	}

	battle_system::EventResult battle_system::onCrit(BattleData::envPtr ptr, BattleData::unitPtr uni, mBattlePtr user, mBattlePtr aim)
	{
		uni->currenAim()->setState(SKILL::ref_crit);
		return adopt;
	}

	battle_system::EventResult battle_system::onCounter(BattleData::envPtr ptr, BattleData::unitPtr uni, mBattlePtr user, mBattlePtr aim)
	{
		return adopt;
	}

	void battle_system::find_aim(BattleData::envPtr env, BattleData::unitPtr uni, const AIM::structAIM& declare, mBattlePtr sign_aim /* = mBattlePtr() */)
	{
		if (sign_aim)
		{
			mBattlePtr user = env->currentUser();
			const int user_camp = (user->currentIdx % 18) / 9;//�Լ�����Ӫ
			const int sign_camp = (sign_aim->currentIdx % 18) / 9;//�Է�����Ӫ
			if (
				(declare.camp == 0 && user_camp == sign_camp) ||
				(declare.camp != 0 && user_camp != sign_camp)
				)
			{
				if (sign_aim->passLimit(declare))
				{
					uni->clearAim();
					uni->pushAim(sign_aim);
					find_aim_sign(env, uni, declare);
					return;
				}
			}
		}
		find_aim_new(env, uni, declare);
	}

	void battle_system::find_aim_new(BattleData::envPtr env, BattleData::unitPtr uni, const AIM::structAIM& declare)
	{
		aimDealMap::iterator it = newAimDeal.find(declare.selectID);
		if (it != newAimDeal.end())
		{
			uni->clearAim();
			it->second(env, uni, declare);
		}
	}

	void battle_system::find_aim_sign(BattleData::envPtr env, BattleData::unitPtr uni, const AIM::structAIM& declare)
	{
		aimDealMap::iterator it = signAimDeal.find(declare.selectID);
		if (it != signAimDeal.end())
		{
			it->second(env, uni, declare);
		}
	}

#define CopyRule(_Dst, _Val)\
	unsigned _Dst[3];\
	memmove(_Dst, _Val, sizeof(unsigned[3]));
	

	void battle_system::aim_follow_new(BattleData::envPtr ptr, BattleData::unitPtr uni, const AIM::structAIM& declare)
	{
		BattleData::unitPtr res_unit = ptr->getEnv(declare.otherData.Follow.followIdx);
		if (res_unit == uni)return;
		res_unit->copyAimTo(uni, declare.otherData.Follow.newStatus);
	}

	void battle_system::aim_follow_sign(BattleData::envPtr ptr, BattleData::unitPtr uni, const AIM::structAIM& declare)
	{
		uni->clearAim();
	}

	void battle_system::aim_single_new(BattleData::envPtr ptr, BattleData::unitPtr uni, const AIM::structAIM& declare)
	{
		mBattlePtr user = ptr->currentUser();
		CopyRule(rule, PriorityXY_[user->Y()]);
		sBattlePtr useSide = ptr->atkHand_;
		if (declare.camp != 0)
		{
			useSide = ptr->defHand_;
		}
		if (declare.isOpp)
		{
			for (unsigned i = 0; i < 3; ++i)
				for (unsigned x = 2; x < 3; --x)	{
					mBattlePtr aim = useSide->getUser(x, rule[i]);
					if (!aim || !aim->passLimit(declare))continue;
					uni->pushAim(aim);
					return;
				}
		}
		else
		{
			for (unsigned i = 0; i < 3; ++i)
				for (unsigned x = 0; x < 3; ++x)	{
					mBattlePtr aim = useSide->getUser(x, rule[i]);
					if (!aim || !aim->passLimit(declare))continue;
					uni->pushAim(aim);
					return;
				}
		}
	}

	void battle_system::aim_single_sign(BattleData::envPtr ptr, BattleData::unitPtr uni, const AIM::structAIM& declare)
	{
		//ʲôҲ����
	}

	void battle_system::aim_line_new(BattleData::envPtr ptr, BattleData::unitPtr uni, const AIM::structAIM& declare)
	{
		aim_single_new(ptr, uni, declare);
		BattleData::unit::aimPtr aimD = uni->mainAim();
		if (!aimD || !aimD->aim_)return;
		mBattlePtr m_aim = aimD->aim_;
		sBattlePtr useSide = ptr->atkHand_;
		if (declare.camp != 0)
		{
			useSide = ptr->defHand_;
		}
		const unsigned x = m_aim->X();
		for (unsigned y = 0; y < 3; ++y)
		{
			mBattlePtr c_aim = useSide->getUser(x, y);
			if (!c_aim || (m_aim == c_aim) || !c_aim->passLimit(declare))continue;
			uni->pushAim(c_aim);
		}
	}

	void battle_system::aim_line_sign(BattleData::envPtr ptr, BattleData::unitPtr uni, const AIM::structAIM& declare)
	{
		BattleData::unit::aimPtr aimD = uni->mainAim();
		if (!aimD || !aimD->aim_)return;
		mBattlePtr m_aim = aimD->aim_;
		sBattlePtr useSide = ptr->atkHand_;
		if (declare.camp != 0)
		{
			useSide = ptr->defHand_;
		}
		const unsigned x = m_aim->X();
		for (unsigned y = 0; y < 3; ++y)
		{
			mBattlePtr c_aim = useSide->getUser(x, y);
			if (!c_aim || (m_aim == c_aim) || !c_aim->passLimit(declare))continue;
			uni->pushAim(c_aim);
		}
	}

	void battle_system::aim_row_new(BattleData::envPtr ptr, BattleData::unitPtr uni, const AIM::structAIM& declare)
	{
		aim_single_new(ptr, uni, declare);
		BattleData::unit::aimPtr aimD = uni->mainAim();
		if (!aimD || !aimD->aim_)return;
		mBattlePtr m_aim = aimD->aim_;
		sBattlePtr useSide = ptr->atkHand_;
		if (declare.camp != 0)
		{
			useSide = ptr->defHand_;
		}
		const unsigned y = m_aim->Y();
		for (unsigned x = 0; x < 3; ++x)
		{
			mBattlePtr c_aim = useSide->getUser(x, y);
			if (!c_aim || (m_aim == c_aim) || !c_aim->passLimit(declare))continue;
			uni->pushAim(c_aim);
		}
	}

	void battle_system::aim_row_sign(BattleData::envPtr ptr, BattleData::unitPtr uni, const AIM::structAIM& declare)
	{
		BattleData::unit::aimPtr aimD = uni->mainAim();
		if (!aimD || !aimD->aim_)return;
		mBattlePtr m_aim = aimD->aim_;
		sBattlePtr useSide = ptr->atkHand_;
		if (declare.camp != 0)
		{
			useSide = ptr->defHand_;
		}
		const unsigned y = m_aim->Y();
		for (unsigned x = 0; x < 3; ++x)
		{
			mBattlePtr c_aim = useSide->getUser(x, y);
			if (!c_aim || (m_aim == c_aim) || !c_aim->passLimit(declare))continue;
			uni->pushAim(c_aim);
		}
	}

	void battle_system::aim_cross_new(BattleData::envPtr ptr, BattleData::unitPtr uni, const AIM::structAIM& declare)
	{
		aim_single_new(ptr, uni, declare);
		BattleData::unit::aimPtr aimD = uni->mainAim();
		if (!aimD || !aimD->aim_)return;
		mBattlePtr m_aim = aimD->aim_;
		sBattlePtr useSide = ptr->atkHand_;
		if (declare.camp != 0)
		{
			useSide = ptr->defHand_;
		}
		const unsigned X = m_aim->X();
		const unsigned Y = m_aim->Y();
		for (unsigned y = 0; y < 3; ++y)
		{
			mBattlePtr c_aim = useSide->getUser(X, y);
			if (!c_aim || (m_aim == c_aim) || !c_aim->passLimit(declare))continue;
			uni->pushAim(c_aim);
		}
		for (unsigned x = 0; x < 3; ++x)
		{
			mBattlePtr c_aim = useSide->getUser(x, Y);
			if (!c_aim || (m_aim == c_aim) || !c_aim->passLimit(declare))continue;
			uni->pushAim(c_aim);
		}
	}

	void battle_system::aim_cross_sign(BattleData::envPtr ptr, BattleData::unitPtr uni, const AIM::structAIM& declare)
	{
		BattleData::unit::aimPtr aimD = uni->mainAim();
		if (!aimD || !aimD->aim_)return;
		mBattlePtr m_aim = aimD->aim_;
		sBattlePtr useSide = ptr->atkHand_;
		if (declare.camp != 0)
		{
			useSide = ptr->defHand_;
		}
		const unsigned X = m_aim->X();
		const unsigned Y = m_aim->Y();
		for (unsigned y = 0; y < 3; ++y)
		{
			mBattlePtr c_aim = useSide->getUser(X, y);
			if (!c_aim || (m_aim == c_aim) || !c_aim->passLimit(declare))continue;
			uni->pushAim(c_aim);
		}
		for (unsigned x = 0; x < 3; ++x)
		{
			mBattlePtr c_aim = useSide->getUser(x, Y);
			if (!c_aim || (m_aim == c_aim) || !c_aim->passLimit(declare))continue;
			uni->pushAim(c_aim);
		}
	}

	void battle_system::aim_random_new(BattleData::envPtr ptr, BattleData::unitPtr uni, const AIM::structAIM& declare)
	{
		sBattlePtr useSide = ptr->atkHand_;
		if (declare.camp != 0)
		{
			useSide = ptr->defHand_;
		}
		manList mL = useSide->getALLUser(declare);
		random_shuffle(mL.begin(), mL.end());
		for (unsigned num = 0; num < mL.size() && num < declare.otherData.Romdom.rNum; ++num)
		{
			uni->pushAim(mL[num]);
		}
	}

	void battle_system::aim_random_sign(BattleData::envPtr ptr, BattleData::unitPtr uni, const AIM::structAIM& declare)
	{
		sBattlePtr useSide = ptr->atkHand_;
		if (declare.camp != 0)
		{
			useSide = ptr->defHand_;
		}
		manList mL = useSide->getALLUser(declare);
		random_shuffle(mL.begin(), mL.end());
		mBattlePtr main_aim = uni->mainAim() ? uni->mainAim()->aim_ : mBattlePtr();
		for (unsigned num = 0; num < mL.size() && num < declare.otherData.Romdom.rNum && num < uni->sizeAim(); ++num)
		{
			if (main_aim == mL[num])continue;
			uni->pushAim(mL[num]);
		}
	}

	void battle_system::aim_current_new(BattleData::envPtr ptr, BattleData::unitPtr uni, const AIM::structAIM& declare)
	{
		if (declare.camp == 0)
		{
			mBattlePtr user = ptr->currentUser();
			if (user->passLimit(declare))
			{
				uni->pushAim(user);
			}
		}
		else
		{
			aim_single_new(ptr, uni, declare);
		}
	}

	void battle_system::aim_current_sign(BattleData::envPtr ptr, BattleData::unitPtr uni, const AIM::structAIM& declare)
	{
		//ʲôҲ����
	}

	void battle_system::aim_other_new(BattleData::envPtr ptr, BattleData::unitPtr uni, const AIM::structAIM& declare)
	{
		if (declare.camp == 0)
		{
			sBattlePtr useSide = ptr->atkHand_;
			manList mL = useSide->getALLUser(declare);
			for (unsigned num = 0; num < mL.size(); ++num)
			{
				mBattlePtr m = mL[num];
				if (m == ptr->currentUser())continue;
				uni->pushAim(m);
			}
		}
		else
		{
			aim_single_new(ptr, uni, declare);
			if (!uni->hasMainAim())return;
			mBattlePtr aimMain = uni->mainAim()->aim_;
			uni->clearAim();//�����״�ѡ������Ŀ��
			sBattlePtr useSide = ptr->defHand_;
			manList mL = useSide->getALLUser(declare);
			for (unsigned num = 0; num < mL.size(); ++num)
			{
				mBattlePtr m = mL[num];
				if (aimMain == m)continue;
				uni->pushAim(mL[num]);
			}
		}
	}

	void battle_system::aim_other_sign(BattleData::envPtr ptr, BattleData::unitPtr uni, const AIM::structAIM& declare)
	{
		mBattlePtr main_aim = uni->mainAim() ? uni->mainAim()->aim_ : mBattlePtr();
		uni->clearAim();//�����״�ѡ������Ŀ��
		if (declare.camp == 0)
		{
			sBattlePtr useSide = ptr->atkHand_;
			manList mL = useSide->getALLUser(declare);
			for (unsigned num = 0; num < mL.size(); ++num)
			{
				mBattlePtr m = mL[num];
				if (m == ptr->currentUser())continue;
				uni->pushAim(m);
			}
		}
		else
		{
			sBattlePtr useSide = ptr->defHand_;
			manList mL = useSide->getALLUser(declare);
			for (unsigned num = 0; num < mL.size(); ++num)
			{
				mBattlePtr m = mL[num];
				if (main_aim == m)continue;
				uni->pushAim(mL[num]);
			}
		}
	}

	void battle_system::aim_all_new(BattleData::envPtr ptr, BattleData::unitPtr uni, const AIM::structAIM& declare)
	{
		if (declare.camp == 0)
		{
			sBattlePtr useSide = ptr->atkHand_;
			manList mL = useSide->getALLUser(declare);
			for (unsigned num = 0; num < mL.size(); ++num)
			{
				uni->pushAim(mL[num]);
			}
		}
		else
		{
			aim_single_new(ptr, uni, declare);
			if (!uni->hasMainAim())return;
			mBattlePtr aimMain = uni->mainAim()->aim_;
			sBattlePtr useSide = ptr->defHand_;
			manList mL = useSide->getALLUser(declare);
			for (unsigned num = 0; num < mL.size(); ++num)
			{
				mBattlePtr m = mL[num];
				if (aimMain == m)continue;
				uni->pushAim(mL[num]);
			}
		}
	}


	void battle_system::aim_all_sign(BattleData::envPtr ptr, BattleData::unitPtr uni, const AIM::structAIM& declare)
	{
		mBattlePtr main_aim = uni->mainAim() ? uni->mainAim()->aim_ : mBattlePtr();
		if (declare.camp == 0)
		{
			sBattlePtr useSide = ptr->atkHand_;
			manList mL = useSide->getALLUser(declare);
			for (unsigned num = 0; num < mL.size(); ++num)
			{
				mBattlePtr m = mL[num];
				if (main_aim == m)continue;
				uni->pushAim(mL[num]);
			}
		}
		else
		{
			sBattlePtr useSide = ptr->defHand_;
			manList mL = useSide->getALLUser(declare);
			for (unsigned num = 0; num < mL.size(); ++num)
			{
				mBattlePtr m = mL[num];
				if (main_aim == m)continue;
				uni->pushAim(mL[num]);
			}
		}
	}

	//////////////////////////////////////////////////////////////////////////end
}
#include "player_kingdomwar_task.h"
#include "playerManager.h"

namespace gg
{
	namespace KingdomWar
	{
		namespace Task
		{
			class OneInt
				: public IParam
			{
				public:
					OneInt(int val): value(val){}

					virtual void load(const mongo::BSONElement& obj)
					{
						std::vector<mongo::BSONElement> ele = obj.Array();
						value = ele[0u].Int();
					}
					virtual mongo::BSONArray toBSON() const
					{
						mongo::BSONArrayBuilder b;
						b.append(value);
						return b.arr();
					}
					virtual void getInfo(qValue& q) const
					{
						q.append(value);
					}

					int value;
			};

			SHAREPTR(OneInt, OneIntPtr);
			
			class TwoInt
				: public IParam
			{
				public:
					TwoInt(int val1, int val2): value1(val1), value2(val2){}

					virtual void load(const mongo::BSONElement& obj)
					{
						std::vector<mongo::BSONElement> ele = obj.Array();
						value1 = ele[0u].Int();
						value2 = ele[2u].Int();
					}
					virtual mongo::BSONArray toBSON() const
					{
						mongo::BSONArrayBuilder b;
						b.append(value1);
						b.append(value2);
						return b.arr();
					}
					virtual void getInfo(qValue& q) const
					{
						q.append(value1);
						q.append(value2);
					}

					int value1;
					int value2;
			};

			SHAREPTR(TwoInt, TwoIntPtr);


#define CHECKER(name)\
	class name\
		: public ICheck\
	{\
		public:\
			static CheckPtr create(const Json::Value& info)\
			{\
				LogE << "kingdom war task type not implement: " << #name << " (" << info["ty"].asInt() << ").." << LogEnd;\
				return Creator<name>::Create(info);\
			}\
			name(const Json::Value& info)\
				: ICheck(info["ty"].asInt())\
			{\
				ForEachC(Json::Value, it, info["arg"])\
					_args.push_back((*it).asInt());\
			}\
			virtual int update(playerDataPtr d, ParamPtr& param, ArgPtr arg = ArgPtr());\
			virtual int init(playerDataPtr d, ParamPtr& param);\
		protected:\
			std::vector<int> _args;\
	}

			CHECKER(CBattleTimes);
			CHECKER(CWinStreakTimes);
			CHECKER(CGetExploit);
			CHECKER(CUseFood);

			int CBattleTimes::update(playerDataPtr d, ParamPtr& param, ArgPtr arg)
			{
				OneIntPtr param_ptr = upCast<OneInt>(param);
				NumArgPtr arg_ptr = upCast<NumArg>(arg);
				param_ptr->value += arg_ptr->value();
				if (param_ptr->value > _args[0u])
					param_ptr->value = _args[0u];
				return param_ptr->value >= _args[0u]? Finished : Running;
			}

			int CBattleTimes::init(playerDataPtr d, ParamPtr& param)
			{
				param = Creator<OneInt>::Create(0);
				OneIntPtr param_ptr = upCast<OneInt>(param);
				return param_ptr->value >= _args[0u]? Finished : Running;
			}

			int CWinStreakTimes::update(playerDataPtr d, ParamPtr& param, ArgPtr arg)
			{
				TwoIntPtr param_ptr = upCast<TwoInt>(param);
				if (!arg)
					param_ptr->value2 = 0;
				else
				{
					NumArgPtr arg_ptr = upCast<NumArg>(arg);
					param_ptr->value2 += arg_ptr->value();
				}
				if (param_ptr->value2 == _args[1u])
				{
					++param_ptr->value1;
					param_ptr->value2 = 0;
				}
				if (param_ptr->value1 > _args[0u])
					param_ptr->value1 = _args[0u];
				return param_ptr->value1 >= _args[0u]? Finished : Running;
			}

			int CWinStreakTimes::init(playerDataPtr d, ParamPtr& param)
			{
				param = Creator<TwoInt>::Create(0, 0);
				TwoIntPtr param_ptr = upCast<TwoInt>(param);
				return param_ptr->value1 >= _args[0u]? Finished : Running;
			}

			int CGetExploit::update(playerDataPtr d, ParamPtr& param, ArgPtr arg)
			{
				TwoIntPtr param_ptr = upCast<TwoInt>(param);
				NumArgPtr arg_ptr = upCast<NumArg>(arg);
				param_ptr->value1 += arg_ptr->value();
				if (param_ptr->value1 > param_ptr->value2)
					param_ptr->value1 = param_ptr->value2;
				return param_ptr->value1 >= param_ptr->value2? Finished : Running;
			}

			int CGetExploit::init(playerDataPtr d, ParamPtr& param)
			{
				param = Creator<TwoInt>::Create(0, _args[0u] * d->LV() + _args[1u]);
				TwoIntPtr param_ptr = upCast<TwoInt>(param);
				return param_ptr->value1 >= param_ptr->value2? Finished : Running;
			}

			int CUseFood::update(playerDataPtr d, ParamPtr& param, ArgPtr arg)
			{
				TwoIntPtr param_ptr = upCast<TwoInt>(param);
				NumArgPtr arg_ptr = upCast<NumArg>(arg);
				param_ptr->value1 += arg_ptr->value();
				if (param_ptr->value1 > param_ptr->value2)
					param_ptr->value1 = param_ptr->value2;
				return param_ptr->value1 >= param_ptr->value2? Finished : Running;
			}

			int CUseFood::init(playerDataPtr d, ParamPtr& param)
			{
				param = Creator<TwoInt>::Create(0, _args[0u] * d->LV() + _args[1u]);
				TwoIntPtr param_ptr = upCast<TwoInt>(param);
				return param_ptr->value1 >= param_ptr->value2? Finished : Running;
			}

			class CheckPtrFactory
			{
				public:
					typedef boost::function<CheckPtr(const Json::Value&)> CreateFunc;
					STDVECTOR(CreateFunc, CreateFuncMap);
					CheckPtrFactory()
					{
						_creator_map[BattleTimes] = boostBind(CBattleTimes::create, _1);
						_creator_map[GetExploit] = boostBind(CGetExploit::create, _1);
						_creator_map[WinStreakTimes] = boostBind(CWinStreakTimes::create, _1);
						_creator_map[UseFood] = boostBind(CUseFood::create, _1);
					}
					CheckPtr create(const Json::Value& info)
					{
						int type = info["ty"].asInt();
						if (type <= Empty || type >= PTaskMax)
							return _creator_map[Empty](info);

						return _creator_map[type](info);
					}
				private:
					CreateFunc _creator_map[PTaskMax];
			};

			struct PersonTaskConfig
			{
				PersonTaskConfig(): id(-1){}
				PersonTaskConfig(const Json::Value& info)
				{
					static CheckPtrFactory factory;
					id = info["id"].asInt();
					weight = info["weight"].asInt();
					checker = factory.create(info);
					reward = info["reward"];
				}
				bool valid() const { return id != -1; }
				int id;
				int weight;
				CheckPtr checker;
				Json::Value reward;
			};

			class PersonTaskConfigMgr
			{
				public:
					static PersonTaskConfigMgr& shared()
					{
						static PersonTaskConfigMgr config_mgr; 
						return config_mgr;
					}
					
					PersonTaskConfigMgr()
					{
						Json::Value json = Common::loadJsonFile("./instance/kingdom_war/person_task.json");
						ForEach(Json::Value, it, json)
						{
							_total_weight += (*it)["weight"].asUInt();
							_config_map.insert(make_pair((*it)["id"].asInt(), PersonTaskConfig(*it)));
						}
						if (_config_map.empty())
							LogE << "kingdom war person_task.json error" << LogEnd;
					}

					const PersonTaskConfig& getConfig(int id) const
					{
						ConfigMap::const_iterator it = _config_map.find(id);
						return it == _config_map.end()? _null : it->second;
					}

					const PersonTaskConfig& randConfig() const
					{
						unsigned val = Common::randomUInt(1, _total_weight);
						ForEachC(ConfigMap, it, _config_map)
						{
							if (val <= it->second.weight)
								return it->second;
						}
						return _null;
					}
					
				private:
					static PersonTaskConfig _null;
					STDMAP(int, PersonTaskConfig, ConfigMap);
					ConfigMap _config_map;
					unsigned _total_weight;
			};

			PersonTaskConfig PersonTaskConfigMgr::_null;

			void Record::load(const PersonTaskConfig& config, playerDataPtr d)
			{
				_id = config.id;
				_checker = config.checker;
				_state = _checker->init(d, _param);
			}

			void Record::load(const mongo::BSONElement& obj)
			{
				_id = obj["i"].Int();
				_state = obj["s"].Int();
				_param->load(obj["p"]);
			}

			mongo::BSONObj Record::toBSON() const 
			{
				return BSON("i" << _id << "s" << _state << "p" << _param->toBSON());
			}

			void Record::getInfo(qValue& q) const
			{
				q.append(_id);
				q.append(_state);
				qValue p;
				_param->getInfo(p);
				q.append(p);
			}

			void Record::update(playerDataPtr d, ArgPtr& arg)
			{
				if (!_checker
					&& !getChecker())
					return;
				_state = _checker->update(d, _param, arg);			
			}

			bool Record::getChecker()
			{
				const PersonTaskConfig& config = PersonTaskConfigMgr::shared().getConfig(_id);
				if (!config.valid())
					return false;
				_checker = config.checker;
				return true;
			}
		}
	}

	playerKingdomWarTask::playerKingdomWarTask(playerData* const own)
		: _auto_player(own), _next_update_time(0)
	{
	}

	void playerKingdomWarTask::loadDB()
	{
		mongo::BSONObj key = BSON(strPlayerID << Own().ID());
		mongo::BSONObj obj = db_mgr.FindOne(DBN::dbPlayerKingdomWarTask, key);
		if (obj.isEmpty())
			return;

		_person_task.load(obj["pt"]);
		_next_update_time = obj["nt"].Int();
	}

	bool playerKingdomWarTask::_auto_save()
	{
		mongo::BSONObj key = BSON(strPlayerID << Own().ID());
		mongo::BSONObjBuilder obj;
		obj << strPlayerID << Own().ID() << "nt" << _next_update_time
			<< "pt" << _person_task.toBSON();
		return db_mgr.SaveMongo(DBN::dbPlayerKingdomWarTask, key, obj.obj());
	}

	void playerKingdomWarTask::_auto_update()
	{
		update();
	}

	void playerKingdomWarTask::update()
	{
	
	}

	void playerKingdomWarTask::checkAndUpdate()
	{
		unsigned cur_time = Common::gameTime();
		if (cur_time >= _next_update_time)
		{
			const KingdomWar::Task::PersonTaskConfig& config = KingdomWar::Task::PersonTaskConfigMgr::shared().randConfig();
			if (!config.valid())
			{
				LogE << "kingdom war person task rand error" << LogEnd;
				return;
			}
			_person_task.load(config, Own().getOwnDataPtr());
			_next_update_time = Common::getNextTimeHMS(cur_time, 20, 25, 0);
			_sign_save();
		}
	}

	void playerKingdomWarTask::update(int type, KingdomWar::Task::ArgPtr& arg)
	{
		checkAndUpdate();

		if (_person_task.type() != type
				|| _person_task.state() != KingdomWar::Task::Running)
			return;

		_person_task.update(Own().getOwnDataPtr(), arg);
		_sign_save();
	}

	int playerKingdomWarTask::getPersonTaskReward()
	{
		checkAndUpdate();

		if (_person_task.state() != KingdomWar::Task::Finished)
			return err_illedge;

		const KingdomWar::Task::PersonTaskConfig& config = KingdomWar::Task::PersonTaskConfigMgr::shared().getConfig(_person_task.id());
		if (!config.valid())
			return err_illedge;

		const Json::Value& reward = config.reward;
		int arg1 = reward[0u].asInt();
		int arg2 = reward[1u].asInt();
		int silver = Own().LV() * arg1 + arg2;
		int exploit = Own().LV() * arg1 + arg2;
		_person_task.setState(KingdomWar::Task::Rewarded);
		return res_sucess;
	}
}

#include "playerCount.h"
#include "dbDriver.h"

namespace gg
{
	namespace CountData
	{
		Data::Data(playerData* const own, const int id) :
			_auto_player(own), seqID(id)
		{
			seqCount.resize(20, 0);
		}

		bool Data::_auto_save()
		{
			mongo::BSONObj  key = BSON(strPlayerID << Own().ID() << "sid" << seqID);
			mongo::BSONArrayBuilder arr;
			for (unsigned i = 0; i < seqCount.size(); ++i)
			{
				arr << seqCount[i];
			}
			mongo::BSONObj  obj = BSON(strPlayerID << Own().ID() << "sid" << seqID <<
				"seq" << arr.arr());
			return db_mgr.SaveMongo(DBN::dbPlayerCount, key, obj);
		}

		int Data::getKey(const int id)
		{
			return id % 20;
		}

		unsigned Data::getCount(const int id)
		{
			if (id < 0)return 0;
			const int key = getKey(id);
			return seqCount[key];
		}

		void Data::resetCount(const int id)
		{
			if (id < 0)return;
			const int key = getKey(id);
			seqCount[key] = 0;
			_sign_save();
		}

		void Data::tickCount(const int id)
		{
			if (id < 0)return;
			const int key = getKey(id);
			unsigned& val = seqCount[key];
			if (val < 1000)
			{
				++val;
				_sign_save();
			}
		}
	}

	playerCount::playerCount(playerData* const own) : _auto_player(own)
	{
		mapData.clear();
	}

	void playerCount::loadDB()
	{
		mongo::BSONObj  key = BSON(strPlayerID << Own().ID());
		objCollection collects = db_mgr.Query(DBN::dbPlayerCount, key);
		for (unsigned i = 0; i < collects.size(); ++i)
		{
			mongo::BSONObj& obj = collects[i];
			const int id = obj["sid"].Int();
			CountData::CountPtr ptr = Creator<CountData::Data>::Create(_Own, id);
			vector<mongo::BSONElement> vec = obj["seq"].Array();
			for (unsigned n = 0; n < vec.size() && n < 20; ++n)
			{
				ptr->seqCount[n] = (unsigned)vec[n].Int();
			}
			mapData[id] = ptr;
		}
	}

	int playerCount::getKey(const int id)
	{
		return id / 20;
	}

	CountData::CountPtr playerCount::getData(const int id)
	{
		const int key = getKey(id);
		DataMap::iterator it = mapData.find(key);
		if (it == mapData.end())
		{
			CountData::CountPtr ptr = Creator<CountData::Data>::Create(_Own, key);
			mapData[key] = ptr;
			return ptr;
		}
		return it->second;
	}

	unsigned playerCount::getCount(const int id)
	{
		if (id < 0)return 0;
		return getData(id)->getCount(id);
	}

	void playerCount::resetCount(const int id)
	{
		if (id < 0)return;
		getData(id)->resetCount(id);
	}

	void playerCount::tickCount(const int id)
	{
		if (id < 0)return;
		getData(id)->tickCount(id);
	}

}
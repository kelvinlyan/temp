#pragma once

#include "auto_base.h"
#include "mongoDB.h"
#include "battle_def.h"
#include "battle_system.h"
#include "kingdomwar_helper.h"

namespace gg
{
	struct mapDataConfig;
	SHAREPTR(mapDataConfig, MapDataCfgPtr);

	namespace KingdomWar
	{
		class NpcData
			: public _auto_meta
		{
			public:
				NpcData(const mongo::BSONObj& obj);
				NpcData(int type, int map_id, int nation, const Position& pos, int hp, const std::vector<int>& man_hp);
				~NpcData();

				int type() const { return _type; }
				int id() const { return _id; }
				const std::string& name() const { return _name; }
				int nation() const { return _nation; }
				int hp() const { return _hp; }
				const MapDataCfgPtr& npcData() const { return _npc_data; }
				bool valid() const { return (bool)_npc_data; }
				bool checkValidAndSave();
				void setDead() { _dead = true; }

				int alterHp(int num);
				void resetManHp(sBattlePtr& ptr);

				sBattlePtr getBattlePtr(int& max_hp, int& cur_hp);
				bool isDead() const;
				
				const Position& position() const { return _pos; }
				void setPosition(int type, int id, unsigned time);

			private:
				virtual bool _auto_save();
				void removeDB();
			
			private:
				int _type;
				int _id;
				std::string _name;
				int _nation;
				int _hp;
				std::vector<int> _man_hp;
				MapDataCfgPtr _npc_data;
				Position _pos;
				bool _dead;
		};

		SHAREPTR(NpcData, NpcDataPtr);
	}
}

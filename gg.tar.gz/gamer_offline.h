//###################################
//create by Jim
//2016-05-03
//###################################

#pragma once

#include "auto_do.h"

namespace gg
{
	class playerOffline :
		public _auto_player
	{
	public:
		playerOffline(playerData* const own);
		~playerOffline(){}
		void loadDB();
		void Off();
		void Online();
		inline unsigned OffTime(){ return offline; }
		inline unsigned OffDay(){ return offlineStanderDay; }
		void resetOffDay();
		void resetOffDayTime();
		virtual void _auto_update();
	private:
		virtual bool _auto_save();
		unsigned offline;
		unsigned offlineStander;//��׼����ʱ��
		unsigned offlineStanderDay;//��������
	};
}
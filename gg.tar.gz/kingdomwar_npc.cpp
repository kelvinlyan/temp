#include "dbDriver.h"
#include "kingdomwar_npc.h"
#include "kingdomwar_system.h"
#include "map_war.h"

namespace gg
{
	namespace KingdomWar
	{
		class NpcIDCreator
			: public _auto_meta
		{
			public:
				NpcIDCreator();
				int get();

			private:
				virtual bool _auto_save();
				
			private:
				int _id;
		};

		NpcIDCreator::NpcIDCreator()
		{
			mongo::BSONObj key = BSON(strNpcID << 0);
			mongo::BSONObj obj = db_mgr.FindOne(DBN::dbKingdomWarNpc, key);
			if (!obj.isEmpty())
				_id = obj["mi"].Int();
			else
				_id = 0;
		}

		int NpcIDCreator::get()
		{
			--_id;
			_sign_save();
			return _id;
		}

		bool NpcIDCreator::_auto_save()
		{
			mongo::BSONObj key = BSON(strNpcID << 0);
			mongo::BSONObj obj = BSON(strNpcID << 0 << "mi" << _id);
			return db_mgr.SaveMongo(DBN::dbKingdomWarNpc, key, obj);
		}

		SHAREPTR(NpcIDCreator, NpcIDCreatorPtr);

		inline static int createNpcID()
		{
			static NpcIDCreatorPtr ptr = Creator<NpcIDCreator>::Create();
			return ptr->get();
		}

		NpcData::NpcData(const mongo::BSONObj& obj)
		{
			_dead = false;
			_id = obj[strNpcID].Int();
			_npc_data = kingdomwar_sys.getNpcData(obj["mi"].Int());
			_name = Common::toString(_npc_data->npcList.front().npcID);
			_hp = obj["h"].Int();
			_nation = obj["n"].Int();
			_type = obj["t"].Int();
			std::vector<mongo::BSONElement> ele = obj["mh"].Array();
			for (unsigned i = 0; i < ele.size(); ++i)
				_man_hp.push_back(ele[i].Int());
			_pos.type = obj["p"]["t"].Int();
			_pos.id = obj["p"]["i"].Int();
			_pos.time = obj["p"]["tm"].Int();
			_pos.from_id = obj["p"]["f"].Int();
		}

		NpcData::NpcData(int type, int map_id, int nation, const Position& pos, int hp, const std::vector<int>& man_hp)
		{
			_dead = false;
			_id = createNpcID();
			_type = type;
			_npc_data = kingdomwar_sys.getNpcData(map_id);
			_name = Common::toString(_npc_data->npcList.front().npcID);
			_nation = nation;
			_pos = pos;
			_hp = hp;
			_man_hp = man_hp;
		}

		NpcData::~NpcData()
		{
			if (!_dead)
				LogE << "Error Npc ID:" << _id << ", Type:" << _type << LogEnd;
		}

		void NpcData::removeDB()
		{
			mongo::BSONObj key = BSON(strNpcID << _id);
			db_mgr.RemoveCollection(DBN::dbKingdomWarNpc, key);
		}

		bool NpcData::_auto_save()
		{
			if (_dead)
			{
				removeDB();
				return true;
			}
			mongo::BSONObj key = BSON(strNpcID << _id);
			mongo::BSONObjBuilder obj;
			obj << strNpcID << _id << "mi" << _npc_data->mapId << "h" << _hp
				<< "n" << _nation << "t" << _type;
			obj << "p" << BSON("t" << _pos.type << "i" << _pos.id << "tm" << _pos.time << "f" << _pos.from_id);
			{
				mongo::BSONArrayBuilder b;
				ForEachC(std::vector<int>, it, _man_hp)
					b.append(*it);
				obj << "mh" << b.arr();
			}
			return db_mgr.SaveMongo(DBN::dbKingdomWarNpc, key, obj.obj());
		}

		sBattlePtr NpcData::getBattlePtr(int& max_hp, int& cur_hp)
		{
			sBattlePtr ptr = map_sys.npcSide(_npc_data);
			ptr->playerNation = _nation;
			if (_pos.type == PosCity)
			{
				CityPtr c_ptr = kingdomwar_sys.getCity(_pos.id);
				c_ptr->addBuff(ptr, _nation);
			}
			kingdomwar_sys.addHpDebuff(ptr, _hp);
			max_hp = 0;
			cur_hp = 0;
			manList& ml = ptr->battleMan;
			for (unsigned i = 0; i < ml.size(); ++i)
			{
				max_hp += ml[i]->currentHP;
				if (!_man_hp.empty())
					ml[i]->currentHP = _man_hp[i];
				cur_hp += ml[i]->currentHP;
			}
			return ptr;
		}
		
		int NpcData::alterHp(int num)
		{
			int pre_hp = _hp;
			_hp += num;
			if (_hp < 0)
				_hp = 0;
			_sign_save();
			return _hp - pre_hp;
		}

		void NpcData::resetManHp(sBattlePtr& ptr)
		{
			manList& ml = ptr->battleMan;
			for (unsigned i = 0; i < ml.size(); ++i)
			{
				if (i < _man_hp.size())
					_man_hp[i] = ml[i]->currentHP;
				else
					_man_hp.push_back(ml[i]->currentHP);
			}

			_sign_save();
		}

		bool NpcData::checkValidAndSave()
		{
			bool is_valid = valid();
			if (is_valid)
				_sign_save();
			return is_valid;
		}

		bool NpcData::isDead() const
		{
			if (_hp <= 0)
				return true;
			if (_man_hp.empty())
				return false;
			ForEachC(std::vector<int>, it, _man_hp)
			{
				if (*it > 0)
					return false;
			}
			return true;
		}

		void NpcData::setPosition(int type, int id, unsigned time)
		{
			if (_pos.type == PosCity)
				_pos.from_id = _pos.id;

			_pos.type = type;
			_pos.id = id;
			_pos.time = time;
			_sign_save();
		}
	}
}

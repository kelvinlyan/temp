#include "gamer_data.h"
#include "dbDriver.h"
#include "gate_account_protocol.h"
#include "game_server.h"
#include "warlords_system.h"
#include "task_mgr.h"
#include "email_system.h"
#include "kingdom_def.h"

namespace gg
{
	playerBase::playerBase(playerData* const own, const string pN) : _auto_player(own)
	{
		initial();
		playerName = pN;
	}

	playerBase::playerBase(playerData* const own, const int pID) : _auto_player(own)
	{
		initial();
		playerID = pID;
	}

	playerBase::playerBase(playerData* const own, const int pID, const string pN) : _auto_player(own)
	{
		initial();
		playerID = pID;
		playerName = pN;
	}

	static vector<unsigned> cfgExpSeq;
	static vector<unsigned> vipExpSeq;

	unsigned playerBase::MAXLEVEL()
	{
		return cfgExpSeq.size();
	}

	unsigned playerBase::MAXVIPLEVEL()
	{
		return vipExpSeq.size();
	}

	void playerBase::initData()
	{
		cfgExpSeq.clear();
		vipExpSeq.clear();
		Json::Value json = Common::loadJsonFile("./instance/gamer/exp.json");
		for (unsigned i = 0; i < json.size(); ++i)
		{
			cfgExpSeq.push_back(json[i].asUInt());
		}

		Json::Value ajson = Common::loadJsonFile("./instance/vip/vipexp.json");
		for (unsigned i = 0; i < ajson.size(); ++i)
		{
			vipExpSeq.push_back(ajson[i].asUInt());
		}
	}

	void playerBase::Online()
	{
		OnlineTime = Common::gameTime();
		_auto_save();
	}

	bool playerBase::motifyName(const string name)
	{
		if (name.empty())return false;
		if (name == playerName)return false;
		string tmpName = playerName;
		playerName = name;
		Log(DBLOG::strLogPlayerName, Own().getOwnDataPtr(), -1, tmpName, playerName);
		if (tmpName != playerName)
		{
			//���͸���̨
			Json::Value updateAccount;
			updateAccount[strMsg][0u] = playerName;
			string strSend = updateAccount.toIndentString();
			net::Msg mj(Own().ID(), service::process_id::ACCOUNT_NET_ID, protocol::l2c::notice_account_player_update_resp, strSend);
			game_svr->async_send_to_gate(mj);
			onNameMotify(tmpName);
		}
		_sign_auto();
		return true;
	}

	void playerBase::setSex(const Gender::SEX type)
	{
		playerGender = type;
		_sign_auto();
	}

	void playerBase::setNation(const Kingdom::NATION type)
	{
		const Kingdom::NATION old = playerNation;
		playerNation = type;
		onSetNation(old);
		_sign_auto();
		Log(DBLOG::strLogPlayerNation, Own().getOwnDataPtr(), -1, old, playerNation);
	}

	void playerBase::setFace(const int id)
	{
		int iOld = playerFaceID;
		playerFaceID = id;
		onSetFace(iOld);
		_sign_auto();
	}

	void playerBase::setSalary(bool bGet)
	{
		bGetOfficialSalary = bGet;
		_sign_auto();
	}

	void playerBase::setOfficial(const int officialAdd)
	{
		const int tmpOfficial = playerOfficial;
		playerOfficial += officialAdd;
		_sign_auto();
		onOfficialAlter(playerOfficial);
	}

	void playerBase::setLV_gm(const unsigned lv)
	{
		if (lv >= cfgExpSeq.size())
		{
			playerLV = cfgExpSeq.size();
		}
		else
		{
			playerLV = lv;
		}
	}

	void playerBase::setExp_gm(const unsigned exp)
	{
		playerExp = exp;
	}

	void playerBase::setDone_gm(const unsigned old)
	{
		upgrade();//�鿴�Ƿ�����
		if (old != playerLV)
		{
			onLevelAlter(old, playerLV);
			Log(DBLOG::strLogPlayerLevel, Own().getOwnDataPtr(), -1, old, playerLV);
		}
	}

	void playerBase::tickRename()
	{
		++renameTimes;
		_sign_auto();
	}

	void playerBase::setProcess(const unsigned pro)
	{
		Log(DBLOG::strLogClientProcess, Own().getOwnDataPtr(), -1, playerProcess, pro);
		playerProcess = pro;
		_sign_auto();
	}

	void playerBase::motifyNo_(const int no)
	{
		rankNo_ = no;
	}

	void playerBase::motifyNationOf_(const int of)
	{
		_sign_update();
		/*if (of == nationOfficial)return;
		nationOfficial = of;
		if (Own().isInitial())
		{
			_sign_update();
		}*/
	}

	void playerBase::upgrade()
	{
		for (unsigned idx = playerLV; idx < cfgExpSeq.size(); ++idx)
		{
			if (playerExp >= cfgExpSeq[idx])
			{
				playerExp -= cfgExpSeq[idx];
				playerLV = idx + 1;
				continue;
			}
			break;
		}
		if (playerLV >= cfgExpSeq.size())
		{
			playerExp = 0;
		}
	}

	bool playerBase::isMaxLevel()
	{
		return (playerLV >= cfgExpSeq.size());
	}

	int playerBase::addExp(const unsigned val)
	{
		if (playerLV >= cfgExpSeq.size())return err_gamer_level_max;
		if (val < 1)return err_illedge;
		const int tmpLevel = playerLV;
		const int tmpExp = playerExp;
		playerExp += val;
		upgrade();
		if (tmpLevel != playerLV)
		{
			onLevelAlter(tmpLevel, playerLV);
			Log(DBLOG::strLogPlayerLevel, Own().getOwnDataPtr(), -1, tmpLevel, playerLV, tmpExp, playerExp);
		}
		_sign_auto();
		return res_sucess;
	}

	int playerBase::addVipExp(const unsigned val)
	{
		if (playerVipLv > vipExpSeq.size()) return err_vip_level_max;
		if (val < 1) return err_illedge;
		int temVipLevel = playerVipLv;
		int tmpVipExp = playerVipExp;
		playerVipExp += val;

// 		if (playerVipLv == 0 && tmpVipExp == 0 && playerVipExp > 0)
// 			Own().Vip->addVipGift(0);

		for (unsigned idx = playerVipLv; idx < vipExpSeq.size(); ++idx)
		{
			if (playerVipExp >= vipExpSeq[idx])
			{
				playerVipExp -= vipExpSeq[idx];
				playerVipLv = idx + 1;
				Own().Vip->addVipGift(playerVipLv);
				TaskMgr::update(Own().getOwnDataPtr(), Task::Vip);
				continue;
			}
			break;
		}
		if (playerVipLv >= vipExpSeq.size())
		{
			playerVipExp = 0;
		}
		if (temVipLevel != playerVipLv)
		{
			onVipAlter(temVipLevel, playerVipLv);
			Log(DBLOG::strLogPlayerVipLevel, Own().getOwnDataPtr(), -1, temVipLevel, playerVipLv);
		}
		_sign_auto();
		return res_sucess;
	}

	void playerBase::_auto_update()
	{
		qValue json(qJson::qj_object), list_json(qJson::qj_array), resJson(qJson::qj_object);
		resJson.addMember(strPlayerID, playerID);
		resJson.addMember(strPlayerName, playerName);
		resJson.addMember(strPlayerLV, playerLV);
		resJson.addMember("exp", playerExp);
		resJson.addMember("sex", playerGender);
		resJson.addMember("nat", playerNation);
		resJson.addMember("fid", playerFaceID);
		resJson.addMember("of", playerOfficial);
		resJson.addMember("rn", renameTimes);
		resJson.addMember("os", bGetOfficialSalary);
		resJson.addMember("vip", playerVipLv);
		resJson.addMember("vexp", playerVipExp);
		resJson.addMember("pp", playerProcess);
		resJson.addMember("nof", NationOf_());
		resJson.addMember("pc", playerCreate);
		resJson.addMember("lut", LVUpLast);
		list_json.append(res_sucess);
		list_json.append(resJson);
		json.addMember(strMsg, list_json);
		Own().sendToClient(gate_client::player_info_update_resp, json);
	}

	bool playerBase::_auto_save()
	{
		mongo::BSONObj key = BSON(strPlayerID << playerID);// << strPlayerName << playerName);
		mongo::BSONObj obj = BSON(strPlayerID << playerID << strPlayerName << playerName << strPlayerLV << playerLV <<
			"exp" << playerExp << "sex" << playerGender << "nat" << playerNation << "fid" << playerFaceID << "pc" << 
			playerCreate << "of" << playerOfficial << "rn" << renameTimes << "os" << bGetOfficialSalary << "vip" << 
			playerVipLv << "vexp" << playerVipExp << "pp" << playerProcess << "lut" << LVUpLast << "olt" << 
			OnlineTime);
		return db_mgr.SaveMongo(DBN::dbPlayerBase ,key, obj);
	}


	bool playerBase::loadDB()
	{
		mongo::BSONObj key;
		if (playerID > 0)key = BSON(strPlayerID << playerID);
		else if (!playerName.empty())key = BSON(strPlayerName << playerName);
		else return false;
		mongo::BSONObj obj = db_mgr.FindOne(DBN::dbPlayerBase, key);
		if (obj.isEmpty())return false;
		playerID = obj[strPlayerID].Int();
		playerName = obj[strPlayerName].String();
		playerLV = (unsigned)obj[strPlayerLV].Int();
		playerExp = obj["exp"].Int();
		playerGender = (Gender::SEX)obj["sex"].Int();
		playerNation = (Kingdom::NATION)obj["nat"].Int();
		playerFaceID = obj["fid"].Int();
		playerCreate = (unsigned)obj["pc"].Int();
		playerOfficial = obj["of"].Int();
		if (!obj["rn"].eoo())renameTimes = obj["rn"].Int();
		if (!obj["os"].eoo())bGetOfficialSalary = obj["os"].Bool();
		playerVipLv = obj["vip"].eoo() ? 0 : obj["vip"].Int();
		playerVipExp = obj["vexp"].eoo() ? 0 : obj["vexp"].Int();
		playerProcess = obj["pp"].eoo() ? 0 : obj["pp"].Int();
		if (!obj["lut"].eoo())LVUpLast = obj["lut"].Int();
		OnlineTime = obj["olt"].eoo() ? Common::gameTime() : obj["olt"].Int();
		return true;
	}

	void playerBase::initial()
	{
		playerID = -1;
		playerName = "";
		playerCreate = 0;
		playerExp = 0;
		playerFaceID = -1;
		playerGender = Gender::Other;
		playerNation = Kingdom::null;
		playerLV = 1;//��ҳ�ʼΪ1
		LVUpLast = 0;
		playerOfficial = 0;
		bGetOfficialSalary = false;
		renameTimes = 0;
		playerVipLv = 0;
		playerVipExp = 0;
		playerProcess = 0;
		rankNo_ = -1;//ȺӢ������//Ĭ��������
		//nationOfficial = Kingdom::None;//��Ч�Ĺ�ְ
		OnlineTime = 0;
	}

	int playerBase::NationOf_()
	{
		return Own().KingFight->getTitle();
	}
}

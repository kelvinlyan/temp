#include "zip_file.hpp"

namespace gg
{

	zipFile::zipFile(const unsigned length/* = 102400*/, const int ioID /* = DangerIO::file_io */) :
		_length(length), _io_id(ioID)
	{
		_buffer_write = (unsigned char*)::GNew(_length);//100k defalut
		_buffer_read = (unsigned char*)::GNew(_length);//100k defalut
	}

	zipFile::~zipFile()
	{
		::GDelete(_buffer_write);
		::GDelete(_buffer_read);
		_buffer_write = NULL;
		_buffer_read = NULL;
	}

	void zipFile::write(const std::string dir, qValue& json)
	{
		if (json.isEmpty())return;
		std::string str = json.toIndentString();
		_impl_write(dir, str);
	}

	void zipFile::write(const std::string dir, Json::Value& json)
	{
		if (json.isNull())return;
		std::string str = json.toIndentString();
		_impl_write(dir, str);
	}

	void zipFile::write(const std::string dir, const std::string& str)
	{
		_impl_write(dir, str);
	}

	void zipFile::async_write(const std::string dir, qValue& json)
	{
		if (json.isNull())
		{
			std::string str = "";
			IOMgr.otherIO(_io_id).post(boostBind(zipFile::_impl_write, this, dir, str));
			return;
		}
		std::string str = json.toIndentString();
		IOMgr.otherIO(_io_id).post(boostBind(zipFile::_impl_write, this, dir, str));
	}

	void zipFile::async_write(const std::string dir, Json::Value& json)
	{
		if (json.isNull())
		{
			std::string str = "";
			IOMgr.otherIO(_io_id).post(boostBind(zipFile::_impl_write, this, dir, str));
			return;
		}
		std::string str = json.toIndentString();
		IOMgr.otherIO(_io_id).post(boostBind(zipFile::_impl_write, this, dir, str));
	}

	void zipFile::async_write(const std::string dir, const std::string& str)
	{
		IOMgr.otherIO(_io_id).post(boostBind(zipFile::_impl_write, this, dir, str));
	}

	void zipFile::_impl_write(const std::string& dir, const std::string& str)
	{
		try
		{
			std::ofstream f(dir.c_str(), std::ios::out | std::ios::trunc | std::ios::binary);
			unsigned long lsize = _length;
			int res = compress(_buffer_write, &lsize, (const unsigned char*)str.c_str(), str.length());
			if (res != Z_OK){
				LogE << "zlib compress failed ... error code :" << res << LogEnd;
			}
			else{
				f.write((const char*)_buffer_write, lsize);
				f.flush();
			}
			f.close();
		}
		catch (std::exception& e)
		{
			LogE << e.what() << LogEnd;
		}
	}

	std::string zipFile::_impl_read(const std::string& dir)
	{
		ifstream i(dir.c_str(), std::ios::binary | std::ios::in);
		i.read((char*)_buffer_write, _length);
		unsigned long lsize = _length;
		unsigned long size = (unsigned long)i.gcount();
		int res = uncompress(_buffer_read, &lsize, _buffer_write, size);
		if (res != Z_OK)return std::string("");
		return std::string(_buffer_read, _buffer_read + lsize + 1);
	}

	std::string zipFile::read_string(const string dir)
	{
		return _impl_read(dir);
	}

	Json::Value zipFile::read_json(const string dir)
	{
		return Common::string2json(_impl_read(dir), dir);
	}

}
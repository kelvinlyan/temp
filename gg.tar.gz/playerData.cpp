#include "playerData.h"
#include "playerManager.h"
#include "service_config.h"

namespace gg
{
#define FalseBreak(DoName) \
	if(!(DoName.get()))\
			{\
		ret = false;\
		break;\
			}

	playerData::playerData(const int pID)
	{
		Info = Creator<playerBase>::Create(this, pID);
		initial();
	}

	playerData::playerData(const string pName)
	{
		Info = Creator<playerBase>::Create(this, pName);
		initial();
	}

	void playerData::initial()
	{
		//����ʵ��
		Tick = Creator<playerTick>::Create(this);
		Man = Creator<playerManMgr>::Create(this);
		Res = Creator<playerResource>::Create(this);
		War = Creator<playerMapWarMgr>::Create(this);
		Task = Creator<playerTask>::Create(this);
		WarFM = Creator<playerWarFM>::Create(this);
		Card = Creator<playerCardMgr>::Create(this);
		CardTs = Creator<playerCardTs>::Create(this);
		Items = Creator<playerItemMgr>::Create(this);
		Sch = Creator<playerSearch>::Create(this);
		Face = Creator<playerFace>::Create(this);
		Poke = Creator<playerPoke>::Create(this);
		Count = Creator<playerCount>::Create(this);
		CarPos = Creator<playerCarPos>::Create(this);
		Trade = Creator<playerTrade>::Create(this);
		KingFight = Creator<playerKingFight>::Create(this);
		KingDom = Creator<playerKingdom>::Create(this);
		RescueData = Creator<playerRescue>::Create(this);
		Team = Creator<playerTeam>::Create(this);
		Vip = Creator<playerVipMgr>::Create(this);
		WorldBoss = Creator<playerWorldBoss>::Create(this);
		Research = Creator<playerResearch>::Create(this);
		Market = Creator<playerMarket>::Create(this);
		Orders = Creator<playerOrders>::Create(this);
		Malls = Creator<playerMall>::Create(this);
		WarLords = Creator<playerWarLords>::Create(this);
		Email = Creator<playerEmail>::Create(this);
		Daily = Creator<playerDaily>::Create(this);
		BuildTeam = Creator<playerBuildTeam>::Create(this);
		Builds = Creator<playerBuilds>::Create(this);
		Admin = Creator<playerAdmin>::Create(this);
		Offline = Creator<playerOffline>::Create(this);
		Custom = Creator<playerCustom>::Create(this);
		DaysActivity = Creator<playerDaysActivity>::Create(this);
		OnlineBox = Creator<playerOnlineBox>::Create(this);
		Affair = Creator<playerAffair>::Create(this);
		Sign = Creator<playerSign>::Create(this);
		MoneyActivity = Creator<playerMoneyActivity>::Create(this);
		DailyCard = Creator<playerDailyCard>::Create(this);
		Fund = Creator<playerFund>::Create(this);
		KingDomWar = Creator<playerKingdomWar>::Create(this);
		KingDomWarShop = Creator<playerKingdomWarShop>::Create(this);
		KingDomWarOutput = Creator<playerKingdomWarOutput>::Create(this);
		KingDomWarFM = Creator<playerKingdomWarFM>::Create(this);
		KingDomWarPos = Creator<playerKingdomWarPos>::Create(this);
		KingDomWarBox = Creator<playerKingdomWarBox>::Create(this);
		KingDomWarTask = Creator<playerKingdomWarTask>::Create(this);
		Patrol = Creator<playerPatrol>::Create(this);

		//���ݳ�ʼ��
		memset(Chat, 0x0, sizeof(Chat));
		Online = false;
		Initial = false;
		TeamCD = 0;
		BusinessCD = 0;
		EquipShowCD = 0;
		ShareLastCD = 0;
		TeamAnnCD = 0;
	}

	playerData::~playerData()
	{
//		cout << "~playerData call" << endl;
	}

	void playerData::Login()
	{
		if (!isOnline())
		{
			Online = true;
			onLogin();
		}
	}

	void playerData::Logout()
	{
		if (isOnline())
		{
			Online = false;
			Initial = false;
			onOFFLine();
		}
	}

	void playerData::sendToClient(const short protocol, Json::Value& msg)
	{
		if (!isOnline())return;
		string str = msg.toIndentString();
		net::Msg mj(ID(), service::process_id::INVAILD_PLAYER_ID, protocol, str);
		player_mgr.sendToPlayer(mj);
	}

	void playerData::sendToClient(const short protocol, qValue& msg)
	{
		if (!isOnline())return;
		string str = msg.toIndentString();
		net::Msg mj(ID(), service::process_id::INVAILD_PLAYER_ID, protocol, str);
		player_mgr.sendToPlayer(mj);
	}

	void playerData::sendToClientFillMsg(const short protocol, qValue& msg)
	{
		if (!isOnline())return;
		qValue cmMsg(qJson::qj_object);
		cmMsg.addMember(strMsg, msg);
		string str = cmMsg.toIndentString();
		net::Msg mj(ID(), service::process_id::INVAILD_PLAYER_ID, protocol, str);
		player_mgr.sendToPlayer(mj);
	}

	void playerData::sendToClient(const short protocol, string& msg)
	{
		if (!isOnline())return;
		net::Msg mj(ID(), service::process_id::INVAILD_PLAYER_ID, protocol, msg);
		player_mgr.sendToPlayer(mj);
	}

	void playerData::sendToClientFillMsg(const short protocol, string& msg)
	{
		if (!isOnline())return;
		string str = "{\"msg\":[" + msg + "]";
		net::Msg mj(ID(), service::process_id::INVAILD_PLAYER_ID, protocol, str);
		player_mgr.sendToPlayer(mj);
	}


// 	bool playerData::outLine()
// 	{
// 		if (isOnline())return false;
// 		unsigned now = Common::gameTime();
// 		if (now < OFFTime || now - OFFTime > 7200)return true;
// 		return false;
// 	}

	bool playerData::isVaild()
	{
		return (ID() > 0 && Name().size() > 0);
	}

	bool playerData::beginLoad()
	{
		bool ret = false;
		do
		{
			if(!Info->loadDB())break;//���������Ч
			Tick->loadDB();
			Items->loadDB();
			KingDom->loadDB();
			Man->loadDB();
			WarFM->loadDB();
			Res->loadDB();
			Research->loadDB();
			Market->loadDB();
			Affair->loadDB();
			Builds->loadDB();
			BuildTeam->loadDB();
			Admin->loadDB();
			Orders->loadDB();
			War->loadDB();
			Task->loadDB();
			Poke->loadDB();
			Card->loadDB();
			CardTs->loadDB();
			Sch->loadDB();
			Count->loadDB();//����
			CarPos->loadDB();
			Trade->loadDB();
			KingFight->loadDB();
			RescueData->loadDB();
			Team->loadDB();
			Vip->loadDB();
			WorldBoss->loadDB();
			Malls->loadDB();
			Daily->loadDB();
			Offline->loadDB();
			Custom->loadDB();
			OnlineBox->loadDB();
			MoneyActivity->loadDB();
			DailyCard->loadDB();
			Fund->loadDB();
			Patrol->loadDB();
			//����������
			Items->sortOut(false);//��������//����//���ǲ�����
			Man->recalMan(false, true);//���ﲻ����//������ս��������¼�
			WarLords->loadDB();
			Email->loadDB();
			DaysActivity->loadDB();
			Sign->loadDB();
			KingDomWar->loadDB();
			KingDomWarShop->loadDB();
			KingDomWarOutput->loadDB();
			KingDomWarFM->loadDB();
			KingDomWarPos->loadDB();
			KingDomWarBox->loadDB();
			KingDomWarTask->loadDB();
			ret = true;
		} while (false);
		return ret;
	}
}

#pragma once

#include "auto_base.h"
#include "mongoDB.h"

namespace gg
{
	class playerData;
	SHAREPTR(playerData, playerDataPtr);

	namespace KingdomWar
	{
		namespace Task
		{
			enum
			{
				Empty = 0,
				BattleTimes,
				GetExploit,
				WinStreakTimes,
				UseFood,
				PTaskMax,
			};

			enum
			{
				Running = 0,
				Finished,
				Rewarded,
			};

			class IArg
			{
				virtual void none(){}
			};

			SHAREPTR(IArg, ArgPtr);

			class NumArg
				: public IArg
			{
				public:
					NumArg(int num): _value(num){}
					int value() const { return _value; }

				private:
					int _value;
			};

			class 

			SHAREPTR(NumArg, NumArgPtr);

			class IParam
			{
				public:
					virtual void load(const mongo::BSONElement& obj) = 0;
					virtual mongo::BSONArray toBSON() const = 0;
					virtual void getInfo(qValue& q) const = 0;
			};

			SHAREPTR(IParam, ParamPtr);

			class ICheck
			{
				public:
					ICheck(int type): _type(type){}
					int type() const { return _type; }
					virtual int init(playerDataPtr d, ParamPtr& param) = 0;
					virtual int update(playerDataPtr d, ParamPtr& param, ArgPtr arg = ArgPtr()) = 0;
				private:
					int _type;
			};

			SHAREPTR(ICheck, CheckPtr);

			enum
			{
				OccupySpecified = Empty + 1,
				GetExploit2,
				OccupyNum1,
				OccupyNum2,
				NTaskMax,
			};

			class ICheck2
			{
				public:
					ICheck2(int type): _type(type){}
					int type() const { return _type; }
					virtual int update(ParamPtr& param, ArgPtr arg = ArgPtr()) = 0;
					virtual int init(int nation, ParamPtr& param) = 0;

				private:
					int _type;
			};

			SHAREPTR(ICheck2, CheckPtr2);

			class NationTask
				: public _auto_meta
			{
				public:
					int id();
					int state();

					void getInfo(qValue& q) const;
					void update(ArgPtr& arg);
					void reset();

				private:
					virtual bool _auto_save();

				private:
					int _id;
					int _nation;
					int _state;
					ParamPtr _param;
					CheckPtr2 _checker;
			};

			SHAREPTR(NationTask, NationTaskPtr);

			class NationTaskMgr
			{
				public:
					static NationTaskMgr& shared()
					{
						static NationTaskMgr task_mgr;
						return task_mgr;
					}

					NationTaskMgr();

					void update(int nation, ArgPtr arg = ArgPtr());
					void getInfo(int nation, qValue& q);
					void reset();
					void addTimer();

				private:
					STDVECTOR(NationTaskPtr, NationTasks);
					NationTasks _nation_tasks;
			};
		}
		
		struct Event
		{
			enum Type
			{
				Occupy,
				GetExploit,
				TimeOut,

			} type;

			union 
			{
				struct 
				{
					int nation;
					int id;
				} occupy;

				struct
				{
					int nation;
					int num;
				} exploit;

			} args;
		};

		class NationTask
			: public _auto_meta
		{
			public:
				void update(const Event& e);

			private:
				bool _auto_save();

			private:
				int _nation;
				struct Record
				{
					int type;
					int value;
					int state;
				};
				Record _record;
		};

		SHAREPTR(NationTask, NationTaskPtr);

		class NationTaskMgr
		{
			public:
				void updata(const Event& e)
				{
					ForEach(NationTasks, it, _nation_task)
						(*it)->update(e);
				}

				void getInfo(qValue& q, int nation)
				{
					_nation_task[nation]->getInfo(q);
				}

				const ACTION::BoxList& getReward(int nation)
				{
					if (
					return _null;
				}
			private:
				static ACTION::BoxList _null;

				STDVECTOR(NationTaskPtr, NationTasks);
				NationTasks _nation_task;
		};
	}
}

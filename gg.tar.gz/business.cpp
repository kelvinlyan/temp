#include "business.h"
#include "zip_file.hpp"
#include "battle_helper.hpp"
#include "chat.h"
//#include "kingdom.h"
#include "kingdom_system.h"
#include "task_mgr.h"

namespace gg
{
	const static unsigned systemUseLimit = 31;

	const static int SilverKeyID = 50005;//��Կ��
	const static int GoldKeyID = 50006;//��Կ��
	const static int CarMaterialID = 50007;//�̴�����
	//50002 fangshui 50003 weishe 50004 yijia
	const static int FangShuiID = 50002;
	const static int WeiSheID = 50003;
	const static int YiJiaID = 50004;
	struct TBstruct
	{
		TBstruct()
		{
			_id_buff = TradeBuff::null;
			_duration = 0;
		}
		TBstruct(const TradeBuff::ID _id, const unsigned _d)
		{
			_id_buff = _id;
			_duration = _d;
		}
		TradeBuff::ID _id_buff;
		unsigned _duration;
	};
	static std::map<int, TBstruct> BuffDoMap;
	TBstruct getBindBuff(const int ID)
	{
		std::map<int, TBstruct>::iterator it = BuffDoMap.find(ID);
		if (it == BuffDoMap.end())return TBstruct();
		return it->second;
	}

	const static int ShunYiID = 50001;
	


	static unsigned CityEventNum = 3;//�����¼�����//һ������1���¼� �¼�ֻ��1��
	static unsigned MapHaiDaoEvent[2] = {5, 10};//��ͼ�����¼�
	static unsigned MapSilverBoxEvent[2] = {5, 10};//��ͼ������
	static unsigned MapGoldBoxEvent[2] = { 5, 10 };//��ͼ����

	business* const business::_Instance = new business();
	static vector< vector< bool > > MapData;
	static boost::unordered_map<int, int> cityEvnMap;
	static vector<int> cityIDList;
	static zipFile tradeFile;//ó���ļ�д����
	static unsigned richTickTime = 0;

	struct AreaRange
	{
		int areaID;
		unsigned left_x;
		unsigned left_y;
		unsigned right_x;
		unsigned right_y;
	};
	UNORDERMAP(int, AreaRange, CityRangeMap);
	static CityRangeMap CitiesRange;//���з�Χ
	bool validCityRange(const int cityID, const unsigned x, const unsigned y)
	{
		CityRangeMap::iterator it = CitiesRange.find(cityID);
		if (it == CitiesRange.end())return false;
		const AreaRange& range = it->second;
		return (x >= range.left_x && x <= range.right_x && y >= range.left_y && y <= range.right_y);
	}

	struct _info
	{
		_info()
		{
			alive = true;
		}
		int playerID;
		string playerName;
		Kingdom::NATION playerNation;
		unsigned cpos_x;//��ǰλ��
		unsigned cpos_y;//��ǰλ��
		unsigned aim_x;
		unsigned aim_y;
		double speed;
		unsigned level;//��ֻ�ȼ�
		unsigned mode;//·��ģʽ
		bool alive;
		qValue toJson()
		{
			qValue json(qJson::qj_array);
			json.append(playerID);
			json.append(playerName);
			json.append(playerNation);
			json.append(cpos_x);
			json.append(cpos_y);
			json.append(aim_x);
			json.append(aim_y);
			json.append(speed);
			json.append(level);
			json.append(mode);
			return json;
		}
	};
	SHAREPTR(_info, _info_ptr);
	UNORDERMAP(int, _info_ptr, _brPlayerMap);
	static _brPlayerMap _brPlayers;//�������
	_info_ptr getBRPlayer(const int playerID)
	{
		_brPlayerMap::iterator it = _brPlayers.find(playerID);
		if (it == _brPlayers.end())return _info_ptr();
		return it->second;
	}
// 	struct _info_key
// 	{
// 		std::size_t operator()(const _info_ptr& key)const
// 		{
// 			std::size_t seed = 0;
// 			boost::hash_combine(seed, boost::hash_value(key->playerID));
// 			return seed;
// 		}
// 	};
// 	typedef boost::unordered_set<_info_ptr, _info_key> TICKSET;
	typedef boost::unordered_set<_info_ptr> TICKSET;
	struct BeaconRange :
		public AreaRange
	{
		typedef TICKSET AreasData;
		AreasData areas;
		AreasData::iterator index;
		bool validRange(const unsigned x, const unsigned y)
		{
			return (x >= left_x && x <= right_x && y >= left_y && y <= right_y);
		}
		BeaconRange()
		{
			areas.clear();
			index = areas.end();
		}
		inline void insert(const _info_ptr info)
		{
			areas.insert(info);
		}
		qValue Package(const unsigned num)
		{
			qValue json_array(qJson::qj_array);
			unsigned loop = std::min(num, (unsigned)areas.size());
			unsigned invalid_num = 0;
			for (unsigned i = 0; i < loop; ++i)
			{
				if (index == areas.end())
				{
					index = areas.begin();
				}
				_info_ptr info = *index;
				++index;
				if (!info->alive || !validRange(info->cpos_x, info->cpos_y))
				{
					areas.erase(info);
					--i;
					loop = std::min(num, (unsigned)areas.size());
					continue;
				}
				json_array.append(info->toJson());
			}
			return json_array;
		}
	};
	SHAREPTR(BeaconRange, _brRangePtr);
	UNORDERMAP(int, _brRangePtr, _brRangeMap);
	static _brRangeMap brRangeMap;//����㲥��Χ
	_brRangePtr getBeacon(const int areaID)
	{
		_brRangeMap::iterator it = brRangeMap.find(areaID);
		if (it == brRangeMap.end())return _brRangePtr();
		return it->second;
	}

	template<typename TYPE>
	struct DisPart
	{
		DisPart()
		{
			m_limit = 0;
			m_DisParts.clear();
		}
		unsigned m_limit;
		typedef std::vector<TYPE> ListType;
		ListType m_DisParts;//�����б�
	};
	typedef DisPart<_brRangePtr> BeaconUnit;//��Ԫ
	typedef DisPart< BeaconUnit > BeaconPart;//x����
	typedef std::vector< BeaconPart > BeaconCollect;//����
	static BeaconCollect staticBeacons;
	void insertDisPart(_info_ptr who)
	{
		const unsigned x = who->cpos_x;
		const unsigned y = who->cpos_y;
		unsigned left = 0;
		unsigned right = staticBeacons.size() - 1;
		if (left >= staticBeacons.size() || right >= staticBeacons.size())return;
		while (left <= right)
		{
			unsigned idx = (left + right) / 2;
			const BeaconPart& disp = staticBeacons[idx];
			if (x >= disp.m_limit)
			{
				right = idx;
			}
			else
			{
				left = idx;
			}
			if (right - left <= 1)
			{
				const BeaconPart::ListType* disp_pointer = NULL;
				if (x >= staticBeacons[left].m_limit)disp_pointer = &staticBeacons[left].m_DisParts;
				else if (x >= staticBeacons[right].m_limit)disp_pointer = &staticBeacons[right].m_DisParts;
				if (disp_pointer != NULL)
				{
					const BeaconPart::ListType& disp_inter = *disp_pointer;
					unsigned left_inter = 0;
					unsigned right_inter = disp_inter.size() - 1;
					if (left_inter >= disp_inter.size() || right_inter >= disp_inter.size())break;
					while (left_inter <= right_inter)
					{
						unsigned idx_inter = (left_inter + right_inter) / 2;
						const BeaconUnit& disp = disp_inter[idx_inter];
						if (y >= disp.m_limit)
						{
							right_inter = idx_inter;
						}
						else
						{
							left_inter = idx_inter;
						}
						if (right_inter - left_inter <= 1)
						{
							const BeaconUnit* unit_pointer = NULL;
							if (y >= disp_inter[left_inter].m_limit)unit_pointer = &disp_inter[left_inter];
							else if (y >= disp_inter[right_inter].m_limit)unit_pointer = &disp_inter[right_inter];
							if (unit_pointer != NULL)
							{
								const BeaconUnit::ListType& unit_list = unit_pointer->m_DisParts;
								for (unsigned i = 0; i < unit_list.size(); ++i)
								{
									_brRangePtr br = unit_list[i];
									br->insert(who);
								}
							}
							break;
						}
					}
				}
				break;
			}
		}
	}

	//�������
	static TICKSET AreaTick;//������Ԥ������

	struct MapCoor
	{
		MapCoor()
		{
			x = 0;
			y = 0;
		}
		MapCoor(const unsigned _x, const unsigned _y)
		{
			x = _x;
			y = _y;
		}
		unsigned x;
		unsigned y;
	};

	//����Ⱥ����
	struct Shark :
		public MapCoor
	{
		Shark() :MapCoor(){}
		Shark(const unsigned _x, const unsigned _y) :MapCoor(_x, _y){}
		bool operator <(const Shark& other)const
		{
			if (x != other.x)return x < other.x;
			return y < other.y;
		}
	};
	STDSET(Shark, SharkPos);
	static SharkPos staticShark;
	bool business::inSharkArea(const unsigned x, const unsigned y)
	{
		return (staticShark.find(Shark(x, y)) != staticShark.end());
	}

	//���������¼��ĵ�ͼ����
	namespace MapEvnet
	{
		enum Type
		{
			null,
			haidao,
			silver_box,
			gold_box,
		};
	}
	struct EventPos :
		public MapCoor
	{
		EventPos() : MapCoor(){}
		EventPos(const unsigned _x, const unsigned _y) :MapCoor(_x, _y){}
		bool operator <(const EventPos& other)const
		{
			if (x != other.x)return x < other.x;
			return y < other.y;
		}
	};
	static vector< EventPos > EventCoor;
	STDMAP(EventPos, MapEvnet::Type, EvnetMap);
	static EvnetMap Events;
	MapEvnet::Type getMapEvent(const unsigned x, const unsigned y)
	{
		EvnetMap::iterator it = Events.find(EventPos(x, y));
		if (it == Events.end())return MapEvnet::null;
		return it->second;
	}
	void removeMapEvent(const unsigned x, const unsigned y)
	{
		Events.erase(EventPos(x, y));
	}

	//����˲�Ƶ�����
	struct TelePos :
		public MapCoor
	{
		TelePos() : MapCoor(){}
		TelePos(const unsigned _x, const unsigned _y) :MapCoor(_x, _y){}
		bool operator <(const TelePos& other)const
		{
			if (x != other.x)return x < other.x;
			return y < other.y;
		}
	};
	STDSET(TelePos, TeleSet);
	TeleSet Teles;
	bool availableTeleport(const unsigned x, const unsigned y)
	{
		return Teles.find(TelePos(x, y)) != Teles.end();
	}

	//������
	struct richData
	{
		richData()
		{
			playerID = -1;
			playerName = "";
			tradeTimes = 0;
			money = 0;
			kingdom = Kingdom::null;
		}
		richData(playerDataPtr player, const int m)
		{
			playerID = player->ID();
			playerName = player->Name();
			kingdom = player->Info->Nation();
			tradeTimes = player->Trade->totalTask();
			money = m;
		}
		Json::Value toJSON()
		{
			Json::Value json;
			json["i"] = playerID;
			json["n"] = playerName;
			json["t"] = tradeTimes;
			json["m"] = money;
			json["k"] = kingdom;
			return json;
		}
		mongo::BSONObj toBSON()
		{
			return BSON("i" << playerID << "n" << playerName << 
				"t" << tradeTimes << "k" << kingdom << "m" << money);
		}
		int playerID;
		string playerName;
		unsigned tradeTimes;
		int money;
		Kingdom::NATION kingdom;
	};
	SHAREPTR(richData, richPtr);
	static vector<richPtr> dayRich, historyRich, totalRich;
	UNORDERMAP(int, richPtr, richMap);
	static richMap dayRichMap, historyRichMap, totalRichMap;

	//������Ʒ����
	struct CityData
	{
		int cityID;
		struct Wares //��Ʒ
		{
			Wares()
			{
				price = 0;
				history.clear();
			}
			int price;//��ǰ�۸�
			int wareID;//��ƷID
			int upPrice;//�ۼ�����
			int lowPrice;//�ۼ�����
			int upPriceF;//�ۼ۸�������
			int lowPriceF;//�ۼ۸�������
			vector<int> history;//��ʷ�۸�
			qValue toHisJson()
			{
				qValue json(qJson::qj_object), data_json(qJson::qj_array);
				json.addMember("id", wareID);
				for (unsigned i = 0; i < history.size(); ++i)
				{
					data_json.append(history[i]);
				}
				json.addMember("p", data_json);
				return json;
			}
			qValue toJson()
			{
				qValue json(qJson::qj_object);
				json.addMember("id", wareID);
				json.addMember("pr", price);
				return json;
			}
		};
		qValue toJson()
		{
			qValue json(qJson::qj_object);
			json.addMember("id", cityID);
			qValue sj(qJson::qj_array), bj(qJson::qj_array);;
			for (wareMap::iterator it = PawnMap.begin(); it != PawnMap.end(); ++it)
			{
				sj.append(it->second->toJson());
			}
			json.addMember("s", sj);
			for (wareMap::iterator it = ShopMap.begin(); it != ShopMap.end(); ++it)
			{
				bj.append(it->second->toJson());
			}
			json.addMember("b", bj);
			return json;
		}
		SHAREPTR(Wares, warePtr);
		UNORDERMAP(int, warePtr, wareMap);
		wareMap PawnMap, ShopMap;//������Ʒ�б�, ������Ʒ�б�
		warePtr saleWare(const int wareID)
		{
			wareMap::iterator it = ShopMap.find(wareID);
			if (it == ShopMap.end())return warePtr();
			return it->second;
		}
		warePtr pawnWare(const int wareID)
		{
			wareMap::iterator it = PawnMap.find(wareID);
			if (it == PawnMap.end())return warePtr();
			return it->second;
		}
	};
	SHAREPTR(CityData, cityPtr);
	UNORDERMAP(int, cityPtr, cityMap);
	static cityMap Cities;

	//����
	struct MapBox
	{
		unsigned LevelLimit;
		acPtrList BoxReward;
	};
	bool GreaterMapBox(const MapBox& left, const MapBox& right)
	{
		return left.LevelLimit > right.LevelLimit;
	}
	static vector<MapBox> SilverBox, GoldBox;

	//����
	struct Pirate
	{
		Pirate()
		{
			LevelLimit = 0;
			npcLevel = 0;
			battleValue = 0;
			background = -1;
			npcName = "bug";
			npcList.clear();
		}
		unsigned LevelLimit;
		unsigned npcLevel;
		int battleValue;
		int background;
		string npcName;
		int npcFace;
		struct armyNPC
		{
			armyNPC()
			{
				memset(this, 0x0, sizeof(armyNPC));
			}
			int npcID;
			bool holdMorale;
			int initAttri[characterNum];
			//int addAttri[characterNum];
			int armsType;
			double armsModule[armsModulesNum];
			int npcLevel;
			unsigned npcPos;
			int battleValue;
			int skill_1;
			int skill_2;
			BattleEquipList equipList;
		};
		vector< vector< armyNPC > > npcList;		//�����б�
		vector< acPtrList > rewardList;//�����б�
	};
	static bool less_pirate(const Pirate& left, const Pirate& right)
	{
		return left.LevelLimit > right.LevelLimit;
	}
	static vector<Pirate> PirateBox;
	

	void business::initData()
	{
		cout << "load business ..." << endl;
		{
			std::map<unsigned, Pirate> tmpPirateBox;
			PirateBox.clear();
			Json::Value json = Common::loadJsonFile("./instance/business/pirate.json");
			for (unsigned i = 0; i < json.size(); ++i)
			{
				Json::Value& pirateJson = json[i];
				const unsigned llimit = pirateJson["limit"].asUInt();
				Pirate pi = tmpPirateBox[llimit];
				pi.LevelLimit = llimit;
				pi.npcName = pirateJson["name"].asString();
				pi.npcFace = pirateJson["face"].asInt();
				pi.npcLevel = pirateJson["level"].asUInt();
				pi.background = pirateJson.isMember("background") ? pirateJson["background"].asInt() : 1;
				pi.battleValue = pirateJson["battleValue"].asInt();
				vector< Pirate::armyNPC > npcl;
				for (unsigned n = 0; n < pirateJson["army"].size(); ++n)
				{
					Pirate::armyNPC npc;
					Json::Value& sg_npc = pirateJson["army"][n];
					npc.npcID = sg_npc["npcID"].asInt();
					npc.holdMorale = sg_npc["holdMorale"].asBool();
					for (unsigned cn = 0; cn < characterNum; ++cn)
					{
						npc.initAttri[cn] = sg_npc["initAttri"][cn].asInt();
						//npc.addAttri[cn] = sg_npc["addAttri"][cn].asInt();
					}
					npc.armsType = sg_npc["armsType"].asInt();
					for (unsigned cn = 0; cn < armsModulesNum; ++cn)
					{
						npc.armsModule[cn] = sg_npc["armsModule"][cn].asDouble();
					}
					npc.npcLevel = sg_npc["npcLevel"].asInt();
					npc.npcPos = sg_npc["npcPos"].asUInt() % 9;
					npc.battleValue = sg_npc["battleValue"].asInt();
					npc.skill_1 = sg_npc["skill_1"].asInt();
					npc.skill_2 = sg_npc["skill_2"].asInt();
					for (unsigned eq_idx = 0; eq_idx < sg_npc["equip"].size(); ++eq_idx)
					{
						npc.equipList.push_back(BattleEquip(sg_npc["equip"][eq_idx][0u].asUInt(), 
							sg_npc["equip"][eq_idx][1u].asInt(), 
							sg_npc["equip"][eq_idx][2u].asUInt()));
					}
					npcl.push_back(npc);
				}
				pi.npcList.push_back(npcl);
				const unsigned rwJsonID = pirateJson["box"].asUInt();
				pi.rewardList.push_back(actionFormat(rwJsonID));
				tmpPirateBox[pi.LevelLimit] = pi;
			}
			for (std::map<unsigned, Pirate>::iterator it = tmpPirateBox.begin(); it != tmpPirateBox.end(); ++it)
			{
				PirateBox.push_back(it->second);
			}
			std::sort(PirateBox.begin(), PirateBox.end(), less_pirate);
		};//����
		{
			SilverBox.clear();
			Json::Value json = Common::loadJsonFile("./instance/business/silver_box.json");
			for (unsigned i = 0; i < json.size(); ++i)
			{
				Json::Value& boxJson = json[i];
				MapBox box;
				box.LevelLimit = boxJson["limit"].asUInt();
// 				Json::Value& reward = boxJson["box"];
// 				box.BoxReward = actionFormat(reward);
				const unsigned rewardID = boxJson["box"].asUInt();
				box.BoxReward = actionFormat(rewardID);
				SilverBox.push_back(box);
			}
			std::sort(SilverBox.begin(), SilverBox.end(), GreaterMapBox);
		};//������
		{
			GoldBox.clear();
			Json::Value json = Common::loadJsonFile("./instance/business/gold_box.json");
			for (unsigned i = 0; i < json.size(); ++i)
			{
				Json::Value& boxJson = json[i];
				MapBox box;
				box.LevelLimit = boxJson["limit"].asUInt();
// 				Json::Value& reward = boxJson["box"];
// 				box.BoxReward = actionFormat(reward);
				const unsigned rewardID = boxJson["box"].asUInt();
				box.BoxReward = actionFormat(rewardID);
				GoldBox.push_back(box);
			}
			std::sort(GoldBox.begin(), GoldBox.end(), GreaterMapBox);
		};//����
		{
			BuffDoMap[FangShuiID] = TBstruct(TradeBuff::fangshui, 60 * MINUTE);
			BuffDoMap[WeiSheID] = TBstruct(TradeBuff::weishe, 60 * MINUTE);
			BuffDoMap[YiJiaID] = TBstruct(TradeBuff::yijia, 30 * MINUTE);
		};//buff�¼�
		//��ʼ����ص������ļ�
		{
			playerTrade::initData();
		};
		{
			Common::createDirectories("./report/business/rich/");//����Ϣ
			Common::createDirectories("./report/business/city/");//������Ϣ
		};//�����ļ���
		{
			Json::Value json = Common::loadJsonFile("./instance/business/event.json");
			CityEventNum = json["city"].asUInt();
			MapHaiDaoEvent[0] = json["haidao"][0u].asUInt();
			MapHaiDaoEvent[1] = json["haidao"][1u].asUInt();
			MapSilverBoxEvent[0] = json["silver_box"][0u].asUInt();
			MapSilverBoxEvent[1] = json["silver_box"][1u].asUInt();
			MapSilverBoxEvent[0] = json["gold_box"][0u].asUInt();
			MapSilverBoxEvent[1] = json["gold_box"][1u].asUInt();
		};//�¼���ʼ��

		{
			staticShark.clear();
			Json::Value json = Common::loadJsonFile("./instance/business/shark.json");
			for (unsigned i = 0; i < json.size(); ++i)
			{
				Json::Value& cityJson = json[i];
				Shark sp;
				sp.x = cityJson["x"].asUInt();
				sp.y = cityJson["y"].asUInt();
				staticShark.insert(sp);
			}
		};//��������

		{
			MapData.clear();
			EventCoor.clear();
			Events.clear();
			Json::Value json = Common::loadJsonFile("./instance/business/map.json");
			const unsigned data_length = json[0u].size();
			const unsigned data_high = json.size();
			for (unsigned y = 0; y < data_length; ++y)
			{
				vector< bool > vec;
				for (unsigned x = data_high - 1; x < data_high; --x)
				{
					const bool pass = (json[x][y].asInt() != 0);
					vec.push_back(pass);
				}
				MapData.push_back(vec);
			}
			for (unsigned x = 0; x < MapData.size(); ++x)
			{
				const vector< bool >& vec = MapData[x];
				for (unsigned y = 0; y < vec.size(); ++y)
				{
					if (vec[y] && !inSharkArea(x,y))EventCoor.push_back(EventPos(x, y));
				}
			}
		};//��ͼ��Ϣ

		{
			CitiesRange.clear();
			Json::Value json = Common::loadJsonFile("./instance/business/city_range.json");
			for (unsigned i = 0; i < json.size(); ++i)
			{
				Json::Value& cityJson = json[i];
				AreaRange range;
				range.areaID = cityJson["cityID"].asInt();
				range.left_x = cityJson["left_x"].asUInt();
				range.left_y = cityJson["left_y"].asUInt();
				range.right_x = cityJson["right_x"].asUInt();
				range.right_y = cityJson["right_y"].asUInt();
				CitiesRange[range.areaID] = range;
			}
		};//��ͼ�������귶Χ

		{
			brRangeMap.clear();
			Json::Value json = Common::loadJsonFile("./instance/business/beacon.json");
			for (unsigned i = 0; i < json.size(); ++i)
			{
				Json::Value& cityJson = json[i];
				_brRangePtr range = Creator<BeaconRange>::Create();
				range->areaID = cityJson["areaID"].asInt();
				range->left_x = cityJson["left_x"].asUInt();
				range->left_y = cityJson["left_y"].asUInt();
				range->right_x = cityJson["right_x"].asUInt();
				range->right_y = cityJson["right_y"].asUInt();
				brRangeMap[range->areaID] = range;
			}
		}; //����㲥
		{
			staticBeacons.clear();
			Json::Value json = Common::loadJsonFile("./instance/business/beacon_area.json");
			for (unsigned i = 0; i < json.size(); ++i)
			{
				Json::Value& cityJson = json[i];
				BeaconPart part;
				const unsigned limit = cityJson["limit"].asUInt();
				part.m_limit = limit;
				Json::Value& data_list = cityJson["data"];
				for (unsigned n = 0; n < data_list.size(); ++n)
				{
					Json::Value& sg_data = data_list[n];
					const unsigned inter_limit = sg_data["inter_limit"].asUInt();
					BeaconUnit tmp_unit;
					tmp_unit.m_limit = inter_limit;
					Json::Value& inter_data = sg_data["inter_data"];
					for (unsigned idx = 0; idx < inter_data.size(); ++idx)
					{
						_brRangePtr br = getBeacon(inter_data[idx].asInt());
						if (br)tmp_unit.m_DisParts.push_back(br);
					}
					part.m_DisParts.push_back(tmp_unit);
				}
				staticBeacons.push_back(part);
			}
		};//����㲥����

		{
			Teles.clear();
			Json::Value json = Common::loadJsonFile("./instance/business/teleport.json");
			for (unsigned i = 0; i < json.size(); ++i)
			{
				Json::Value& teleJson = json[i];
				TelePos tp;
				tp.x = teleJson["x"].asUInt();
				tp.y = teleJson["y"].asUInt();
				Teles.insert(tp);
			}
		};//����˲�Ƶ�����

		{
			Json::Value json = Common::loadJsonFile("./instance/business/city.json");
			for (unsigned i = 0; i < json.size(); ++i)
			{
				Json::Value& city_json = json[i];
				cityPtr city = Creator<CityData>::Create();
				city->cityID = city_json["id"].asInt();
				for (unsigned n = 0; n < city_json["buy"].size(); ++n)
				{
					Json::Value& ware_json = city_json["buy"][n];
					CityData::warePtr ware = Creator<CityData::Wares>::Create();
					ware->wareID = ware_json["wareID"].asInt();
					ware->lowPrice = ware_json["lowPrice"].asInt();
					ware->upPrice = ware_json["upPrice"].asInt();
					ware->lowPriceF = ware_json["lowPriceF"].asInt();
					ware->upPriceF = ware_json["upPriceF"].asInt();
					city->ShopMap[ware->wareID] = ware;
				}
				for (unsigned n = 0; n < city_json["sale"].size(); ++n)
				{
					Json::Value& ware_json = city_json["sale"][n];
					CityData::warePtr ware = Creator<CityData::Wares>::Create();
					ware->wareID = ware_json["wareID"].asInt();
					ware->lowPrice = ware_json["lowPrice"].asInt();
					ware->upPrice = ware_json["upPrice"].asInt();
					ware->lowPriceF = ware_json["lowPriceF"].asInt();
					ware->upPriceF = ware_json["upPriceF"].asInt();
					city->PawnMap[ware->wareID] = ware;
				}
				Cities[city->cityID] = city;
			}
			for (cityMap::const_iterator it = Cities.begin(); it != Cities.end(); ++it)
			{
				cityIDList.push_back(it->first);
			}
			for (cityMap::iterator it = Cities.begin(); it != Cities.end(); ++it)
			{
				cityPtr city = it->second;
				const string file_name = "./report/business/city/" + Common::toString(it->first);
				Json::Value json = tradeFile.read_json(file_name);
				if (json.isNull())//�ļ�Ϊ��, ��ô�������ɼ۸�
				{
					qValue write_json(qJson::qj_object), buy_json(qJson::qj_array), sale_json(qJson::qj_array);
					for (CityData::wareMap::iterator wit = city->ShopMap.begin(); wit != city->ShopMap.end(); ++wit)
					{
						CityData::warePtr ware = wit->second;
						ware->price = Common::randomBetween(ware->lowPrice, ware->upPrice);
						ware->history.push_back(ware->price);
						buy_json.append(ware->toHisJson());
					}
					for (CityData::wareMap::iterator wit = city->PawnMap.begin(); wit != city->PawnMap.end(); ++wit)
					{
						CityData::warePtr ware = wit->second;
						ware->price = Common::randomBetween(ware->lowPrice, ware->upPrice);
						ware->history.push_back(ware->price);
						sale_json.append(ware->toHisJson());
					}
					write_json.addMember("b", buy_json);
					write_json.addMember("s", sale_json);
					tradeFile.write(file_name, write_json);
					continue;
				}
				for (unsigned i = 0; i < json["b"].size(); ++i)
				{
					Json::Value& item_json = json["b"][i];
					CityData::wareMap::iterator wit = city->ShopMap.find(item_json["id"].asInt());
					if (wit == city->ShopMap.end())continue;
					CityData::warePtr ware = wit->second;
					for (unsigned n = 0; n < item_json["p"].size(); ++n)
					{
						ware->history.push_back(item_json["p"][n].asInt());
					}
					ware->price = ware->history.back();
				}
				for (unsigned i = 0; i < json["s"].size(); ++i)
				{
					Json::Value& item_json = json["s"][i];
					CityData::wareMap::iterator wit = city->PawnMap.find(item_json["id"].asInt());
					if (wit == city->PawnMap.end())continue;
					CityData::warePtr ware = wit->second;
					for (unsigned n = 0; n < item_json["p"].size(); ++n)
					{
						ware->history.push_back(item_json["p"][n].asInt());
					}
					ware->price = ware->history.back();
				}
				for (CityData::wareMap::iterator wit = city->ShopMap.begin(); wit != city->ShopMap.end(); ++wit)
				{
					CityData::warePtr ware = wit->second;
					if (ware->history.empty())
					{
						ware->price = Common::randomBetween(ware->lowPrice, ware->upPrice);
						ware->history.push_back(ware->price);
					}
				}
				for (CityData::wareMap::iterator wit = city->PawnMap.begin(); wit != city->PawnMap.end(); ++wit)
				{
					CityData::warePtr ware = wit->second;
					if (ware->history.empty())
					{
						ware->price = Common::randomBetween(ware->lowPrice, ware->upPrice);
						ware->history.push_back(ware->price);
					}
				}
			}
		};//������Ϣ

		{
			//���յ�Ʊ
			{
				dayRich.clear();
				dayRichMap.clear();
				mongo::BSONObj key = BSON("key" << 1);
				mongo::BSONObj obj = db_mgr.FindOne(DBN::dbPlayerTradeRich, key);
				if (!obj.isEmpty())
				{
					vector<mongo::BSONElement> vec = obj["r"].Array();
					for (unsigned i = 0; i < vec.size(); ++i)
					{
						mongo::BSONElement& elem = vec[i];
						richPtr rich = Creator<richData>::Create();
						rich->playerID = elem["i"].Int();
						rich->playerName = elem["n"].String();
						rich->tradeTimes = (unsigned)elem["t"].Int();
						rich->money = elem["m"].Int();
						rich->kingdom = (Kingdom::NATION)elem["k"].Int();
						dayRich.push_back(rich);
						dayRichMap[rich->playerID] = rich;
					}
				}
			};
			//��ʷ��Ʊ
			{
				historyRich.clear();
				historyRichMap.clear();
				mongo::BSONObj key = BSON("key" << 2);
				mongo::BSONObj obj = db_mgr.FindOne(DBN::dbPlayerTradeRich, key);
				if (!obj.isEmpty())
				{
					vector<mongo::BSONElement> vec = obj["r"].Array();
					for (unsigned i = 0; i < vec.size(); ++i)
					{
						mongo::BSONElement& elem = vec[i];
						richPtr rich = Creator<richData>::Create();
						rich->playerID = elem["i"].Int();
						rich->playerName = elem["n"].String();
						rich->tradeTimes = (unsigned)elem["t"].Int();
						rich->money = elem["m"].Int();
						rich->kingdom = (Kingdom::NATION)elem["k"].Int();
						historyRich.push_back(rich);
						historyRichMap[rich->playerID] = rich;
					}
				}
			};
			//��ʷ�ܰ�
			{
				totalRich.clear();
				totalRichMap.clear();
				mongo::BSONObj key = BSON("key" << 3);
				mongo::BSONObj obj = db_mgr.FindOne(DBN::dbPlayerTradeRich, key);
				if (!obj.isEmpty())
				{
					vector<mongo::BSONElement> vec = obj["r"].Array();
					for (unsigned i = 0; i < vec.size(); ++i)
					{
						mongo::BSONElement& elem = vec[i];
						richPtr rich = Creator<richData>::Create();
						rich->playerID = elem["i"].Int();
						rich->playerName = elem["n"].String();
						rich->tradeTimes = (unsigned)elem["t"].Int();
						rich->money = elem["m"].Int();
						rich->kingdom = (Kingdom::NATION)elem["k"].Int();
						totalRich.push_back(rich);
						totalRichMap[rich->playerID] = rich;
					}
				}
			};
			//timer
			{
				richTickTime = Common::timeZero(Common::gameTime()) + DAY;
				mongo::BSONObj key = BSON("key" << 4);
				mongo::BSONObj obj = db_mgr.FindOne(DBN::dbPlayerTradeRich, key);
				if (!obj.isEmpty())
				{
					richTickTime = (unsigned)obj["tt"].Int();
				}
				else
				{
					saveTimerRich();
				}
			};
		};//���������ݶ�ȡ//���ݿ�

		//�׳���ʱ��
		{
			const unsigned now = Common::gameTime();
			const tm tm_now = Common::toTm(now);
			const unsigned tick_price = now - tm_now.tm_sec - (tm_now.tm_min % 10) * MINUTE + 10 * MINUTE;
			Timer::AddEventPerTimeCT(boostBind(business::cityPriceTick, this, _1), Inter::event_city_price_timer, tick_price, 10 * MINUTE);
			const unsigned tick_city = now - tm_now.tm_sec - tm_now.tm_min * MINUTE + (tm_now.tm_min >= 30 ? MINUTE * 30 : 0);
			Timer::AddEventPerTimeCT(boostBind(business::cityEventTick, this, _1), Inter::event_city_event_timer, tick_city, 30 * MINUTE);
			const unsigned tick_event = now - tm_now.tm_sec - tm_now.tm_min * MINUTE;
			Timer::AddEventPerTimeCT(boostBind(business::mapEventTick, this, _1), Inter::event_map_event_timer, tick_event, HOUR);
			Timer::AddEventTickTime(boostBind(business::richTick, this, _1), Inter::event_rich_event_timer, richTickTime);//�����¼�
			Timer::AddEventPerTimeCT(boostBind(business::areaTick, this, _1), Inter::event_trade_area_timer, now, 3);
		};//��ʱ���趨����
	}

	void business::cityPriceTick(const structTimer& timerData)
	{
		for (cityMap::iterator it = Cities.begin(); it != Cities.end(); ++it)
		{
			cityPtr city = it->second;
			const string file_name = "./report/business/city/" + Common::toString(it->first);
			qValue write_json(qJson::qj_object), buy_json(qJson::qj_array), sale_json(qJson::qj_array);
			for (CityData::wareMap::iterator wit = city->ShopMap.begin(); wit != city->ShopMap.end(); ++wit)
			{
				CityData::warePtr ware = wit->second;
				int alter_price = Common::randomBetween(ware->lowPriceF, ware->upPriceF);
				if (Common::randomOk(0.5))alter_price = -alter_price;
				int final_price = ware->price + alter_price;
				if (final_price <= ware->upPrice && final_price >= ware->lowPrice)
				{
					ware->price = final_price;
				}
				else
				{
					final_price = ware->price - alter_price;
					if (final_price <= ware->upPrice && final_price >= ware->lowPrice)
					{
						ware->price = final_price;
					}
					else
					{
						ware->price = Common::randomBetween(ware->lowPrice, ware->upPrice);
					}
				}
				ware->history.push_back(ware->price);
				if (ware->history.size() > 100)ware->history.erase(ware->history.begin());
				buy_json.append(ware->toHisJson());
			}
			for (CityData::wareMap::iterator wit = city->PawnMap.begin(); wit != city->PawnMap.end(); ++wit)
			{
				CityData::warePtr ware = wit->second;
				int alter_price = Common::randomBetween(ware->lowPriceF, ware->upPriceF);
				if (Common::randomOk(0.5))alter_price = -alter_price;
				int final_price = ware->price + alter_price;
				if (final_price <= ware->upPrice && final_price >= ware->lowPrice)
				{
					ware->price = final_price;
				}
				else
				{
					final_price = ware->price - alter_price;
					if (final_price <= ware->upPrice && final_price >= ware->lowPrice)
					{
						ware->price = final_price;
					}
					else
					{
						ware->price = Common::randomBetween(ware->lowPrice, ware->upPrice);
					}
				}
				ware->history.push_back(ware->price);
				if (ware->history.size() > 100)ware->history.erase(ware->history.begin());
				sale_json.append(ware->toHisJson());
			}
			write_json.addMember("b", buy_json);
			write_json.addMember("s", sale_json);
			tradeFile.async_write(file_name, write_json);
		}
	}

	const static int cityRate[4] = {-5, -3, 3, 5};
	void business::cityEventTick(const structTimer& timerData)
	{
		cityEvnMap.clear();
		vector<int> vec = cityIDList;
		for (unsigned i = 0; i < CityEventNum; ++i)
		{
			if (vec.empty())continue;
			unsigned idx = (unsigned)Common::randomBetween(0, vec.size() - 1);
			cityEvnMap[vec[idx]] = cityRate[Common::randomBetween(0, 3)];
			vec.erase(vec.begin() + idx);
		}
	}

	void business::mapEventTick(const structTimer& timerData)
	{
		const unsigned pirate_num = Common::randomBetween(MapHaiDaoEvent[0], MapHaiDaoEvent[1]);
		const unsigned silver_box_num = Common::randomBetween(MapSilverBoxEvent[0], MapSilverBoxEvent[1]);
		const unsigned gold_box_num = Common::randomBetween(MapGoldBoxEvent[0], MapGoldBoxEvent[1]);
//		LogS << "pirate " << pirate_num << "\tsilver_box " << silver_box_num << "\tgold_box " << gold_box_num << LogEnd;
		Events.clear();//�¼����
		random_shuffle(EventCoor.begin(), EventCoor.end());
//		LogS << EventCoor.size() << LogEnd;
		unsigned begin_idx = 0;
		unsigned num = 0;
//		LogS << "begin_idx " << begin_idx << LogEnd;
		for (unsigned i = begin_idx; i < EventCoor.size() && num < pirate_num; ++i, ++num)
		{
			Events[EventCoor[i]] = MapEvnet::haidao;
		}
		begin_idx += pirate_num;
		num = 0;
//		LogS << "begin_idx " << begin_idx << LogEnd;
		for (unsigned i = begin_idx; i < EventCoor.size() && num < silver_box_num; ++i, ++num)
		{
			Events[EventCoor[i]] = MapEvnet::silver_box;
		}
		begin_idx += silver_box_num;
		num = 0;
//		LogS << "begin_idx " << begin_idx << LogEnd;
		for (unsigned i = begin_idx; i < EventCoor.size() && num < gold_box_num; ++i, ++num)
		{
			Events[EventCoor[i]] = MapEvnet::gold_box;
		}
		begin_idx += gold_box_num;
		num = 0;
	}

	int business::cityPriceRate(const int cityID)
	{
		boost::unordered_map<int, int>::iterator it = cityEvnMap.find(cityID);
		if (it == cityEvnMap.end())return 0;
		return it->second;
	}

	bool richGreator(richPtr left, richPtr right)
	{
		if (left->money != right->money)return left->money > right->money;
		if (left->tradeTimes != right->money)return left->tradeTimes < right->tradeTimes;
		return left->playerID < right->playerID;
	}

	void business::updateName(playerDataPtr player)
	{
		{
			richMap::iterator it = dayRichMap.find(player->ID());
			if (it != dayRichMap.end())
			{
				richPtr rich = it->second;
				rich->playerName = player->Name();
				saveDayRich();
			}
		};
		{
			richMap::iterator it = historyRichMap.find(player->ID());
			if (it != historyRichMap.end())
			{
				richPtr rich = it->second;
				rich->playerName = player->Name();
				saveHistoryRich();
			}
		};
		{
			richMap::iterator it = totalRichMap.find(player->ID());
			if (it != totalRichMap.end())
			{
				richPtr rich = it->second;
				rich->playerName = player->Name();
				saveTotalRich();
			}
		};
		{
			_info_ptr info = getBRPlayer(player->ID());
			if (info)info->playerName = player->Name();
		};
	}

	void business::insertDayRich(playerDataPtr player, const int money)
	{
		//����
		richMap::iterator it = dayRichMap.find(player->ID());
		if (it != dayRichMap.end())
		{
			richPtr rich = it->second;
			if (rich->money < money)
			{
				rich->money = money;
			}
			std::sort(dayRich.begin(), dayRich.end(), richGreator);
			saveDayRich();
			return;
		}

		//����
		richPtr rich = Creator<richData>::Create(player, money);
		if (dayRich.size() < 50)
		{
			dayRich.push_back(rich);
			dayRichMap[rich->playerID] = rich;
			std::sort(dayRich.begin(), dayRich.end(), richGreator);
			saveDayRich();
			return;
		}

		//�������
		richPtr back_rich = dayRich.back();
		if (richGreator(rich, back_rich))
		{
			dayRich.pop_back();
			dayRichMap.erase(back_rich->playerID);
			dayRich.push_back(rich);
			dayRichMap[rich->playerID] = rich;
			std::sort(dayRich.begin(), dayRich.end(), richGreator);
			saveDayRich();
			return;
		}
	}

	void business::insertHisRich(playerDataPtr player, const int money)
	{
		//����
		richMap::iterator it = historyRichMap.find(player->ID());
		if (it != historyRichMap.end())
		{
			richPtr rich = it->second;
			if (rich->money < money)
			{
				rich->money = money;
			}
			std::sort(historyRich.begin(), historyRich.end(), richGreator);
			saveHistoryRich();
			return;
		}

		//����
		richPtr rich = Creator<richData>::Create(player, money);
		if (historyRich.size() < 50)
		{
			historyRich.push_back(rich);
			historyRichMap[rich->playerID] = rich;
			std::sort(historyRich.begin(), historyRich.end(), richGreator);
			saveHistoryRich();
			return;
		}

		//�������
		richPtr back_rich = historyRich.back();
		if (richGreator(rich, back_rich))
		{
			historyRich.pop_back();
			historyRichMap.erase(back_rich->playerID);
			historyRich.push_back(rich);
			historyRichMap[rich->playerID] = rich;
			std::sort(historyRich.begin(), historyRich.end(), richGreator);
			saveHistoryRich();
			return;
		}
	}

	void business::insertTotalRich(playerDataPtr player, const int money)
	{
		//����
		richMap::iterator it = totalRichMap.find(player->ID());
		if (it != totalRichMap.end())
		{
			richPtr rich = it->second;
			if (rich->money < money)
			{
				rich->money = money;
			}
			if (player->Trade->totalTask() > rich->tradeTimes)
			{
				rich->tradeTimes = player->Trade->totalTask();
			}
			std::sort(totalRich.begin(), totalRich.end(), richGreator);
			saveTotalRich();
			return;
		}

		//����
		richPtr rich = Creator<richData>::Create(player, money);
		if (dayRich.size() < 50)
		{
			totalRich.push_back(rich);
			totalRichMap[rich->playerID] = rich;
			std::sort(totalRich.begin(), totalRich.end(), richGreator);
			saveTotalRich();
			return;
		}

		//�������
		richPtr back_rich = totalRich.back();
		if (richGreator(rich, back_rich))
		{
			totalRich.pop_back();
			totalRichMap.erase(back_rich->playerID);
			totalRich.push_back(rich);
			totalRichMap[rich->playerID] = rich;
			std::sort(totalRich.begin(), totalRich.end(), richGreator);
			saveTotalRich();
			return;
		}
	}

	void business::saveDayRich()
	{
		mongo::BSONObj key = BSON("key" << 1);
		mongo::BSONArrayBuilder arr;
		for (unsigned i = 0; i < dayRich.size(); ++i)
		{
			arr << dayRich[i]->toBSON();
		}
		mongo::BSONObj obj = BSON("key" << 1 << "r" << arr.arr());
		db_mgr.SaveMongo(DBN::dbPlayerTradeRich, key, obj);
	}

	void business::saveHistoryRich()
	{
		mongo::BSONObj key = BSON("key" << 2);
		mongo::BSONArrayBuilder arr;
		for (unsigned i = 0; i < historyRich.size(); ++i)
		{
			arr << historyRich[i]->toBSON();
		}
		mongo::BSONObj obj = BSON("key" << 2 << "r" << arr.arr());
		db_mgr.SaveMongo(DBN::dbPlayerTradeRich, key, obj);
	}

	void business::saveTotalRich()
	{
		mongo::BSONObj key = BSON("key" << 3);
		mongo::BSONArrayBuilder arr;
		for (unsigned i = 0; i < totalRich.size(); ++i)
		{
			arr << totalRich[i]->toBSON();
		}
		mongo::BSONObj obj = BSON("key" << 3 << "r" << arr.arr());
		db_mgr.SaveMongo(DBN::dbPlayerTradeRich, key, obj);
	}

	void business::saveTimerRich()
	{
		mongo::BSONObj key = BSON("key" << 4);
		mongo::BSONObj obj = BSON("key" << 4 << "tt" << richTickTime);
		db_mgr.SaveMongo(DBN::dbPlayerTradeRich, key, obj);
	}

	void business::areaTick(const structTimer& timerData)
	{
		for (TICKSET::iterator it = AreaTick.begin(); it != AreaTick.end(); ++it)
		{
			insertDisPart(*it);
		}
		AreaTick.clear();
	}

	void business::richTick(const structTimer& timerData)
	{
		{
			qValue data_json(qJson::qj_array);
			for (unsigned i = 0; i < dayRich.size(); ++i)
			{
				richPtr rich = dayRich[i];
				Log(DBLOG::strLogTradeRank, 0, rich->playerID, rich->playerName, i + 1, rich->tradeTimes, rich->money);
				qValue sg_json(qJson::qj_array);
				sg_json.append(rich->playerID).append(rich->playerName).append(rich->kingdom).append(rich->tradeTimes).append(rich->money);
				data_json.append(sg_json);
			}
			dayRich.clear();
			dayRichMap.clear();
			saveDayRich();
			tradeFile.async_write("./report/business/rich/day", data_json);
		};//���յ�Ʊ
		{
			qValue data_json(qJson::qj_array);
			for (unsigned i = 0; i < historyRich.size(); ++i)
			{
				richPtr rich = historyRich[i];
				Log(DBLOG::strLogTradeRank, 1, rich->playerID, rich->playerName, i + 1, rich->tradeTimes, rich->money);
				qValue sg_json(qJson::qj_array);
				sg_json.append(rich->playerID).append(rich->playerName).append(rich->kingdom).append(rich->tradeTimes).append(rich->money);
				data_json.append(sg_json);
			}
			tradeFile.async_write("./report/business/rich/history", data_json);
		};//��ʷ��Ʊ
		{
			qValue data_json(qJson::qj_array);
			for (unsigned i = 0; i < totalRich.size(); ++i)
			{
				richPtr rich = totalRich[i];
				Log(DBLOG::strLogTradeRank, 2, rich->playerID, rich->playerName, i + 1, rich->tradeTimes, rich->money);
				qValue sg_json(qJson::qj_array);
				sg_json.append(rich->playerID).append(rich->playerName).append(rich->kingdom).append(rich->tradeTimes).append(rich->money);
				data_json.append(sg_json);
			}
			tradeFile.async_write("./report/business/rich/total", data_json);
		};//��ʷ����
		//д���¸�richд���ʱ��
		richTickTime += DAY;
		saveTimerRich();
		Timer::AddEventTickTime(boostBind(business::richTick, this, _1), Inter::event_rich_event_timer, richTickTime);//�����¼�
	}

	void business::playerOFFLine(const int playerID)
	{
		_info_ptr info =  getBRPlayer(playerID);
		if (info)
		{
			info->alive = false;
			_brPlayers.erase(playerID);
		}
	}

	bool business::availablePlace(const unsigned x, const unsigned y)
	{
		if (x < MapData.size())
		{
			vector< bool >& yVec = MapData[x];
			if (y < yVec.size())
			{
				//cout << x << "	" << y << "	" << yVec[y] << endl;
				return yVec[y];
			}
		}
		return false;
	}

	void business::update_car(net::Msg& m, Json::Value& r)
	{
		playerDataPtr player = player_mgr.getPlayer(m.playerID);
		if (!player)Return(r, err_illedge);
		r[strMsg][1u] = player->CarPos->X();
		r[strMsg][2u] = player->CarPos->Y();
		Return(r, res_sucess);
	}

	void business::update_base(net::Msg& m, Json::Value& r)
	{
		playerDataPtr player = player_mgr.getPlayer(m.playerID);
		if (!player)Return(r, err_illedge);
		player->Trade->updateBase();
	}
	void business::update_ware(net::Msg& m, Json::Value& r)
	{
		playerDataPtr player = player_mgr.getPlayer(m.playerID);
		if (!player)Return(r, err_illedge);
		player->Trade->updateWare();
	}
	void business::update_buff(net::Msg& m, Json::Value& r)
	{
		playerDataPtr player = player_mgr.getPlayer(m.playerID);
		if (!player)Return(r, err_illedge);
		player->Trade->updateBuff();
	}

// 	void business::start_move(net::Msg& m, Json::Value& r)
// 	{
// 		playerDataPtr player = player_mgr.getPlayer(m.playerID);
// 		if (!player)Return(r, err_illedge);
// 		if (player->LV() < systemUseLimit)Return(r, err_player_lv_too_low);
// 		ReadJsonArray;
// 		const unsigned x = js_msg[0u].asUInt();//Ŀ��
// 		const unsigned y = js_msg[1u].asUInt();//Ŀ��
// 		const unsigned mode = js_msg[2u].asUInt();
// 		player->CarPos->start_move(x, y, mode);
// 		r[strMsg][1u] = player->CarPos->X();
// 		r[strMsg][2u] = player->CarPos->Y();
// 		Return(r, res_sucess);
// 	}

	void business::update_move(net::Msg& m, Json::Value& r)
	{
		playerDataPtr player = player_mgr.getPlayer(m.playerID);
		if (!player)Return(r, err_illedge);
		if (player->LV() < systemUseLimit)Return(r, err_player_lv_too_low);
		ReadJsonArray;
		const unsigned aim_x = js_msg[0u][0u].asUInt();
		const unsigned aim_y = js_msg[0u][1u].asUInt();
		const int mode = js_msg[1u].asInt();
		if (!player->CarPos->set_aim(aim_x, aim_y, mode))Return(r, err_illedge);
		vector< std::pair<unsigned, unsigned> > update_list;
		Json::Value& update_json = js_msg[2u];
		for (unsigned i = 0; i < update_json.size() && i < 50; ++i)
		{
			Json::Value& c_json = update_json[i];
			update_list.push_back(std::pair<unsigned, unsigned>(c_json[0u].asUInt(), c_json[1u].asUInt()));
		}
		int res = player->CarPos->update_move(update_list);
		r[strMsg][1u] = player->CarPos->X();
		r[strMsg][2u] = player->CarPos->Y();
		r[strMsg][3u] = player->CarPos->tX();
		r[strMsg][4u] = player->CarPos->tY();
		r[strMsg][5u] = player->CarPos->move_mode();
		Return(r, res);
	}

	void business::end_move(net::Msg& m, Json::Value& r)
	{
		playerDataPtr player = player_mgr.getPlayer(m.playerID);
		if (!player)Return(r, err_illedge);
		if (player->LV() < systemUseLimit)Return(r, err_player_lv_too_low);
		player->CarPos->end_move();
		r[strMsg][1u] = player->CarPos->X();
		r[strMsg][2u] = player->CarPos->Y();
		Return(r, res_sucess);
	}

	const static int taskBegin[3] = { 120000, 80000, 60000 };
	const static int taskEnd[3] = { 240000, 160000, 120000 };
	void business::accept_task(net::Msg& m, Json::Value& r)
	{
		playerDataPtr player = player_mgr.getPlayer(m.playerID);
		if (!player)Return(r, err_illedge);
		if (player->LV() < systemUseLimit)Return(r, err_player_lv_too_low);
		if (player->Info->Nation() == Kingdom::null)Return(r, err_illedge);
		if (player->Trade->taskType() != TradeType::null)Return(r, err_illedge);
		if (player->Trade->taskTimes() >= 5)Return(r, err_trade_task_over_times);
		const unsigned playerLV = player->LV();
		int bg_num = 0;
		int ed_num = 0;
		if (playerLV > 80){ bg_num = taskBegin[0]; ed_num = taskEnd[0]; }
		else if (playerLV > 60){ bg_num = taskBegin[1]; ed_num = taskEnd[1]; }
		else if (playerLV > 30){ bg_num = taskBegin[2]; ed_num = taskEnd[2]; }
		else Return(r, err_illedge);
		player->Trade->acceptTask(bg_num, ed_num);
		Log(DBLOG::strLogBusiness, player, 0, bg_num, ed_num);
		Return(r, res_sucess);
	}

	void business::money_show(net::Msg& m, Json::Value& r)
	{
		playerDataPtr player = player_mgr.getPlayer(m.playerID);
		if (!player)Return(r, err_illedge);
		if (player->LV() < systemUseLimit)Return(r, err_player_lv_too_low);
		if (player->Trade->taskType() == TradeType::null)Return(r, err_illedge);
		unsigned now = Common::gameTime();
		if (player->BusinessCD > now)Return(r, err_business_show_cd_limit);
		player->BusinessCD = now + 60;//60s
		Json::Value chatJson = Json::arrayValue;
		chatJson.append(chat_sys.ChatPackage(player));
		chatJson.append(player->Trade->getMoney());
		chatJson.append(player->Trade->getComplete());
		chat_sys.despatchAll(CHAT::server_business_money, chatJson);
		Return(r, res_sucess);
	}

	void business::city_event(net::Msg& m, Json::Value& r)
	{
		playerDataPtr player = player_mgr.getPlayer(m.playerID);
		if (!player)Return(r, err_illedge);
		if (player->LV() < systemUseLimit)Return(r, err_player_lv_too_low);
		
		Json::Value& data_json = r[strMsg][1u] = Json::arrayValue;
		for (boost::unordered_map<int, int>::iterator it = cityEvnMap.begin(); it != cityEvnMap.end(); ++it)
		{
			Json::Value sg_json;
			sg_json.append(it->first);
			sg_json.append(it->second);
			data_json.append(sg_json);
		}
		Return(r, res_sucess);
	}

	void business::cancel_task(net::Msg& m, Json::Value& r)
	{
		playerDataPtr player = player_mgr.getPlayer(m.playerID);
		if (!player)Return(r, err_illedge);
		if (player->LV() < systemUseLimit)Return(r, err_player_lv_too_low);
		ReadJsonArray;
		const unsigned idx = js_msg[0u].asUInt();
		if (player->Info->Nation() == Kingdom::null)Return(r, err_illedge);
		if (player->Trade->taskType() != TradeType::runing)Return(r, err_illedge);
		Log(DBLOG::strLogBusiness, player, 1, player->Trade->getMoney(), player->Trade->getComplete());
		player->Trade->cancelTask();
		Return(r, res_sucess);
	}

	void business::complete_task(net::Msg& m, Json::Value& r)
	{
		playerDataPtr player = player_mgr.getPlayer(m.playerID);
		if (!player)Return(r, err_illedge);
		if (player->LV() < systemUseLimit)Return(r, err_player_lv_too_low);
		if (player->Info->Nation() == Kingdom::null)Return(r, err_illedge);
		if (player->Trade->taskType() != TradeType::complete)Return(r, err_illedge);
		if (
			player->Items->isOver
			(
				player->Items->itemUsePos(CarMaterialID, 1)
			)
			)Return(r, err_bag_full);
		int cm = player->Trade->getMoney() - player->Trade->getComplete();
		cm = cm < 0 ? 0 : cm;
		const unsigned times = player->Trade->taskTimes();
		//��������Ʊ��� / 8 + 10000 + ����������� * 2 %
		const int silver = int((player->Trade->getComplete() / 4 + 10000 + cm * 0.1) * (times > 3 ? 0.3 : 1.0));
		const int contribute = 500 + (int)player->LV() * 5;
		kingdom_sys.upgradeConstruction(player->Info->Nation(), Kingdom::CLevel, contribute);
		player->Res->alterSilver(silver);
		player->Res->alterContribution(contribute);
		player->Items->addItem(CarMaterialID, 2);
		player->Trade->overTask();
		r[strMsg][1u] = silver;
		r[strMsg][2u] = contribute;
		r[strMsg][3u] = 2;
		r[strMsg][4u] = contribute;
		Log(DBLOG::strLogBusiness, player, 2, cm, silver, contribute, 2);
		{
			//����
			//player->Task->evTask(TaskDef::BusinessNumEv);
			//�ճ�
			TaskMgr::update(player, Task::BusinessTimes, 1);
			TaskMgr::update(player, Task::BusinessAllTimes);
			player->Daily->tickTask(DAILY::business_trade);
		}
		Return(r, res_sucess);
	}

	void business::complete_task_ok(net::Msg& m, Json::Value& r)
	{
		playerDataPtr player = player_mgr.getPlayer(m.playerID);
		if (!player)Return(r, err_illedge);
		if (player->Info->VipLv() < 3)Return(r, err_vip_lv_too_low);
		if (player->LV() < systemUseLimit)Return(r, err_player_lv_too_low);
		if (player->Info->Nation() == Kingdom::null)Return(r, err_illedge);
		if (player->Res->getCash() < 50)Return(r, err_cash_not_enough);
		if (player->Trade->taskType() == TradeType::null)//û������ͽ�������
		{
			const unsigned playerLV = player->LV();
			if (playerLV > 80)player->Trade->acceptTask(taskBegin[0], taskEnd[0]);
			else if (playerLV > 60)player->Trade->acceptTask(taskBegin[1], taskEnd[1]);
			else if (playerLV > 30)player->Trade->acceptTask(taskBegin[2], taskEnd[2]);
		}
		if (
			player->Items->isOver
			(
			player->Items->itemUsePos(CarMaterialID, 2)
			)
			)Return(r, err_bag_full);
		int cm = player->Trade->getMoney() - player->Trade->getComplete();
		cm = cm < 0 ? 0 : cm;
		const unsigned times = player->Trade->taskTimes();
		//��������Ʊ��� / 8 + 10000 + ����������� * 2 %
		const int silver = int((player->Trade->getComplete() / 4 + 10000 + cm * 0.1) * (times > 3 ? 0.3 : 1.0));
		const int contribute = 500 + (int)player->LV() * 5;
		kingdom_sys.upgradeConstruction(player->Info->Nation(), Kingdom::CLevel, contribute);
		player->Res->alterSilver(silver);
		player->Res->alterContribution(contribute);
		player->Items->addItem(CarMaterialID, 2);
		player->Trade->overTask();
		player->Res->alterCash(-50);
		r[strMsg][1u] = silver;
		r[strMsg][2u] = contribute;
		r[strMsg][3u] = 2;
		r[strMsg][4u] = contribute;
		Log(DBLOG::strLogBusiness, player, 3, cm, silver, contribute, 2);
		{
			//����
			//player->Task->evTask(TaskDef::BusinessNumEv);
			//�ճ�
			TaskMgr::update(player, Task::BusinessTimes, 1);
			TaskMgr::update(player, Task::BusinessAllTimes);
			player->Daily->tickTask(DAILY::business_trade);
		}
		Return(r, res_sucess);
	}

	void business::update_city(net::Msg& m, Json::Value& r)
	{
		playerDataPtr player = player_mgr.getPlayer(m.playerID);
		if (!player)Return(r, err_illedge);
		if (player->LV() < systemUseLimit)Return(r, err_player_lv_too_low);
		if (!player->CarPos->is_stop())Return(r, err_car_is_moving);
		//player->CarPos->end_move();
		const unsigned x = player->CarPos->X();
		const unsigned y = player->CarPos->Y();
		ReadJsonArray;
		const int cityID = js_msg[0u].asInt();
		if (!validCityRange(cityID, x, y))Return(r, err_illedge);
		qValue data_json(qJson::qj_array);
		data_json.append(res_sucess)
			.append(cityID)
			.append(Cities[cityID]->toJson())
			.append(cityPriceRate(cityID));
		player->sendToClientFillMsg(gate_client::player_trade_city_update_resp, data_json);
	}

	void business::buy_item(net::Msg& m, Json::Value& r)
	{
		playerDataPtr player = player_mgr.getPlayer(m.playerID);
		if (!player)Return(r, err_illedge);
		if (player->LV() < systemUseLimit)Return(r, err_player_lv_too_low);
		if (player->Info->Nation() == Kingdom::null)Return(r, err_illedge);
		if (player->Trade->taskType() != TradeType::runing)Return(r, err_illedge);
		if (!player->CarPos->is_stop())Return(r, err_car_is_moving);
		//player->CarPos->end_move();
		const unsigned x = player->CarPos->X();
		const unsigned y = player->CarPos->Y();
		ReadJsonArray;
		const int cityID = js_msg[0u].asInt();
		const int wareID = js_msg[1u].asInt();
		const unsigned wareNum = js_msg[2u].asUInt();
		const int warePrice = js_msg[3u].asInt();
		if (!validCityRange(cityID, x, y))Return(r, err_illedge);
		cityPtr city = Cities[cityID];
		CityData::warePtr ware = city->saleWare(wareID);
		if (!ware)Return(r, err_illedge);
		if (ware->price != warePrice)
		{
			r[strMsg][1u] = ware->price;
			Return(r, err_refresh_trade_city);
		}
		const int need_money = ware->price * wareNum;
		if (player->Trade->getMoney() < need_money)Return(r, err_trade_money_not_enough);
		if (player->Trade->addWare(wareID, wareNum, warePrice) == res_sucess)
		{
			player->Trade->alterMoney(-need_money);
			r[strMsg][1u] = need_money;
			Return(r, res_sucess);
		}
		Return(r, err_trade_bag_full);
	}

	int CarDurable(const double rate)
	{
		if (rate <= 0.1)return -18;
		if (rate <= 0.2)return -16;
		if (rate <= 0.3)return -14;
		if (rate <= 0.4)return -12;
		if (rate <= 0.5)return -10;
		if (rate <= 0.6)return -8;
		if (rate <= 0.7)return -6;
		if (rate <= 0.8)return -4;
		if (rate <= 0.9)return -2;
		return 0;
	}
	void business::sale_item(net::Msg& m, Json::Value& r)
	{
		playerDataPtr player = player_mgr.getPlayer(m.playerID);
		if (!player)Return(r, err_illedge);
		if (player->LV() < systemUseLimit)Return(r, err_player_lv_too_low);
		if (player->Info->Nation() == Kingdom::null)Return(r, err_illedge);
		if (player->Trade->taskType() == TradeType::null)Return(r, err_illedge);
		if (!player->CarPos->is_stop())Return(r, err_car_is_moving);
		//player->CarPos->end_move();
		const unsigned x = player->CarPos->X();
		const unsigned y = player->CarPos->Y();
		ReadJsonArray;
		const int cityID = js_msg[0u].asInt();
		const int cityRate = js_msg[1u].asInt();
		const int wareID = js_msg[2u].asInt();
		const unsigned wareNum = js_msg[3u].asUInt();
		const int warePrice = js_msg[4u].asInt();
		if (!validCityRange(cityID, x, y))Return(r, err_illedge);
		const int rate = cityPriceRate(cityID);
		cityPtr city = Cities[cityID];//��ֵ��֤����һ��
		CityData::warePtr ware = city->pawnWare(wareID);
		if (!ware)Return(r, err_illedge);
		if (rate != cityRate || ware->price != warePrice)
		{
			r[strMsg][2u] = ware->price;
			r[strMsg][1u] = rate;
			Return(r, err_refresh_trade_city);
		}
		if (player->Trade->checkWare(wareID, wareNum))
		{
			player->Trade->removeWare(wareID, wareNum);
			int all_rate = 100 + 
				CarDurable(player->Trade->getDurableRate()) +
				player->Trade->getSaleRate() +
				((rate < 0 && player->Trade->checkBuff(TradeBuff::fangshui)) ? 0 : rate) +
				(player->Trade->checkBuff(TradeBuff::yijia) ? 10 : 0);
			const int reward = int(
				all_rate / 100.0 * warePrice * wareNum
				);
			player->Trade->alterMoney(reward);
			r[strMsg][1u] = reward;
			Return(r, res_sucess);
		}
		Return(r, err_illedge);
	}

	void business::update_area(net::Msg& m, Json::Value& r)
	{
		playerDataPtr player = player_mgr.getPlayer(m.playerID);
		if (!player)Return(r, err_illedge);
		if (player->Info->Nation() == Kingdom::null)Return(r, err_illedge);
		ReadJsonArray;
		const int areaID = js_msg[0u].asInt();
		const unsigned num = js_msg[1u].asInt();
		if (num >= 50 || num < 1)Return(r, err_illedge);
		_brRangePtr br = getBeacon(areaID);
		if (br && br->validRange(player->CarPos->X(), player->CarPos->Y()))
		{
			qValue data_json(qJson::qj_array);
			data_json.append(res_sucess);
			data_json.append(br->Package(num));
			player->sendToClientFillMsg(gate_client::player_trade_map_area_update_resp, data_json);
			return;
		}
		Return(r, err_illedge);
	}

	void business::update_map(net::Msg& m, Json::Value& r)
	{
		playerDataPtr player = player_mgr.getPlayer(m.playerID);
		if (!player)Return(r, err_illedge);
		if (player->Info->Nation() == Kingdom::null)Return(r, err_illedge);
		Json::Value& data_json = r[strMsg][1u];
		data_json = Json::arrayValue;
		for (EvnetMap::iterator it = Events.begin(); it != Events.end(); ++it)
		{
			Json::Value json;
			const EventPos& pos = it->first;
			const MapEvnet::Type type = it->second;
			json.append(pos.x);
			json.append(pos.y);
			json.append(type);
			data_json.append(json);
		}
		Return(r, res_sucess);
	}

	void business::car_upgrade(net::Msg& m, Json::Value& r)
	{
		playerDataPtr player = player_mgr.getPlayer(m.playerID);
		if (!player)Return(r, err_illedge);
		if (player->LV() < systemUseLimit)Return(r, err_player_lv_too_low);
		if (!player->CarPos->is_stop())Return(r, err_car_is_moving);
		ReadJsonArray;
		const int times = js_msg[0u].asUInt();
		if (times < 1 || times > 10)Return(r, err_illedge);
		if (player->Info->Nation() == Kingdom::null)Return(r, err_illedge);
// 		if (player->Res->getSilver() < 10000 * times)Return(r, err_silver_not_enough);
// 		if (player->Res->getWood() < 1000 * times)Return(r, err_wood_not_enough);
// 		if (player->Res->getIron() < 1000 * times)Return(r, err_iron_not_enough);
		if (!player->Items->overItem(CarMaterialID, 1 * times))Return(r, err_item_not_enough);
// 		player->Res->alterSilver(-10000 * times);
// 		player->Res->alterWood(-1000 * times);
// 		player->Res->alterIron(-1000 * times);
		player->Items->removeItem(CarMaterialID, 1 * times);
		player->Trade->addExp(10 * times);
		r[strMsg][3u] = player->Trade->getExp();
		r[strMsg][2u] = player->Trade->getLevel();
		r[strMsg][1u] = 1000 * times;
		Log(DBLOG::strLogBusiness, player, 6, CarMaterialID, times, 10 * times);
		Return(r, res_sucess);
	}

	void business::item_use(net::Msg& m, Json::Value& r)
	{
		playerDataPtr player = player_mgr.getPlayer(m.playerID);
		if (!player)Return(r, err_illedge);
		if (player->LV() < systemUseLimit)Return(r, err_player_lv_too_low);
		if (player->Info->Nation() == Kingdom::null)Return(r, err_illedge);
		if (player->Trade->taskType() == TradeType::null)Return(r, err_illedge);
		ReadJsonArray;
		const int itemID = js_msg[0u].asInt();
		if (!player->Items->overItem(itemID, 1))Return(r, err_item_not_enough);
		const TBstruct dataBuff = getBindBuff(itemID);
		if (dataBuff._id_buff == TradeBuff::null)Return(r, err_illedge);
		if (player->Trade->checkBuff(dataBuff._id_buff))Return(r, err_trade_buff_hold);
		player->Trade->insertBuff(dataBuff._id_buff, dataBuff._duration);
		player->Items->removeItem(itemID, 1);
		Log(DBLOG::strLogBusiness, player, 4, itemID, 1);
		r[strMsg][2u] = dataBuff._duration;
		r[strMsg][1u] = dataBuff._id_buff;
		Return(r, res_sucess);
	}

	void business::open_box(net::Msg& m, Json::Value& r)
	{
		playerDataPtr player = player_mgr.getPlayer(m.playerID);
		if (!player)Return(r, err_illedge);
		if (player->LV() < systemUseLimit)Return(r, err_player_lv_too_low);
		if (player->Info->Nation() == Kingdom::null)Return(r, err_illedge);
		if (player->Trade->taskType() == TradeType::null)Return(r, err_illedge);
		player->CarPos->end_move();
		const unsigned x = player->CarPos->X();
		const unsigned y = player->CarPos->Y();
		ReadJsonArray;
		const unsigned ax = js_msg[0u].asUInt();
		const unsigned ay = js_msg[1u].asUInt();
		const MapEvnet::Type type = getMapEvent(ax, ay);
		if (!(type == MapEvnet::silver_box || type == MapEvnet::gold_box))Return(r, err_trade_box_not_found);
		if ((ax > x && ax - x > 3) || (ay > y && ay - y > 3) || (ax < x && x - ax > 3) || (ay < y && y - ay > 3))Return(r, err_illedge);
		const unsigned lv = player->LV();
		if (MapEvnet::silver_box == type)
		{
			if (!player->Items->overItem(SilverKeyID, 1))Return(r, err_item_not_enough);
			for (unsigned i = 0; i < SilverBox.size(); ++i)
			{
				if (lv > SilverBox[i].LevelLimit)
				{
					const int res = actionDo(player, SilverBox[i].BoxReward, 1, false);
					if (res != res_sucess)
					{
						r[strMsg][1u] = actionError();
						Return(r, res);
					}
					break;
				}
			}
			player->Items->removeItem(SilverKeyID, 1);
			Log(DBLOG::strLogBusiness, player, 4, SilverKeyID, 1);
		}
		if (MapEvnet::gold_box == type)
		{
			if (!player->Items->overItem(GoldKeyID, 1))Return(r, err_item_not_enough);
			for (unsigned i = 0; i < GoldBox.size(); ++i)
			{
				if (lv > GoldBox[i].LevelLimit)
				{
					const int res = actionDo(player, GoldBox[i].BoxReward, 1, false);
					if (res != res_sucess)
					{
						r[strMsg][1u] = actionError();
						Return(r, res);
					}
					break;
				}
			}
			player->Items->removeItem(GoldKeyID, 1);
			Log(DBLOG::strLogBusiness, player, 4, GoldKeyID, 1);
		}
		r[strMsg][1u] = actionRes();
		removeMapEvent(ax, ay);
		Return(r, res_sucess);
	}

	sBattlePtr npcSide(const Pirate& pir, const vector<Pirate::armyNPC>& npcList)
	{
		sBattlePtr sb = Creator<sideBattle>::Create();
		sb->playerID = -1;
		sb->playerName = pir.npcName;
		sb->isPlayer = false;
		sb->playerLevel = pir.npcLevel;
		sb->battleValue = pir.battleValue;
		sb->playerFace = pir.npcFace;
		manList& ml = sb->battleMan;
		ml.clear();
		for (unsigned i = 0; i < npcList.size(); i++)
		{
			const Pirate::armyNPC& npc = npcList[i];
			mBattlePtr man = Creator<manBattle>::Create();
			man->manID = npc.npcID;
			man->holdMorale = npc.holdMorale;
			man->set_skill_1(npc.skill_1);
			man->set_skill_2(npc.skill_2);
			man->armsType = npc.armsType;
			man->manLevel = npc.npcLevel;
			man->currentIdx = npc.npcPos;
			man->battleValue = npc.battleValue;
			memcpy(man->armsModule, npc.armsModule, sizeof(man->armsModule));
			memcpy(man->initialAttri, npc.initAttri, sizeof(man->initialAttri));
			memcpy(man->battleAttri, npc.initAttri, sizeof(man->battleAttri));
			//memcpy(man->battleAttri, npc.addAttri, sizeof(man->battleAttri));
			man->currentHP = man->getTotalAttri(idx_hp);
			man->equipList = npc.equipList;
			ml.push_back(man);
		}
		return sb;
	}

	void business::challenge_pirate(net::Msg& m, Json::Value& r)
	{
		playerDataPtr player = player_mgr.getPlayer(m.playerID);
		if (!player)Return(r, err_illedge);
		if (player->LV() < systemUseLimit)Return(r, err_player_lv_too_low);
		if (player->Info->Nation() == Kingdom::null)Return(r, err_illedge);
		if (player->Trade->taskType() == TradeType::null)Return(r, err_illedge);
		player->CarPos->end_move();
		const unsigned x = player->CarPos->X();
		const unsigned y = player->CarPos->Y();
		ReadJsonArray;
		const unsigned ax = js_msg[0u].asUInt();
		const unsigned ay = js_msg[1u].asUInt();
		const MapEvnet::Type type = getMapEvent(ax, ay);
		if (type != MapEvnet::haidao)Return(r, err_trade_haidao_not_found);
		if ((ax > x && ax - x > 2) || (ay > y && ay - y > 2) || (ax < x && x - ax > 2) || (ay < y && y - ay > 2))Return(r, err_illedge);
		const unsigned lv = player->LV();
		for (unsigned i = 0; i < PirateBox.size(); ++i)
		{
			const Pirate& pir = PirateBox[i];
			if (lv > pir.LevelLimit)
			{
				sBattlePtr atk = BattleHelp::WarPlayer(player);
				const int idx = Common::randomBetween(0, pir.npcList.size() - 1);
				sBattlePtr def = npcSide(pir,pir.npcList[idx]);
				BattleReportData reportData;
				const O2ORes res = battle_sys.One2One(reportData, atk, def, typeBattle::trade_pirate);
				reportData.addNotice(player->ID());
				reportData.addReportdeclare("bg", pir.background);
				if (resBattle::atk_win == res.res)
				{
					removeMapEvent(ax, ay);
				}
				Json::Value me_json;
				unsigned total_me = BattleHelp::AddManExp(player, 0, me_json);
				reportData.addReportdeclare("me", me_json);
				Json::Value res_json = Json::arrayValue;
				if (resBattle::atk_win == res.res && player->Trade->hitPirate() < 5)
				{
					player->Trade->tickPirate();
					actionDo(player, pir.rewardList[idx], 1);
					res_json = actionRes();
				}
				reportData.addReportdeclare("wb", res_json);
				Json::Value playerJson;
				playerJson.append(player->LV());
				playerJson.append(player->Info->EXP());
				playerJson.append(player->LV());
				playerJson.append(player->Info->EXP());
				playerJson.append(0);
				playerJson.append(player->Info->isMaxLevel());
				reportData.addReportdeclare("plv", playerJson);
				reportData.addCopyField("last_rep/" + Common::toString(player->ID()));
				reportData.Done(typeBattle::trade_pirate);
				r[strMsg][1u] = res.res;
				Return(r, res_sucess);
			}
		}
		Return(r, err_illedge);
	}

	void business::car_teleport(net::Msg& m, Json::Value& r)
	{
		playerDataPtr player = player_mgr.getPlayer(m.playerID);
		if (!player)Return(r, err_illedge);
		if (player->LV() < systemUseLimit)Return(r, err_player_lv_too_low);
		if (player->Info->Nation() == Kingdom::null)Return(r, err_illedge);
		if (!player->Items->overItem(ShunYiID, 1))Return(r, err_item_not_enough);
		ReadJsonArray;
		const unsigned x = js_msg[0u].asUInt();
		const unsigned y = js_msg[1u].asUInt();
		if (availableTeleport(x, y))
		{
			player->Items->removeItem(ShunYiID, 1);
			player->CarPos->setPos(x, y);
			player->CarPos->end_move(false);
			player->CarPos->forceSave();
			r[strMsg][1u] = player->CarPos->X();
			r[strMsg][2u] = player->CarPos->Y();
			r[strMsg][3u] = player->CarPos->tX();
			r[strMsg][4u] = player->CarPos->tY();
			Log(DBLOG::strLogBusiness, player, 4, ShunYiID, 1);
			Return(r, res_sucess);
		}
		Return(r, err_illedge);
	}
	void business::car_repair(net::Msg& m, Json::Value& r)
	{
		playerDataPtr player = player_mgr.getPlayer(m.playerID);
		if (!player)Return(r, err_illedge);
		if (player->LV() < systemUseLimit)Return(r, err_player_lv_too_low);
		if (player->Info->Nation() == Kingdom::null)Return(r, err_illedge);
		const int cost_silver = player->Trade->getDurableLimit() * 100;
		if (cost_silver == 0)Return(r, err_illedge);
		if (cost_silver > player->Res->getSilver())Return(r, err_silver_not_enough);
		player->Res->alterSilver(-cost_silver);
		player->Trade->fullDurable();
		r[strMsg][1u] = cost_silver;
		Log(DBLOG::strLogBusiness, player, 7, cost_silver, player->Res->getSilver());
		Return(r, res_sucess);
	}

	void business::updateMoveCar(playerDataPtr player)
	{
		_info_ptr info = getBRPlayer(player->ID());
		if (!info){
			info = Creator<_info>::Create();
			info->playerID = player->ID();
			info->playerNation = player->Info->Nation();
			info->playerName = player->Name();
			_brPlayers[player->ID()] = info;
		}
		info->mode = player->CarPos->move_mode();
		info->cpos_x = player->CarPos->X();//��ǰλ��
		info->cpos_y = player->CarPos->Y();//��ǰλ��
		info->aim_x = player->CarPos->tX();
		info->aim_y = player->CarPos->tY();
		info->speed = player->Trade->getSpeed();
		info->level = player->Trade->getLevel();
		AreaTick.insert(info);
	}

// 	void business::startMoveCar(playerDataPtr player, const unsigned mode)
// 	{
// 		_info_ptr info = getBRPlayer(player->ID());
// 		if (!info){
// 			info = Creator<_info>::Create();
// 			info->playerID = player->ID();
// 			_brPlayers[player->ID()] = info;
// 		}
// 		info->playerNation = player->Info->Nation();
// 		info->playerName = player->Name();
// 		info->cpos_x = player->CarPos->X();
// 		info->cpos_y = player->CarPos->Y();
// 		info->aim_x = player->CarPos->tX();
// 		info->aim_y = player->CarPos->tY();
// 		info->moving_time = Common::gameTime();
// 		info->speed = player->Trade->getSpeed();
// 		info->level = player->Trade->getLevel();
// 		info->mode = mode;
// 		AreaTick.insert(info);
// 	}


}

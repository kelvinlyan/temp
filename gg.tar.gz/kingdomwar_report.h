#pragma once

#include "commom.h"
#include "mongoDB.h"
#include "quickjson.h"

namespace gg
{
	class playerData;
	SHAREPTR(playerData, playerDataPtr);

	namespace KingdomWar
	{
		class ReportMgr
		{
			public:
				ReportMgr(int max);

				void load(const mongo::BSONElement& obj);
				mongo::BSONArray toBSON() const;

				void push(qValue& rep);
				void updateAll(playerDataPtr d, short protocol);

			private:
				typedef std::deque<std::string> ReportList;
				ReportList _rep_list;
				int _max;
		};
	}
}

#include "team_war.h"
#include "battle_system.h"
#include "chat.h"
#include "battle_helper.hpp"
#include "item_system.h"
#include "task_mgr.h"
#include "kingdom_system.h"

namespace gg
{
	const static unsigned teamMaxMember = 8;//����������

	static vector<unsigned> VipBuyLimit;
	static vector<int> VipBuyCost;

	TeamWar* const TeamWar::_Instance = new TeamWar();
	static std::queue<int> teamIDList;
	typedef std::vector<sBattlePtr> sbList;
	struct team
	{
		team(const int tID);
		~team(){
			for (unsigned i = 0; i < wait_member.size(); ++i)
			{
				sBattlePtr sb = wait_member[i];
				if (!sb->isPlayer)continue;
				playerDataPtr c_player = player_mgr.getCachePlayer(sb->playerID);
				if (c_player)
				{
					c_player->Team->setTeamID(-1);
					static qValue nullMessage(qJson::qj_array);
					nullMessage.toArray();
					nullMessage.append(State::getState());
					c_player->sendToClientFillMsg(gate_client::war_team_dismiss_resp, nullMessage);
				}
			}
			if (team_id > -1)teamIDList.push(team_id);
			if (timer_id)
			{
				timer_id->delTimer();
			}
			timer_id = ptrTimerIdentify();
		}
		bool is_leader(playerDataPtr player)const
		{
			return (leader_member->playerID == player->ID());
		}
		inline int leader_id()const
		{
			return leader_member->playerID;
		}
		inline string leader_name()const
		{
			return leader_member->playerName;
		}
		sBattlePtr member_leave(const unsigned idx);
		sBattlePtr member_leave(playerDataPtr player);
		int robot_join();
		int member_join(playerDataPtr player);
		int team_id;//��ӱ��
		Kingdom::NATION nation_limit;//��������
		unsigned level_limit;//�ȼ�����
		int hit_id;//�����ľ���ID
		unsigned over_time;//��ʼʱ��
		ptrTimerIdentify timer_id;//��ʱ��ID
		unsigned hit_idx;//�����ľ����±�IDX
		unsigned robot_cd;//���ӻ�����CD
		unsigned robot_num;//���ӻ����˵�����
		bool is_first_hit;//�Ƿ��׹�
		sBattlePtr leader_member;//�ӳ���Ϣ
		sbList wait_member;//�ȴ����б�
	};
	SHAREPTR(team, teamPtr);
	UNORDERMAP(int, teamPtr, teamMap);
	static teamMap mapTeam;
	teamPtr getTeam(const int teamID)
	{
		teamMap::iterator it = mapTeam.find(teamID);
		if (it == mapTeam.end())return teamPtr();
		return it->second;
	}
	UNORDERMAP(int, teamMap, teamPartMap);
	static teamPartMap  mapTeamPart;//���ݾ���ID������
	void getTeamPart(const int hitID, teamMap& useMap)
	{
		useMap = mapTeamPart[hitID];
	}

	//ɾ�������Ϣ
	void delTeam(const int teamID)
	{
		teamPtr t = getTeam(teamID);
		if (t)
		{
			mapTeam.erase(teamID);
			mapTeamPart[t->hit_id].erase(teamID);
		}
	}

	//���
	qValue buildTeamInfo(const team& t)
	{
		qValue sg_team(qJson::qj_array);
		sg_team.append(t.team_id);
		sg_team.append(t.leader_id());
		sg_team.append(t.leader_name());
		sg_team.append(t.level_limit);
		sg_team.append(t.nation_limit);
		sg_team.append(unsigned(t.wait_member.size()));
		qValue mb_json(qJson::qj_array);
		for (sbList::const_iterator it = t.wait_member.begin(); it != t.wait_member.end(); ++it)
		{
			sBattlePtr sb = *it;
			qValue sg_mb(qJson::qj_array);
			sg_mb.append(sb->playerID);
			sg_mb.append(sb->playerFace);
			sg_mb.append(sb->playerNation);
			sg_mb.append(sb->playerName);
			sg_mb.append(sb->playerLevel);
			sg_mb.append(sb->battleValue);
			sg_mb.append(sb->isPlayer);
			mb_json.append(sg_mb);
		}
		sg_team.append(mb_json);
		sg_team.append(t.hit_id);
		sg_team.append(t.over_time);
		return sg_team;
	}

	qValue buildTeamInfo(teamPtr t)
	{
		return buildTeamInfo(*t);
	}

	static void OverTeam(const structTimer& timerData, const int teamID)
	{
		teamPtr t = getTeam(teamID);
		if (t)
		{
			if (Common::gameTime() > t->over_time)
			{
				delTeam(teamID);
			}
			else
			{
				t->timer_id = Timer::AddEventTickTime(boostBind(OverTeam, _1, t->team_id), Inter::event_timer_team_over, t->over_time + 2);
			}
		}
	}
	
	team::team(const int tID)
	{
		team_id = tID;
		nation_limit = Kingdom::null;
		level_limit = 0;
		hit_id = -1;
		hit_idx = 0;
		robot_cd = 0;
		robot_num = 0;
		leader_member = sBattlePtr();
		wait_member.clear();
		over_time = Common::gameTime() + 180;
		timer_id = Timer::AddEventTickTime(boostBind(OverTeam, _1, tID), Inter::event_timer_team_over, over_time + 2);
	}

	int team::member_join(playerDataPtr player)
	{
		if (level_limit > player->LV())return err_player_lv_too_low;
		if (nation_limit != Kingdom::null && nation_limit != player->Info->Nation())return err_player_nation_not_match;
		if (teamMaxMember <= wait_member.size())return err_team_list_over;
		//wait_member.insert(wait_member.begin() + (wait_member.size() - robot_num), BattleHelp::WarPlayer(player));
		for (unsigned i = wait_member.size() - 1; i < wait_member.size(); --i)
		{
			sBattlePtr sb = wait_member[i];
			if (sb->isPlayer)
			{
				wait_member.insert(wait_member.begin() + 1 + i, BattleHelp::WarPlayer(player));
				break;
			}
		}
		player->Team->setTeamID(team_id);
		robot_cd = Common::gameTime() + 3;
		over_time += 60;
		for (unsigned i = 0; i < wait_member.size(); ++i)
		{
			sBattlePtr sb = wait_member[i];
			if (!sb->isPlayer)continue;
			playerDataPtr t_player = player_mgr.getOnlinePlayer(sb->playerID);
			if (t_player)
			{
				qValue data_list(qJson::qj_array);
				data_list.append(res_sucess);
				data_list.append(buildTeamInfo(*this));
				data_list.append(t_player->TeamAnnCD);
				data_list.append(robot_cd);
				t_player->sendToClientFillMsg(gate_client::war_team_detail_info_resp, data_list);
			}
		}
		return res_sucess;
	}

	sBattlePtr team::member_leave(const unsigned idx)//���ܴ�����ӽ�ɢ������
	{
		sBattlePtr res_sb;
		if (idx >= wait_member.size())return res_sb;
		res_sb = wait_member[idx];
		if (res_sb == leader_member)//�ӳ�
		{
			delTeam(team_id);
		}
		else
		{
			sBattlePtr sb = wait_member[idx];
			if (sb->isPlayer)
			{
				playerDataPtr c_player = player_mgr.getCachePlayer(sb->playerID);
				if (c_player)
				{
					c_player->Team->setTeamID(-1);
				}
			}
			else
			{
				--robot_num;
			}
			wait_member.erase(wait_member.begin() + idx);
			for (unsigned i = 0; i < wait_member.size(); ++i)
			{
				sBattlePtr sb = wait_member[i];
				if (!sb->isPlayer)continue;
				playerDataPtr t_player = player_mgr.getOnlinePlayer(sb->playerID);
				if (t_player)
				{
					qValue data_list(qJson::qj_array);
					data_list.append(res_sucess);
					data_list.append(buildTeamInfo(*this));
					data_list.append(t_player->TeamAnnCD);
					data_list.append(robot_cd);
					t_player->sendToClientFillMsg(gate_client::war_team_detail_info_resp, data_list);
				}
			}
		}
		return res_sb;
	}

	sBattlePtr team::member_leave(playerDataPtr player)//���ܴ�����ӽ�ɢ������
	{
		sBattlePtr res_sb;
		if (is_leader(player))
		{
			res_sb = leader_member;
			delTeam(team_id);
		}
		else
		{
			for (unsigned i = 0; i < wait_member.size(); ++i)
			{
				sBattlePtr sb = wait_member[i];
				if (!sb->isPlayer)continue;
				if (sb->playerID == player->ID())
				{
					res_sb = sb;
					player->Team->setTeamID(-1);
					wait_member.erase(wait_member.begin() + i);
					break;
				}
			}
			for (unsigned i = 0; i < wait_member.size(); ++i)
			{
				sBattlePtr sb = wait_member[i];
				if (!sb->isPlayer)continue;
				playerDataPtr t_player = player_mgr.getOnlinePlayer(sb->playerID);
				if (t_player)
				{
					qValue data_list(qJson::qj_array);
					data_list.append(res_sucess);
					data_list.append(buildTeamInfo(*this));
					data_list.append(t_player->TeamAnnCD);
					data_list.append(robot_cd);
					t_player->sendToClientFillMsg(gate_client::war_team_detail_info_resp, data_list);
				}
			}
		}
		return res_sb;
	}

	///////////////////////////////////////////////////////
	struct teamNPC
	{
		teamNPC()
		{
			memset(this, 0x0, sizeof(teamNPC) - sizeof(BattleEquipList));
			equipList.clear();
		}
		int npcID;
		bool holdMorale;
		int initAttri[characterNum];
		int addAttri[characterNum];
		int armsType;
		double armsModule[armsModulesNum];
		int npcLevel;
		unsigned npcPos;
		int skill_1;
		int skill_2;
		bool is_leader;//�Ƿ��Ƕӳ�
		BattleEquipList equipList;//װ���б�
	};
	//��������
	struct singleArmy
	{
		singleArmy()
		{
			npcList.clear();
		}
		int ArmyID;					//��ͼID
		int ArmyFace;				//����ͷ��
		std::string ArmyName;			//��ͼ����
		int ArmyLevel;					//��ͼ�ȼ�
		int battleValue;					//��ͼս����
		int maxWin;						//��npc�����ʤ
		vector< teamNPC > npcList;		//�����б�
	};

	////////////////////////////////////////////////////////////////////////////////
	struct twconfig				//��ͼ����
	{
		twconfig()
		{
			npcList.clear();
		}
		int tmID;					//����ID
		unsigned tmIDX;//����idx
		int frontId;					//ǰ�õ�ͼID
		int background;					//����ID
		int maxWin;					//��������ʤ��
		unsigned limitMember;//���ٿ�ս����
		vector< singleArmy > npcList;		//�����б�
		acPtrList winBox, winBoxSP;//ʤ������
		unsigned leader_idx;
		int cost_merit;//��ս���ľ���
	};
	SHAREPTR(twconfig, twcPtr);
	UNORDERMAP(int, twcPtr, configMap);
	configMap mapConfigs_;
	class TEAMROBOT
	{
	public:
		TEAMROBOT(const unsigned idx) : IDX(idx)
		{
			uniques.clear();
			robots.clear();
		}
		~TEAMROBOT(){}
		qValue toJson()
		{
			qValue json(qJson::qj_array);
			for (RobotMap::iterator it = robots.begin(); it != robots.end(); ++it)
			{
				sBattlePtr sb = it->second;
				qValue data_json(qJson::qj_array);
				data_json.append(sb->playerNation)
					.append(sb->playerName)
					.append(sb->playerLevel)
					.append(sb->playerFace);
				json.append(data_json);
			}
			return json;
		}
		void insert(sBattlePtr sb)
		{
			if (!sb)return;
			if (robots.find(sb->playerID) == robots.end())//û�е����ӵ�list
			{
				uniques.insert(uniques.begin(), sb->playerID);
				save(sb);
			}
			robots[sb->playerID] = sb;//��������µĶ�������ɵ�
			if (robots.size() > 30)
			{
				robots.erase(uniques.back());
				del(uniques.back());
				uniques.pop_back();
			}
		}
		void random_robot_array()//�������������
		{
			random_shuffle(uniques.begin(), uniques.end());
		}
		sBattlePtr random_robot(const boost::unordered_set<int>& ignored)
		{
			if (uniques.size() < 10)return sBattlePtr();
			INTLIST tmpList = uniques;
			random_shuffle(tmpList.begin(), tmpList.end());
			for (unsigned i = 0; i < tmpList.size(); ++i)
			{
				if (ignored.find(tmpList[i]) != ignored.end())continue;
				return sideBattle::CreateFrom(robots[tmpList[i]]);
			}
			return sBattlePtr();
		}
	private:
		void save(sBattlePtr sb)
		{
			mongo::BSONObj key = BSON(strPlayerID << sb->playerID << "idx" << IDX);
			mongo::BSONObjBuilder obj_builder;
			mongo::BSONArrayBuilder arr_builder;
			for (unsigned i = 0; i < sb->battleMan.size(); ++i)
			{
				mBattlePtr m = sb->battleMan[i];
				mongo::BSONArrayBuilder ias_builder, bas_builder;
				for (unsigned idx = 0; idx < characterNum; ++idx)
				{
					ias_builder.append(m->initialAttri[idx]);
					bas_builder.append(m->battleAttri[idx]);
				}
				arr_builder << BSON("mid" << m->manID << "lv" << m->manLevel << "idx" <<
					m->currentIdx << "ias" << ias_builder.arr() << "bas" << bas_builder.arr());
			}
			obj_builder << strPlayerID << sb->playerID << "idx" << IDX << "lv" <<
				sb->playerLevel << "na" << sb->playerName << "bv" << sb->battleValue <<
				"fa" << sb->playerFace << "m" << arr_builder.arr();
			db_mgr.SaveMongo(DBN::dbTeamWar, key, obj_builder.obj());
		}
		void del(const int playerID)
		{
			mongo::BSONObj key = BSON(strPlayerID << playerID << "idx" << IDX);
			db_mgr.RemoveCollection(DBN::dbTeamWar, key);
		}
		typedef std::vector<int> INTLIST;
		const unsigned IDX;
		INTLIST uniques;
		UNORDERMAP(int, sBattlePtr, RobotMap);
		RobotMap robots;
	};
	SHAREPTR(TEAMROBOT, TEAMROBOTPTR);
	static std::vector<TEAMROBOTPTR> Robots;
	//����ս����
	twcPtr getConfig(const int tmID)
	{
		configMap::iterator it = mapConfigs_.find(tmID);
		if (it == mapConfigs_.end())return twcPtr();
		return it->second;
	}

	int team::robot_join()
	{
		if (wait_member.size() >= teamMaxMember)return err_team_list_over;
		boost::unordered_set<int> ignoreList;
		for (unsigned i = 0; i < wait_member.size(); i++)
		{
			sBattlePtr sb = wait_member[i];
			if (sb->isPlayer)continue;
			ignoreList.insert(sb->playerID);
		}
		sBattlePtr sb = Robots[hit_idx]->random_robot(ignoreList);
		if (!sb)return err_team_war_no_more_robot;
		wait_member.push_back(sb);
		++robot_num;
		for (unsigned i = 0; i < wait_member.size(); ++i)
		{
			sBattlePtr sb = wait_member[i];
			if (!sb->isPlayer)continue;
			playerDataPtr t_player = player_mgr.getOnlinePlayer(sb->playerID);
			if (t_player)
			{
				qValue data_list(qJson::qj_array);
				data_list.append(res_sucess);
				data_list.append(buildTeamInfo(*this));
				data_list.append(t_player->TeamAnnCD);
				data_list.append(robot_cd);
				t_player->sendToClientFillMsg(gate_client::war_team_detail_info_resp, data_list);
			}
		}
		robot_cd = Common::gameTime() + 3;
		return res_sucess;
	}

	void TeamWar::clearTeamWarSystem()
	{
		mapTeam.clear();
		mapTeamPart.clear();
	}

	void TeamWar::initData()
	{
		for (int i = 0; i < 500; ++i)
		{
			teamIDList.push(i);//500����
		}

		{//���ŵ�ͼ���
			cout << "load ./instance/team_war/" << endl;
			FileJsonSeq seq = Common::loadFileJsonFromDir("./instance/team_war/");
			for (unsigned i = 0; i < seq.size(); ++i)
			{
				Json::Value& json = seq[i];
				twcPtr twc = Creator<twconfig>::Create();
				twc->tmID = json["teamID"].asInt();
				twc->frontId = json["frontID"].asInt();
				twc->background = json.isMember("background") ? json["background"].asInt() : 1;
				twc->tmIDX = json["teamIDX"].asUInt();
				twc->maxWin = json["maxWin"].asInt();
				twc->limitMember = json["limitMember"].asUInt();
				twc->winBox = actionFormat(json["box"].asInt());
				twc->winBoxSP = actionFormat(json["boxSP"].asInt());
				Json::Value& army = json["army"];
				twc->leader_idx = json["army_leader"].asUInt();
				twc->cost_merit = json["cost_merit"].asInt();
				if (twc->leader_idx >= army.size())
				{
					twc->leader_idx = army.size() - 1;
				}
				for (unsigned n = 0; n < army.size(); ++n)
				{
					Json::Value& army_json = army[n];
					singleArmy sg_army;
					sg_army.ArmyID = army_json["armyID"].asInt();
					sg_army.ArmyLevel = army_json["armyLV"].asInt();
					sg_army.ArmyName = army_json["armyNA"].asString();
					sg_army.maxWin = army_json["maxWin"].asInt();
					sg_army.battleValue = army_json["battleValue"].asInt();
					sg_army.ArmyFace = army_json["armyFace"].asInt();
					Json::Value& npc_json = army_json["npc"];
					const unsigned leader_idx = army_json["leader_idx"].asUInt();
					for (unsigned idx = 0; idx < npc_json.size(); ++idx)
					{
						teamNPC npc;
						Json::Value& sg_npc = npc_json[idx];
						npc.npcID = sg_npc["npcID"].asInt();
						npc.holdMorale = sg_npc["holdMorale"].asBool();
						for (unsigned cn = 0; cn < characterNum; ++cn)
						{
							npc.initAttri[cn] = sg_npc["initAttri"][cn].asInt();
						}
						npc.armsType = sg_npc["armsType"].asInt();
						for (unsigned cn = 0; cn < armsModulesNum; ++cn)
						{
							npc.armsModule[cn] = sg_npc["armsModule"][cn].asDouble();
						}
						npc.npcLevel = sg_npc["npcLevel"].asInt();
						npc.npcPos = sg_npc["npcPos"].asUInt() % 9;
						npc.skill_1 = sg_npc["skill_1"].asInt();
						npc.skill_2 = sg_npc["skill_2"].asInt();
						npc.is_leader = (idx == leader_idx);
						for (unsigned eq_idx = 0; eq_idx < sg_npc["equip"].size(); ++eq_idx)
						{
							npc.equipList.push_back(BattleEquip(sg_npc["equip"][eq_idx][0u].asUInt(),
								sg_npc["equip"][eq_idx][1u].asInt(),
								sg_npc["equip"][eq_idx][2u].asUInt()));
						}
						sg_army.npcList.push_back(npc);
					}
					twc->npcList.push_back(sg_army);
				}
				mapConfigs_[twc->tmID] = twc;
			}
		};
		{//vip�����������
			VipBuyLimit.clear();
			Json::Value json = Common::loadJsonFile("./instance/team/vip_limit.json");
			for (unsigned i = 0; i < json.size(); ++i)
			{
				VipBuyLimit.push_back(json[i].asUInt());
			}

			VipBuyCost.clear();
			Json::Value json_cost = Common::loadJsonFile("./instance/team/vip_cost.json");
			for (unsigned i = 0; i < json_cost.size(); ++i)
			{
				VipBuyCost.push_back(json_cost[i].asInt());
			}
		};
		{//�����˶�ȡ
			const unsigned loop = TeamSize();
			for (unsigned i = 0; i < loop; ++i)
			{
				Robots.push_back(Creator<TEAMROBOT>::Create(i));
			}
			objCollection objs = db_mgr.Query(DBN::dbTeamWar);
			for (unsigned i = 0; i < objs.size(); ++i)
			{
				mongo::BSONObj& obj = objs[i];
				const unsigned idx = (unsigned)obj["idx"].Int();
				sBattlePtr sb = Creator<sideBattle>::Create();
				sb->playerID = obj["pi"].Int();
				sb->playerLevel = obj["lv"].Int();
				sb->playerName = obj["na"].String();
				sb->battleValue = obj["bv"].Int();
				sb->playerFace = obj["fa"].Int();
				sb->isPlayer = false;
				vector<mongo::BSONElement> elems = obj["m"].Array();
				for (unsigned n = 0; n < elems.size(); ++n)
				{
					mongo::BSONElement& elem = elems[n];
					mBattlePtr mb = Creator<manBattle>::Create();
					mb->manID = elem["mid"].Int();
					mb->manLevel = elem["lv"].Int();
					mb->currentIdx = (unsigned)elem["idx"].Int();
					vector<mongo::BSONElement> ias = elem["ias"].Array();
					for (unsigned idx = 0; idx < ias.size(); ++idx)
					{
						mb->initialAttri[idx] = ias[idx].Int();
					}
					vector<mongo::BSONElement> bas = elem["bas"].Array();
					for (unsigned idx = 0; idx < bas.size(); ++idx)
					{
						mb->battleAttri[idx] = bas[idx].Int();
					}
					cfgManPtr config = man_sys.getConfig(mb->manID);
					if (!config)continue;
					mb->set_skill_1(config->skill_1);
					mb->set_skill_2(config->skill_2);
					mb->armsType = config->armsType;
					memcpy(mb->armsModule, config->armsModules, sizeof(mb->armsModule));
// 					vector < mongo::BSONElement > eqs = elem["eqs"].Array();//��Զ���ڱ���������Բ�Ҫ
// 					for (unsigned idx = 0; idx < eqs.size(); ++idx)
// 					{
// 						mongo::BSONElement& elem = eqs[idx];
// 						mb->equipList.push_back(manBattle::EquipDefine(elem["i"].Int(), elem["l"].Int()));
// 					}
					if (sb->battleMan.empty())
					{
						sb->leaderMan = mb;
					}
					sb->battleMan.push_back(mb);
				}
				Robots[idx]->insert(sb);
			}
			for (unsigned i = 0; i < Robots.size(); ++i)
			{
				Robots[i]->random_robot_array();
			}
		};
	}

	void TeamWar::insertRobot(const unsigned tIDX, sBattlePtr ins_)
	{
		if (tIDX >= Robots.size())return;
		sBattlePtr nsb = sideBattle::CreateFrom(ins_);
		nsb->isPlayer = false;
		Robots[tIDX]->insert(nsb);
	}

	void TeamWar::leave_team(playerDataPtr player)
	{
		teamPtr t = getTeam(player->Team->getTeamID());
		if (t)t->member_leave(player);
		player->Team->setTeamID(-1);
	}

	unsigned TeamWar::TeamSize()
	{
		return mapConfigs_.size();
	}

	void TeamWar::team_own_update(net::Msg& m, Json::Value& r)
	{
		playerDataPtr player = player_mgr.getPlayer(m.playerID);
		if (!player)Return(r, err_illedge);
		player->Team->_auto_update();
	}

	void TeamWar::team_create(net::Msg& m, Json::Value& r)
	{
		if (teamIDList.empty())Return(r, err_war_team_team_full);
		playerDataPtr player = player_mgr.getPlayer(m.playerID);
		if (!player)Return(r, err_illedge);
		if (player->Info->Nation() == Kingdom::null)Return(r, err_illedge);
		if (getTeam(player->Team->getTeamID()))Return(r, err_illedge);
		ReadJsonArray;
		const Kingdom::NATION nation_limit = js_msg[0u].asBool() ? player->Info->Nation() : Kingdom::null;
		const unsigned level_limit = js_msg[1u].asUInt();
		const int hit_id = js_msg[2u].asInt();//�����Ч��
		twcPtr config = getConfig(hit_id);
		if (!config)Return(r, err_illedge);
		if (!player->War->isChallenge(config->frontId))Return(r, err_war_map_limit);

		const bool has_defeat = player->Team->beenWin(config->tmIDX);
		if (has_defeat)
		{
			if (player->Team->HitTimes() < 1)Return(r, err_team_war_times_over);
			if (player->Res->getAction() < 1)Return(r, err_action_not_enough);
		}
		teamPtr t = Creator<team>::Create(teamIDList.front());
		teamIDList.pop();
		t->is_first_hit = !has_defeat;
		t->nation_limit = nation_limit;
		t->level_limit = level_limit;
		t->hit_id = hit_id;
		t->hit_idx = config->tmIDX;
		t->leader_member = BattleHelp::WarPlayer(player);
		t->wait_member.push_back(t->leader_member);
		player->Team->setTeamID(t->team_id);
		//���ӵ�����б�
		mapTeam[t->team_id] = t;
		mapTeamPart[hit_id][t->team_id] = t;
		qValue data_list(qJson::qj_array);
		data_list.append(res_sucess);
		data_list.append(buildTeamInfo(t));
		data_list.append(player->TeamAnnCD);
		data_list.append(t->robot_cd);
		player->sendToClientFillMsg(gate_client::war_team_detail_info_resp, data_list);
		Return(r, res_sucess);
	}

	void TeamWar::team_leave(net::Msg& m, Json::Value& r)
	{
		playerDataPtr player = player_mgr.getPlayer(m.playerID);
		if (!player)Return(r, err_illedge);
		teamPtr t = getTeam(player->Team->getTeamID());
		if (!t)Return(r, err_war_team_not_found);
		const bool is_leader = t->is_leader(player);
		player->Team->leaveTeam();
		r[strMsg][1u] = is_leader;
		Return(r, res_sucess);
	}

	void TeamWar::team_join(net::Msg& m, Json::Value& r)
	{
		playerDataPtr player = player_mgr.getPlayer(m.playerID);
		if (!player)Return(r, err_illedge);
		if (player->Info->Nation() == Kingdom::null)Return(r, err_illedge);
		if (getTeam(player->Team->getTeamID()))Return(r, err_illedge);
		ReadJsonArray;
		const int team_id = js_msg[0u].asInt();
		teamPtr t = getTeam(team_id);
		if (!t)
		{
			r[strMsg][1u] = team_id;
			Return(r, err_war_team_no_found);
		}
		twcPtr config = getConfig(t->hit_id);
		if (!config)Return(r, err_illedge);
		if (!player->War->isChallenge(config->frontId))Return(r, err_war_map_limit);
		if (!t->is_first_hit)
		{
			if (player->Res->getAction() < 1)Return(r, err_action_not_enough);
			if (player->Team->HitTimes() < 1)Return(r, err_team_war_times_over);
		}
		const int res = t->member_join(player);
		if (res != res_sucess)Return(r, res);
		Return(r, res_sucess);
	}

	void TeamWar::change_position(net::Msg& m, Json::Value& r)//����ս��˳��
	{
		playerDataPtr player = player_mgr.getPlayer(m.playerID);
		if (!player)Return(r, err_illedge);
		teamPtr t = getTeam(player->Team->getTeamID());
		if (!t)Return(r, err_illedge);
		if (!t->is_leader(player))Return(r, err_illedge);
		ReadJsonArray;
		const unsigned cg_idx1 = js_msg[0u].asUInt();
		const unsigned cg_idx2 = js_msg[1u].asUInt();
		if (cg_idx1 >= t->wait_member.size() || cg_idx2 >= t->wait_member.size())Return(r, err_illedge);
		sBattlePtr tmp_sb = t->wait_member[cg_idx1];
		t->wait_member[cg_idx1] = t->wait_member[cg_idx2];
		t->wait_member[cg_idx2] = tmp_sb;
		for (unsigned i = 0; i < t->wait_member.size(); ++i)
		{
			sBattlePtr sb = t->wait_member[i];
			if (sb->isPlayer)
			{
				playerDataPtr t_player = player_mgr.getOnlinePlayer(sb->playerID);
				if (t_player)
				{
					qValue data_list(qJson::qj_array);
					data_list.append(res_sucess);
					data_list.append(buildTeamInfo(t));
					data_list.append(t_player->TeamAnnCD);
					data_list.append(t->robot_cd);
					t_player->sendToClientFillMsg(gate_client::war_team_detail_info_resp, data_list);
				}
			}
		}
		Return(r, res_sucess);
	}

	void TeamWar::team_kick(net::Msg& m, Json::Value& r)//�ӳ�����
	{
		playerDataPtr player = player_mgr.getPlayer(m.playerID);
		if (!player)Return(r, err_illedge);
		teamPtr t = getTeam(player->Team->getTeamID());
		if (!t)Return(r, err_illedge);
		if (!t->is_leader(player))Return(r, err_illedge);//���Ƕӳ�������t��
		ReadJsonArray;
		const unsigned idx = js_msg[0u].asUInt();
		if (idx >= t->wait_member.size())Return(r, err_illedge);
		sBattlePtr check_sb = t->wait_member[idx];
		if (check_sb == t->leader_member)Return(r, err_illedge);//�������ߵ��Լ�
		sBattlePtr sb = t->member_leave(idx);
		if (sb && sb->isPlayer)
		{
			playerDataPtr t_player = player_mgr.getCachePlayer(sb->playerID);
			if (t_player)
			{
				static qValue nullMessage(qJson::qj_object);
				t_player->sendToClient(gate_client::war_team_be_kicked_resp, nullMessage);//֪ͨ���Ѿ����߳�
			}
		}
		Return(r, res_sucess);
	}

	void TeamWar::team_update(net::Msg& m, Json::Value& r)
	{
		playerDataPtr player = player_mgr.getPlayer(m.playerID);
		if (!player)Return(r, err_illedge);
		if (player->Info->Nation() == Kingdom::null)Return(r, err_illedge);
		unsigned now = Common::gameTime();
		if (player->TeamCD > now)Return(r, err_team_info_req_too_fast);
		player->TeamCD = now + 3;//3s ����һ��
		player->Team->_auto_update();
		ReadJsonArray;
		const int hitID = js_msg[0u].asInt();
		teamMap updateMap;
		getTeamPart(hitID, updateMap);
		qValue list_json(qJson::qj_array), data_json(qJson::qj_array);
		unsigned num = 0;
		for (teamMap::iterator it = updateMap.begin(); it != updateMap.end();)
		{
			teamPtr ptr = it->second;
			++it;
			qValue sg_team(qJson::qj_array);
			sg_team.append(ptr->team_id);
			sg_team.append(ptr->leader_member->playerFace);
			sg_team.append(ptr->leader_member->playerNation);
			sg_team.append(ptr->leader_name());
			sg_team.append(ptr->leader_member->playerLevel);
			sg_team.append(ptr->level_limit);
			sg_team.append(ptr->nation_limit);
			sg_team.append(unsigned(ptr->wait_member.size()));
			playerDataPtr leader_player = player_mgr.getCachePlayer(ptr->leader_member->playerID);
			if (leader_player)
			{
				sg_team.append(!(leader_player->Team->beenWin(ptr->hit_idx)));
			}
			else
			{
				sg_team.append(false);
			}
			data_json.append(sg_team);
			++num;
			if (num > 199 || it == mapTeam.end())
			{
				list_json.append(res_sucess);
				list_json.append(data_json);
				num = 0;
				player->sendToClientFillMsg(gate_client::war_team_info_part_resp, list_json);
				list_json.toArray();
				data_json.toArray();
			}
		}
		Return(r, res_sucess);
	}

	void TeamWar::team_info_update(net::Msg& m, Json::Value& r)
	{
		playerDataPtr player = player_mgr.getPlayer(m.playerID);
		if (!player)Return(r, err_illedge);
		teamPtr t = getTeam(player->Team->getTeamID());
		if (!t)Return(r, err_war_team_not_found);
		qValue data_list(qJson::qj_array);
		data_list.append(res_sucess);
		data_list.append(buildTeamInfo(t));
		data_list.append(player->TeamAnnCD);
		data_list.append(t->robot_cd);
		player->sendToClientFillMsg(gate_client::war_team_detail_info_resp, data_list);
	}

	void TeamWar::team_first(net::Msg& m, Json::Value& r)//�׹�
	{
		playerDataPtr player = player_mgr.getPlayer(m.playerID);
		if (!player)Return(r, err_illedge);
		unsigned now = Common::gameTime();
		if (player->TeamAnnCD > now)Return(r, err_team_war_ann_too_fast);
		ReadJsonArray;
		const int channel_id = js_msg[0u].asInt();
		teamPtr t = getTeam(player->Team->getTeamID());
		if (!t)Return(r, err_illedge);
		if (player->Team->beenWin(t->hit_idx))Return(r, err_illedge);
		//todo
		qValue data_json(qJson::qj_array);
		data_json.append(chat_sys.ChatPackageQ(player)).
			append(t->hit_id).
			append((unsigned)t->wait_member.size()).
			append(t->team_id).
			append(t->nation_limit).
			append(t->level_limit);
		if (channel_id == CHAT::chat_kingdom)
		{
			chat_sys.despatchKingdom(CHAT::server_team_war_first_invite, player->Info->Nation(), data_json);
		}
		else
		{
			chat_sys.despatchAll(CHAT::server_team_war_first_invite, data_json);
		}
		player->TeamAnnCD = now + 30;//30s ����һ��
		//���������Ϣ
		qValue data_list(qJson::qj_array);
		data_list.append(res_sucess);
		data_list.append(buildTeamInfo(t));
		data_list.append(player->TeamAnnCD);
		data_list.append(t->robot_cd);
		player->sendToClientFillMsg(gate_client::war_team_detail_info_resp, data_list);
		r[strMsg][1u] = channel_id;
		Return(r, res_sucess);
	}

	void TeamWar::team_robot(net::Msg& m, Json::Value& r)//��������ս
	{
		playerDataPtr player = player_mgr.getPlayer(m.playerID);
		if (!player)Return(r, err_illedge);
		teamPtr t = getTeam(player->Team->getTeamID());
		if (!t)Return(r, err_illedge);
		//if (!player->Team->beenWin(t->hit_idx))Return(r, err_illedge);
		unsigned now = Common::gameTime();
		if (t->robot_cd > now)Return(r, err_team_war_robot_too_fast);
		twcPtr config = getConfig(t->hit_id);
		if (!config)Return(r, err_illedge);
		if (player->Res->getMerit() < config->cost_merit)Return(r, err_merit_not_enough);
		const int res = t->robot_join();
		if (res != res_sucess)Return(r, res);
		Return(r, res_sucess);
	}

	sbList npcSide(twcPtr config)
	{
		sbList vec;
		for (unsigned i = 0; i < config->npcList.size(); ++i)
		{
			const singleArmy& sg_army = config->npcList[i];
			sBattlePtr sb = Creator<sideBattle>::Create();
			sb->playerID = sg_army.ArmyID;
			sb->playerName = sg_army.ArmyName;
			sb->isPlayer = false;
			sb->playerLevel = sg_army.ArmyLevel;
			sb->battleValue = sg_army.battleValue;
			sb->winMax = sg_army.maxWin;
			sb->playerFace = sg_army.ArmyFace;
			manList& ml = sb->battleMan;
			ml.clear();
			for (unsigned idx = 0; idx < sg_army.npcList.size(); idx++)
			{
				const teamNPC& npc = sg_army.npcList[idx];
				mBattlePtr man = Creator<manBattle>::Create();
				man->manID = npc.npcID;
				man->holdMorale = npc.holdMorale;
				man->set_skill_1(npc.skill_1);
				man->set_skill_2(npc.skill_2);
				man->armsType = npc.armsType;
				man->manLevel = npc.npcLevel;
				man->currentIdx = npc.npcPos;
				memcpy(man->armsModule, npc.armsModule, sizeof(man->armsModule));
				memcpy(man->initialAttri, npc.initAttri, sizeof(man->initialAttri));
				memcpy(man->battleAttri, npc.initAttri, sizeof(man->battleAttri));
				//memcpy(man->battleAttri, npc.addAttri, sizeof(man->battleAttri));
				man->currentHP = man->getTotalAttri(idx_hp);
				if (npc.is_leader)
				{
					sb->leaderMan = man;
				}
				man->equipList = npc.equipList;
				ml.push_back(man);
			}
			if (!sb->leaderMan && !sb->battleMan.empty())
			{
				sb->leaderMan = sb->battleMan[0];
			}
			vec.push_back(sb);
		}
		return vec;
	}

	bool inSPTime()
	{
		const tm now_tm = Common::toTm(Common::gameTime());
		const unsigned time_limit = now_tm.tm_hour * HOUR + now_tm.tm_min * MINUTE + now_tm.tm_sec;

		const static unsigned FirstStart = 12 * HOUR;
		const static unsigned FirstEnd = 14 * HOUR;
		if (time_limit >= FirstStart && time_limit <= FirstEnd)return true;

		const static unsigned SecondStart = 20 * HOUR;
		const static unsigned SecondEnd = 23 * HOUR;
		if (time_limit >= SecondStart && time_limit <= SecondEnd)return true;

		return false;
	}

	void TeamWar::robot_test()
	{
		twcPtr atk_config = getConfig(1);
		twcPtr def_config = getConfig(11);
		sbList atk = npcSide(atk_config);
		sbList def = npcSide(def_config);
		BattleReportData reportData;
		resBattle::RES res_battle = battle_sys.Team2Team(reportData, atk, def, typeBattle::team_war_story, 3);
		reportData.addReportdeclareT("bg", atk_config->background);
		{
			qValue atk_team_json(qJson::qj_array);
			if (!atk.empty())
			{
				sBattlePtr sb = atk[0];
				atk_team_json.append(sb->playerFace);
				atk_team_json.append(sb->playerName);
				atk_team_json.append(sb->playerLevel);
			}
			reportData.addReportdeclareT("atm", atk_team_json);//������������Ϣ
		};
		{
			qValue def_team_json(qJson::qj_array);
			if (!def.empty())
			{
				sBattlePtr sb = def[0];
				def_team_json.append(sb->playerFace);
				def_team_json.append(sb->playerName);
				def_team_json.append(sb->playerLevel);
			}
			reportData.addReportdeclareT("dtm", def_team_json);//���ط�������Ϣ
		};

		reportData.DoneT(typeBattle::team_war_story);
	}

	void TeamWar::team_fight(net::Msg& m, Json::Value& r)//��ʼս��
	{
		playerDataPtr player = player_mgr.getPlayer(m.playerID);
		if (!player)Return(r, err_illedge);
		teamPtr t = getTeam(player->Team->getTeamID());
		if (!t)Return(r, err_illedge);
		if (!t->is_leader(player))Return(r, err_illedge);
		twcPtr config = getConfig(t->hit_id);
		if (!config)Return(r, err_illedge);
		if (t->wait_member.size() < config->limitMember)Return(r, err_illedge);
		const int cost_merit = t->robot_num > 0 ? config->cost_merit : 0;
		if (cost_merit > player->Res->getMerit())Return(r, err_merit_not_enough);
		sbList atk;
		for (unsigned i = 0; i < t->wait_member.size(); ++i)
		{
			sBattlePtr sb = t->wait_member[i];
			for (unsigned idx = 0; idx < sb->battleMan.size(); ++idx)
			{
				mBattlePtr m = sb->battleMan[idx];
				m->currentHP = m->getTotalAttri(idx_hp);
				if (0 == idx)
				{
					sb->leaderMan = m;
				}
			}
			sb->winMax = config->maxWin;
			if (!sb->isPlayer)
			{
				sb->playerID = i;
			}
			atk.push_back(sb);
		}
		sbList def = npcSide(config);
		BattleReportData reportData;
		resBattle::RES res_battle = battle_sys.Team2Team(reportData, atk, def, typeBattle::team_war_story, 3);
		reportData.addReportdeclareT("bg", config->background);
		reportData.addReportdeclareT("tid", config->tmID);
		//����������//���ӽ���
		const bool isSPTime = inSPTime();
		Json::Value data_json;
		for (unsigned i = 0; i < t->wait_member.size(); ++i)
		{
			sBattlePtr sb = t->wait_member[i];
			Json::Value sg_res;
			sg_res.append(sb->playerID);
			sg_res.append((sb == t->leader_member));
			sg_res.append(sb->playerFace);
			sg_res.append(sb->playerNation);
			sg_res.append(sb->playerName);
			sg_res.append(sb->playerLevel);
			sg_res.append(sb->isPlayer);
			sg_res.append(sb->winNum);
			Json::Value res_json = Json::arrayValue;
			if (sb->isPlayer)
			{
				reportData.addNotice(sb->playerID);
				playerDataPtr c_player = player_mgr.getPlayer(sb->playerID);
				if (!c_player)continue;
				if (!t->is_first_hit)
				{
					c_player->Res->alterAction(-1);
					c_player->Team->alterHitTimes(-1);
				}
				TaskMgr::update(c_player, Task::TeamWarTimes, 1);
				if (resBattle::atk_win == res_battle)
				{
					c_player->Team->tickWin(config->tmIDX);
					//��������
					KingdomPtr kingdom_ptr = kingdom_sys.getData(c_player->Info->Nation());
					const double add = kingdom_ptr ? kingdom_ptr->getAddNum(Kingdom::CTeamWar) / 10000.0 : 0.0;
					if (isSPTime)
					{
						ACTION::Rate c_rate;
						c_rate.rate = 1.0 + (sb->winNum < 2 ? 0.0 : ((sb->winNum + 1) * 0.03)) + add;
						setActionRate(ACTION::merit, c_rate);
						actionDo(c_player, config->winBoxSP);
					}
					else
					{
						ACTION::Rate c_rate;
						c_rate.rate = 1.0 + (sb->winNum < 2 ? 0.0 : ((sb->winNum + 1) * 0.03)) + add;
						setActionRate(ACTION::merit, c_rate);
						actionDo(c_player, config->winBox);
					}
					res_json = actionRes();
					for (unsigned i = 0; i < res_json.size(); ++i)
					{
						const Json::Value& sg_json = res_json[i];
						const int actionID = sg_json[0u].asInt();
						if (actionID == ACTION::item)
						{
							cfgItemPtr item_config = item_sys.getConfig(sg_json[1u].asInt());
							if (item_config &&
								item_config->quality == itemDef::purple &&
								item_config->type == itemDef::type_paper)
							{
								qValue json(qJson::qj_array);
								json.append(chat_sys.ChatPackageQ(c_player));
								json.append(config->tmID);
								json.append(item_config->itemID);
								chat_sys.despatchAll(CHAT::server_teamwar_paper_cast, json);
							}
							if (item_config &&
								item_config->type == itemDef::type_paper)
							{
								TaskMgr::update(c_player, Task::TeamWarPaperNum, sg_json[2u].asInt());
							}
						}
					}
				}
				if (!t->is_first_hit)
				{
					Json::Value exp_json;
					exp_json.append(ACTION::exp);
					exp_json.append(10);
					res_json.append(exp_json);
				}
				sg_res.append(res_json);
				//�ճ�
				c_player->Daily->tickTask(DAILY::team_war_fight);
				Log(DBLOG::strLogTeamWar, c_player, 1, t->team_id, t->hit_id, t->is_first_hit, t->is_leader(c_player), res_battle, t->robot_num, cost_merit, res_json.toIndentString());
			}
			else
			{
				sg_res.append(Json::arrayValue);
			}
			data_json.append(sg_res);
		}
		reportData.addReportdeclareT("wl", data_json);
		{
			qValue atk_team_json(qJson::qj_array);
			atk_team_json.append(t->leader_member->playerFace);
			atk_team_json.append(t->leader_member->playerName);
			atk_team_json.append(t->leader_member->playerLevel);
			reportData.addReportdeclareT("atm", atk_team_json);//������������Ϣ
		};
		{
			qValue def_team_json(qJson::qj_array);
			const singleArmy& sg_army = config->npcList[config->leader_idx];
			def_team_json.append(sg_army.ArmyFace);
			def_team_json.append(sg_army.ArmyName);
			def_team_json.append(sg_army.ArmyLevel);
			reportData.addReportdeclareT("dtm", def_team_json);//���ط�������Ϣ
		};
		reportData.DoneT(typeBattle::team_war_story);
		//�۳������˵ľ���
		player->Res->alterMerit(-cost_merit);
		//ɾ�����//ȫ���˳����
		delTeam(t->team_id);
		Return(r, res_sucess);
	}

	void TeamWar::show_robot(net::Msg& m, Json::Value& r)
	{
		playerDataPtr player = player_mgr.getPlayer(m.playerID);
		if (!player)Return(r, err_illedge);
		teamPtr t = getTeam(player->Team->getTeamID());
		if (!t)Return(r, err_illedge);
		qValue json(qJson::qj_array);
		json.append(res_sucess).
			append(Robots[t->hit_idx]->toJson());
		player->sendToClientFillMsg(gate_client::war_team_show_robot_resp, json);
	}

	void TeamWar::buy_times(net::Msg& m, Json::Value& r)//�����ַ�����
	{
		playerDataPtr player = player_mgr.getPlayer(m.playerID);
		if (!player)Return(r, err_illedge);
		const int vipLV = player->Info->VipLv();
		if (vipLV < 0)Return(r, err_illedge);
		const unsigned buyNum = player->Team->getBuy();
		if(buyNum >= VipBuyLimit[vipLV])Return(r, err_vip_lv_too_low);
		const int cost_cash = VipBuyCost[buyNum];
		if (player->Res->getCash() < cost_cash)Return(r, err_cash_not_enough);
		player->Team->alterHitTimes(1);
		player->Team->alterBuyTimes(1);
		player->Res->alterCash(-cost_cash);
		Log(DBLOG::strLogTeamWar, player, 0, 1, buyNum + 1, cost_cash);
		Return(r, res_sucess);
	}

}

#include "shop_mgr.h"
#include "playerManager.h"

namespace gg
{
	const static int MaxSize = 8;
	const static int TypeOfPos[MaxSize] = { 0, 1, 1, 1, 2, 2, 3, 3 };
	const static int NumOfType[] = { 1, 3, 2, 2 };

	ShopData::ShopData(const Json::Value& info)
	{
		_id = info["id"].asInt();
		_price = info["price"].asInt();
		_buy_num = info["buynum"].asInt();
		_nation = info["nation"].asInt();
		_base_weight = info["weight"].asInt();
		_add_weight = info["wmodule"].asInt();
		_max_weight = info["mweight"].asInt();
		_type = info["index"].asInt();
		Json::Value box = info["box"];
		_box = actionFormatBox(box);
	}

	void ShopDataMgr::init(const Json::Value& info)
	{
		ForEachC(Json::Value, it, info)
		{
			ShopDataPtr ptr = Creator<ShopData>::Create(*it);
			_shop_map[ptr->_id] = ptr;
			if (ptr->_nation == 3)
			{
				for (unsigned i = 0; i <= Kingdom::nation_num; ++i)
					_shop_rd[i][ptr->_type].push_back(ptr);
			}
			else if (ptr->_nation >= 0 || ptr->_nation < Kingdom::nation_num)
			{
				_shop_rd[ptr->_nation][ptr->_type].push_back(ptr);
			}
		}
	}

	ShopDataPtr ShopDataMgr::getShopData(int id)
	{
		ShopDataMap::iterator it = _shop_map.find(id);
		return it != _shop_map.end()? it->second : ShopDataPtr();
	}

	ShopDataList ShopDataMgr::getShopList(playerDataPtr d)
	{
		ShopDataList shop_list;
		int nation = d->Info->Nation();
		if (nation == Kingdom::null)
			nation = Kingdom::nation_num;
		for (unsigned type = 0; type < 4; ++type)
		{
			ShopDataList& rd_vec = _shop_rd[nation][type];
			int total_weight = 0;
			ShopDataMap tmp_map;
			for (unsigned i = 0; i < rd_vec.size(); ++i)
			{
				ShopDataPtr ptr = rd_vec[i];
				ptr->_tmp_weight = ptr->_base_weight + d->LV() * ptr->_add_weight;
				if (ptr->_tmp_weight > ptr->_max_weight)
					ptr->_tmp_weight = ptr->_max_weight;
				if (ptr->_tmp_weight > 0)
				{
					total_weight += ptr->_tmp_weight;
					tmp_map[total_weight] = ptr;
				}
			}
			for (unsigned i = 0; i < NumOfType[type]; ++i)
			{
				if (total_weight < 1)
					break;
				int rd_num = Common::randomBetween(0, total_weight - 1);
				std::pair<ShopDataMap::iterator, bool> ret = tmp_map.insert(make_pair(rd_num, ShopDataPtr()));
				ShopDataMap::iterator it = ret.first;
				if (ret.second)
					tmp_map.erase(it++);
				else
					++it;
				total_weight -= it->second->_tmp_weight;
				shop_list.push_back(it->second);
				tmp_map.erase(it);
			}
		}
		return shop_list;
	}
}

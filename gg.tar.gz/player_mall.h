//###################################
//create by Jim
//2016-04-23
//###################################

#pragma once

#include "auto_do.h"

namespace gg
{
	class playerMall :
		public _auto_player
	{
	public:
		playerMall(playerData* const own);
		~playerMall(){}
		void loadDB();
		int getNum(const int goodID);
		void alterNum(const int goodID, const int val = 1);//�ı����
		void resetNum();
		virtual void _auto_update();
	private:
		virtual bool _auto_save();
		UNORDERMAP(int, int, BUYMAP);
		BUYMAP mapBuy;//����
	};
}
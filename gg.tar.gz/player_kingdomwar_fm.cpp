#include "player_kingdomwar_fm.h"
#include "playerManager.h"
#include "man_system.h"
#include "kingdomwar_def.h"
#include "task_mgr.h"
#include "kingdomwar_system.h"

namespace gg
{
	namespace KingdomWar
	{
		int getManMaxHp(playerDataPtr player, int army_id, playerManPtr man)
		{
			mBattlePtr mbattle = Creator<manBattle>::Create();
			cfgManPtr config = man_sys.getConfig(man->mID());
			if (!config) return 0;
			mbattle->manID = man->mID();
			mbattle->battleValue = man->battleValue();
			mbattle->holdMorale = config->holdMorale;
			mbattle->set_skill_1(config->skill_1);
			mbattle->set_skill_2(config->skill_2);
			mbattle->armsType = config->armsType;
			mbattle->manLevel = man->LV();
			memcpy(mbattle->armsModule, config->armsModules, sizeof(mbattle->armsModule));
			man->toInitialAttri(mbattle->initialAttri);
			man->toBattleAttri(player->KingDomWarFM->getFMId(army_id), mbattle->battleAttri);
			return mbattle->getTotalAttri(idx_hp);
		}
	}

	playerKingdomWarSGFM::playerKingdomWarSGFM(int army_id, playerData* const own)
		: _auto_player(own), _army_id(army_id), _inited(false)
	{
		_fm_id = 0;
		_power = -1;
		_man_list.assign(9, playerManPtr());
	}

	void playerKingdomWarSGFM::load(const mongo::BSONObj& obj)
	{
		_fm_id = obj["i"].Int();
		_inited = obj["t"].Bool();
		const std::vector<mongo::BSONElement> ele = obj["f"].Array();
		for (unsigned i = 0; i < 9; ++i)
			_man_list[i] = Own().Man->findMan(ele[i].Int());
	}

	bool playerKingdomWarSGFM::_auto_save()
	{
		mongo::BSONObj key = BSON(strPlayerID << Own().ID() << "a" << _army_id);
		mongo::BSONObjBuilder obj;
		obj << strPlayerID << Own().ID() << "a" << _army_id << "i" << _fm_id
			<< "t" << _inited;
		{
			mongo::BSONArrayBuilder b;
			ForEachC(ManList, it, _man_list)
				b.append((*it)? (*it)->mID() : -1);
			obj << "f" << b.arr();
		}
		return db_mgr.SaveMongo(DBN::dbPlayerKingdomWarFM, key, obj.obj());
	}

	void playerKingdomWarSGFM::getInfo(qValue& q)
	{
		if (_army_id == 0 && !_inited)
		{
			_inited = true;
			defaultFm();
			TaskMgr::update(Own().getOwnDataPtr(), Task::EnterKingdomWar);
		}
		q.addMember("a", _army_id);
		q.addMember("i", _fm_id);
		q.addMember("v", bv());
		qValue f;
		ForEachC(ManList, it, _man_list)
			f.append((*it)? (*it)->mID() : -1);
		q.addMember("f", f);
	}

	void playerKingdomWarSGFM::getLookUpInfo(qValue& q)
	{
		q.addMember("na", Own().Name());
		q.addMember("nt", Own().Info->Nation());
		q.addMember("lv", Own().LV());
		q.addMember("hp", Own().KingDomWar->armyHp(_army_id));
		q.addMember("bv", bv());
		qValue fm;
		ForEachC(ManList, it, _man_list)
		{
			if (!(*it))
				continue;
			qValue tmp;
			tmp.append((*it)->mID());
			tmp.append(Own().KingDomWar->manHp((*it)->mID()));
			tmp.append(KingdomWar::getManMaxHp(Own().getOwnDataPtr(), _army_id, (*it)));
			tmp.append((*it)->LV());
			fm.append(tmp);
		}
		q.addMember("fm", fm);
	}
	
	void playerKingdomWarSGFM::_auto_update()
	{
		qValue m;
		m.append(res_sucess);
		qValue q(qJson::qj_object);
		getInfo(q);
		m.append(q);
		Own().sendToClientFillMsg(gate_client::kingdom_war_single_formation_resp, m);
	}

	void playerKingdomWarSGFM::clearBV()
	{
		_power = -1;
	}

	void playerKingdomWarSGFM::defaultFm()
	{
		_man_list = Own().WarFM->currentFM();
		_fm_id = Own().WarFM->currentID();
		_power = -1;
		_sign_save();
	}

	int playerKingdomWarSGFM::setFormation(int fm_id, const int fm[9])
	{
		const FMCFG::HOLEVEC& config = playerWarFM::getConfig(fm_id).HOLES;
		boost::unordered_set<int> SAMEMAN;
		for (unsigned i = 0; i < 9; ++i)
		{
			if (fm[i] < 0)continue;
			if (!SAMEMAN.insert(fm[i] / 100).second)return err_fomat_same_man;
			if (Own().KingDomWarFM->manUsed(_army_id, fm[i])) return err_fomat_same_man;
		}
		
		ManList tmpList;
		tmpList.assign(9, playerManPtr());
		if (_fm_id == fm_id)
		{
			for (unsigned i = 0; i < 9; ++i)
			{
				if (fm[i] < 0)continue;
				if (!config[i].Use)continue;
				if (Own().LV() < config[i].LV)return err_format_hole_limit;
				if (config[i].Process > 0 && !Own().War->isChallenge(config[i].Process))return err_format_hole_limit;
				playerManPtr man = Own().Man->findMan(fm[i]);//ÊÇ·ñÂú×ã¿ªÆôÌõ¼þ
				tmpList[i] = man;
			}
			_man_list = tmpList;
		}
		else
		{
			_fm_id = fm_id;
			int idx = 0;
			for (unsigned i = 0; i < 9; ++i)
			{
				if (!config[i].Use)continue;
				if (Own().LV() < config[i].LV)return err_format_hole_limit;
				if (config[i].Process > 0 && !Own().War->isChallenge(config[i].Process))return err_format_hole_limit;
				for(; idx < 9; ++idx)
				{
					if (fm[idx] < 0)
						continue;
					playerManPtr man = Own().Man->findMan(fm[idx++]);//ÊÇ·ñÂú×ã¿ªÆôÌõ¼þ
					tmpList[i] = man;
					break;
				}
			}
			_man_list = tmpList;
		}

		recalFM();
		_sign_auto();
		return res_sucess;
	}

	void playerKingdomWarSGFM::clearManHp()
	{
		ForEach(ManList, it, _man_list)
		{
			if (!(*it)) continue;
			Own().KingDomWar->setManHp((*it)->mID(), 0);
		}
	}

	void playerKingdomWarSGFM::recalFM()
	{
		_power = 0;
		unsigned num = 0;
		for (unsigned i = 0; i < 9; ++i)
		{
			playerManPtr& man = _man_list[i];
			if (!man)continue;
			++num;
			_power += man->battleValue();
		}
		const FMCFG& config = playerWarFM::getConfig(_fm_id);
		const int scLV = Own().Research->getForLV(config.techID);
		_power += (scLV * 7 * num);
		//Èç¹ûÔ½½ç//ÄÇÃ´10ÒÚ
		const static int MaxValue = 1000000000;//10ÒÚ
		if (_power < 0 || _power > MaxValue)
			_power = MaxValue;
	}

	int playerKingdomWarSGFM::upManHp()
	{
		int add = 0;
		ForEach(ManList, it, _man_list)
		{
			if (!*it) continue;
			int max = KingdomWar::getManMaxHp(Own().getOwnDataPtr(), _army_id, *it);
			int cur = Own().KingDomWar->manHp((*it)->mID());
			add += (max - cur);
			Own().KingDomWar->setManHp((*it)->mID(), max);
		}
		return add;
	}

	int playerKingdomWarSGFM::bv()
	{
		if (_power == -1)
			recalFM();
		return _power;
	}

	void playerKingdomWarSGFM::getHpInfo(qValue& q)
	{
		q.addMember("a", _army_id);
		qValue qq;
		ForEachC(ManList, it, _man_list)
		{
			if (!(*it))
				continue;
			qValue tmp;
			tmp.append((*it)->mID());
			tmp.append(Own().KingDomWar->manHp((*it)->mID()));
			tmp.append(KingdomWar::getManMaxHp(Own().getOwnDataPtr(), _army_id, (*it)));
			tmp.append((*it)->LV());
			qq.append(tmp);
		}
		q.addMember("h", qq);
	}

	int playerKingdomWarSGFM::getUpHpCost()
	{
		int cost = 0;
		ForEachC(ManList, it, _man_list)
		{
			if (!(*it))
				continue;
			int cur_hp = Own().KingDomWar->manHp((*it)->mID());
			int max_hp = KingdomWar::getManMaxHp(Own().getOwnDataPtr(), _army_id, (*it));
			if (cur_hp < max_hp)
				cost += (max_hp - cur_hp);
		}
		return cost;
	}

	bool playerKingdomWarSGFM::isDead()
	{
		ForEachC(ManList, it, _man_list)
		{
			if (!(*it))
				continue;
			if (Own().KingDomWar->manHp((*it)->mID()) > 0)
				return false;
		}
		return true;
	}

	playerKingdomWarFM::playerKingdomWarFM(playerData* const own)
		: _auto_player(own)
	{
		for (int i = 0; i < KingdomWar::ArmyNum; ++i)
			_fm_list.push_back(Creator<playerKingdomWarSGFM>::Create(i, own));
	}

	void playerKingdomWarFM::loadDB()
	{
		mongo::BSONObj key = BSON(strPlayerID << Own().ID());
		objCollection objs = db_mgr.Query(DBN::dbPlayerKingdomWarFM, key);
		for (unsigned i = 0; i < objs.size(); ++i)
		{
			int army_id = objs[i]["a"].Int();
			_fm_list[army_id]->load(objs[i]);
		}
	}

	bool playerKingdomWarFM::_auto_save()
	{
		return true;
	}

	void playerKingdomWarFM::_auto_update()
	{
	}

	void playerKingdomWarFM::update()
	{
		qValue m;
		m.append(res_sucess);
		qValue q;
		for (unsigned i = 0; i < _fm_list.size(); ++i)
		{
			qValue tmp(qJson::qj_object);
			_fm_list[i]->getInfo(tmp);
			q.append(tmp);
		}
		m.append(q);
		Own().sendToClientFillMsg(gate_client::kingdom_war_all_formation_resp, m);
	}

	int playerKingdomWarFM::setFormation(int army_id, int fm_id, const int fm[9])
	{
		if (army_id < 0 || army_id >= _fm_list.size())
			return err_illedge;

		return _fm_list[army_id]->setFormation(fm_id, fm);
	}

	bool playerKingdomWarFM::manUsed(int army_id, int man_id) const
	{
		for (unsigned i = 0; i < _fm_list.size(); ++i)
		{
			if (i == army_id)
				continue;
			const ManList& ml = _fm_list[i]->manList();
			ForEachC(ManList, it, ml)
			{
				if ((*it) && (*it)->mID() == man_id)
					return true;
			}
		}
		return false;
	}

	void playerKingdomWarFM::getHpInfo(int army_id, qValue& q)
	{
		_fm_list[army_id]->getHpInfo(q);
	}

	void playerKingdomWarFM::recalFM()
	{
		if (Own().Info->Nation() == Kingdom::null)
			return;
		for (unsigned i = 0; i < _fm_list.size(); ++i)
			_fm_list[i]->clearBV();
	}

	int playerKingdomWarFM::getUpHpCost(int army_id)
	{
		return _fm_list[army_id]->getUpHpCost();
	}

	int playerKingdomWarFM::upManHpByFood(const std::vector<int>& army_id_vec, int& cost)
	{
		cost = 0;
		for (unsigned i = 0; i < army_id_vec.size(); ++i)
			cost += getUpHpCost(army_id_vec[i]);
		if (cost == 0)
			return err_kingdomwar_army_state_full;
		int prev = Own().Res->getFood();
		if (prev < cost)
			return err_food_not_enough;
		Own().Res->alterFood(0 - cost);
		TaskMgr::update(Own().getOwnDataPtr(), Task::KingdomWarUseFoodNum, cost);
		int add = 0;
		for (unsigned i = 0; i < army_id_vec.size(); ++i)
			add += upManHp(army_id_vec[i]);
		int exploit = kingdomwar_sys.hpExploit(Own().LV(), add);
		if (exploit < 1)
			exploit = 1;
		playerKingdomWar::ExploitReason = KingdomWar::UpManHp;
		Own().Res->alterExploit(exploit);
		Log(DBLOG::strLogKingdomWar, Own().getOwnDataPtr(), 7, prev, Own().Res->getFood());
		return res_sucess;
	}
}

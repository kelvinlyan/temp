#include "player_search.h"
#include "search_system.h"
#include "res_code.h"
#include "playerManager.h"
#include "task_mgr.h"
#include "item_system.h"

namespace gg
{
	playerSearch::playerSearch(playerData* const own)
		: _auto_player(own), _cd(0), _id(0), _type(0), _flush_times(0), _search_times(0)
	{
	}

	void playerSearch::loadDB()
	{
		mongo::BSONObj key = BSON(strPlayerID << Own().ID());
		mongo::BSONObj obj = db_mgr.FindOne(DBN::dbPlayerSearch, key);
		
		if (obj.isEmpty()) 
			return;

		checkNotEoo(obj["cd"])
			_cd = obj["cd"].Int();
		checkNotEoo(obj["id"])
			_id = obj["id"].Int();
		checkNotEoo(obj["ty"])
			_type = obj["ty"].Int();
		checkNotEoo(obj["ft"])
			_flush_times = obj["ft"].Int();
		checkNotEoo(obj["st"])
			_search_times = obj["st"].Int();
		checkNotEoo(obj["sr"])
		{
			std::vector<mongo::BSONElement> ele = obj["sr"].Array();
			for (unsigned i = 0; i < ele.size(); ++i)
				_records.push_back(Search::ShopRecord(ele[i]["id"].Int(), ele[i]["bt"].Int()));
		}
	}

	bool playerSearch::_auto_save()
	{
		mongo::BSONObj key = BSON(strPlayerID << Own().ID());
		mongo::BSONObjBuilder obj;
		obj << strPlayerID << Own().ID() << "cd" << _cd << "id" << _id
			<< "ty" << _type << "ft" << _flush_times << "st" << _search_times;
		{
			mongo::BSONArrayBuilder b;
			ForEachC(SearchShopRecords, it, _records)
				b.append(BSON("id" << it->_id << "bt" << it->_buy_times));
			obj << "sr" << b.arr();
		}
		return db_mgr.SaveMongo(DBN::dbPlayerSearch, key, obj.obj());
	}

	void playerSearch::_auto_update()
	{
		update();
	}

	void playerSearch::update()
	{
		Json::Value res;
		res[strMsg][0u] = res_sucess;
		res[strMsg][1u]["id"] = _id;
		res[strMsg][1u]["cd"] = _cd;
		res[strMsg][1u]["ty"] = _type;
		res[strMsg][1u]["st"] = _search_times;
		Own().sendToClient(gate_client::player_search_data_resp, res);
	}

	int playerSearch::searchFor(int id, int type, bool batch, Json::Value& r)
	{
		if (_id != 0)
			return err_illedge;
		SearchConfig ptr = search_sys.getConfig(id);
		if (!ptr)
			return err_illedge;
		if (type < 1 || type > ptr->_silver.size())
			return err_illedge;
		if (Own().Info->VipLv() < ptr->_vip[type - 1])
			return err_vip_lv_too_low;

		int need_silver = 0;
		int need_wood = 0;
		int need_iron = 0;
		int need_gold = 0;
		unsigned times = batch? 10 : 1;
		for (unsigned i = 0; i < times; ++i)
			need_silver += ptr->_silver[type - 1].get(Own().LV(), _search_times + i);
		for (unsigned i = 0; i < times; ++i)
			need_wood += ptr->_wood[type - 1].get(Own().LV(), _search_times + i);
		for (unsigned i = 0; i < times; ++i)
			need_iron += ptr->_iron[type - 1].get(Own().LV(), _search_times + i);
		for (unsigned i = 0; i < times; ++i)
			need_gold += ptr->_gold[type - 1].get(Own().LV(), _search_times + i);

		if (Own().Res->getSilver() < need_silver)
			return err_silver_not_enough;
		if (Own().Res->getWood() < need_wood)
			return err_wood_not_enough;
		if (Own().Res->getIron() < need_iron)
			return err_iron_not_enough;
		if (Own().Res->getCash() < need_gold)
			return err_gold_not_enough;

		Own().Res->alterSilver(0 - need_silver);
		Own().Res->alterWood(0 - need_wood);
		Own().Res->alterIron(0 - need_iron);
		Own().Res->alterCash(0 - need_gold);
		
		if (batch)
			batchSearch(id, type, r);
		else
			oneSearch(id, type);

		_search_times += times;
		TaskMgr::update(Own().getOwnDataPtr(), Task::SearchTimes, times);
		Log(DBLOG::strLogSearch, Own().getOwnDataPtr(), 0, id, type, need_silver, need_wood, need_iron, need_gold, batch? 1 : 0);
		_sign_auto();
		return res_sucess;
	}

	int playerSearch::oneSearch(int id, int type)
	{
		SearchConfig ptr = search_sys.getConfig(id);
		if (!ptr) return err_illedge;
		
		_id = id;
		_type = type;
		_cd = Common::gameTime() + ptr->_need_time;
		return res_sucess;
	}

	int playerSearch::batchSearch(int id, int type, Json::Value& r)
	{
		SearchConfig ptr = search_sys.getConfig(id);
		if (!ptr) return err_illedge;
		
		acPtrList& rw = ptr->_reward[type - 1];
		for (unsigned i = 0; i < 10; ++i)
		{
			actionDo(Own().getOwnDataPtr(), rw, 1, false);
			Json::Value tmp = actionRes();
			updateTask(tmp);
			r.append(tmp);
			Log(DBLOG::strLogSearch, Own().getOwnDataPtr(), 3, id, type, 0, 0, 0, 0, 0, tmp.toIndentString());
		}

		return res_sucess;
	}

	void playerSearch::updateTask(const Json::Value& r)
	{
		ForEachC(Json::Value, it, r)
		{
			const Json::Value& rw = *it;
			if (rw[0u].asInt() == ACTION::item && (rw[1u].asInt() / 10000 == 6))
			{
				TaskMgr::update(Own().getOwnDataPtr(), Task::SearchPaperNum, rw[2u].asInt());
				int item_id = rw[1u].asInt();
				cfgItemPtr conf = item_sys.getConfig(item_id);
				if (conf)
					TaskMgr::update(Own().getOwnDataPtr(), Task::SearchPaperNumOfColor, conf->quality, rw[2u].asInt());
			}
		}
	}

	int playerSearch::getReward(int id, Json::Value& r)
	{
		if (_id == 0 || id != _id)
			return err_illedge;
		SearchConfig ptr = search_sys.getConfig(id);
		if (!ptr)
		{
			LogE << "search id " << id << " not found" << LogEnd;
			return err_illedge;
		}
		if (Common::gameTime() < _cd)
			return err_illedge;
		
		acPtrList& reward = ptr->_reward[_type - 1];
		int res = actionDo(Own().getOwnDataPtr(), reward, 1, false);
		if (res == res_sucess)
		{
			_id = 0;
			_cd = 0;
			r = actionRes();
			updateTask(r);
			Log(DBLOG::strLogSearch, Own().getOwnDataPtr(), 1, id, _type, 0, 0, 0, 0, 0, r.toIndentString());
			_sign_auto();
		}
		return res;
	}

	int playerSearch::cleanCd(int id)
	{
		if (_id == 0 || _id != id)
			return err_illedge;

		unsigned cur_time = Common::gameTime();
		if (_cd > cur_time)
		{
			int cost = (_cd - cur_time) / 60 + 1;
			if (Own().Res->getCash() < cost)
				return err_cash_not_enough;
			Own().Res->alterCash(0 - cost);
			_cd = 0;
			_sign_auto();
		}
		return res_sucess;
	}

	void playerSearch::updateShop()
	{
		checkShopRecord();

		Json::Value res;
		res[strMsg][0u] = res_sucess;
		Json::Value& shop = res[strMsg][1u]["sl"];
		shop = Json::arrayValue;
		ForEachC(SearchShopRecords, it, _records)
		{
			Json::Value tmp;
			tmp.append(it->_id);
			tmp.append(it->_buy_times);
			shop.append(tmp);
		}
		res[strMsg][1u]["ft"] = _flush_times;
		Own().sendToClient(gate_client::player_search_shop_info_resp, res);
	}

	int playerSearch::buy(int pos, int id, Json::Value& r)
	{
		if(pos <= 0 || pos > _records.size())
			return err_illedge;

		Search::ShopRecord& rcd = _records[pos - 1];
		if (rcd._id != id)
			return err_illedge;

		SearchShopData ptr = search_sys.getShopData(id);
		if (!ptr)
			return err_illedge;

		if (rcd._buy_times >= ptr->_buy_times)
			return err_goods_sale_out;
		
		if (Own().Res->getSearchPoints() < ptr->_consume_con)
			return err_search_point_not_enough;

		int res = actionDoBox(Own().getOwnDataPtr(), ptr->_box, false);
		if (res == res_sucess)
		{
			int tmp = Own().Res->getSearchPoints();
			++rcd._buy_times;
			Own().Res->alterSearchPoints(0 - ptr->_consume_con);
			updateShop();
			_sign_save();
			r = actionRes();
			Log(DBLOG::strLogSearch, Own().getOwnDataPtr(), 2, tmp, Own().Res->getSearchPoints(), id, 1);
		}
		else
		{
			Json::Value error_code = actionError();
			res = error_code[0u][1u].asInt();
		}

		return res;
	}

	int playerSearch::flush()
	{
		int cost = search_sys.getFlushCost(_flush_times);
		if (Own().Res->getCash() < cost)
			return err_gold_not_enough;
		Own().Res->alterCash(0 - cost);
		++_flush_times;
		_records.clear();
		checkShopRecord();
		updateShop();
		return res_sucess;
	}

	void playerSearch::checkShopRecord()
	{
		if (_records.empty())
		{
			std::vector<int> id_list;	

			search_sys.getShopList(Own().Info->Nation(), id_list);

			for (unsigned i = 0; i < id_list.size(); ++i)
				_records.push_back(Search::ShopRecord(id_list[i], 0));

			_sign_save();
		}
	}

	void playerSearch::dailyTick()
	{
		_records.clear();
		checkShopRecord();
		_search_times = 0;
		_flush_times = 0;
	}
}

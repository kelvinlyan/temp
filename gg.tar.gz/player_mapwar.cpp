#include "player_mapwar.h"
#include "dbDriver.h"
#include "map_war.h"
#include "res_code.h"
#include "task_mgr.h"

namespace gg
{

	playerChatperData::playerChatperData(playerData* const own) :_auto_player(own)
	{
		chapterStartNum = 0;
		chapterId = 0;
		pmapDataMap.clear();
		//speEventMap.clear();
		rewardItem.clear();
	}

	playerChatperData::playerChatperData(playerData* const own, int cChapterId) : _auto_player(own)
	{
		chapterStartNum = 0;
		chapterId = cChapterId;
		pmapDataMap.clear();
		//speEventMap.clear();
		rewardItem.clear();
	}

	void playerChatperData::_auto_update()
	{
		qValue res(qJson::qj_array);
		res.append(res_sucess).append(formatJson());
		//cout << res.toIndentString() << endl;
		Own().sendToClientFillMsg(gate_client::map_war_base_resp, res);
	}

	bool playerChatperData::_auto_save()
	{	
		mongo::BSONObj key = BSON(strPlayerID << Own().ID());
		mongo::BSONObjBuilder obj;
		obj << strPlayerID << Own().ID();

		mongo::BSONArrayBuilder mapData;
		for (MapDataMap::iterator it = pmapDataMap.begin(); it != pmapDataMap.end(); it++)
		{
			mongo::BSONObj map_obj = BSON("mi" << it->second->mapId << //��ͼID
				"sn" << it->second->starNum << //����
				"st" << it->second->mState << //״̬
				"swt" << it->second->sweepTimes << //����ɨ���Ĵ���
				"ct" << it->second->challengeTimes << //������ս�Ĵ���
				"re" << it->second->reChallengeTimes //���ô���
				);
			mapData << map_obj;
		}
		obj << "md" << mapData.arr();
		obj << "cs" << chapterStartNum;
		
		mongo::BSONArrayBuilder rewardData;
		for (RewardItemMap::iterator it = rewardItem.begin(); it != rewardItem.end(); it++)
		{
			mongo::BSONObj reward_obj = BSON("rs" << it->second->rState << "nm" << it->second->starNum);
			rewardData << reward_obj;
		}
		obj << "rw" << rewardData.arr();

// 		mongo::BSONArrayBuilder eventData;
// 		for (SpeEventMap::iterator it = speEventMap.begin(); it != speEventMap.end(); it++)
// 		{
// 			mongo::BSONObjBuilder event_obj;
// 
// 			mongo::BSONArrayBuilder conArr;
// 			for (ComConMap::iterator cIt = it->second->conMap.begin(); cIt != it->second->conMap.end(); cIt++)
// 			{
// 				mongo::BSONObj con_obj = BSON("id" << cIt->second->id << "ci" << cIt->second->commonId << "tn" << cIt->second->tNum << "nm" << cIt->second->num);
// 				conArr << con_obj;
// 			}
// 
// 			event_obj << "co" << conArr.arr();
// 			event_obj << "id" << it->second->eventId;
// 			event_obj << "et" << it->second->endTime;
// 			event_obj << "st" << it->second->sSteae;
// 			eventData << event_obj.obj();
// 		}
// 		obj << "ev" << eventData.arr();

		return db_mgr.SaveMongo(DBN::dbPlayerWar + Common::toString(chapterId), key, obj.obj());
	}

	qValue playerChatperData::formatJson()
	{
		qValue res(qJson::qj_object);
		qValue mapJson(qJson::qj_object);
		for (MapDataMap::iterator it = pmapDataMap.begin(); it != pmapDataMap.end(); it++)
		{
			qValue mdJson(qJson::qj_object);
			mdJson.addMember("sn", it->second->starNum);
			mdJson.addMember("ms", it->second->mState);
			mdJson.addMember("ct", it->second->challengeTimes);
			mdJson.addMember("rt", map_sys.ReNum(Own().Info->VipLv()) - it->second->reChallengeTimes);
			mdJson.addMember("ctt", countChallenge(it->second->mapId));
			mdJson.addMember("trr", countReChanllengte(it->second->mapId));
			mapJson.addMember(Common::toString(it->second->mapId), mdJson);
		}
		res.addMember("mp", mapJson);
		qValue rewardJson(qJson::qj_object);
		for (RewardItemMap::iterator it = rewardItem.begin(); it != rewardItem.end(); it++)
		{
			rewardJson.addMember(Common::toString(it->second->starNum), it->second->rState);
		}
		res.addMember("sn", chapterStartNum);
		res.addMember("rw", rewardJson);
		res.addMember("ch", chapterId);
// 		qValue speEvenJson(qJson::qj_object);
// 		for (SpeEventMap::iterator it = speEventMap.begin(); it != speEventMap.end(); it++)
// 		{
// 			if (it->second->sSteae == eventMap::goIng)
// 			{
// 				qValue obj(qJson::qj_object); 
// 				obj.addMember("t", it->second->endTime);
// 				int lt = 0;
// 				speEventCfgPtr eventPtr = map_sys.getSpeEventConfig(it->second->eventId);
// 				if (eventPtr && eventPtr->limitTime != -1)
// 				{
// 					lt = it->second->endTime - eventPtr->limitTime;
// 				}
// 				obj.addMember("st", lt);
// 				speEvenJson.addMember(Common::toString(it->second->eventId), obj);
// 			}
// 		}
// 		res.addMember("ev", speEvenJson);
		return res;
	}

	void	 playerChatperData::createmapData()
	{
		chapterCfgPtr config = map_sys.getConfig(chapterId);
		if (!config) return;

		rewardItemMap::iterator reIt = config->rewardItemArry.begin();

		for (reIt; reIt != config->rewardItemArry.end(); reIt++)
		{
			SelfRewardItemPtr rewartItemPtr = Creator<selfRewardItem>::Create();
			rewartItemPtr->starNum = reIt->second->starNum;
			rewartItemPtr->rState = warReward::Unfinished;
			rewardItem[rewartItemPtr->starNum] = rewartItemPtr;
		}

		int firstMapId = config->firstMpdId;
		mapDataMap::iterator maIt = config->mapData.find(firstMapId);
		if (maIt == config->mapData.end()) { return; }
		insertMapData(firstMapId);
	}

	void playerChatperData::insertMapData(int mapId)
	{
		MapDataMap::iterator it = pmapDataMap.find(mapId);
		if (it != pmapDataMap.end()) return;
		mapDateCfgPtr configMap = map_sys.getMapConfig(mapId);
		if (!configMap) return;
		SelfMapDataPtr mapData = Creator<selfMapData>::Create();
		mapData->mapId = mapId;
		mapData->starNum = 0;
		mapData->challengeTimes = configMap->chanllengeTimes;
		mapData->reChallengeTimes = 0;
		mapData->mState = warMap::CanCH;
		pmapDataMap[mapData->mapId] = mapData;
		//��鴥���������¼�
		//insertEvent(mapId, eventMap::enterMap);
	}

	int playerChatperData::setMapStar(int mapId, int starNum)
	{
		MapDataMap::iterator it = pmapDataMap.find(mapId);
		if (it != pmapDataMap.end())
		{
			if (it->second->mState == warMap::Faile){ return 0; }
			it->second->mState = warMap::Success;
			int num = starNum - it->second->starNum;
			if (num > 0) 
			{ 
				chapterStartNum = chapterStartNum + num; 
				it->second->starNum = starNum;
				TaskMgr::update(Own().getOwnDataPtr(), Task::WarStarSum, num);
				TaskMgr::update(Own().getOwnDataPtr(), Task::WarMapStar, mapId, starNum);
				_sign_auto();
			}
			checkItem();
			return num;
		}
		return 0;
	}

	void playerChatperData::checkItem()
	{
		RewardItemMap::iterator it = rewardItem.begin();
		for (it; it != rewardItem.end(); it++)
		{
			if (it->second->starNum <= chapterStartNum && it->second->rState == warReward::Unfinished)
			{
				it->second->rState = warReward::Notrev;
				_sign_auto();
			}
		}
	}

// 	void playerChatperData::eventCon(eventMap::eventType type, int commonId, int num)
// 	{
// 		for (SpeEventMap::iterator it = speEventMap.begin(); it != speEventMap.end(); it++)
// 		{
// 			if (it->second->sSteae != eventMap::goIng) 	continue;
// 
// 			if (it->second->endTime != 0 && Common::gameTime() >= (unsigned)it->second->endTime)
// 			{
// 				it->second->sSteae = eventMap::faileState;
// 				continue;
// 			}
// 
// 			int updateS = false;
// 			//���
// 			for (ComConMap::iterator conIt = it->second->conMap.begin(); conIt != it->second->conMap.end(); conIt++)
// 			{
// 				if (conIt->second->id != type) continue;
// 				
// 				switch (type)
// 				{
// 				case gg::eventMap::None:
// 					break;
// 				case gg::eventMap::SuccessMap:
// 				{
// 					if (conIt->second->commonId == commonId)
// 					{
// 						conIt->second->num = conIt->second->num + 1;
// 					}
// 					break;
// 				}
// 				default:
// 					break;
// 				}
// 			}
// 		}
// 		checkEven();
// 	}

// 	void	 playerChatperData::checkEven()
// 	{
// 		bool updateS = false;
// 		for (SpeEventMap::iterator it = speEventMap.begin(); it != speEventMap.end(); it ++)
// 		{
// 			if (it->second->sSteae != eventMap::goIng) continue;
// 			if (it->second->endTime != 0 && (int)Common::gameTime() >= it->second->endTime)
// 			{
// 				it->second->sSteae = eventMap::faileState;
// 				updateS = true;
// 			}
// 			selfSpeEventPtr eventPtr = it->second;
// 			for (ComConMap::iterator eit = eventPtr->conMap.begin(); eit != eventPtr->conMap.end(); eit++)
// 			{
// 				if (eit->second->num >= eit->second->tNum)
// 				{
// 					eit->second->num = eit->second->tNum;
// 					it->second->sSteae = eventMap::finishState;
// 					updateS = true;
// 				}
// 			}
// 		}
// 		if (updateS) _sign_auto();
// 	}

	void playerChatperData::reChanllengeTimeDaily()
	{
		for (MapDataMap::iterator it = pmapDataMap.begin(); it != pmapDataMap.end(); it++)
		{
			mapDateCfgPtr mapConfig = map_sys.getMapConfig(it->second->mapId);
			if (mapConfig)
			{
				it->second->challengeTimes = mapConfig->chanllengeTimes;
				it->second->reChallengeTimes = 0;
			}
		}
		_sign_auto();
	}

	bool playerChatperData::reChanllengeAcc(int mapId)
	{
		MapDataMap::iterator it = pmapDataMap.find(mapId);
		if (it == pmapDataMap.end() || it->second->reChallengeTimes >= map_sys.ReNum(Own().Info->VipLv())) return false;
		mapDateCfgPtr mapConfig = map_sys.getMapConfig(mapId);
		if (mapConfig)
		{
			it->second->reChallengeTimes++;
			it->second->challengeTimes = mapConfig->chanllengeTimes;
			_sign_auto();
			return true;
		}
		return false;
	}

	void playerChatperData::subChanllengeTime(int mpaId, int times)
	{
		MapDataMap::iterator it = pmapDataMap.find(mpaId);
		if (it == pmapDataMap.end()) return;
		it->second->challengeTimes = it->second->challengeTimes - times;
		_sign_auto();
	}

// 	void playerChatperData::insertEvent(int mapId, eventMap::eventEve typeE, int starNum, sBattlePtr atk)
// 	{
// 		vector<int> eventList = map_sys.getEventIDList(mapId);
// 		for (vector<int>::iterator it = eventList.begin(); it != eventList.end(); it++)
// 		{
// 			int eventId = *it;
// 			speEventCfgPtr ptr = map_sys.getSpeEventConfig(eventId);
// 			if (!ptr) continue;
// 			if (!Common::randomOk(ptr->pro)) continue;
// 			bool isInsert = false;
// 			switch (typeE)
// 			{
// 			case gg::eventMap::enterMap:
// 			{
// 				if (ptr->mapId == mapId) isInsert = true;
// 				isInsert = true;
// 				break;
// 			}
// 			case gg::eventMap::starMap:
// 			{
// 				if (!ptr->cleanMapStar.empty() && ptr->cleanMapStar[0] == mapId && ptr->cleanMapStar[1] == starNum)
// 				{
// 					isInsert = true;
// 				}
// 				break;
// 			}
// 			case gg::eventMap::manMap:
// 			{
// 				if (!ptr->manCleanMap.empty() && ptr->manCleanMap[0] == mapId)
// 				{
// 					for (manList::iterator it = atk->battleMan.begin(); it != atk->battleMan.end(); it++)
// 					{
// 						if ((*it)->manID == ptr->manCleanMap[1])
// 						{
// 							isInsert = true;
// 						}
// 					}
// 				}
// 				break;
// 			}
// 			default:
// 				break;
// 			}
// 
// 			if (isInsert)
// 			{
// 				selfSpeEventPtr eventPtr = Creator<selfSpeEvent>::Create();
// 				eventPtr->eventId = ptr->eventId;
// 				if (ptr->limitTime != -1) eventPtr->endTime = Common::gameTime() + ptr->limitTime;
// 
// 				for (completeConCfgMap::iterator it = ptr->conList.begin(); it != ptr->conList.end(); it++)
// 				{
// 					SselfComConPtr objPtr = Creator<selfComCon>::Create();
// 					objPtr->id = (eventMap::eventType)it->second->id;
// 					objPtr->commonId = it->second->commonId;
// 					objPtr->tNum = it->second->num;
// 
// 					eventPtr->conMap[objPtr->id] = objPtr;
// 				}
// 
// 				SpeEventMap::iterator eit = speEventMap.find(eventId);
// 
// 				if (eit != speEventMap.end())
// 				{
// 					if (eit->second->sSteae == eventMap::goIng) return;
// 					if (eit->second->sSteae == eventMap::finishState && ptr->repSuc == 1)
// 						speEventMap[eventPtr->eventId] = eventPtr;
// 					if (eit->second->sSteae == eventMap::faileState && ptr->repAct == 1)
// 						speEventMap[eventPtr->eventId] = eventPtr;
// 				}
// 				else
// 				{
// 					speEventMap[eventPtr->eventId] = eventPtr;
// 
// 				}
// 				_sign_auto();
// 			}
// 		}
// 	}

	int playerChatperData::getRewared(int rewardId)
	{
		RewardItemMap::iterator it = rewardItem.find(rewardId);
		if (it == rewardItem.end()) return err_charpter_reward_id_not_found;
		if (it->second->rState != warReward::Notrev) return err_charpter_reward_state_not_recv;
		ACTION::BoxList acPtr = map_sys.getChapterRewardList(chapterId, rewardId);
		int res = actionDoBox(Own().getOwnDataPtr(), acPtr, false);
		if (res == res_sucess)
		{
			it->second->rState = warReward::Finish;
			_sign_auto();
		}
		return res;
	}

	int playerChatperData::countChallenge(int mapId)
	{
		mapDateCfgPtr mapConfig = map_sys.getMapConfig(mapId);
		if (mapConfig)
		{
			return  mapConfig->chanllengeTimes;
		}
		return 0;
	}

	int playerChatperData::countReChanllengte(int mapId)
	{
		mapDateCfgPtr mapConfig = map_sys.getMapConfig(mapId);
		if (mapConfig)
		{
			return map_sys.ReNum(Own().Info->VipLv());
		}
		return 0;
	}
////////////////////////////////////////////////////////////////////////////////////
///////////////////////////////////Mgr//////////////////////////////////////////////

	playerMapWarMgr::playerMapWarMgr(playerData* const own) :_auto_player(own)
	{
		selfChapterDate.clear();
		chChapterId = 0;
		chMaxMapId = 0;
	}

	void playerMapWarMgr::loadDB()
	{
		totalStartNum = 0;

		mongo::BSONObj key = BSON(strPlayerID << Own().ID());

		int maxNum = map_sys.getMaxChapterNum();
		int minNum = map_sys.getMinChapterNum();
		for (int n = minNum; n < maxNum + 1; n++)
		{
			mongo::BSONObj obj = db_mgr.FindOne(DBN::dbPlayerWar + Common::toString(n), key);
			if (obj.isEmpty()) break;
			playerChatperDataPtr chatperData = Creator<playerChatperData>::Create(_Own);
			chatperData->chapterStartNum = obj["cs"].Int();
			chatperData->chapterId = n;
			if (!obj["md"].eoo())
			{
				vector<mongo::BSONElement> sets = obj["md"].Array();
				for (unsigned i = 0; i < sets.size(); i++)
				{
					SelfMapDataPtr mapData = Creator<selfMapData>::Create();
					mapData->mapId = sets[i]["mi"].Int();
					mapData->starNum = sets[i]["sn"].Int();
					mapData->mState = (warMap::mapState)sets[i]["st"].Int();
					mapData->sweepTimes = sets[i]["swt"].Int();
					mapData->challengeTimes = sets[i]["ct"].Int();
					if (!sets[i]["re"].eoo())
						mapData->reChallengeTimes = sets[i]["re"].Int();
					else
						mapData->reChallengeTimes = 0;
					chatperData->pmapDataMap[mapData->mapId] = mapData;
					//�ۻ��ܵ�����
					totalStartNum = totalStartNum + mapData->starNum;
					if (chMaxMapId < mapData->mapId && mapData->mState == warMap::Success)
						chMaxMapId = mapData->mapId;
				}
			}
			if (!obj["rw"].eoo())
			{
				vector<mongo::BSONElement> sets = obj["rw"].Array();
				for (unsigned i = 0; i < sets.size(); i++)
				{
					SelfRewardItemPtr rewarData = Creator<selfRewardItem>::Create();
					rewarData->rState = (warReward::rewardState)sets[i]["rs"].Int();
					rewarData->starNum = sets[i]["nm"].Int();
					chatperData->rewardItem[rewarData->starNum] = rewarData;
				}
			}
			
// 			if (!obj["ev"].eoo())
// 			{
// 				vector<mongo::BSONElement> sets = obj["ev"].Array();
// 				for (unsigned i = 0; i < sets.size(); i++)
// 				{
// 					selfSpeEventPtr eventPtr = Creator<selfSpeEvent>::Create();
// 					eventPtr->eventId = sets[i]["id"].Int();
// 					eventPtr->endTime = sets[i]["et"].Int();
// 
// 
// 					vector<mongo::BSONElement> coSets = sets[i]["co"].Array();
// 					for (unsigned ci = 0; ci < coSets.size(); ci++)
// 					{
// 						SselfComConPtr ptr = Creator<selfComCon>::Create();
// 						ptr->id = (eventMap::eventType)coSets[ci]["id"].Int();
// 						ptr->commonId = coSets[ci]["ci"].Int();
// 						ptr->tNum = coSets[ci]["tn"].Int();
// 						ptr->num = coSets[ci]["nm"].Int();
// 						eventPtr->conMap[ptr->id] = ptr;
// 					}
// 					chatperData->speEventMap[eventPtr->eventId] = eventPtr;
// 				}
// 			}

			selfChapterDate[n] = chatperData;
			if (n > chChapterId){ chChapterId = n; }
		}
	}

	playerChatperDataPtr playerMapWarMgr::getChatperData(int chapterId)
	{
		ChapterDateMap::iterator it = selfChapterDate.find(chapterId);
		if (it != selfChapterDate.end())return it->second;
		return playerChatperDataPtr();
	}


	SelfMapDataPtr playerMapWarMgr::getMapData(int mapId)
	{
		int chapterId = map_sys.getChapterId(mapId);
		if (chapterId == 0) 
		{ 
			return SelfMapDataPtr(); 
		}
		ChapterDateMap::iterator it = selfChapterDate.find(chapterId);
		if (it == selfChapterDate.end()) 
		{ 
			return SelfMapDataPtr(); 
		}
		MapDataMap::iterator mIt = it->second->pmapDataMap.find(mapId);
		if (mIt == it->second->pmapDataMap.end()) 
		{ 
			return SelfMapDataPtr();
		}
		return mIt->second;
	}

	void playerMapWarMgr::changeStart_gm(int mapId, int starNum)
	{
		//��������
		int chapterId = map_sys.getChapterId(mapId);
		if (chapterId == 0 || starNum <= 0 || starNum > 5) { return; }
		ChapterDateMap::iterator it = selfChapterDate.find(chapterId);
		if (it == selfChapterDate.end()) { return; }

		int num = it->second->setMapStar(mapId, starNum);
		changeMaxMapId(mapId);
		totalStartNum = totalStartNum + num;

		const chapterCfgPtr config = map_sys.getConfig(chapterId);
		if (!config) { return; }
		if ((config->compltetKeyArmyId == mapId) && (config->followChapterId != -1))
		{
			int nextChapterId = config->followChapterId;
			playerChatperDataPtr chatperData = Creator<playerChatperData>::Create(_Own, nextChapterId);
			chatperData->createmapData();
			selfChapterDate[nextChapterId] = chatperData;
			chChapterId = nextChapterId;
			chatperData->_sign_auto();
		}
		else
		{
			mapDataMap::iterator itC = config->mapData.begin();
			for (itC; itC != config->mapData.end(); itC++)
			{
				if (itC->second->frontId != mapId) continue;
				selfChapterDate[chapterId]->insertMapData(itC->second->mapId);
			}
		}
	}

	void playerMapWarMgr::changeStart(int mapId, int starNum, sBattlePtr atk)
	{

		//��������
		int chapterId = map_sys.getChapterId(mapId);
		if (chapterId == 0 || starNum <= 0) { return; }
		ChapterDateMap::iterator it = selfChapterDate.find(chapterId);
		if (it == selfChapterDate.end()) { return; }

		int num = it->second->setMapStar(mapId, starNum);
		changeMaxMapId(mapId);
		totalStartNum = totalStartNum + num;

		//������ս����
		subChanllenge(mapId);

		const chapterCfgPtr config = map_sys.getConfig(chapterId);
		if (!config) { return; }
		if ((config->compltetKeyArmyId == mapId) && (config->followChapterId != -1))
		{
			int nextChapterId = config->followChapterId;
			ChapterDateMap::iterator it = selfChapterDate.find(nextChapterId);
			if (it == selfChapterDate.end())
			{
				playerChatperDataPtr chatperData = Creator<playerChatperData>::Create(_Own, nextChapterId);
				chatperData->createmapData();
				selfChapterDate[nextChapterId] = chatperData;
				chChapterId = nextChapterId;
				chatperData->_sign_auto();
			}
		}
		else
		{
			mapDataMap::iterator itC = config->mapData.begin();
			for (itC; itC != config->mapData.end(); itC++)
			{
				if (itC->second->frontId != mapId) continue;
				selfChapterDate[chapterId]->insertMapData(itC->second->mapId);		
			}
		}
		/////�¼�����
		{
			//������������ͨ��ĳ���ؿ�
			//Own().Task->evTask(TaskDef::MapSuEv, mapId);
			//��������ĳ����ͨ�عؿ�
			//if (starNum == MAX_MAP_STAR_NUM) Own().Task->evTask(TaskDef::MapStartEv, mapId, starNum);
			//����������ͨ��ĳ���ؿ�
			//Own().Task->actTask(TaskDef::MapSuAc, mapId);
			//��������������
			//it->second->eventCon(eventMap::SuccessMap, mapId, 1);
			//�����¼��������� ĳ������ͨ��ĳ����ͼ
			//it->second->insertEvent(mapId, eventMap::starMap, starNum);
			//�����¼��������� ��ĳ��NPC��ͨ��ĳ����ͼ
			//it->second->insertEvent(mapId, eventMap::manMap, starNum, atk);
		}
	}

// 	void	 playerMapWarMgr::FinishEvent(int eventID, int mapId, int starNum, sBattlePtr atk)
// 	{
// 		int chapterId = map_sys.getEventChapterId(eventID);
// 		playerChatperDataPtr ptr = getChatperData(chapterId);
// 		if (!ptr) return;
// 		//�����¼����
// 		ptr->eventCon(eventMap::SuccessMap, mapId, 1);
// 	}

	void	 playerMapWarMgr::checkBaseData()
	{
		if (selfChapterDate.size() == 0)
			createBaseData();
	}

	void	 playerMapWarMgr::createBaseData()
	{
		int minChapterId = map_sys.getMinChapterNum();
		playerChatperDataPtr chatperData = Creator<playerChatperData>::Create(_Own, minChapterId);
		chatperData->createmapData();
		selfChapterDate[minChapterId] = chatperData;
		chChapterId = minChapterId;
		chatperData->_sign_save();
	}

	//��½����
	void playerMapWarMgr::sendMapBase()
	{
		//����������¿����½�
		chapterCfgPtr	configPtr = map_sys.getConfig(chChapterId);
		playerChatperDataPtr	ptr = getChatperData(chChapterId);
		if (configPtr && ptr)
		{
			int compltetId = configPtr->compltetKeyArmyId;
			MapDataMap::iterator mIt = ptr->pmapDataMap.find(compltetId);
			if (mIt != ptr->pmapDataMap.end() && mIt->second->mState == warMap::Success)
			{
				int nextChapterId = configPtr->followChapterId;
				playerChatperDataPtr chatperData = Creator<playerChatperData>::Create(_Own, nextChapterId);
				chatperData->createmapData();
				selfChapterDate[nextChapterId] = chatperData;
				chatperData->_sign_auto();
			}
		}
		for (ChapterDateMap::iterator it = selfChapterDate.begin();
			it != selfChapterDate.end(); it++)
		{
// 			bool isUpdate = false;
// 			//��������¼�
// 			for (SpeEventMap::iterator eIt = it->second->speEventMap.begin();
// 				eIt != it->second->speEventMap.end(); eIt++)
// 			{
// 				if (eIt->second->endTime <= (int)Common::gameTime() && eIt->second->endTime != 0
// 					&& eIt->second->sSteae == eventMap::goIng)
// 				{
// 					eIt->second->sSteae = eventMap::faileState;
// 					isUpdate = true;
// 				}
// 			}
// 			//����
// 			if (isUpdate) it->second->_sign_auto();
// 			else it->second->_sign_update();
			it->second->_sign_update();
		}
	}

	bool playerMapWarMgr::isChallenge(int mapId)
	{
		int chapterId = map_sys.getChapterId(mapId);
		if (chapterId == 0) { return false; }
		ChapterDateMap::iterator it = selfChapterDate.find(chapterId);
		if (it == selfChapterDate.end()) { return false; }
		MapDataMap::iterator mIt = it->second->pmapDataMap.find(mapId);
		if (mIt == it->second->pmapDataMap.end()) { return false; }
		if (mIt->second->mState == warMap::Success) { return true; }
		else{ return false; }
	}

	int playerMapWarMgr::getChapterReward(int chapterId, int rewardId)
	{
		playerChatperDataPtr ptr = getChatperData(chapterId);
		if (!ptr) return err_charpter_id_not_found;
		return ptr->getRewared(rewardId);
	}

	int playerMapWarMgr::sweepMap(int mapId, int times)
	{
		SelfMapDataPtr mapPTr = getMapData(mapId);
		if (!mapPTr) return err_illedge;
		if (mapPTr->starNum != MAX_MAP_STAR_NUM) { return err_mapwar_sweep_more_star; }
		if (mapPTr->challengeTimes < times) { return err_mapwar_not_challengtimes; }
		return res_sucess;
	}

	int	playerMapWarMgr::chanllenge(int mapId, int times)
	{
		SelfMapDataPtr mapPTr = getMapData(mapId);
		if (!mapPTr || mapPTr->mState == warMap::Faile) return err_illedge;
		if (mapPTr->challengeTimes < times) { return err_mapwar_not_challengtimes; }
		return res_sucess;
	}

	void	playerMapWarMgr::subChanllenge(int mapId, int times)
	{
		int chapterId = map_sys.getChapterId(mapId);
		if (chapterId == 0) return;
		ChapterDateMap::iterator it = selfChapterDate.find(chapterId);
		if (it == selfChapterDate.end()) return;
		it->second->subChanllengeTime(mapId, times);
	}

	void playerMapWarMgr::reChanllengeTimeDaily()
	{
		for (ChapterDateMap::iterator it = selfChapterDate.begin(); it != selfChapterDate.end(); it++)
		{
			it->second->reChanllengeTimeDaily();
		}
	}

	int	 playerMapWarMgr::reChanllengeAcc(int mapId)
	{
		int chapterId = map_sys.getChapterId(mapId);
		if (chapterId == 0) return err_illedge;
		ChapterDateMap::iterator it = selfChapterDate.find(chapterId);
		if (it == selfChapterDate.end()) return err_illedge;
		if (it->second->reChanllengeAcc(mapId)) return res_sucess;
		return err_illedge;
	}

// 	bool	 playerMapWarMgr::chanllengeEvent(int evnetId, int mapId)
// 	{
// 		int chapterId = map_sys.getEventChapterId(evnetId);
// 		playerChatperDataPtr ptr = getChatperData(chapterId);
// 		if (!ptr) return false;
// 		SpeEventMap::iterator it = ptr->speEventMap.find(evnetId);
// 		if (it == ptr->speEventMap.end()) return false;
// 		ComConMap::iterator cIt = it->second->conMap.begin();
// 		for (cIt; cIt != it->second->conMap.end(); cIt++)
// 		{
// 			if (cIt->second->commonId == mapId) return true;
// 		}
// 		return false;
// 	}

	bool playerMapWarMgr::isChallengeChatper(int chapterId)
	{
		if (chChapterId > chapterId) return true;
		return false;
	}

	void	 playerMapWarMgr::changeMaxMapId(int mapId)
	{
		if (mapId > chMaxMapId)
		{
			Log(DBLOG::strLogWarProcess, Own().getOwnDataPtr(), -1, chMaxMapId, mapId);
			chMaxMapId = mapId;
			onChangeMaxMapId();
		}
	}
	/////////////////////////////////////// �����¼���ʱ������
// 	void playerMapWarMgr::addTimer()
// 	{
// 		eventID = ptrTimerIdentify();
// 		//shared_from_this();
// 		
// 		eventID = Timer::AddEventSeconds(boostBind(playerMapWarMgr::checkEv, this, _1), 
// 			Inter::event_mapwar_timer, 5);
// 	}

// 	void playerMapWarMgr::clearTimerID()
// 	 { 
// 		 if (eventID){
// 			 eventID->delTimer();
// 		 }
// 		 eventID = ptrTimerIdentify();
// 	}

// 	void playerMapWarMgr::checkEv(const structTimer& timerData)
// 	{
// 		if (!eventID) return;
// 		
// 		for (ChapterDateMap::iterator it = selfChapterDate.begin(); 
// 			it != selfChapterDate.end(); it++)
// 		{
// 			it->second->checkEven();
// 		}
// 
// 		eventID = Timer::AddEventSeconds(boostBind(playerMapWarMgr::checkEv, this, _1),
// 			Inter::event_mapwar_timer, 5);
// 	}

	int playerMapWarMgr::getStarSum(int chapterId)
	{
		if (chapterId == -1)
		{
			int sum = 0;
			ForEach(ChapterDateMap, it, selfChapterDate)
				sum += it->second->getStartNum();
			return sum;
		}
		else
		{
			ChapterDateMap::iterator it = selfChapterDate.find(chapterId);
			if (it == selfChapterDate.end())
				return 0;
			return it->second->getStartNum();
		}
	}
} 

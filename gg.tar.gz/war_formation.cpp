#include "war_formation.h"
#include "playerManager.h"

namespace gg
{
	static FMCONFIG FMConfig;
	static FMCFG NullConfig;

	const FMCFG& playerWarFM::getConfig(const int FMID)
	{
		if (FMID < 0 || FMID >= (int)FMConfig.size())return NullConfig;
		return FMConfig[FMID];
	}

	void playerSGFM::initData()
	{
		{//�����
			FMConfig.clear();
			FMConfig.resize(12);
			cout << "load ./instance/formation/" << endl;
			FileJsonSeq seq = Common::loadFileJsonFromDir("./instance/formation/");
			for (unsigned i = 0; i < seq.size(); ++i)
			{
				Json::Value& json = seq[i];
				unsigned fmID = json["fmID"].asUInt();
				FMCFG& config = FMConfig[fmID];
				config.techID = json["techID"].asInt();
				config.HOLES.resize(9);
				for (unsigned n = 0; n < json["fm"].size() && n < 9; ++n)
				{
					Json::Value& holeJson = json["fm"][n];
					unsigned hID = holeJson["hole"].asUInt();
					config.HOLES[hID].LV = holeJson["lv"].asUInt();
					config.HOLES[hID].Process = holeJson["process"].asInt();
					config.HOLES[hID].Use = true;
				}
			}
		};
	}

	playerSGFM::playerSGFM(const unsigned ID, playerData* const own) : _auto_player(own), fmID(ID)
	{
		FMPower = 0;
		isNew = true;
	}

	void playerSGFM::tryToFormat(const vector<playerManPtr>& vec)
	{
		const FMCFG::HOLEVEC& config = FMConfig[fmID].HOLES;
		unsigned idx = 0;
		for (unsigned i = 0; i < 9 && idx < vec.size(); ++i)
		{
			if (!config[i].Use)continue;
			if (Own().LV() < config[i].LV)continue;
			if (config[i].Process > 0 && !Own().War->isChallenge(config[i].Process))continue;
			FMList[i] = vec[idx];
			++idx;
		}
		if (idx > 0)
		{
			isNew = false;
			recalFM(true);
		}
		_sign_auto();//�Զ����ºͱ���
	}

	int playerSGFM::format(const int fm[9])
	{
		int res = rawFormat(fm);
		if (res == res_sucess)
		{
			recalFM();
			_sign_auto(); 
		}
		return res;
	}

	void playerSGFM::recalFM(const bool initial /* = false */)
	{
		int tmp_val = FMPower;
		FMPower = 0;
		unsigned num = 0;
		for (unsigned i = 0; i < 9; ++i)
		{
			playerManPtr man = FMList[i];
			if (!man)continue;
			++num;
			FMPower += man->battleValue();
		}
		const FMCFG& config = FMConfig[fmID];
		const int scLV = Own().Research->getForLV(config.techID);
		FMPower += (scLV * 7 * num);
		//���Խ��//��ô10��
		const static int MaxValue = 1000000000;//10��
		if (FMPower < 0 || FMPower > MaxValue)FMPower = MaxValue;

		if (tmp_val != FMPower)
		{
			_sign_update();
			const unsigned currentFMID = Own().WarFM->currentID();
			if (!initial && currentFMID == fmID)
			{
				Own().onBVAlter();
			}
		}
	}

	int playerSGFM::rawFormat(const int fm[9])
	{
		const FMCFG::HOLEVEC& config = FMConfig[fmID].HOLES;
		boost::unordered_set<int> SAMEMAN;
		for (unsigned i = 0; i < 9; ++i)
		{
			if (fm[i] < 0)continue;
			if (!SAMEMAN.insert(fm[i] / 100).second)return err_fomat_same_man;
		}
		playerManPtr tmpList[9];//�����б�
		for (unsigned i = 0; i < 9; ++i)
		{
			if (fm[i] < 0)continue;
			if (!config[i].Use)continue;
			if (Own().LV() < config[i].LV)return err_format_hole_limit;
			if (config[i].Process > 0 && !Own().War->isChallenge(config[i].Process))return err_format_hole_limit;
			playerManPtr man = Own().Man->findMan(fm[i]);//�Ƿ����㿪������
			tmpList[i] = man;
		}
		for (unsigned i = 0; i < 9; ++i)
		{
			FMList[i] = tmpList[i];
		}
		isNew = false;
		return res_sucess;
	}

	mongo::BSONArray playerSGFM::toBsonArr()
	{
		mongo::BSONArrayBuilder arr;
		for (unsigned i = 0; i < 9; ++i)
		{
			arr << (FMList[i] ? FMList[i]->mID() : -1);
		}
		return arr.arr();
	}

	std::vector<playerManPtr> playerSGFM::toInvaildFormat()
	{
		std::vector<playerManPtr> list;
		for (unsigned i = 0; i < 9; ++i)
		{
			playerManPtr m = FMList[i];
			if (!m)continue;
			list.push_back(m);
		}
		return list;
	}

	std::vector<playerManPtr> playerSGFM::toFormat()
	{
		std::vector<playerManPtr> list;
		for (unsigned i = 0; i < 9; ++i)
		{
			list.push_back(FMList[i]);
		}
		return list;
	}

	bool playerSGFM::isEmpty()
	{
		for (unsigned i = 0; i < 9; ++i)
		{
			if(FMList[i])return false;
		}
		return true;
	}

	qValue playerSGFM::toJson()
	{
		qValue json(qJson::qj_object);
		json.addMember("id", fmID);
		json.addMember("bv", FMPower);
		qValue m_json(qJson::qj_array);
		for (unsigned i = 0; i < 9; ++i)
		{
			m_json.append(FMList[i] ? FMList[i]->mID() : -1);
		}
		json.addMember("m", m_json);
		return json;
	}

	bool playerSGFM::_on_sign_update()
	{
		Own().WarFM->tickFM(fmID);
		return false;
	}

	void playerSGFM::rawInitial(const bool in, vector<mongo::BSONElement>& vec)
	{
		isNew = in;
		unsigned num = 0;
		for (unsigned i = 0; i < vec.size() && i < 9; ++i)
		{
			playerManPtr m = Own().Man->findMan(vec[i].Int());
			if (m)++num;
			FMList[i] = m;
		}
		if (num > 0)isNew = false;
	}

	bool playerSGFM::_auto_save()
	{
		mongo::BSONObj key = BSON(strPlayerID << Own().ID() << "fid" << fmID);
		mongo::BSONObj obj = BSON(strPlayerID << Own().ID() << "fid" << fmID << 
			"arr" << toBsonArr() << "in" << isNew);
		return db_mgr.SaveMongo(DBN::dbPlayerWarFM, key, obj);
	}

	//mgr
	playerWarFM::playerWarFM(playerData* const own) : _auto_player(own)
	{
		fmList.clear();
		for (unsigned i = 0; i < 12; ++i)
		{
			playerFMPtr dataPtr = Creator<playerSGFM>::Create(i, own);
			fmList.push_back(dataPtr);
		}
		currentFMID = 0;
	}

	int playerWarFM::format(const unsigned fmID, const int fm[9])
	{
		if (fmID > fmList.size())return err_format_not_find;
		currentFMID = fmID;
		_sign_auto();
		const int res = fmList[fmID]->format(fm);
		qValue log_val = fmList[currentFMID]->toJson();
		Log(DBLOG::strLogFormation, Own().getOwnDataPtr(), -1, currentFMID, "","","","","","", log_val.toIndentString());
		return res;
	}

	void playerWarFM::_auto_update()
	{
		qValue json(qJson::qj_array);
		json.append(res_sucess).append(currentFMID);
		qValue fmJson(qJson::qj_array);
		for (UINTSET::iterator it = updateList_.begin();it != updateList_.end(); ++it)
		{
			const unsigned idx = *it;
			if (idx >= fmList.size())continue;
			fmJson.append(fmList[idx]->toJson());
		}
		json.append(fmJson);
		updateList_.clear();
		Own().sendToClientFillMsg(gate_client::war_format_update_resp, json);
	}

	bool playerWarFM::_auto_save()
	{
		mongo::BSONObj key = BSON(strPlayerID << Own().ID());
		mongo::BSONObj obj = BSON(strPlayerID << Own().ID() << "cid" << currentFMID);
		return db_mgr.SaveMongo(DBN::dbPlayerWarFMBase, key, obj);
	}

	int playerWarFM::defaultFM(const unsigned fmID)
	{
		if (fmID >= fmList.size())return err_format_not_find;
		const unsigned oldFMID = currentFMID;//�ϵ�ID
		currentFMID = fmID;
		if (fmList[currentFMID]->isNewFM() && oldFMID != currentFMID)
		{
			std::vector<playerManPtr> vec = fmList[oldFMID]->toInvaildFormat();
			fmList[currentFMID]->tryToFormat(vec);
		}
		_sign_auto();
		Own().onBVAlter();
		qValue log_val = fmList[currentFMID]->toJson();
		Log(DBLOG::strLogFormation, Own().getOwnDataPtr(), -1, currentFMID, "", "", "", "", "", "", log_val.toIndentString());
		return res_sucess;
	}

	void playerWarFM::loadDB()
	{
		mongo::BSONObj key = BSON(strPlayerID << Own().ID());
		mongo::BSONObj baseObj = db_mgr.FindOne(DBN::dbPlayerWarFMBase, key);
		if (!baseObj.isEmpty())
		{
			currentFMID = (unsigned)baseObj["cid"].Int();
		}
		objCollection collection = db_mgr.Query(DBN::dbPlayerWarFM, key);
		if (collection.empty())return;
		for (unsigned i = 0; i < collection.size(); ++i)
		{
			mongo::BSONObj& obj = collection[i];
			unsigned fmID = (unsigned)obj["fid"].Int();
			bool isNew = obj["in"].eoo() ? true : obj["in"].Bool();
			if (fmID >= fmList.size())continue;
			std::vector<mongo::BSONElement> elems = obj["arr"].Array();
			fmList[fmID]->rawInitial(isNew ,elems);
		}
	}

	void playerWarFM::updateAll()
	{
		qValue json(qJson::qj_array);
		json.append(res_sucess).append(currentFMID);
		qValue fmJson(qJson::qj_array);
		for (unsigned i = 0; i < fmList.size(); ++i)
		{
			fmJson.append(fmList[i]->toJson());
		}
		json.append(fmJson);
		Own().sendToClientFillMsg(gate_client::war_format_update_resp, json);
	}

	void playerWarFM::updateSingle(const unsigned fmID)
	{
		qValue json(qJson::qj_array);
		if (fmID > fmList.size())
		{
			json.append(err_format_not_find);
			Own().sendToClientFillMsg(gate_client::war_format_update_single_resp, json);
			return;
		}
		json.append(res_sucess);
		json.append(fmList[fmID]->toJson());
		Own().sendToClientFillMsg(gate_client::war_format_update_single_resp, json);
		return;
	}

	void playerWarFM::recalFMValue(const bool update /* = true */, const bool initial /* = false */)
	{
		for (unsigned i = 0; i < fmList.size(); ++i)
		{
			if (fmList[i])fmList[i]->recalFM(initial);
		}
		if(update)_sign_update();
	}

	int playerWarFM::currentBV()
	{
		return fmList[currentFMID]->getBV();
	}

	std::vector<playerManPtr> playerWarFM::currentFM()
	{
		return fmList[currentFMID]->toFormat();
	}

	std::vector<playerManPtr> playerWarFM::appointFM(const unsigned FMID)
	{
		if (FMID >= fmList.size())return std::vector<playerManPtr>();
		return fmList[FMID]->toFormat();
	}

	std::vector<playerManPtr> playerWarFM::currentInvaildFM()
	{
		return fmList[currentFMID]->toInvaildFormat();
	}

	std::vector<playerManPtr> playerWarFM::appointInvaildFM(const unsigned FMID)
	{
		if (FMID >= fmList.size())return std::vector<playerManPtr>();
		return fmList[FMID]->toInvaildFormat();
	}

	void playerWarFM::tickFM(const unsigned FMID)
	{
		updateList_.insert(FMID);
	}

	bool playerWarFM::currentEmpty()
	{
		return appointEmpty(currentFMID);
	}

	bool playerWarFM::appointEmpty(const unsigned FMID)
	{
		if (FMID >= fmList.size())return true;
		return fmList[FMID]->isEmpty();
	}
}
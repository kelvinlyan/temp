#include "action_system.h"
#include "playerManager.h"
//#include "kingdom.h"
#include "kingdom_system.h"
#include "kingdom_def.h"

namespace gg
{
	//action
	UNORDERMAP(int, ACTION::RegFunc, RegMap);
	static RegMap staticMapReg;//ע�����ʼ��

	//action box
	UNORDERMAP(int, ACTION::RegBoxFunc, RegBoxMap);
	static RegBoxMap staticMapBoxReg;//ע�����ʼ��


	typedef boost::unordered_map<int, ACTION::Box*> BoxPtrList;//������Ů���ӵ�
	void actionArrange(ACTION::BoxList& vec)
	{
		BoxPtrList itemLs, cardLs;
		for (unsigned i = 0; i < vec.size(); i++)
		{
			ACTION::Box& box = vec[i];
			if (box.actionID == ACTION::item)
			{
				if (itemLs[box.boxData._Item.itemID] == NULL)
				{
					itemLs[box.boxData._Item.itemID] = &box;
				}
				else
				{
					itemLs[box.boxData._Item.itemID]->boxData._Item.num += box.boxData._Item.num;
					vec.erase(vec.begin() + i);
					--i;
					continue;
				}
			}
			else if (box.actionID == ACTION::lady)
			{
				if (cardLs[box.boxData._Item.itemID] == NULL)
				{
					cardLs[box.boxData._Item.itemID] = &box;
				}
				else
				{
					cardLs[box.boxData._Item.itemID]->boxData._Item.num += box.boxData._Item.num;
					vec.erase(vec.begin() + i);
					--i;
					continue;
				}
			}
		}
	}

	ACTION::BoxList actionFormatBox(Json::Value& acJson)
	{
		ACTION::BoxList vec;
		try
		{
			do
			{
				if (!acJson.isArray())break;
				for (unsigned i = 0; i < acJson.size(); ++i)
				{
					Json::Value& json = acJson[i];
					const int actionID = json["aID"].asInt();
					if (actionID <= ACTION::null || actionID >= ACTION::ACTION_NUM)continue;
					ACTION::Box thisBox;
					thisBox.actionID = actionID;
					staticMapBoxReg[actionID](thisBox.boxData, json);
					vec.push_back(thisBox);
				}
			} while (false);
		}
		catch (std::exception& e)
		{
			cout << e.what() << endl;
		}
		actionArrange(vec);
		return vec;
	}

	ACTION::BoxList actionFormatBox(const int boxID)
	{
		Json::Value json = Common::loadJsonFile("./instance/actionBox/" + Common::toString(boxID) + ".json");
		return actionFormatBox(json);
	}

	acPtrList actionFormat(Json::Value& acJson)
	{
		acPtrList vec;
		try
		{
			do
			{
				if (!acJson.isArray())break;
				for (unsigned i = 0; i < acJson.size(); ++i)
				{
					Json::Value& json = acJson[i];
					acValuePtr ptr = Creator<ACTION::Value>::Create();
					ptr->BasicPick = json["pick"].asUInt();
					ACTION::DataActionMap& staticMap = ptr->staticPrize;
					ACTION::DataActionMap& dynamicVector = ptr->dynamicPrize;
					for (unsigned n = 0; n < json["action"].size(); ++n)
					{
						Json::Value& sgJson = json["action"][n];
						const int actionID = sgJson["aID"].asInt();
						if (actionID < ACTION::null || actionID >= ACTION::ACTION_NUM)continue;
						const unsigned weight = sgJson["wgt"].asUInt();
						if (weight < 1)continue;
						const bool recover = sgJson["rec"].asBool();
						ACTION::ptrDataAction ptr_data = Creator<ACTION::DataAction>::Create();
						staticMapReg[actionID](ptr_data->actionData, sgJson);
						ptr_data->actionID = actionID;
						ptr_data->weight = weight;
						ptr_data->recover = recover;
						ptr_data->tag = n;//��ʶ
						bool is_dynamic = false;
						if (sgJson.isMember("adjust"))//����ѡ��
						{
							Json::Value& ad_json = sgJson["adjust"];
							const int adjustID = ad_json["id"].asInt();
							const unsigned growW = ad_json["grow"].asUInt();
							if (adjustID >= 0)
							{
								is_dynamic = true;
								ptr_data->adjustID = adjustID;
								ptr_data->growW = growW;
							}
						}
						if (sgJson.isMember("limit"))//����ѡ��
						{
							Json::Value& lm_json = sgJson["limit"];
							ptr_data->Limits = toLimitData(lm_json);
							if (ptr_data->Limits._limits.size() > 0)
							{
								is_dynamic = true;
							}
						}
						
						if (is_dynamic)
						{
							dynamicVector[ptr_data->tag] = ptr_data;
						}
						else
						{
							ptr->BasicWeight += ptr_data->weight;
							ptr_data->final_weight = ptr_data->weight;
							staticMap[ptr->BasicWeight] = ptr_data;
						}
					}
					vec.push_back(ptr);
				}
			} while (false);
		}
		catch (std::exception& e)
		{
			cout << e.what() << endl;
		}
		return vec;
	}

	acPtrList actionFormat(const int boxID)
	{
		Json::Value json = Common::loadJsonFile("./instance/action/" + Common::toString(boxID) + ".json");
		return actionFormat(json);
	}

	Json::Value jsonFormats2c(const Json::Value& info)
	{
		Json::Value res = Json::arrayValue;
		ForEachC(Json::Value, it, info)
		{
			const Json::Value& rw = *it;
			Json::Value tmp;
			tmp.append(rw["aID"].asInt());
			if (rw["id"] != Json::nullValue)
				tmp.append(rw["id"].asInt());
			tmp.append(rw["v"].asInt());
			res.append(tmp);
		}
		return res;
	}

	ACTION::BoxList actionFormatBoxc2s(const Json::Value& acJson)
	{
		Json::Value res = Json::arrayValue;
		ForEachC(Json::Value, it, acJson)
		{
			const Json::Value& rw = *it;
			Json::Value tmp;
			tmp["aID"] = rw[0u].asInt();
			if (rw.size() == 2)
				tmp["v"] = rw[1u].asInt();
			else
			{
				tmp["id"] = rw[1u].asInt();
				tmp["v"] = rw[2u].asInt();
			}
			res.append(tmp);
		}
		return actionFormatBox(res);
	}

	typedef boost::unordered_map<int, ACTION::Box> ResList;//��Դ�����ӵ�
	typedef boost::unordered_map<int, ACTION::Box> ItemList;//������Ů���ӵ�
	static ResList staticRes;//��Դ���ü��//��Դmapʹ��action������
	static ItemList staticMan, staticItem, staticCard;//����������Ҫ��ʵ�ʵı����ռ�//���ߺͿ�Ƭʹ�õ���id�Ϳ�ƬID������
	Json::Value resCode;//������Ϣ����
	ACTION::BoxList resBoxList;//������������
	Json::Value jsonDeclare;
	//����
	static ActionRateMap Rates;
	const static ACTION::Rate NULLRate;
	const ACTION::Rate& getRate(const int actionID)
	{
		ActionRateMap::const_iterator it = Rates.find(actionID);
		if (it == Rates.end())return NULLRate;
		return it->second;
	}

	void setActionRate(const int actionID, const ACTION::Rate& rate)
	{
		if (rate.isNull())return;
		Rates[actionID] = rate;
	}

	void setActionRate(const ActionRateMap& rates)
	{
		Rates = rates;
	}

	//�����ж������
	typedef boost::function<void(playerDataPtr, const ACTION::Declare&)> BoxFunc;
	UNORDERMAP(int, BoxFunc, BoxDeclareMap);
	static BoxDeclareMap mapBoxDeclare;

	void nullRes(playerDataPtr player, const ACTION::Declare& dec)
	{
	}

	void naturalRes(playerDataPtr player, const ACTION::Declare& dec, const int actionID)
	{
		if (actionID <= ACTION::null || actionID >= ACTION::ACTION_NUM)return;
		const int res_num = dec._Res.val;
		ResList::iterator it = staticRes.find(actionID);
		if (it == staticRes.end())
		{
			ACTION::Box box;
			box.actionID = actionID;
			box.boxData._Res.val = res_num;
			staticRes[actionID] = box;
		}
		else
		{
			ACTION::Box& box = it->second;
			box.boxData._Res.val += res_num;
		}
	}

	void manRes(playerDataPtr player, const ACTION::Declare& dec)
	{
		ResList::iterator it = staticMan.find(dec._Res.val);
		if (it == staticMan.end())
		{
			ACTION::Box box;
			box.actionID = ACTION::man;
			box.boxData._Res.val = dec._Res.val;
			staticRes[dec._Res.val] = box;
		}
	}

	void itemRes(playerDataPtr player, const ACTION::Declare& dec)
	{
		const int itemID = dec._Item.itemID;
		const unsigned num = dec._Item.num;
		ItemList::iterator it = staticItem.find(itemID);
		if (it == staticItem.end())
		{
			ACTION::Box box;
			box.actionID = ACTION::item;
			box.boxData._Item.itemID = itemID;
			box.boxData._Item.num = num;
			staticItem[itemID] = box;
		}
		else
		{
			ACTION::Box& box = it->second;
			box.boxData._Item.num += num;
		}
	}

	void cardRes(playerDataPtr player, const ACTION::Declare& dec)
	{
		const int cardID = dec._Item.itemID;
		const unsigned num = dec._Item.num;
		ItemList::iterator it = staticCard.find(cardID);
		if (it == staticCard.end())
		{
			ACTION::Box box;
			box.actionID = ACTION::lady;
			box.boxData._Item.itemID = cardID;
			box.boxData._Item.num = num;
			staticCard[cardID] = box;
		}
		else
		{
			ACTION::Box& box = it->second;
			box.boxData._Item.num += num;
		}
	}

	void kingdomExp(playerDataPtr player, const ACTION::Declare& dec)//���Ҿ���
	{
		const int itemID = dec._Item.itemID;
		const unsigned num = dec._Item.num;
		ItemList::iterator it = staticRes.find(ACTION::kingdom_skill_exp);
		if (it == staticRes.end())
		{
			ACTION::Box box;
			box.actionID = ACTION::kingdom_skill_exp;
			box.boxData._Item.itemID = itemID;
			box.boxData._Item.num = num;
			staticRes[ACTION::kingdom_skill_exp] = box;
		}
		else
		{
			ACTION::Box& box = it->second;
			box.boxData._Item.num += num;
		}
	}

	//У��
	int actionCheckAvailable(playerDataPtr player, ACTION::BoxList& vec)
	{
		int res = res_sucess;
		{//�����ж�//��Ů�ж�
			unsigned item_pos = 0;
			unsigned lady_pos = 0;
			for (unsigned i = 0; i < vec.size(); ++i)
			{
				const ACTION::Box& box = vec[i];
				if (box.actionID == ACTION::item)
				{
					unsigned pos = player->Items->itemUsePos(box.boxData._Item.itemID, box.boxData._Item.num);
					if (pos == 0xFFFFFFFF)
					{
						item_pos = 0xFFFFFFFF;
						break;
					}
					item_pos += pos;
					continue;
				}
				if (box.actionID == ACTION::lady)
				{
					lady_pos += box.boxData._Item.num;
					continue;
				}
			}
			if (player->Items->tryOver(item_pos))
			{
				res = err_action_do_failed;
				Json::Value err;
				err.append(ACTION::item);
				err.append(err_bag_full);
				resCode.append(err);
			}
			if (player->Card->tryOver(lady_pos))
			{
				res = err_action_do_failed;
				Json::Value err;
				err.append(ACTION::lady);
				err.append(err_card_bag_over);
				resCode.append(err);
			}
		};
		return res;
	}

	//////////////////////////////////////////////////////////////////////////
	//�������ʵ���
	typedef boost::function<void(ACTION::Box&, const ACTION::Rate&)> RateFunc;
	UNORDERMAP(int, RateFunc, RateFuncMap);
	static RateFuncMap mapRateFunc;
	void rate_cm_res(ACTION::Box& box, const ACTION::Rate& rate)
	{
		const int num = int(box.boxData._Res.val * rate.rate) + rate.fix;
		box.boxData._Res.val = num < 0 ? 0 : num;
	}

	void rate_item(ACTION::Box& box, const ACTION::Rate& rate)
	{
		const int num = int(box.boxData._Item.num * rate.rate) + rate.fix;
		box.boxData._Item.num = num < 0 ? 0 : num;
	}


	//////////////////////////////////////////////////////////////////////////
	//ִ�н���
	typedef boost::function<void(playerDataPtr, const ACTION::Box&)> DoFunc;
	UNORDERMAP(int, DoFunc, DoFuncMap);
	static DoFuncMap mapDoFunc;
	void do_silver(playerDataPtr player, const ACTION::Box& box)
	{
		if (box.boxData._Res.val < 1)return;
		int add = player->Res->alterSilver(box.boxData._Res.val);
		Json::Value json;
		json.append(box.actionID);
		json.append(add);
		jsonDeclare.append(json);
	}

	void do_ticket(playerDataPtr player, const ACTION::Box& box)
	{
		if (box.boxData._Res.val < 1)return;
		player->Res->alterTicket(box.boxData._Res.val);
		Json::Value json;
		json.append(box.actionID);
		json.append(box.boxData._Res.val);
		jsonDeclare.append(json);
	}

	void do_gold(playerDataPtr player, const ACTION::Box& box)
	{
		if (box.boxData._Res.val < 1)return;
		player->Res->alterGold(box.boxData._Res.val);
		Json::Value json;
		json.append(box.actionID);
		json.append(box.boxData._Res.val);
		jsonDeclare.append(json);
	}

	void do_food(playerDataPtr player, const ACTION::Box& box)
	{
		if (box.boxData._Res.val < 1)return;
		player->Res->alterFood(box.boxData._Res.val);
		Json::Value json;
		json.append(box.actionID);
		json.append(box.boxData._Res.val);
		jsonDeclare.append(json);
	}

	void do_wood(playerDataPtr player, const ACTION::Box& box)
	{
		if (box.boxData._Res.val < 1)return;
		player->Res->alterWood(box.boxData._Res.val);
		Json::Value json;
		json.append(box.actionID);
		json.append(box.boxData._Res.val);
		jsonDeclare.append(json);
	}

	void do_iron(playerDataPtr player, const ACTION::Box& box)
	{
		if (box.boxData._Res.val < 1)return;
		player->Res->alterIron(box.boxData._Res.val);
		Json::Value json;
		json.append(box.actionID);
		json.append(box.boxData._Res.val);
		jsonDeclare.append(json);
	}

	void do_merit(playerDataPtr player, const ACTION::Box& box)
	{
		if (box.boxData._Res.val < 1)return;
		player->Res->alterMerit(box.boxData._Res.val);
		Json::Value json;
		json.append(box.actionID);
		json.append(box.boxData._Res.val);
		jsonDeclare.append(json);
	}

	void do_fame(playerDataPtr player, const ACTION::Box& box)
	{
		if (box.boxData._Res.val < 1)return;
		int add = player->Res->alterFame(box.boxData._Res.val);
		Json::Value json;
		json.append(box.actionID);
		json.append(add);
		jsonDeclare.append(json);
	}

	void do_action(playerDataPtr player, const ACTION::Box& box)
	{
		if (box.boxData._Res.val < 1)return;
		player->Res->alterAction(box.boxData._Res.val);
		Json::Value json;
		json.append(box.actionID);
		json.append(box.boxData._Res.val);
		jsonDeclare.append(json);
	}

	void do_exp(playerDataPtr player, const ACTION::Box& box)
	{
		if (box.boxData._Res.val < 1)return;
		player->Info->addExp(box.boxData._Res.val);
		Json::Value json;
		json.append(box.actionID);
		json.append(box.boxData._Res.val);
		jsonDeclare.append(json);
	}

	void do_contribution(playerDataPtr player, const ACTION::Box& box)
	{
		if (box.boxData._Res.val < 1)return;
		player->Res->alterContribution(box.boxData._Res.val);
		Json::Value json;
		json.append(box.actionID);
		json.append(box.boxData._Res.val);
		jsonDeclare.append(json);
	}

	void do_heroes_coin(playerDataPtr player, const ACTION::Box& box)
	{
		if (box.boxData._Res.val < 1)return;
		player->Res->alterHeroPartyMoney(box.boxData._Res.val);
		Json::Value json;
		json.append(box.actionID);
		json.append(box.boxData._Res.val);
		jsonDeclare.append(json);
	}

	void do_lady_coin(playerDataPtr player, const ACTION::Box& box)
	{
		if (box.boxData._Res.val < 1)return;
		player->Res->alterLadyCoin(box.boxData._Res.val);
		Json::Value json;
		json.append(box.actionID);
		json.append(box.boxData._Res.val);
		jsonDeclare.append(json);
	}

	void do_vip_exp(playerDataPtr player, const ACTION::Box& box)
	{
		if (box.boxData._Res.val < 1)return;
		player->Info->addVipExp(box.boxData._Res.val);
		Json::Value json;
		json.append(box.actionID);
		json.append(box.boxData._Res.val);
		jsonDeclare.append(json);
	}

	void do_points(playerDataPtr player, const ACTION::Box& box)
	{
		if (box.boxData._Res.val < 1)return;
		player->Res->alterPoints(box.boxData._Res.val);
		Json::Value json;
		json.append(box.actionID);
		json.append(box.boxData._Res.val);
		jsonDeclare.append(json);
	}

	void do_search_points(playerDataPtr player, const ACTION::Box& box)
	{
		if (box.boxData._Res.val < 1)return;
		player->Res->alterSearchPoints(box.boxData._Res.val);
		Json::Value json;
		json.append(box.actionID);
		json.append(box.boxData._Res.val);
		jsonDeclare.append(json);
	}

	void do_exploit_coin(playerDataPtr player, const ACTION::Box& box)
	{
		if (box.boxData._Res.val < 1)return;
		player->Res->alterExploit(box.boxData._Res.val);
		Json::Value json;
		json.append(box.actionID);
		json.append(box.boxData._Res.val);
		jsonDeclare.append(json);
	}

	void do_kingdom_exp(playerDataPtr player, const ACTION::Box& box)
	{
		if (box.boxData._Item.num < 1)return;
		if (res_sucess ==
			kingdom_sys.upgradeConstruction(player->Info->Nation(), box.boxData._Item.itemID, box.boxData._Item.num))
		{
			Json::Value json;
			json.append(box.actionID);
			json.append(box.boxData._Item.itemID);
			json.append(box.boxData._Item.num);
			jsonDeclare.append(json);
		}
	}

	void do_paper(playerDataPtr player, const ACTION::Box& box)
	{
		if (box.boxData._Res.val < 1)return;
		player->Res->alterPaper(box.boxData._Res.val);
		Json::Value json;
		json.append(box.actionID);
		json.append(box.boxData._Res.val);
		jsonDeclare.append(json);
	}

	void do_item(playerDataPtr player, const ACTION::Box& box)
	{
		int itemID = box.boxData._Item.itemID;
		int num = box.boxData._Item.num;
		if (num < 1)return;
		itemVec vec = player->Items->addItem(itemID, num);
		if (vec.empty())//�����ռ䲻��
		{
			resBoxList.push_back(box);
			Json::Value err;
			err.append(box.actionID);
			err.append(err_bag_full);
			err.append(itemID);
			err.append(num);
			resCode.append(err);
			return;
		}
		Json::Value json;
		json.append(box.actionID);
		json.append(itemID);
		json.append(num);
		jsonDeclare.append(json);
	}

	void do_man(playerDataPtr player, const ACTION::Box& box)
	{
		if (player->Man->addMan(box.boxData._Res.val) == res_sucess)
		{
			Json::Value json;
			json.append(box.actionID);
			json.append(box.boxData._Res.val);
			jsonDeclare.append(json);
		}
	}

	void do_lady(playerDataPtr player, const ACTION::Box& box)
	{
		int cardID = box.boxData._Item.itemID;
		int num = box.boxData._Item.num;
		if (num < 1)return;
		int res = player->Card->resAddCard(cardID, num);
		if (res != res_sucess)
		{
			resBoxList.push_back(box);
			Json::Value err;
			err.append(box.actionID);
			err.append(res);
			err.append(cardID);
			err.append(num);
			resCode.append(err);
			return;
		}
		Json::Value json;
		json.append(box.actionID);
		json.append(cardID);
		json.append(num);
		jsonDeclare.append(json);
	}

	//ִ�н���
	ACTION::BoxList toBox()//ִ�н���
	{
		ACTION::BoxList vec;
		for (ResList::iterator it = staticRes.begin(); it != staticRes.end(); ++it)//������Դ
		{
			vec.push_back(it->second);
		}
		for (ResList::iterator it = staticMan.begin(); it != staticMan.end(); ++it)//�佫
		{
			vec.push_back(it->second);
		}
		for (ItemList::iterator it = staticItem.begin(); it != staticItem.end(); ++it)//����
		{
			vec.push_back(it->second);
		}
		for (ItemList::iterator it = staticCard.begin(); it != staticCard.end(); ++it)//��Ů
		{
			vec.push_back(it->second);
		}
		return vec;
	}

	void implBox(playerDataPtr player, ACTION::BoxList& boxL)//ִ�н���
	{
		for (unsigned i = 0; i < boxL.size(); ++i)
		{
			const ACTION::Box& box = boxL[i];
			DoFuncMap::iterator fit = mapDoFunc.find(box.actionID);
			if (fit != mapDoFunc.end())
			{
				fit->second(player, box);
			}
		}
	}

	Json::Value actionError()
	{
		return resCode;
	}

	Json::Value actionRes()
	{
		return jsonDeclare;
	}

	ACTION::BoxList actionErrorBox()
	{
		return resBoxList;
	}

	void resetAction()
	{
		jsonDeclare = Json::arrayValue;
		resCode = Json::arrayValue;
		resBoxList.clear();
		staticRes.clear();
		staticMan.clear();
		staticItem.clear();
		staticCard.clear();
	}

	//Ч��ִ��
	STDMAP(int, bool, SIGNTAG);
	ACTION::BoxList preToBox(playerDataPtr player, const acPtrList& vec, const unsigned times /* = 1 */)
	{
		resetAction();
		for (unsigned t = 0; t < times; ++t)
		{
			for (unsigned i = 0; i < vec.size(); i++)
			{
				acValuePtr ptr = vec[i];
				unsigned prize_weight = ptr->BasicWeight;
				unsigned prize_pick = ptr->BasicPick;
				ACTION::DataActionMap finalPrize = ptr->staticPrize;
				const ACTION::DataActionMap& dynamicPrize = ptr->dynamicPrize;
				SIGNTAG _Tags_Use;//��ʶID//��ʶ��ȡ���ĵ���
				for (ACTION::DataActionMap::const_iterator it = dynamicPrize.begin(); it != dynamicPrize.end(); ++it)
				{
					ACTION::ptrDataAction data_ptr = it->second;
					const bool pass_bool = resLimitPass(player, data_ptr->Limits);
					if (pass_bool)//ͨ�������ж�
					{
						prize_pick += data_ptr->Limits._pick;
						data_ptr->final_weight = data_ptr->weight + 
							player->Count->getCount(data_ptr->adjustID) * data_ptr->growW;//��������Ȩ�ص���
						prize_weight += data_ptr->final_weight;//��Ȩ������
						finalPrize[prize_weight] = data_ptr;
					}
					if (pass_bool && data_ptr->adjustID >= 0)//ͨ�����е�����Ŀ
					{
						_Tags_Use[data_ptr->adjustID] = false;
					}
				}

				for (unsigned n = 0; n < prize_pick; ++n)
				{
					if (1 > prize_weight)break;
					unsigned r_num = Common::randomUInt(0, prize_weight - 1);
					std::pair<ACTION::DataActionMap::iterator, bool> pib = 
						finalPrize.insert(ACTION::DataActionMap::value_type(r_num, ACTION::ptrDataAction()));
					ACTION::DataActionMap::iterator it = pib.first;
					if (pib.second)//����ɹ�
					{
						finalPrize.erase(it++);
					}
					else//����ʧ��
					{
						++it;
					}
					ACTION::ptrDataAction ptr = it->second;
					if (ptr->adjustID >= 0)
					{
						_Tags_Use[ptr->adjustID] = true;
					}
					BoxDeclareMap::iterator deal_it = mapBoxDeclare.find(ptr->actionID);
					if (deal_it != mapBoxDeclare.end())
					{
						deal_it->second(player, ptr->actionData);
						if (ptr->recover)continue;
					}
					finalPrize.erase(it++);
					const unsigned cut_num = ptr->final_weight;
					prize_weight -= cut_num;
					if (cut_num < 1)continue;//���Ȩ�ز����㲻��Ҫ�䶯
					if ((n + 1) >= prize_pick)continue;//��������һ��,��ô����Ҫ�˷�ʱ�����Ȩ��
					for (ACTION::DataActionMap::iterator alter_it = it; alter_it != finalPrize.end();)
					{
						ACTION::ptrDataAction alter_ptr = alter_it->second;
						const unsigned old_key = alter_it->first;
						finalPrize.erase(alter_it++);
						finalPrize[old_key - cut_num] = alter_ptr;
					}
				}
				//����ʧ�ܵ���Ŀ
				for (SIGNTAG::const_iterator it = _Tags_Use.begin(); it != _Tags_Use.end(); ++it)
				{
					const unsigned adjustID = it->first;
					const bool signBool = it->second;
					if (signBool)
					{
						player->Count->resetCount(adjustID);
					}
					else
					{
						player->Count->tickCount(adjustID);
					}
				}
			}//��������˽�������ѡ//���������
		}
		return toBox();
	}

	int actionDo(playerDataPtr player, const acPtrList& vec, const unsigned times/* = 1*/, const bool jump/* = true*/)
	{
		ACTION::BoxList box_vec = preToBox(player, vec, times);
		return actionDoBox(player, box_vec, jump);//����box�����������
	}

	int actionDoBox(playerDataPtr player, const ACTION::BoxList& vec, const bool jump)
	{
		resetAction();
		ACTION::BoxList c_vec = vec;
		if (!Rates.empty())
		{
			for (unsigned i = 0; i < c_vec.size(); ++i)
			{
				ACTION::Box& box = c_vec[i];
				const ACTION::Rate& r = getRate(box.actionID);
				if (!r.isNull())
				{
					RateFuncMap::iterator fit = mapRateFunc.find(box.actionID);
					if (fit != mapRateFunc.end())
					{
						fit->second(box, r);
					}
				}
			}
			Rates.clear();
		}

		if (!jump)
		{
			int res = actionCheckAvailable(player, c_vec);
			if (res != res_sucess)return err_action_do_failed;
		}
		implBox(player, c_vec);
		return res_sucess;
	}

	int actionDoBoxNum(playerDataPtr player, const ACTION::BoxList& vec, const unsigned times, const bool jump)
	{
		resetAction();
		ACTION::BoxList c_vec = vec;
		if (times < 1)
		{
			return res_sucess;
		}
		if (!Rates.empty() || times > 1)
		{
			ACTION::Rate timesRate(times);
			for (unsigned i = 0; i < c_vec.size(); ++i)
			{
				ACTION::Box& box = c_vec[i];
				RateFuncMap::iterator fit = mapRateFunc.find(box.actionID);
				if (fit != mapRateFunc.end())
				{
					//���ʵ���
					const ACTION::Rate& r = getRate(box.actionID);
					if (!r.isNull())fit->second(box, r);
					//��������
					if(times > 1)fit->second(box, timesRate);
				}
			}
			Rates.clear();
		}

		if (!jump)
		{
			int res = actionCheckAvailable(player, c_vec);
			if (res != res_sucess)return err_action_do_failed;
		}
		implBox(player, c_vec);
		return res_sucess;
	}

	void actionInitData()
	{
		initLimit();//���Ƴ�ʼ��

		//box reg��ʼ��
		staticMapBoxReg[ACTION::silver] = boostBind(ACTION::FORMATBOX::ResReg, _1, _2);
		staticMapBoxReg[ACTION::ticket] = boostBind(ACTION::FORMATBOX::ResReg, _1, _2);
		staticMapBoxReg[ACTION::gold] = boostBind(ACTION::FORMATBOX::ResReg, _1, _2);
		staticMapBoxReg[ACTION::food] = boostBind(ACTION::FORMATBOX::ResReg, _1, _2);
		staticMapBoxReg[ACTION::wood] = boostBind(ACTION::FORMATBOX::ResReg, _1, _2);
		staticMapBoxReg[ACTION::iron] = boostBind(ACTION::FORMATBOX::ResReg, _1, _2);
		staticMapBoxReg[ACTION::merit] = boostBind(ACTION::FORMATBOX::ResReg, _1, _2);
		staticMapBoxReg[ACTION::fame] = boostBind(ACTION::FORMATBOX::ResReg, _1, _2);
		staticMapBoxReg[ACTION::action] = boostBind(ACTION::FORMATBOX::ResReg, _1, _2);
		staticMapBoxReg[ACTION::exp] = boostBind(ACTION::FORMATBOX::ResReg, _1, _2);
		staticMapBoxReg[ACTION::man] = boostBind(ACTION::FORMATBOX::ResReg, _1, _2);
		staticMapBoxReg[ACTION::item] = boostBind(ACTION::FORMATBOX::ItemReg, _1, _2);
		staticMapBoxReg[ACTION::lady] = boostBind(ACTION::FORMATBOX::ItemReg, _1, _2);
		staticMapBoxReg[ACTION::paper] = boostBind(ACTION::FORMATBOX::ResReg, _1, _2);
		staticMapBoxReg[ACTION::contribution] = boostBind(ACTION::FORMATBOX::ResReg, _1, _2);
		staticMapBoxReg[ACTION::heroes_coin] = boostBind(ACTION::FORMATBOX::ResReg, _1, _2);
		staticMapBoxReg[ACTION::lady_coin] = boostBind(ACTION::FORMATBOX::ResReg, _1, _2);
		staticMapBoxReg[ACTION::vip_exp] = boostBind(ACTION::FORMATBOX::ResReg, _1, _2);
		staticMapBoxReg[ACTION::points] = boostBind(ACTION::FORMATBOX::ResReg, _1, _2);
		staticMapBoxReg[ACTION::search_points] = boostBind(ACTION::FORMATBOX::ResReg, _1, _2);
		staticMapBoxReg[ACTION::kingdom_skill_exp] = boostBind(ACTION::FORMATBOX::ItemReg, _1, _2);
		staticMapBoxReg[ACTION::exploit_coin] = boostBind(ACTION::FORMATBOX::ResReg, _1, _2);

		//action reg��ʼ��
		staticMapReg[ACTION::null] = boostBind(ACTION::FORMAT::NullReg, _1, _2);
		staticMapReg[ACTION::silver] = boostBind(ACTION::FORMAT::ResReg, _1, _2);
		staticMapReg[ACTION::ticket] = boostBind(ACTION::FORMAT::ResReg, _1, _2);
		staticMapReg[ACTION::gold] = boostBind(ACTION::FORMAT::ResReg, _1, _2);
		staticMapReg[ACTION::food] = boostBind(ACTION::FORMAT::ResReg, _1, _2);
		staticMapReg[ACTION::wood] = boostBind(ACTION::FORMAT::ResReg, _1, _2);
		staticMapReg[ACTION::iron] = boostBind(ACTION::FORMAT::ResReg, _1, _2);
		staticMapReg[ACTION::merit] = boostBind(ACTION::FORMAT::ResReg, _1, _2);
		staticMapReg[ACTION::fame] = boostBind(ACTION::FORMAT::ResReg, _1, _2);
		staticMapReg[ACTION::action] = boostBind(ACTION::FORMAT::ResReg, _1, _2);
		staticMapReg[ACTION::exp] = boostBind(ACTION::FORMAT::ResReg, _1, _2);
		staticMapReg[ACTION::man] = boostBind(ACTION::FORMAT::ResReg, _1, _2);
		staticMapReg[ACTION::item] = boostBind(ACTION::FORMAT::ItemReg, _1, _2);
		staticMapReg[ACTION::lady] = boostBind(ACTION::FORMAT::ItemReg, _1, _2);
		staticMapReg[ACTION::paper] = boostBind(ACTION::FORMAT::ResReg, _1, _2);
		staticMapReg[ACTION::contribution] = boostBind(ACTION::FORMAT::ResReg, _1, _2);
		staticMapReg[ACTION::heroes_coin] = boostBind(ACTION::FORMAT::ResReg, _1, _2);
		staticMapReg[ACTION::lady_coin] = boostBind(ACTION::FORMAT::ResReg, _1, _2);
		staticMapReg[ACTION::vip_exp] = boostBind(ACTION::FORMAT::ResReg, _1, _2);
		staticMapReg[ACTION::points] = boostBind(ACTION::FORMAT::ResReg, _1, _2);
		staticMapReg[ACTION::search_points] = boostBind(ACTION::FORMAT::ResReg, _1, _2);
		staticMapReg[ACTION::kingdom_skill_exp] = boostBind(ACTION::FORMAT::ItemReg, _1, _2);
		staticMapReg[ACTION::exploit_coin] = boostBind(ACTION::FORMAT::ResReg, _1, _2);

		//��������
		mapBoxDeclare[ACTION::null] = boostBind(nullRes, _1, _2);
		mapBoxDeclare[ACTION::silver] = boostBind(naturalRes, _1, _2, (int)ACTION::silver);
		mapBoxDeclare[ACTION::ticket] = boostBind(naturalRes, _1, _2, (int)ACTION::ticket);
		mapBoxDeclare[ACTION::gold] = boostBind(naturalRes, _1, _2, (int)ACTION::gold);
		mapBoxDeclare[ACTION::food] = boostBind(naturalRes, _1, _2, (int)ACTION::food);
		mapBoxDeclare[ACTION::wood] = boostBind(naturalRes, _1, _2, (int)ACTION::wood);
		mapBoxDeclare[ACTION::iron] = boostBind(naturalRes, _1, _2, (int)ACTION::iron);
		mapBoxDeclare[ACTION::merit] = boostBind(naturalRes, _1, _2, (int)ACTION::merit);
		mapBoxDeclare[ACTION::fame] = boostBind(naturalRes, _1, _2, (int)ACTION::fame);
		mapBoxDeclare[ACTION::action] = boostBind(naturalRes, _1, _2, (int)ACTION::action);
		mapBoxDeclare[ACTION::exp] = boostBind(naturalRes, _1, _2, (int)ACTION::exp);
		mapBoxDeclare[ACTION::man] = boostBind(manRes, _1, _2);
		mapBoxDeclare[ACTION::item] = boostBind(itemRes, _1, _2);
		mapBoxDeclare[ACTION::lady] = boostBind(cardRes, _1, _2);
		mapBoxDeclare[ACTION::paper] = boostBind(naturalRes, _1, _2, (int)ACTION::paper);
		mapBoxDeclare[ACTION::contribution] = boostBind(naturalRes, _1, _2, (int)ACTION::contribution);
		mapBoxDeclare[ACTION::heroes_coin] = boostBind(naturalRes, _1, _2, (int)ACTION::heroes_coin);
		mapBoxDeclare[ACTION::lady_coin] = boostBind(naturalRes, _1, _2, (int)ACTION::lady_coin);
		mapBoxDeclare[ACTION::vip_exp] = boostBind(naturalRes, _1, _2, (int)ACTION::vip_exp);
		mapBoxDeclare[ACTION::points] = boostBind(naturalRes, _1, _2, (int)ACTION::points);
		mapBoxDeclare[ACTION::search_points] = boostBind(naturalRes, _1, _2, (int)ACTION::search_points);
		mapBoxDeclare[ACTION::kingdom_skill_exp] = boostBind(kingdomExp, _1, _2);
		mapBoxDeclare[ACTION::exploit_coin] = boostBind(naturalRes, _1, _2, (int)ACTION::exploit_coin);

		//���ʵ���
		mapRateFunc[ACTION::silver] = boostBind(rate_cm_res, _1, _2);
		mapRateFunc[ACTION::ticket] = boostBind(rate_cm_res, _1, _2);
		mapRateFunc[ACTION::gold] = boostBind(rate_cm_res, _1, _2);
		mapRateFunc[ACTION::food] = boostBind(rate_cm_res, _1, _2);
		mapRateFunc[ACTION::wood] = boostBind(rate_cm_res, _1, _2);
		mapRateFunc[ACTION::iron] = boostBind(rate_cm_res, _1, _2);
		mapRateFunc[ACTION::merit] = boostBind(rate_cm_res, _1, _2);
		mapRateFunc[ACTION::fame] = boostBind(rate_cm_res, _1, _2);
		mapRateFunc[ACTION::action] = boostBind(rate_cm_res, _1, _2);
		mapRateFunc[ACTION::exp] = boostBind(rate_cm_res, _1, _2);
		mapRateFunc[ACTION::item] = boostBind(rate_item, _1, _2);
		mapRateFunc[ACTION::lady] = boostBind(rate_item, _1, _2);
		mapRateFunc[ACTION::paper] = boostBind(rate_cm_res, _1, _2);
		mapRateFunc[ACTION::contribution] = boostBind(rate_cm_res, _1, _2);
		mapRateFunc[ACTION::heroes_coin] = boostBind(rate_cm_res, _1, _2);
		mapRateFunc[ACTION::lady_coin] = boostBind(rate_cm_res, _1, _2);
		mapRateFunc[ACTION::vip_exp] = boostBind(rate_cm_res, _1, _2);
		mapRateFunc[ACTION::points] = boostBind(rate_cm_res, _1, _2);
		mapRateFunc[ACTION::search_points] = boostBind(rate_cm_res, _1, _2);
		mapRateFunc[ACTION::kingdom_skill_exp] = boostBind(rate_item, _1, _2);
		mapRateFunc[ACTION::exploit_coin] = boostBind(rate_cm_res, _1, _2);

		//ִ��Ч��
		mapDoFunc[ACTION::silver] = boostBind(do_silver, _1, _2);
		mapDoFunc[ACTION::ticket] = boostBind(do_ticket, _1, _2);
		mapDoFunc[ACTION::gold] = boostBind(do_gold, _1, _2);
		mapDoFunc[ACTION::food] = boostBind(do_food, _1, _2);
		mapDoFunc[ACTION::wood] = boostBind(do_wood, _1, _2);
		mapDoFunc[ACTION::iron] = boostBind(do_iron, _1, _2);
		mapDoFunc[ACTION::merit] = boostBind(do_merit, _1, _2);
		mapDoFunc[ACTION::fame] = boostBind(do_fame, _1, _2);
		mapDoFunc[ACTION::action] = boostBind(do_action, _1, _2);
		mapDoFunc[ACTION::exp] = boostBind(do_exp, _1, _2);
		mapDoFunc[ACTION::man] = boostBind(do_man, _1, _2);
		mapDoFunc[ACTION::item] = boostBind(do_item, _1, _2);
		mapDoFunc[ACTION::lady] = boostBind(do_lady, _1, _2);
		mapDoFunc[ACTION::paper] = boostBind(do_paper, _1, _2);
		mapDoFunc[ACTION::contribution] = boostBind(do_contribution, _1, _2);
		mapDoFunc[ACTION::heroes_coin] = boostBind(do_heroes_coin, _1, _2);
		mapDoFunc[ACTION::lady_coin] = boostBind(do_lady_coin, _1, _2);
		mapDoFunc[ACTION::vip_exp] = boostBind(do_vip_exp, _1, _2);
		mapDoFunc[ACTION::points] = boostBind(do_points, _1, _2);
		mapDoFunc[ACTION::search_points] = boostBind(do_search_points, _1, _2);
		mapDoFunc[ACTION::kingdom_skill_exp] = boostBind(do_kingdom_exp, _1, _2);
		mapDoFunc[ACTION::exploit_coin] = boostBind(do_exploit_coin, _1, _2);
	}
}

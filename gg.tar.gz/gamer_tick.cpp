#include "gamer_tick.h"
#include "dbDriver.h"

namespace gg
{
	playerTick::playerTick(playerData* const own) :_auto_player(own)
	{
		tick5C = Common::getNextTime(5);
		tick8C = Common::getNextTime(8);
		tick18C = Common::getNextTime(18);
	}

	void playerTick::tick5Event(const bool is_timer /* = true */)
	{
		unsigned stander = player_mgr.stander5();
		if (stander > tick5C)
		{
			tick5C = stander;
			_sign_auto();
			on5ClockTick(is_timer, 1);
		}
	}

	void playerTick::tick8Event(const bool is_timer /* = true */)
	{
		unsigned stander = player_mgr.stander8();
		if (stander > tick8C)
		{
			tick8C = stander;
			_sign_auto();
			on8ClockTick(is_timer, 1);
		}
	}

	void playerTick::tick18Event(const bool is_timer /* = true */)
	{
		unsigned stander = player_mgr.stander18();
		if (stander > tick18C)
		{
			tick18C = stander;
			_sign_auto();
			on18ClockTick(is_timer, 1);
		}
	}

	typedef boost::function< void() > TICKFUNC;
	typedef std::map< unsigned, TICKFUNC, less< unsigned > > MAPTICK;
	void playerTick::loginTick()
	{
		const unsigned now = Common::gameTime();
		unsigned tmp_tick5C = Common::getTodayTime(5);
		tmp_tick5C = (tmp_tick5C > now) ? (tmp_tick5C - DAY) : tmp_tick5C;
		unsigned tmp_tick8C = Common::getTodayTime(8);
		tmp_tick8C = (tmp_tick8C > now) ? (tmp_tick8C - DAY) : tmp_tick8C;
		unsigned tmp_tick18C = Common::getTodayTime(18);
		tmp_tick18C = (tmp_tick18C > now) ? (tmp_tick18C - DAY) : tmp_tick18C;
		
		MAPTICK MapTick;
		if (tmp_tick5C >= tick5C)
		{
			const unsigned per_time = (tmp_tick5C - tick5C) / DAY + 1;
			tick5C = tmp_tick5C + DAY;
			_sign_save();
			MapTick[tmp_tick5C] = boostBind(playerTick::on5ClockTick, this, false, per_time, true);
		}
		if (tmp_tick8C >= tick8C)
		{
			const unsigned per_time = (tmp_tick8C - tick8C) / DAY + 1;
			tick8C = tmp_tick8C + DAY;
			_sign_save();
			MapTick[tmp_tick8C] = boostBind(playerTick::on8ClockTick, this, false, per_time, true);
		}
		if (tmp_tick18C >= tick18C)
		{
			const unsigned per_time = (tmp_tick18C - tick18C) / DAY + 1;
			tick18C = tmp_tick18C + DAY;
			_sign_save();
			MapTick[tmp_tick18C] = boostBind(playerTick::on18ClockTick, this, false, per_time, true);
		}
		//ִ��
		for (MAPTICK::iterator it = MapTick.begin(); it != MapTick.end(); ++it)
		{
			it->second();
		}
	}

	void playerTick::loadDB()
	{
		mongo::BSONObj key = BSON(strPlayerID << Own().ID());
		mongo::BSONObj obj = db_mgr.FindOne(DBN::dbPlayerTick, key);
		if (obj.isEmpty())
		{
			tick5C = Common::getNextTime(5);
			tick8C = Common::getNextTime(8);
			tick18C = Common::getNextTime(18);
			_auto_save();
		}
		else
		{
			tick5C = (unsigned)obj["t5c"].Int();
			tick8C = (unsigned)obj["t8c"].Int();
			tick18C = (unsigned)obj["t18c"].Int();
		}
	}

	bool playerTick::_auto_save()
	{
		mongo::BSONObj key = BSON(strPlayerID << Own().ID());
		mongo::BSONObj obj = BSON(strPlayerID << Own().ID() << "t5c" << tick5C <<
			"t8c" << tick8C << "t18c" << tick18C);
		return db_mgr.SaveMongo(DBN::dbPlayerTick, key, obj);
	}

	void playerTick::_auto_update()
	{
		Json::Value json;
		json[strMsg][0u] = res_sucess;
		Json::Value& resJson = json[strMsg][1u];
		resJson["ti"] = tick5C;
		resJson["ti8"] = tick8C;
		resJson["ti18"] = tick18C;
		Own().sendToClient(gate_client::player_tick_time_resp, json);
	}

}
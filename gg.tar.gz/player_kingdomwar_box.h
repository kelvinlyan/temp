#pragma once

#include "auto_base.h"

namespace gg
{
	class playerKingdomWarBox
		: public _auto_player
	{
		public:
			playerKingdomWarBox(playerData* const own);
			
			void loadDB();
			virtual bool _auto_save();
			virtual void _auto_update();

			void update();

			int getReward(int id, Json::Value& r);
			void clear();

			int rpState();
			void resetRpState();
			void resetRpStateAndUpdate();

		private:
			std::vector<int> _box_state;
			int _rp_state;
	};
}

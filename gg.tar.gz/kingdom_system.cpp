#include "kingdom_system.h"
#include "kingfight_system.h"
#include "heroparty_system.h"

namespace gg
{
	struct KingdomStrength
	{
		KingdomStrength(int nation, int lv, int num)
			: _nation(nation), _con_lv(lv), _hero_num(num){}

		bool operator<(const KingdomStrength& rhs) const
		{
			if (_con_lv != rhs._con_lv)
				return _con_lv > rhs._con_lv;
			if (_hero_num != rhs._hero_num)
				return _hero_num > rhs._hero_num;
			return _nation < rhs._nation;
		}
		int _nation;
		int _con_lv;
		int _hero_num;
	};

	kingdom_system* const kingdom_system::_Instance = new kingdom_system();

	kingdom_system::kingdom_system()
	{
	}

	void kingdom_system::initData()
	{
		for (unsigned i = 0; i < Kingdom::nation_num; ++i)
			_kingdom.push_back(Creator<KingdomInfo>::Create((Kingdom::NATION)i));
		loadFile();
		loadDB();

		//Timer::AddEventSeconds(boostBind(kingdom_system::testTimer, this), Inter::event_king_fight_timer, 1);
	}

	void kingdom_system::addKingdom(net::Msg& m, Json::Value& r)
	{
		playerDataPtr d = player_mgr.getPlayer(m.playerID);
		if (!d) Return(r, err_illedge);
		if (d->LV() < 15)Return(r, err_player_lv_too_low);
		ReadJsonArray;
		int id = js_msg[0u].asInt();
		bool rand = false;
		if (id == (int)Kingdom::null)
		{
			rand = true;
			id = getRandKingdom();
		}
		int res = _kingdom[id]->join(d);
		if (rand && res == res_sucess)
		{
			d->Res->alterTicket(100);
			d->Res->alterSilver(100000);
		}
		Return(r, res);
	}

	void kingdom_system::showBuild(net::Msg& m, Json::Value& r)
	{
		playerDataPtr d = player_mgr.getPlayer(m.playerID);
		if (!d || d->Info->Nation() == Kingdom::null)
			Return(r, err_illedge);

		updateBuilding(d);
	}

	void kingdom_system::playerCon(net::Msg& m, Json::Value& r)
	{
		playerDataPtr d = player_mgr.getPlayer(m.playerID);
		if (!d || d->Info->Nation() == Kingdom::null)
			Return(r, err_illedge);

		ReadJsonArray;
		int type = js_msg[0u].asInt();
		int id = js_msg[1u].asInt();
		
		int res = _kingdom[d->Info->Nation()]->playerCon(d, id, type);
		Return(r, res);
	}
	
	void kingdom_system::showShop(net::Msg& m, Json::Value& r)
	{
		playerDataPtr d = player_mgr.getPlayer(m.playerID);
		if (!d || d->Info->Nation() == Kingdom::null) 
			Return(r, err_illedge);

		d->KingDom->updateShop();
	}

	void kingdom_system::refShop(net::Msg& m, Json::Value& r)
	{
		playerDataPtr d = player_mgr.getPlayer(m.playerID);
		if (!d || d->Info->Nation() == Kingdom::null) 
			Return(r, err_illedge);

		int res = d->KingDom->flush();
		Return(r, res);
	}

	void kingdom_system::playershop(net::Msg& m, Json::Value& r)
	{
		playerDataPtr d = player_mgr.getPlayer(m.playerID);
		if (!d || d->Info->Nation() == Kingdom::null) 
			Return(r, err_illedge);

		ReadJsonArray;
		int pos = js_msg[0u].asInt();

		int res = d->KingDom->buy(pos);
		Return(r, res);
	}

	void kingdom_system::showSkill(net::Msg& m, Json::Value& r)
	{
		playerDataPtr d = player_mgr.getPlayer(m.playerID);
		if (!d || d->Info->Nation() == Kingdom::null) 
			Return(r, err_illedge);

		d->KingDom->getSkillInfo(r[strMsg][1u]);
		Return(r, res_sucess);
	}

	void kingdom_system::upSkill(net::Msg& m, Json::Value& r)
	{
		playerDataPtr d = player_mgr.getPlayer(m.playerID);
		if (!d || d->Info->Nation() == Kingdom::null) 
			Return(r, err_illedge);

		ReadJsonArray;
		int id = js_msg[0u].asInt();
		int res = d->KingDom->upSkill(id);
		if (res == res_sucess)
			d->KingDom->getSkillInfo(r[strMsg][1u]);
		Return(r, res);
	}

	void kingdom_system::showRank(net::Msg& m, Json::Value& r)
	{
		playerDataPtr d = player_mgr.getPlayer(m.playerID);
		if (!d || d->Info->Nation() == Kingdom::null) 
			Return(r, err_illedge);

		ReadJsonArray;
		int type = js_msg[0u].asInt();
		type == 1? _kingdom[d->Info->Nation()]->getConRank(r[strMsg][1u])
			: _kingdom[d->Info->Nation()]->getHeroPartyRank(r[strMsg][1u]);
		Return(r, res_sucess);
	}

	void kingdom_system::showKingdom(net::Msg& m, Json::Value& r)
	{
		playerDataPtr d = player_mgr.getPlayer(m.playerID);
		if (!d || d->Info->Nation() == Kingdom::null) 
			Return(r, err_illedge);

		kingfight_sys.getData(d->Info->Nation())->getKingInfo(r[strMsg][1u]);
		_kingdom[d->Info->Nation()]->getBaseInfo(r[strMsg][1u]);
		Return(r, res_sucess);
	}

	void kingdom_system::changeAnnouncement(net::Msg& m, Json::Value& r)
	{
		playerDataPtr d = player_mgr.getPlayer(m.playerID);
		if (!d || d->Info->Nation() == Kingdom::null) 
			Return(r, err_illedge);

		ReadJsonArray;
		const std::string& str = js_msg[0u].asString();
		int res = _kingdom[d->Info->Nation()]->setAnnouncement(d, str);
		Return(r, res);
	}

	void kingdom_system::loadFile()
	{
		Json::Value json;
		json = Common::loadJsonFile("./instance/kingdom/kingdomconstruction.json");
		ForEach(Json::Value, it, json)
		{
			int id = (*it)["id"].asInt();
			_construction_conf[id] = Creator<KingdomConstructionConf>::Create(*it);
		}
		
		json = Common::loadJsonFile("./instance/kingdom/kingdomcontribution.json");
		_contribution_conf.load(json[0u]);

		json = Common::loadJsonFile("./instance/kingdom/conVip.json");
		ForEach(Json::Value, it, json)
			_vip_times.push_back((*it)["action"].asInt());

		json = Common::loadJsonFile("./instance/kingdom/kingdomshop.json");
		ShopDataMgr::init(json);
		
		json = Common::loadJsonFile("./instance/kingdom/shop_cost.json");
		ForEach(Json::Value, it, json)
			_flush_costs.push_back((*it).asInt());
	}
	
	void kingdom_system::loadDB()
	{
		for (unsigned i = 0; i < Kingdom::nation_num; ++i)
			_kingdom[i]->init();
	}

	const KingdomConstructionConfPtr kingdom_system::getConstructionConf(int id)
	{
		KingdomConstructionConfMap::iterator it = _construction_conf.find(id);
		return it == _construction_conf.end()? KingdomConstructionConfPtr() : it->second;
	}

	const KingdomContributionConf& kingdom_system::getContributionConf() const
	{
		return _contribution_conf;
	}

	unsigned kingdom_system::getMaxConTimes(int vip) const
	{
		if (vip < 0)
			vip = 0;
		if (vip >= _vip_times.size())
			vip = _vip_times.size() - 1;
		return _vip_times[vip];
	}

	int kingdom_system::getRandKingdom() const
	{
		int min_i = 0;
		unsigned min_v = _kingdom[0u]->getPlayerNum();
		for (int i = 1; i < Kingdom::nation_num; ++i)
		{
			if (_kingdom[i]->getPlayerNum() < min_v)
			{
				min_v = _kingdom[i]->getPlayerNum();
				min_i = i;
			}
		}
		return min_i;
	}

	void kingdom_system::updateConRank(playerDataPtr d, int old_con)
	{
		if (d->Info->Nation() == Kingdom::null)
			return;
		_kingdom[d->Info->Nation()]->update(d, old_con);
	}

/*
	const KingdomShopConfPtr kingdom_system::getShopConf(int id)
	{
		KingdomShopConfMap::iterator it = _shop_map.find(id);
		if (it != _shop_map.end())
			return it->second;
		return KingdomShopConfPtr();
	}
*/	

	int kingdom_system::getFlushCost(unsigned times) const
	{
		if (times >= _flush_costs.size())
			times = _flush_costs.size() - 1;
		return _flush_costs[times];
	}

/*
	const KingdomShopConfList kingdom_system::getShopList(int nation)
	{
		KingdomShopConfList shop_list;
		if (nation == Kingdom::null)
			return shop_list;

		KingdomShopConfList fix = _shopFix[nation];
		KingdomShopConfList rd = _shopRd[nation];

		unsigned rdNum = 0;
		if (fix.size() < 8)
			rdNum = 8 - fix.size();
		shop_list = fix;

		unsigned tmp_total = _weight[nation];
		for (unsigned i = 0; i < rdNum; i++)
		{
			const unsigned rd_num = Common::randomBetween(0, tmp_total - 1);
			unsigned real_num = 0;
			for (unsigned idx = 0; idx < rd.size(); idx++)
			{
				real_num += rd[idx]->_weight;
				if (real_num > rd_num)
				{
					shop_list.push_back(rd[idx]);
					tmp_total -= rd[idx]->_weight;
					rd.erase(rd.begin() + idx);
					break;
				}
			}
		}
		return shop_list;
	}
*/
	void kingdom_system::updateBuilding(playerDataPtr d)
	{
		if (d->Info->Nation() == Kingdom::null)
			return;
		
		Json::Value msg;
		msg[strMsg][0u] = res_sucess;
		_kingdom[d->Info->Nation()]->getConstruction(msg[strMsg][1u]);
		d->KingDom->getInfo(msg[strMsg][1u]);
		d->sendToClient(gate_client::player_kingdom_showbuild_resp, msg);
	}

	int kingdom_system::upgradeConstruction(int nation, int id, int exp)
	{
		if (nation == Kingdom::null)
			return err_illedge;
		
		return _kingdom[nation]->addConstuctionExp(id, exp);
	}

	const KingdomPtr kingdom_system::getData(int nation) const
	{
		if (nation == Kingdom::null)
			return KingdomPtr();
		return _kingdom[nation];
	}

	void kingdom_system::tickRank()
	{
		resetStrengthRank();
		for (unsigned i = 0; i < Kingdom::nation_num; ++i)
			_kingdom[i]->tick();
	}

	void kingdom_system::resetStrengthRank()
	{
		int weiNum = _kingdom[Kingdom::wei]->getTotalLv();
		int shuNum = _kingdom[Kingdom::shu]->getTotalLv();
		int wuNum = _kingdom[Kingdom::wu]->getTotalLv();

		int weiHeroNum = heroparty_sys.heropartyNationPlayerNum(Kingdom::wei);
		int shuHeroNum = heroparty_sys.heropartyNationPlayerNum(Kingdom::shu);
		int wuHeroNum = heroparty_sys.heropartyNationPlayerNum(Kingdom::wu);
		
		vector<KingdomStrength> kingdomStrengthList;
		kingdomStrengthList.push_back(KingdomStrength(Kingdom::wei, weiNum, weiHeroNum));
		kingdomStrengthList.push_back(KingdomStrength(Kingdom::shu, shuNum, shuHeroNum));
		kingdomStrengthList.push_back(KingdomStrength(Kingdom::wu, wuNum, wuHeroNum));
		std::sort(kingdomStrengthList.begin(), kingdomStrengthList.end());

		for (unsigned i = 0; i < kingdomStrengthList.size(); ++i)
			_strength_rank[kingdomStrengthList[i]._nation] = i + 1;
	}

	int kingdom_system::getRate(int strength_rank) const
	{
		const static int Rate[] = {5, 0, -5};
		return Rate[strength_rank - 1];
	}

	void kingdom_system::testTimer()
	{
		Timer::AddEventSeconds(boostBind(kingdom_system::testTimer, this), Inter::event_king_fight_timer, 1);
	}
}

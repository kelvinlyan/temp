#include "player_patrol.h"
#include "dbDriver.h"
#include <iterator>

namespace gg
{
	const std::string strPos = "pos"; //��ǰѲ��λ��
	const std::string strState = "state"; //��ǰ״̬
	const std::string strSEventIdx = "sid"; //�����¼�idx
	const std::string strEEventIdx = "eid"; //�յ㱦��idx
	const std::string strREventType = "rtype"; //����¼�����
	const std::string strCardId = "card"; //��Ůid
	const std::string strLevel = "lv"; //��Ů�ȼ�

	static int CardId = -1;
	static int Level = -1;


	playerPatrol::playerPatrol(playerData* const own)
		:_auto_player(own),
		_curr_pos(1),
		_state(patrol::PatrolUninit),
		_curr_s_event_idx(0),
		_end_point_box_idx(-1)
	{
		_curr_event.type = patrol::PatrolNone;
	}

	void playerPatrol::setPos(unsigned pos, bool add)
	{
		if (add)
		{
			if (pos > 0)
			{
				_curr_pos = _curr_pos + pos > END_POINT ? END_POINT : _curr_pos + pos;
			}
		}
		else
		{
			_curr_pos = pos;
		}
		_auto_save();
	}

	void playerPatrol::loadDB()
	{
		mongo::BSONObj key BSON(strPlayerID << Own().ID());
		mongo::BSONObj obj = db_mgr.FindOne(DBN::dbPlayerPatrol, key);
		if (!obj.isEmpty())
		{
			int CurrPos = obj[strPos].Int();
			int State = obj[strState].Int();
			int SIdx = obj[strSEventIdx].Int();
			int EIdx = obj[strEEventIdx].Int();
			int RType = obj[strREventType].Int();
			int CardId = obj[strCardId].Int();
			int Level = obj[strLevel].Int();
			
			setPos(CurrPos);
			setStateFromInt(State);
			setRandomEventFromInt(RType);
			//���������������۸ģ����ܻ��������ط�����ϵͳ�ı���
			_curr_s_event_idx = SIdx;
			_end_point_box_idx = EIdx;
			_curr_event.cardId = CardId;
			_curr_event.level = Level;
		}
	}

	bool playerPatrol::_auto_save()
	{
		mongo::BSONObj key = BSON(strPlayerID << Own().ID());
		mongo::BSONObj obj = BSON(strPlayerID << Own().ID()
			<< strPos << _curr_pos
			<< strState << (int)_state
			<< strSEventIdx << _curr_s_event_idx 
			<< strEEventIdx << _end_point_box_idx
			<< strREventType << (int)_curr_event.type 
			<< strCardId << _curr_event.cardId 
			<< strLevel << _curr_event.level);

		return db_mgr.SaveMongo(DBN::dbPlayerPatrol, key, obj);
	}

	void playerPatrol::setRandomEventFromInt(int type)
	{
		if (type == 1)
		{
			_curr_event.type = patrol::PatrolOneStar;
		}
		else if (type == 2)
		{
			_curr_event.type = patrol::PatrolTwoStar;
		}
		else if (type == 3)
		{
			_curr_event.type = patrol::PatrolThreeStar;
		}
		else if (type == 4)
		{
			_curr_event.type = patrol::PatrolLadyCoin;
		}
		else if (type == 5)
		{
			_curr_event.type = patrol::PatrolDice;
		}
		else
		{
			_curr_event.type = patrol::PatrolNone;
		}
	}

	void playerPatrol::setStateFromInt(int state)
	{
		if (state == 102)
		{
			_state = patrol::PatrolPenddingDice;
		}
		else if (state == 103)
		{
			_state = patrol::PatrolPenddingEvent;
		}
		else if (state == 104)
		{
			_state = patrol::PatrolPenddingRewardRandom;
		}
		else if (state == 105)
		{
			_state = patrol::PatrolPenddingRewardSpecial;
		}
		else if (state == 106)
		{
			_state = patrol::PatrolPenddingBox;
		}
		else
		{
			_state = patrol::PatrolUninit;
		}
	}

	void playerPatrol::restart()
	{
		if (_curr_pos != END_POINT)//����������յ㣬����ȡ����ɡ�
		{
			setPos(1);
			setState(patrol::PatrolPenddingDice);
			setEndPointIdx(-1);
		}
	}

	void playerPatrol::addTimer()
	{
//#ifdef PATROL_DEBUG
//		{
//			delTimer();
//			_timerId = Timer::AddEventSeconds(boostBind(playerPatrol::restoreHalfTick, _1, Own().ID()), Inter::event_patrol_dice_restore, 20 * MINUTE);
//		}
//#endif
		if (Own().LV() > PATROL_LEVEL_LIMIT)
		{
			delTimer();
			_timerId = Timer::AddEventSeconds(boostBind(playerPatrol::restoreHalfTick, _1, Own().ID()), Inter::event_patrol_dice_restore, 30 * MINUTE);
		}
	}

	void playerPatrol::delTimer()
	{
		if (_timerId)
		{
			_timerId->delTimer();
		}
		_timerId = ptrTimerIdentify();
	}

	void playerPatrol::addTickTimer()
	{
//#ifdef PATROL_DEBUG
//		{
//			delTickTimer();
//			_tenTimerId = Timer::AddEventTickTime(boostBind(playerPatrol::addFiveDice, _1, Own().ID()), Inter::event_patrol_dice_five, Common::getNextTime(11,35));
//			_twentyOneTimerId = Timer::AddEventTickTime(boostBind(playerPatrol::addFiveDice, _1, Own().ID()), Inter::event_patrol_dice_five, Common::getNextTime(11, 50));
//		}
//#endif
		if (Own().LV() > PATROL_LEVEL_LIMIT)
		{
			delTickTimer();
			_tenTimerId = Timer::AddEventTickTime(boostBind(playerPatrol::addFiveDice, _1, Own().ID()), Inter::event_patrol_dice_five, Common::getNextTime(10));
			_twentyOneTimerId = Timer::AddEventTickTime(boostBind(playerPatrol::addFiveDice, _1, Own().ID()), Inter::event_patrol_dice_five, Common::getNextTime(21));
		}
	}

	void playerPatrol::delTickTimer()
	{
		if (_twentyOneTimerId)
		{
			_twentyOneTimerId->delTimer();
		}
		if (_tenTimerId)
		{
			_tenTimerId->delTimer();
		}
		_twentyOneTimerId = ptrTimerIdentify();
		_tenTimerId = ptrTimerIdentify();
	}


	void playerPatrol::restoreHalfTick(const structTimer& timerData, const int playerID)
	{
		playerDataPtr player = player_mgr.getOnlinePlayer(playerID);
		if (!player || player->LV() < PATROL_LEVEL_LIMIT)
		{
//#ifdef PATROL_DEBUG
//			{
//				player->Res->alterDice(1);
//				player->Patrol->addTimer();
//			}
//#endif
			return;
		}

		player->Res->alterDice(1);
		player->Patrol->addTimer();
	}

	void playerPatrol::addFiveDice(const structTimer & timerData, const int playerID)
	{
		playerDataPtr player = player_mgr.getOnlinePlayer(playerID);

		if (!player || player->LV() < PATROL_LEVEL_LIMIT)
		{
//#ifdef PATROL_DEBUG
//			{
//				player->Res->alterDice(5);
//				player->Patrol->addTickTimer();
//			}
//#endif
			return;
		}

		player->Res->alterDice(5);
		player->Patrol->addTickTimer();
	}

	playerPatrol::~playerPatrol()
	{
	}

}
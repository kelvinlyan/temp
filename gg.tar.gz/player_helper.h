#pragma once

#include "auto_base.h"
#include "battle_def.h"

namespace gg
{
	class playerMan;
	SHAREPTR(playerMan, playerManPtr);
	STDVECTOR(playerManPtr, ManList);

	unsigned getCurrentHp(const sBattlePtr& ptr);
	unsigned getMaxHp(const sBattlePtr& ptr);
	int getFirstManID(const ManList& man_list);
	BattleEquipList getEquipList(const ManList& man_list);
	qValue equipQ(const BattleEquipList& equip_list);
}

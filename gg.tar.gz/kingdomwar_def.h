#pragma once

#include <string>

namespace gg
{
	namespace KingdomWar
	{
		enum
		{
			ArmyNum = 3,
			ArmyMaxHp = 100,

			PosEmpty = -1,
			PosCity,
			PosPath,
			PosSiege,

			//
			Left = 0,
			Right,
			MaxSide,

			// 
			Player = 0,
			Npc,
			Npc2,

			//
			Enter = 0,
			Leave,
			Defeated,
			HpEmpty,

			// 
			Win = 0,
			Lose,

			//
			ResMove = 0,
			ResHpEmpty,
			ResDefeated,
			ResKickBack,
		};

		const static std::string strNpcID = "ni";
	}
}

//###################################
//create by Jim
//2015-11-12
//###################################

#pragma once

#include "auto_do.h"

#define DICE_MAX	30	//���������

namespace gg
{
	class playerTick;

	class playerResource :
		public _auto_player
	{
		friend class playerTick;
	public:
		playerResource(playerData* const own);
		~playerResource(){}
		inline int getGold(){ return Gold; }//���
		inline int getTicket(){ return Ticket;}//��ȯ
		inline int getCash(){ return Gold + Ticket; }//���+��ȯ
		inline int getSilver(){ return Silver;/* +getCash() * 100;*/ }//����
		inline int getTroops(){ return Troops; }//���ñ���
		inline int getFood(){ return Food; }//��ʳ
		inline int getWood(){ return Wood; }//ľ
		inline int getIron(){ return Iron; }//��
		inline int getMerit(){ return Merit; }//����
		inline int getFame(){ return Fame; }//����
		inline int getAction(){ return Action; }//����//�ж�����
		inline int getHeroPartyMoney(){ return HeroPartyMoney; }//ȺӢ����
		inline int getLadyCoin(){ return LadyCoin; }//����
		inline int getShare(){ return shareTimes; }
		inline int getPaper(){ return RedPaper; }
		inline int getPoints(){ return Points; }
		inline int getSearchPoints(){ return SearchPoints; }
		int getExploit();
		int getContribution();
		inline int getDice() { return Dice; }


		//motify
		int alterSilver(const int val);
		int alterTicket(const int val, const bool isConsume = true);
		int alterGold(const int val, const bool isConsume = true);
		int alterCash(const int val, const bool isConsume = true);
		int alterTroops(const int val);
		int alterFood(const int val);
		int alterWood(const int val);
		int alterIron(const int val);
		int alterMerit(const int val);
		int alterFame(const int val);
		int alterAction(const int val);
		int alterContribution(const int val);
		int alterHeroPartyMoney(const int val);
		int alterLadyCoin(const int val);
		int alterShareTimes(const int val);
		int alterPaper(const int val);
		int alterPoints(const int val);
		int alterSearchPoints(const int val);
		void addRechargeNum(const int num);
		void alterExploit(const int val);
		int alterDice(const int val);

		//other
		void loadDB();
		virtual void _auto_update();
	private:
		void onAlterGold(const int old_val);
		void onAlterTicket(const int old_val);
		void onAlterAction(const int old_val);
		void onAlterContribution(const int alter_val);
		virtual bool _auto_save();
		void initial();
		int Gold;//���
		int Ticket;//���ͽ��
		int Silver;//����
		int Troops;//����
		int Food;//��ʳ
		int Wood;//ľ��
		int Iron;//��
		int Merit;//����
		int Fame;//����
		int Action;//�ж���//����
		//int Contribution;//���ҹ���ֵ
		int HeroPartyMoney;//ȺӢ����
		int LadyCoin;//����
		int shareTimes;//ս����������
		int RedPaper;//�����
		int Points;//����
		int SearchPoints;//Ѱ�û���
		unsigned RechargeNum;//��ֵ����
		unsigned Dice;//��������
	};
}

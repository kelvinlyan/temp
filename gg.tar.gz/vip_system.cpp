#include "vip_system.h"

namespace gg
{
	vip_system* const vip_system::_Instance = new vip_system();

	void	 vip_system::initData()
	{
		cout << "load vip system ..." << endl;
		Json::Value vipBox = Common::loadJsonFile("./instance/vip/vipgift.json");
		for (unsigned i = 0; i < vipBox.size(); i++)
		{
			vipGiftDataPtr objPtr = Creator<vipGiftData>::Create();
			objPtr->vipLv = vipBox[i]["viplv"].asInt();
			objPtr->box = actionFormatBox(vipBox[i]["box"]);
			vipGiftConfig[objPtr->vipLv] = objPtr;
		}
	//	Json::Value json = Common::loadJsonFile("./instance/vip/firstgift.json");
	//	firstGift = actionFormatBox(json);
	}

	vipGiftDataPtr vip_system::getVipGif(int lv)
	{
		vipGiftDataMap::iterator it = vipGiftConfig.find(lv);
		if (it != vipGiftConfig.end()) return it->second;
		return vipGiftDataPtr();
	}

	void vip_system::showGift(net::Msg& m, Json::Value& r)
	{
		ReadJsonArray;

		const int playerID = m.playerID;

		playerDataPtr player = player_mgr.getPlayer(playerID);
		if (!player) Return(r, err_illedge);

		r[strMsg][1u] = player->Vip->formatgift();
		//cout << r << endl;
		Return(r, res_sucess);
	}

	void vip_system::getGift(net::Msg& m, Json::Value& r)
	{
		ReadJsonArray;

		const int playerID = m.playerID;
		const int id = js_msg[0u].asInt();

		playerDataPtr player = player_mgr.getPlayer(playerID);
		if (!player) Return(r, err_illedge);

		int resR = player->Vip->getVipGift(id);
		r[strMsg][1u] = player->Vip->formatgift();
		//cout << r << endl;
		Return(r, resR);
	}

	void vip_system::addVip(net::Msg& m, Json::Value& r)
	{
		ReadJsonArray;

		const int playerID = m.playerID;
		const int num = js_msg[0u].asInt();

		playerDataPtr player = player_mgr.getPlayer(playerID);
		if (!player) Return(r, err_illedge);

		player->Info->addVipExp(num);
		//cout << r << endl;
		Return(r, res_sucess);
	}

	void vip_system::getFirstGift(net::Msg& m, Json::Value& r)
	{
		playerDataPtr player = player_mgr.getPlayer(m.playerID);
		if (!player) Return(r, err_illedge);
		
		int res = player->Vip->getFirstGift(r[strMsg][1u]);
		//cout << r << endl;
		Return(r, res);
	}
}

#include "player_rescue.h"
#include "rescue_system.h"
#include "kingdom_system.h"

namespace gg
{
	static vector<int> rwLimit;
	int playerRescue::getLimit()
	{
		//const int level = kingdom_sys.getCountryLevel(Own().Info->Nation());
		const KingdomPtr ptr = kingdom_sys.getData(Own().Info->Nation());
		int level = ptr? ptr->getLevel() : 0;
		if (level < 0 || level >= (int)rwLimit.size())return 0;
		return rwLimit[level];
	}
	void playerRescue::initData()
	{
		{
			rwLimit.clear();
			Json::Value json = Common::loadJsonFile("./instance/rescue/reward_limit.json");
			for (unsigned i = 0; i < json.size(); ++i)
			{
				rwLimit.push_back(json[i].asInt());
			}
		};
	}

	void playerRescue::loadDB()
	{
		mongo::BSONObj  key = BSON(strPlayerID << Own().ID());
		mongo::BSONObj obj = db_mgr.FindOne(DBN::dbPlayerRescue, key);
		if (obj.isEmpty())return;
		rewardNum = obj["rn"].Int();
	}

	int playerRescue::wonReward(const int num)
	{
		if (num < 1)return 0;
		int con_num = num;
		const int max_today = getLimit();
		if ((rewardNum + num) > max_today)
		{
			con_num = max_today - rewardNum;
			rewardNum = max_today;
		}
		else
		{
			rewardNum += num;
		}
		Own().Res->alterContribution(con_num);
		_sign_auto();
		return con_num;
	}

	playerRescue::playerRescue(playerData* const own) :_auto_player(own)
	{
		rewardNum = 0;
	}

	void playerRescue::_auto_update()
	{
		Json::Value json;
		json[strMsg][0u] = res_sucess;
		Json::Value& dataJson = json[strMsg][1u];
		dataJson["rn"] = rewardNum;
		Own().sendToClient(gate_client::player_rescue_update_resp, json);
	}

	bool playerRescue::_auto_save()
	{
		mongo::BSONObj  key = BSON(strPlayerID << Own().ID());
		mongo::BSONObj  obj = BSON(strPlayerID << Own().ID() << "rn" << rewardNum);
		return db_mgr.SaveMongo(DBN::dbPlayerRescue, key, obj);
	}
}

#include "kingdomwar_city.h"
#include "kingdomwar_system.h"
#include "player_helper.h"
#include "map_war.h"
#include "net_helper.hpp"

namespace gg
{
	namespace KingdomWar
	{
		enum
		{
			// param
			QueueMemNum = 8,
			QueueNum = 3,
			DefSpeed = 10,
			AttackInterval = 6,
			AttackerWaitTime = 60,
			DefenderWaitTime = 60,
			StartWaitTime = 10,

			// queue state
			Free = 0,
			Wait,
			Busy,
		};

		static CItemPtr makeCityItem(const mongo::BSONElement& obj, CityPtr& ptr)
		{
			int type = obj["t"].Int();
			switch(type)
			{
				case Player:
					return Creator<CityItemPlayer>::Create(obj, ptr);
				case Npc:
				case Npc2:
					return Creator<CityItemNpc>::Create(obj, ptr);
				default:
					return CItemPtr();
			}
		}

		CityReportData::CityReportData(unsigned cur_time, CItemPtr& atk_ptr, CItemPtr& def_ptr)
			: path("")
		{
			time = cur_time;
			atk_info = atk_ptr->getBattleInfo();
			def_info = def_ptr->getBattleInfo();
		}

		void CityReportData::one2one()
		{
			result = battle_sys.One2One(data, atk_info.ptr, def_info.ptr, typeBattle::kingdomwar);
			if (result.res == resBattle::atk_win)
				++atk_info.win_streak;
			else
				++def_info.win_streak;
			atk_info.cur_hp = getCurrentHp(atk_info.ptr);
			def_info.cur_hp = getCurrentHp(def_info.ptr);
		}

		void CityReportData::done()
		{
			data.Done(typeBattle::kingdomwar);
		}

		void CityReportData::getInfo(qValue& q)
		{
			q.append(path);
			q.append(atk_info.max_hp);
			q.append(atk_info.pre_hp);
			q.append(atk_info.cur_hp);
			q.append(def_info.max_hp);
			q.append(def_info.pre_hp);
			q.append(def_info.cur_hp);
			q.append((int)result.res);
			q.append(atk_info.win_streak);
			q.append(def_info.win_streak);
		}
	
		CityItemPlayer::CityItemPlayer(const mongo::BSONElement& obj, CityPtr& ptr)
			: CityItemBase(ptr)
		{
			_pid = obj["p"].Int();
			_army_id = obj["a"].Int();
			playerDataPtr d = player_mgr.getPlayer(_pid);
			_name = d->Name();
			_nation = d->Info->Nation();
			_face = getFirstManID(d->KingDomWarFM->getFM(_army_id));
			_equip = getEquipList(d->KingDomWarFM->getFM(_army_id));
			_lv = d->LV();
		}

		CityItemPlayer::CityItemPlayer(playerDataPtr& d, int army_id, CityPtr& ptr)
			: CityItemBase(ptr)
		{
			_pid = d->ID();
			_name = d->Name();
			_nation = d->Info->Nation();
			_army_id = army_id;
			_face = getFirstManID(d->KingDomWarFM->getFM(army_id));
			_equip = getEquipList(d->KingDomWarFM->getFM(army_id));
			_lv = d->LV();
		}

		mongo::BSONObj CityItemPlayer::toBSON() const
		{
			return BSON("t" << (int)Player << "p" << _pid << "a" << _army_id);
		}

		void CityItemPlayer::getInfo(qValue& q) const
		{
			q.append(_pid);
			q.append(_army_id);
			q.append(_name);
			q.append(_nation);
			q.append(_face);
			q.append(equipQ(_equip));
		}

		void CityItemPlayer::getInfo2(qValue& q, int state) const
		{
			q.append(_name);
			q.append(_lv);
			q.append(_nation);
			q.append(state);
		}

		BattleInfo CityItemPlayer::getBattleInfo()
		{
			playerDataPtr d = player_mgr.getPlayer(_pid);
			BattleInfo info;
			info.ptr = kingdomwar_sys.getBattlePtr(d, _army_id, info.max_hp, info.pre_hp);
			info.win_streak = d->KingDomWar->winStreak(_army_id);
			return info;
		}

		void CityItemPlayer::resetHp(sBattlePtr& ptr)
		{
			playerDataPtr d = player_mgr.getPlayer(_pid);
			manList& ml = ptr->battleMan;
			for (unsigned i = 0; i < ml.size(); ++i)
			{
				if (!ml[i])
					continue;
				d->KingDomWar->setManHp(ml[i]->manID, ml[i]->currentHP);
			}
		}

		bool CityItemPlayer::isDead()
		{
			playerDataPtr d = player_mgr.getPlayer(_pid);	
			return d->KingDomWar->isDead(_army_id);
		}

		void CityItemPlayer::beDead(unsigned time, int reason)
		{
			playerDataPtr d = player_mgr.getPlayer(_pid);	
			kingdomwar_sys.goBackMainCity(time, d, _army_id, reason);
		}

		void CityItemPlayer::doneBattle(CityReportData& rep_data, CItemPtr& target, bool atk_side)
		{
			resetHp(atk_side? rep_data.atk_info.ptr : rep_data.def_info.ptr);

			playerDataPtr d = player_mgr.getPlayer(_pid);

			// result
			int result = repResult(rep_data.result.res, atk_side);
			int star = rep_data.result.star;

			// exploit
			int exploit = result == Win?
				kingdomwar_sys.winExploit(star) : kingdomwar_sys.loseExploit(star);
			d->Res->alterExploit(exploit);

			// hp
			int hp_cost = result == Win?
				kingdomwar_sys.winHpCost(star) : kingdomwar_sys.loseHpCost(star);
			hp_cost = d->KingDomWar->alterArmyHp(_army_id, 0 - hp_cost);

			// rep
			int pos = PosCity;
			int tips = repTips(result, d, _army_id);
			qValue rep;
			rep << rep_data.time << _city->id() << _army_id << _face << target->name() 
				<< target->nation() << target->type() << pos << result << exploit << tips 
				<< hp_cost;
			std::string rpath = d->KingDomWar->addReport(rep, result, pos, _army_id);
			rep_data.data.addCopyField(rpath);
			if (rep_data.path == "")
				rep_data.path = rpath;
			
			// 
			qValue rw;
			qValue tmp;
			tmp.append(ACTION::exploit_coin);
			tmp.append(exploit);
			rw.append(tmp);
			rep_data.data.addReportdeclare(atk_side? "rwa" : "rwb", rw);

			if (result == Lose || isDead())
				kingdomwar_sys.goBackMainCity(rep_data.time, d, _army_id, result == Lose? ResDefeated : ResHpEmpty);
		}

		CityItemNpc::CityItemNpc(NpcDataPtr npc_data, CityPtr& ptr)
			: CityItemBase(ptr), _data(npc_data)
		{
		}
		
		CityItemNpc::CityItemNpc(const mongo::BSONElement& obj, CityPtr& ptr)
			: CityItemBase(ptr)
		{
			int id = obj["i"].Int();
			_data = kingdomwar_sys.getNpc(id);
		}

		mongo::BSONObj CityItemNpc::toBSON() const
		{
			return BSON("t" << _data->type() << "i" << _data->id());
		}

		inline int CityItemNpc::face() const
		{
			return _data->npcData()->npcList.front().npcID;
		}

		inline int CityItemNpc::lv() const
		{
			return _data->npcData()->mapLevel;
		}

		void CityItemNpc::getInfo(qValue& q) const
		{
			q.append(_data->id());
			q.append(face());
			q.append(nation());
			q.append(_data->type());
		}

		void CityItemNpc::getInfo2(qValue& q, int state) const
		{
			q.append(face());
			q.append(lv());
			q.append(nation());
			q.append(state);
		}

		void CityItemNpc::beDead(unsigned time, int reason)
		{
			_data->setDead();
		}

		void CityItemNpc::doneBattle(CityReportData& rep_data, CItemPtr& target, bool atk_side)
		{
			// result
			int result = repResult(rep_data.result.res, atk_side);
			int star = rep_data.result.star;

			// hp
			int hp_cost = result == Win?
				kingdomwar_sys.winHpCost(star) : kingdomwar_sys.loseHpCost(star);
			hp_cost = _data->alterHp(0 - hp_cost);
			
			// man_hp
			_data->resetManHp(atk_side? rep_data.atk_info.ptr : rep_data.def_info.ptr);

			qValue rw;
			rep_data.data.addReportdeclare(atk_side? "rwa" : "rwb", rw);

			if (result == Lose || isDead())
				beDead(rep_data.time, result == Lose? ResDefeated : ResHpEmpty);
		}

		BattleInfo CityItemNpc::getBattleInfo()
		{
			BattleInfo info;
			info.ptr = _data->getBattlePtr(info.max_hp, info.pre_hp);
			info.win_streak = 0;
			return info;
		}

		CItemCounter::CItemCounter()
		{
			_num.assign(Kingdom::nation_num + 1, 0);
		}

		void CItemCounter::push(CItemPtr ptr)
		{
			int idx = ptr->type() == Npc?
				Kingdom::nation_num : ptr->nation();
			++_num[idx];
			if (ptr->type() == Player)
			{
				CItemPlayer pptr = upCast<CityItemPlayer>(ptr);
				pushPlayer(_player_info, pptr);
			}
		}

		void CItemCounter::pop(CItemPtr ptr)
		{
			int idx = ptr->type() == Npc?
				Kingdom::nation_num : ptr->nation();
			--_num[idx];
			if (ptr->type() == Player)
			{
				CItemPlayer pptr = upCast<CityItemPlayer>(ptr);
				popPlayer(_player_info, pptr);
			}
		}

		void CItemCounter::clear()
		{
		
		}

		bool CItemCounter::pushPlayer(CItemMap& cmap, CItemPlayer& ptr)
		{
			CItemMap::iterator it = cmap.find(ptr->pid());
			if (it == cmap.end())
			{
				cmap[ptr->pid()] = CItemPlayerVec(1, ptr); 
				return true;
			}
			CItemPlayerVec& vec = it->second;
			ForEach(CItemPlayerVec, itp, vec)
			{
				if ((*itp) == ptr)
					return false;
			}
			vec.push_back(ptr);
			return true;
		}
		
		bool CItemCounter::popPlayer(CItemMap& cmap, CItemPlayer& ptr)
		{
			CItemMap::iterator it = cmap.find(ptr->pid());
			if (it == cmap.end())
				return false;
			CItemPlayerVec& vec = it->second;
			ForEach(CItemPlayerVec, itp, vec)
			{
				if ((*itp) == ptr)
				{
					vec.erase(itp);
					if (vec.empty())
						cmap.erase(it);
					return true;
				}
			}
			return false;
		}

		void CItemCounter::updateName(playerDataPtr& d)
		{
			CItemMap::iterator it = _player_info.find(d->ID());
			if (it == _player_info.end())
			{
				LogE << "kingdom war update name error: " << d->ID() << LogEnd;
				return;
			}
			CItemPlayerVec& vec = it->second;
			ForEach(CItemPlayerVec, itp, vec)
				(*itp)->alterName(d->Name());
		}

		inline void UpCItem::getInfo(qValue& q) const
		{
			q.append(_type);
			_ptr->getInfo(q);
		}

		UpDataMgr::UpDataMgr()
		{
			_up_datas.assign(QueueNum, UpData());
		}

		inline void UpDataMgr::push(int queue_id, int type, int side, const CItemPtr& ptr)
		{
			_up_datas[queue_id]._up_items.push_back(UpCItem(type, side, ptr));
		}

		inline void UpDataMgr::push(int queue_id, const qValue& rep)
		{
			_up_datas[queue_id]._up_reps.append(rep);
		}
		
		void UpDataMgr::clear()
		{
			for (unsigned i = 0; i < QueueNum; ++i)
			{
				_up_datas[i]._up_items.clear();
				_up_datas[i]._up_reps.toArray();
			}
		}

		void UpDataMgr::getInfo(qValue& q)
		{
			for (unsigned i = 0; i < QueueNum; ++i)
			{
				qValue qq;
				qValue atk_q;
				qValue def_q;
				ForEachC(UpData::UpCItems, it, _up_datas[i]._up_items)
				{
					qValue tmp;
					(*it).getInfo(tmp);
					if ((*it).side() == Left)
						atk_q.append(tmp);
					else
						def_q.append(tmp);
				}
				qq.append(atk_q);
				qq.append(def_q);
				qq.append(_up_datas[i]._up_reps);
				q.append(qq);
			}
		}

		BattleField::BattleField(CityPtr& ptr)
			: _city(ptr)
		{
			_state = Closed;	
			_next_tick_time = 0;
			_first_battle_nation = -1;
			_next_battle_time.assign(QueueNum, 0);
			_queue_state.assign(QueueNum, (int)Free);
			_attacker_queue.assign(QueueNum, CItemQueue());
			_defender_queue.assign(QueueNum, CItemQueue());
			_rep_backup.assign(QueueNum, qValue());
			_wins.assign(Kingdom::nation_num + 1, -1);
			_counter = _city->_counter;

			_atk_wait_timer = 0;
			_def_wait_timer = 0;
			_battle_timer.assign(QueueNum, 0);
			_modified = true;
		}

		void BattleField::init()
		{
			loadDB();
			kingdomwar_sys.addUpdater(boostBind(BattleField::tick, this));
		}

		void BattleField::loadDB()
		{
			mongo::BSONObj key = BSON("ci" << _city->id());
			mongo::BSONObj obj = db_mgr.FindOne(DBN::dbKingdomWarCityBattle, key);
			if (obj.isEmpty())
				return;
			
			_state = obj["st"].Int();
			if (_state == Closed)
				return;
			_next_tick_time = obj["ntt"].Int();
			_first_battle_nation = obj["fbn"].Int();
			{
				std::vector<mongo::BSONElement> ele = obj["qst"].Array();
				for (unsigned i = 0; i < ele.size(); ++i)
					_queue_state[i] = ele[i].Int();
			}
			{
				std::vector<mongo::BSONElement> ele = obj["nbt"].Array();
				for (unsigned i = 0; i < ele.size(); ++i)
					_next_battle_time[i] = ele[i].Int();
			}
			{
				std::vector<mongo::BSONElement> ele = obj["aq"].Array();
				for (unsigned i = 0; i < ele.size(); ++i)
				{
					std::vector<mongo::BSONElement> ele2 = ele[i].Array();
					for (unsigned j = 0; j < ele2.size(); ++j)
					{
						CItemPtr ptr = makeCityItem(ele2[j], _city);
						push(i, true, ptr);
						_counter->push(ptr);
					}
				}
			}
			{
				std::vector<mongo::BSONElement> ele = obj["dq"].Array();
				for (unsigned i = 0; i < ele.size(); ++i)
				{
					std::vector<mongo::BSONElement> ele2 = ele[i].Array();
					for (unsigned j = 0; j < ele2.size(); ++j)
					{
						CItemPtr ptr = makeCityItem(ele2[j], _city);
						push(i, false, ptr);
						_counter->push(ptr);
					}
				}
			}
			{
				std::vector<mongo::BSONElement> ele = obj["ws"].Array();
				for (unsigned i = 0; i < Kingdom::nation_num; ++i)
					_wins[i] = ele[i].Int();
			}
			for (unsigned i = 0; i < QueueNum; ++i)
			{
				if (_queue_state[i] == Busy)
					setBattleTimer(_next_battle_time[i], i);
			}

			if (_state == StartWait)
				setStartWaitTimer();
			if (_state == AttackerWait)
				setAttackerWaitTimer();
			if (_state == DefenderWait)
				setDefenderWaitTimer();
		}

		int BattleField::unfilledAttackerQueue()
		{
			int min = QueueMemNum;
			int id = -1;
			for (unsigned i = 0; i < QueueNum; ++i)
			{
				if (_state == StartWait)
				{
					if (_attacker_queue[i].empty())
						return i;
					continue;
				}
				if (_attacker_queue[i].empty())
					return i;
				int total = _attacker_queue[i].size() + _defender_queue[i].size();
				if (total >= QueueMemNum + 1
					|| _attacker_queue[i].size() >= QueueMemNum)
					continue;
				if (_attacker_queue[i].size() < min)
				{
					min = _attacker_queue[i].size();
					id = i;
				}
			}
			return id;
		}

		int BattleField::unfilledDefenderQueue()
		{
			int min = QueueMemNum;
			int id = -1;
			for (unsigned i = 0; i < QueueNum; ++i)
			{
				if (_state == StartWait)
				{
					if (!_attacker_queue[i].empty()
						&& _defender_queue[i].empty())
						return i;
					continue;
				}
				if (_attacker_queue[i].empty())
					continue;
				if (_defender_queue[i].empty())
					return i;
				int total = _attacker_queue[i].size() + _defender_queue[i].size();
				if (total >= QueueMemNum + 1
					|| _defender_queue[i].size() >= QueueMemNum)
					continue;
				if (_defender_queue[i].size() < min)
				{
					min = _defender_queue[i].size();
					id = i;
				}
			}
			return id;
		}

		bool BattleField::tryGetNpcDefender(int queue_id)
		{
			CItemPtr ptr = _city->getNpcDefender();
			if (ptr)
			{
				push(queue_id, false, ptr);
				return true;
			}
			return false;
		}
		
		void BattleField::tryGetPlayer(unsigned cur_time)
		{
			while (true)
			{
				bool flag = true;
				if (tryGetAttacker(cur_time))
					flag = false;
				if (tryGetDefender(cur_time))
					flag = false;
				if (flag)
					break;
			}
		}

		bool BattleField::tryGetAttacker(unsigned cur_time)
		{
			int queue_id = unfilledAttackerQueue();
			if (queue_id == -1)
				return false;
			CItemPtr ptr = _city->getAttacker();	
			if (!ptr)
				return false;
			push(queue_id, true, ptr);
			return true;
		}

		bool BattleField::tryGetDefender(unsigned cur_time)
		{
			int queue_id = unfilledDefenderQueue();
			if (queue_id == -1)
				return false;
			CItemPtr ptr = _city->getDefender();	
			if (!ptr)
				return false;
			push(queue_id, false, ptr);
			return true;
		}

		void BattleField::getInfo(qValue& q) const
		{
			if (_state == Closed)
			{
				q.toObject();
				qValue n;
				n.append((int)_city->_attacker_backup.size());
				n.append((int)_city->_defender_backup.size());
				q.addMember("n", n);
				qValue a;
				const std::vector<int>& num = _counter->num();
				for (unsigned i = 0; i < num.size(); ++i)
					a.append(num[i]);
				q.addMember("a", a);
				qValue t;
				for (unsigned i = 0; i < QueueNum; ++i)
					t.append(_next_battle_time[i]);
				q.addMember("t", t);
				qValue b;
				for (unsigned i = 0; i < QueueNum; ++i)
				{
					qValue q;
					qValue atk_q;
					qValue def_q;
					q.append(atk_q);
					q.append(def_q);
					b.append(q);
				}
				q.addMember("b", b);
				q.addMember("s", _state);
				q.addMember("at", _next_tick_time);
				q.addMember("dt", _next_tick_time);
				q.addMember("w", _next_tick_time);
				qValue r;
				for (unsigned i = 0; i < QueueNum; ++i)
				{
					qValue tmp;
					r.append(tmp);
				}
				q.addMember("r", r);
			}
			else
			{
				q = _main_info.Copy();
			}
		}

		void BattleField::tick()
		{
			if (!_modified)
				return;
			_modified = false;

			_main_info.toObject();
			{
				qValue n;
				n.append((int)_city->_attacker_backup.size());
				n.append((int)_city->_defender_backup.size());
				_main_info.addMember("n", n);
				qValue a;
				const std::vector<int>& num = _counter->num();
				for (unsigned i = 0; i < num.size(); ++i)
					a.append(num[i]);
				_main_info.addMember("a", a);
			}
			{
				qValue t;
				for (unsigned i = 0; i < QueueNum; ++i)
					t.append(_next_battle_time[i]);
				_main_info.addMember("t", t);
				_main_info.addMember("s", _state);
				_main_info.addMember("w", _next_tick_time);
				_main_info.addMember("at", _next_tick_time);
				_main_info.addMember("dt", _next_tick_time);
			}
			{
				qValue r;
				for (unsigned i = 0; i < QueueNum; ++i)
				{
					qValue tmp;
					if (!_rep_backup[i].isEmpty())
						tmp = _rep_backup[i].Copy();
					r.append(tmp);
				}
				_main_info.addMember("r", r);
			}
			{
				qValue b;
				for (unsigned i = 0; i < QueueNum; ++i)
				{
					qValue q;
					qValue atk_q;
					qValue def_q;
					ForEach(CItemQueue, it, _attacker_queue[i])
					{
						qValue tmp;
						(*it)->getInfo(tmp);
						atk_q.append(tmp);
					}
					ForEach(CItemQueue, it, _defender_queue[i])
					{
						qValue tmp;
						(*it)->getInfo(tmp);
						def_q.append(tmp);
					}
					q.append(atk_q);
					q.append(def_q);
					b.append(q);
				}
				_main_info.addMember("b", b);
			}
			
			if (!_city->empty())
			{
				qValue mm(qJson::qj_object);
				qValue m;
				m.append(res_sucess);
				qValue qq(qJson::qj_object);
				{
					qValue n;
					n.append((int)_city->_attacker_backup.size());
					n.append((int)_city->_defender_backup.size());
					qq.addMember("n", n);
				}
				{
					qValue a;
					const std::vector<int>& num = _counter->num();
					for (unsigned i = 0; i < num.size(); ++i)
						a.append(num[i]);
					qq.addMember("a", a);
				}
				{
					qValue t;
					for (unsigned i = 0; i < QueueNum; ++i)
						t.append(_next_battle_time[i]);
					qq.addMember("t", t);
					qq.addMember("s", _state);
					qq.addMember("w", _next_tick_time);
					qq.addMember("at", _next_tick_time);
					qq.addMember("dt", _next_tick_time);
				}
				{
					qValue b;
					_updater.getInfo(b);
					qq.addMember("b", b);
				}
				m.append(qq);
				mm.addMember(strMsg, m);
				detail::batchOnline(_city->getObserver(), mm, gate_client::kingdom_war_city_battle_update_resp);
			}
			_updater.clear();
		}

		void BattleField::changeState(int state, unsigned cur_time)
		{
			_state = state;
			switch(_state)
			{
				case StartWait:
					_next_tick_time = cur_time + StartWaitTime;
					setStartWaitTimer();
					break;
				case AttackerWait:
					_next_tick_time = cur_time + AttackerWaitTime;
					setAttackerWaitTimer();
					break;
				case DefenderWait:
					_next_tick_time = cur_time + DefenderWaitTime;
					setDefenderWaitTimer();
					break;
				default:
					break;
			}
		}

		void BattleField::handleAddPlayer(unsigned tick_time)
		{
			_sign_save();

			if (_state == Closed)
				changeState(StartWait, tick_time);

			tryGetPlayer(tick_time);

			if (_state == StartWait)
				return;

			if (_state == AttackerWait && !noDefenders())
			{
				changeState(Opened, tick_time);
			}
			if (_state == DefenderWait && !noAttackers())
			{
				if (noDefenders())
					changeState(AttackerWait, tick_time);
				else
					changeState(Opened, tick_time);
			}

			resetQueueState(tick_time);
		}

		void BattleField::resetQueueState(unsigned tick_time)
		{
			for (unsigned i = 0; i < QueueNum; ++i)
			{
				if (!_attacker_queue[i].empty())
				{
					if (_queue_state[i] == Free)
					{
						_queue_state[i] = Busy;
						setBattleTimer(tick_time + AttackInterval, i);
					}
					if (_queue_state[i] == Wait && !_defender_queue[i].empty())
					{
						_queue_state[i] = Busy;
						tickBattle(_battle_timer[i], tick_time, i);
					}
				}
			}
		}

		void BattleField::handleAddNpc(unsigned tick_time)
		{
			for (unsigned i = 0; i < QueueNum; ++i)
			{
				if (_queue_state[i] == Wait)
				{
					if (tryGetNpcDefender(i))
					{
						_queue_state[i] = Busy;
						tickBattle(_battle_timer[i], tick_time, i);
						_sign_save();
					}
					return;
				}
			}
		}

		void BattleField::setBattleTimer(unsigned tick_time, int id)
		{
			++_battle_timer[id];
			_next_battle_time[id] = tick_time;
			kingdomwar_sys.addTimer(tick_time, boostBind(BattleField::tickBattle, this, _battle_timer[id], _next_battle_time[id], id));
		}

		void BattleField::setStartWaitTimer()
		{
			kingdomwar_sys.addTimer(_next_tick_time, boostBind(BattleField::tickStartWait, this, _next_tick_time));
		}

		void BattleField::setAttackerWaitTimer()
		{
			++_atk_wait_timer;
			kingdomwar_sys.addTimer(_next_tick_time, boostBind(BattleField::tickAttackerWait, this, _atk_wait_timer, _next_tick_time));
		}

		void BattleField::setDefenderWaitTimer()
		{
			++_def_wait_timer;
			kingdomwar_sys.addTimer(_next_tick_time, boostBind(BattleField::tickDefenderWait, this, _def_wait_timer, _next_tick_time));
		}

		void BattleField::tickStartWait(unsigned tick_time)
		{
			changeState(Opened, tick_time);
			tryGetPlayer(tick_time);
			resetQueueState(tick_time);
		}

		void BattleField::tickBattle(unsigned timer_id, unsigned tick_time, int idx)
		{
			if (timer_id != _battle_timer[idx])
				return;

			_sign_save();

			if (_defender_queue[idx].empty() 
				&& !tryGetNpcDefender(idx))
			{
				_queue_state[idx] = Wait;	
				return;
			}
			
			CItemPtr atk_ptr = _attacker_queue[idx].front();
			CItemPtr def_ptr = _defender_queue[idx].front();
			CityReportData rep_data(tick_time, atk_ptr, def_ptr);
			rep_data.one2one();
			atk_ptr->doneBattle(rep_data, def_ptr, true);
			def_ptr->doneBattle(rep_data, atk_ptr, false);
			rep_data.done();

			qValue q;
			rep_data.getInfo(q);
			_updater.push(idx, q);

			if (rep_data.result.res == resBattle::def_win
				|| atk_ptr->isDead())
			{
				int reason = (rep_data.result.res == resBattle::def_win? Defeated : HpEmpty);
				pop(idx, true, reason);
				tryGetAttacker(tick_time);
			}
			if (rep_data.result.res == resBattle::atk_win 
				|| def_ptr->isDead())
			{
				int reason = (rep_data.result.res == resBattle::atk_win? Defeated : HpEmpty);
				pop(idx, false, reason);
				tryGetDefender(tick_time);
			}

			if (_attacker_queue[idx].empty())
			{
				_queue_state[idx] = Free;
				releaseDefender(idx, tick_time);
			}

			if (noAttackers())
			{
				changeState(DefenderWait, tick_time);
				return;
			}
			if (noDefenders())
				changeState(AttackerWait, tick_time);

			if (_queue_state[idx] != Free)
				setBattleTimer(tick_time + AttackInterval, idx);
		}

		int BattleField::getWinNation()
		{
			int win_nation = -1;
			int win_max = -1;
			for (unsigned i = 0; i < Kingdom::nation_num; ++i)
			{
				if (i == _city->nation())
					continue;
				if (_wins[i] > win_max)
				{
					win_max = _wins[i];
					win_nation = i;
				}
			}
			if (win_nation == -1)
				return _city->nation();
			for (unsigned i = 0; i < Kingdom::nation_num; ++i)
			{
				if (i == win_nation)
					continue;
				if (_wins[i] == win_max)
					return _first_battle_nation;
			}
			return win_nation;
		}

		void BattleField::tickAttackerWait(unsigned timer_id, unsigned tick_time)
		{
			if (timer_id != _atk_wait_timer)
				return;

			if (_state == AttackerWait)
			{
				for (unsigned i = 0; i < QueueNum; ++i)
				{
					CItemQueue tmp;
					clear(i, true, tmp);
					ForEach(CItemQueue, it, tmp)
						_city->releaseAttacker(*it, tick_time);
				}
				int win_nation = getWinNation();
				Log(DBLOG::strLogKingdomWar, 4, _city->nation(), win_nation, _wins[0u] == -1? 0 : _wins[0u], _wins[1u] == -1? 0 : _wins[1u],  _wins[2u] == -1? 0 : _wins[2u], _city->id());
				tickClose(true);
				_city->handleBattleResult(tick_time, true, win_nation);
				_sign_save();
			}
		}

		void BattleField::tickDefenderWait(unsigned timer_id, unsigned tick_time)
		{
			if (timer_id != _def_wait_timer)
				return;

			if (_state == DefenderWait)
			{
				tickClose(false);
				_city->handleBattleResult(tick_time, false);
				_sign_save();
			}
		}
		
		void BattleField::tickClose(bool result)
		{
			if (!_city->empty())
			{
				qValue mm(qJson::qj_object);
				qValue m;
				m.append(res_sucess);
				qValue q(qJson::qj_object);
				q.addMember("r", result);
				q.addMember("n", _city->nation());
				q.addMember("c", _city->id());
				{
					qValue w;
					for (unsigned i = 0; i <= Kingdom::nation_num; ++i)
						w.append(_wins[i]);
					q.addMember("w", w);
				}
				{
					qValue l;
					const std::vector<int>& num = _counter->num();
					for (unsigned i = 0; i <= Kingdom::nation_num; ++i)
						l.append(num[i]);
					q.addMember("l", l);
				}
				m.append(q);
				mm.addMember(strMsg, m);
				detail::batchOnline(_city->getObserver(), mm, gate_client::kingdom_war_siege_info_resp);
			}
				
			changeState(Closed, 0);
			reset();
			_sign_save();
		}

		void BattleField::reset()
		{
			for (unsigned i = 0; i < QueueNum; ++i)
				_queue_state[i] = Free;
			for (unsigned i = 0; i <= Kingdom::nation_num; ++i)
				_wins[i] = -1;
			for (unsigned i = 0; i < QueueNum; ++i)
				_rep_backup[i].toArray();
			_next_tick_time = 0;
			for (unsigned i = 0; i < QueueNum; ++i)
				_next_battle_time[i] = 0;

			clearBattleTimer();
			clearAttackerWaitTimer();
			clearDefenderWaitTimer();
		}

		inline void BattleField::clearAttackerWaitTimer()
		{
			++_atk_wait_timer;
		}

		inline void BattleField::clearDefenderWaitTimer()
		{
			++_def_wait_timer;
		}

		void BattleField::clearBattleTimer()
		{
			for (unsigned i = 0; i < QueueNum; ++i)
				++_battle_timer[i];
		}

		void BattleField::releaseDefender(int id, unsigned tick_time)
		{
			CItemQueue tmp;
			clear(id, false, tmp);
			ForEach(CItemQueue, it, tmp)
			{
				_city->releaseDefender(*it, tick_time);
			}
		}

		bool BattleField::_auto_save()
		{
			mongo::BSONObj key = BSON("ci" << _city->id());
			mongo::BSONObjBuilder obj;
			obj << "ci" << _city->id() << "st" << _state;
			if (_state != Closed)
			{
				obj << "ntt" << _next_tick_time << "fbn" << _first_battle_nation;
				{
					mongo::BSONArrayBuilder b1, b2, b3, b4;
					for (unsigned i = 0; i < QueueNum; ++i)
					{
						b1.append(_queue_state[i]);
						b2.append(_next_battle_time[i]);
						mongo::BSONArrayBuilder b01;
						ForEach(CItemQueue, it, _attacker_queue[i])
							b01.append((*it)->toBSON());
						b3.append(b01.arr());
						mongo::BSONArrayBuilder b02;
						ForEach(CItemQueue, it, _defender_queue[i])
							b02.append((*it)->toBSON());
						b4.append(b02.arr());
					}
					obj << "qst" << b1.arr() << "nbt" << b2.arr()
						<< "aq" << b3.arr() << "dq" << b4.arr();
				}
				{
					mongo::BSONArrayBuilder b;
					for (unsigned i = 0; i < Kingdom::nation_num; ++i)
						b.append(_wins[i]);
					obj << "ws" << b.arr();
				}
			}
			return db_mgr.SaveMongo(DBN::dbKingdomWarCityBattle, key, obj.obj());
		}

		void BattleField::_sign_save()
		{
			_auto_meta::_sign_save();
			_modified = true;
		}

		bool BattleField::noAttackers() const
		{
			for (unsigned i = 0; i < QueueNum; ++i)
			{
				if (!_attacker_queue[i].empty())
					return false;
			}
			return true;
		}

		bool BattleField::noDefenders() const
		{
			if (!_city->_npc_list.empty())
				return false;
			for (unsigned i = 0; i < QueueNum; ++i)
			{
				if (!_defender_queue[i].empty())
					return false;
			}
			return true;
		}

		bool BattleField::onFight(NpcDataPtr d)
		{
			if (d->nation() != _city->nation())
			{
				for (unsigned i = 0; i < QueueNum; ++i)
				{
					ForEach(CItemQueue, it, _attacker_queue[i])
					{
						CItemNpc ptr = upCast<CityItemNpc>(*it);
						if (ptr && ptr->id() == d->id())
							return true;
					}
				}
			}
			else
			{
				for (unsigned i = 0; i < QueueNum; ++i)
				{
					ForEach(CItemQueue, it, _defender_queue[i])
					{
						CItemNpc ptr = upCast<CityItemNpc>(*it);
						if (ptr && ptr->id() == d->id())
							return true;
					}
				}
			}
			return false;
		}

		bool BattleField::onFight(playerDataPtr& d, int army_id)
		{
			if (d->Info->Nation() != _city->nation())
			{
				for (unsigned i = 0; i < QueueNum; ++i)
				{
					ForEach(CItemQueue, it, _attacker_queue[i])
					{
						CItemPlayer ptr = upCast<CityItemPlayer>(*it);
						if (ptr && ptr->pid() == d->ID() && ptr->armyId() == army_id)
							return true;
					}
				}
			}
			else
			{
				for (unsigned i = 0; i < QueueNum; ++i)
				{
					ForEach(CItemQueue, it, _defender_queue[i])
					{
						CItemPlayer ptr = upCast<CityItemPlayer>(*it);
						if (ptr && ptr->pid() == d->ID() && ptr->armyId() == army_id)
							return true;
					}
				}
			}
			return false;
		}

		void BattleField::push(int queue_id, bool is_attacker_queue, CItemPtr ptr)
		{
			CItemQueue& q = is_attacker_queue? 
				_attacker_queue[queue_id] : _defender_queue[queue_id];
			q.push_back(ptr);
			_updater.push(queue_id, Enter, is_attacker_queue? Left : Right, ptr);
		}

		void BattleField::pop(int queue_id, bool is_attacker_queue, int type)
		{
			CItemQueue& q = is_attacker_queue? 
				_attacker_queue[queue_id] : _defender_queue[queue_id];
			CItemPtr ptr = q.front();
			q.pop_front();
			_updater.push(queue_id, type, is_attacker_queue? Left : Right, ptr);
			_counter->pop(ptr);
		}

		void BattleField::clear(int queue_id, bool is_attacker_queue, CItemQueue& ret_q)
		{
			CItemQueue& q = is_attacker_queue?
				_attacker_queue[queue_id] : _defender_queue[queue_id];
			ForEach(CItemQueue, it, q)
			{
				CItemPtr ptr = *it;
				_updater.push(queue_id, Leave, is_attacker_queue? Left : Right, ptr);
			}
			q.swap(ret_q);
			_sign_save();
		}

		void BattleField::getCItemList(qValue& q, int side)
		{
			int num = 0;
			qValue l;
			for (unsigned i = 0; i < QueueNum; ++i)
			{
				CItemQueue& queue = side == 0? 
					_attacker_queue[i] : _defender_queue[i];
				ForEachC(CItemQueue, it, queue)
				{
					qValue tmp;
					(*it)->getInfo2(tmp, 1);
					l.append(tmp);
				}
				num += queue.size();
			}
			CItemList& list = side == 0? 
				_city->_attacker_backup : _city->_defender_backup;
			ForEachC(CItemList, it, list)
			{
				qValue tmp;
				(*it)->getInfo2(tmp, 0);
				l.append(tmp);
			}
			num += list.size();
			if (side != 0)
			{
				ForEachC(CItemNpcList, it, _city->_npc_list)
				{
					qValue tmp;
					(*it)->getInfo2(tmp, 0);
					l.append(tmp);
				}
				num += _city->_npc_list.size();
			}
			q.addMember("n", num);
			q.addMember("l", l);
			q.addMember("s", side);
		}

		void BattleField::clear(unsigned tick_time)
		{
			/*
			changeState(Closed, tick_time);
			for (unsigned i = 0; i < QueueNum; ++i)
				_queue_state[i] = Free;
			for (unsigned i = 0; i <= Kingdom::nation_num; ++i)
				_wins[i] = -1;
			for (unsigned i = 0; i < QueueNum; ++i)
				_rep_backup[i].toArray();
			_next_tick_time = 0;
			for (unsigned i = 0; i < QueueNum; ++i)
				_next_battle_time[i] = 0;
			_counter->clear();
			for (unsigned i = 0; i < QueueNum; ++i)
			{
				ForEach(CItemQueue, it, _attacker_queue[i])
				{
					playerDataPtr d = player_mgr.getPlayer((*it)->pid());
					if (!d) continue;
					kingdomwar_sys.goBackMainCity(tick_time, d, (*it)->armyId(), ResKickBack);
				}
				_attacker_queue[i].clear();
				ForEach(CItemQueue, it, _defender_queue[i])
				{
					playerDataPtr d = player_mgr.getPlayer((*it)->id());
					if (!d) continue;
					kingdomwar_sys.goBackMainCity(tick_time, d, (*it)->armyId(), ResKickBack);
				}
				_defender_queue[i].clear();
			}
			*/
		}

		std::vector<int> City::Num(Kingdom::nation_num + 1, 0);

		City::City(const Json::Value& info)
		{
			_id = info["id"].asInt();

			if (_id == MainCity[Kingdom::wei])
				_nation = Kingdom::wei;
			else if (_id == MainCity[Kingdom::shu])
				_nation = Kingdom::shu;
			else if (_id == MainCity[Kingdom::wu])
				_nation = Kingdom::wu;
			else
				_nation = Kingdom::nation_num;

			++Num[_nation];

			_output.assign(Kingdom::nation_num + 1, 0);
			if (info["gold"].asInt() > 0)
			{
				_output_type = 0;
				_output[Kingdom::nation_num] = info["gold"].asInt();
			}
			if (info["silver"].asInt() > 0)
			{
				_output_type = 1;
				_output[Kingdom::nation_num] = info["silver"].asInt();
			}
			if (info["fame"].asInt() > 0)
			{
				_output_type = 2;
				_output[Kingdom::nation_num] = info["fame"].asInt();
			}
			if (info["merit"].asInt() > 0)
			{
				_output_type = 3;
				_output[Kingdom::nation_num] = info["merit"].asInt();
			}

			_output_max = info["max"].asInt() * _output[Kingdom::nation_num];

			_npc_start = info["npc_start"].asInt();
			_npc_add = info["npc_add"].asInt();
			_npc_max = info["npc_max"].asInt();

			_buff_type = info["buff_type"].asInt();
			const Json::Value& buff_value = info["buff_value"];
			ForEachC(Json::Value, it, buff_value)
				_buff_value.push_back((*it).asInt());

			_counter = Creator<CItemCounter>::Create();
			_sup_time = Common::gameTime();
			_sup_base = 0;
			_sup_rate = kingdomwar_sys.supRate();
		}

		int City::state()
		{
			return _battle_field->state() == Closed? 0 : 1;
		}

		void City::tryLoadPlayer(playerDataPtr& d, int army_id)
		{
			if (!onFight(d, army_id))
			{
				if (_nation != d->Info->Nation())
				{
					CItemPlayer ptr = Creator<CityItemPlayer>::Create(d, army_id, upCast<City>(shared_from_this()));
					_attacker_backup.push_back(ptr);
					_counter->push(ptr);
				}
				else
				{
					CItemPlayer ptr = Creator<CityItemPlayer>::Create(d, army_id, upCast<City>(shared_from_this()));
					_defender_backup.push_back(ptr);
					_counter->push(ptr);
				}
			}
		}

		void City::tryLoadNpc(NpcDataPtr& d)
		{
			if (!onFight(d))
			{
				CItemNpc ptr = Creator<CityItemNpc>::Create(d, upCast<City>(shared_from_this()));
				if (d->type() == Npc)
					_npc_list.push_back(ptr);
				else if (d->nation() != _nation)
					_attacker_backup.push_back(ptr);
				else
					_defender_backup.push_back(ptr);
			}
		}

		void City::init()
		{
			loadDB();

			kingdomwar_sys.add5MinTicker(boostBind(City::tickOutput, this));
			kingdomwar_sys.add5MinTicker(boostBind(City::tickCreateNpc, this));

			_battle_field = Creator<BattleField>::Create(
				upCast<City>(shared_from_this()));
			_battle_field->init();
		}

		void City::loadDB()
		{
			mongo::BSONObj key = BSON("ci" << _id);
			mongo::BSONObj obj = db_mgr.FindOne(DBN::dbKingdomWarCityBase, key);
			if (obj.isEmpty())
			{
				initMaxNpc(Common::gameTime());
				return;
			}

			alterNation(obj["nt"].Int());
			{
				std::vector<mongo::BSONElement> ele = obj["o"].Array();
				for (unsigned i = 0; i < Kingdom::nation_num; ++i)
					_output[i] = ele[i].Int();
			}

			checkNotEoo(obj["sb"])
				_sup_base = obj["sb"].Int();
			checkNotEoo(obj["st"])
				_sup_time = obj["st"].Int();
		}

		bool City::_auto_save()
		{
			mongo::BSONObj key = BSON("ci" << _id);
			mongo::BSONObjBuilder obj;
			obj << "ci" << _id << "nt" << _nation
				<< "sb" << _sup_base << "st" << _sup_time;
			{
				mongo::BSONArrayBuilder b;
				for (unsigned i = 0; i < Kingdom::nation_num; ++i)
					b.append(_output[i]);
				obj << "o" << b.arr();
			}
			return db_mgr.SaveMongo(DBN::dbKingdomWarCityBase, key, obj.obj());
		}

		int City::enter(unsigned time, NpcDataPtr d)
		{
			CItemNpc ptr = Creator<CityItemNpc>::Create(d, upCast<City>(shared_from_this()));
			_counter->push(ptr);
			if (_nation == d->nation())
			{
				_defender_backup.push_back(ptr);
				d->setPosition(PosCity, _id, time);
				if (_battle_field->state() != Closed)
					noticeAddDefender(time);
			}
			else if (_battle_field->state() == Closed && _defender_backup.empty() && _npc_list.empty())
			{
				_defender_backup.push_back(ptr);
				d->setPosition(PosCity, _id, time);
				Log(DBLOG::strLogKingdomWar, 4, _nation, d->nation(), 0, 0, 0, _id);
				alterNation(d->nation());
				kingdomwar_sys.DoBroadcast(-1, qValue() << 0 << _nation << _id);
				initNpc(time);
				_sign_save();
			}
			else
			{
				_attacker_backup.push_back(ptr);
				d->setPosition(PosCity, _id, time);
				noticeAddAttacker(time);
			}
			return res_sucess;
		
		}
		
		int City::enter(unsigned time, playerDataPtr d, int army_id, int reason)
		{
			CItemPlayer ptr = Creator<CityItemPlayer>::Create(d, army_id, upCast<City>(shared_from_this()));
			_counter->push(ptr);
			if (_nation == d->Info->Nation())
			{
				_defender_backup.push_back(ptr);
				d->KingDomWarPos->setPosition(army_id, PosCity, _id, time, reason);
				if (_battle_field->state() != Closed)
					noticeAddDefender(time);
			}
			else if (_battle_field->state() == Closed && _defender_backup.empty() && _npc_list.empty())
			{
				_defender_backup.push_back(ptr);
				d->KingDomWarPos->setPosition(army_id, PosCity, _id, time, reason);
				Log(DBLOG::strLogKingdomWar, 4, _nation, d->Info->Nation(), 0, 0, 0, _id);
				alterNation(d->Info->Nation());
				kingdomwar_sys.DoBroadcast(-1, qValue() << 0 << _nation << _id);
				initNpc(time);
				_sign_save();
			}
			else
			{
				_attacker_backup.push_back(ptr);
				d->KingDomWarPos->setPosition(army_id, PosCity, _id, time, reason);
				noticeAddAttacker(time);
			}
			return res_sucess;
		}

		bool City::onFight(playerDataPtr d, int army_id)
		{
			return _battle_field->onFight(d, army_id);
		}

		bool City::onFight(NpcDataPtr d)
		{
			return _battle_field->onFight(d);
		}

		int City::leave(unsigned time, playerDataPtr d, int army_id, int to_city_id)
		{
			PathPtr ptr;
			ForEach(std::vector<PathPtr>, it, _paths)
			{
				if ((*it)->access(_id, to_city_id))
				{
					ptr = *it;
					break;
				}
			}
			if (!ptr)
				return err_illedge;

			CItemList& list = d->Info->Nation() != _nation?
				_attacker_backup : _defender_backup;
			bool find = false;
			ForEach(CItemList, it, list)
			{
				CItemPlayer ptr = upCast<CityItemPlayer>(*it);
				if (!ptr) continue;
				if (ptr->pid() == d->ID()
					&& ptr->armyId() == army_id)
				{
					_counter->pop(ptr);
					list.erase(it);		
					find = true;
					break;
				}
			}
			if (!find)
				return err_illedge;
			
			_sign_save();
			return ptr->enter(time, d, army_id, to_city_id);
		}

		void City::noticeAddAttacker(unsigned tick_time)
		{
			_battle_field->handleAddPlayer(tick_time);
		}

		void City::noticeAddDefender(unsigned tick_time)
		{
			_battle_field->handleAddPlayer(tick_time);
		}

		void City::noticeAddNpc(unsigned tick_time)
		{
			_battle_field->handleAddNpc(tick_time);
		}

		CItemPtr City::getAttacker()
		{
			if (_attacker_backup.empty())
				return CItemPtr();
			CItemPtr ptr = _attacker_backup.back();
			_attacker_backup.pop_back();
			return ptr;
		}

		CItemPtr City::getDefender()
		{
			if (_defender_backup.empty())
				return CItemPtr();
			CItemPtr ptr = _defender_backup.back();
			_defender_backup.pop_back();
			return ptr;
		}

		CItemPtr City::getNpcDefender()
		{
			if (_npc_list.empty())
				return CItemPtr();
			CItemPtr ptr = _npc_list.back();
			_npc_list.pop_back();
			_sign_save();
			return ptr;
		}

		void City::releaseDefender(CItemPtr& ptr, unsigned tick_time)
		{
			if (ptr->type() == Npc)
			{
				_npc_list.push_back(upCast<CityItemNpc>(ptr));
				noticeAddNpc(tick_time);
			}
			else
			{
				_defender_backup.push_back(ptr);
				noticeAddDefender(tick_time);
			}
		}

		void City::releaseAttacker(CItemPtr& ptr, unsigned tick_time)
		{
			_attacker_backup.push_back(ptr);
		}

		void City::alterNation(int nation)
		{
			--Num[_nation];
			_nation = nation;
			++Num[_nation];
		}

		void City::handleBattleResult(unsigned tick_time, bool result, int nation)
		{
			if (result)
			{
				alterNation(nation);
				kingdomwar_sys.DoBroadcast(-1, qValue() << 0 << _nation << _id);
				ForEach(CItemList, it, _attacker_backup)
				{
					CItemPtr& ptr = *it;
					if (ptr->nation() == _nation)
					{
						_defender_backup.push_back(ptr);
						//ptr->enter(PosCity, _id, tick_time);
						//ptr->setPosition(PosCity, _id, tick_time);
					}
					else
					{
						_counter->pop(ptr);
						ptr->beDead(tick_time, ResKickBack);
					}
				}
				_attacker_backup.clear();
				initNpc(tick_time);
				_sign_save();
			}
		}

		void City::tickOutput()
		{
			if (_nation == Kingdom::nation_num)
				return;
			if (kingdomwar_sys.state() == Closed &&
				((kingdomwar_sys.next5MinTime() - 5 * MINUTE) % (15 * MINUTE) != 0))
				return;
			_output[_nation] += _output[Kingdom::nation_num];
			_sign_save();
		}

		void City::initNpc(unsigned cur_time)
		{
			for (unsigned i = 0; i < _npc_start; ++i)
			{
				int map_id = kingdomwar_sys.randomNpcID();
				CItemNpc ptr = createNpc(cur_time, map_id);
				if (!ptr)
				{
					LogE << "create npc error: map id " << map_id << LogEnd;
					continue;
				}
				_npc_list.push_back(ptr);
				_counter->push(ptr);
			}
		}

		void City::initMaxNpc(unsigned cur_time)
		{
			for (unsigned i = 0; i < _npc_max; ++i)
			{
				int map_id = kingdomwar_sys.randomNpcID();
				CItemNpc ptr = createNpc(cur_time, map_id);
				if (!ptr)
				{
					LogE << "create npc error: map id " << map_id << LogEnd;
					continue;
				}
				_npc_list.push_back(ptr);
				_counter->push(ptr);
			}
		}

		CItemNpc City::createNpc(unsigned cur_time, int map_id)
		{
			Position pos;
			pos.type = PosCity;
			pos.time = cur_time;
			pos.id = _id;
			pos.from_id = _id;
			std::vector<int> man_hp;
			NpcDataPtr ptr = Creator<NpcData>::Create((int)Npc, map_id, _nation, pos, (int)ArmyMaxHp, man_hp);
			if (!ptr->valid())
				return CItemNpc();
			return Creator<CityItemNpc>::Create(ptr, upCast<City>(shared_from_this()));
		}

		CItemNpc City::createNpc2(unsigned cur_time, int map_id)
		{
			Position pos;
			pos.type = PosCity;
			pos.time = cur_time;
			pos.id = _id;
			pos.from_id = _id;
			std::vector<int> man_hp;
			NpcDataPtr ptr = Creator<NpcData>::Create((int)Npc2, map_id, _nation, pos, (int)ArmyMaxHp, man_hp);
			if (!ptr->checkValidAndSave())
				return CItemNpc();
			return Creator<CityItemNpc>::Create(ptr, upCast<City>(shared_from_this()));
		}

		void City::tickCreateNpc()
		{
			tickCreateNpc2();
			if (_battle_field->state() != Closed)
				return;
			if (_npc_list.size() >= _npc_max)
				return;
			int add_num = _npc_add;
			if (_npc_list.size() + add_num > _npc_max)
				add_num = _npc_max - _npc_list.size();
			for (unsigned i = 0; i < add_num; ++i)
			{
				int map_id = kingdomwar_sys.randomNpcID();
				CItemNpc npc_ptr = createNpc(0, map_id);
				if (!npc_ptr)
				{
					LogE << "create npc error: map id " << map_id << LogEnd;
					continue;
				}
				_npc_list.push_back(npc_ptr);
				_counter->push(npc_ptr);
			}
		}

		void City::tickCreateNpc2()
		{
			ForEach(std::vector<PathPtr>, it, _paths)
			{
				PathPtr ptr = *it;
				int target_id = ptr->getLinkedId(_id);
				if (ptr->access(_id, target_id))
				{
					int map_id = kingdomwar_sys.randomNpcID();
					CItemNpc npc = createNpc2(0, map_id);
					if (!npc)
						continue;
					LogI << "City:" << _id << ", Npc ID:" << npc->id() << LogEnd;
					ptr->enter(Common::gameTime(), npc->npcData(), target_id);
				}
			}
		}

		void City::getMilitaryInfo(qValue& q)
		{
			q.addMember("n", _nation);
			const std::vector<int>& num = _counter->num();
			qValue n;
			for (unsigned i = 0; i < num.size(); ++i)
				n.append(num[i]);
			q.addMember("a", n);
		}

		void City::getFighterList(qValue& q, int side)
		{
			return _battle_field->getCItemList(q, side);
		}

		void City::addBuff(sBattlePtr ptr, int nation)
		{
			if (nation == Kingdom::nation_num)
				return;
			int buff = _buff_value[nation];
			if (_buff_type == 1)
			{
				ForEach(manList, it, ptr->battleMan)
				{
					(*it)->battleAttri[idx_phyHurtRate] += buff;
					(*it)->battleAttri[idx_warHurtRate] += buff;
					(*it)->battleAttri[idx_magicHurtRate] += buff;
					(*it)->battleAttri[idx_cureRate] += buff;
				}
			}
			else if (_buff_type == 2)
			{
				ForEach(manList, it, ptr->battleMan)
				{
					(*it)->battleAttri[idx_phyCutRate] += buff;
					(*it)->battleAttri[idx_warCutRate] += buff;
					(*it)->battleAttri[idx_magicCutRate] += buff;
				}
			}
		}

		void City::addBuff(playerDataPtr& d, sBattlePtr ptr)
		{
			addBuff(ptr, d->Info->Nation());
		}

		unsigned City::getSup(unsigned cur_time)
		{
			if (cur_time < _sup_time)
				return 0;
			return (cur_time - _sup_time) * 6 * _sup_rate + _sup_base;
		}

		void City::reset(unsigned cur_time)
		{
			if (_sup_rate != kingdomwar_sys.supRate())
			{
				if (cur_time > _sup_time)
				{
					_sup_base = getSup(cur_time);
					_sup_time = cur_time;
					_sign_save();
				}
				_sup_rate = kingdomwar_sys.supRate();
			}
		}

		int City::unityNation()
		{
			for(unsigned i = 0; i < Kingdom::nation_num; ++i)
			{
				if (Num[i] == kingdomwar_sys.citySize() - 2)
					return i;
			}
			return -1;
		}

		void City::clear()
		{
			_attacker_backup.clear();
			_defender_backup.clear();
			//_battle_field->clear();
		}

		CityList::CityList()
		{
		}

		CityPtr CityList::getCity(int id)
		{
			if (id < 0 || id >= _citys.size())
				return CityPtr();
			return _citys[id];
		}

		void CityList::push(const CityPtr& ptr)
		{
			while(ptr->id() >= _citys.size())
				_citys.push_back(CityPtr());
			_citys[ptr->id()] = ptr;
		}

		void CityList::clear()
		{
			ForEach(Citys, it, _citys)
				(*it)->clear();
		}
		
		void CityList::update(bool is_first)
		{
			if (is_first)
			{
				LogI << "city size: " << _citys.size() << LogEnd;
				_main_state_info.toArray();
				_main_nation_info.toArray();
				for (unsigned i = 0; i < _citys.size(); ++i)
				{
					_states.push_back(_citys[i]->state());
					_nations.push_back(_citys[i]->nation());
					_main_state_info.append(_states[i]);
					_main_nation_info.append(_nations[i]);
				}
			}
			else
			{
				_update_state_info.toArray();
				_update_nation_info.toArray();
				for (unsigned i = 0; i < _citys.size(); ++i)
				{
					if (_states[i] != _citys[i]->state())
					{
						_states[i] = _citys[i]->state();
						qValue tmp;
						tmp.toArray();
						tmp.append(_citys[i]->id());
						tmp.append(_states[i]);
						_update_state_info.append(tmp);
					}
					if (_nations[i] != _citys[i]->nation())
					{
						_nations[i] = _citys[i]->nation();
						qValue tmp;
						tmp.toArray();
						tmp.append(_citys[i]->id());
						tmp.append(_nations[i]);
						_update_nation_info.append(tmp);
					}
				}
				if (!_update_state_info.isEmpty())
				{
					_main_state_info.toArray();
					for (unsigned i = 0; i < _citys.size(); ++i)
						_main_state_info.append(_states[i]);
				}
				if (!_update_nation_info.isEmpty())
				{
					_main_nation_info.toArray();
					for (unsigned i = 0; i < _citys.size(); ++i)
						_main_nation_info.append(_nations[i]);
				}
			}
		}
		
		void CityList::loadDB()
		{
			ForEach(Citys, it, _citys)
				(*it)->init();
		}
	}
}

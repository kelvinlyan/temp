#pragma once

#include "kingfight_data.h"

#define kingfight_sys (*gg::kingfight_system::_Instance)

namespace gg
{
	SHAREPTR(KingFight::Manager, KingFightManager);

	class kingfight_system
	{
		public:
			static kingfight_system* const _Instance;		

			kingfight_system();
			void initData();

			DeclareRegFunction(showUI);
			DeclareRegFunction(challengeCrown);
			DeclareRegFunction(reFightTime);
			DeclareRegFunction(guessCrown);
			DeclareRegFunction(receiveReward);
			DeclareRegFunction(showOfficialsUI);
			DeclareRegFunction(anOfficial);
			DeclareRegFunction(showBeforOfficial);

			int betSilver() const;
			int winSilver() const;
			int loseSilver() const;
			const KingFightManager getData(int nation) const;
			void updateName(playerDataPtr d);

		private:
			void setBroadcastTimer();
			void broadcastAt2125();
			void setSilverIndex();

		private:
			int _silver_index;
			std::vector<KingFightManager> _manager;
	};
}

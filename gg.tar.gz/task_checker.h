#pragma once

#include "commom.h"
#include "mongoDB.h"
#include "auto_base.h"
#include "task_def.h"

namespace gg
{
	namespace Task
	{
		class ICheck
		{
			public:
				ICheck(int type): _type(type){}

				int type() const { return _type; }
				virtual int run(playerDataPtr d, int& value, int action, int arg1, int arg2) = 0;

			private:
				int _type;
		};

		SHAREPTR(ICheck, CheckPtr);

#define EmptyChecker(name)\
	class name\
		: public Task::ICheck\
	{\
		public:\
			static CheckPtr create(const Json::Value& info)\
			{\
				LogE << "task type not implement: " << #name << " (" << info["ty"].asInt() << ").." << LogEnd;\
				return Creator<name>::Create(info);\
			}\
			name(const Json::Value& info)\
				: Task::ICheck(info["ty"].asInt())\
			{\
			}\
			virtual int run(playerDataPtr d, int& value, int action, int arg1, int arg2)\
			{\
				return ICheck::run(d, value, action, arg1, arg2);\
			}\
	}

#define NumChecker(name)\
	class name\
		: public Task::ICheck\
	{\
		public:\
			static CheckPtr create(const Json::Value& info)\
			{\
				return Creator<name>::Create(info);\
			}\
			name(const Json::Value& info)\
				: Task::ICheck(info["ty"].asInt())\
			{\
				ForEachC(Json::Value, it, info["arg"])\
					_args.push_back((*it).asInt());\
			}\
			int getResult(int& value)\
			{\
				if (value > _args[0u])\
					value = _args[0u];\
				return value >= _args[0u]? Finished : Running;\
			}\
			virtual int run(playerDataPtr d, int& value, int action, int arg1, int arg2)\
			{\
				if (action == Init)\
					value = 0;\
				else if (action == Update)\
					value += arg1;\
				return getResult(value);\
			}\
		protected:\
			std::vector<int> _args;\
	}


#define OwnChecker(name)\
	class name\
		: public Task::ICheck\
	{\
		public:\
			static CheckPtr create(const Json::Value& info)\
			{\
				return Creator<name>::Create(info);\
			}\
			name(const Json::Value& info)\
				: Task::ICheck(info["ty"].asInt())\
			{\
				ForEachC(Json::Value, it, info["arg"])\
					_args.push_back((*it).asInt());\
			}\
			int getResult(int& value)\
			{\
				if (value > _args[0u])\
					value = _args[0u];\
				return value >= _args[0u]? Finished : Running;\
			}\
			virtual int run(playerDataPtr d, int& value, int action, int arg1, int arg2);\
		protected:\
			std::vector<int> _args;\
	}

		class Checker
		{
			public:
				typedef boost::function<CheckPtr(const Json::Value&)> CreateFunc;

				static void init();
				static CheckPtr create(const Json::Value& info);

			private:
				static CreateFunc _creator_map[TypeMax];
		};	
		
		EmptyChecker(CEmpty);
		EmptyChecker(CRechargeNum);
        OwnChecker(CVip);                            
        NumChecker(CConsumeNum);                     
        NumChecker(CConsumeTimes);                   
        NumChecker(CGetSilverNum);                   
        NumChecker(CGetMeritNum);                    
        NumChecker(CGetFameNum);                     
        NumChecker(CGetFoodNum);                     
        NumChecker(CGetWoodNum);                     
        NumChecker(CGetIronNum);                     
        NumChecker(CUseActionNum);                   
        NumChecker(CUseSilverNum);                   
        NumChecker(CUseMeritNum);                    
        NumChecker(CUseFameNum);                     
        NumChecker(CUseFoodNum);                     
        NumChecker(CUseWoodNum);                     
        NumChecker(CUseIronNum);                     
        OwnChecker(CLv);                             
        OwnChecker(CPower);                          
        OwnChecker(CWarCharpter);                    
        OwnChecker(CWarStarSum);                     
        OwnChecker(CEquipNumOfColor);                
        NumChecker(CStrengthenTimes);                
        NumChecker(CForgeTimes);                     
        NumChecker(CHighForgeTimes);                 
        OwnChecker(CForgeNumOfColor);                
        NumChecker(CWashTimes);                      
        NumChecker(CHighWashTimes);                  
        NumChecker(CTransferTimes);                  
        NumChecker(CResolveTimes);                   
        OwnChecker(CManNum);                         
        OwnChecker(CManNumOfColor);                  
        OwnChecker(CManMaxLv);                       
        NumChecker(CUseExpItemTimes);                
        NumChecker(CAdvanceTimes);                   
        NumChecker(CTemperTimes);                    
        EmptyChecker(CInheritTimes);                   
        NumChecker(CStoneNum);                       
        OwnChecker(CGemStoneNumOfLv);                
        NumChecker(CInLayTimes);                     
        NumChecker(CWarLordsAttackTimes);            
        NumChecker(CWarLordsGetFameNum);             
        OwnChecker(CWarLordsGetTitle);               
        NumChecker(CHeroPartyTimes);                 
        OwnChecker(CHeroPartyRank);                  
        NumChecker(CHeroPartyShopTimes);             
        NumChecker(CHeroPartyShopFlushTimes);        
        NumChecker(CTeamWarTimes);                   
        NumChecker(CTeamWarPaperNum);                
        NumChecker(CTeamWarShopTimes);               
        NumChecker(CBuildTimes);                     
        OwnChecker(CInfantryLv);                     
        OwnChecker(CSowarLv);                        
        OwnChecker(CSapperLv);                       
        OwnChecker(CInstrumentLv);                   
        OwnChecker(CAdviserLv);                      
        OwnChecker(CAssistLv);                       
        OwnChecker(CDwellingsLvSum);                    
        OwnChecker(CCroplandLvSum);                     
        OwnChecker(CMineLvSum);                         
        OwnChecker(CWoodFarmLvSum);                     
        OwnChecker(CFiefNum);                        
        NumChecker(CSearchTimes);                    
        NumChecker(CSearchPaperNum);                 
        OwnChecker(CSearchPaperNumOfColor);          
        OwnChecker(CMilitaryTechLvSum);              
        OwnChecker(CWarTechLvSum);                   
        OwnChecker(CHomeTechLvSum);                  
        OwnChecker(CFormationTechLvSum);             
        NumChecker(CMarketTimes);                    
        NumChecker(CMarketSilverTimes);              
        NumChecker(CMarketIronTimes);                
        NumChecker(CMarketFoodTimes);                
        NumChecker(CMarketWoodTimes);                
        NumChecker(CMarketSilverNum);                
        NumChecker(CMarketIronNum);                  
        NumChecker(CMarketFoodNum);                  
        NumChecker(CMarketWoodNum);                  
        OwnChecker(CAppointManNum);                  
        OwnChecker(CMilitaryRank);                   
        OwnChecker(CKingdomSkillLvSum);              
        NumChecker(CKingdomUpSkillTimes);            
        NumChecker(CKingdomShopTimes);               
        NumChecker(CKingdomShopFlushTimes);          
        NumChecker(CKingTitleTimes);                 
        NumChecker(CKingdomContributeTimes);         
        NumChecker(CKingdomContributeNum);           
        EmptyChecker(CKingdomLv);                      
        EmptyChecker(CKingdomFoodLv);                  
        EmptyChecker(CKingdomSilverLv);                
        EmptyChecker(CKingdomWoodLv);                  
        EmptyChecker(CKingdomIronLv);                  
        EmptyChecker(CKingdomFameLv);                  
        EmptyChecker(CHougong1);
        OwnChecker(CCardInvestNum);
        OwnChecker(CCardLotteryTimes);
        EmptyChecker(CHougong4);
        EmptyChecker(CHougong5);
        EmptyChecker(CHougong6);
        EmptyChecker(CHougong7);
        EmptyChecker(CHougong8);
        NumChecker(CWorldBossDamage);                
        NumChecker(CWorldBossIncentTimes);           
        NumChecker(CWorldBossKingdomIncentTimes);    
        NumChecker(CWorldBossLastShotTimes);         
        NumChecker(CKingdomWarWinTimes);
        NumChecker(CGetExploitNum);
        NumChecker(CKingdomWarUseFoodNum);
        NumChecker(CMallTimes);                 
        NumChecker(CMallConsumeNum);
        OwnChecker(CSignDayNum);                    
        OwnChecker(CWarMapStar);                     
		OwnChecker(CResolveTargetNum);
        OwnChecker(CMilitaryTechMaxLv);              
        OwnChecker(CWarTechNum);                     
        OwnChecker(CHomeTechNum);
        OwnChecker(CFormationTechNum);               
		NumChecker(CRescueTimes);
		OwnChecker(COfficialLv);
		OwnChecker(CManSpecified);
        OwnChecker(CEquipMaxLv);                     
		NumChecker(CBusinessTimes);
		OwnChecker(CInlayGemOfLv);
		NumChecker(CChangeFace);
		OwnChecker(CAffairsAllTimes);
		NumChecker(CAffairsTimes);
		NumChecker(CSpeedUpTimes);
        OwnChecker(CDwellingsLv);                    
        OwnChecker(CCroplandLv);                     
        OwnChecker(CMineLv);                         
        OwnChecker(CWoodFarmLv);                     
		OwnChecker(CNewProgress);
		OwnChecker(CKingdomWarSiegeAllTimes);
		OwnChecker(CEnterKingdomWar);
		OwnChecker(CKingdomContributeAllTimes);
		OwnChecker(CBusinessAllTimes);
	}
}

#include "gm_tools.h"
#include "mongoDB.h"
#include "service_config.h"
#include "gate_game_protocol.h"
#include "commom.h"
#include "game_time.h"
#include "money_activity.h"

using namespace mongo;

namespace gg
{
	gm_tools* const gm_tools::_Instance = new gm_tools();

	gm_tools::gm_tools()
	{

	}

	gm_tools::~gm_tools()
	{

	}

	bool gm_tools::is_from_gm_http(int net_id)
	{
		bool isfull = service::process_id::HTTP_GM_START_NET_ID <= net_id && net_id <= service::process_id::HTTP_GM_END_NET_ID;
		bool ispart = service::process_id::HTTP_GM_START_NET_ID <= (net_id/100) && (net_id/100) <= service::process_id::HTTP_GM_END_NET_ID;
		return (isfull || ispart);
	}

	//�Զ���������ݸ�ʽ
	struct customGift
	{
		int csID;//���ID
		string title;//����
		string csWords;//�������
		Json::Value boxJson;//���
		ACTION::BoxList boxList;//�������
		unsigned startTime;//��ʼʱ��
		unsigned endTime;//����ʱ��
		int getTimes;//��ȡʱ��
		unsigned perTime;//��ȡ���
		unsigned levelLimit;//�ȼ����� >=
		unsigned vipLimit;//vip�ȼ�����
		unsigned createTime;//����ʱ��
		bool isActive()
		{
			const unsigned now = Common::gameTime();
			return (now > startTime && now < endTime);
		}
	};
	SHAREPTR(customGift, customPtr);
	STDMAP(int, customPtr, CustomMap);
	static CustomMap CustomGifts;
	static void delCustom(const int csID)
	{
		CustomGifts.erase(csID);
		mongo::BSONObj key = BSON("key" << csID);
		db_mgr.RemoveCollection(DBN::dbCustomGift, key);
	}
	static void saveCustom(customPtr ptr)
	{
		if (Common::gameTime() > ptr->endTime)
		{
			delCustom(ptr->csID);
			return;
		}
		mongo::BSONObj key = BSON("key" << ptr->csID);
		mongo::BSONObj obj = BSON("key" << ptr->csID <<
			"w" << ptr->csWords << "box" << Common::json2string(ptr->boxJson) <<
			"st" << ptr->startTime << "et" << ptr->endTime <<
			"pt" << ptr->perTime << "ct" << ptr->createTime <<
			"gts" << ptr->getTimes << "vl" << ptr->vipLimit <<
			"ll" << ptr->levelLimit << "tl" << ptr->title);
		db_mgr.SaveMongo(DBN::dbCustomGift, key, obj);
	}
	customPtr getCustom(const int csID)
	{
		CustomMap::iterator it = CustomGifts.find(csID);
		if (it == CustomGifts.end())return customPtr();
		customPtr ptr = it->second;
		if (Common::gameTime() > ptr->endTime)
		{
			delCustom(ptr->csID);
			return customPtr();
		}
		return ptr;
	}

	void gm_tools::initData()
	{
		CustomGifts.clear();
		objCollection objs = db_mgr.Query(DBN::dbCustomGift);
		for (unsigned i = 0; i < objs.size(); ++i)
		{
			mongo::BSONObj& obj = objs[i];
			customPtr ptr = Creator<customGift>::Create();
			ptr->csID = obj["key"].Int();
			ptr->title = obj["tl"].String();
			ptr->csWords = obj["w"].String();
			ptr->boxJson = Common::string2json(obj["box"].String());
			ptr->boxList = actionFormatBox(ptr->boxJson);
			if (ptr->boxList.empty())
			{
				delCustom(ptr->csID);
				continue;
			}
			ptr->startTime = (unsigned)obj["st"].Int();
			ptr->endTime = (unsigned)obj["et"].Int();
			ptr->perTime = (unsigned)obj["pt"].Int();
			ptr->createTime = (unsigned)obj["ct"].Int();
			ptr->vipLimit = (unsigned)obj["vl"].Int();
			ptr->levelLimit = (unsigned)obj["ll"].Int();
			ptr->getTimes = obj["gts"].Int();
			if (Common::gameTime() > ptr->endTime)
			{
				delCustom(ptr->csID);
				continue;
			}
			CustomGifts[ptr->csID] = ptr;
		}
	}

	bool gm_tools::isGmProtocal( int msgType )
	{
		if (gate_client::gm_protocal_start_req <=msgType && msgType <= gate_client::gm_protocal_end_req)
			return true;

		return false;
	}


	void gm_tools::BaseGet(net::Msg& m, Json::Value& r)
	{
		playerDataPtr player = player_mgr.getPlayer(m.playerID);
		if (!player)Return(r, err_null_player);
		Json::Value& bJson = r[strMsg][1u];
		playerBase& Bas = *(player->Info.get());
		bJson.append(Bas.ID());
		bJson.append(Bas.Name());
		bJson.append(Bas.Sex());
		bJson.append(Bas.LV());
		bJson.append(Bas.EXP());
		bJson.append(Bas.Face());
		bJson.append(Bas.Official());
		bJson.append(Bas.Nation());//����
		bJson.append(Bas.VipLv());//vip�ȼ�
		bJson.append(Bas.VipExp());//vip����
		Return(r, res_sucess);
	}

	void gm_tools::ResGet(net::Msg& m, Json::Value& r)
	{
		playerDataPtr player = player_mgr.getPlayer(m.playerID);
		if (!player)Return(r, err_null_player);
		playerResource& res = *(player->Res.get());
		Json::Value& bJson = r[strMsg][1u];
		bJson.append(res.getGold());
		bJson.append(res.getTicket());
		bJson.append(res.getSilver());
		bJson.append(res.getFood());
		bJson.append(res.getWood());
		bJson.append(res.getIron());
		bJson.append(res.getMerit());
		bJson.append(res.getFame());
		bJson.append(res.getAction());
		bJson.append(res.getContribution());
		bJson.append(res.getHeroPartyMoney());
		bJson.append(res.getLadyCoin());
		bJson.append(res.getExploit());
		Return(r, res_sucess);
	}

	void gm_tools::LadyGet(net::Msg& m, Json::Value& r)
	{
		playerDataPtr player = player_mgr.getPlayer(m.playerID);
		if (!player)Return(r, err_null_player);
		r[strMsg][1u] = player->Card->gmPackage();
		Return(r, res_sucess);
	}

	void gm_tools::ManGet(net::Msg& m, Json::Value& r)
	{
		playerDataPtr player = player_mgr.getPlayer(m.playerID);
		if (!player)Return(r, err_null_player);
		r[strMsg][1u] = player->Man->gmPackage();
		Return(r, res_sucess);
	}

	void gm_tools::ItemGet(net::Msg& m, Json::Value& r)
	{
		playerDataPtr player = player_mgr.getPlayer(m.playerID);
		if (!player)Return(r, err_null_player);
		r[strMsg][1u] = player->Items->gmPackage();
		Return(r, res_sucess);
	}

	void gm_tools::BaseSet(net::Msg& m, Json::Value& r)
	{
		playerDataPtr player = player_mgr.getPlayer(m.playerID);
		if (!player)Return(r, err_null_player);
		ReadJsonArray;
		string name = js_msg[0u].asString();
		unsigned lv = js_msg[1u].asUInt();
		unsigned exp = js_msg[2u].asUInt();
		int face = js_msg[3u].asInt();
		int vip_exp = js_msg[4u].asInt();
		playerBase& Bas = *(player->Info.get());
		const unsigned old_lv = Bas.LV();
		Bas.motifyName(name);
		Bas.setLV_gm(lv);
		Bas.setExp_gm(exp);
		Bas.setDone_gm(old_lv);
		Bas.setFace(face);
		Bas.addVipExp(vip_exp);
		Return(r, res_sucess);
	}

	void gm_tools::ResSet(net::Msg& m, Json::Value& r)
	{
		playerDataPtr player = player_mgr.getPlayer(m.playerID);
		if (!player)Return(r, err_null_player);
		playerResource& res = *(player->Res.get());
		ReadJsonArray;
		int gold = js_msg[0u].asInt();
		int ticket = js_msg[1u].asInt();
		int silver = js_msg[2u].asInt();
		int food = js_msg[3u].asInt();
		int wood = js_msg[4u].asInt();
		int iron = js_msg[5u].asInt();
		int merit = js_msg[6u].asInt();
		int fame = js_msg[7u].asInt();
		int action = js_msg[8u].asInt();
		int contribute = js_msg[9u].asInt();
		int hpmoney = js_msg[10u].asInt();
		int ladycoin = js_msg[11u].asInt();
		int exploit = js_msg[12u].asInt();
		res.alterGold(gold);
		res.alterTicket(ticket);
		res.alterSilver(silver);
		res.alterFood(food);
		res.alterWood(wood);
		res.alterIron(iron);
		res.alterMerit(merit);
		res.alterFame(fame);
		res.alterAction(action);
		res.alterContribution(contribute);
		res.alterHeroPartyMoney(hpmoney);
		res.alterLadyCoin(ladycoin);
		playerKingdomWar::ExploitReason = KingdomWar::GM;
		res.alterExploit(exploit);
		Return(r, res_sucess);
	}

	void gm_tools::LadySet(net::Msg& m, Json::Value& r)
	{
		playerDataPtr player = player_mgr.getPlayer(m.playerID);
		if (!player)Return(r, err_null_player);
		Return(r, res_sucess);
	}

	void gm_tools::ManSet(net::Msg& m, Json::Value& r)
	{
		playerDataPtr player = player_mgr.getPlayer(m.playerID);
		if (!player)Return(r, err_null_player);
		ReadJsonArray;
		Json::Value& res_json = r[strMsg][1u];
		for (unsigned i = 0; i < js_msg.size() && i < 30; ++i)
		{
			Json::Value& sg_json = js_msg[i];
			const int manID = sg_json[0u].asInt();
			const unsigned manLV = sg_json[1u].asUInt();
			const unsigned manExp = sg_json[2u].asUInt();
			const unsigned manState = sg_json[3u].asUInt();
			playerManPtr man = player->Man->findMan(manID);
			if (!man)
			{
				res_json.append(manID);
				continue;
			}
			man->setLV_gm(manLV);
			man->setExp_gm(manExp);
			man->setState_gm(manState);
			man->setDone_gm();
		}
		Return(r, res_sucess);
	}

	void gm_tools::ManAdd(net::Msg& m, Json::Value& r)
	{
		playerDataPtr player = player_mgr.getPlayer(m.playerID);
		if (!player)Return(r, err_null_player);
		ReadJsonArray;
		for (unsigned i = 0; i < js_msg.size() && i < 30; ++i)
		{
			player->Man->addMan(js_msg[i].asInt());
		}
		Return(r, res_sucess);
	}

	void gm_tools::ItemAdd(net::Msg& m, Json::Value& r)
	{
		playerDataPtr player = player_mgr.getPlayer(m.playerID);
		if (!player)Return(r, err_null_player);
		ReadJsonArray;
		Json::Value& error_json = (r[strMsg][1u] = Json::arrayValue);
		for (unsigned i = 0; i < js_msg.size() && i < 30; ++i)
		{
			Json::Value& item_json = js_msg[i];
			const int itemID = item_json[0u].asInt();
			const unsigned num = item_json[1u].asUInt();
			if (player->Items->addItem(itemID, num).empty())
			{
				error_json.append(item_json);
			}
		}
		Return(r, res_sucess);
	}

	void gm_tools::ItemRemove(net::Msg& m, Json::Value& r)
	{
		playerDataPtr player = player_mgr.getPlayer(m.playerID);
		if (!player)Return(r, err_null_player);
		ReadJsonArray;
		Json::Value& error_json = (r[strMsg][1u] = Json::arrayValue);
		for (unsigned i = 0; i < js_msg.size() && i < 30; ++i)
		{
			Json::Value& item_json = js_msg[i];
			const int itemID = item_json[0u].asInt();
			const unsigned num = item_json[1u].asUInt();
			itemPtr item = player->Items->getLocalItem(itemID, itemDef::pos_bag | itemDef::pos_man);
			if (!item)
			{
				error_json.append(item_json);
				continue;
			}
			item->cutNum(num);
		}
		Return(r, res_sucess);
	}

	void gm_tools::CardAdd(net::Msg& m, Json::Value& r)
	{
		playerDataPtr player = player_mgr.getPlayer(m.playerID);
		if (!player)Return(r, err_null_player);
		ReadJsonArray;
		Json::Value& error_json = (r[strMsg][1u] = Json::arrayValue);
		for (unsigned i = 0; i < js_msg.size() && i < 30; ++i)
		{
			Json::Value& card_json = js_msg[i];
			const int cardID = card_json[0u].asInt();
			const unsigned num = card_json[1u].asUInt();
			if (player->Card->resAddCard(cardID, num) != res_sucess)
			{
				error_json.append(card_json);
			}
		}
		Return(r, res_sucess);
	}

	void gm_tools::Recharge(net::Msg& m, Json::Value& r)//Ψһ�ĳ�ֵ���
	{
		ReadJsonArray;
		const int playerID = js_msg[0u].asInt();
		const string order_str = js_msg[1u].asString();
		const int add_gold = js_msg[2u].asInt();
		const int add_extra_gold = js_msg[3u].asInt();
		const int type = js_msg[4u].asInt();
		playerDataPtr player = player_mgr.getPlayer(playerID);
		if (!player)Return(r, err_null_player);
		player->Res->alterGold(add_gold);
		player->Res->alterTicket(add_extra_gold);
		//ģ��VIP��ȡ����
		player->Info->addVipExp(add_gold);
		player->Res->addRechargeNum(add_gold);
		money_sys.tickNum(player, MONEYACTIVITY::money_activity_recharge, add_gold);
		Log(DBLOG::strLogRecharge, -1, order_str, add_gold, add_extra_gold, type, add_gold);//���ӻ�þ���
		qValue json(qJson::qj_array);
		json.append(res_sucess);
		json.append(order_str);
		json.append(add_gold);
		json.append(add_extra_gold);
		json.append(type);
		player->sendToClientFillMsg(gate_client::player_recharge_announce_resp, json);
		Return(r, res_sucess);
	}

	void gm_tools::GiftCard(net::Msg& m, Json::Value& r)
	{
		ReadJsonArray;
		const int playerID = js_msg[0u].asInt();
		const string info_json = js_msg[1u].toIndentString();
		Json::Value& rwTo = js_msg[2u];
		playerDataPtr player = player_mgr.getPlayer(playerID);
		if (!player)Return(r, err_null_player);
		const int action_res = actionDoBox(player, actionFormatBox(rwTo));
		Json::Value resJson = actionRes();
		if (res_sucess == action_res && player->isOnline())
		{
			Json::Value json;
			json[strMsg][0u] = res_sucess;
			json[strMsg][1u] = resJson;
			player->sendToClient(gate_client::player_gift_reward_resp, json);
		}
		Log(DBLOG::strLogGiftFromGM, player, -1, info_json, "", "", "", "", "", "", resJson.toIndentString());
		Return(r, action_res);
	}

	void gm_tools::ReplyTickGamer(net::Msg& m, Json::Value& r)
	{
		playerDataPtr player = player_mgr.getOnlinePlayer(m.playerID);
		if (!player)Return(r, err_player_not_online);
		static Json::Value nullJson = Json::objectValue;
		player->sendToClient(gate_client::player_gm_reply_resp, nullJson);
		Return(r, res_sucess);
	}


	void gm_tools::gmUpdateCustom(net::Msg& m, Json::Value& r)
	{
		const static unsigned PageNum = 20;
		ReadJsonArray;
		const unsigned page = js_msg[0u].asUInt();
		const unsigned page_start = page * PageNum;
		Json::Value& data_json = (r[strMsg][1u] = Json::arrayValue);
		unsigned cNum = 0;
		for (CustomMap::iterator it = CustomGifts.begin(); it != CustomGifts.end(); ++it)
		{
			if (cNum++ < page_start)continue;
			customPtr ptr = it->second;
			Json::Value sg_json;
			sg_json.append(ptr->csID);
			sg_json.append(ptr->title);
			sg_json.append(ptr->csWords);
			sg_json.append(ptr->boxJson);
			sg_json.append(Common::toStampTime(ptr->startTime));
			sg_json.append(Common::toStampTime(ptr->endTime));
			sg_json.append(ptr->perTime);
			sg_json.append(ptr->getTimes);
			sg_json.append(ptr->levelLimit);
			sg_json.append(ptr->vipLimit);
			data_json.append(sg_json);
			if (data_json.size() >= PageNum)break;
		}
		r[strMsg][2u] = CustomGifts.size() / PageNum + (CustomGifts.size() % PageNum > 0) ? 1 : 0;
		Return(r, res_sucess);
	}

	void gm_tools::gmMotifyCustom(net::Msg& m, Json::Value& r)
	{
		const unsigned now = Common::gameTime();
		ReadJsonArray;
		for (unsigned i = 0; i < js_msg.size(); ++i)
		{
			Json::Value& json = js_msg[i];
			const int csID = json[0u].asInt();
			customPtr ptr = getCustom(csID);
			if (!ptr)
			{
				ptr = Creator<customGift>::Create();
				ptr->createTime = Common::gameTime();
			}
			ptr->csID = csID;
			ptr->title = json[1u].asString();
			ptr->csWords = json[2u].asString();

			//ʱ���ж�
			ptr->startTime = Common::toLocalTime(json[4u].asUInt());
			ptr->endTime = Common::toLocalTime(json[5u].asUInt());
			if (now > ptr->endTime)
			{
				delCustom(csID);
				continue;
			}

			//����ж�
			ptr->boxList.clear();
			Json::Value& box_json_list = json[3u];
			ptr->boxJson = box_json_list;
			ptr->boxList = actionFormatBox(ptr->boxJson);
			if (ptr->boxList.empty())
			{
				delCustom(csID);
				continue;
			}

			//������Ϣ
			ptr->perTime = json[6u].asUInt();
			ptr->getTimes = json[7u].asInt();
			ptr->levelLimit = json[8u].asUInt();
			ptr->vipLimit = json[9u].asUInt();
			CustomGifts[ptr->csID] = ptr;
			saveCustom(ptr);
		}
		Return(r, res_sucess);
	}

	void gm_tools::motifyWarProcess(net::Msg& m, Json::Value& r)
	{
		playerDataPtr player = player_mgr.getPlayer(m.playerID);
		if (!player)Return(r, err_null_player);
		ReadJsonArray;
		for (unsigned i = 0; i < js_msg.size() && i < 50; ++i)
		{
			Json::Value& war_json = js_msg[i];
			const int mapID = war_json[0u].asInt();
			const unsigned star = war_json[1u].asUInt();
			player->War->changeStart_gm(mapID, star);
		}
		Return(r, res_sucess);
	}

	void gm_tools::CardRemove(net::Msg& m, Json::Value& r)
	{
		playerDataPtr player = player_mgr.getPlayer(m.playerID);
		if (!player)Return(r, err_null_player);
		ReadJsonArray;
		Json::Value& error_json = (r[strMsg][1u] = Json::arrayValue);
		for (unsigned i = 0; i < js_msg.size() && i < 30; ++i)
		{
			const int cardID = js_msg[i].asInt();
			playerCardPtr card = player->Card->getCard(cardID);
			if (!card)
			{
				error_json.append(cardID);
				continue;
			}
			card->Delete();
		}
		Return(r, res_sucess);
	}

	void gm_tools::ItemSet(net::Msg& m, Json::Value& r)
	{
		playerDataPtr player = player_mgr.getPlayer(m.playerID);
		if (!player)Return(r, err_null_player);
		Return(r, res_sucess);
	}
	//dbTimeTable

	static void saveTimeDev()
	{
		mongo::BSONObj key = BSON("key" << 1);
		mongo::BSONObj obj = BSON("key" << 1 << "dev" << Common::timeDev());
		db_mgr.SaveMongo(DBN::dbTimeTable, key, obj);
	}

	void gm_tools::TimeGet(net::Msg& m, Json::Value& r)
	{
		r[strMsg][1u] = Common::toStampTime(Common::gameTime());
		r[strMsg][2u] = Common::timeZone();
		r[strMsg][3u] = Common::timeDev();
		r[strMsg][4u] = Common::gameTime();
		Return(r, res_sucess);
	}

	void gm_tools::TimeSet(net::Msg& m, Json::Value& r)
	{
		ReadJsonArray;
		const unsigned dev = js_msg[0u].asUInt();
		if (dev > 10 * DAY)Return(r, err_illedge);
		const unsigned time_set = dev + Common::timeDev();
		Common::AnyFunction save_func = boost::bind(&saveTimeDev);
		Common::setTimeDev(time_set, save_func);

		//����ʱ��
		Json::Value time_json = season_sys.serverPackage();
		player_mgr.sendToAll(gate_client::server_info_resp, time_json);
		
		Return(r, res_sucess);
	}


	void gm_tools::updateCustomTitle(net::Msg& m, Json::Value& r)
	{
		playerDataPtr player = player_mgr.getPlayer(m.playerID);
		if (!player)Return(r, err_illedge);
		Json::Value& data_json = (r[strMsg][1u] = Json::arrayValue);
		const unsigned playerLV = player->LV();
		const unsigned playerVip = player->Info->VipLv();
		for (CustomMap::iterator it = CustomGifts.begin(); it != CustomGifts.end(); ++it)
		{
			customPtr ptr = it->second;
			const int res = player->Custom->canGetBox(ptr->csID, ptr->createTime, ptr->getTimes);
			if (res == err_custom_gift_get_max)continue;
			Json::Value sg_json;
			sg_json.append(ptr->csID);
			sg_json.append(ptr->title);
			sg_json.append(ptr->levelLimit);
			sg_json.append(ptr->vipLimit);
			sg_json.append(player->Custom->getBoxCD(ptr->csID, ptr->createTime));
			data_json.append(sg_json);
		}
		Return(r, res_sucess);
	}

	void gm_tools::updateCustom(net::Msg& m, Json::Value& r)
	{
		playerDataPtr player = player_mgr.getPlayer(m.playerID);
		if (!player)Return(r, err_illedge);
		ReadJsonArray;
		const int csID = js_msg[0u].asInt();
		customPtr ptr = getCustom(csID);
		const unsigned vipLevel = player->Info->VipLv();
		if (!ptr)Return(r, err_custom_gift_no_found);
		Json::Value& player_json = r[strMsg][1u];//�����Ϣ
		player_json.append(player->Custom->getBoxTimes(ptr->csID, ptr->createTime));
		player_json.append(player->Custom->getBoxCD(ptr->csID, ptr->createTime));
		Json::Value& data_json = r[strMsg][2u];//�����Ϣ
		data_json.append(ptr->csID);
		data_json.append(ptr->title);
		data_json.append(ptr->csWords);
		data_json.append(ptr->boxJson);
		data_json.append(ptr->startTime);
		data_json.append((ptr->endTime));
		data_json.append(ptr->perTime);
		data_json.append(ptr->getTimes);
		data_json.append(ptr->levelLimit);
		data_json.append(ptr->vipLimit);
		Return(r, res_sucess);
	}

	void gm_tools::getCustomBox(net::Msg& m, Json::Value& r)
	{
		playerDataPtr player = player_mgr.getPlayer(m.playerID);
		if (!player)Return(r, err_illedge);
		ReadJsonArray;
		const int csID = js_msg[0u].asInt();
		customPtr ptr = getCustom(csID);
		if (!ptr)Return(r, err_custom_gift_no_found);
		if (!ptr->isActive())Return(r, err_custom_not_active);
		if (player->LV() < ptr->levelLimit)Return(r, err_player_lv_too_low);
		const unsigned VipLevel = player->Info->VipLv();
		if (VipLevel < ptr->vipLimit)Return(r, err_vip_lv_too_low);
		int res = player->Custom->canGetBox(csID, ptr->createTime, ptr->getTimes);
		if (res != res_sucess)Return(r, res);
		res = actionDoBox(player, ptr->boxList, false);
		if (res != res_sucess)
		{
			r[strMsg][1u] = actionError();
			Return(r, res);
		}
		player->Custom->tickTimes(csID, ptr->createTime, ptr->perTime, 1);
		r[strMsg][3u] = Common::gameTime() + ptr->perTime + 1;
		r[strMsg][2u] = player->Custom->getBoxTimes(ptr->csID, ptr->createTime);
		r[strMsg][1u] = actionRes();
		Log(DBLOG::strLogCustomGift, player, -1, VipLevel, player->Custom->getBoxTimes(csID, ptr->createTime),
			ptr->title, "", "", "", "", r[strMsg][1u].toIndentString());
		Return(r, res_sucess);
	}

	bool gm_tools::isAliveCustom(const int csID, const unsigned ct)
	{
		customPtr ptr = getCustom(csID);
		if (!ptr)return false;
		if (ptr->createTime != ct)return false;
		return true;
	}

}


#include "patrol_system.h"


namespace gg
{
	patrol_system* const patrol_system::_Instance = new patrol_system();

	////��ʼ��ȫ�������������
	//static boost::random::mt19937 gen(Common::gameTime());
	////�ֲ��������������ӳ�䵽[1,6]
	//static const boost::random::uniform_int_distribution<> dist(1, 6);

	patrol_system::patrol_system()
	{
	}


	void patrol_system::initData()
	{
		BOOST_STATIC_ASSERT(EVENT_NUM == 6);
		_r_event[0].id = 1;
		_r_event[0].type = patrol::PatrolOneStar;
		_r_event[1].id = 2;
		_r_event[1].type = patrol::PatrolTwoStar;
		_r_event[2].id = 3;
		_r_event[2].type = patrol::PatrolThreeStar;
		_r_event[3].id = 4;
		_r_event[3].type = patrol::PatrolLadyCoin;
		_r_event[4].id = 5;
		_r_event[4].type = patrol::PatrolDice;
		_r_event[5].id = 6;
		_r_event[5].type = patrol::PatrolNone;

		_odds[0] = 0;
		int i = 0;

		std::cout << "load ./cardconfig/patrol.json" << std::endl;

		Json::Value value = Common::loadJsonFile(std::string("./instance/cardconfig/patrol.json"));
		Json::Value spots = value["s_port"];
		for (i = 0; i < spots.size(); ++i)
		{
			_spot.push_back(spots[i].asInt());
		}

		Json::Value odds = value["odds"];

		std::cout << "odds size:" << odds.size() << std::endl;
		assert(EVENT_NUM == odds.size());//
		
		for (i = 0; i < odds.size(); ++i)
		{
			_odds[i + 1] = odds[i].asInt();
			_odds[i + 1] += _odds[i];
		}
		assert(_odds[i] == ODDS_SUM);

		Json::Value s_event = value["s_event"];
		int j = 0;
		for (i = 0; i < s_event.size(); ++i)
		{
			SpecialEvent se;
			//s_id
			se.id = s_event[i]["s_id"].asInt();
			//subject
			Json::Value subject = s_event[i]["subject"];
			se.subject.topic = subject["topic"].asString();
			for (j = 0; j < subject["opt"].size(); ++j)
			{
				se.subject.option.push_back(subject["opt"][j].asString());
			}
			se.subject.ansIdx = subject["ans"].asInt();
			//box
			se.box_list = actionFormatBox(s_event[i]["box"]);
			//box2
			se.box_list = actionFormatBox(s_event[i]["box2"]);
			//push_back()
			_s_event.push_back(se);
		}

		Json::Value e_box = value["end_box"];
		for (i = 0; i < e_box.size(); ++i)
		{
			_e_event.push_back(actionFormatBox(e_box[i]["box"]));
		}

	}

	patrol_system::~patrol_system()
	{
	}

	patrol::RandomEvent patrol_system::getRandomEvent()
	{
		int target = Common::randomBetween(0, ODDS_SUM);
		size_t idx = 0;//����¼����±�
		for (int i = 0; i < EVENT_NUM; ++i)
		{
			if (target > _odds[i] && target <= _odds[i + 1])
			{
				idx = i;
				break;
			}
		}

		/*patrol::RandomEvent event = _r_event[idx];

		fillRandomEvent(event);*/

		return _r_event[idx];
	}

	void patrol_system::fillRandomEvent(patrol::RandomEvent & event)
	{
		if (event.type == patrol::PatrolLadyCoin
			|| event.type == patrol::PatrolNone
			|| event.type == patrol::PatrolDice)
		{
			return;
		}
		if (event.type == patrol::PatrolOneStar)
		{
			//1�ǣ�1��3��
			event.level = Common::randomBetween(1, 3);
			event.cardId = _star_id_group[0][Common::randomBetween(0, _star_id_group[0].size() - 1)];
		}
		if (event.type == patrol::PatrolTwoStar)
		{
			//2�ǣ�4��6��
			event.level = Common::randomBetween(1, 3);
			event.cardId = _star_id_group[1][Common::randomBetween(0, _star_id_group[1].size() - 1)];
		}
		if (event.type == patrol::PatrolThreeStar)
		{
			//3�ǣ�7��9��
			event.level = Common::randomBetween(1, 3);
			event.cardId = _star_id_group[2][Common::randomBetween(0, _star_id_group[2].size() - 1)];
		}
	}

	bool patrol_system::isSpecialSpot(unsigned pos)
	{
		return std::find(_spot.begin(), _spot.end(), pos) != _spot.end();
	}

	void patrol_system::reqPatrolInfo(net::Msg& m, Json::Value& r)
	{
		playerDataPtr player = player_mgr.getPlayer(m.playerID);
		if (!player)Return(r, err_illedge);

		tm now = Common::toTm(Common::gameTime());
		if (now.tm_hour < 10)
		{
			Return(r, err_patrol_beyond_time);
		}

		r[strMsg][0u] = (int)player->Patrol->getState();
		r[strMsg][1u] = player->Patrol->getPos();
		int e_id = player->Patrol->getEndPointIdx();
		if (e_id == -1)
		{
			e_id = Common::randomBetween(0, _e_event.size() - 1);
			player->Patrol->setEndPointIdx(e_id);
		}
		r[strMsg][2u] = e_id;
		r[strMsg][3u] = player->Res->getDice();
	}

	void patrol_system::reqPatrolThrowDice(net::Msg& m, Json::Value& r)
	{
		playerDataPtr player = player_mgr.getPlayer(m.playerID);
		if (!player)Return(r, err_illedge);

		tm now = Common::toTm(Common::gameTime());
		if (player->Res->getDice() == 0)
		{
			Return(r, err_patrol_dice_not_enough);
		}
		else if (player->Card->isOver())
		{
			Return(r, err_patrol_card_full);
		}
		else if (now.tm_hour < 10)
		{
			Return(r, err_patrol_beyond_time);
		}
		else if (player->Patrol->getState() != patrol::PatrolPenddingDice)
		{
			Return(r, err_patrol_state_error);
		}

		int point = Common::randomBetween(1, 6);
		player->Patrol->setPos(point, true);
		player->Patrol->setState(patrol::PatrolPenddingEvent);
		player->Res->alterDice(-1);
		Return(r, point);
		
	}

	void patrol_system::reqPatrolGetCurrEvent(net::Msg& m, Json::Value& r)
	{
		/*
		//�Ƿ�������㣿
		//1. �����
		//		�������ñ����ʷ������ñ��еĽ���
		//2. ����¼�
		//		����¼����ͣ���ͬ���¼������в�ͬ�ķ��ؽṹ��
		//			--������Ů�Ǽ���ȡ��Ů������ȼ�
		//3. �յ��¼�
		//		�������ñ����ʷ��ز�ͬ�Ľ������
		*/
		playerDataPtr player = player_mgr.getPlayer(m.playerID);
		if (!player)Return(r, err_illedge);

		tm now = Common::toTm(Common::gameTime());
		if (player->Patrol->getState() != patrol::PatrolPenddingEvent)
		{
			Return(r, err_patrol_state_error);
		}
		else if (now.tm_hour < 10)
		{
			Return(r, err_patrol_beyond_time);
		}


		Json::Value detail = Json::Value::null;
		if (!isSpecialSpot(player->Patrol->getPos()))
		{
			//����¼�
			r[strMsg][0u] = 1;
			patrol::RandomEvent event = getRandomEvent();
			fillRandomEvent(event);
			player->Patrol->setRandomEvent(event);

			detail["e_id"] = (int)event.type;
			detail["c_id"] = event.cardId;
			detail["lv"] = event.level;

			player->Patrol->setState(patrol::PatrolPenddingRewardRandom);
		}
		else if (player->Patrol->getPos() == END_POINT)
		{
			//�յ㱦�䣨�յ㲻��������¼��������¼���
			r[strMsg][0u] = 3;
			int target = player->Patrol->getEndPointIdx();
			detail["b_id"] = target;
			player->Patrol->setState(patrol::PatrolPenddingBox);
		}
		else
		{
			//�����
			r[strMsg][0u] = 2;
			int target = Common::randomBetween(0, _s_event.size() - 1);
			detail["s_id"] = target;
			//detail["box"] = _idBoxJson[target];
			player->Patrol->setSpecialEventIndex(target);
			player->Patrol->setState(patrol::PatrolPenddingRewardSpecial);

		}
		r[strMsg][1u] = detail;
		return;

	}

	void patrol_system::reqPatrolGetReward(net::Msg& m, Json::Value& r)
	{
		playerDataPtr player = player_mgr.getPlayer(m.playerID);
		if (!player)Return(r, err_illedge);

		tm now = Common::toTm(Common::gameTime());
		if (player->Patrol->getState() == patrol::PatrolPenddingEvent
			|| player->Patrol->getState() == patrol::PatrolPenddingDice)
		{
			Return(r, err_patrol_state_error);
		}
		else if (now.tm_hour < 10)
		{
			Return(r, err_patrol_beyond_time);
		}

		int oldDiceNum = player->Res->getDice();

		patrol::PatrolState state = player->Patrol->getState();
		if (state == patrol::PatrolPenddingRewardRandom)
		{
			//1. ����¼�����
			//2. ��ȡ����
			//3. ���ؽ����
			patrol::RandomEvent event = player->Patrol->getRandomEvent();
			if (event.type == patrol::PatrolNone)
			{
			}
			else if (event.type == patrol::PatrolDice)
			{
				player->Res->alterDice(1);
			}
			else if (event.type == patrol::PatrolLadyCoin)
			{
				player->Res->alterLadyCoin(1);
			}
			else if (event.type == patrol::PatrolOneStar)
			{
				player->Card->addCard(event.cardId, 1, event.level);
			}
			else if (event.type == patrol::PatrolTwoStar)
			{
				player->Card->addCard(event.cardId, 1, event.level);
			}
			else
			{
				player->Card->addCard(event.cardId, 1, event.level);
			}

			player->Patrol->setState(patrol::PatrolPenddingDice);

			Return(r, res_sucess);

		}
		else if (state == patrol::PatrolPenddingRewardSpecial)
		{
			ReadJsonArray;
			int flag = js_msg[0u].asInt();
			//1. �ر����±�
			//2. ��ý���
			//3. ���ؽ����
			int idx = player->Patrol->getSpecialEventIndex();
			//��ȡ����//һ�뽱����
			int ret = actionDoBox(player, _s_event[idx].box_list, false);
			if (flag == 1 && ret == res_sucess)
			{
				ret = actionDoBox(player, _s_event[idx].box_list2);
			}
			player->Patrol->setState(patrol::PatrolPenddingDice);
			Return(r, ret);
		}
		else if (state == patrol::PatrolPenddingBox)
		{
			//1. ���ձ����±�
			//2. ��ý���
			//3. ���ؽ����
			int idx = player->Patrol->getEndPointIdx();
			const int ret = actionDoBox(player, _e_event[idx], false);
			player->Patrol->setState(patrol::PatrolPenddingDice);

			//����λ��
			player->Patrol->setPos(1);
			//��һ�ֵ����ձ���
			player->Patrol->setEndPointIdx(Common::randomBetween(0, _e_event.size() - 1));
			Return(r, ret);
		}

		//
		Log<int,int>(DBLOG::strLogDice, player, 0, (int)state, oldDiceNum, player->Res->getDice());
	}
}

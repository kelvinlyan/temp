#include "money_activity.h"
#include "playerManager.h"

namespace gg
{
	MoneyActivity* const MoneyActivity::_Instance = new MoneyActivity();

	struct ActivityReward
	{
		ActivityReward()
		{
			checkNum = 0;
			rewardJson = Json::arrayValue;
			boxList.clear();
		}
		~ActivityReward(){}
		int checkNum;//�������
		Json::Value rewardJson;//reward json
		ACTION::BoxList boxList;//box list
	};
	SHAREPTR(ActivityReward, ptrReward);

	struct ActivityData
	{
		ActivityData(const MONEYACTIVITY::MATYPE type) : typeAct(type)
		{
			showBegin = 0;
			showEnd = 0;
			actBegin = 0;
			actEnd = 0;
			paramJson = Json::objectValue;
			createTime = 0;
			rewardList.clear();
			timerID = ptrTimerIdentify();
		}
		~ActivityData(){}
		void clearData()
		{
			showBegin = 0;
			showEnd = 0;
			actBegin = 0;
			actEnd = 0;
			paramJson = Json::objectValue;
			createTime = 0;
			rewardList.clear();
			if (timerID){
				timerID->delTimer();
			}
			timerID = ptrTimerIdentify();
			saveData();
		}
		void saveData()
		{
			mongo::BSONObj key = BSON("key" << typeAct);
			mongo::BSONArrayBuilder arr;
			for (MapReward::iterator it = rewardList.begin(); it != rewardList.end(); ++it)
			{
				ptrReward ptr = it->second;
				arr << BSON("cn" << ptr->checkNum << "re" << ptr->rewardJson.toIndentString());
			}
			mongo::BSONObj obj = BSON(
				"key" << typeAct << "ct" << createTime <<
				"ab" << actBegin << "ae" << actEnd << "sb" << 
				showBegin << "se" << showEnd << "pa" <<
				paramJson.toIndentString() << "box" << 
				arr.arr()
				);
			db_mgr.SaveMongo(DBN::dbMoneyActivity, key, obj);
		}
		void saveBackData()
		{
			mongo::BSONObj key = BSON("key" << typeAct << "ct" << createTime);
			mongo::BSONArrayBuilder arr;
			for (MapReward::iterator it = rewardList.begin(); it != rewardList.end(); ++it)
			{
				ptrReward ptr = it->second;
				arr << BSON("cn" << ptr->checkNum << "re" << ptr->rewardJson.toIndentString());
			}
			mongo::BSONObj obj = BSON(
				"key" << typeAct << "ct" << createTime <<
				"ab" << actBegin << "ae" << actEnd << "sb" <<
				showBegin << "se" << showEnd << "pa" <<
				paramJson.toIndentString() << "box" <<
				arr.arr()
				);
			db_mgr.SaveMongo(DBN::dbMoneyActivityBackUp, key, obj);
		}
		void delBackData()
		{
			mongo::BSONObj key = BSON("key" << typeAct << "ct" << createTime);
			db_mgr.RemoveCollection(DBN::dbMoneyActivityBackUp, key);
		}
		const MONEYACTIVITY::MATYPE typeAct;
		unsigned showBegin;
		unsigned showEnd;
		bool isShow()
		{
			const unsigned now = Common::gameTime();
			return (now >= showBegin && now <= showEnd);
		}
		unsigned actBegin;
		unsigned actEnd;
		bool isAct()
		{
			const unsigned now = Common::gameTime();
			return (now >= actBegin && now <= actEnd);
		}
		//////////////////////////////////////////////////////////////////////////
		bool isAward()
		{
			const unsigned now = Common::gameTime();
			return (now >= actBegin && now <= showEnd);
		}
		bool isMotify()
		{
			const unsigned now = Common::gameTime();
			return (actBegin == 0 || now < actBegin);
		}
		Json::Value clientJson()
		{
			Json::Value data_json = Json::arrayValue;
			data_json.append(showBegin);
			data_json.append(showEnd);
			data_json.append(actBegin);
			data_json.append(actEnd);
			data_json.append(paramJson);
			Json::Value json = Json::arrayValue;
			for (MapReward::iterator it = rewardList.begin(); it != rewardList.end(); ++it)
			{
				ptrReward ptr = it->second;
				Json::Value sg_json;
				sg_json.append(ptr->checkNum);
				sg_json.append(ptr->rewardJson);
				json.append(sg_json);
			}
			data_json.append(json);
			return data_json;
		}
		//////////////////////////////////////////////////////////////////////////
		Json::Value paramJson;//extra param
		unsigned createTime;//����ʱ��
		STDMAP(int, ptrReward, MapReward);
		MapReward rewardList;
		ptrTimerIdentify timerID;
	};
	SHAREPTR(ActivityData, ptrActivity);
	static ptrActivity ActivityList[MONEYACTIVITY::money_activity_num];
	struct BackUpKey
	{	
		BackUpKey(const unsigned type = MONEYACTIVITY::money_activity_begin, const unsigned ct = 0)
		{
			typeAtc = type;
			createTime = ct;
		}
		bool operator<(const BackUpKey& other)const
		{
			if (typeAtc != other.typeAtc)return typeAtc < other.typeAtc;
			return createTime < other.createTime;
		}
		unsigned typeAtc;
		unsigned createTime;
	};
	STDMAP(BackUpKey, ptrActivity, MapBackUp);
	static MapBackUp backUpMap[MONEYACTIVITY::money_activity_num];

	unsigned MoneyActivity::currentRewardKey(const unsigned type)
	{
		if (type > MONEYACTIVITY::money_activity_end)return 0;
		ptrActivity ptr = ActivityList[type];
		return ptr->createTime;
	}

	bool MoneyActivity::checkMatchCurrent(const unsigned type, const unsigned ct)
	{
		if (type > MONEYACTIVITY::money_activity_end)return false;
		ptrActivity ptr = ActivityList[type];
		return (ptr->createTime == ct);
	}

	ACTION::BoxList MoneyActivity::currenReward(const unsigned type, const int checkNum)
	{
		if (type > MONEYACTIVITY::money_activity_end)return ACTION::BoxList();
		ptrActivity ptr = ActivityList[type];
		ActivityData::MapReward::iterator re_it = ptr->rewardList.find(checkNum);
		if (re_it == ptr->rewardList.end())return ACTION::BoxList();
		return re_it->second->boxList;
	}

	bool MoneyActivity::hasReward(const unsigned type, const unsigned ct, const std::set<int>& filter, const int total_check)
	{
		if (type > MONEYACTIVITY::money_activity_end)return false;
		ptrActivity ptr = ActivityList[type];
		if (!ptr->isAward())return false;
		ActivityData::MapReward tmpMap = ptr->rewardList;
		for (std::set<int>::iterator it = filter.begin(); it != filter.end(); ++it)
		{
			tmpMap.erase(*it);
		}
		for (ActivityData::MapReward::iterator it = tmpMap.begin(); it != tmpMap.end(); ++it)
		{
			if (total_check >= it->second->checkNum)
			{
				return true;
			}
			break;
		}
		return false;
	}

	vector<Json::Value> MoneyActivity::backUpReward(const unsigned type, const unsigned ct, const std::set<int>& filter, const int total_check)
	{
		vector<Json::Value> vec;
		if (type > MONEYACTIVITY::money_activity_end)return vec;
		BackUpKey key(type, ct);
		MapBackUp::iterator it = backUpMap[type].find(key);
		if (it == backUpMap[type].end())return vec;
		ptrActivity ptr = it->second;
		ActivityData::MapReward tmpMap = ptr->rewardList;
		for (std::set<int>::iterator it = filter.begin(); it != filter.end(); ++it)
		{
			tmpMap.erase(*it);
		}
		for (ActivityData::MapReward::iterator it = tmpMap.begin(); it != tmpMap.end(); ++it)
		{
			if (total_check >= it->second->checkNum)
			{
				vec.push_back(it->second->rewardJson);
				continue;
			}
			break;
		}
		return vec;
	}

	static void MoneyTimer(ptrActivity ptr)
	{
		ptr->clearData();
		ptr->saveData();
		playerManager::playerDataVec vec =  player_mgr.allOnline();
		for (unsigned i = 0; i < vec.size(); ++i)
		{
			playerDataPtr player = vec[i];
			player->MoneyActivity->clearType();
			qValue json(qJson::qj_array);
			json.append(res_sucess);
			json.append(ptr->typeAct);
			json.append(false);
			player->sendToClientFillMsg(gate_client::player_money_activity_update_red_resp, json);
		}
	}

	void MoneyActivity::initData()
	{
		//��ʼ��
		for (unsigned i = 0; i < MONEYACTIVITY::money_activity_num; ++i)
		{
			ActivityList[i] = Creator<ActivityData>::Create(MONEYACTIVITY::MATYPE(i));
			ptrActivity ptr = ActivityList[i];
			mongo::BSONObj key = BSON("key" << i);
			mongo::BSONObj obj = db_mgr.FindOne(DBN::dbMoneyActivity, key);
			if (obj.isEmpty())continue;
			ptr->actBegin = obj["ab"].Int();
			ptr->actEnd = obj["ae"].Int();
			ptr->showBegin = obj["sb"].Int();
			ptr->showEnd = obj["se"].Int();
			ptr->createTime = obj["ct"].Int();
			if (ptr->showEnd < Common::gameTime())
			{
				ptr->clearData();
				continue;
			}
			ptr->paramJson = Common::string2json(obj["pa"].String());
			vector<mongo::BSONElement> vecs = obj["box"].Array();
			for (unsigned idx = 0; idx < vecs.size(); ++idx)
			{
				mongo::BSONElement& elem = vecs[idx];
				ptrReward ptr_re = Creator<ActivityReward>::Create();
				ptr_re->checkNum = elem["cn"].Int();
				ptr_re->rewardJson = Common::string2json(elem["re"].String());
				ptr_re->boxList = actionFormatBox(ptr_re->rewardJson);
				ptr->rewardList[ptr_re->checkNum] = ptr_re;
			}
		}

		{//ȫ������
			objCollection objs = db_mgr.Query(DBN::dbMoneyActivityBackUp);
			for (unsigned i = 0; i < objs.size();++i)
			{
				mongo::BSONObj& obj = objs[i];
				const unsigned type = obj["key"].Int();
				if (type > MONEYACTIVITY::money_activity_end)continue;
				ptrActivity ptr = Creator<ActivityData>::Create(MONEYACTIVITY::MATYPE(type));
				ptr->actBegin = obj["ab"].Int();
				ptr->actEnd = obj["ae"].Int();
				ptr->showBegin = obj["sb"].Int();
				ptr->showEnd = obj["se"].Int();
				ptr->createTime = obj["ct"].Int();
				ptr->paramJson = Common::string2json(obj["pa"].String());
				vector<mongo::BSONElement> vecs = obj["box"].Array();
				for (unsigned idx = 0; idx < vecs.size(); ++idx)
				{
					mongo::BSONElement& elem = vecs[idx];
					ptrReward ptr_re = Creator<ActivityReward>::Create();
					ptr_re->checkNum = elem["cn"].Int();
					ptr_re->rewardJson = Common::string2json(elem["re"].String());
					ptr_re->boxList = actionFormatBox(ptr_re->rewardJson);
					ptr->rewardList[ptr_re->checkNum] = ptr_re;
				}
				backUpMap[type][BackUpKey(type, ptr->createTime)] = ptr;
			}
		};

		for (unsigned i = 0; i < MONEYACTIVITY::money_activity_num; ++i)
		{
			ptrActivity ptr = ActivityList[i];
			if (ptr->isAct() && !ptr->timerID)
			{
				ptr->timerID = Timer::AddEventTickTime(boostBind(MoneyTimer, ptr), Inter::event_timer_money_activity, ptr->showEnd + 1);
			}
		}
	}

	void MoneyActivity::tickNum(playerDataPtr player, const unsigned type, const int num)
	{
		if (type > MONEYACTIVITY::money_activity_end)return;
		ptrActivity ptr = ActivityList[type];
		if (!ptr->isAct())return;
		if (!ptr->timerID)
		{
			ptr->timerID = Timer::AddEventTickTime(boostBind(MoneyTimer, ptr), Inter::event_timer_money_activity, ptr->showEnd + 1);
		}
		if (backUpMap[type].insert(MapBackUp::value_type(BackUpKey(type, ptr->createTime), ptr)).second)//����ɹ�
		{
			ptr->saveBackData();
			if (backUpMap[type].size() > 100)
			{
				ptrActivity back_ptr = backUpMap[type].rbegin()->second;
				back_ptr->delBackData();
				backUpMap[type].erase(BackUpKey(back_ptr->typeAct, back_ptr->createTime));
			}
		}
		player->MoneyActivity->tickNum(type, num);
	}

	void MoneyActivity::UpdateRed(net::Msg& m, Json::Value& r)
	{
		playerDataPtr player = player_mgr.getPlayer(m.playerID);
		if (!player)Return(r, err_illedge);
		ReadJsonArray;
		const unsigned type = js_msg[0u].asUInt();
		if (type > MONEYACTIVITY::money_activity_end)Return(r, err_illedge);
		r[strMsg][1u] = type;
		r[strMsg][2u] = player->MoneyActivity->hasReward(type);
		Return(r, res_sucess);
	}

	void MoneyActivity::UpdateOwn(net::Msg& m, Json::Value& r)
	{
		playerDataPtr player = player_mgr.getPlayer(m.playerID);
		if (!player)Return(r, err_illedge);
		ReadJsonArray;
		const unsigned type = js_msg[0u].asUInt();
		if (type > MONEYACTIVITY::money_activity_end)Return(r, err_illedge);
		player->MoneyActivity->signTickUpdate(type);
	}

	void MoneyActivity::GetTitle(net::Msg& m, Json::Value& r)
	{
		Json::Value& data_json = r[strMsg][1u] = Json::arrayValue;
		for (unsigned i = 0; i < MONEYACTIVITY::money_activity_num; ++i)
		{
			if (ActivityList[i]->isShow())
			{
				data_json.append(i);
			}
		}
		Return(r, res_sucess);
	}

	void MoneyActivity::GetDetail(net::Msg& m, Json::Value& r)
	{
		playerDataPtr player = player_mgr.getPlayer(m.playerID);
		if (!player)Return(r, err_illedge);
		ReadJsonArray;
		const unsigned idx = js_msg[0u].asUInt();
		if (idx > MONEYACTIVITY::money_activity_end)Return(r, err_illedge);
		ptrActivity ptr = ActivityList[idx];
		if (!ptr->isShow())Return(r, err_money_activity_not_show);
		r[strMsg][1u] = ptr->clientJson();
		Return(r, res_sucess);
	}

	void MoneyActivity::WonReward(net::Msg& m, Json::Value& r)
	{
		playerDataPtr player = player_mgr.getPlayer(m.playerID);
		if (!player)Return(r, err_illedge);
		ReadJsonArray;
		const unsigned type = js_msg[0u].asUInt();
		const int checkNum = js_msg[1u].asInt();
		if (type > MONEYACTIVITY::money_activity_end)Return(r, err_illedge);
		ptrActivity ptr = ActivityList[type];
		if (!ptr->isAward())Return(r, err_money_activity_not_award);
		const int res = player->MoneyActivity->tryAward(type, checkNum);
		if (res == res_sucess)
		{
			r[strMsg][1u] = actionRes();
		}
		else if (res == err_action_do_failed)
		{
			r[strMsg][1u] = actionError();
		}
		//���
		qValue json(qJson::qj_array);
		json.append(res_sucess);
		json.append(type);
		json.append(player->MoneyActivity->hasReward(type));
		player->sendToClientFillMsg(gate_client::player_money_activity_update_red_resp, json);
		Return(r, res);
	}

	void MoneyActivity::GmUpdate(net::Msg& m, Json::Value& r)
	{
		ReadJsonArray;
		const unsigned type = js_msg[0u].asUInt();
		if (type > MONEYACTIVITY::money_activity_end)Return(r, err_illedge);
		ptrActivity ptr = ActivityList[type];
		Json::Value& data_json = r[strMsg][1u] = Json::objectValue;
		data_json["ab"] = Common::toStampTime(ptr->actBegin);
		data_json["ae"] = Common::toStampTime(ptr->actEnd);
		data_json["sb"] = Common::toStampTime(ptr->showBegin);
		data_json["se"] = Common::toStampTime(ptr->showEnd);
		data_json["pa"] = ptr->paramJson;
		Json::Value& vecs = data_json["box"] = Json::arrayValue;
		for (ActivityData::MapReward::iterator it = ptr->rewardList.begin(); it != ptr->rewardList.end(); ++it)
		{
			ptrReward ptr_re = it->second;
			Json::Value sg_json;
			sg_json["cn"] = ptr_re->checkNum;
			sg_json["re"] = ptr_re->rewardJson;
			vecs.append(sg_json);
		}
		Return(r, res_sucess);
	}

	void MoneyActivity::GmMotify(net::Msg& m, Json::Value& r)
	{
		ReadJson;
		Json::Value& js_msg = js[strMsg];
		const unsigned type = js_msg["type"].asUInt();
		if (type > MONEYACTIVITY::money_activity_end)Return(r, err_illedge);
		ptrActivity ptr = ActivityList[type];
		const bool remove = js_msg["rm"].asBool();
		if (remove)
		{
			if (ptr->isAct())//��Ѿ���ʼ��
			{
				//����һ����Ҵٷ��ı���
				if (backUpMap[type].find(BackUpKey(type, ptr->createTime)) != backUpMap[type].end())
				{
					MoneyTimer(ptr);
					Return(r, res_sucess);
				}
			}
			ptr->clearData();
			ptr->saveData();
			Return(r, res_sucess);
		}
		if (!ptr->isMotify())Return(r, err_illedge);
		const unsigned actBegin = js_msg["ab"].asUInt();
		const unsigned actEnd = js_msg["ae"].asUInt();
		const unsigned showBegin = js_msg["sb"].asUInt();
		const unsigned showEnd = js_msg["se"].asUInt();
		const unsigned now = Common::gameTime();
		if (
			actBegin < showBegin ||
			actEnd > showEnd ||
			actBegin > actEnd ||
			showBegin > showEnd ||
			now > Common::toLocalTime(actEnd) ||
			now > Common::toLocalTime(showEnd)
			) Return(r, err_illedge);
		ptr->actBegin = Common::toLocalTime(actBegin);
		ptr->actEnd = Common::toLocalTime(actEnd);
		ptr->showBegin = Common::toLocalTime(showBegin);
		ptr->showEnd = Common::toLocalTime(showEnd);
		ptr->createTime = Common::gameTime();
		ptr->paramJson = js_msg["pa"];
		Json::Value vecs = js_msg["box"];
		ptr->rewardList.clear();//����ɵ�����
		for (unsigned idx = 0; idx < vecs.size(); ++idx)
		{
			Json::Value& elem = vecs[idx];
			ptrReward ptr_re = Creator<ActivityReward>::Create();
			ptr_re->checkNum = elem["cn"].asInt();
			ptr_re->rewardJson = elem["re"];
			ptr_re->boxList = actionFormatBox(ptr_re->rewardJson);
			ptr->rewardList[ptr_re->checkNum] = ptr_re;
		}
		ptr->saveData();
		Return(r, res_sucess);
	}

}
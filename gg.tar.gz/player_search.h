#pragma once

#include "auto_base.h"

namespace gg
{
	namespace Search
	{
		struct ShopRecord
		{
			ShopRecord(int id, int buy_times)
				: _id(id), _buy_times(buy_times){}

			int _id;	
			int _buy_times;
		};
	}

	STDVECTOR(Search::ShopRecord, SearchShopRecords);

	class playerSearch
		: public _auto_player
	{
		public:
			playerSearch(playerData* const own);

			void loadDB();
			virtual bool _auto_save();
			virtual void _auto_update();

			void update();
			void updateShop();

			int searchFor(int id, int type, bool batch, Json::Value& r);
			int getReward(int id, Json::Value& r);
			int cleanCd(int id);
			int buy(int pos, int id, Json::Value& r);
			int flush();

			void dailyTick();

		private:
			int oneSearch(int id, int type);
			int batchSearch(int id, int type, Json::Value& r);
			void updateTask(const Json::Value& rw);

		private:
			void checkShopRecord();
			
		private:
			unsigned _cd;
			unsigned _id;
			int _type;
			unsigned _flush_times;
			unsigned _search_times;

			SearchShopRecords _records;
	};
}

//###################################
//create by Jim
//2016-01-26
//###################################


#pragma once

#include "auto_base.h"

namespace gg
{
	class playerPoke :
		public _auto_player
	{
	public:
		playerPoke(playerData* const own);
		~playerPoke(){}
		void signPoke(const int pokeID);//��ʶͼ��
		void loadDB();
		virtual void _auto_update();
	private:
		virtual bool _auto_save();
		std::string pokeData;//ͼ������ 0,1���
	};
}
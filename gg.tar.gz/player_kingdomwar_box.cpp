#include "player_kingdomwar_box.h"
#include "playerManager.h"

namespace gg
{
	namespace KingdomWar
	{
		struct BoxData
		{	
			BoxData(const Json::Value& info)
			{
				_target = info["target"].asInt();
				Json::Value box = info["reward"];
				_box = actionFormatBox(box);
			}

			int _target;
			ACTION::BoxList _box;
		};

		SHAREPTR(BoxData, BoxDataPtr);
		STDVECTOR(BoxDataPtr, BoxDataMap);

		static BoxDataPtr getBoxData(int id)
		{
			static BoxDataMap box_map;
			if (box_map.empty())
			{
				Json::Value json = Common::loadJsonFile("./instance/kingdom_war/box_reward.json");
				ForEach(Json::Value, it, json)
					box_map.push_back(Creator<BoxData>::Create(*it));
				if (box_map.empty())
					LogE << "kingdom war box_reward.json error" << LogEnd;
			}
			if (id < 0 || id >= box_map.size())
			{
				LogE << "kingdom war box data index out of range: " << id << LogEnd;
				return BoxDataPtr();
			}
			return box_map[id];
		}
	}

	playerKingdomWarBox::playerKingdomWarBox(playerData* const own)
		: _auto_player(own)
	{
		_box_state.assign(5, 0);
		_rp_state = -1;
	}

	void playerKingdomWarBox::loadDB()
	{
		mongo::BSONObj key = BSON(strPlayerID << Own().ID());
		mongo::BSONObj obj = db_mgr.FindOne(DBN::dbPlayerKingdomWarBox, key);
		
		if (obj.isEmpty()) 
			return;

		std::vector<mongo::BSONElement> ele = obj["bx"].Array();
		for (unsigned i = 0; i < ele.size(); ++i)
			_box_state[i] = ele[i].Int();
	}

	bool playerKingdomWarBox::_auto_save()
	{
		mongo::BSONObj key = BSON(strPlayerID << Own().ID());
		mongo::BSONObjBuilder obj;
		obj << strPlayerID << Own().ID();
		{
			mongo::BSONArrayBuilder b;
			for (unsigned i = 0; i < 5; ++i)
				b.append(_box_state[i]);
			obj << "bx" << b.arr();
		}
		return db_mgr.SaveMongo(DBN::dbPlayerKingdomWarBox, key, obj.obj());
	}

	void playerKingdomWarBox::_auto_update()
	{
		update();
	}

	void playerKingdomWarBox::update()
	{
		qValue m;
		m.append(res_sucess);
		qValue q;
		ForEachC(std::vector<int>, it, _box_state)
			q.append(*it);
		m.append(q);
		Own().sendToClientFillMsg(gate_client::kingdom_war_box_reward_resp, m);
	}

	void playerKingdomWarBox::clear()
	{
		_box_state.clear();
		_box_state.assign(5, 0);
		_rp_state = -1;
		resetRpStateAndUpdate();
		_sign_save();
	}

	int playerKingdomWarBox::rpState()
	{
		if (_rp_state == -1)
			resetRpState();
		return _rp_state == 2? 0 : _rp_state;
	}

	void playerKingdomWarBox::resetRpStateAndUpdate()
	{
		if (_rp_state == 2)
			return;
		int tmp = _rp_state;
		resetRpState();
		if (tmp != _rp_state)
			Own().KingDomWar->updateRedPoint();
	}

	void playerKingdomWarBox::resetRpState()
	{
		for (int id = 0; id < 5; ++id)
		{
			if (_box_state[id] == 1)
				continue;
			KingdomWar::BoxDataPtr ptr = KingdomWar::getBoxData(id);
			if (!ptr)
			{
				_rp_state = 0;
				return;
			}
			if (Own().KingDomWar->getExploit() >= ptr->_target)
			{
				_rp_state = 1;
				return;
			}
			else
			{
				_rp_state = 0;
				return;
			}
		}
		_rp_state = 2;
	}

	int playerKingdomWarBox::getReward(int id, Json::Value& r)
	{
		KingdomWar::BoxDataPtr ptr = KingdomWar::getBoxData(id);
		if (!ptr)
			return err_illedge;

		if (Own().KingDomWar->getExploit() < ptr->_target
			|| _box_state[id] != 0)
			return err_illedge;

		int res = actionDoBox(Own().getOwnDataPtr(), ptr->_box, false);
		if (res == res_sucess)
		{
			r = actionRes();
			_box_state[id] = 1;
			resetRpStateAndUpdate();
			_sign_auto();
		}
		else
		{
			Json::Value error_code = actionError();
			res = error_code[0u][1u].asInt();
		}

		return res_sucess;
	}
	
}

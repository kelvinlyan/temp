#include "fund_config.h"

namespace gg
{
	FundConfig* const FundConfig::_Instance = new FundConfig();


	FundConfig::FundConfig()
	{
		
	}

	void FundConfig::initData()
	{
		cout << "load ./fund/fund.json..." << endl;
		Json::Value value = Common::loadJsonFile(std::string("./instance/fund/fund.json"));
		_config.vip_lv = value["vip_lv"].asInt();
		_config.gold = value["gold"].asInt();
		Json::Value items = value["items"];
		for (int i = 0; i < items.size(); ++i)
		{
			FundReward reward;
			reward.id = items[i]["reward_id"].asInt();
			reward.r_lv = items[i]["r_lv"].asInt();
			//��json����Ϊ����ACTION::BoxList
			reward.box_list = actionFormatBox(items[i]["box"]);
			//���ڻ�������ݣ���log�ȣ�
			Json::Value box = items[i]["box"];
			std::string boxStr("[");
			for (int j = 0; j < box.size(); ++j)
			{
				boxStr += std::string("[");
				boxStr += boost::lexical_cast<std::string>(box[j]["aID"].asInt());
				boxStr += std::string(",");
				boxStr += boost::lexical_cast<std::string>(box[j]["v"].asInt());
				boxStr += std::string("]");
				if (j != box.size() - 1)
				{
					boxStr += std::string(",");
				}
			}
			boxStr += std::string("]");

			_idBoxDesc[reward.id] = boxStr;
			_idBoxJson[reward.id] = items[i]["box"];
			_config.reward_list[reward.id] = reward;

		}
	}

	//void FundConfig::generateAllIdLvBoxDesc()
	//{
	//	for (RewardList::const_iterator it = _config.reward_list.begin(); it != _config.reward_list.end(); ++it)
	//	{
	//		std::string item("id:");
	//		item += boost::lexical_cast<std::string>(it->first);
	//		item += std::string(",lv:");
	//		item += boost::lexical_cast<std::string>(it->second.r_lv);
	//		item += std::string(",box:");
	//		item += _idBoxDesc[it->first];//ͨ��idȡ��box�ı�ʾ

	//		_allDesc[it->first] = item;
	//	}
	//}
}
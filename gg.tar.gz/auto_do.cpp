#include "auto_do.h"
#include "playerData.h"

namespace gg
{
	int State::state = -1;
	int NumberCounter::counter = 0;

	void _auto_meta::_sign_auto()
	{
		try
		{
			_sign_save();
			_sign_update();
		}
		catch (std::exception& e)
		{
			LogE << e.what() << LogEnd;
		}
	}

	void _auto_meta::_sign_save()
	{
		if (_on_sign_save())
		{
			helper_mgr._tick_save(getOwn());
		}
	}

	void _auto_meta::_sign_update()
	{
		if (_on_sign_update())
		{
			helper_mgr._tick_update(getOwn());
		}
	}

	_meta_weak _auto_meta::getOwn()
	{
		return shared_from_this();
	}

	void _auto_player::_begin_update()
	{
		if (Own().isOnline())
		{
			_auto_update();
		}
	}

	helper* const helper::helperMgr = new helper();

	struct cmp_weak
	{
		bool operator()(const _meta_weak& l, const _meta_weak& r) const
		{
			_meta_shared shared_l = l.lock();
			_meta_shared shared_r = r.lock();
			return (shared_l.get() < shared_r.get());
		}
	};
	typedef std::set< _meta_weak, cmp_weak > metaList;
	//typedef boost::unordered_set< _meta_weak > metaList;
	metaList _save_meta, _update_meta;

	helper::helper()
	{
	}

	void helper::_tick_update(_meta_weak pointer)
	{
		if (!pointer.lock())return;
		_update_meta.insert(pointer);
	}

	void helper::_tick_save(_meta_weak pointer)
	{
		if (!pointer.lock())return;
		_save_meta.insert(pointer);
	}

	void helper::_tick_both(_meta_weak pointer)
	{
		if (!pointer.lock())return;
		_save_meta.insert(pointer);
		_update_meta.insert(pointer);
	}

	void helper::_run_tick()
	{
		for (metaList::iterator it = _update_meta.begin(); it != _update_meta.end(); ++it)
		{
			_meta_shared shared = (*it).lock();
			if (!shared)continue;
			shared->_begin_update();
		}

		for (metaList::iterator it = _save_meta.begin(); it != _save_meta.end(); ++it)
		{
			_meta_shared shared = (*it).lock();
			if (!shared)continue;
			shared->_auto_save();
			shared->_auto_end();
		}

		_update_meta.clear();
		_save_meta.clear();
	}


	void helper::_over_tick()
	{
		for (metaList::iterator it = _save_meta.begin(); it != _save_meta.end(); ++it)
		{
			_meta_shared shared = (*it).lock();
			if (!shared)continue;
			shared->_auto_save();
		}

		_update_meta.clear();
		_save_meta.clear();
	}

}


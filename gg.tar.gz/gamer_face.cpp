#include "gamer_face.h"
#include "dbDriver.h"

namespace gg
{
	playerFace::playerFace(playerData* const own) : _auto_player(own)
	{
		_FaceList.clear();
	}

	bool playerFace::openFace(const int faceID)
	{
		return _FaceList.find(faceID) != _FaceList.end();
	}

	void playerFace::insertFace(const int faceID)
	{
		_FaceList.insert(faceID);
	}
}

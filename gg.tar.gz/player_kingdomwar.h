#pragma once

#include "kingdomwar_def.h"
#include "kingdomwar_helper.h"
#include "kingdomwar_report.h"
#include "auto_base.h"
#include "mongoDB.h"

namespace gg
{
	namespace KingdomWar
	{
		enum
		{
			//reason
			Clear,
			Battle,
			UpManHp,
			GM,
			Others,
		};
	}

	class playerKingdomWar
		: public _auto_player
	{
		public:
			playerKingdomWar(playerData* const own);

			void loadDB();
			virtual bool _auto_save();
			virtual void _auto_update();

			void updateReport();
			void updateRedPoint();
			void alterRedPoint(bool rp);

			int manHp(int man_id) const;
			void setManHp(int man_id, int hp);
			bool isDead(int army_id);
			
			std::string addReport(qValue& rep, int result, int state, int army_id);
			int useHpItem(int army_id, int num);
			int buyHpItem(int num);

			int getExploit() const { return _exploit; } 
			int getTotalExploit() const { return _total_exploit; }
			int alterExploit(int num);
			void clearExploit();

			int alterArmyHp(int army_id, int num);
			void fillArmyHp(int army_id);
			int armyHp(int army_id, unsigned cur_time = 0, bool recal = false);
			bool armyHpFilled(int army_id);
			void resetArmyHp(int army_id, unsigned cur_time);

			void attach(int id);
			void detach(int id);

			unsigned siegeTimes() const { return _siege_times; }
			void clearWinStreak(int army_id);
			int winStreak(int army_id) const { return _win_streak[army_id]; } 
			unsigned useHpItemTimes() const { return _use_hp_item_times; }
			void dailyTick();

			static int ExploitReason;
		private:
			STDMAP(int, int, Man2HpMap);
			Man2HpMap _man_hp;

			KingdomWar::ReportMgr _rep_mgr;
			unsigned _report_id;
			bool _red_point;
			unsigned _siege_times;
			unsigned _use_hp_item_times;

			int _exploit;
			int _total_exploit;
			unsigned _clear_time;
			unsigned _win_streak[3];

			int _attach_city;
			bool _attach_main;

			STDVECTOR(int, ArmyHp);
			ArmyHp _army_hp;
			ArmyHp _army_hp_base;
	};
}

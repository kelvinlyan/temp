#include "rescue_system.h"
#include "ownerland_system.h"
#include "task_mgr.h"

namespace gg
{
	rescue_system* const rescue_system::_Instance = new rescue_system();

	struct rescueDefine
	{
		rescueDefine()
		{
			rescueID = Rescue::rescue_null;
			aliveTime = 2 * HOUR;
			remainTick = 10;
			rewardNum = 0;
			extraJson = Json::nullValue;
		}
		Rescue::TYPE rescueID;//����������
		unsigned aliveTime;//��Чʱ��//
		unsigned remainTick;//�ɱ������Ĵ���//Ĭ��10��
		int rewardNum;//��õĹ���ֵ
		Json::Value extraJson;//�����������Ϣ
	};
	static rescueDefine rescueDs[Rescue::rescue_end];//������Ϣ
	const rescueDefine& getRescueDf(const Rescue::TYPE type)
	{
		if (type <= Rescue::rescue_null || type >= Rescue::rescue_end)return rescueDs[Rescue::rescue_null];
		return rescueDs[type];
	}

	struct rescueKey
	{
		rescueKey()
		{
			playerID = -1;
			rescueID = Rescue::rescue_null;
		}
		rescueKey(const int id, const Rescue::TYPE type)
		{
			playerID = id;
			rescueID = type;
		}
		bool operator==(const rescueKey& key)const
		{
			return (
				key.playerID == playerID &&
				key.rescueID == rescueID
				);
		}
		int playerID;//���ID
		Rescue::TYPE rescueID;//����������
	};
	struct key_hash
	{
		std::size_t operator()(const rescueKey& key)const
		{
			std::size_t seed = 0;
			boost::hash_combine(seed, boost::hash_value(key.playerID));
			boost::hash_combine(seed, boost::hash_value(key.rescueID));
			return seed;
		}
	};

	//�����ص�
	namespace DEAL
	{
		static void tickRescuer(playerDataPtr who, playerDataPtr you, const rescueDefine& config, const Json::Value json = Json::objectValue)
		{
			Json::Value tickJson;
			tickJson[strMsg][0u] = res_sucess;
			tickJson[strMsg][1u] = config.rescueID;
			tickJson[strMsg][2u] = who->Name();
			tickJson[strMsg][3u] = json;
			you->sendToClient(gate_client::player_rescuer_tick_resp, tickJson);
		}

		static bool reduceBuildteam(playerDataPtr who, playerDataPtr you, const rescueDefine& config, const int iID, const unsigned idx)
		{
			if (you->BuildTeam->reduceBuildCDPer(iID, idx, 100, 5))//1% ����5��
			{
				tickRescuer(who, you, config);
				return true;
			}
			return false;
		}
	}
	typedef boost::function<bool(playerDataPtr, playerDataPtr, const rescueDefine&)> DealFunction;
	UNORDERMAP(int, DealFunction, DealMap);
	static DealMap MapDeal;//����ʵ��
	bool toDealRescue(playerDataPtr who, playerDataPtr you, const Rescue::TYPE type)
	{
		DealMap::iterator it = MapDeal.find(type);
		if (it == MapDeal.end())return false;
		const rescueDefine& rdf = getRescueDf(type);
		return it->second(who, you, rdf);
	}
	//��������ʱ��
	static bool rescueNewTick[Kingdom::nation_num];
	//����������Ϣ
	struct rescueInfo;
	SHAREPTR(rescueInfo, rescueIPtr);
	typedef boost::unordered_map<rescueKey, rescueIPtr, key_hash> rescueMap;
	static rescueMap rescues[Kingdom::nation_num];
	//����
	typedef std::list<rescueIPtr> rescueDataList;
	static rescueDataList rescuesList[Kingdom::nation_num];
	struct rescueInfo
	{
		rescueInfo()
		{
			playerID = -1;
			playerFace = -1;
			playerName = "";
			playerLV = 0;
			rescueID = Rescue::rescue_null;
			rescueData = "";
			aliveTime = 0;
			remainTick = 0;
			rescueList.clear();
			delDB = false;
		}
		~rescueInfo(){}
		rescueKey Key()
		{
			return rescueKey(playerID, rescueID);
		}
		bool tickHelp(playerDataPtr who, playerDataPtr you)
		{
			if (!toDealRescue(who, you, rescueID))
			{
				deleteData();
				return false;
			}
			const int won_num = who->RescueData->wonReward(100);
			Log(DBLOG::strLogRescue, you, 1, rescueID, rescueData.toIndentString(), who->ID(), who->Name(), won_num);
			rescueList.insert(who->ID());
			if (remainTick > 0)	--remainTick;
			if (0 == remainTick)deleteData();
			else saveData();
			return true;
		}
		UNORDERSET(int, ListSet);
		void saveData()
		{
			if (!delDB)
			{
				mongo::BSONObj key = toBsonKey();
				mongo::BSONObj obj = toBson();
				db_mgr.SaveMongo(DBN::dbRescue, key, obj);
			}
		}
		void deleteData()
		{
			remainTick = 0;
			aliveTime = 0;
			if (!delDB)
			{
				delDB = true;
				if (nationID > Kingdom::null && nationID < Kingdom::nation_num)
				{
					rescues[nationID].erase(Key());
				}
				mongo::BSONObj key = toBsonKey();
				db_mgr.RemoveCollection(DBN::dbRescue, key);
			}
		}
		mongo::BSONObj toBsonKey()
		{
			return BSON("pi" << playerID << "ri" << rescueID);
		}
		mongo::BSONObj toBson()
		{
			mongo::BSONArrayBuilder arr;
			for (ListSet::const_iterator it = rescueList.begin(); it != rescueList.end(); ++it)
			{
				arr << *it;
			}
			return BSON("pi" << playerID << "ri" << rescueID << "pn" << playerName << "na" <<  nationID <<
				"lv" << playerLV << "fid" << playerFace << 
				"rd" << rescueData.toIndentString() << "al" << aliveTime << "rm" << remainTick << "rl" << arr.arr());
		}
		void setBson(mongo::BSONObj& obj)
		{
			playerID = obj["pi"].Int();
			playerFace = obj["fid"].Int();
			playerName = obj["pn"].String();
			playerLV = (unsigned)obj["lv"].Int();
			rescueID = (Rescue::TYPE)obj["ri"].Int();
			string res_str = obj["rd"].String();
			rescueData = qValue(res_str.c_str());
			aliveTime = (unsigned)obj["al"].Int();
			remainTick = (unsigned)obj["rm"].Int();
			nationID = (Kingdom::NATION)obj["na"].Int();
			vector < mongo::BSONElement > vec = obj["rl"].Array();
			for (unsigned i = 0; i < vec.size(); ++i)
			{
				rescueList.insert(vec[i].Int());
			}
		}
		bool isDead()
		{
			unsigned now = Common::gameTime();
			return (remainTick == 0 || now > aliveTime);
		}
		bool isTickPlayer(const int playerID)
		{
			return rescueList.find(playerID) != rescueList.end();
		}
		qValue toJson()
		{
			qValue json(qJson::qj_object);
			json.addMember("pi", playerID);
			json.addMember("fid", playerFace);
			json.addMember("na", nationID);
			json.addMember("pn", playerName);
			json.addMember("lv", playerLV);
			json.addMember("ex", rescueData, true);
			json.addMember("al", aliveTime);
			json.addMember("rm", remainTick);
			json.addMember("tp", rescueID);
			return json;
		}
		int playerID;//���ID
		int playerFace;//���ͷ��
		Kingdom::NATION nationID;
		string playerName;//�������
		unsigned playerLV;//��ҵȼ�
		Rescue::TYPE rescueID;//����������
		qValue rescueData;//������ת������
		unsigned aliveTime;//��Чʱ��
		unsigned remainTick;//ʣ��ɱ������Ĵ���
		ListSet rescueList;//�����б�
		bool delDB;//�Ƿ�ɾ����DB
	};
	//�����㷨
	bool sortDataList(rescueIPtr left, rescueIPtr right)
	{
		return left->aliveTime > right->aliveTime;
	}
	//��������
	rescueIPtr FindRescueData(const Rescue::TYPE type, playerDataPtr player)
	{
		const Kingdom::NATION na = player->Info->Nation();
		if (na <= Kingdom::null || na >= Kingdom::nation_num)return rescueIPtr();
		rescueMap& checkMap = rescues[na];
		rescueMap::iterator it = checkMap.find(rescueKey(player->ID(), type));
		if (it == checkMap.end())return rescueIPtr();
		rescueIPtr ptr = it->second;
		if (ptr->isDead())
		{
			ptr->deleteData();
			return rescueIPtr();
		}
		return ptr;
	}
	rescueIPtr FindRescueData(const rescueKey key, playerDataPtr player)
	{
		const Kingdom::NATION na = player->Info->Nation();
		if (na <= Kingdom::null || na >= Kingdom::nation_num)return rescueIPtr();
		rescueMap& checkMap = rescues[na];
		rescueMap::iterator it = checkMap.find(key);
		if (it == checkMap.end())return rescueIPtr();
		rescueIPtr ptr = it->second;
		if (ptr->isDead())
		{
			ptr->deleteData();
			return rescueIPtr();
		}
		return ptr;
	}
	void InsertRescueData(rescueIPtr ptr)
	{
		const Kingdom::NATION na = ptr->nationID;
		if (na <= Kingdom::null || na >= Kingdom::nation_num)return;
		rescueMap& checkMap = rescues[na];
		checkMap[ptr->Key()] = ptr;
		rescueDataList& checkList = rescuesList[na];
		checkList.push_front(ptr);
		ptr->saveData();
		while (checkMap.size() > 100000)
		{
			rescueIPtr del = checkList.back();
			checkList.pop_back();
			del->deleteData();
		}
	}

	//֪ͨ��ʱ��
	static void newTickClient(const Kingdom::NATION nation)
	{
		rescueNewTick[nation] = false;
		static Json::Value json = Json::objectValue;
		player_mgr.sendToKingdom(nation, gate_client::system_new_rescue_info_resp, json);
	}

	void rescue_system::initData()
	{
		//ע�ᴦ������
		MapDeal[Rescue::rescue_build_1] = boostBind(DEAL::reduceBuildteam, _1, _2, _3, (int)LAND::zhu_cheng, 0);
		MapDeal[Rescue::rescue_build_2] = boostBind(DEAL::reduceBuildteam, _1, _2, _3, (int)LAND::zhu_cheng, 1);
		MapDeal[Rescue::rescue_build_3] = boostBind(DEAL::reduceBuildteam, _1, _2, _3, (int)LAND::zhu_cheng, 2);
		MapDeal[Rescue::rescue_build_4] = boostBind(DEAL::reduceBuildteam, _1, _2, _3, (int)LAND::xia_kou, 0);
		MapDeal[Rescue::rescue_build_5] = boostBind(DEAL::reduceBuildteam, _1, _2, _3, (int)LAND::xia_kou, 1);
		MapDeal[Rescue::rescue_build_6] = boostBind(DEAL::reduceBuildteam, _1, _2, _3, (int)LAND::xia_kou, 2);
		MapDeal[Rescue::rescue_build_7] = boostBind(DEAL::reduceBuildteam, _1, _2, _3, (int)LAND::xiang_yang, 0);
		MapDeal[Rescue::rescue_build_8] = boostBind(DEAL::reduceBuildteam, _1, _2, _3, (int)LAND::xiang_yang, 1);
		MapDeal[Rescue::rescue_build_9] = boostBind(DEAL::reduceBuildteam, _1, _2, _3, (int)LAND::xiang_yang, 2);
		MapDeal[Rescue::rescue_build_10] = boostBind(DEAL::reduceBuildteam, _1, _2, _3, (int)LAND::wu_ling, 0);
		MapDeal[Rescue::rescue_build_11] = boostBind(DEAL::reduceBuildteam, _1, _2, _3, (int)LAND::wu_ling, 1);
		MapDeal[Rescue::rescue_build_12] = boostBind(DEAL::reduceBuildteam, _1, _2, _3, (int)LAND::wu_ling, 2);


		//��ʼ�������ļ�
		playerRescue::initData();
		{
			Json::Value json = Common::loadJsonFile("./instance/rescue/rescue.json");
			for (unsigned i = 0; i < json.size(); ++i)
			{
				Json::Value& sg_json = json[i];
				const unsigned idx = sg_json["rescueID"].asUInt();
				if (idx <= Rescue::rescue_null || idx >= Rescue::rescue_end)continue;
				rescueDefine& rdf = rescueDs[idx];
				rdf.rescueID = (Rescue::TYPE)idx;
				if (sg_json.isMember("extraJson"))rdf.extraJson = sg_json["extraJson"];
				if (sg_json.isMember("remainTick"))rdf.remainTick = sg_json["remainTick"].asUInt();
				if (sg_json.isMember("aliveTime"))rdf.aliveTime = sg_json["aliveTime"].asUInt();
				if (sg_json.isMember("rewardNum"))rdf.rewardNum = sg_json["rewardNum"].asInt();
			}
		};

		//��ʼ�����ݿ�����
		for (unsigned i = 0; i < Kingdom::nation_num; ++i)
		{
			rescues[i].clear();
			rescuesList[i].clear();
			rescueNewTick[i] = false;
		}
		objCollection objC = db_mgr.Query(DBN::dbRescue);
		for (unsigned i = 0; i < objC.size(); ++i)
		{
			mongo::BSONObj& obj = objC[i];
			rescueIPtr ptr = Creator<rescueInfo>::Create();
			ptr->setBson(obj);
			if (ptr->nationID <= Kingdom::null || ptr->nationID >= Kingdom::nation_num)continue;
			rescues[ptr->nationID][ptr->Key()] = ptr;
			rescuesList[ptr->nationID].push_back(ptr);
		}
		for (unsigned i = 0; i < Kingdom::nation_num; ++i)
		{
			rescuesList[i].sort(sortDataList);
		}
	}

	int rescue_system::AddRescue(const Rescue::TYPE type, playerDataPtr player, Json::Value extraJson /* = Json::objectValue */)
	{
		if (!player)return err_illedge;
		const Kingdom::NATION na = player->Info->Nation();
		if (na <= Kingdom::null || na >= Kingdom::nation_num)return err_illedge;
		rescueIPtr old_ptr = FindRescueData(type, player);
		if (old_ptr)return err_rescue_duplication;
		const rescueDefine& config = getRescueDf(type);
		if (config.rescueID == Rescue::rescue_null)return err_illedge;
		rescueIPtr ptr = Creator<rescueInfo>::Create();
		ptr->playerID = player->ID();
		ptr->rescueID = type;
		ptr->nationID = na;
		ptr->playerName = player->Name();
		ptr->playerFace = player->Info->Face();
		ptr->playerLV = player->LV();
		string ex_str = extraJson.toIndentString();
		ptr->rescueData = qValue(ex_str.c_str());
		ptr->remainTick = config.remainTick;//�������
		ptr->aliveTime = Common::gameTime() + config.aliveTime;
		InsertRescueData(ptr);
		if (!rescueNewTick[na])
		{
			rescueNewTick[na] = true;
			Timer::AddEventSeconds(boostBind(newTickClient, na), Inter::event_tick_new_rescue, 30);//30s֮������
		}
		{
			//����	
			//player->Task->evTask(TaskDef::RescueNumEv);
			//�ճ�
			TaskMgr::update(player, Task::RescueTimes, 1);
			player->Daily->tickTask(DAILY::ask_for_help);
		}
		return res_sucess;
	}

	void rescue_system::removeRescue(const Rescue::TYPE type, playerDataPtr player)
	{
		if (!player)return;
		const Kingdom::NATION na = player->Info->Nation();
		if (na <= Kingdom::null || na >= Kingdom::nation_num)return;
		rescueIPtr old_ptr = FindRescueData(type, player);
		if (!old_ptr)return;
		old_ptr->deleteData();
	}

	void rescue_system::sendRescueData(playerDataPtr player)
	{
		if (!player)return;
		const Kingdom::NATION na = player->Info->Nation();
		if (na <= Kingdom::null || na >= Kingdom::nation_num)return;
		qValue updateJson(qJson::qj_object), data_arr(qJson::qj_array), data_list(qJson::qj_array);
		rescueDataList& checkList = rescuesList[na];
		unsigned num = 0;
		for (rescueDataList::iterator it = checkList.begin(); it != checkList.end();)
		{
			rescueDataList::iterator old_it = it;
			++it;
			rescueIPtr ptr = (*old_it);
			if (ptr->isDead())
			{
				checkList.erase(old_it);
				ptr->deleteData();
				continue;
			}
			if (ptr->playerID == player->ID())continue;
			if (ptr->isTickPlayer(player->ID()))continue;
			data_list.append(ptr->toJson());
			if (++num >= 20)break;
		}
		data_arr.append(res_sucess);
		data_arr.append(data_list);
		updateJson.addMember(strMsg, data_arr);
		player->sendToClient(gate_client::system_rescue_update_resp, updateJson);
	}

	void rescue_system::UpdateOwnRescue(net::Msg& m, Json::Value& r)
	{
		playerDataPtr player = player_mgr.getPlayer(m.playerID);
		if (!player)Return(r, err_illedge);
		player->RescueData->_auto_update();
	}

	void rescue_system::UpdateRescue(net::Msg& m, Json::Value& r)
	{
		playerDataPtr player = player_mgr.getPlayer(m.playerID);
		if (!player)Return(r, err_illedge);
		const Kingdom::NATION na = player->Info->Nation();
		if (na <= Kingdom::null || na >= Kingdom::nation_num)Return(r, err_illedge);
		sendRescueData(player);
	}

	void rescue_system::TickRescue(net::Msg& m, Json::Value& r)
	{
		playerDataPtr player = player_mgr.getPlayer(m.playerID);
		if (!player)Return(r, err_illedge);
		ReadJsonArray;
		Json::Value& res_code = (r[strMsg][2u] = Json::arrayValue);
		for (unsigned i = 0; i < js_msg.size() && i < 20; ++i)
		{
			Json::Value& sg_json = js_msg[i];
			const int playerID = sg_json[0u].asInt();
			const int type = sg_json[1u].asInt();
			rescueIPtr ptr = FindRescueData(rescueKey(playerID, (Rescue::TYPE)type), player);
			if (!ptr)
			{
				res_code.append(err_rescue_miss);
				continue;
			}
			playerDataPtr you = player_mgr.getPlayer(ptr->playerID);
			if (!you)
			{
				ptr->deleteData();
				res_code.append(err_rescue_miss);
				continue;
			}
			if (!ptr->tickHelp(player, you))res_code.append(err_rescue_miss);

			res_code.append(res_sucess);
		}
		sendRescueData(player);
		r[strMsg][1u] = js_msg.size();
		Return(r, res_sucess);
	}

}

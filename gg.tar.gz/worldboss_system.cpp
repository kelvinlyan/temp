#include "worldboss_system.h"
#include "battle_helper.hpp"
#include "game_time.h"
#include "email_system.h"
#include "task_mgr.h"
#include "chat.h"
#include "kingdom_system.h"

namespace gg
{
	template<typename T1, typename T2, typename T3, typename T4, typename T5>
	void worldBossBroadcast(int nation, int type, const T1& arg1, const T2& arg2, const T3& arg3, const T4& arg4, const T5& arg5)
	{
		Json::Value msg;
		msg.append(type);
		msg.append(arg1);
		msg.append(arg2);
		msg.append(arg3);
		msg.append(arg4);
		msg.append(arg5);
		if (nation == -1)
			chat_sys.despatchAll(CHAT::server_worldboss_state, msg);
		else
			chat_sys.despatchKingdom(CHAT::server_worldboss_state, (Kingdom::NATION)nation, msg);
	}

	namespace WorldBoss
	{
		enum
		{
			LvLimit = 25,
		};
	}

	worldboss_system* const worldboss_system::_Instance = new worldboss_system;

	worldboss_system::worldboss_system()
		: _report_mgr(10)
	{
	}

	void worldboss_system::initData()
	{
		// default value
		_map_id = -1;
		_bg_id = 0;
		_buff_id = 0;
		_20hp_broadcast = false;

		_state = WorldBoss::Closed;
		_tick_time = 0;
		_tick_day = 0;
		_next_tick_time = 0;

		_person_rank = Json::arrayValue;
		_nation_rank = Json::arrayValue;
		_ui_info = Json::arrayValue;
		for (unsigned i = 0; i < Kingdom::nation_num; ++i)
		{
			Json::Value tmp;
			tmp.append(i);
			tmp.append(0);
			_nation_rank.append(tmp);
			
			_reward_info[i]["nr"] = 0;
			_reward_info[i]["kd"] = 0;
			_reward_info[i]["ks"] = 0;
			_reward_info[i]["pi"] = -1;
		}

		loadFile();
		loadDB();
		createReportDir();

		setComingBroadcastTimer();
		setOpenBroadcastTimer();
		setBroadcastTimer14();
		setBroadcastTimer15();
	}

	void worldboss_system::showUI(net::Msg& m, Json::Value& r)
	{
		playerDataPtr d = player_mgr.getPlayer(m.playerID);
		if (!d) Return(r, err_illedge);

		if (d->Info->Nation() == Kingdom::null)
			Return(r, err_no_join_kingdom);
		if (d->LV() < WorldBoss::LvLimit)
			Return(r, err_lv_not_enough);

		addCachePlayer(d);
		d->WorldBoss->getUIInfo(r[strMsg][1u]);
		getUIInfo(d, r[strMsg][1u]);

		Return(r, res_sucess);
	}

	void worldboss_system::addCachePlayer(playerDataPtr d)
	{
		if (_cache_list.size() < WorldBoss::CacheSize)
		{
			ForEach(Json::Value, it, _cache_list)
			{
				if((*it)[0u].asInt() == d->ID())
					return;
			}
			Json::Value tmp;
			tmp.append(d->ID());
			tmp.append(d->Name());
			tmp.append(getFaceId(d));
			tmp.append(d->Info->Nation());
			Json::Value evv = Json::arrayValue;
			BattleEquipList equip_vec = getEquipList(d);
			ForEach(BattleEquipList, it, equip_vec)
			{
				BattleEquip& e = *it;
				Json::Value ev;
				ev.append(e.equipPos);
				ev.append(e.equipID);
				ev.append(e.equipLevel);
				evv.append(ev);
			}
			tmp.append(evv);
			_cache_list.append(tmp);
		}
	}

	void worldboss_system::getUIInfo(playerDataPtr d, Json::Value& info)
	{
		if (_map_id == -1)
		{
			int season = season_sys.getSeason(Common::gameTime());
			int type = (season == SEASON::Summer || season == SEASON::Winter)? 1 : 0;
			info["mid"] = _config.getMinMapId(type);
			info["chp"] = _config.getMinMapHp(type);
			info["mhp"] = _config.getMinMapHp(type);
		}
		else
		{
			info["mid"] = _map_id;
			info["chp"] = _total_hp;
			info["mhp"] = _max_hp;
		}
		info["da"] = _buff_id;
		info["kb"] = _nation_list.getRank(d->Info->Nation()) - 1;
		info["tt"] = _next_tick_time;
		info["st"] = _state;
		getUIPlayerList(info["ra"]);
	}

	void worldboss_system::fight(net::Msg& m, Json::Value& r)
	{
		ReadJsonArray;
		playerDataPtr d = player_mgr.getPlayer(m.playerID);
		if (!d) Return(r, err_illedge);

		if (d->Info->Nation() == Kingdom::null)
			Return(r, err_no_join_kingdom);
		if (d->LV() < WorldBoss::LvLimit)
			Return(r, err_lv_not_enough);
		if (d->WarFM->currentEmpty()) 
			Return(r, err_worldboss_empty);
		if (_state == WorldBoss::Closed)
			Return(r, err_worldboss_closed);
		if (d->WorldBoss->inCd())
			Return(r, err_worldboss_in_cd);
		
		int res = fightBoss(d);
		if (res == res_sucess)
		{
			r[strMsg][1u] = _param;
			_param = Json::nullValue;
		}
		Return(r, res);
	}
	
	void worldboss_system::showrep(net::Msg& m, Json::Value& r)
	{
		playerDataPtr d = player_mgr.getPlayer(m.playerID);
		if (!d) Return(r, err_illedge);

		if (d->Info->Nation() == Kingdom::null)
			Return(r, err_no_join_kingdom);
		if (d->LV() < WorldBoss::LvLimit)
			Return(r, err_lv_not_enough);
		
		_report_mgr.getInfo(r[strMsg][1u]["wr"]);
		d->WorldBoss->getReportInfo(r[strMsg][1u]["pr"]);
		Return(r, res_sucess);
	}

	void worldboss_system::showIncentive(net::Msg& m, Json::Value& r)
	{
		playerDataPtr d = player_mgr.getPlayer(m.playerID);
		if (!d) Return(r, err_illedge);

		if (d->Info->Nation() == Kingdom::null)
			Return(r, err_no_join_kingdom);
		if (d->LV() < WorldBoss::LvLimit)
			Return(r, err_lv_not_enough);
		
		d->WorldBoss->getIncentInfo(r[strMsg][1u]);
		r[strMsg][1u]["nm"] = _incent_num[d->Info->Nation()];
		Json::Value& names = r[strMsg][1u]["na"];
		names = Json::arrayValue;
		ForEach(NameList, it, _incent_names[d->Info->Nation()])
			names.append(*it);
		Return(r, res_sucess);
	}

	void worldboss_system::incentive(net::Msg& m, Json::Value& r)
	{
		playerDataPtr d = player_mgr.getPlayer(m.playerID);
		if (!d) Return(r, err_illedge);

		if (d->Info->Nation() == Kingdom::null)
			Return(r, err_no_join_kingdom);
		if (d->LV() < WorldBoss::LvLimit)
			Return(r, err_lv_not_enough);
		if (_state == WorldBoss::Closed)
			Return(r, err_worldboss_closed);
		
		ReadJsonArray;
		int type = js_msg[0u].asInt();
		int resource = js_msg[1u].asInt();

		if ((type != WorldBoss::KingdomType && type != WorldBoss::PersonType)
			|| (resource != WorldBoss::UseGold && resource != WorldBoss::UseMerit))
			Return(r, err_illedge);
		
		int res;
		if (type == WorldBoss::KingdomType)
			res = addKingdomeIncent(d, resource);
		else
			res = d->WorldBoss->addPersonIncent(resource);

		if (res == res_sucess)
		{
			r[strMsg][1u] = _param;
			_param = Json::nullValue;
		}
		Return(r, res);
	}

	void worldboss_system::rankKingdom(net::Msg& m, Json::Value& r)
	{
		playerDataPtr d = player_mgr.getPlayer(m.playerID);
		if (!d) Return(r, err_illedge);

		if (d->Info->Nation() == Kingdom::null)
			Return(r, err_no_join_kingdom);
		if (d->LV() < WorldBoss::LvLimit)
			Return(r, err_lv_not_enough);
		
		if (_state == WorldBoss::Opened)
			_nation_list.getInfo(r[strMsg][1u]);
		else
			r[strMsg][1u] = _nation_rank;

		Return(r, res_sucess);
	}

	void worldboss_system::rankSelf(net::Msg& m, Json::Value& r)
	{
		playerDataPtr d = player_mgr.getPlayer(m.playerID);
		if (!d) Return(r, err_illedge);

		if (d->Info->Nation() == Kingdom::null)
			Return(r, err_no_join_kingdom);
		if (d->LV() < WorldBoss::LvLimit)
			Return(r, err_lv_not_enough);
		
		if (_state == WorldBoss::Opened)
			_rank_list.getRankInfo(r[strMsg][1u]);
		else
			r[strMsg][1u] = _person_rank;

		Return(r, res_sucess);
	}

	void worldboss_system::cleanCd(net::Msg& m, Json::Value& r)
	{
		playerDataPtr d = player_mgr.getPlayer(m.playerID);
		if (!d) Return(r, err_illedge);

		if (d->Info->Nation() == Kingdom::null)
			Return(r, err_no_join_kingdom);
		if (d->LV() < WorldBoss::LvLimit)
			Return(r, err_lv_not_enough);
		if (_state == WorldBoss::Closed)
			Return(r, err_worldboss_closed);
		
		int res = d->WorldBoss->cleanCd();
		Return(r, res);
	}

	void worldboss_system::getReward(net::Msg& m, Json::Value& r)
	{
		playerDataPtr d = player_mgr.getPlayer(m.playerID);
		if (!d) Return(r, err_illedge);

		if (d->Info->Nation() == Kingdom::null)
			Return(r, err_no_join_kingdom);
		if (d->LV() < WorldBoss::LvLimit)
			Return(r, err_lv_not_enough);

		if (_state == WorldBoss::Opened)
			Return(r, err_illedge);

		r[strMsg][1u] = _reward_info[d->Info->Nation()];
		d->WorldBoss->getRewardInfo(r[strMsg][1u]);

		Return(r, res_sucess);
	}

	int worldboss_system::fightBoss(playerDataPtr d)
	{
		sBattlePtr atk = BattleHelp::WarPlayer(d);
		addPlayerAttr(d, atk);
		BattleReportData reportData;
		O2ORes resultB = battle_sys.One2One(reportData, atk, _boss_ptr, typeBattle::world_boss);
		doneBattle(reportData, d);
		if (!_20hp_broadcast && (double)_total_hp / (double)_max_hp <= 0.2)
		{
			_20hp_broadcast = true;
			worldBossBroadcast(-1, 11, _type == 0? 1 : 0, "", "", "", "");
		}

		if (_total_hp <= 0)
		{
			_helper._kill_pid = d->ID();
			TaskMgr::update(d, Task::WorldBossLastShotTimes, 1);
			tickClose(Common::gameTime());
			worldBossBroadcast(-1, 9, "", "", "", "", "");
			worldBossBroadcast(-1, 10, chat_sys.ChatPackage(d), _helper._last_reward, "", "", "");
		}
		else
		{
			saveCurrentInfo();	
		}
		d->Daily->tickTask(DAILY::world_boss);
		return res_sucess;
	}

	void worldboss_system::addPlayerAttr(playerDataPtr d, sBattlePtr ptr)
	{
		int buff = _config.getIncentBuff(WorldBoss::PersonType, d->WorldBoss->getIncentNum());
		buff += _config.getIncentBuff(WorldBoss::KingdomType, _incent_num[d->Info->Nation()]);
		buff += _config.getWeakBuff(_nation_list.getRank(d->Info->Nation()));
		buff += _config.getDamageBuff(_buff_id);

		ForEach(manList, it, ptr->battleMan)
		{
			(*it)->battleAttri[idx_phyHurtRate] += buff;
			(*it)->battleAttri[idx_warHurtRate] += buff;
			(*it)->battleAttri[idx_magicHurtRate] += buff;
		}
	}

	void worldboss_system::tickOpen(unsigned tick_time)
	{
		if (_state == WorldBoss::Closed)
		{
			int season = season_sys.getSeason(tick_time);
			int type = (season == SEASON::Summer || season == SEASON::Winter)? 1 : 0;
			_next_tick_time = tick_time + WorldBoss::CloseTime - WorldBoss::OpenTime;
			Timer::AddEventTickTime(boostBind(worldboss_system::tickClose, this, _next_tick_time), Inter::event_world_boss_timer, _next_tick_time);
			//Timer2::add(_next_tick_time, boostBind(worldboss_system::tickClose, this, _next_tick_time));
			
			{
				_map_id = getNewMapId(type, _prev_info.getMapId(type), _prev_info.getKillTime(type));
				Log(DBLOG::strLogWorldBoss, 6, tick_time, season, _prev_info.getMapId(type), _map_id);
				_tick_time = tick_time;
				_tick_day = Common::timeZero(tick_time);
				_state = WorldBoss::Opened;
				_rep_id = 0;
				_buff_id = 0;
				_report_mgr.clear();
				for (unsigned i = 0; i < Kingdom::nation_num; ++i)
					_incent_num[i] = 0;

				createBoss(true);
				_20hp_broadcast = false;
			}
			{
				_rank_list.clear();
				_nation_list.clear();
			}

			saveCurrentInfo();

			updateState();
		}
	}

	void worldboss_system::tickClose(unsigned tick_time)
	{
		if (_state == WorldBoss::Opened)
		{
			int season = season_sys.getSeason(tick_time);
			int type = (season == SEASON::Summer || season == SEASON::Winter)? 1 : 0;

			{
				_state = WorldBoss::Closed;
				_tick_time = tick_time;
			}
			{
				for (unsigned i = 0; i < Kingdom::nation_num; ++i)
				{
					_helper._nation_reward[i] = getNationReward(_nation_list.getRank(i));
					_helper._kill_reward = getKillReward();
					_helper._last_reward = getLastReward();
					_helper._player_count[i] = 0;
				}
				
				int kill_time = -1;
				if (_total_hp <= 0)
				{
					kill_time = tick_time - (Common::timeZero(tick_time) + WorldBoss::OpenTime); 
					if (kill_time < 10 * MINUTE)
						worldBossBroadcast(-1, 2, _type == 0 ? 1 : 0, "", "", "", "");
					else
						worldBossBroadcast(-1, 3, _type == 0 ? 1 : 0, "", "", "", "");
					worldBossBroadcast(-1, 5, _type == 0 ? 1 : 0, "", "", "", "");
				}
				else
				{
					worldBossBroadcast(-1, 4, _type == 0 ? 1 : 0, "", "", "", "");
				}

				_prev_info.setInfo(_type, _map_id, kill_time);
				_helper._rank = 0;
				_rank_list.run(boostBind(worldboss_system::setRankAndGetReward, this, _1));
				_person_rank = Json::arrayValue;
				_rank_list.getRankInfo(_person_rank);
				_nation_rank = Json::arrayValue;
				_nation_list.getInfo(_nation_rank);
				_ui_info = Json::arrayValue;
				_rank_list.getUIInfo(_ui_info);
				
				for(unsigned i = 0; i < Kingdom::nation_num; ++i)
				{
					_reward_info[i] = Json::nullValue;
					int rk = _nation_list.getRank(i);
					int damage = _nation_list.getDamage(i);
					_reward_info[i]["nr"] = rk;
					_reward_info[i]["kd"] = damage;
					_reward_info[i]["ks"] = _helper._nation_reward[i];
					_reward_info[i]["pi"] = _helper._kill_pid;
					if (_total_hp <= 0)
					{
						_reward_info[i]["ps"] = _helper._last_reward;
						_reward_info[i]["bs"] = _helper._kill_reward;
					}
					
					Log(DBLOG::strLogWorldBoss, 5, tick_time, season, i, _helper._player_count[i], _nation_list.getDamage(i));
				}

				_helper._kill_pid = -1;
			}
			
			unsigned cur_time = Common::gameTime();
			unsigned cur_time_zero = Common::timeZero(cur_time);
			unsigned cur_day_timestamp = cur_time - cur_time_zero;

			if (_tick_day != cur_time_zero
				&& (cur_day_timestamp >= WorldBoss::OpenTime && cur_day_timestamp < WorldBoss::CloseTime))
			{
				_next_tick_time = cur_time_zero + WorldBoss::OpenTime;
				Timer::AddEventTickTime(boostBind(worldboss_system::tickOpen, this, _next_tick_time), Inter::event_world_boss_timer, _next_tick_time);
				//Timer2::add(_next_tick_time, boostBind(worldboss_system::tickOpen, this, _next_tick_time));
				Timer::AddEventTickTime(boostBind(worldboss_system::resetBoss, this, _next_tick_time - 16 * HOUR), Inter::event_world_boss_timer, _next_tick_time - 16 * HOUR);
				//Timer2::add(_next_tick_time - 16 * HOUR, boostBind(worldboss_system::resetBoss, this, _next_tick_time - 16 * HOUR));
			}
			else
			{
				_next_tick_time = Common::getNextTimeTS(cur_time, WorldBoss::OpenTime);
				Timer::AddEventTickTime(boostBind(worldboss_system::tickOpen, this, _next_tick_time), Inter::event_world_boss_timer, _next_tick_time);
				//Timer2::add(_next_tick_time, boostBind(worldboss_system::tickOpen, this, _next_tick_time));
				Timer::AddEventTickTime(boostBind(worldboss_system::resetBoss, this, _next_tick_time - 16 * HOUR), Inter::event_world_boss_timer, _next_tick_time - 16 * HOUR);
				//Timer2::add(_next_tick_time - 16 * HOUR, boostBind(worldboss_system::resetBoss, this, _next_tick_time - 16 * HOUR));
			}

			saveCurrentInfo();
			saveTermInfo();
			updateState();
		}
	}

	void worldboss_system::doneBattle(BattleReportData& reportData, playerDataPtr d)
	{
		int tmp_hp = _total_hp;
		_total_hp = 0;
		manList& ml = _boss_ptr->battleMan;
		for (unsigned i = 0; i < ml.size(); ++i)
			_total_hp += ml[i]->currentHP;

		int ave = _total_hp / ml.size();
		int left = _total_hp % ml.size();

		for (unsigned i = 0; i < ml.size(); ++i)
		{
			ml[i]->currentHP = ave;
			if (i == 0)
				ml[i]->currentHP += left;
		}

		int damage = tmp_hp - _total_hp;
		double damage_rate = (double)damage / (double)_max_hp;
		int buff_id = _config.getDamageBuffId(damage_rate);
		if (buff_id > _buff_id)
		{
			_buff_id = buff_id;
			worldBossBroadcast(-1, 12, _type == 0? 1 : 0, d->Info->Nation(), chat_sys.ChatPackage(d), _buff_id, (double)_config.getDamageBuff(_buff_id) / 10000.0);
		}
		else
			buff_id = 0;

		std::string rep_id = getRepId();
		_rank_list.update(d, d->WorldBoss->doneBattle(_map_id, damage, buff_id, rep_id));
		_nation_list.addDamage(d->Info->Nation(), damage);

		int silver = getBattleReward(damage);
		d->WorldBoss->addSilver(silver, true);

		WorldBoss::ComReportPtr ptr = Creator<WorldBoss::ComReport>::Create(damage, _map_id, buff_id, rep_id, d->ID(), d->Name());
		_report_mgr.push(ptr);

		reportData.addNotice(d->ID());
		reportData.addReportdeclare("ah", damage);
		reportData.addReportdeclare("sr", silver);
		reportData.addReportdeclare("bn", _map_id);
		reportData.addReportdeclare("bg", _bg_id);

		std::string path = "worldBoss/" + rep_id;
		reportData.addCopyField(path);
		reportData.Done(typeBattle::world_boss);
		
		_param["sr"] = silver;
		_param["ah"] = damage;
	}

	void worldboss_system::loadFile()
	{
		_config.init();
	}

	void worldboss_system::loadDB()
	{
		mongo::BSONObj key = BSON("key" << "term");
		mongo::BSONObj obj = db_mgr.FindOne(DBN::dbWorldBoss, key);
		if (!obj.isEmpty())
		{
			checkNotEoo(obj["pr"])
				_person_rank = Common::string2json(obj["pr"].String());

			checkNotEoo(obj["nr"])
				_nation_rank = Common::string2json(obj["nr"].String());

			checkNotEoo(obj["ri"])
			{
				std::vector<mongo::BSONElement> ele = obj["ri"].Array();
				for (unsigned i = 0; i < ele.size(); ++i)
					_reward_info[i] = Common::string2json(ele[i].String());
			}

			checkNotEoo(obj["pv"])
				_prev_info.load(obj["pv"]);
			
			checkNotEoo(obj["ui"])
				_ui_info = Common::string2json(obj["ui"].String());
		}

		key = BSON("key" << "state");
		obj = db_mgr.FindOne(DBN::dbWorldBoss, key);

		if (!obj.isEmpty())
		{
			_map_id = obj["mi"].Int();
			_max_hp = obj["mh"].Int();
			_rep_id = obj["ri"].Int();
			_buff_id = obj["bf"].Int();
			_report_mgr.load(obj["rl"]);

			_state = obj["st"].Int();
			_tick_time = obj["tt"].Int();
			_tick_day = Common::timeZero(_tick_time);
			_total_hp = obj["hp"].Int();

			{
				std::vector<mongo::BSONElement> ele = obj["in"].Array();
				for (unsigned i = 0; i < ele.size(); ++i)
					_incent_num[i] = ele[i].Int();
			}

			{
				std::vector<mongo::BSONElement> ele = obj["nm"].Array();
				for(unsigned i = 0; i < ele.size(); ++i)
				{
					std::vector<mongo::BSONElement> eles = ele[i].Array();
					for(unsigned j = 0; j < eles.size(); ++j)
						_incent_names[i].push_back(eles[j].String());
				}
			}
		}
		
		loadRankList();
		initState();
	}

	void worldboss_system::createReportDir()
	{
		Common::createDirectories("./report/worldBoss/");
	}

	void worldboss_system::initState()
	{
		if (_state == WorldBoss::Opened)
		{
			createBoss(false);
			
			_next_tick_time = _tick_time + WorldBoss::CloseTime - WorldBoss::OpenTime;
			Timer::AddEventTickTime(boostBind(worldboss_system::tickClose, this, _next_tick_time), Inter::event_world_boss_timer, _next_tick_time);
			//Timer2::add(_next_tick_time, boostBind(worldboss_system::tickClose, this, _next_tick_time));
		}
		else
		{
			unsigned cur_time = Common::gameTime();
			unsigned cur_time_zero = Common::timeZero(cur_time);
			unsigned cur_day_timestamp = cur_time - cur_time_zero;

			if (cur_time_zero != _tick_day 
				&& (cur_day_timestamp >= WorldBoss::OpenTime && cur_day_timestamp < WorldBoss::CloseTime))
			{
				_next_tick_time = cur_time_zero + WorldBoss::OpenTime;
				Timer::AddEventTickTime(boostBind(worldboss_system::tickOpen, this, _next_tick_time), Inter::event_world_boss_timer, _next_tick_time);
				//Timer2::add(_next_tick_time, boostBind(worldboss_system::tickOpen, this, _next_tick_time));
			}
			else
			{
				_next_tick_time = Common::getNextTimeTS(cur_time, WorldBoss::OpenTime);
				Timer::AddEventTickTime(boostBind(worldboss_system::tickOpen, this, _next_tick_time), Inter::event_world_boss_timer, _next_tick_time);
				//Timer2::add(_next_tick_time, boostBind(worldboss_system::tickOpen, this, _next_tick_time));
			}

			if (cur_day_timestamp >= 5 * HOUR && cur_day_timestamp < WorldBoss::OpenTime)
				resetBoss(cur_day_timestamp + 5 * HOUR);
		}
	}

	void worldboss_system::createBoss(bool reset)
	{
		_season = season_sys.getSeason(_tick_time);
		_type = (_season == SEASON::Summer || _season == SEASON::Winter)? 1 : 0;
		_bg_id = _config.getBgId(_type, _map_id);
		_boss_ptr = _config.getBattlePtr(_type, _map_id);
		manList& ml = _boss_ptr->battleMan;
		if (reset)
		{
			_max_hp = 0;
			_total_hp = 0;

			for (unsigned i = 0; i < ml.size(); ++i)
			{
				_total_hp += ml[i]->currentHP;
				_max_hp += ml[i]->currentHP;
			}
		}
		else
		{
			int ave = _total_hp / ml.size();
			int left = _total_hp % ml.size();
			for (unsigned i = 0; i < ml.size(); ++i)
			{
				ml[i]->currentHP = ave;
				if (i == 0)
					ml[i]->currentHP += left;
			}
		}
	}

	int worldboss_system::getNewMapId(int type, int map_id, int kill_time)
	{
		int min_id = _config.getMinMapId(type);
		int max_id = _config.getMaxMapId(type);

		if (map_id == -1)
			return min_id;
			
		if (kill_time == -1)
			map_id -= 3;
		else if (kill_time <= 3 * MINUTE)
			map_id += 3;
		else if (kill_time < 5 * MINUTE)
			map_id += 2;
		else if (kill_time < 10 * MINUTE)
			map_id += 1;
		else if (kill_time <= 15 * MINUTE)
			map_id -= 1;
		else if (kill_time <= 20 * MINUTE)
			map_id -= 2;

		if (map_id > max_id)
			map_id = max_id;

		if (map_id < min_id)
			map_id = min_id;

		return map_id;
	}

	void worldboss_system::saveCurrentInfo()
	{
		mongo::BSONObj key = BSON("key" << "state");
		mongo::BSONObjBuilder obj;
		obj << "key" << "state" << "mi" << _map_id 
			<< "st" << _state << "ri" << _rep_id
			<< "tt" << _tick_time << "bf" << _buff_id
			<< "mh" << _max_hp << "rl"<< _report_mgr.toBSON()
			<< "hp" << _total_hp;
		{
			mongo::BSONArrayBuilder b;
			for (unsigned i = 0; i < 3; ++i)
				b.append(_incent_num[i]);
			obj << "in" << b.arr();
		}
		{
			mongo::BSONArrayBuilder b;
			for (unsigned i = 0; i < 3; ++i)
			{
				mongo::BSONArrayBuilder b2;
				for (unsigned j = 0; j < _incent_names[i].size(); ++j)
					b2.append(_incent_names[i][j]);
				b.append(b2.arr());
			}
			obj << "nm" << b.arr();
		}
		db_mgr.SaveMongo(DBN::dbWorldBoss, key, obj.obj());
	}

	void worldboss_system::saveTermInfo()
	{
		mongo::BSONObj key = BSON("key" << "term");
		mongo::BSONObjBuilder obj;
		obj << "key" << "term" << "pr" << _person_rank.toIndentString() 
			<< "nr" << _nation_rank.toIndentString()
			<< "ui" << _ui_info.toIndentString() << "pv" << _prev_info.toBSON();
		{
			mongo::BSONArrayBuilder b;
			for(unsigned i = 0; i < Kingdom::nation_num; ++i)
				b.append(_reward_info[i].toIndentString());
			obj << "ri" << b.arr();
		}
		db_mgr.SaveMongo(DBN::dbWorldBoss, key, obj.obj());
	}

	int worldboss_system::getBattleReward(int damage) const
	{
		double per = (double)damage / (double)_max_hp;

		int silver = (1000000 + (_map_id % 100000) * 3000) * per + 1500;
		double rate = _config.getRewardRate(Common::gameTime());

		return (int)(silver * rate);
	}

	int worldboss_system::getKillReward() const
	{
		int silver =  15000 + (_map_id % 100000) * 100;
		if (silver > 30000)
			silver = 30000;
		return silver;
	}

	int worldboss_system::getLastReward() const
	{
		int silver =  50000 + (_map_id % 100000) * 200;
		if (silver > 80000)
			silver = 80000;
		return silver;
	}

	int worldboss_system::getNationReward(int rank) const
	{
		switch(rank)
		{
			case 1:
			{
				int silver = 25000 + (_map_id % 100000) * 200;
				return silver > 50000? 50000 : silver;
			}
			case 2:
			{
				int silver = 20000 + (_map_id % 100000) * 150;
				return silver > 40000? 40000 : silver;
			}
			case 3:
			{
				int silver = 15000 + (_map_id % 100000) * 100;
				return silver > 30000? 30000 : silver;
			}
			default:
				return 0;
		}
	}

	void worldboss_system::loadRankList()
	{
		objCollection objs = db_mgr.Query(DBN::dbPlayerWorldBoss);
		ForEachC(objCollection, it, objs)
		{
			const mongo::BSONObj& obj = (*it);
			if (obj["rd"].Int() != _tick_day)
				continue;

			int pid = obj[strPlayerID].Int();

			playerDataPtr d = player_mgr.getPlayer(pid);
			if (!d) continue;
			if (d->WorldBoss->getDamage() != 0)
			{
				_rank_list.update(d, 0);
				_nation_list.addDamage(d->Info->Nation(), d->WorldBoss->getDamage());
			}
		}
	}

	int worldboss_system::getRank(playerDataPtr d) const
	{
		if (_state == WorldBoss::Opened)
			return _rank_list.getRank(d);
		else
			return d->WorldBoss->getRank();
	}

	void worldboss_system::getUIPlayerList(Json::Value& info)
	{
		if (_state == WorldBoss::Closed)
			info = _ui_info;
		else
			_rank_list.getUIInfo(info);

		if (info.size() < _cache_list.size())
			info = _cache_list;
	}

	void worldboss_system::setRankAndGetReward(const WorldBoss::PlayerInfo& p)
	{
		int rk = ++_helper._rank;
		playerDataPtr d = player_mgr.getPlayer(p.id());
		if (d != playerDataPtr())
		{
			const ACTION::BoxList& box = _config.getRankReward(rk);
			actionDoBox(d, box);
			d->WorldBoss->setRank(rk, actionRes());
			int silver = _helper._nation_reward[d->Info->Nation()];
			if (_helper._kill_pid != -1)
				silver += _helper._kill_reward;
			if (_helper._kill_pid == d->ID())
			{
				silver += _helper._last_reward;
			}
			d->WorldBoss->addSilver(silver);

			if (d->Info->Nation() != Kingdom::null)
				++_helper._player_count[d->Info->Nation()];

			if (rk == 1)
				worldBossBroadcast(-1, 6, chat_sys.ChatPackage(d), d->WorldBoss->getDamage(), (double)d->WorldBoss->getDamage() / (double)_max_hp, actionRes(), "");
			else if (rk == 2)
				worldBossBroadcast(-1, 7, chat_sys.ChatPackage(d), d->WorldBoss->getDamage(), (double)d->WorldBoss->getDamage() / (double)_max_hp, actionRes(), "");
			else if (rk == 3)
				worldBossBroadcast(-1, 8, chat_sys.ChatPackage(d), d->WorldBoss->getDamage(), (double)d->WorldBoss->getDamage() / (double)_max_hp, actionRes(), "");

			Log(DBLOG::strLogWorldBoss, d, 7, _tick_time, _season, d->WorldBoss->getDamage());

			Json::Value param;
			param.append(_type);
			//param.append(_map_id);
			param.append(d->WorldBoss->getTotalRewardInfo());
			param.append(d->WorldBoss->getDamage());
			param.append(d->WorldBoss->getRank());
			EmailPtr e = email_sys.createSystem(EmailDef::WorldBossReward, param);
			email_sys.sendToPlayer(d->ID(), e);
		}
	}

	std::string worldboss_system::getRepId()
	{
		return Common::toString(++_rep_id);
	}

	int worldboss_system::getFaceId(playerDataPtr d)
	{
		std::vector<playerManPtr> man_vec = d->WarFM->currentFM();
		ForEach(std::vector<playerManPtr>, it, man_vec)
		{
			if (*it)
				return (*it)->mID();
		}
		return WorldBoss::DefaultFace; // default id
	}

	int worldboss_system::getIncentNum(playerDataPtr d)
	{
		if (d->Info->Nation() == Kingdom::null)
			return 0;

		return _incent_num[d->Info->Nation()] + d->WorldBoss->getIncentNum();
	}

	int worldboss_system::addKingdomeIncent(playerDataPtr d, int resource)
	{
		int succ = 0;
		int res = d->WorldBoss->checkKingdomIncentLimit(_incent_num[d->Info->Nation()], resource, succ);
		if (res == res_sucess)
		{
			if (succ == 1)
			{
				++_incent_num[d->Info->Nation()];
				_incent_names[d->Info->Nation()].push_back(d->Name());
				saveCurrentInfo();
				worldBossBroadcast(d->Info->Nation(), 13, chat_sys.ChatPackage(d), "", "", "", "");
			}
			
			_param["is"] = succ;
			_param["it"] = (int)WorldBoss::KingdomType;
		}
		return res;
	}


	BattleEquipList worldboss_system::getEquipList(playerDataPtr d)
	{
		std::vector<playerManPtr> man_vec = d->WarFM->currentFM();
		BattleEquipList equip_vec;
		ForEach(std::vector<playerManPtr>, it, man_vec)
		{
			if (!*it) continue;
			std::vector<itemPtr> equipList = (*it)->getEquipList();
			for (unsigned pos = 0; pos < equipList.size(); ++pos)
			{
				itemPtr item = equipList[pos];
				if (!item) continue;
				equip_vec.push_back(BattleEquip(pos, item->itemID(), item->getLv()));
			}
			break;
		}
		return equip_vec;
	}

	void worldboss_system::resetBoss(unsigned tick_time)
	{
		int season = season_sys.getSeason(tick_time);
		int type = (season == SEASON::Summer || season == SEASON::Winter)? 1 : 0;
		_map_id = getNewMapId(type, _prev_info.getMapId(type), _prev_info.getKillTime(type));
		_buff_id = 0;
		sBattlePtr boss_ptr = _config.getBattlePtr(type, _map_id);
		manList& ml = boss_ptr->battleMan;
		_max_hp = 0;
		_total_hp = 0;

		for (unsigned i = 0; i < ml.size(); ++i)
		{
			_total_hp += ml[i]->currentHP;
			_max_hp += ml[i]->currentHP;
		}
	}

	void worldboss_system::testBroadcast(playerDataPtr d)
	{
		Json::Value res;
		Json::Value tmp;
		tmp.append(1);
		tmp.append(1000);
		res.append(tmp);

		worldBossBroadcast(-1, 0, 0, "", "", "", "");
		worldBossBroadcast(-1, 1, 0, "", "", "", "");
		worldBossBroadcast(-1, 2, 0, "", "", "", "");
		worldBossBroadcast(-1, 3, 0, "", "", "", "");
		worldBossBroadcast(-1, 4, 0, "", "", "", "");
		worldBossBroadcast(-1, 5, 0, "", "", "", "");
		worldBossBroadcast(-1, 6, chat_sys.ChatPackage(d), 1000, 0.1, res, "");
		worldBossBroadcast(-1, 7, chat_sys.ChatPackage(d), 1000, 0.1, res, "");
		worldBossBroadcast(-1, 8, chat_sys.ChatPackage(d), 1000, 0.1, res, "");
		worldBossBroadcast(-1, 9, "", "", "", "", "");
		worldBossBroadcast(-1, 10, chat_sys.ChatPackage(d), 1000, "", "", "");
		worldBossBroadcast(-1, 11, 0, "", "", "", "");
		worldBossBroadcast(-1, 12, 0, d->Info->Nation(), chat_sys.ChatPackage(d), 1, 0.1);
		worldBossBroadcast(d->Info->Nation(), 13, chat_sys.ChatPackage(d), "", "", "", "");
	}

	void worldboss_system::setComingBroadcastTimer()
	{
		unsigned next_tick_time = Common::getNextTimeHMS(Common::gameTime(), 20, 30, 0);
		Timer::AddEventPerTimeCT(boostBind(worldboss_system::bossComingBroadcast, this), Inter::event_world_boss_timer, next_tick_time, DAY);
	}

	void worldboss_system::setOpenBroadcastTimer()
	{
		unsigned next_tick_time = Common::getNextTimeHMS(Common::gameTime(), 21, 0, 0);
		Timer::AddEventPerTimeCT(boostBind(worldboss_system::bossOpenBroadcast, this), Inter::event_world_boss_timer, next_tick_time, DAY);
	}

	void worldboss_system::bossComingBroadcast()
	{
		int season = season_sys.getSeason(Common::gameTime());
		int type = 1;
		if (season == SEASON::Summer || season == SEASON::Winter)
			type = 0;
		worldBossBroadcast(-1, 0, type, "", "", "", "");
	}

	void worldboss_system::bossOpenBroadcast()
	{
		int season = season_sys.getSeason(Common::gameTime());
		int type = 1;
		if (season == SEASON::Summer || season == SEASON::Winter)
			type = 0;
		worldBossBroadcast(-1, 1, type, "", "", "", "");
	}

	double worldboss_system::getDamageRate(unsigned damage)
	{
		return (double)damage / (double)_max_hp;
	}

	void worldboss_system::setBroadcastTimer14()
	{
		unsigned next_tick_time;
		next_tick_time = Common::getNextTimeHMS(Common::gameTime(), 20, 55, 0);
		Timer::AddEventPerTimeCT(boostBind(worldboss_system::bossBroadcast14, this), Inter::event_world_boss_timer, next_tick_time, DAY);
		next_tick_time = Common::getNextTimeHMS(Common::gameTime(), 20, 56, 30);
		Timer::AddEventPerTimeCT(boostBind(worldboss_system::bossBroadcast14, this), Inter::event_world_boss_timer, next_tick_time, DAY);
	}

	void worldboss_system::bossBroadcast14()
	{
		int season = season_sys.getSeason(Common::gameTime());
		int type = 1;
		if (season == SEASON::Summer || season == SEASON::Winter)
			type = 0;
		Json::Value roll_msg;
		roll_msg.append(14);
		roll_msg.append(type);
		Json::Value extra_json;
		extra_json["weight"] = 0;
		extra_json["roll"] = 2;
		chat_sys.despatchAllSP(CHAT::server_worldboss_state, roll_msg, extra_json, CHATPOS::scroll_bar_top);
	}

	void worldboss_system::setBroadcastTimer15()
	{
		unsigned next_tick_time;
		next_tick_time = Common::getNextTimeHMS(Common::gameTime(), 20, 59, 55);
		Timer::AddEventPerTimeCT(boostBind(worldboss_system::bossBroadcast15, this), Inter::event_world_boss_timer, next_tick_time, DAY);
		next_tick_time = Common::getNextTimeHMS(Common::gameTime(), 21, 1, 55);
		Timer::AddEventPerTimeCT(boostBind(worldboss_system::bossBroadcast15, this), Inter::event_world_boss_timer, next_tick_time, DAY);
		next_tick_time = Common::getNextTimeHMS(Common::gameTime(), 21, 3, 55);
		Timer::AddEventPerTimeCT(boostBind(worldboss_system::bossBroadcast15, this), Inter::event_world_boss_timer, next_tick_time, DAY);
		next_tick_time = Common::getNextTimeHMS(Common::gameTime(), 21, 5, 55);
		Timer::AddEventPerTimeCT(boostBind(worldboss_system::bossBroadcast15, this), Inter::event_world_boss_timer, next_tick_time, DAY);
		next_tick_time = Common::getNextTimeHMS(Common::gameTime(), 21, 7, 55);
		Timer::AddEventPerTimeCT(boostBind(worldboss_system::bossBroadcast15, this), Inter::event_world_boss_timer, next_tick_time, DAY);
	}

	void worldboss_system::bossBroadcast15()
	{
		int season = season_sys.getSeason(Common::gameTime());
		int type = 1;
		if (season == SEASON::Summer || season == SEASON::Winter)
			type = 0;
		Json::Value roll_msg;
		roll_msg.append(15);
		roll_msg.append(type);
		Json::Value extra_json;
		extra_json["weight"] = 0;
		extra_json["roll"] = 2;
		chat_sys.despatchAllSP(CHAT::server_worldboss_state, roll_msg, extra_json, CHATPOS::scroll_bar_top);
	}

	void worldboss_system::updateState()
	{
		qValue mm(qJson::qj_object);
		qValue m;
		m.append(res_sucess);
		m.append(_state);
		mm.addMember(strMsg, m);
		player_mgr.sendToAll(gate_client::player_worldboss_red_point_resp, mm);
	}

	void worldboss_system::updateState(playerDataPtr d)
	{
		qValue m;
		m.append(res_sucess);
		m.append(_state);
		d->sendToClientFillMsg(gate_client::player_worldboss_red_point_resp, m);	
	}
}

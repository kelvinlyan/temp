#pragma once

#include "dbDriver.h"
#include "playerManager.h"

namespace gg
{
	namespace WarLords
	{
		enum
		{
			PageSize = 10,
			InitSize = 120,
		};

		struct InitHelpStruct
		{
			bool operator<(const InitHelpStruct& rhs) const
			{
				if (lv == rhs.lv)
					return pid < rhs.pid;
				return lv > rhs.lv;
			}

			int pid;
			int lv;
			int nation;
		};

		struct PlayerInfo
		{
			PlayerInfo(playerDataPtr d);

			inline void getInfo(Json::Value& q) const;

			int pid;
			int face;
			std::string name;
			int lv;
			int cd;
			unsigned power;
			std::vector<int> evil_value;
		};

		SHAREPTR(PlayerInfo, PlayerPtr);

		typedef std::list<PlayerPtr> PlayerList;

		struct OnOffLineList
		{
			PlayerList online;
			PlayerList offline;
		};

		STDVECTOR(OnOffLineList, Lv2List);

		class PlayerListMgr
		{
			public:
				void init(unsigned size);

				void getInfo(int nation, int begin, int end, int page, Json::Value& q) const;
				int getAllPage(int nation, int begin, int end) const;
				int getPageByPid(int nation, int begin, int end, int pid) const;

				void updateLogin(playerDataPtr d);
				void updateLogout(playerDataPtr d);

				void updateLv(playerDataPtr d, int olv);
				void updateName(playerDataPtr d);
				void updateCd(playerDataPtr d);
				void updatePower(playerDataPtr d);
				void updateEvilValue(playerDataPtr d);

			private:
				Lv2List player_list[Kingdom::nation_num];
		};
	}
}

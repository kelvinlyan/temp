//###################################
//create by Jim
//2016-03-03
//###################################

#pragma once

#include "auto_base.h"

namespace gg
{
	class playerTick;
	class playerRescue :
		public _auto_player
	{
		friend class playerTick;
	public:
		playerRescue(playerData* const own);
		~playerRescue(){}
		static void initData();
		virtual void _auto_update();
		int wonReward(const int num);
		
		void loadDB();
	private:
		int getLimit();
		virtual bool _auto_save();
		int rewardNum;//���������õĹ���ֵ
	};
}
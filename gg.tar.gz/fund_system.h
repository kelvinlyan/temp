//###################################
//create by linxing
//2016-06-20
//###################################

#pragma once
#ifndef FUND_SYSTEM
#define FUND_SYSTEM

#include "dbDriver.h"
#include "action_system.h"
#include "fund_config.h"


#define fund_sys (*gg::fund_system::_Instance)

namespace gg
{
	class fund_system
	{
	public:
		fund_system();
		~fund_system();

		DeclareRegFunction(reqFundInfo);
		DeclareRegFunction(reqFundBuy);
		DeclareRegFunction(reqFundGetReward);
	public:
		static fund_system* const _Instance;

	private:
		/// ���齱��id�Ƿ���Ч
		bool isValidFundId(const int& id) const;

	};
}

#endif

#pragma once

#define warlords_sys (*gg::warlords_system::_Instance)

#include "warlords_helper.h"

namespace gg
{
	class warlords_system
	{
		public:
			static warlords_system* const _Instance;

			void initData();

			DeclareRegFunction(playerInfoReq);
			DeclareRegFunction(battleInfoReq);
			DeclareRegFunction(attackReq);
			DeclareRegFunction(reportListReq);
			DeclareRegFunction(tableReq);
			DeclareRegFunction(searchReq);
			DeclareRegFunction(lookUpReq);
			DeclareRegFunction(setMessageReq);
		
			void updatePlayerLv(playerDataPtr d, int old_lv);
			void updatePlayerName(playerDataPtr d);
			void updatePlayerCd(playerDataPtr d);
			void updateLogin(playerDataPtr d);
			void updateLogout(playerDataPtr d);
			void updatePower(playerDataPtr d);
			void updateEvilValue(playerDataPtr d);

			int getTypeByLv(int lv) const;
			int getTitle(unsigned evil_value) const;

			void testBroadcast(playerDataPtr d);

			void npcBattle(playerDataPtr d);

		private:
			void battleBroadcast(const O2ORes& res, playerDataPtr d, playerDataPtr target);
			void getLevelIndex(int type, int& begin, int& end);
			void loadFile();

			int check(playerDataPtr d, playerDataPtr target);
			Json::Value getRobReward(const O2ORes& res, playerDataPtr d, playerDataPtr target);
			Json::Value getSysReward(const O2ORes& res, playerDataPtr d, playerDataPtr target);
			Json::Value sumReward(const Json::Value& rob_reward, const Json::Value& sys_reward);


			void getReward(const O2ORes& res, playerDataPtr d, playerDataPtr target, Json::Value& atk_reward, Json::Value& def_reward, Json::Value& fame_reward);
			void sendEmail(BattleReportData& reportData, const O2ORes& res, playerDataPtr d, playerDataPtr target, const std::string& report, const Json::Value& reward, const Json::Value& fame_reward);
			int getFameReward(int result, playerDataPtr d, playerDataPtr target);

		private:
			typedef std::pair<int, int> BeginEndLevel;
			typedef std::vector<BeginEndLevel> LevelVec; 
			LevelVec level_vec;

			typedef std::vector<int> EvilValue2Type;
			EvilValue2Type evil_type;
			
			WarLords::PlayerListMgr player_list;

			//
			int param1;
			double param2;
			double param3;
	};
}

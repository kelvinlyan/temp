#pragma once
			
#include "dbDriver.h"
#include "kingdomwar_data.h"
#include "kingdomwar_path.h"
#include "kingdomwar_city.h"
#include "kingdomwar_timer.h"

#define kingdomwar_sys (*gg::kingdomwar_system::_Instance)

namespace gg
{
	class kingdomwar_system
		: public KingdomWar::Observer
	{
		public:
			static kingdomwar_system* const _Instance;

			typedef boost::function<void()> Func;
			STDVECTOR(Func, FuncList);

			UNORDERMAP(int, MapDataCfgPtr, MapDataMap);

			kingdomwar_system();

			void initData();

			KingdomWar::CityPtr getCity(int id);
			KingdomWar::PathPtr getPath(int id);
			KingdomWar::CityPtr getMainCity(int nation);
			const ACTION::BoxList& getRankReward(int rank) const;
			MapDataCfgPtr getNpcData(int map_id);
			void addHpDebuff(sBattlePtr ptr, int hp);

			void updateName(playerDataPtr d);
			void updateTitle(playerDataPtr d, int old_title);

			int citySize() const { return _city_list.size(); }
			unsigned next5MinTime() const { return _state->next5MinTime(); }
			unsigned nextClearTime() const { return _state->nextClearTime(); }
			int state() const { return _state->get(); }

			double speedRate() const { return _state->primeState() == KingdomWar::PrimeTime? 2.5 : 1; }
			double supRate() const { return _state->primeState() == KingdomWar::PrimeTime? 10 : 1; }
			double foodRate() const { return _state->primeState() == KingdomWar::PrimeTime? 0.8 : 1; }

			DeclareRegFunction(quitReq);
			DeclareRegFunction(mainInfoReq);
			DeclareRegFunction(moveReq);
			DeclareRegFunction(playerInfoReq);
			DeclareRegFunction(formationReq);
			DeclareRegFunction(setFormationReq);
			DeclareRegFunction(cityBattleInfoReq);
			DeclareRegFunction(retreatReq);
			DeclareRegFunction(reportInfoReq);
			DeclareRegFunction(rankInfoReq);
			DeclareRegFunction(buyHpItemReq);
			DeclareRegFunction(useHpItemReq);
			DeclareRegFunction(outputInfoReq);
			DeclareRegFunction(getOutputReq);
			DeclareRegFunction(signGatherReq);
			DeclareRegFunction(armyInfoReq);
			DeclareRegFunction(changeFormationReq);
			DeclareRegFunction(militaryInfoReq);
			DeclareRegFunction(playerListReq);
			DeclareRegFunction(upManHpCostReq);
			DeclareRegFunction(upManHpReq);
			DeclareRegFunction(lookUpPlayerReq);
			
			void getMainInfo(qValue& q);
			void mainInfo();
			void mainInfo(playerDataPtr d);
			virtual void tick();

			void goBackMainCity(unsigned time, playerDataPtr d, int army_id, int reason);

			void addTimer(unsigned tick_time, const KingdomWar::Timer::TickFunc& func);
			void addUpdater(const Func& func);
			void add5MinTicker(const Func& func);
			void updateRank(playerDataPtr d, int old_value);

			int getCostTime(int from_id, int to_id);
			int getCityNumOfNation(int nation);
			sBattlePtr getBattlePtr(playerDataPtr d, int army_id, int& max_hp, int& cur_hp);

			const KingdomWar::LineInfo& getLine(int from_id, int to_id) const;

			KingdomWar::NpcDataPtr getNpc(int id);

			int randomNpcID() const;

			int checkStar(int star) const
			{
				if (star < 0)
					star = 0 - star;
				if (star >= _win_hp_cost.size())
					star = 0;
				return star;
			}

			int winHpCost(int star) const { return _win_hp_cost[checkStar(star)]; }
			int loseHpCost(int star) const { return _lose_hp_cost[checkStar(star)]; }
			int winExploit(int star) const { return _win_exploit[checkStar(star)]; }
			int loseExploit(int star) const { return _lose_exploit[checkStar(star)]; }
			inline int hpExploit(int lv, int hp) const;

			void updateHpInfo(playerDataPtr d, int army_id);
			const KingdomWar::HpDebuff& hpDebuff(int hp) const;

			void DoBroadcast(int nation, qValue& m);

		private:
			void loadFile();
			void loadPlayer();
			void loadNpc();
			void startTimer();
			void timerTick();
			void outputTick();
			void addTimer();
			void update();
			void resetRandomRange();
			void tickEvery5Min();
			void tickState();
			void tickClearTime();
			void tickPrimeState();
			void tickUnity(unsigned cur_time);
			void updateSign(int nation);
			void updateSign(playerDataPtr d);

			void loadPathPlayer(KingdomWar::PathPtr& ptr, unsigned time, int pid, int army_id, int to_city_id);
			void loadPathNpc(KingdomWar::PathPtr& ptr, unsigned time, KingdomWar::NpcDataPtr d, int to_city_id);

		private:
			KingdomWar::CityList _city_list;
			KingdomWar::PathList _path_list;
			
			KingdomWar::ShortestPath _shortest_path;
			KingdomWar::RankMgr _rank_mgr;
			KingdomWar::SignList _sign;
			KingdomWar::BuffPtr _kingdom_buff;
			SHAREPTR(KingdomWar::State, StatePtr);
			StatePtr _state;

			FuncList _updaters;
			FuncList _5_min_tickers;

			MapDataMap _npc_map;
			std::vector<KingdomWar::NpcRule> _npc_rule;
			std::vector<ACTION::BoxList> _rank_reward;
			std::vector<int> _win_hp_cost;
			std::vector<int> _lose_hp_cost;
			std::vector<int> _win_exploit;
			std::vector<int> _lose_exploit;
			std::vector<int> _hp_exploit;
			std::vector<KingdomWar::HpDebuff> _hp_debuff;

			int _rand_begin;
			int _rand_end;

			STDMAP(int, KingdomWar::NpcDataPtr, NpcDataMap);
			NpcDataMap _npc_data;
	};

	inline int kingdomwar_system::hpExploit(int lv, int hp) const
	{
		if (lv < 1)
			lv = 1;
		if (lv > _hp_exploit.size())
			lv = _hp_exploit.size();
		return hp / _hp_exploit[lv - 1];
	}
}

#include "task_mgr.h"
#include "days_activity_system.h"
#include "task_system.h"

namespace gg
{
	void TaskMgr::update(playerDataPtr d, int type, int arg1, int arg2)
	{
		task_sys.update(d, type, arg1, arg2);
		days_activity_sys.update(d, type, arg1, arg2);
	}
}

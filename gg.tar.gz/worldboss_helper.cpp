#include "worldboss_helper.h"
#include "worldboss_system.h"
#include "playerData.h"

namespace gg
{
	namespace WorldBoss
	{
		Npc::Npc(const Json::Value& obj)
		{
			_npc_id = obj["npcID"].asInt();
			_hold_morale = obj["holdMorale"].asBool();
			for (unsigned i = 0; i < characterNum; ++i)
				_init_attr[i] = obj["initAttri"][i].asInt();
			_arms_type = obj["armsType"].asInt();
			for (unsigned i = 0; i < armsModulesNum; ++i)
				_arms_module[i] = obj["armsModule"][i].asDouble();
			_npc_level = obj["npcLevel"].asInt();
			_npc_pos = obj["npcPos"].asUInt() % 9;
			_skill_1 = obj["skill_1"].asInt();
			_skill_2 = obj["skill_2"].asInt();
			_battle_value = obj["battleValue"].asInt();
			for (unsigned eq_idx = 0; eq_idx < obj["equip"].size(); ++eq_idx)
			{
				_equip_vec.push_back(BattleEquip(obj["equip"][eq_idx][0u].asUInt(),
							obj["equip"][eq_idx][1u].asInt(),
							obj["equip"][eq_idx][2u].asUInt()));
			}
		}

		Boss::Boss(const Json::Value& obj)
		{
			_map_id = obj["mapId"].asInt();
			_map_name = obj["mapName"].asString();
			_map_level = obj["mapLevel"].asInt();
			_face_id = obj["faceID"].asInt();
			_bg_id = obj["formationBgId"].asInt();
			_battle_value = obj["battleValue"].asInt();
			const Json::Value& army = obj["army"];
			for(unsigned i = 0; i < army.size(); ++i)
				_npc_list.push_back(Npc(army[i]));
		}

		void BossMgr::init()
		{
			_min_map_id_1 = 99999999;
			_min_map_id_2 = 99999999;
			_max_map_id_1 = -1;
			_max_map_id_2 = -1;

			Json::Value json = Common::loadJsonFile("./instance/boss/bossMap1.json");
			for (unsigned i = 0; i < json.size(); ++i)
			{
				BossPtr ptr = Creator<WorldBoss::Boss>::Create(json[i]);
				_boss_map_1.insert(make_pair(ptr->_map_id, ptr));
				if (ptr->_map_id < _min_map_id_1)
					_min_map_id_1 = ptr->_map_id;
				if (ptr->_map_id > _max_map_id_1)
					_max_map_id_1 = ptr->_map_id;
			}

			json = Common::loadJsonFile("./instance/boss/bossMap2.json");
			for (unsigned i = 0; i < json.size(); ++i)
			{
				BossPtr ptr = Creator<WorldBoss::Boss>::Create(json[i]);
				_boss_map_2.insert(make_pair(ptr->_map_id, ptr));
				if (ptr->_map_id < _min_map_id_2)
					_min_map_id_2 = ptr->_map_id;
				if (ptr->_map_id > _max_map_id_2)
					_max_map_id_2 = ptr->_map_id;
			}

			_min_map_hp_1 = 0;
			_min_map_hp_2 = 0;
			sBattlePtr ptr = getBattlePtr(0, _min_map_id_1);
			ForEachC(manList, it, ptr->battleMan)
				_min_map_hp_1 += (*it)->currentHP;
			ptr = getBattlePtr(1, _min_map_id_2);
			ForEachC(manList, it, ptr->battleMan)
				_min_map_hp_2 += (*it)->currentHP;
		}

		sBattlePtr BossMgr::getBattlePtr(int type, int map_id) const
		{
			const BossMap& bm = type == 0? _boss_map_1 : _boss_map_2;
			BossMap::const_iterator it = bm.find(map_id);
			if (it == bm.end())
				return sBattlePtr();

			BossPtr conf = it->second;
			sBattlePtr ptr = Creator<sideBattle>::Create();
			ptr->playerID = conf->_map_id;
			ptr->playerName = conf->_map_name;
			ptr->isPlayer = false;
			ptr->playerFace = conf->_face_id;
			ptr->playerLevel = conf->_map_level;
			ptr->battleValue = conf->_battle_value;
			manList& ml = ptr->battleMan;
			ml.clear();

			for (unsigned i = 0; i < conf->_npc_list.size(); ++i)
			{
				const Npc& npc = conf->_npc_list[i];
				mBattlePtr man = Creator<manBattle>::Create();
				man->manID = npc._npc_id;
				man->holdMorale = npc._hold_morale;
				man->set_skill_1(npc._skill_1);
				man->set_skill_2(npc._skill_2);
				man->armsType = npc._arms_type;
				man->manLevel = npc._npc_level;
				man->currentIdx = npc._npc_pos;
				man->battleValue = npc._battle_value;
				man->equipList = npc._equip_vec;
				memcpy(man->armsModule, npc._arms_module, sizeof(man->armsModule));
				memcpy(man->initialAttri, npc._init_attr, sizeof(man->initialAttri));
				memcpy(man->battleAttri, npc._init_attr, sizeof(man->battleAttri));
				man->currentHP = man->getTotalAttri(idx_hp);
				ml.push_back(man);
			}
			return ptr;
		}

		int BossMgr::getBgId(int type, int map_id) const
		{
			const BossMap& bm = type == 0? _boss_map_1 : _boss_map_2;
			BossMap::const_iterator it = bm.find(map_id);
			if (it == bm.end())
				return 0;
			return it->second->_bg_id;
		}

		RewardRate::Item::Item(const Json::Value& obj)
		{
			_up_time = obj["upInterval"].asUInt();
			_down_time = obj["downInterval"].asUInt();
			_rate = obj["per"].asDouble();
		}

		void RewardRate::init()
		{
			Json::Value json = Common::loadJsonFile("./instance/boss/bossRewardBuff.json");
			for (unsigned i = 0; i < json.size(); ++i)
				_items.push_back(Item(json[i]));
		}

		double RewardRate::getRewardRate(unsigned cur_time) const
		{
			unsigned cur_ts = cur_time - Common::timeZero(cur_time);
			unsigned pass_ts = cur_ts - OpenTime;
			ForEachC(Items, it, _items)
			{
				if (pass_ts <= it->_down_time)
					return it->_rate;
			}
			return 0.0;
		}

		IncentMgr::Item::Item(const Json::Value& obj)
		{
			_need_merit = obj["needMerit"].asInt();
			_need_gold = obj["needGold"].asInt();
			_buff = obj["addper"].asInt();
			_suc_rate = obj["successRate"].asDouble();
		}

		void IncentMgr::init()
		{
			Json::Value json = Common::loadJsonFile("./instance/boss/kingdomIncentive.json");
			for (unsigned i = 0; i < json.size(); ++i)
				_kingdom_incent.push_back(Item(json[i]));

			json = Common::loadJsonFile("./instance/boss/playerIncentive.json");
			for (unsigned i = 0; i < json.size(); ++i)
				_person_incent.push_back(Item(json[i]));
		}

		int IncentMgr::getIncentMaxId(int type) const
		{
			return type == KingdomType?
				_kingdom_incent.size() : _person_incent.size();
		}

		int IncentMgr::getIncentCost(int type, int resource, int id) const
		{
			if (type == KingdomType)
				return resource == UseGold? _kingdom_incent[id]._need_gold : _kingdom_incent[id]._need_merit;
			else
				return resource == UseGold? _person_incent[id]._need_gold : _person_incent[id]._need_merit;
		}

		int IncentMgr::getIncentBuff(int type, int id) const
		{
			if (type == KingdomType)
			{
				if (id == 0 || id > _kingdom_incent.size())
					return 0;
				return _kingdom_incent[id - 1]._buff;
			}
			else
			{
				if (id == 0 || id > _person_incent.size())
					return 0;
				return _person_incent[id - 1]._buff;
			}
		}

		double IncentMgr::getIncentSucRate(int type, int id) const
		{
			if (type == KingdomType)
			{
				if (id < 0 || id >= _kingdom_incent.size())
					return 0.0;
				return _kingdom_incent[id]._suc_rate;
			}
			else
			{
				if (id < 0 || id >= _person_incent.size())
					return 0.0;
				return _person_incent[id]._suc_rate;
			}
		}

		void CleanCdCost::init()
		{
			Json::Value json = Common::loadJsonFile("./instance/boss/cleanCD.json");
			for (unsigned i = 0; i < json.size(); ++i)
				_costs.push_back(json[i]["goldNum"].asInt());
		}

		int CleanCdCost::getCleanCdCost(unsigned times) const
		{
			if (_costs.empty())
				return 0;
			if (times >= _costs.size())
				times = _costs.size() - 1;
			return _costs[times];
		}

		DamageBuff::Item::Item(const Json::Value& obj)
		{
			_buff = obj["incdamageNum"].asInt();
			_hp_rate = obj["damapeHp"].asDouble();
		}

		void DamageBuff::init()
		{
			Json::Value json = Common::loadJsonFile("./instance/boss/damageBuff.json");
			for (unsigned i = 0; i < json.size(); ++i)
				_items.push_back(Item(json[i]));
		}

		int DamageBuff::getDamageBuffId(double damage_rate) const
		{
			for (unsigned i = 0; i < _items.size(); ++i)
			{
				if (damage_rate < _items[i]._hp_rate)
					return i;
			}
			return _items.size();
		}

		int DamageBuff::getDamageBuff(int id) const
		{
			if (id == 0 || id > _items.size())
				return 0;

			return _items[id - 1]._buff;
		}
		
		void WeakBuff::init()
		{
			Json::Value json = Common::loadJsonFile("./instance/boss/kingdomBuff.json");
			_buffs.push_back(0);
			for (unsigned i = 0; i < json.size(); ++i)
				_buffs.push_back(json[i]["incdamageNum"].asInt());
		}

		int WeakBuff::getWeakBuff(int rank) const
		{
			if (rank == 0 || rank > _buffs.size())
				return 0;
				
			return _buffs[rank - 1];
		}

		void RankReward::init()
		{
			Json::Value json = Common::loadJsonFile("./instance/boss/rankReward.json");
			for (unsigned i = 0; i < json.size(); ++i)
				_rank_reward.push_back(actionFormatBox(json[i]));
		}
		
		const ACTION::BoxList& RankReward::getRankReward(int rank) const
		{
			if (rank < 1 || rank > _rank_reward.size())
				rank = _rank_reward.size();
			return _rank_reward[rank - 1];
		}

		void Config::init()
		{
			BossMgr::init();
			IncentMgr::init();
			RewardRate::init();
			CleanCdCost::init();
			DamageBuff::init();
			WeakBuff::init();
			RankReward::init();
		}

		PrevInfo::PrevInfo()
		{
			for(unsigned i = 0; i < 2; ++i)
			{
				_items[i]._map_id = -1;
				_items[i]._kill_time = -1;
			}
		}

		void PrevInfo::load(const mongo::BSONElement& obj)
		{
			std::vector<mongo::BSONElement> ele = obj.Array();
			for(unsigned i = 0; i < ele.size(); ++i)
			{
				_items[i]._map_id = ele[i]["mi"].Int();
				_items[i]._kill_time = ele[i]["kt"].Int();
			}
		}

		mongo::BSONArray PrevInfo::toBSON() const
		{
			mongo::BSONArrayBuilder b;
			for(unsigned i = 0; i < 2; ++i)
				b.append(BSON("mi" << _items[i]._map_id << "kt" << _items[i]._kill_time));
			return b.arr();
		}

		int PrevInfo::getMapId(int type) const
		{
			return _items[type]._map_id;
		}

		int PrevInfo::getKillTime(int type) const
		{
			return _items[type]._kill_time;
		}

		void PrevInfo::setInfo(int type, int map_id, int kill_time)
		{
			_items[type]._map_id = map_id;
			_items[type]._kill_time = kill_time;
		}

		KingdomRank::KingdomRank()
		{
			items.assign(3, Item());
			for (unsigned i = 0; i < Kingdom::nation_num; ++i)
			{
				items[i].nation = i;
				items[i].damage = 0;
				items[i].rate = 0.0;
			}
		}

		void KingdomRank::clear()
		{
			for (unsigned i = 0; i < Kingdom::nation_num; ++i)
			{
				items[i].damage = 0;
				items[i].rate = 0.0;
			}
		}

		void KingdomRank::addDamage(int nation, int damage)
		{
			for (unsigned i = 0; i < Kingdom::nation_num; ++i)
			{
				if (items[i].nation == nation)
				{
					items[i].damage += damage;
					items[i].rate = worldboss_sys.getDamageRate(items[i].damage);
					break;
				}
			}
			
			std::sort(items.begin(), items.end());
		}

		int KingdomRank::getRank(int nation) const
		{
			for (unsigned i = 0; i < Kingdom::nation_num; ++i)
			{
				if (items[i].nation == nation)
					return i + 1;
			}
			return 0;
		}

		int KingdomRank::getDamage(int nation) const
		{
			for (unsigned i = 0; i < Kingdom::nation_num; ++i)
			{
				if (items[i].nation == nation)
					return items[i].damage;
			}
			return 0;
		}

		void KingdomRank::getInfo(Json::Value& info) const
		{
			ForEachC(Items, it, items)
			{
				Json::Value tmp;
				tmp.append(it->nation);
				tmp.append(it->rate);
				info.append(tmp);
			}
		}

		PlayerInfo::PlayerInfo(playerDataPtr d)
			: _pid(d->ID()), _name(d->Name()), _damage(d->WorldBoss->getDamage()), _nation(d->Info->Nation())
		{
			_face = worldboss_sys.getFaceId(d);
			_equip_vec = worldboss_sys.getEquipList(d);
			_rate = worldboss_sys.getDamageRate(_damage);
		}

		void PlayerInfo::getUIInfo(Json::Value& info) const 
		{
			info.append(_pid);
			info.append(_name);
			info.append(_face);
			info.append(_nation);
			Json::Value evv = Json::arrayValue;
			ForEachC(BattleEquipList, it, _equip_vec)
			{
				const BattleEquip& e = *it;
				Json::Value ev;
				ev.append(e.equipPos);
				ev.append(e.equipID);
				ev.append(e.equipLevel);
				evv.append(ev);
			}
			info.append(evv);
		}

		void PlayerInfo::getRankInfo(Json::Value& info) const
		{
			info.append(_pid);
			info.append(_name);
			//info.append(_damage);
			info.append(_rate);
			info.append(_nation);
		}

		void RankList::update(playerDataPtr d, int old_damage)
		{
			_rank_mgr.update(Creator<PlayerInfo>::Create(d), old_damage);
		}

		int RankList::getRank(playerDataPtr d) const
		{
			return _rank_mgr.getRank(d->ID(), d->WorldBoss->getDamage());
		}
		
		void RankList::getUIInfo(Json::Value& info)
		{
			_json = Json::arrayValue;
			_rank_mgr.run(boostBind(RankList::packageUIInfo, this, _1), 0, UISize);
			info = _json;
		}

		void RankList::getRankInfo(Json::Value& info)
		{
			_json = Json::arrayValue;
			_rank_mgr.run(boostBind(RankList::packageRankInfo, this, _1), 0, RankSize);
			info = _json;
		}

		void RankList::clear()
		{
			_rank_mgr.clear();
		}
		
		void RankList::packageUIInfo(const PlayerInfo& p)
		{	
			Json::Value info;
			p.getUIInfo(info);
			_json.append(info);
		}

		void RankList::packageRankInfo(const PlayerInfo& p)
		{
			Json::Value info;
			p.getRankInfo(info);
			_json.append(info);
		}

		void RankList::run(Handler h)
		{
			_rank_mgr.run(h);
		}

		OwnReport::OwnReport(int damage, int map_id, int buff, const std::string& rep_id)
			: _damage(damage), _map_id(map_id), _buff(buff), _rep_id(rep_id)
		{
		}

		OwnReport::OwnReport(const mongo::BSONElement& obj)
		{
			_damage = obj["dm"].Int();
			_map_id = obj["mi"].Int();
			_buff = obj["bf"].Int();
			_rep_id = obj["ri"].String();
		}

		void OwnReport::getInfo(Json::Value& info) const
		{
			info.append(_damage);
			info.append(_map_id);
			info.append(_buff);
			info.append(_rep_id);
		}

		mongo::BSONObj OwnReport::toBSON() const
		{
			return BSON("dm" << _damage << "mi" << _map_id << "bf" << _buff << "ri" << _rep_id);
		}

		ComReport::ComReport(int damage, int map_id, int buff, const std::string& rep_id, int pid, const std::string& name)
			: OwnReport(damage, map_id, buff, rep_id), _pid(pid), _name(name)
		{
		}

		ComReport::ComReport(const mongo::BSONElement& obj)
			: OwnReport(obj)
		{
			_pid = obj["pi"].Int();	
			_name = obj["nm"].String();
		}

		void ComReport::getInfo(Json::Value& info) const
		{
			OwnReport::getInfo(info);
			info.append(_pid);
			info.append(_name);
		}

		mongo::BSONObj ComReport::toBSON() const
		{
			return BSON("dm" << _damage << "mi" << _map_id << "bf" << _buff << "ri" << _rep_id
				<< "pi" << _pid << "nm" << _name);
		}
	}
}

#include "kingdomwar_data.h"
#include "playerManager.h"
#include "kingdomwar_system.h"
#include "net_helper.hpp"
#include "game_time.h"
#include "email_system.h"
#include "kingdom_def.h"
#include "map_war.h"

namespace gg
{
	namespace KingdomWar
	{
		enum
		{
			OpenTime = 9 * HOUR,
			CloseTime = 23 * HOUR,
			PrimeOpenTime = 20 * HOUR + 25 * MINUTE,
			PrimeCloseTime = 20 * HOUR + 55 * MINUTE,

			SignMax = 1,
		};

		RankItem::RankItem(playerDataPtr d)
		{
			_pid = d->ID();
			_name = d->Name();
			_nation = d->Info->Nation();
			_exploit = d->KingDomWar->getExploit();
		}

		void RankItem::getInfo(qValue& q) const
		{
			q.append(_name);
			q.append(_nation);
			q.append(_exploit);
		}

		RankMgr::RankMgr()
		{
		}

		void RankMgr::update(playerDataPtr d, int old_value)
		{
			_rank.update(Creator<RankItem>::Create(d), old_value);
		}

		void RankMgr::getInfo(playerDataPtr d, int begin, int end, qValue& q)
		{
			if (begin < 1 || end < begin)
				return;
			_info.toArray();
			_rk = begin;
			_rank.run(boostBind(RankMgr::packageInfo, this, _1), begin - 1, end - begin + 1);
			q.addMember("l", _info);
			q.addMember("n", _rank.size());
			q.addMember("r", getRank(d));
			q.addMember("e", d->KingDomWar->getExploit());
		}

		int RankMgr::getRank(playerDataPtr d) const
		{
			return _rank.getRank(d->ID(), d->KingDomWar->getExploit());
		}

		void RankMgr::packageInfo(const RankItem& item)
		{
			qValue tmp;
			tmp.append(_rk++);
			item.getInfo(tmp);
			_info.append(tmp);
		}

		void RankMgr::tickRank()
		{
			_rk = 0;
			_rank.run(boostBind(RankMgr::tickRankItem, this, _1));
			_rank.run(boostBind(RankMgr::tickClearItem, this, _1));
			_rank.clear();
		}

		void RankMgr::tickRankItem(const RankItem& item)
		{
			++_rk;
			playerDataPtr d = player_mgr.getPlayer(item.id());
			if (!d) return;

			const ACTION::BoxList& box = kingdomwar_sys.getRankReward(_rk);	
			actionDoBox(d, box);

			Json::Value m;
			m.append(kingdomwar_sys.nextClearTime() - 1);
			m.append(item.value());
			m.append(_rk);
			m.append(actionRes());
			EmailPtr e = email_sys.createSystem(EmailDef::KingdomWarRankReward, m);
			email_sys.sendToPlayer(d->ID(), e);
		}

		void RankMgr::tickClearItem(const RankItem& item)
		{
			playerDataPtr d = player_mgr.getPlayer(item.id());
			if (!d) return;

			d->KingDomWarBox->clear();
			d->KingDomWar->clearExploit();
		}

		State::State()
		{
			_next_5_min_tick_time = 0;
			_state = -1;
			_next_tick_time = 0;
			_next_clear_time = 0;
			_last_prime_state = 0;
			_last_prime_time = 0;
			_prime_state = -1;
			_next_prime_time = 0;
		}

		void State::init()
		{
			mongo::BSONObj key = BSON("ci" << -1);
			mongo::BSONObj obj = db_mgr.FindOne(DBN::dbKingdomWarCityBase, key);
			if (!obj.isEmpty())
			{
				checkNotEoo(obj["5min"])
					_next_5_min_tick_time = obj["5min"].Int();
				checkNotEoo(obj["st"])
					_state = obj["st"].Int();
				checkNotEoo(obj["ntt"])
					_next_tick_time = obj["ntt"].Int();
				checkNotEoo(obj["nct"])
					_next_clear_time = obj["nct"].Int();
				checkNotEoo(obj["lpst"])
					_last_prime_state = obj["lpst"].Int();
				checkNotEoo(obj["lpt"])
					_last_prime_time = obj["lpt"].Int();
				_prime_state = _last_prime_state;
				_next_prime_time = _last_prime_time;
			}

			unsigned cur_time = Common::gameTime();
			unsigned day_time = Common::timeZero(cur_time);
			unsigned day_stamp = cur_time - day_time;
			
			if (_next_5_min_tick_time == 0)
				_next_5_min_tick_time = (day_stamp / (5 * MINUTE) + 1) * (5 * MINUTE) + day_time;
			if (_next_clear_time == 0)
				_next_clear_time = season_sys.getNSTimeHMS(cur_time, SEASON::Spring, 5, 0, 0);
			if (_next_tick_time == 0)
			{
				if (day_stamp < OpenTime)
				{
					_state = Closed;
					_next_tick_time = day_time + OpenTime;
				}
				else if (day_stamp < CloseTime)
				{
					_state = Opened;
					_next_tick_time = day_time + CloseTime;
				}
				else
				{
					_state = Closed;
					_next_tick_time = day_time + OpenTime + DAY;
				}
			}
			
			if (_last_prime_time == 0)
			{
				if (day_stamp < PrimeOpenTime)
				{
					_prime_state = PrimeTime;
					_next_prime_time = day_time - DAY + PrimeCloseTime;
					_last_prime_state = _prime_state;
					_last_prime_time = _next_prime_time;
				}
				else if (day_stamp < PrimeCloseTime)
				{
					_prime_state = OrdinaryTime;
					_next_prime_time = day_time + PrimeOpenTime;
					_last_prime_state = _prime_state;
					_last_prime_time = _next_prime_time;
				}
				else
				{
					_prime_state = PrimeTime;
					_next_prime_time = day_time + PrimeCloseTime;
					_last_prime_state = _prime_state;
					_last_prime_time = _next_prime_time;
				}
			}
		}

		bool State::_auto_save()
		{
			mongo::BSONObj key = BSON("ci" << -1);
			mongo::BSONObjBuilder obj;
			obj << "ci" << -1 << "5min" << _next_5_min_tick_time
				<< "ntt" << _next_tick_time << "nct" << _next_clear_time << "st" << _state
				<< "lpst" << _last_prime_state << "lpt" << _last_prime_time;
			return db_mgr.SaveMongo(DBN::dbKingdomWarCityBase, key, obj.obj());
		}

		void State::reset5MinTime()
		{
			_next_5_min_tick_time += 5 * MINUTE;
			_sign_save();
		}

		void State::resetTickTimeAndState()
		{
			if (_state == Closed)
			{
				_state = Opened;
				_next_tick_time += (CloseTime - OpenTime);
			}
			else
			{
				_state = Closed;
				_next_tick_time = Common::getNextTimeTS(_next_tick_time, OpenTime);
			}
			_sign_save();
		}

		void State::resetClearTime()
		{
			_next_clear_time = season_sys.getNSTimeHMS(_next_clear_time, SEASON::Spring, 5, 0, 0);
			_sign_save();
		}

		void State::resetPrimeTimeAndState()
		{
			_last_prime_state = _prime_state;
			_last_prime_time = _next_prime_time;
			if (_prime_state == PrimeTime)
			{
				_prime_state = OrdinaryTime;
				_next_prime_time = Common::getNextTimeTS(_next_prime_time, PrimeOpenTime);
			}
			else
			{
				_prime_state = PrimeTime;
				_next_prime_time += (PrimeCloseTime - PrimeOpenTime);
			}
			_sign_save();
		}

		Sign::Sign(int nation)
			: _nation(nation)
		{
		}

		void Sign::init(const mongo::BSONObj& obj)
		{
			std::vector<mongo::BSONElement> ele = obj["l"].Array();
			for (unsigned i = 0; i < ele.size(); ++i)
				_id_list.push_back(ele[i].Int());
		}
		
		bool Sign::_auto_save()
		{
			mongo::BSONObj key = BSON("ci" << _nation - 4);
			mongo::BSONObjBuilder obj;
			obj << "ci" << _nation - 4;
			{
				mongo::BSONArrayBuilder b;
				ForEachC(IDList, it, _id_list)
					b.append(*it);
				obj << "l" << b.arr();
			}
			return db_mgr.SaveMongo(DBN::dbKingdomWarCityBase, key, obj.obj());
		}

		int Sign::setSign(playerDataPtr d, int id)
		{
			if (d->KingFight->getTitle() != Kingdom::GuoWang)
				return err_kingdomwar_not_king;

			ForEach(IDList, it, _id_list)
			{
				if ((*it) == id)
				{
					_id_list.erase(it);
					_sign_save();
					return res_sucess;
				}	
			}
			_id_list.clear();
			//if (_id_list.size() >= SignMax)
			//	return err_illedge;
			_id_list.push_back(id);
			Log(DBLOG::strLogKingdomWar, d, 3, id);
			_sign_save();
			return res_sucess;
		}

		void Sign::clear()
		{
			if (!_id_list.empty())
			{
				_id_list.clear();
				_sign_save();
			}
		}

		void Sign::getInfo(qValue& q)
		{
			ForEachC(IDList, it, _id_list)
				q.append(*it);
		}
		
		void SignList::init()
		{
			for (unsigned i = 0; i < Kingdom::nation_num; ++i)
			{
				_sign.push_back(Creator<Sign>::Create(i));
				mongo::BSONObj key = BSON("ci" << i - 4);
				mongo::BSONObj obj = db_mgr.FindOne(DBN::dbKingdomWarCityBase, key);
				if (obj.isEmpty())
					continue;
				_sign[i]->init(obj);
			}
		}

		int SignList::setSign(playerDataPtr d, int id)
		{
			return _sign[d->Info->Nation()]->setSign(d, id);
		}

		void SignList::getInfo(qValue& q, int nation)
		{
			return _sign[nation]->getInfo(q);
		}

		void SignList::clear()
		{
			for (unsigned i = 0; i < Kingdom::nation_num; ++i)
				_sign[i]->clear();
		}

		KingdomBuff::KingdomBuff()
		{
			_buff.assign(Kingdom::nation_num, 0);
		}

		void KingdomBuff::init()
		{
			Json::Value info = Common::loadJsonFile("./instance/kingdom_war/kingdom_buff.json");
			_max = info["max"].asInt();
			_min = info["min"].asInt();
			_add = info["add"].asInt();
			Json::Value& ch = info["change"];
			ForEach(Json::Value, it, ch)
				_change.push_back((*it).asInt());

			mongo::BSONObj key = BSON("ci" << -5);
			mongo::BSONObj obj = db_mgr.FindOne(DBN::dbKingdomWarCityBase, key);
			if (obj.isEmpty())
				return;
			
			std::vector<mongo::BSONElement> ele = obj["b"].Array();
			for (unsigned i = 0; i < ele.size(); ++i)
				_buff[i] = ele[i].Int();
		}

		bool KingdomBuff::_auto_save()
		{
			mongo::BSONObj key = BSON("ci" << -5);
			mongo::BSONObjBuilder obj;
			obj << "ci" << -5;
			{
				mongo::BSONArrayBuilder b;
				for (unsigned i = 0; i < _buff.size(); ++i)
					b.append(_buff[i]);
				obj << "b" << b.arr();
			}
			return db_mgr.SaveMongo(DBN::dbKingdomWarCityBase, key, obj.obj());
		}

		void KingdomBuff::getInfo(qValue& q)
		{
			for (unsigned i = 0; i < _buff.size(); ++i)
				q.append(_buff[i]);
		}

		void KingdomBuff::reset(unsigned tick_time)
		{
			for (unsigned i = 0; i < _buff.size(); ++i)
			{
				int num = kingdomwar_sys.getCityNumOfNation(i);
				int prev = _buff[i];
				_buff[i] += _change[num];
				if (_buff[i] > _max)
					_buff[i] = _max;
				if (_buff[i] < _min)
					_buff[i] = _min;

				Log(DBLOG::strLogKingdomWar, 8, i, tick_time, num, prev, _buff[i]);
			}
			_sign_save();
		}

		int KingdomBuff::getBuff(int nation)
		{
			return _buff[nation] * _add;
		}

		NpcRule::NpcRule(const Json::Value& info)
		{
			_power_begin = info["power_start"].asInt();
			_power_end = info["power_end"].asInt();
			_npc_begin = info["npc_start"].asInt();
			_npc_end = info["npc_end"].asInt();
		}
		
	}
}


#include "player_kingdomwar_shop.h"
#include "kingdomwar_shop.h"

namespace gg
{
	playerKingdomWarShop::playerKingdomWarShop(playerData* const own)
		: _auto_player(own), _flush_times(0), _used_exploit(0)
	{
	}

	void playerKingdomWarShop::loadDB()
	{
		mongo::BSONObj key = BSON(strPlayerID << Own().ID());
		mongo::BSONObj obj = db_mgr.FindOne(DBN::dbPlayerKingdomWarShop, key);
		
		if (obj.isEmpty()) 
			return;

		checkNotEoo(obj["ep"])
			_used_exploit = obj["ep"].Int();
		checkNotEoo(obj["ft"])
			_flush_times = obj["ft"].Int();
		checkNotEoo(obj["sr"])
		{
			std::vector<mongo::BSONElement> ele = obj["sr"].Array();
			for (unsigned i = 0; i < ele.size(); ++i)
				_records.push_back(Record(ele[i]["id"].Int(), ele[i]["bt"].Int()));
		}
	}

	bool playerKingdomWarShop::_auto_save()
	{
		mongo::BSONObj key = BSON(strPlayerID << Own().ID());
		mongo::BSONObjBuilder obj;
		obj << strPlayerID << Own().ID() << "ft" << _flush_times << "ep" << _used_exploit;
		{
			mongo::BSONArrayBuilder b;
			ForEachC(std::vector<Record>, it, _records)
				b.append(BSON("id" << it->_id << "bt" << it->_buy_times));
			obj << "sr" << b.arr();
		}
		return db_mgr.SaveMongo(DBN::dbPlayerKingdomWarShop, key, obj.obj());
	}

	void playerKingdomWarShop::_auto_update()
	{
		update();
	}

	void playerKingdomWarShop::update()
	{
		checkShopRecord();
		
		qValue m;
		m.append(res_sucess);
		qValue sl;
		ForEachC(std::vector<Record>, it, _records)
		{
			qValue tmp;
			tmp.append(it->_id);
			tmp.append(it->_buy_times);
			sl.append(tmp);
		}
		qValue q(qJson::qj_object);
		q.addMember("sl", sl);
		q.addMember("ft", _flush_times);
		m.append(q);
		Own().sendToClientFillMsg(gate_client::kingdom_war_shop_info_resp, m);
	}

	int playerKingdomWarShop::buy(int pos, int id, Json::Value& r)
	{
		if(pos <= 0 || pos > _records.size())
			return err_illedge;

		Record& rcd = _records[pos - 1];
		if (rcd._id != id)
			return err_illedge;

		ShopDataPtr ptr = kingdomwar_shop.getShopData(id);
		if (!ptr)
			return err_illedge;

		if (rcd._buy_times >= ptr->_buy_num)
			return err_goods_sale_out;
		
		if (Own().Res->getExploit() < ptr->_price)
			return err_exploit_coin_not_enough;

		int res = actionDoBox(Own().getOwnDataPtr(), ptr->_box, false);
		if (res == res_sucess)
		{
			r[1u] = id;
			r[2u] = actionRes();
			++rcd._buy_times;
			int tmp = Own().Res->getExploit();
			Own().Res->alterExploit(0 - ptr->_price);
			int cur = Own().Res->getExploit();
			Log(DBLOG::strLogKingdomWar, Own().getOwnDataPtr(), 1, tmp, cur, id);
			_sign_auto();
		}
		else
		{
			Json::Value error_code = actionError();
			res = error_code[0u][1u].asInt();
		}

		return res;
	}

	int playerKingdomWarShop::flush()
	{
		int cost = kingdomwar_shop.getFlushCost(_flush_times);
		if (Own().Res->getCash() < cost)
			return err_gold_not_enough;
		Own().Res->alterCash(0 - cost);
		++_flush_times;
		_records.clear();
		checkShopRecord();
		Log(DBLOG::strLogKingdomWar, Own().getOwnDataPtr(), 2, cost);
		_sign_auto();
		return res_sucess;
	}

	void playerKingdomWarShop::checkShopRecord()
	{
		if (_records.empty())
		{
			ShopDataList shop_list = kingdomwar_shop.getShopList(Own().getOwnDataPtr());
			ForEachC(ShopDataList, it, shop_list)
				_records.push_back(Record((*it)->_id, 0));
			_sign_auto();
		}
	}

	void playerKingdomWarShop::dailyTick()
	{
		_records.clear();
		checkShopRecord();
		_flush_times = 0;
	}

	void playerKingdomWarShop::alterUsedExploit(int num)
	{
		int cur = Own().Res->getExploit();
		if (cur < num)
			num = cur;
		_used_exploit += num;
		_sign_save();
	}
}

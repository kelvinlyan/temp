#include "player_mall.h"
#include "dbDriver.h"

namespace gg
{
	playerMall::playerMall(playerData* const own) :_auto_player(own)
	{
		mapBuy.clear();
	}

	void playerMall::loadDB()
	{
		mapBuy.clear();
		mongo::BSONObj key = BSON(strPlayerID << Own().ID());
		mongo::BSONObj obj = db_mgr.FindOne(DBN::dbPlayerMall, key);
		if (obj.isEmpty())return;
		vector<mongo::BSONElement> vec = obj["arr"].Array();
		for (unsigned i = 0; i < vec.size(); ++i)
		{
			mongo::BSONElement elem = vec[i];
			mapBuy[elem["i"].Int()] = elem["v"].Int();
		}
	}

	void playerMall::_auto_update()
	{
		qValue json(qJson::qj_array);
		for (BUYMAP::const_iterator it = mapBuy.begin(); it != mapBuy.end(); ++it)
		{
			qValue sg_json(qJson::qj_array);
			sg_json.append(it->first);
			sg_json.append(it->second);
			json.append(sg_json);
		}
		qValue data_json(qJson::qj_array);
		data_json.append(res_sucess).append(json);
		Own().sendToClientFillMsg(gate_client::player_mall_info_update_resp, data_json);
	}

	bool playerMall::_auto_save()
	{
		mongo::BSONObj key = BSON(strPlayerID << Own().ID());
		mongo::BSONArrayBuilder arr;
		for (BUYMAP::const_iterator it = mapBuy.begin(); it != mapBuy.end(); ++it)
		{
			arr << BSON("i" << it->first << "v" << it->second);
		}
		mongo::BSONObj obj = BSON(strPlayerID << Own().ID() << "arr" << arr.arr());
		return db_mgr.SaveMongo(DBN::dbPlayerMall, key, obj);
	}

	void playerMall::resetNum()
	{
		mapBuy.clear();
		_sign_auto();
	}

	void playerMall::alterNum(const int goodID, const int val /* = 1 */)
	{
		mapBuy[goodID] += val;
		_sign_auto();
	}

	int playerMall::getNum(const int goodID)
	{
		BUYMAP::iterator it = mapBuy.find(goodID);
		if (it == mapBuy.end())return 0;
		return it->second;
	}
}
#include "search_system.h"
#include "chat.h"

namespace gg
{
	namespace Search
	{
		Config::Config(const Json::Value& info)
		{
			_id = info["id"].asInt();
			_need_time = info["needTime"].asUInt();
			const Json::Value& ref_silver = info["silver"];
			ForEachC(Json::Value, it, ref_silver)
				_silver.push_back(Cost(*it));
			const Json::Value& ref_wood = info["wood"];
			ForEachC(Json::Value, it, ref_wood)
				_wood.push_back(Cost(*it));
			const Json::Value& ref_iron = info["iron"];
			ForEachC(Json::Value, it, ref_iron)
				_iron.push_back(Cost(*it));
			const Json::Value& ref_gold = info["gold"];
			ForEachC(Json::Value, it, ref_gold)
				_gold.push_back(Cost(*it));
			const Json::Value& ref_vip = info["vip"];
			ForEachC(Json::Value, it, ref_vip)
				_vip.push_back((*it).asInt());
			const Json::Value& ref_rw = info["reward"];
			ForEachC(Json::Value, it, ref_rw)
				_reward.push_back(actionFormat((*it).asInt()));
		}

		ShopData::ShopData(Json::Value& info)
		{
			_id = info["id"].asInt();
			_consume_con = info["consumeCon"].asInt();
			_buy_times = info["buynum"].asInt();
			_weight = info["weight"].asInt();
			_kingdom_id = (Kingdom::NATION)info["nation"].asInt();
			_box = actionFormatBox(info["box"]);
		}

		Cost::Cost(const Json::Value& info)
		{
			ForEachC(Json::Value, it, info)
			{
				Times2Cost tmp;
				const Json::Value& c = *it;
				ForEachC(Json::Value, itc, c)
					tmp.push_back((*itc).asInt());
				_lv_cost.push_back(tmp);
			}
		}

		int Cost::get(int lv, int times) const
		{
			if (_lv_cost.empty())
			{
				LogE << "search cost empty" << LogEnd;
				return 0;
			}
			if (lv < 0)
				lv = 0;
			if (lv > _lv_cost.size() - 1)
				lv = _lv_cost.size() - 1;
			const Times2Cost& c = _lv_cost[lv];
			if (c.empty())
			{
				LogE << "search cost empty" << LogEnd;
				return 0;
			}
			if (times < 0)
				times = 0;
			if (times >= c.size())
				times = c.size() - 1;
			return c[times];
		}
	}

	search_system* const search_system::_Instance = new search_system();

	void search_system::initData()
	{
		initialCheck("search.json");
		loadFile();
	}

	void search_system::loadFile()
	{
		Json::Value json = Common::loadJsonFile("./instance/search/search.json");
	
		for (unsigned i = 0; i < json.size(); ++i)
		{
			SearchConfig ptr = Creator<Search::Config>::Create(json[i]);
			_config_map.insert(make_pair(ptr->_id, ptr));
		}

		json = Common::loadJsonFile("./instance/search/shop_cost.json");
		for (unsigned i = 0; i < json.size(); ++i)
			_flush_costs.push_back(json[i].asInt());

		memset(_weight, 0x0, sizeof(_weight));
		json = Common::loadJsonFile("./instance/search/shop.json");
		for (unsigned i = 0; i < json.size(); ++i)
		{
			SearchShopData ptr = Creator<Search::ShopData>::Create(json[i]);
			_shop_map.insert(make_pair(ptr->_id, ptr));
			if (ptr->_weight == 0)
			{
				if (ptr->_kingdom_id != -1)
					_shopFix[ptr->_kingdom_id].push_back(ptr);
				else
				{
					for (unsigned j = 0; j < Kingdom::nation_num; ++j)
						_shopFix[j].push_back(ptr);
					_shopFix[Kingdom::nation_num].push_back(ptr);
				}
			}
			else
			{
				if (ptr->_kingdom_id != -1)
				{
					_shopRd[ptr->_kingdom_id].push_back(ptr);
					_weight[ptr->_kingdom_id] += ptr->_weight;
				}
				else
				{
					for (int j = 0; j < Kingdom::nation_num; ++j)
					{
						_shopRd[j].push_back(ptr);
						_weight[j] += ptr->_weight;
					}
					_shopRd[Kingdom::nation_num].push_back(ptr);
					_weight[Kingdom::nation_num] += ptr->_weight;
				}
			}
		}
	}

	SearchConfig search_system::getConfig(int id)
	{
		SearchConfigMap::iterator it = _config_map.find(id);
		if (it != _config_map.end())
			return it->second;
		return SearchConfig();
	}

	void search_system::getData(net::Msg& m, Json::Value& r)
	{
		playerDataPtr d = player_mgr.getPlayer(m.playerID);
		if (!d)Return(r, err_illedge);

		if (d->LV() < Search::LvLimit)
			Return(r, err_player_lv_too_low);

		d->Sch->update();
	}

	void search_system::searchFor(net::Msg& m, Json::Value& r)
	{
		playerDataPtr d = player_mgr.getPlayer(m.playerID);
		if (!d)Return(r, err_illedge);
		ReadJsonArray;
		int id = js_msg[0u].asInt();
		int type = js_msg[1u].asInt();
		bool batch = js_msg[2u].asBool();
		
		if (d->LV() < Search::LvLimit)
			Return(r, err_player_lv_too_low);
		int res = d->Sch->searchFor(id, type, batch, r[strMsg][1u]);
		if (res == res_sucess)
		{
			//ÈÕ³£
			d->Daily->tickTask(DAILY::player_search, batch? 10 : 1);
		}
		Return(r, res);
	}

	void search_system::getReward(net::Msg& m, Json::Value& r)
	{
		playerDataPtr d = player_mgr.getPlayer(m.playerID);
		if (!d)Return(r, err_illedge);
		if (d->LV() < Search::LvLimit)
			Return(r, err_player_lv_too_low);
		ReadJsonArray;
		int id = js_msg[0u].asInt();
		int res = d->Sch->getReward(id, r[strMsg][1u]);
		if (res == res_sucess)
			beginCheck(d, r[strMsg][1u]);
		Return(r, res);
	}

	void search_system::cancelID(net::Msg& m, Json::Value& r)
	{
		playerDataPtr d = player_mgr.getPlayer(m.playerID);
		if (!d) Return(r, err_illedge);
		if (d->LV() < Search::LvLimit)
			Return(r, err_player_lv_too_low);
		ReadJsonArray;
		int id = js_msg[0u].asInt();
		int res = d->Sch->cleanCd(id);
		Return(r, res);
	}

	void search_system::shopInfo(net::Msg& m, Json::Value& r)
	{
		playerDataPtr d = player_mgr.getPlayer(m.playerID);
		if (!d) Return(r, err_illedge);
		if (d->LV() < Search::LvLimit)
			Return(r, err_player_lv_too_low);
		d->Sch->updateShop();
	}

	void search_system::buy(net::Msg& m, Json::Value& r)
	{
		playerDataPtr d = player_mgr.getPlayer(m.playerID);
		if (!d) Return(r, err_illedge);
		if (d->LV() < Search::LvLimit)
			Return(r, err_player_lv_too_low);
		ReadJsonArray;
		int pos = js_msg[0u].asInt();
		int id = js_msg[1u].asInt();
		int res = d->Sch->buy(pos, id, r[strMsg][1u]);
		Return(r, res);
	}

	void search_system::flush(net::Msg& m, Json::Value& r)
	{
		playerDataPtr d = player_mgr.getPlayer(m.playerID);
		if (!d) Return(r, err_illedge);
		if (d->LV() < Search::LvLimit)
			Return(r, err_player_lv_too_low);
		int res = d->Sch->flush();
		Return(r, res);
	}

	void search_system::onItemBroadcast(playerDataPtr player, const unsigned channel, const Json::Value& info_json)
	{
		Json::Value data_json;
		const int itemID = info_json[1u].asInt();
		data_json.append(chat_sys.ChatPackage(player));
		data_json.append(itemID);
		if (channel == CHAT::chat_all)
		{
			chat_sys.despatchAll(CHAT::server_search_purple, data_json);
		}
		else if (channel == CHAT::chat_kingdom)
		{
			chat_sys.despatchKingdom(CHAT::server_search_ry, player->Info->Nation(), data_json);
		}
	}

	SearchShopData search_system::getShopData(int id)
	{
		SearchShopMap::iterator it = _shop_map.find(id);
		if (it != _shop_map.end())
			return it->second;
		return SearchShopData();
	}

	void search_system::getShopList(int nation, std::vector<int>& id_list)
	{
		if (nation <= Kingdom::null || nation >= Kingdom::nation_num)
			nation = Kingdom::nation_num;

		SearchShopList fix = _shopFix[nation];
		SearchShopList rd = _shopRd[nation];

		unsigned rdNum = 0;
		if (fix.size() < Search::ShopItemCount)
			rdNum = Search::ShopItemCount - fix.size();
		for (unsigned i = 0; i < fix.size(); i++)
		{
			if (i < Search::ShopItemCount)
				id_list.push_back(fix[i]->_id);
		}

		unsigned tmp_total = _weight[nation];
		for (unsigned i = 0; i < rdNum; i++)
		{
			const unsigned rd_num = Common::randomBetween(0, tmp_total - 1);
			unsigned real_num = 0;
			for (unsigned idx = 0; idx < rd.size(); idx++)
			{
				real_num += rd[idx]->_weight;
				if (real_num > rd_num)
				{
					id_list.push_back(rd[idx]->_id);

					tmp_total -= rd[idx]->_weight;
					rd.erase(rd.begin() + idx);
					break;
				}
			}
		}
	}

	int search_system::getFlushCost(unsigned times)
	{
		if (times >= _flush_costs.size())
			times = _flush_costs.size() - 1;
		return _flush_costs[times];
	}
}

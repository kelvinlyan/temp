#include "map_war.h"
#include "skill.h"
#include "man_system.h"
#include "battle_helper.hpp"
#include "broadcast_check.h"
#include "chat.h"
#include "item_system.h"
#include "team_war.h"

namespace gg
{
	map_war* const map_war::_Instance = new map_war();

	const static string chapterDataDirStr = "./instance/chapter/";
	const static std::string strRpChapter = "chapter/";

	static ActionRateMap staticRate;

	const static int sweepItemID = 10001;

	class MapWarCast :
		public actionResCheck
	{
	private:
		virtual void onItemBroadcast(playerDataPtr player, const unsigned channel, const Json::Value& info_json)
		{
			Json::Value data_json;
			data_json.append(chat_sys.ChatPackage(player));
			data_json.append(info_json[1u].asInt());
			if (channel == CHAT::chat_all)
			{
				chat_sys.despatchAll(CHAT::server_war_item_purple, data_json);
			}
			else if (channel == CHAT::chat_kingdom)
			{
				const int itemID = info_json[1u].asInt();
				cfgItemPtr config = item_sys.getConfig(itemID);
				if (config)
				{
					if (config->quality == itemDef::yellow)
					{
						chat_sys.despatchKingdom(CHAT::server_war_item_yellow, player->Info->Nation(), data_json);
					}
					else if (config->quality == itemDef::red)
					{
						chat_sys.despatchKingdom(CHAT::server_war_item_red, player->Info->Nation(), data_json);
					}
				}
			}
		}
		virtual void onManBroadcast(playerDataPtr player, const unsigned channel, const Json::Value& info_json)
		{
			Json::Value data_json;
			data_json.append(info_json[1u].asInt());
			data_json.append(chat_sys.ChatPackage(player));
			if (channel == CHAT::chat_all)
			{
				chat_sys.despatchAll(CHAT::server_war_man_rare, data_json);
			}
			else if (channel == CHAT::chat_kingdom)
			{
				chat_sys.despatchKingdom(CHAT::server_war_man_rare, player->Info->Nation(), data_json);
			}
		}
	};

	static MapWarCast Cast;

	void map_war::initData()
	{
		cout << "load map war system ..." << endl;
		Common::createDirectories(strRpDirRoot + strRpChapter);

		Cast.initialCheck("map_war.json");


		for (unsigned i = 0; i < ACTION::ACTION_NUM;++i)
		{
			staticRate[i] = ACTION::Rate(2.0, 0);
		}

		maxChapterNum = 0;
		// ��ʼ���½�����
		{
			cout << "load " << chapterDataDirStr << endl;
			FileJsonSeq chapterList = Common::loadFileJsonFromDir(chapterDataDirStr);
			for (unsigned i = 0; i < chapterList.size(); ++i)
			{
				Json::Value& chapter = chapterList[i];

				chapterCfgPtr chapterPtr = Creator<chapterConfig>::Create();
				
				chapterPtr->chapterId = chapter["id"].asInt();
				chapterPtr->preChapterId = chapter["preChapterId"].asInt();
				chapterPtr->followChapterId = chapter["followChapterId"].asInt();
				chapterPtr->compltetKeyArmyId = chapter["compltetKeyArmyId"].asInt();
				chapterPtr->firstMpdId = chapter["fistArmyId"].asInt();

				chapterPtr->mapData.clear();

				for (unsigned n = 0; n < chapter["mapData"].size(); ++n)
				{
					Json::Value& chapterMap = chapter["mapData"][n];	

					mapDateCfgPtr mapDatePtr = Creator<mapDataConfig>::Create();

					mapDatePtr->mapId = chapterMap["mapId"].asInt();
					mapDatePtr->frontId = chapterMap["frontId"].asInt();
					mapDatePtr->background = chapterMap.isMember("background") ? chapterMap["background"].asInt() : 1;
					mapDatePtr->chapterID = chapterPtr->chapterId;
					mapDatePtr->faceID = chapterMap["faceID"].asInt();
					mapDatePtr->mapName = chapterMap["mapName"].asString();
					mapDatePtr->mapLevel = chapterMap["mapLevel"].asInt();
					mapDatePtr->battleValue = chapterMap["battleValue"].asInt();
					mapDatePtr->needFood = chapterMap["needfood"].asInt();
					mapDatePtr->needAction = chapterMap["needAction"].asInt();
					mapDatePtr->chanllengeTimes = chapterMap["challengeTimes"].asInt();
					mapDatePtr->manExp = chapterMap["manExp"].asUInt();
					mapDatePtr->levelLimit = chapterMap["levelLimit"].asUInt();
					mapDatePtr->robotIDX = chapterMap["robotIDX"].asInt();
// 					Json::Value& rwJson = chapterMap["winBox"];
// 					mapDatePtr->winBox = actionFormat(rwJson);
					const unsigned rwJsonID = chapterMap["winBox"].asUInt();
					mapDatePtr->winBox = actionFormat(rwJsonID);
					for (unsigned nn = 0; nn < chapterMap["army"].size(); ++nn)
					{
						Json::Value& npcJson = chapterMap["army"][nn];
						armyNPC npc;
						npc.npcID = npcJson["npcID"].asInt();
						npc.holdMorale = npcJson["holdMorale"].asBool();
						for (unsigned cn = 0; cn < characterNum; ++cn)
						{
							npc.initAttri[cn] = npcJson["initAttri"][cn].asInt();
//							npc.addAttri[cn] = npcJson["addAttri"][cn].asInt();
						}
						npc.armsType = npcJson["armsType"].asInt();
						for (unsigned cn = 0; cn < armsModulesNum; ++cn)
						{
							npc.armsModule[cn] = npcJson["armsModule"][cn].asDouble();
						}
						npc.npcLevel = npcJson["npcLevel"].asInt();
						npc.npcPos = npcJson["npcPos"].asUInt() % 9;
						npc.battleValue = npcJson["battleValue"].asInt();
						npc.skill_1 = npcJson["skill_1"].asInt();
						npc.skill_2 = npcJson["skill_2"].asInt();
						for (unsigned eq_idx = 0; eq_idx < npcJson["equip"].size(); ++eq_idx)
						{
							npc.equipList.push_back(BattleEquip(npcJson["equip"][eq_idx][0u].asUInt(),
								npcJson["equip"][eq_idx][1u].asInt(),
								npcJson["equip"][eq_idx][2u].asUInt()));
						}
						mapDatePtr->npcList.push_back(npc);
					}

					if (mapDatePtr->frontId == -1)
					{
						firstMapID = mapDatePtr->mapId;
						minChapterNum = chapterPtr->chapterId;
					}

					chapterPtr->mapData[mapDatePtr->mapId] = mapDatePtr;
					mapChapterID[mapDatePtr->mapId] = chapterPtr->chapterId;
				}

				
				chapterPtr->rewardItemArry.clear();
				for (unsigned n = 0; n < chapter["rewardItemArry"].size(); ++n)
				{
					Json::Value& chapterReward = chapter["rewardItemArry"][n];

					rewardItemCfgPtr rewardItemPtr = Creator<rewardItemConfig>::Create();

					rewardItemPtr->starNum = chapterReward["startNum"].asInt();
// 					Json::Value& rwJson = chapterReward["itemArry"];
// 					rewardItemPtr->ItemArry = actionFormat(rwJson);
					const unsigned rwJsonID = chapterReward["itemArry"].asInt();
					rewardItemPtr->ItemArry = actionFormatBox(rwJsonID);
				
					chapterPtr->rewardItemArry[rewardItemPtr->starNum] = rewardItemPtr;
				}

				mapChapter[chapterPtr->chapterId] = chapterPtr;

				//���ݿ����Ӷ���
				db_mgr.EnsureIndex(DBN::dbPlayerWar + Common::toString(chapterPtr->chapterId), BSON(strPlayerID << 1 ));

				if (maxChapterNum < chapterPtr->chapterId){ maxChapterNum = chapterPtr->chapterId; }

			}
		};
// 		{
// 			//�����¼�
// 			Json::Value speEventJson = Common::loadJsonFile("./instance/specialEvent/specialEvent.json");
// 			for (unsigned i = 0; i < speEventJson.size(); ++i)
// 			{
// 				speEventCfgPtr speEventPtr = Creator<speEventConfig>::Create();
// 				speEventPtr->eventId = speEventJson[i]["id"].asInt();
// 				speEventPtr->limitTime = speEventJson[i]["limitTime"].asInt();
// 				speEventPtr->mapId = speEventJson[i]["mapId"].asInt();
// 				speEventPtr->background = speEventJson[i].isMember("background") ? speEventJson[i]["background"].asInt() : 1;
// 				insertEvent(speEventPtr->mapId, speEventPtr->eventId);
// 				speEventPtr->pro = speEventJson[i]["probability"].asDouble();
// 				speEventPtr->repAct = speEventJson[i]["repAct"].asInt();
// 				speEventPtr->repSuc = speEventJson[i]["repSuc"].asInt();
// 
// 				for (unsigned n = 0; n < speEventJson[i]["cleanMapStar"].size(); n++)
// 				{
// 					speEventPtr->cleanMapStar.push_back(speEventJson[i]["cleanMapStar"][n].asInt());
// 				}
// 
// 				if (!speEventPtr->cleanMapStar.empty())
// 				{
// 					insertEvent(speEventPtr->cleanMapStar[0], speEventPtr->eventId);
// 				}
// 
// 				for (unsigned n = 0; n < speEventJson[i]["manCleanMap"].size(); n++)
// 				{
// 					speEventPtr->manCleanMap.push_back(speEventJson[i]["cleanMapStar"][n].asInt());
// 				}
// 
// 				if (!speEventPtr->manCleanMap.empty())
// 				{
// 					insertEvent(speEventPtr->manCleanMap[0], speEventPtr->eventId);
// 				}
// 
// 				for (unsigned n = 0; n < speEventJson[i]["completeCon"].size(); n++)
// 				{
// 					Json::Value& eventConConfig = speEventJson[i]["completeCon"][n];
// 					completeConCfgPtr objPtr = Creator<completeConConfig>::Create();
// 					objPtr->id = eventConConfig["id"].asInt();
// 					objPtr->commonId = eventConConfig["commonId"].asInt();
// 					objPtr->num = eventConConfig["num"].asInt();
// 					speEventPtr->conList[objPtr->id] = objPtr;
// 				}
// 				mapSpeEvent[speEventPtr->eventId] = speEventPtr;	
// 			}
// 		};
	
// 		{
// 			//�����¼���ͼ
// 			Json::Value speEventMapJson = Common::loadJsonFile("./instance/specialEvent/specialMap.json");
// 			for (unsigned i = 0; i < speEventMapJson.size(); ++i)
// 			{
// 				Json::Value& chapterMap = speEventMapJson[i];
// 
// 				mapDateCfgPtr mapDatePtr = Creator<mapDataConfig>::Create();
// 
// 				mapDatePtr->mapId = chapterMap["mapId"].asInt();
// 				mapDatePtr->frontId = chapterMap["frontId"].asInt();
// 				mapDatePtr->mapName = chapterMap["mapName"].asString();
// 				mapDatePtr->mapLevel = chapterMap["mapLevel"].asInt();
// 				mapDatePtr->needFood = chapterMap["needfood"].asInt();
// 				mapDatePtr->needAction = chapterMap["needAction"].asInt();
// 				mapDatePtr->chanllengeTimes = chapterMap["challengeTimes"].asInt();
// 				mapDatePtr->manExp = chapterMap["manExp"].asUInt();
// // 				Json::Value& rwJson = chapterMap["winBox"];
// // 				mapDatePtr->winBox = actionFormat(rwJson);
// 				const unsigned rwJsonID = chapterMap["winBox"].asUInt();
// 				mapDatePtr->winBox = actionFormat(rwJsonID);
// 				for (unsigned nn = 0; nn < chapterMap["army"].size(); ++nn)
// 				{
// 					Json::Value& npcJson = chapterMap["army"][nn];
// 					armyNPC npc;
// 					npc.npcID = npcJson["npcID"].asInt();
// 					npc.holdMorale = npcJson["holdMorale"].asBool();
// 					for (unsigned cn = 0; cn < characterNum; ++cn)
// 					{
// 						npc.initAttri[cn] = npcJson["initAttri"][cn].asInt();
// //						npc.addAttri[cn] = npcJson["addAttri"][cn].asInt();
// 					}
// 					npc.armsType = npcJson["armsType"].asInt();
// 					for (unsigned cn = 0; cn < armsModulesNum; ++cn)
// 					{
// 						npc.armsModule[cn] = npcJson["armsModule"][cn].asDouble();
// 					}
// 					npc.npcLevel = npcJson["npcLevel"].asInt();
// 					npc.npcPos = npcJson["npcPos"].asUInt() % 9;
// 					npc.battleValue = npcJson["battleValue"].asInt();
// 					npc.skill_1 = npcJson["skill_1"].asInt();
// 					npc.skill_2 = npcJson["skill_2"].asInt();
// 					for (unsigned eq_idx = 0; eq_idx < npcJson["equip"].size(); ++eq_idx)
// 					{
// 						npc.equipList.push_back(BattleEquip(npcJson["equip"][eq_idx][0u].asUInt(),
// 							npcJson["equip"][eq_idx][1u].asInt(),
// 							npcJson["equip"][eq_idx][2u].asUInt()));
// 					}
// 					mapDatePtr->npcList.push_back(npc);
// 				}
// 				speMapData[mapDatePtr->mapId] = mapDatePtr;
// 			}
// 		};

		{
			Json::Value actionVip = Common::loadJsonFile("./instance/vip/reNumVip.json");
			for (unsigned i = 0; i < actionVip.size(); ++i)
			{
				int iVip = actionVip[i]["vip"].asInt();
				int iAction = actionVip[i]["action"].asInt();
				mapVipReNum[iVip] = iAction;
			}
		}

		loadDb();
	}

	void map_war::loadDb()
	{
		objCollection obj = db_mgr.Query(DBN::dbChapterReport);
		if (obj.empty()) return;
		for (objCollection::iterator it = obj.begin(); it != obj.end(); it++)
		{
			mongo::BSONObj obj = (*it);
			int mapId = obj["ci"].Int();
			if (!obj["frp"].eoo())
			{
				reportCfgPtr fPtr = Creator<reportConfig>::Create();
				fPtr->sNum = obj["frp"]["sn"].Int();
				fPtr->rTime = obj["frp"]["rt"].Int();
				fPtr->name = obj["frp"]["nm"].String();
				fPtr->playerNation = (Kingdom::NATION)obj["frp"]["pn"].Int();	
				fPtr->roundNum = obj["frp"]["rn"].Int();
				fPtr->damage = obj["frp"]["dm"].Int();
				fPtr->playerId = obj["frp"]["pi"].Int();
				fPtr->playerLV = obj["frp"]["lv"].Int();


				firstReport[mapId] = fPtr;
			}

			if (!obj["prp"].eoo())
			{
				reportCfgPtr fPtr = Creator<reportConfig>::Create();
				fPtr->sNum = obj["prp"]["sn"].Int();
				fPtr->rTime = obj["prp"]["rt"].Int();
				fPtr->name = obj["prp"]["nm"].String();
				fPtr->playerNation = (Kingdom::NATION)obj["prp"]["pn"].Int();
				fPtr->roundNum = obj["prp"]["rn"].Int();
				fPtr->damage = obj["prp"]["dm"].Int();
				fPtr->playerId = obj["prp"]["pi"].Int();
				fPtr->playerLV = obj["prp"]["lv"].Int();

				perReport[mapId] = fPtr;
			}

			if (!obj["rrp"].eoo())
			{
				vector<mongo::BSONElement> sets = obj["rrp"].Array();

				vector<reportCfgPtr> ptrVector;
				ptrVector.clear();

				for (unsigned i = 0; i < sets.size(); i++)
				{
					reportCfgPtr fPtr = Creator<reportConfig>::Create();
					fPtr->sNum = sets[i]["sn"].Int();
					fPtr->rTime = sets[i]["rt"].Int();
					fPtr->name = sets[i]["nm"].String();
					fPtr->playerNation = (Kingdom::NATION)sets[i]["pn"].Int();
					fPtr->roundNum = sets[i]["rn"].Int();
					fPtr->damage = sets[i]["dm"].Int();
					fPtr->playerId = sets[i]["pi"].Int();
					fPtr->playerLV = sets[i]["lv"].Int();

					ptrVector.push_back(fPtr);
				}

				recentReport[mapId] = ptrVector;
			}
		}

	}

	bool map_war::upateDb(int mapId)
	{
		mongo::BSONObj key = BSON("ci" << mapId);
		mongo::BSONObjBuilder obj;
		obj << "ci" << mapId;

		reportCfgMap::iterator it = firstReport.find(mapId);
		if (it != firstReport.end())
		{
			mongo::BSONObj firstRp = BSON("sn" << it->second->sNum << "rt" << it->second->rTime << "nm" << it->second->name << "lv" << it->second->playerLV << "pn" << it->second->playerNation << "rn" << it->second->roundNum << "dm" << it->second->damage << "pi" << it->second->playerId);
			obj << "frp" << firstRp;
		}

		reportCfgMap::iterator pIt = perReport.find(mapId);
		if (pIt != perReport.end())
		{
			mongo::BSONObj perRp = BSON("sn" << pIt->second->sNum << "rt" << pIt->second->rTime << "nm" << pIt->second->name << "lv" << pIt->second->playerLV << "pn" << pIt->second->playerNation << "rn" << pIt->second->roundNum << "dm" << pIt->second->damage << "pi" << pIt->second->playerId);
			obj << "prp" << perRp;
		}

		mongo::BSONArrayBuilder reRp;
		reportCfgMapVector::iterator rIt = recentReport.find(mapId);
		if (rIt != recentReport.end())
		{
			for (vector<reportCfgPtr>::iterator obIt = rIt->second.begin(); obIt != rIt->second.end(); obIt++)
			{
				mongo::BSONObj obj = BSON("sn" << (*obIt)->sNum << "rt" << (*obIt)->rTime << "nm" << (*obIt)->name << "lv" << (*obIt)->playerLV << "pn" << (*obIt)->playerNation << "rn" << (*obIt)->roundNum << "dm" << (*obIt)->damage << "pi" << (*obIt)->playerId);
				reRp << obj;
			}
		}
		obj << "rrp" << reRp.arr();

		//cout << "map_war_add" << endl;
		return db_mgr.SaveMongo(DBN::dbChapterReport, key, obj.obj());
		
	}

// 	void map_war::insertEvent(int mapId, int eventId)
// 	{
// 		if (chpterEventID[mapId].empty())
// 		{
// 			vector<int> v;
// 			v.clear();
// 			v.push_back(eventId);
// 			chpterEventID[mapId] = v;
// 		}
// 		else
// 		{
// 			chpterEventID[mapId].push_back(eventId);
// 		}
// 	}

	const int map_war::getChapterId(const int mapId)
	{
		boost::unordered_map<int, int>::iterator it = mapChapterID.find(mapId);
		if (it != mapChapterID.end())return it->second;
		return 0;
	}

	const chapterCfgPtr map_war::getConfig(const int chapterId)
	{
		ChapterCfgMap::iterator it = mapChapter.find(chapterId);
		if (it != mapChapter.end())return it->second;
		return chapterCfgPtr();
	}

	const mapDateCfgPtr map_war::getMapConfig(const int mapId)
	{
		int chapterId = getChapterId(mapId);
		if (chapterId == 0) return mapDateCfgPtr();
		chapterCfgPtr chapterPtr = getConfig(chapterId);
		mapDataMap::iterator it = chapterPtr->mapData.find(mapId);
		if (it != chapterPtr->mapData.end()) return it->second;
		return mapDateCfgPtr();
	}
	
// 	const speEventCfgPtr map_war::getSpeEventConfig(const int eventId)
// 	{
// 		speEventCfgMap::iterator it = mapSpeEvent.find(eventId);
// 		if (it != mapSpeEvent.end()) return it->second;
// 		return speEventCfgPtr();
// 	}

// 	const int map_war::getEventChapterId(const int eventId)
// 	{
// 		speEventCfgPtr ptr = getSpeEventConfig(eventId);
// 		if (!ptr) return 0;
// 		int mapId = ptr->mapId;
// 		return getChapterId(mapId);
// 	}

// 	const vector<int> map_war::getEventIDList(const int mapId)
// 	{
// 		boost::unordered_map< int, vector<int> >::iterator it = chpterEventID.find(mapId);
// 		if (it != chpterEventID.end()) return it->second;
// 		vector<int> a;
// 		a.clear();
// 		return a;
// 	}

	const ACTION::BoxList map_war::getChapterRewardList(const int chapterId, const int rewardId)
	{
		chapterCfgPtr ptr = getConfig(chapterId);
		if (!ptr) return ACTION::BoxList();
		rewardItemMap::iterator it = ptr->rewardItemArry.find(rewardId);
		if (it == ptr->rewardItemArry.end()) return ACTION::BoxList();
		return it->second->ItemArry;
	}

	const reportCfgPtr map_war::getFristReport(const int mapId)
	{
		reportCfgMap::iterator it = firstReport.find(mapId);
		if (it != firstReport.end()) return it->second;
		return reportCfgPtr();
	}

	const reportCfgPtr map_war::getPerReport(const int mapId)
	{
		reportCfgMap::iterator it = perReport.find(mapId);
		if (it != perReport.end()) return it->second;
		return reportCfgPtr();
	}

	const vector<reportCfgPtr> map_war::getRecentReport(const int mapId)
	{
		reportCfgMapVector::iterator it = recentReport.find(mapId);
		if (it != recentReport.end()) return it->second;
		vector<reportCfgPtr> a;
		a.clear();
		return a;
	}

	Json::Value map_war::formatJson(reportCfgPtr ptr)
	{
		Json::Value res;
		res["sn"] = ptr->sNum;
		res["rt"] = ptr->rTime;
		res["nm"] = ptr->name;
		res["lv"] = ptr->playerLV;
		res["pn"] = ptr->playerNation;
		//res["rn"] = ptr->roundNum;
		//res["dm"] = ptr->damage;
		//res["pi"] = ptr->playerId;
		return res;
	}


	//�ͻ��˲��� �鿴�½�����
	void map_war::mapDate(net::Msg& m, Json::Value& r)
	{
		ReadJsonArray;
		const int playerID = m.playerID;
		playerDataPtr player = player_mgr.getPlayer(playerID);
		if (!player)Return(r, err_illedge);
		int chId = 0;
		if (js_msg[0u].empty())
		{ 
			chId = player->War->getChId();
		}
		else 
		{ 
			chId = js_msg[0u].asInt(); 
		}
		playerChatperDataPtr chapterData = player->War->getChatperData(chId);
		if (!chapterData) Return(r, err_illedge);
		qValue res_data(qJson::qj_array);
		res_data.append(res_sucess).append(chapterData->formatJson());
		player->sendToClientFillMsg(gate_client::map_war_base_resp, res_data);
	}

	//ս��
	int getDamage(sBattlePtr atk)
	{
		int damage = 0;
		for (manList::iterator it = atk->battleMan.begin(); it != atk->battleMan.end(); it++)
		{
			damage = damage + ((*it)->getTotalAttri(idx_hp) - (*it)->currentHP);
		}
		return damage;
	}

	//����
	bool comp(const reportCfgPtr& a, const reportCfgPtr& b)
	{
		if (a->playerLV != b->playerLV) return a->playerLV < b->playerLV;
		if (a->roundNum != b->roundNum) return a->roundNum < b->roundNum;
		if (a->damage != b->damage) return a->damage < b->damage;
		return true;
	}
	//������������ //ɨ����
	int map_war::checkConSweep(mapDateCfgPtr config, int times, playerDataPtr player)
	{
		int needFood = config->needFood * times;
		int needAction = config->needAction * times;
		if (player->Res->getFood() < needFood) return  err_food_not_enough;
		if (player->Res->getAction() < needAction) return err_action_not_enough;
		times = times < 0 ? 0 : times;
		if (!player->Items->overItem(sweepItemID, (unsigned)times))return err_item_not_enough;
		return res_sucess;
	}
	
	//�۳���������//ɨ����
	void map_war::subConSweep(mapDateCfgPtr config, int times, playerDataPtr player)
	{
		int needFood = config->needFood * times;
		int needAction = config->needAction * times;
		player->Res->alterFood(-needFood);
		player->Res->alterAction(-needAction);
		times = times < 0 ? 0 : times;
		player->Items->removeItem(sweepItemID, (unsigned)times);
	}

	//������������
	int map_war::checkCon(mapDateCfgPtr config, int times, playerDataPtr player)
	{
		int needFood = config->needFood * times;
		int needAction = config->needAction * times;
		if (player->Res->getFood() < needFood) return  err_food_not_enough;
		if (player->Res->getAction() < needAction) return err_action_not_enough;
		return res_sucess;
	}

	//�۳���������
	void map_war::subCon(mapDateCfgPtr config, int times, playerDataPtr player)
	{
		int needFood = config->needFood * times;
		int needAction = config->needAction * times;
		player->Res->alterFood(-needFood);
		player->Res->alterAction(-needAction);
	}

	//���ô���VIp
	int map_war::ReNum(int vipLv)
	{
		MapReNumVipMap::iterator it = mapVipReNum.find(vipLv);
		if (it != mapVipReNum.end()) return it->second;
		return 0;
	}

	//��ս���ߵ�ͼ
	void map_war::challengeMap(mapDateCfgPtr config, playerDataPtr player, Json::Value& r)
	{
		ACTION::BoxList boxes = preToBox(player, config->winBox);
		const int res = actionCheckAvailable(player, boxes);
		if (res != res_sucess)
		{
			r[strMsg][1u] = actionError();
			Return(r, res);
		}
		BattleReportData reportData;
		sBattlePtr atk = BattleHelp::WarPlayer(player);
		sBattlePtr def = npcSide(config);
		O2ORes resultB = battle_sys.One2One(reportData, atk, def, typeBattle::war_story);
		reportData.addNotice(player->ID());//����������
		Json::Value rep_json = config->mapName;
		reportData.addCopyField("last_rep/" + Common::toString(player->ID()));
		reportData.addReportdeclare("bg", config->background);
		Json::Value playerJson;
		playerJson.append(player->LV());
		playerJson.append(player->Info->EXP());
		int actionNum = 0;
		if (player->Info->LV() >= LEVELPRO || (player->Info->LV() < LEVELPRO && resultB.res == resBattle::atk_win))
		{
			subCon(config, 1, player);
			actionNum = config->needAction;
		}

		if (resultB.res == resBattle::atk_win)
		{
			//����
			Json::Value me_json;
			unsigned total_me = BattleHelp::AddManExp(player, config->manExp, me_json);
			const unsigned num = total_me / 100;
			if (num > 0)
			{
				player->Items->addItem(10004, num);
			}
			reportData.addReportdeclare("me", me_json);
			const int ap = player->Research->getResearchData(LAND::idx_home_type_merit);
			setActionRate(ACTION::merit, ACTION::Rate(1.0 + ap / 10000.0));
			actionDoBox(player, boxes);
			Json::Value res_json = actionRes();
			Cast.beginCheck(player, res_json);
			if (num > 0)
			{
				Json::Value exp_book_json;
				exp_book_json.append(ACTION::item);
				exp_book_json.append(10004);
				exp_book_json.append(num);
				res_json.append(exp_book_json);
			}
			if (100103 == config->mapId && !player->War->isChallenge(100103))
			{
				itemVec vec = player->Items->addItem(3004, 1);
				if (vec.size() > 0)
				{
					itemPtr item = vec[0];
					item->setBKReborn(itemDeclare::rb_idx_1, idx_crit, 50);
					item->setBKReborn(itemDeclare::rb_idx_2, idx_block, 50);
					item->replaceUncertainRB(false);
					Json::Value fix_equip_json;
					fix_equip_json.append(ACTION::item);
					fix_equip_json.append(3004);
					fix_equip_json.append(1);
					res_json.append(fix_equip_json);
				}
			}
			reportData.addReportdeclare("wb", res_json);
			playerJson.append(player->LV());
			playerJson.append(player->Info->EXP());
			playerJson.append(actionNum * 10);
			playerJson.append(player->Info->isMaxLevel());
			reportData.addReportdeclare("plv", playerJson);
			unsigned roundNum = reportData.getLastRound();
			int rDamage = getDamage(atk);

			changeRep(reportData, config, player, roundNum, rDamage, resultB.star);
			player->War->changeStart(config->mapId, resultB.star, atk);

			Log(DBLOG::strLogWar, player, 0, config->mapId, resultB.res, 0, 0, 0, 0, 0, res_json.toIndentString());

			//player->War->changeMaxMapId(config->mapId);

			team_war.insertRobot(config->robotIDX, atk);
		}
		else
		{
			Log(DBLOG::strLogWar, player, 0, config->mapId, resultB.res);
		}
		//������������͸��ͻ���
		reportData.Done(typeBattle::war_story);
		//�ճ�
		player->Daily->tickTask(DAILY::war_npc);
		r[strMsg][1u] = resultB.res;
		Return(r, res_sucess);
	}

	//�ͻ��˲��� ��ս��������
	void map_war::challenge(net::Msg& m, Json::Value& r)
	{
		ReadJsonArray;
		const int playerID = m.playerID;
		const int mapId = js_msg[0u].asInt();

		playerDataPtr player = player_mgr.getPlayer(playerID);
		if (!player) Return(r, err_illedge);

		mapDateCfgPtr config = getMapConfig(mapId);
		if (!config) Return(r, err_illedge);

		if (player->LV() < config->levelLimit)Return(r, err_player_lv_too_low);

		int resultR = checkCon(config, 1, player);
		if (resultR != res_sucess) Return(r, resultR);

		int resultC = player->War->chanllenge(mapId);
		if (resultC != res_sucess) Return(r, resultR);

		challengeMap(config, player, r);
	}

	void map_war::getChapterReward(net::Msg& m, Json::Value& r)
	{
		ReadJsonArray;
		const int playerID = m.playerID;
		playerDataPtr player = player_mgr.getPlayer(playerID);
		if (!player)Return(r, err_illedge);
		const int chapterId = js_msg[0u].asInt();
		const int rewardId = js_msg[1u].asInt();
		int res = player->War->getChapterReward(chapterId, rewardId);
		Return(r, res);
	}

	void map_war::getMapStrategy(net::Msg& m, Json::Value& r)
	{
		ReadJsonArray;
		const int playerID = m.playerID;
		playerDataPtr player = player_mgr.getPlayer(playerID);
		if (!player)Return(r, err_illedge);
		const int mapId = js_msg[0u].asInt();

		r[strMsg][1u] = Json::objectValue;
		reportCfgPtr fPtr = getFristReport(mapId);
		if (fPtr) r[strMsg][1u]["fp"] = formatJson(fPtr);

		reportCfgPtr pPtr = getPerReport(mapId);
		if (pPtr) r[strMsg][1u]["pp"] = formatJson(pPtr);

		vector<reportCfgPtr> vectorPtr = getRecentReport(mapId);
		Json::Value rpArry;
		for (vector<reportCfgPtr>::iterator it = vectorPtr.begin(); it != vectorPtr.end(); it++)
		{
			rpArry.append(formatJson(*it));
		}
		if (!rpArry.empty()) r[strMsg][1u]["rp"] = rpArry;
		Return(r, res_sucess);
	}
	
	void map_war::sweepMap(net::Msg& m, Json::Value& r)
	{
		ReadJsonArray;
		const int playerID = m.playerID;
		const int mapId = js_msg[0u].asInt();
		const int sTimes = js_msg[1u].asInt();
		if (sTimes < 1 || sTimes > 10)Return(r, err_illedge);

		playerDataPtr player = player_mgr.getPlayer(playerID);
		if (!player)Return(r, err_illedge);

		mapDateCfgPtr config = getMapConfig(mapId);
		if (!config) Return(r, err_illedge);

		int resultR = checkConSweep(config, sTimes, player);
		if (resultR != res_sucess) Return(r, resultR);

		int rsultS = player->War->sweepMap(mapId, sTimes);
		if (rsultS != res_sucess) Return(r, rsultS);

		subConSweep(config, sTimes, player);
		player->War->subChanllenge(mapId, sTimes);

		//����
		std::vector<playerManPtr> vec = player->WarFM->currentInvaildFM();
	
		Json::Value& rw_json = r[strMsg][1u] = Json::arrayValue;
		for (int i = 0; i < sTimes; ++i)
		{
			int critSeat = 0;

			const int ap = player->Research->getResearchData(LAND::idx_home_type_merit);
			if (Common::randomOk(SWEEP_CRIT))
			{
				ActionRateMap tmpMap = staticRate;
				tmpMap[ACTION::merit].rate += ap / 10000.0;
				setActionRate(tmpMap);
				critSeat = 1;
			}
			else
			{
				setActionRate(ACTION::merit, ACTION::Rate(1.0 + ap / 10000.0));
			}

			actionDo(player, config->winBox);
 			Json::Value rwjson = actionRes();
			Cast.beginCheck(player, rwjson);
			const unsigned add_num = (config->manExp * vec.size()) / 100;
			if (add_num > 0)
			{
				player->Items->addItem(10004, add_num);
				Json::Value exp_book_json;
				exp_book_json.append(ACTION::item);
				exp_book_json.append(10004);
				exp_book_json.append(add_num);
				rwjson.append(exp_book_json);
			}
			if (config->needAction > 0)
			{
				Json::Value exp_json;
				exp_json.append(ACTION::exp);
				exp_json.append(config->needAction * 10);
				rwjson.append(exp_json);
			}
			Json::Value mdJson;
			mdJson["bj"] = critSeat;
			mdJson["rw"] = rwjson;
			rw_json.append(mdJson);

			Log(DBLOG::strLogWar, player, 1, mapId, 2.0, 0, 0, 0, 0, 0, rwjson.toIndentString());
		}
		//�ճ�
		player->Daily->tickTask(DAILY::war_npc, sTimes);
		Return(r, res_sucess);
	}

	//��ս�����¼���ͼ
// 	void	 map_war::challengeEvent(mapDateCfgPtr config, playerDataPtr player, int eventId)
// 	{
// 
// 		sBattlePtr atk = BattleHelp::WarPlayer(player);
// 		sBattlePtr def = npcSide(config);
// 		O2ORes resultB = battle_sys.One2One(atk, def, typeBattle::war_story);
// 		battle_sys.addNotice(player->ID());//����������
// 		battle_sys.addReportdeclare("bg", config->background);
// 
// 		if (resultB.res == resBattle::atk_win)
// 		{
// 			subCon(config, 1, player);
// 			int actionNum = config->needAction;
// 			//����
// 			Json::Value me_json = Json::arrayValue;
// 			BattleHelp::AddManExp(player, config->manExp, me_json);
// 			battle_sys.addReportdeclare("me", me_json);
// 			Json::Value playerJson;
// 			playerJson.append(player->LV());
// 			playerJson.append(player->Info->EXP());
// 			actionDo(player, config->winBox, 1);
// 			Json::Value res_json = actionRes();
// 			battle_sys.addReportdeclare("wb", res_json);
// 			playerJson.append(player->LV());
// 			playerJson.append(player->Info->EXP());
// 			playerJson.append(actionNum * 10);
// 			playerJson.append(player->Info->isMaxLevel());
// 			battle_sys.addReportdeclare("plv", playerJson);
// 
// 			unsigned roundNum = battle_sys.getLastRound();
// 			int rDamage = getDamage(atk);
// 			player->War->FinishEvent(eventId, config->mapId, resultB.res, atk);
// 		}
// 		else
// 		{
// 			int actionNum = 0;
// 			if (player->LV() >= LEVELPRO)
// 			{
// 				subCon(config, 1, player);
// 				actionNum = config->needAction;
// 			}
// 		}
// 		//������������͸��ͻ���
// 		battle_sys.Done(typeBattle::war_story);
// 	}


// 	void map_war::chanllengeEvent(net::Msg& m, Json::Value& r)
// 	{
// 		ReadJsonArray;
// 		const int playerID = m.playerID;
// 		const int mapId = js_msg[0u].asInt();
// 		const int eventId = js_msg[1u].asInt();
// 
// 		playerDataPtr player = player_mgr.getPlayer(playerID);
// 		if (!player)Return(r, err_illedge);
// 
// 		int rsultS = player->War->chanllengeEvent(eventId, mapId);
// 		if (!rsultS) Return(r, err_illedge);
// 
// 		mapDateCfgPtr	 ptr = getSpeMapData(mapId);
// 		if (!ptr) Return(r, err_illedge);
// 
// 		challengeEvent(ptr, player, eventId);
// 
// 		Return(r, res_sucess);
// 	}

	void map_war::reChanllengeAcc(net::Msg& m, Json::Value& r)
	{
		ReadJsonArray;
		const int playerID = m.playerID;
		const int mapId = js_msg[0u].asInt();

		playerDataPtr player = player_mgr.getPlayer(playerID);
		if (!player)Return(r, err_illedge);

		if (player->Res->getCash() < 50) Return(r, err_cash_not_enough);
		int resutRes = player->War->reChanllengeAcc(mapId);
		if (resutRes == res_sucess)
		{
			Log(DBLOG::strLogWar, player, 2, mapId);
			player->Res->alterCash(-50);
		}
		
		Return(r, resutRes);
	}

	sBattlePtr map_war::npcSide(mapDateCfgPtr npcPtr)
	{
		sBattlePtr sb = Creator<sideBattle>::Create();
		sb->playerID = npcPtr->mapId;
		sb->playerName = npcPtr->mapName;
		sb->isPlayer = false;
		sb->playerLevel = npcPtr->mapLevel;
		sb->playerFace = npcPtr->faceID;
		sb->battleValue = npcPtr->battleValue;
		manList& ml = sb->battleMan;
		ml.clear();
		for (unsigned i = 0; i < npcPtr->npcList.size(); i++)
		{
			const armyNPC& npc = npcPtr->npcList[i];
			mBattlePtr man = Creator<manBattle>::Create();
			man->manID = npc.npcID;
			man->holdMorale = npc.holdMorale;
			man->set_skill_1(npc.skill_1);
			man->set_skill_2(npc.skill_2);
			man->armsType = npc.armsType;
			man->manLevel = npc.npcLevel;
			man->currentIdx = npc.npcPos;
			man->battleValue = npc.battleValue;
			memcpy(man->armsModule, npc.armsModule, sizeof(man->armsModule));
			memcpy(man->initialAttri, npc.initAttri, sizeof(man->initialAttri));
			memcpy(man->battleAttri, npc.initAttri, sizeof(man->battleAttri));
			//memcpy(man->battleAttri, npc.addAttri, sizeof(man->battleAttri));
			man->currentHP = man->getTotalAttri(idx_hp);
			man->equipList = npc.equipList;
			ml.push_back(man);
		}
		return sb;
	}

	void map_war::changeRep(BattleReportData& reportData, mapDateCfgPtr config, playerDataPtr player, int roundNum, int rDamage, int starsNum)
	{
		//������ͼ����
		//�״�ͨ��
		bool	updateS = false;
		const int mapId = config->mapId;
		if (!getFristReport(mapId))
		{
			string rPath = strRpChapter + Common::toString(mapId) + "_first";

			reportCfgPtr reportPtr = Creator<reportConfig>::Create();
			reportPtr->name = player->Name();
			reportPtr->playerLV = player->LV();
			reportPtr->playerNation = player->Info->Nation();
			reportPtr->roundNum = roundNum;
			reportPtr->damage = rDamage;
			reportPtr->playerId = player->ID();
			reportPtr->rTime = Common::gameTime();
			firstReport[mapId] = reportPtr;

			reportData.addCopyField(rPath);
			updateS = true;

			//ȫ������
			if ((int)player->LV() + 2 < config->mapLevel)
			{
				qValue data_json(qJson::qj_array);
				data_json.append(chat_sys.ChatPackageQ(player)).
					append(mapId).
					append(config->mapName);
				chat_sys.despatchAll(CHAT::server_war_map_first, data_json);
			}
		}

		//����ͨ��
		if (true)
		{
			string rPath = strRpChapter + Common::toString(mapId) + "_per";
			reportCfgPtr perPTr = getPerReport(mapId);

			reportCfgPtr reportPtr = Creator<reportConfig>::Create();
			reportPtr->name = player->Name();
			reportPtr->playerLV = player->LV();
			reportPtr->playerNation = player->Info->Nation();
			reportPtr->roundNum = roundNum;
			reportPtr->damage = rDamage;
			reportPtr->playerId = player->ID();
			reportPtr->rTime = Common::gameTime();

			if (!perPTr || comp(reportPtr, perPTr))
			{
				perReport[mapId] = reportPtr;
				updateS = true;
			}
			reportData.addCopyField(rPath);
		}

		if (!player->War->isChallenge(mapId))
		{
			reportCfgPtr reportPtr = Creator<reportConfig>::Create();
			reportPtr->name = player->Name();
			reportPtr->playerLV = player->LV();
			reportPtr->playerNation = player->Info->Nation();
			reportPtr->roundNum = roundNum;
			reportPtr->damage = rDamage;
			reportPtr->playerId = player->ID();
			reportPtr->rTime = Common::gameTime();

			if (getRecentReport(mapId).empty())
			{
				vector<reportCfgPtr> vectorPtr;
				vectorPtr.push_back(reportPtr);
				reportPtr->sNum = 1;
				recentReport[mapId] = vectorPtr;
			}
			else
			{
				int sNum = recentReport[mapId].back()->sNum;
				if (sNum == 5) reportPtr->sNum = 1;
				else reportPtr->sNum = sNum + 1;
				recentReport[mapId].push_back(reportPtr);
				if (recentReport[mapId].size() > 5)
				{
					recentReport[mapId].erase(recentReport[mapId].begin());
				}
			}
			updateS = true;
			string rPath = strRpChapter + Common::toString(mapId) + "_" + Common::toString(reportPtr->sNum);
			reportData.addCopyField(rPath);
		}

		if (updateS) upateDb(mapId);
	}
	
// 	mapDateCfgPtr map_war::getSpeMapData(int mapId)
// 	{
// 		mapDataMap::iterator it = speMapData.find(mapId);
// 		if (it != speMapData.end()) return it->second;
// 		return mapDateCfgPtr();
// 	}
}

#include "task_system.h"

namespace gg
{
	TaskConfig::TaskConfig(const Json::Value& info)
	{
		_id = info["id"].asInt();
		_follow_id = info["followId"].asInt();
		_prev_id = -1;
		_open_lv = info["openLv"].asInt();
		_check_ptr = Task::Checker::create(info["condition"]);
		Json::Value reward = info["reward"];
		_reward = actionFormatBox(reward);
	}

	task_system* const task_system::_Instance = new task_system;
	
	task_system::task_system()
	{
	
	}

	void task_system::initData()
	{
		_version_id = 0;
		loadFile();
	}

	void task_system::playerInfoReq(net::Msg& m, Json::Value& r)
	{
		playerDataPtr d = player_mgr.getPlayer(m.playerID);
		if (!d) Return(r, err_illedge);

		d->Task->update();
	}

	void task_system::getRewardReq(net::Msg& m, Json::Value& r)
	{
		playerDataPtr d = player_mgr.getPlayer(m.playerID);
		if (!d) Return(r, err_illedge);

		ReadJsonArray;
		int type = js_msg[0u].asInt();
		int id = js_msg[1u].asInt();
		int res = d->Task->getReward(type, id);
		if (res == res_sucess)
		{
			r[strMsg][1u] = _param;
			_param = Json::nullValue;
		}
		Return(r, res);
	}

	void task_system::redPointReq(net::Msg& m, Json::Value& r)
	{
		playerDataPtr d = player_mgr.getPlayer(m.playerID);
		if (!d) Return(r, err_illedge);

		d->Task->updateRedPoint();
	}

	TaskConfigPtr task_system::getMainTask(int id)
	{
		TaskConfigMap::iterator it = _main_task_map.find(id);
		if (it == _main_task_map.end())
			return TaskConfigPtr();
		return it->second;
	}

	TaskConfigPtr task_system::getBranchTask(int id)
	{
		TaskConfigMap::iterator it = _branch_task_map.find(id);
		if (it == _branch_task_map.end())
			return TaskConfigPtr();
		return it->second;
	}

	void task_system::update(playerDataPtr d, int type, int arg1, int arg2)
	{
		d->Task->updateMain(type, arg1, arg2);
		d->Task->updateBranch(type, arg1, arg2);
	}

	void task_system::loadFile()
	{
		std::string str;
		Json::Value json = Common::loadJsonFile("./instance/task/mainTask.json");
		str += json.toIndentString();
		ForEach(Json::Value, it, json)
			_main_task_map.insert(make_pair((*it)["id"].asInt(), Creator<TaskConfig>::Create(*it)));

		ForEach(TaskConfigMap, it, _main_task_map)
		{
			int follow_id = it->second->_follow_id;
			if (follow_id != -1)
			{
				TaskConfigMap::iterator n_it = _main_task_map.find(follow_id);
				if (n_it != _main_task_map.end())
					n_it->second->_prev_id = it->first;
				else
					LogE << "follow main task " << follow_id << " not found" << LogEnd;
			}
		}

		ForEach(TaskConfigMap, it, _main_task_map)
		{
			if (it->second->_prev_id == -1)
				_main_start_tasks.push_back(it->first);
		}
		
		json = Common::loadJsonFile("./instance/task/branchTask.json");
		str += json.toIndentString();
		ForEach(Json::Value, it, json)
			_branch_task_map.insert(make_pair((*it)["id"].asInt(), Creator<TaskConfig>::Create(*it)));

		ForEach(TaskConfigMap, it, _branch_task_map)
		{
			int follow_id = it->second->_follow_id;
			if (follow_id != -1)
			{
				TaskConfigMap::iterator n_it = _branch_task_map.find(follow_id);
				if (n_it != _branch_task_map.end())
					n_it->second->_prev_id = it->first;
				else
					LogE << "follow branch task " << follow_id << " not found" << LogEnd;
			}
		}

		ForEach(TaskConfigMap, it, _branch_task_map)
		{
			if (it->second->_prev_id == -1)
				_branch_start_tasks.push_back(it->first);
		}

		checkAndUpdateVersion(str);
	}

	void task_system::checkAndUpdateVersion(const std::string& config_str)
	{
		mongo::BSONObj key = BSON("key" << "task");
		mongo::BSONObj obj = db_mgr.FindOne(DBN::dbConfigBackup, key);
		if (obj.isEmpty())
		{
			++_version_id;
			db_mgr.SaveMongo(DBN::dbConfigBackup, key
				, BSON("key" << "task" << "version_id" << _version_id << "value" << config_str));	
			return;
		}

		_version_id = obj["version_id"].Int();

		if (obj["value"].String() != config_str)
		{
			++_version_id;
			db_mgr.SaveMongo(DBN::dbConfigBackup, key
				, BSON("key" << "task" << "version_id" << _version_id << "value" << config_str));	
		}
	}
	
	void task_system::openStartTask(playerDataPtr d)
	{
		ForEach(TaskIdList, it, _main_start_tasks)
			d->Task->openMainTask(*it, true);
		ForEach(TaskIdList, it, _branch_start_tasks)
			d->Task->openBranchTask(*it, true);
	}
	
	void task_system::checkUnopenedTask(playerDataPtr d)
	{
		d->Task->checkUnOpenedTask();
	}

}

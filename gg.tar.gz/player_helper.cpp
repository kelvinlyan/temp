#include "player_helper.h"
#include "playerManager.h"

namespace gg
{
	unsigned getCurrentHp(const sBattlePtr& ptr)
	{
		unsigned hp = 0;
		ForEachC(manList, it, ptr->battleMan)
			hp += (*it)->currentHP;
		return hp;
	}

	unsigned getMaxHp(const sBattlePtr& ptr)
	{
		unsigned hp = 0;
		ForEachC(manList, it, ptr->battleMan)
			hp += (*it)->getTotalAttri(idx_hp);
		return hp;
	}

	int getFirstManID(const ManList& man_list)
	{
		ForEachC(ManList, it, man_list)
		{
			if (*it) 
				return (*it)->mID();
		}
		return 200;
	}

	BattleEquipList getEquipList(const ManList& man_list)
	{
		BattleEquipList equip_list;
		ForEachC(ManList, it, man_list)
		{
			if (!*it) continue;
			std::vector<itemPtr> equipList = (*it)->getEquipList();
			for (unsigned pos = 0; pos < equipList.size(); ++pos)
			{
				itemPtr item = equipList[pos];
				if (!item) continue;
				equip_list.push_back(BattleEquip(pos, item->itemID(), item->getLv()));
				break;
			}
			break;
		}
		return equip_list;
	}

	qValue equipQ(const BattleEquipList& equip_list)
	{
		qValue q;
		ForEachC(BattleEquipList, it, equip_list)
		{
			qValue tmp;
			tmp.append(it->equipPos);
			tmp.append(it->equipID);
			tmp.append(it->equipLevel);
			q.append(tmp);
		}
		return q;
	}
}

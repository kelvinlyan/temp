//###################################
//create by Jim
//2015-11-13
//###################################

#pragma once

#include "dbDriver.h"
#include "skill_def.h"

#define skill_mgr (*gg::skillManager::_Instance)

namespace gg
{

	class skillManager
	{
		SHAREPTR(skillDeclare, SkillPtr);
	public:
		static skillManager* const _Instance;

		void initData();
		const skillDeclare* getSkill(const int ID);
	private:
		typedef boost::unordered_map<int, SkillPtr> skillMap;
		skillMap mapSkill;
	};
}
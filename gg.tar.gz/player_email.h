//###################################
//create by Cai
//2016-04-07
//###################################

#pragma once

#include "auto_base.h"
#include "email.h"

namespace gg
{
	class playerEmail
		: public _auto_player
	{
		public:
			playerEmail(playerData* const own);
			
			void loadDB();
			virtual bool _auto_save();
			virtual void _auto_update();

			Json::Value getEmailList();
			int getPackage(int id);
			void addEmail(EmailPtr& e);
			void addCommonEmail();
			void updateRedPoint(bool check = false);
			std::string getRepId();

		private:
			bool getRedPoint();
			unsigned getId();
			void doAddEmail(const EmailPtr& e);

		private:
			typedef std::deque<EmailPtr> EmailList;

			bool _red_point;
			unsigned _rep_id;
				
			unsigned _owner_email_id;
			unsigned _common_email_id;
			EmailList _email_list[EmailDef::TypeMax];
	};
}

//###################################
//create by Jim
//2016-02-15
//###################################

#pragma once

#include "dbDriver.h"
#include "channel.h"
#include "quickjson.h"

#define chat_sys (*gg::chat_system::_Instance)

namespace gg
{
	namespace CHATPOS
	{
		enum
		{
			chat_windows = (0x0001 << 0),//���촰
			scroll_bar_top = (0x0001 << 1),//����������
			scroll_bar_mid = (0x0001 << 2),//�в�������
		};
	}

	class chat_system
	{
	public:
		static chat_system* const _Instance;
		void initData();

		//��������
		DeclareRegFunction(ChatReq);//����
		//DeclareRegFunction(ShowReq);//չʾ

		//gm����
		DeclareRegFunction(UpdateRollNotice);//��ȡ��������
		DeclareRegFunction(RollNotice);//���ù�������//�滻//����
		DeclareRegFunction(RemoveRollNotice);//���ù�������//ɾ��

		//gm���Դ���
		DeclareRegFunction(gmForbidChat);
		DeclareRegFunction(gmOpenChat);
		DeclareRegFunction(gmSetChatUpdate);

		//json value
		template<typename TYPE>
		bool despatchAllSP(const int senderID, Json::Value& message, TYPE data, const unsigned pos = CHATPOS::chat_windows)
		{
			Json::Value chatReq;
			chatReq[strMsg][0u] = res_sucess;
			chatReq[strMsg][1u] = CHAT::chat_all;
			chatReq[strMsg][2u] = ServerPackage(senderID);
			chatReq[strMsg][3u] = message;
			chatReq[strMsg][4u] = pos;
			chatReq[strMsg][5u] = data;
			return impl_despatchAll(chatReq);
		}
		template<typename TYPE>
		bool despatchKingdomSP(const int senderID, const Kingdom::NATION nation, Json::Value& message, TYPE data, const unsigned pos = CHATPOS::chat_windows)
		{
			Json::Value chatReq;
			chatReq[strMsg][0u] = res_sucess;
			chatReq[strMsg][1u] = CHAT::chat_all;
			chatReq[strMsg][2u] = ServerPackage(senderID);
			chatReq[strMsg][3u] = message;
			chatReq[strMsg][4u] = pos;
			chatReq[strMsg][5u] = data;
			return impl_despatchKingdom(nation, chatReq);
		}
		template<typename TYPE>
		bool despatchPlayerSP(const int senderID, const int playerID, Json::Value& message, TYPE data, const unsigned pos = CHATPOS::chat_windows)
		{
			Json::Value chatReq;
			chatReq[strMsg][0u] = res_sucess;
			chatReq[strMsg][1u] = CHAT::chat_all;
			chatReq[strMsg][2u] = ServerPackage(senderID);
			chatReq[strMsg][3u] = message;
			chatReq[strMsg][4u] = pos;
			chatReq[strMsg][5u] = data;
			return impl_despatchPlayer(playerID, chatReq);
		}
		template<typename TYPE>
		bool despatchPlayerSP(const int senderID, const string playerName, Json::Value& message, TYPE data, const unsigned pos = CHATPOS::chat_windows)
		{
			Json::Value chatReq;
			chatReq[strMsg][0u] = res_sucess;
			chatReq[strMsg][1u] = CHAT::chat_all;
			chatReq[strMsg][2u] = ServerPackage(senderID);
			chatReq[strMsg][3u] = message;
			chatReq[strMsg][4u] = pos;
			chatReq[strMsg][5u] = data;
			return impl_despatchPlayer(playerName, chatReq);
		}
		inline bool despatchAll(const int senderID, Json::Value& message, const unsigned pos = CHATPOS::chat_windows)
		{
			return despatchAllSP(senderID, message, 0, pos);
		}
		inline bool despatchKingdom(const int senderID, const Kingdom::NATION nation, Json::Value& message, const unsigned pos = CHATPOS::chat_windows)
		{
			return despatchKingdomSP(senderID, nation, message, 0, pos);
		}
		inline bool despatchPlayer(const int senderID, const int playerID, Json::Value& message, const unsigned pos = CHATPOS::chat_windows)
		{
			return despatchPlayerSP(senderID, playerID, message, 0, pos);
		}
		inline bool despatchPlayer(const int senderID, const string playerName, Json::Value& message, const unsigned pos = CHATPOS::chat_windows)
		{
			return despatchPlayerSP(senderID, playerName, message, 0, pos);
		}
		//qvalue
		template<typename TYPE>
		bool despatchAllSP(const int senderID, qValue& message, TYPE data, const unsigned pos = CHATPOS::chat_windows)
		{
			qValue chat_data(qJson::qj_array);
			chat_data.append(res_sucess).
				append(CHAT::chat_all).
				append(ServerPackageQ(senderID)).
				append(message).
				append(pos).
				append(data);
			return impl_despatchAll(chat_data);
		}
		template<typename TYPE>
		bool despatchKingdomSP(const int senderID, const Kingdom::NATION nation, qValue& message, TYPE data, const unsigned pos = CHATPOS::chat_windows)
		{
			qValue chat_data(qJson::qj_array);
			chat_data.append(res_sucess).
				append(CHAT::chat_all).
				append(ServerPackageQ(senderID)).
				append(message).
				append(pos).
				append(data);
			return impl_despatchKingdom(nation, chat_data);
		}
		template<typename TYPE>
		bool despatchPlayerSP(const int senderID, const int playerID, qValue& message, TYPE data, const unsigned pos = CHATPOS::chat_windows)
		{
			qValue chat_data(qJson::qj_array);
			chat_data.append(res_sucess).
				append(CHAT::chat_all).
				append(ServerPackageQ(senderID)).
				append(message).
				append(pos).
				append(data);
			return impl_despatchPlayer(playerID, chat_data);
		}
		template<typename TYPE>
		bool despatchPlayerSP(const int senderID, const string playerName, qValue& message, TYPE data, const unsigned pos = CHATPOS::chat_windows)
		{
			qValue chat_data(qJson::qj_array);
			chat_data.append(res_sucess).
				append(CHAT::chat_all).
				append(ServerPackageQ(senderID)).
				append(message).
				append(pos).
				append(data);
			return impl_despatchPlayer(playerName, chat_data);
		}
		inline bool despatchAll(const int senderID, qValue& message, const unsigned pos = CHATPOS::chat_windows)
		{
			return despatchAllSP(senderID, message, 0, pos);
		}
		inline bool despatchKingdom(const int senderID, const Kingdom::NATION nation, qValue& message, const unsigned pos = CHATPOS::chat_windows)
		{
			return despatchKingdomSP(senderID, nation, message, 0, pos);
		}
		inline bool despatchPlayer(const int senderID, const int playerID, qValue& message, const unsigned pos = CHATPOS::chat_windows)
		{
			return despatchPlayerSP(senderID, playerID, message, 0, pos);
		}
		inline bool despatchPlayer(const int senderID, const string playerName, qValue& message, const unsigned pos = CHATPOS::chat_windows)
		{
			return despatchPlayerSP(senderID, playerName, message, 0, pos);
		}

		int toChatWindowsRep(const string source_path);//���Ƶ����촰ս����ַ

		//��������Ϣ���
		Json::Value ChatPackage(playerDataPtr player);
		qValue ChatPackageQ(playerDataPtr player);

		//ϵͳ�����Ϣ���
		qValue ServerPackageQ(const int ID);
		Json::Value ServerPackage(const int ID);

		//������Ϣ����
		void sendBufferChat(playerDataPtr player);

	private:
		bool impl_despatchAll(Json::Value& chatReq);
		bool impl_despatchAll(qValue& chat_data);
		bool impl_despatchKingdom(const Kingdom::NATION nation, Json::Value& chatReq);
		bool impl_despatchKingdom(const Kingdom::NATION nation, qValue& chat_data);
		bool impl_despatchPlayer(const int playerID, Json::Value& chatReq);
		bool impl_despatchPlayer(const string playerName, Json::Value& chatReq);
		bool impl_despatchPlayer(const int playerID, qValue& chat_data);
		bool impl_despatchPlayer(const string playerName, qValue& chat_data);
	};
}
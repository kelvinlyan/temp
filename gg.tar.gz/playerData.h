//###################################
//create by Jim
//2015-11-04
//###################################

#pragma once
#include <boost/thread/mutex.hpp>
#include <boost/thread/recursive_mutex.hpp>
#include <boost/shared_ptr.hpp>
#include <boost/enable_shared_from_this.hpp>
#include "commom.h"
#include "channel.h"
#include "quickjson.h"

//@�������ͷ�ļ�
#include "gamer_data.h"
#include "gamer_tick.h"
#include "player_man.h"
#include "gamer_resource.h"
#include "player_mapwar.h"
#include "player_task.h"
#include "war_formation.h"
#include "player_card.h"
#include "player_item.h"
#include "player_search.h"
#include "gamer_face.h"
#include "pokedex.h"
#include "playerCount.h"
#include "player_trade.h"
#include "player_kingfight.h"
#include "player_kingdom.h"
#include "player_rescue.h"
#include "player_team.h"
#include "player_vip.h"
#include "player_worldboss.h"
#include "player_research.h"
#include "player_market.h"
#include "player_orders.h"
#include "player_mall.h"
#include "player_warlords.h"
#include "player_email.h"
#include "player_daily.h"
#include "player_build_team.h"
#include "player_feod.h"
#include "player_admin.h"
#include "gamer_offline.h"
#include "gamer_custom.h"
#include "player_days_activity.h"
#include "gamer_online_box.h"
#include "player_affair.h"
#include "player_sign.h"
#include "player_money.h"
#include "gamer_daily_card.h"
#include "player_fund.h"
#include "player_kingdomwar.h"
#include "player_kingdomwar_shop.h"
#include "player_kingdomwar_output.h"
#include "player_kingdomwar_fm.h"
#include "player_kingdomwar_pos.h"
#include "player_kingdomwar_box.h"
#include "player_kingdomwar_task.h"
#include "player_patrol.h"

//@�������ͷ�ļ�

namespace gg
{
	const static string strPlayerID = "pi";

#define ShareData(TYPENAME) boost::shared_ptr<TYPENAME>

	class playerData :
		public boost::enable_shared_from_this<playerData>
	{
		friend class playerManager;
	public:
		inline playerDataPtr getOwnDataPtr(){
			return shared_from_this();
		}
		bool isVaild();
//		inline int Net(){ return netID; }
		inline bool isOnline()
		{
			return Online;
		}
		inline bool isInitial()
		{
			return Initial;
		}
		void sendToClient(const short protocol, Json::Value& msg);
		void sendToClient(const short protocol, qValue& msg);
		void sendToClientFillMsg(const short protocol, qValue& msg);
		void sendToClient(const short protocol, string& msg);
		void sendToClientFillMsg(const short protocol, string& msg);
		void Logout();
		void Login();
//		bool outLine();
		inline int ID(){ return Info->ID(); }
		inline string Name(){ return Info->Name(); }
		inline unsigned LV(){ return Info->LV(); }
		inline bool motifyName(const string name){ return Info->motifyName(name); }

		//////////////////////////////////////////////////////////////////////////
		ShareData(playerBase) Info;
		ShareData(playerTick) Tick;
		ShareData(playerManMgr) Man;
		ShareData(playerResource) Res;
		ShareData(playerMapWarMgr) War;//
		ShareData(playerTask) Task;//
		ShareData(playerWarFM) WarFM;
		ShareData(playerCardMgr) Card;
		ShareData(playerCardTs) CardTs;
		ShareData(playerItemMgr) Items;
		ShareData(playerSearch) Sch;
		ShareData(playerFace) Face;
		ShareData(playerPoke) Poke;
		ShareData(playerCount) Count;
		ShareData(playerCarPos) CarPos;
		ShareData(playerTrade) Trade;//ó��
		ShareData(playerKingFight) KingFight;//
		ShareData(playerKingdom) KingDom;//
		ShareData(playerRescue) RescueData;
		ShareData(playerTeam) Team;//
		ShareData(playerVipMgr) Vip;//
		ShareData(playerWorldBoss) WorldBoss;//
		ShareData(playerWarLords) WarLords;//
		ShareData(playerResearch) Research;
		ShareData(playerMarket) Market;
		ShareData(playerOrders) Orders;
		ShareData(playerMall) Malls;
		ShareData(playerEmail) Email;
		ShareData(playerDaily) Daily;
		ShareData(playerBuildTeam) BuildTeam;
		ShareData(playerBuilds) Builds;
		ShareData(playerAdmin) Admin;
		ShareData(playerOffline) Offline;
		ShareData(playerCustom) Custom;
		ShareData(playerDaysActivity) DaysActivity;
		ShareData(playerOnlineBox) OnlineBox;
		ShareData(playerAffair) Affair;
		ShareData(playerSign) Sign;
		ShareData(playerMoneyActivity) MoneyActivity;
		ShareData(playerDailyCard) DailyCard;
		ShareData(playerFund) Fund;
		ShareData(playerKingdomWar) KingDomWar;
		ShareData(playerKingdomWarShop) KingDomWarShop;
		ShareData(playerKingdomWarOutput) KingDomWarOutput;
		ShareData(playerKingdomWarFM) KingDomWarFM;
		ShareData(playerKingdomWarPos) KingDomWarPos;
		ShareData(playerKingdomWarBox) KingDomWarBox;
		ShareData(playerKingdomWarTask) KingDomWarTask;
		ShareData(playerPatrol) Patrol;



		//////////////////////////////////////////////////////////////////////////
		//memory
		unsigned Chat[CHAT::user_channel];
		unsigned TeamCD;
		unsigned BusinessCD;
		unsigned EquipShowCD;
		unsigned ShareLastCD;
		unsigned TeamAnnCD;
		//end
		//public method
		void onBVAlter();//�����ս���ı��ʱ��
	protected:
		bool beginLoad();
		void endLoad();


		bool Online;
		bool Initial;
		void initial();
		void onLogin();//��ҵ�½��ʱ��
		void onOFFLine();//�������
		void onRefresh();
		void onCreateRole();//��Ҵ�����ɫ��ʱ��
	public:
		playerData(const int pID);
		playerData(const string pName);
		~playerData();
		static playerDataPtr Create(const int playerID)
		{
			return Creator<playerData>::Create(playerID);
		}
		static playerDataPtr Create(const string playerName)
		{
			return Creator<playerData>::Create(playerName);
		}
	};
}

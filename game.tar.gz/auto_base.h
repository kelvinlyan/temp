//###################################
//create by Jim
//2015-11-04
//###################################

#pragma once

#include <iostream>
#include "commom.h"
#include "timmer.hpp"
#include "quickjson.h"

const static std::string strMsg = "msg";

namespace gg
{
	class State
	{
	public:
		inline static void setState(const int type)
		{
			state = type;
		}
		inline static int getState()
		{
			return state;
		}
	private:
		static int state;
	};

	class NumberCounter
	{
	public:
		inline static int getCounter()
		{
			return counter;
		}
		inline static void Step()
		{
			counter = ++counter % 1000000;
		}
	private:
		static int counter;
	};

	class helper;
	class playerManager;
	class playerData;
	typedef boost::shared_ptr<playerData> playerDataPtr;
	class _auto_meta;
	typedef boost::weak_ptr<_auto_meta> _meta_weak;
	typedef boost::shared_ptr<_auto_meta> _meta_shared;
	class _auto_meta :
		public boost::enable_shared_from_this<_auto_meta>
	{
		friend class helper;
		virtual _meta_weak getOwn();
		virtual void _begin_update(){}
	public:
		virtual void _auto_update(){}
		virtual bool _auto_save(){ return true; }
		virtual void _auto_end(){}
		virtual void _sign_update();
		virtual void _sign_save();
		virtual void _sign_auto(); //����_sign_update/_sign_save
		virtual bool _on_sign_update(){ return true; }//�������false����ֹ_sign_update
		virtual bool _on_sign_save(){ return true; }//�������false����ֹ_sign_save
	public:
		virtual ~_auto_meta(){}
	};

	namespace AutoPlayer
	{
		enum
		{
			class_load = (0x0001 << 0),//�������db�Ķ�ȡ
			class_complete = (0x0001 << 1),//������ݵĴ���

			class_all_empty = 0,//��յ�״̬
			class_all_over = (class_load | class_complete),//��ȫ״̬
		};
	}

	class _auto_player :
		public _auto_meta
	{
		friend class playerData;
		virtual void _begin_update();
	protected:
		_auto_player(playerData* const pD) : _Own(pD)
		{
//			cout << &Own() << endl;
			classState = 0;
			isRun = false;
		}
		playerData& Own(){ return *_Own; }
		playerData* const _Own;
		virtual void classLoad() {}//��ȡ���ݿ�
		virtual void classFinal(){} //�����������֮��Ҫ��������//һ��ʹ������Ϳ���
		virtual void classRefresh() {}//�����ߵ�����ˢ��//�����ж�
		void setClassState(const unsigned state) { classState = state; }//�½���ɫloading״̬Ϊ���
		unsigned classState;
		bool isRun;
	public:
		void toLoad();
		inline bool loadOK() { return (AutoPlayer::class_load & classState) > 0; }
		inline bool completeOK() { return (AutoPlayer::class_complete & classState) > 0; }
		virtual ~_auto_player(){}
	};

	//
#define DeclareRegFunction(NAME)\
	void NAME(net::Msg& m, Json::Value& r)

#define PARSEJSON \
	Json::Value js;\
	Json::Reader reader;\
	std::string recv_str(m.strUTF8, m.dataLen());\
	reader.parse(recv_str, js);\

#define ReadJson \
	Json::Value js;\
	Json::Reader reader;\
	std::string recv_str(m.strUTF8, m.dataLen());\
	if(! reader.parse(recv_str, js)){\
		LogW << "recv string :" << string(m.strUTF8, m.packageLen - net::MINPACKAGE) << LogEnd;\
		LogW << "json parse failed " << __FUNCTION__ << \
		"	player_id: " << m.playerID << "	type " << m.protocolID << LogEnd;\
		return;\
					}\
	if(! js.isObject()){\
	LogW << "recv string :" << js.toIndentString() << LogEnd;\
		LogW << "json is not a object " << __FUNCTION__ << \
			"	player_id: " << m.playerID << "	type " << m.protocolID << LogEnd;\
		return;\
					}\

#define ReadJsonArray \
	Json::Value js;\
	Json::Reader reader;\
	std::string recv_str(m.strUTF8, m.dataLen());\
	if(! reader.parse(recv_str, js)){\
		LogW << "recv string :" << string(m.strUTF8, m.packageLen - net::MINPACKAGE) << LogEnd;\
		LogW << "json parse failed " << __FUNCTION__ << \
		"	player_id: " << m.playerID << "	type " << m.protocolID << LogEnd;\
		return;\
			}\
	if(! js.isObject()){\
	LogW << "recv string :" << js.toIndentString() << LogEnd;\
		LogW << "json is not a object " << __FUNCTION__ << \
			"	player_id: " << m.playerID << "	type " << m.protocolID << LogEnd;\
		return;\
			}\
	Json::Value& js_msg = js[strMsg];\
	if(!js_msg.isArray()){\
		LogW << "recv string :" << js.toIndentString() << LogEnd;\
		LogW << "ReadJsonArray error " << __FUNCTION__ << \
		"	player_id: " << m.playerID << "	type " << m.protocolID << LogEnd;\
		return;\
			}\

#define UnAcceptRetrun(CON, CODE)\
	if( !( CON ) ){\
	r[msgStr][0u] = CODE;\
	return;\
			}

#define Return(JSON, CODE)\
			{\
		JSON[strMsg][0u] = CODE;\
		return;\
			}

#define resReturn(JSON, CODE, RES)\
					{\
		JSON[strMsg][0u] = CODE;\
		return RES;\
					}
}
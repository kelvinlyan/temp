#include "warlords_system.h"
#include "battle_helper.hpp"
#include "chat.h"
#include "commom.h"
#include "email_system.h"
#include "task_mgr.h"
#include "map_war.h"
#include "kingdom_system.h"
#include "festival_system.h"

namespace gg
{
	namespace WarLords
	{
		enum
		{
			LvLimit = 40,
		};
	};

	struct RewardItem 
	{
		void clear()
		{
			iron = 0;
			wood = 0;
			food = 0;
			fame = 0;
		};
		int iron;
		int wood;
		int food;
		int fame;
	};

	static RewardItem RW;

	warlords_system* const warlords_system::_Instance = new warlords_system();

	void warlords_system::initData()
	{
		LogS << "war lords initial ..." << LogEnd;
		evil_type.assign(50 + 1 + 100, 0);
		unsigned type = 0;
		unsigned i = 0;
		for (; i <= 25; ++i)
			evil_type[i] = type;
		++type;
		for (; i <= 40; ++i)
			evil_type[i] = type;
		++type;
		for (; i <= 45; ++i)
			evil_type[i] = type;
		++type;
		for (; i <= 50; ++i)
			evil_type[i] = type;
		++type;
		for (; i <= 55; ++i)
			evil_type[i] = type;
		++type;
		for (; i <= 60; ++i)
			evil_type[i] = type;
		++type;
		for (; i <= 70; ++i)
			evil_type[i] = type;
		++type;
		for (; i <= 85; ++i)
			evil_type[i] = type;
		++type;
		for (; i <= 110; ++i)
			evil_type[i] = type;
		++type;
		for (; i <= 140; ++i)
			evil_type[i] = type;
		++type;
		for (; i <= 150; ++i)
			evil_type[i] = type;

		Common::createDirectories("./report/warlords/");

		loadFile();
		player_list.init(level_vec.size());
	}

	void warlords_system::playerInfoReq(net::Msg& m, Json::Value& r)
	{
		playerDataPtr d = player_mgr.getPlayer(m.playerID);
		if (!d) Return(r, err_illedge);
		if (d->LV() < WarLords::LvLimit)
			Return(r, err_lv_not_enough);
		
		d->WarLords().update();
	}

	void warlords_system::battleInfoReq(net::Msg& m, Json::Value& r)
	{
		playerDataPtr d = player_mgr.getPlayer(m.playerID);
		if (!d) Return(r, err_illedge);
		if (d->LV() < WarLords::LvLimit)
			Return(r, err_lv_not_enough);
		ReadJsonArray;
		int nation = js_msg[0u].asInt();
		int type = js_msg[1u].asInt();
		int page = js_msg[2u].asInt();
		int begin, end;
		getLevelIndex(type, begin, end);
		if (begin == -1 || end == -1)
			Return(r, err_illedge);
		if (page == -1)
			page = player_list.getPageByPid(nation, begin, end, d->ID());
		//qValue q;
		r[strMsg][1u]["i"] = Json::arrayValue;
		player_list.getInfo(nation, begin, end, page, r[strMsg][1u]["i"]);	
		r[strMsg][1u]["n"] = player_list.getAllPage(nation, begin, end);
		r[strMsg][1u]["c"] = page;
		Return(r, res_sucess);
		//player_mgr.sendToPlayer(m.playerID, gate_client::warlords_battle_info_resp, q);
	}

	void warlords_system::attackReq(net::Msg& m, Json::Value& r)
	{
		playerDataPtr d = player_mgr.getPlayer(m.playerID);
		if (!d) Return(r, err_illedge);
		if (d->LV() < WarLords::LvLimit)
			Return(r, err_lv_not_enough);
		ReadJsonArray;
		int id = js_msg[0u].asInt();
		if (id == d->ID())
			Return(r, err_illedge);
		playerDataPtr target = player_mgr.getPlayer(id);
		if (!target) Return(r, err_illedge);
	
		int res = check(d, target);
		if (res != res_sucess)
			Return(r, res);
		
		BattleReport reportData;
		sBattlePtr atk = BattleHelp::WarPlayer(d);
		sBattlePtr def = BattleHelp::WarPlayer(target);
		O2ORes resultB = reportData.One2One(atk, def, typeBattle::warlords);

		Json::Value atk_reward;
		Json::Value def_reward;
		Json::Value fame_reward;
		getReward(resultB, d, target, atk_reward, def_reward, fame_reward);

		unsigned now = Common::gameTime();
		std::string atk_report_id = d->WarLords().atkAddReport(now, target, resultB, atk_reward);
		std::string def_report_id = target->WarLords().defAddReport(now, d, resultB, def_reward);
		std::string atk_path = "warlords/" + Common::toString(d->ID()) + "/" + atk_report_id;
		std::string def_path = "warlords/" + Common::toString(target->ID()) + "/" + def_report_id;
		reportData.addCopyField(atk_path);
		reportData.addCopyField(def_path);
		if (d->Info().Nation() != target->Info().Nation()
			&& festival_sys.current())
		{
			ActionBoxList extra = festival_sys.current()->worldExtra();
			actionDoBox(d, extra);
			Json::Value extra_json = actionRes();
			combineActionRes(extra_json, atk_reward);
		}
		reportData.addReportdeclare("wb", atk_reward);
		reportData.addNotice(d->ID());
		if (d->Info().Nation() != target->Info().Nation()
			&& atk->battleValue < def->battleValue)
			TaskMgr::update(d, Task::WarLordsBeatHigherBV, 1);

		battleBroadcast(resultB, d, target);
		sendEmail(reportData, resultB, d, target, atk_path, def_reward, fame_reward);
		//TaskMgr::update(d, Task::WarLordsAttackTimes, 1);
		//d->Daily().tickTask(DAILY::hit_world_other);
		reportData.Done(typeBattle::warlords);
		r[strMsg][1u] = resultB.res == resBattle::atk_win;
		Return(r, res_sucess);
	}

	void warlords_system::reportListReq(net::Msg& m, Json::Value& r)
	{
		playerDataPtr d = player_mgr.getPlayer(m.playerID);
		if (!d) Return(r, err_illedge);
		if (d->LV() < WarLords::LvLimit)
			Return(r, err_lv_not_enough);
		d->WarLords().getReportInfo(r[strMsg][1u]);
		Return(r, res_sucess);
	}

	void warlords_system::tableReq(net::Msg& m, Json::Value& r)
	{
		playerDataPtr d = player_mgr.getPlayer(m.playerID);
		if (!d) Return(r, err_illedge);
		if (d->LV() < WarLords::LvLimit)
			Return(r, err_lv_not_enough);
		ReadJsonArray;
		int target_id = js_msg[0u].asInt();
		playerDataPtr target = player_mgr.getPlayer(target_id);
		if (!target) Return(r, err_warlords_name_not_found);

		if (d->Info().Nation() == Kingdom::null
			|| target->Info().Nation() == Kingdom::null)
			Return(r, err_illedge);

		target->WarLords().getTable(d->Info().Nation(), r[strMsg][1u]);
		Return(r, res_sucess);
	}

	void warlords_system::searchReq(net::Msg& m, Json::Value& r)
	{
		playerDataPtr d = player_mgr.getPlayer(m.playerID);
		if (!d) Return(r, err_illedge);
		if (d->LV() < WarLords::LvLimit)
			Return(r, err_lv_not_enough);
		
		if (d->WarLords().inSearchCd())
			Return(r, err_warlords_in_search_cd);

		ReadJsonArray;
		std::string target_name = js_msg[0u].asString();
		playerDataPtr target = player_mgr.getPlayer(target_name);
		if (!target) Return(r, err_warlords_name_not_found);

		r[strMsg][1u] = target->ID();
		Return(r, res_sucess);
	}

	void warlords_system::lookUpReq(net::Msg& m, Json::Value& r)
	{
		playerDataPtr d = player_mgr.getPlayer(m.playerID);	
		if (!d) Return(r, err_illedge);
		if (d->LV() < WarLords::LvLimit)
			Return(r, err_lv_not_enough);
		
		ReadJsonArray;
		int target_id = js_msg[0u].asInt();
		playerDataPtr target = player_mgr.getPlayer(target_id);
		if (!target) Return(r, err_warlords_name_not_found);
		
		int prev = d->Res().getCash();
		if (prev < 5)
			Return(r, err_illedge);
		d->Res().alterCash(-5);
		Log(DBLOG::strLogWarLords, d, 1, target->Name(), 5, prev, d->Res().getCash());

		qValue mm;
		mm.append(res_sucess);
		qValue q(qJson::qj_object);
		q.addMember("f", target->Res().getFood());
		q.addMember("i", target->Res().getIron());
		q.addMember("w", target->Res().getWood());
		q.addMember("fi", target->WarFM().currentID());
		{
			qValue fm;
			std::vector<playerManPtr> vec = target->WarFM().currentFM();
			for (unsigned i = 0; i < vec.size(); ++i)
				fm.append(vec[i]? vec[i]->mID() : -1);
			q.addMember("fm", fm);
		}
		mm.append(q);
		d->sendToClientFillMsg(gate_client::warlords_look_up_resp, mm);
	}

	void warlords_system::setMessageReq(net::Msg& m, Json::Value& r)
	{
		playerDataPtr d = player_mgr.getPlayer(m.playerID);	
		if (!d) Return(r, err_illedge);
		if (d->LV() < WarLords::LvLimit)
			Return(r, err_lv_not_enough);
		
		ReadJsonArray;
		const std::string& str = js_msg[0u].asString();
		int res = d->WarLords().setMessage(str);
		if (res == res_sucess)
			r[strMsg][1u] = str;
		Return(r, res_sucess);
	}

	void warlords_system::updatePlayerLv(playerDataPtr d, int olv)
	{
		player_list.updateLv(d, olv);
	}

	void warlords_system::updatePlayerName(playerDataPtr d)
	{
		player_list.updateName(d);
	}

	void warlords_system::updatePlayerCd(playerDataPtr d)
	{
		player_list.updateCd(d);
	}

	void warlords_system::updateLogin(playerDataPtr d)
	{
		player_list.updateLogin(d);
	}

	void warlords_system::updateLogout(playerDataPtr d)
	{
		player_list.updateLogout(d);
	}

	void warlords_system::updatePower(playerDataPtr d)
	{
		player_list.updatePower(d);
	}

	void warlords_system::updateEvilValue(playerDataPtr d)
	{
		player_list.updateEvilValue(d);
	}

	void warlords_system::loadFile()
	{
		const Json::Value& json = Common::loadJsonFile("./instance/warlords/config.json");
		const Json::Value& range = json["range"];
		ForEach(Json::Value, it, range)
		{
			const Json::Value& pair = (*it);
			int begin = pair[0u].asInt();
			int end = pair[1u].asInt();
			if (end == -1)
				continue;
			level_vec.push_back(make_pair(end, begin));
		}
		const Json::Value& reward_param = json["rewardParam"];
		param1 = reward_param[0u].asInt();	
		param2 = reward_param[1u].asDouble();
		param3 = reward_param[2u].asDouble();
		param4 = reward_param[3u].asInt();

		const Json::Value& npcName = json["npcName"];
		for (unsigned i = 0; i < 3; ++i)
			npc_name[i] = npcName[i].asString();

		const Json::Value& fameRate = json["fameRate"];
		ForEach(Json::Value, it, fameRate)
			fame_rate.push_back((*it).asDouble());
	}

	void warlords_system::getLevelIndex(int type, int& begin, int& end)
	{
		if (type < 0 || type >= level_vec.size())
		{
			begin = -1;
			end = -1;
		}
		else
		{
			begin = level_vec[type].first;
			end = level_vec[type].second;
		}
	}

	void warlords_system::battleBroadcast(const O2ORes& res, playerDataPtr d, playerDataPtr target)
	{
		if (res.res == resBattle::atk_win 
			&& d->Info().Nation() != target->Info().Nation())
		{
			int nation = d->Info().Nation();
			int evil = target->WarLords().getTitle(nation);
			if (evil >= 8)
			{
				Json::Value msg;
				if(evil == 10)
					msg.append(1);
				else if(evil == 11)
					msg.append(2);
				else
					msg.append(0);
				msg.append(chat_sys.ChatPackage(d));
				msg.append(chat_sys.ChatPackage(target));
				chat_sys.despatchKingdom(CHAT::server_warlords_battle, (Kingdom::NATION)nation, msg);
			}
		}
	}
	
	int warlords_system::getTitle(unsigned evil_value) const
	{
		return evil_type[evil_value];
	}

	int warlords_system::getTypeByLv(int lv) const
	{
		for (int i = 0; i < level_vec.size(); ++i)
		{
			int begin = level_vec[i].first;
			int end = level_vec[i].second;
			if (lv <= begin && lv >= end)
				return i;
		}
		return -1;
	}

	void warlords_system::sendEmail(BattleReport& reportData, const O2ORes& res, playerDataPtr d, playerDataPtr target, const std::string& report, const Json::Value& reward, const Json::Value& fame_reward)
	{
		if (d->Info().Nation() != target->Info().Nation())
		{
			if (res.res == resBattle::atk_win)
			{
				/*
				Json::Value paramA;
				paramA.append(target->Name());
				paramA.append(RW.iron);
				paramA.append(RW.wood);
				paramA.append(RW.fame);
				paramA.append(RW.food);
				std::string atk_rep_id = d->Email().getRepId();
				std::string path = "email/" + Common::toString(d->ID()) + "/" + atk_rep_id;
				reportData.addCopyField(path);
				EmailPtr ptrA = email_sys.createReport(EmailDef::WarLordsBattleA, paramA, path);
				email_sys.sendToPlayer(d->ID(), ptrA);
				*/

				Json::Value paramB;
				paramB.append(d->Name());
				paramB.append(RW.iron);
				paramB.append(RW.wood);
				paramB.append(d->ID());
				std::string def_rep_id = target->Email().getRepId();
				std::string path = "email/" + Common::toString(target->ID()) + "/" + def_rep_id;
				reportData.addCopyField(path);
				EmailPtr ptrB = email_sys.createReport(EmailDef::WarLordsBattleB, paramB, path);
				email_sys.sendToPlayer(target->ID(), ptrB);
			}
			else
			{
				/*
				Json::Value paramC;
				paramC.append(target->Name());
				paramC.append(RW.fame);
				paramC.append(RW.food);
				std::string atk_rep_id = d->Email().getRepId();
				std::string path = "email/" + Common::toString(d->ID()) + "/" + atk_rep_id;
				reportData.addCopyField(path);
				EmailPtr ptrC = email_sys.createReport(EmailDef::WarLordsBattleC, paramC, path);
				email_sys.sendToPlayer(d->ID(), ptrC);
				*/

				Json::Value paramD;
				paramD.append(d->Name());
				paramD.append(d->ID());
				std::string def_rep_id = target->Email().getRepId();
				std::string path = "email/" + Common::toString(target->ID()) + "/" + def_rep_id;
				reportData.addCopyField(path);
				EmailPtr ptrD = email_sys.createReport(EmailDef::WarLordsBattleD, paramD, path);
				email_sys.sendToPlayer(target->ID(), ptrD);
			}
		}
	}

	void warlords_system::getReward(const O2ORes& res, playerDataPtr d, playerDataPtr target, Json::Value& atk_reward, Json::Value& def_reward, Json::Value& fame_reward)
	{
		RW.clear();
		atk_reward = Json::arrayValue;
		def_reward = Json::arrayValue;
		fame_reward = Json::arrayValue;
		if (d->Info().Nation() == target->Info().Nation())
			return;

		if (res.res == resBattle::atk_win)
		{	
			int max = target->LV() * 4000;
			/*{
				int value = target->Res().getFood() * 0.1;
				if (value > max)
					value = max;
				d->Res().alterFood(value);
				target->Res().alterFood(0 - value);
				Json::Value tmp;
				tmp.append(ACTION::food);
				tmp.append(value);
				atk_reward.append(tmp);
				def_reward.append(tmp);
			}*/
			{
				int value = target->Res().getIron() * 0.1;
				if (value > max)
					value = max;
				d->Res().alterIron(value);
				target->Res().alterIron(0 - value);
				Json::Value tmp;
				tmp.append(ACTION::iron);
				tmp.append(value);
				atk_reward.append(tmp);
				def_reward.append(tmp);
				RW.iron = value;
			}
			{
				int value = target->Res().getWood() * 0.1;
				if (value > max)
					value = max;
				d->Res().alterWood(value);
				target->Res().alterWood(0 - value);
				Json::Value tmp;
				tmp.append(ACTION::wood);
				tmp.append(value);
				atk_reward.append(tmp);
				def_reward.append(tmp);
				RW.wood = value;
			}
		}

		int fame = getFameReward(res.res, d, target);
		fame = d->WarLords().addFame(fame);
		int food_value = d->LV() * 100 + 10000;
		d->Res().alterFood(food_value);
		Json::Value tmp;
		tmp.append(ACTION::fame);
		tmp.append(fame);
		fame_reward.append(tmp);
		Json::Value food;
		food.append(ACTION::food);
		food.append(food_value);
		fame_reward.append(food);
		Log(DBLOG::strLogWarLords, d, 0, target->ID(), target->Name(), -1, d->WarLords().getAttackTimes() + 1, atk_reward.toIndentString(), fame_reward.toIndentString(), res.res);
		atk_reward.append(tmp);
		atk_reward.append(food);
		RW.fame = fame;
		RW.food = food_value;
	}

	static int getMaxManBV(const std::vector<playerManPtr>& man_vec)
	{
		int max = 0;
		ForEachC(std::vector<playerManPtr>, it, man_vec)
		{
			const playerManPtr& ptr = *it;
			if (ptr && ptr->battleValue() > max)
				max = ptr->battleValue();
		}
		return max;
	}

	int warlords_system::getFameReward(int result, playerDataPtr d, playerDataPtr target)
	{
		double bv_rate = 1.0;
		int my_power = d->WarFM().currentBV();
		//if ((double)d->WarFM().currentBV() / 5.0 > (double)getMaxManBV(target->WarFM().currentFM()) * 0.4)
		{
			if (my_power > param4)
				my_power = param4;
			bv_rate = (double)(target->WarFM().currentBV() + 1) / (double)(my_power + 1);
			bv_rate = pow(bv_rate, 1.5);
			if (bv_rate < 0.7)
				bv_rate = 0.7;
			if (bv_rate > 1.3)
				bv_rate = 1.3;
		}
		double lv_rate = (double)(target->LV()) / (double)d->LV();
		if (lv_rate < 0.9)
			lv_rate = 0.9;
		if (lv_rate > 1.1)
			lv_rate = 1.1;
		double fail_rate = result == resBattle::atk_win ? 1.0 : param3;
		
		return (param1 + my_power / param2) * bv_rate * lv_rate * fail_rate * fame_rate[target->WarLords().getTitle(d->Info().Nation())];
	}

	void warlords_system::testBroadcast(playerDataPtr d)
	{
		Json::Value msg;
		msg = Json::arrayValue;
		msg.append(0);
		msg.append(chat_sys.ChatPackage(d));
		msg.append(chat_sys.ChatPackage(d));
		chat_sys.despatchKingdom(CHAT::server_warlords_battle, (Kingdom::NATION)d->Info().Nation(), msg);
		msg = Json::arrayValue;
		msg.append(1);
		msg.append(chat_sys.ChatPackage(d));
		msg.append(chat_sys.ChatPackage(d));
		chat_sys.despatchKingdom(CHAT::server_warlords_battle, (Kingdom::NATION)d->Info().Nation(), msg);
		msg = Json::arrayValue;
		msg.append(2);
		msg.append(chat_sys.ChatPackage(d));
		msg.append(chat_sys.ChatPackage(d));
		chat_sys.despatchKingdom(CHAT::server_warlords_battle, (Kingdom::NATION)d->Info().Nation(), msg);
	}

	void warlords_system::npcBattle(playerDataPtr d)
	{
		mapDataCfgPtr config = map_sys.getMapConfig(100501);
		if (!config)
			return;

		if (d->Info().Nation() == Kingdom::null)
			return;
		
		BattleReport reportData;
		sBattlePtr atk = map_sys.npcSide(config);
		atk->playerName = npc_name[d->Info().Nation()];
		sBattlePtr def = BattleHelp::WarPlayer(d);
		O2ORes resultB = reportData.One2One(atk, def, typeBattle::warlords);
		reportData.addReportdeclare("wb", Json::arrayValue);
		std::string rep_id = d->WarLords().addNpcRep(Common::gameTime(), atk->playerName, resultB);
		std::string path = "warlords/" + Common::toString(d->ID()) + "/" + rep_id;
		reportData.addCopyField(path);
		reportData.Done(typeBattle::warlords);
	}

	int warlords_system::check(playerDataPtr d, playerDataPtr target)
	{
		if (d->Info().Nation() == Kingdom::null
			|| target->Info().Nation() == Kingdom::null)
			return err_no_join_kingdom;
		
		int type_1 = getTypeByLv(d->LV());
		int type_2 = getTypeByLv(target->LV());
		if (type_1 > type_2)
			return err_warlords_higher_range;
		if (type_1 < type_2)
			return err_warlords_lower_range;

		if (d->Info().Nation() != target->Info().Nation())
		{
			if (d->WarLords().getAttackTimes() >= playerWarLords::AttackTimes)
				return err_warlords_times_limit;
			if (d->Res().getAction() < 1)
				return err_action_not_enough;
			if (Common::gameTime() < target->WarLords().getCd())
				return err_warlords_cd_limit;
		}
		return res_sucess;
	}
}

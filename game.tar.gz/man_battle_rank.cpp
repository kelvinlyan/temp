#include "man_battle_rank.h"

namespace gg
{
	ManBattleRank* const ManBattleRank::_Instance = new ManBattleRank();

	using namespace NSManRank;
	ptrRankData ManBattleRank::getData(const int playerID, const int manID)
	{
		PlayerMap::const_iterator it = Player.find(FindKey(playerID, manID));
		if (it == Player.end())return ptrRankData();
		return it->second;
	}

	void ManBattleRank::initData()
	{
		if (isInitial)return;
		cout << "initial man battle rank list ..." << endl;
		Rank.clear();
		Player.clear();
		mongo::Query find_query(BSON("cbv" << BSON("$gt" << 0)));
		find_query.sort(strPlayerID, 1).sort("mid", 1).sort("q", -1).sort("lv", -1).sort("cbv", -1);
		objCollection objs = db_mgr.QueryCustom(DBN::dbPlayerMan, find_query, 100);
		std::set<int> same_member;
		for (unsigned i = 0; i < objs.size(); ++i)
		{
			mongo::BSONObj& obj = objs[i];
			const int playerID = obj[strPlayerID].Int();
			if (same_member.insert(playerID).second)
			{
				playerDataPtr now_player = player_mgr.getPlayer(playerID);
				if (!now_player)break;
				now_player->Man();
			}
		}
		cout << "man battle rank size:" << Rank.size() << "\t" << Player.size() << endl;
		isInitial = true;
	}

	void ManBattleRank::ManDetail(net::Msg& m, Json::Value& r)
	{
		playerDataPtr player = player_mgr.getPlayer(m.playerID);
		if (!player)Return(r, err_illedge);//�Ƿ�����
		ReadJsonArray;
		const int id = js_msg[0u].asInt();
		const int mid = js_msg[1u].asInt();
		ptrRankData ptr = getData(id, mid / 100);
		qValue json(qJson::qj_array);
		if (ptr)
		{
			json.
				append(res_sucess).
				append(ptr->manID).
				append(ptr->manLV).
				append(ptr->battleValue).
				append(ptr->toAttriJson())
				;
			player->sendToClientFillMsg(gate_client::player_man_rank_detail_resp, json);
			return;
		}
		Return(r, err_illedge);
	}

	void ManBattleRank::RankList(net::Msg& m, Json::Value& r)
	{
		playerDataPtr player = player_mgr.getPlayer(m.playerID);
		if (!player)Return(r, err_illedge);//�Ƿ�����
		qValue json(qJson::qj_array);
		ptrRankData ownData;
		int rankNo = -1;
		for (unsigned i = 0; i < Rank.size(); ++i)
		{
			ptrRankData ptr = Rank[i];
			json.append(
				qValue(qJson::qj_array).
				append(ptr->playerID).
				append(ptr->playerName).
				append(ptr->manID).
				append(ptr->manLV).
				append(ptr->battleValue)
			);
			if (!ownData && ptr->playerID == player->ID())
			{
				ownData = ptr;
				rankNo = i + 1;
			}
		}
		player->sendToClientFillMsg(gate_client::player_man_battle_rank_resp,
			qValue(qJson::qj_array).
			append(res_sucess).
			append(json).
			append(rankNo).
			append(ownData ? ownData->manID : player->Man().MaxMan()).
			append(ownData ? ownData->battleValue : player->Man().MaxManBV())
		);
	}

	void ManBattleRank::updateInfo(playerDataPtr player)
	{
		for (unsigned i = 0; i < Rank.size(); ++i)
		{
			ptrRankData ptr = Rank[i];
			if (ptr->playerID == player->ID())
			{
				ptr->playerName = player->Name();
			}
		}
	}

	void ManBattleRank::updatePlayer(playerDataPtr player, playerManPtr man)
	{
		updatePlayer(player, *man);
	}

	static bool RankSort(const RankData& left, const RankData& right)
	{
		if (left.battleValue != right.battleValue)return left.battleValue > right.battleValue;
		if (left.manLV != right.manLV)return left.manLV > right.manLV;
		const int OwnStar = left.manID % 100;
		const int OtherStar = right.manID % 100;
		if (OwnStar != OtherStar)return OwnStar > OtherStar;
		if (left.manID != right.manID)return left.manID < right.manID;
		return left.playerID < right.playerID;
	}

	static bool RankSort(ptrRankData left, ptrRankData right)
	{
		return RankSort(*left, *right);
	}

	void ManBattleRank::updatePlayer(playerDataPtr player, playerMan& man)
	{
		ptrRankData ptr = getData(player->ID(), man.ID());
		bool down_key = false;
		if (ptr)//�ȸ��·ǹ�Ҫ����
		{
			const RankData old_data = *ptr;
			ptr->setNewData(player, man);
			if (RankSort(old_data, *ptr))
			{
				down_key = true;
			}
		}
		else
		{
			ptr = Creator<RankData>::Create(player, man);
			if (Rank.size() >= 100 && Rank.back()->battleValue > ptr->battleValue)return;
			Rank.push_back(ptr);
		}
		if (ptr->isNull())return;
		Player[FindKey(ptr->playerID, ptr->rawID())] = ptr;
		std::sort(Rank.begin(), Rank.end(), (bool(*)(ptrRankData, ptrRankData))RankSort);
		if (Rank.size() > 100)
		{
			ptrRankData back_ptr = Rank.back();
			Rank.pop_back();
			Player.erase(FindKey(back_ptr->playerID, back_ptr->rawID()));
		}
		if(Rank.size() == 100)
		{
			ptrRankData rank_99 = Rank[99];
			ptrRankData rank_98 = Rank[98];
			if (down_key && rank_99 == ptr)
			{
				mongo::Query find_query(BSON("cbv" << BSON("$gte" << rank_99->battleValue << "$lte" << rank_98->battleValue)));
				find_query.sort(strPlayerID, 1).sort("mid", 1).sort("q", -1).sort("lv", -1).sort("cbv", -1);
				objCollection objs = db_mgr.QueryCustom(DBN::dbPlayerMan, find_query, 3);
				for (unsigned i = 0; i < objs.size(); ++i)
				{
					mongo::BSONObj& obj = objs[i];
					const int playerID = obj[strPlayerID].Int();
					const int rawID = obj["mid"].Int() / 100;
					if (playerID == rank_99->playerID &&
						rawID == rank_99->rawID())continue;
					if (playerID == rank_98->playerID &&
						rawID == rank_98->rawID())continue;
					playerDataPtr back_player = player_mgr.getPlayer(playerID);
					if (back_player)
					{
						playerManPtr man = back_player->Man().findManRaw(rawID);
						if (man)
						{
							ptrRankData check_ptr = Creator<RankData>::Create(back_player, man);
							if (RankSort(check_ptr, ptr))
							{
								Player.erase(FindKey(ptr->playerID, ptr->rawID()));
								Rank[99] = check_ptr;
								Player[FindKey(check_ptr->playerID, check_ptr->rawID())] = check_ptr;
								break;
							}
						}
					}
				}
			}
		}
	}

}

//###################################
//create by Jim
//2016-04-14
//###################################

#pragma once

#include "dbDriver.h"

#define compensate_sys (*gg::compensate::_Instance)

namespace gg
{
	class compensate
	{
	public:
		static compensate* const _Instance;
		void initData();
		void tickLevel(const unsigned from, const unsigned to);
		void tryGetCompenstate(playerDataPtr player, const unsigned from, const unsigned to);
	};
}
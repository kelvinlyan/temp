#include "game_handle.h"
#include "common_protocol.h"
#include "gate_game_protocol.h"
#include "game_log_protocol.h"
#include "gate_account_protocol.h"
#include "mongoDB.h"
#include "game_server.h"
#include "service_config.h"
#include "gm_tools.h"
#include "playerManager.h"

using namespace gate_client;
namespace gg
{
	handler::handler()
	{
		Regist();
	}

	handler::CallFunction::CallFunction()
	{
		resp_ = -1;
	}

	handler::~handler()
	{

	}

	void handler::recv_client_handler(net::linkLocalPtr session, net::Msg& m)
	{
		session->keep_alive();
		State::setState(m.protocolID);
		NumberCounter::Step();
		despatch(m);
	}

	//gm tools
	void handler::recv_local_handler(net::linkLocalPtr session, net::Msg& m)
	{
		session->keep_alive();
		State::setState(m.protocolID);
		NumberCounter::Step();
		if (m.protocolID == game_protocol::comomon::keep_alive_req)
		{
			string str;
			net::Msg mj(-1, service::process_id::GAME_NET_ID, game_protocol::comomon::keep_alive_resp,str);
			session->write_buffer(mj);
			return;
		}
		despatch(m);
	}

	void handler::reg_func(const short command_id, const short response_id, handler_function func)
	{
		CallFunction f;
		f.resp_ = response_id;
		f.f_ = func;
		func_keeper[command_id] = f;
	}

	void handler::despatch(net::Msg& m)
	{
		try
		{
			//cout << "type:" << m.protocolID << "\tplayer_id:" << m.playerID << endl;
			Json::Value resp_json = Json::Value::null;
			//��������Э��Ų��Ұ󶨵ĺ���
			function_keeper::iterator it = func_keeper.find(m.protocolID);
			if(it == func_keeper.end())return;
			CallFunction& f = it->second;
			//���ð󶨵ĺ���
			f.f_(m,resp_json);
			helper_mgr._run_tick();
			//resp_jsonΪ��ʱ�������κ����ݣ���������һ���Ѿ������ˣ�
			if(!resp_json.isNull() && f.resp_ != -1){
				string str = resp_json.toIndentString();
				net::Msg mj(m.playerID, m.netID, f.resp_, str);
				game_svr->async_send_to_gate(mj);
			}
		}catch(std::exception& e)
		{
			LogE << "type:" << m.protocolID << ", pid:" << m.playerID << ", " << e.what() << LogEnd;
		}
	}
}

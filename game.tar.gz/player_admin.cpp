#include "player_admin.h"
#include "dbDriver.h"
#include "player_man.h"
#include "task_mgr.h"
#include "ownerland_system.h"

namespace gg
{
	namespace ADMIN
	{
		void Data::clear()
		{
			Own().Admin().useManList.erase(manID);
			manID = -1;
			endTime = 0;
			addTimes = 0;
			containType = 0;
		}
	}

	playerAdmin::playerAdmin(playerData* const own) : _auto_player(own)
	{
		timerID = ptrTimerIdentify();
		for (unsigned i = 0; i < LAND::FEOD_NUM; ++i)
		{
			ADMIN::AdminList& list_data = Admin[i];
			for (unsigned idx = 0; idx < LAND::idx_adminType_num; ++idx)
			{
				list_data.push_back(Creator<ADMIN::Data>::Create(own, i, idx));
			}
		}
	}

	void playerAdmin::classLoad()
	{
		mongo::BSONObj key = BSON(strPlayerID << Own().ID());
		mongo::BSONObj obj = db_mgr.FindOne(DBN::dbPlayerAdmin, key);
		if (obj.isEmpty())return;
		vector<mongo::BSONElement> vec = obj["arr"].Array();
		for (unsigned i = 0; i < vec.size(); ++i)
		{
			mongo::BSONElement& elem = vec[i];
			const int iFeod = elem["if"].Int();
			if (iFeod < LAND::FEOD_START || iFeod > LAND::FEOD_END)continue;
			const int iType = elem["it"].Int();
			if (iType < LAND::idx_adminType_begin || iType > LAND::idx_adminType_end)continue;
			ADMIN::dataPtr data_ptr = Admin[iFeod][iType];
			data_ptr->manID = elem["mid"].Int();
			data_ptr->endTime = unsigned(elem["et"].Int());
			data_ptr->addTimes = elem["ats"].Int();
			if (elem["cts"].eoo())
			{
				data_ptr->containType = ownerland_sys.FullContainType();
			}
			else
			{
				data_ptr->containType = elem["cts"].Int();
			}
			useManList.insert(data_ptr->manID);
		}
	}

	bool playerAdmin::_auto_save()
	{
		mongo::BSONObj key = BSON(strPlayerID << Own().ID());
		mongo::BSONArrayBuilder arr;
		for (unsigned i = 0; i < LAND::FEOD_NUM; ++i)
		{
			const ADMIN::AdminList& list_data = Admin[i];
			for (unsigned idx = 0; idx < LAND::idx_adminType_num; ++idx)
			{
				ADMIN::dataPtr data_ptr = list_data[idx];
				arr << BSON("if" << data_ptr->iFeod << "it" <<
					data_ptr->type << "mid" << data_ptr->manID <<
					"et" << data_ptr->endTime << "ats" << data_ptr->addTimes <<
					"cts" << data_ptr->containType);
			}
		}
		mongo::BSONObj obj = BSON(strPlayerID << Own().ID() << 
			"arr" << arr.arr());
		return db_mgr.SaveMongo(DBN::dbPlayerAdmin, key, obj);
	}

	void playerAdmin::_auto_update()
	{
		qValue json(qJson::qj_array);
		for (unsigned i = 0; i < LAND::FEOD_NUM; ++i)
		{
			ADMIN::AdminList& list_data = Admin[i];
			for (unsigned idx = 0; idx < LAND::idx_adminType_num; ++idx)
			{
				qValue sg_json(qJson::qj_array);
				ADMIN::dataPtr data_ptr = list_data[idx];
				sg_json.append(data_ptr->iFeod);
				sg_json.append(data_ptr->type);
				data_ptr->checkOver();//��������Ƿ��ȥ
				playerManPtr man = Own().Man().findManRaw(data_ptr->manID);
				if (man)
				{
					sg_json.append(man->mID());
				}
				else
				{
					data_ptr->clear();
					sg_json.append(data_ptr->manID);
				}
				sg_json.append(data_ptr->endTime);
				sg_json.append(data_ptr->addTimes);
				sg_json.append(data_ptr->containType);
				json.append(sg_json);
			}
		}
		qValue send_json(qJson::qj_array);
		send_json.append(res_sucess);
		send_json.append(json);
		//����
		Own().sendToClientFillMsg(gate_client::building_land_admin_resp, send_json);
	}

	unsigned playerAdmin::getNoFreshContain(const int iFeod, const LAND::LandAdminType type)
	{
		if (iFeod < LAND::FEOD_START || iFeod > LAND::FEOD_END)return 0;
		if (type < LAND::idx_adminType_begin || type > LAND::idx_adminType_end)return 0;
		return (Admin[iFeod][type])->containType;
	}

	unsigned playerAdmin::getNoFreshEndTime(const int iFeod, const LAND::LandAdminType type)
	{
		if (iFeod < LAND::FEOD_START || iFeod > LAND::FEOD_END)return 0;
		if (type < LAND::idx_adminType_begin || type > LAND::idx_adminType_end)return 0;
		return (Admin[iFeod][type])->endTime;
	}

	cfgManPtr playerAdmin::getNoFreshAdmin(const int iFeod, const LAND::LandAdminType type)
	{
		if (iFeod < LAND::FEOD_START || iFeod > LAND::FEOD_END)return cfgManPtr();
		if (type < LAND::idx_adminType_begin || type > LAND::idx_adminType_end)return cfgManPtr();
		playerManPtr man = Own().Man().findManRaw((Admin[iFeod][type])->manID);
		if (!man)return cfgManPtr();
		return man->getConfig();
	}

	int playerAdmin::addAppoint(const int iFeod, const LAND::LandAdminType type, const unsigned aTime)
	{
		if (iFeod < LAND::FEOD_START || iFeod > LAND::FEOD_END)return err_illedge;
		if (type < LAND::idx_adminType_begin || type > LAND::idx_adminType_end)return err_illedge;
		ADMIN::dataPtr data_ptr = Admin[iFeod][type];
		if (data_ptr->checkOver())return err_illedge;
		if (data_ptr->addTimes >= 20)return err_max_appoint_count;//�����Լ�������ʱ��
		if (data_ptr->endTime - Common::gameTime() + aTime >= 12 * HOUR)return err_admin_add_time_over_12_once;//���β���������12��Сʱ
		data_ptr->endTime += aTime;
		++data_ptr->addTimes;
		_sign_auto();
		Log(DBLOG::strLogManAppoint, Own().getOwnDataPtr(), 2, iFeod, type, data_ptr->manID, aTime,
			Common::toStampTime(data_ptr->endTime));
		return res_sucess;
	}

	int playerAdmin::appointMan(const int iFeod, const LAND::LandAdminType type, const int manID, const unsigned containType)
	{
		if (iFeod < LAND::FEOD_START || iFeod > LAND::FEOD_END)return err_illedge;
		if (type < LAND::idx_adminType_begin || type > LAND::idx_adminType_end)return err_illedge;
		ADMIN::dataPtr data_ptr = Admin[iFeod][type];
		//if (!data_ptr->checkOver())return err_illedge;
		if (data_ptr->checkOver())
		{
			if (useManList.find(data_ptr->manID) != useManList.end())return err_admin_same_man;
			playerManPtr man = Own().Man().findMan(manID);
			if (!man)return err_man_no_found;
			cfgManPtr config = man->getConfig();
			data_ptr->manID = man->ID();
			data_ptr->containType = containType;
			data_ptr->endTime = Common::gameTime() + config->appoint;
			useManList.insert(data_ptr->manID);
			TaskMgr::update(Own().getOwnDataPtr(), Task::AppointManNum);
			if (type == LAND::idx_adminType_builder)//����ǽ�����
			{
				Own().BuildTeam().tryFullWork(iFeod);//������������
			}
			Log(DBLOG::strLogManAppoint, Own().getOwnDataPtr(), 0, iFeod, type, man->ID(), config->appoint,
				Common::toStampTime(data_ptr->endTime), containType);
		}
		else
		{
			if (type == LAND::idx_adminType_builder)//����ǽ�����
			{
				if (type != data_ptr->type)return err_illedge;
				playerManPtr man = Own().Man().findMan(manID);
				if (!man)return err_man_no_found;
				if (man->ID() != data_ptr->manID)return err_illedge;
				cfgManPtr config = man->getConfig();
				data_ptr->containType = containType;
				Own().BuildTeam().tryFullWork(iFeod);//������������
				Log(DBLOG::strLogManAppoint, Own().getOwnDataPtr(), 0, iFeod, type, manID, config->appoint,
					Common::toStampTime(data_ptr->endTime), containType);
			}
			else
			{
				return err_illedge;
			}
		}
		_sign_auto();
		return res_sucess;
	}

	int playerAdmin::outgoingMan(const int iFeod, const LAND::LandAdminType type)
	{
		if (iFeod < LAND::FEOD_START || iFeod > LAND::FEOD_END)return err_illedge;
		if (type < LAND::idx_adminType_begin || type > LAND::idx_adminType_end)return err_illedge;
		ADMIN::dataPtr data_ptr = Admin[iFeod][type];
		if (data_ptr->checkOver())return err_illedge;
		Log(DBLOG::strLogManAppoint, Own().getOwnDataPtr(), 1, iFeod, type, data_ptr->manID);
		data_ptr->clear();
		_sign_auto();
		return res_sucess;
	}

	int playerAdmin::getAddTimes(const int iFeod, const LAND::LandAdminType type)
	{
		if (iFeod < LAND::FEOD_START || iFeod > LAND::FEOD_END)return 0;
		if (type < LAND::idx_adminType_begin || type > LAND::idx_adminType_end)return 0;
		ADMIN::dataPtr data_ptr = Admin[iFeod][type];
		if (data_ptr->checkOver())return 0;
		return data_ptr->addTimes;
	}

	void playerAdmin::clearAdmin()
	{
		bool is_save = false;
		for (unsigned i = 0; i < LAND::FEOD_NUM; ++i)
		{
			const ADMIN::AdminList& list_data = Admin[i];
			for (unsigned idx = 0; idx < LAND::idx_adminType_num; ++idx)
			{
				ADMIN::dataPtr data_ptr = list_data[idx];
				if (data_ptr->checkOver())
				{
					is_save = true;
				}
			}
		}
		if (is_save)_sign_auto();
	}

	cfgManPtr playerAdmin::getVaildAdmin(const int iFeod, const LAND::LandAdminType type)
	{
		if (iFeod < LAND::FEOD_START || iFeod > LAND::FEOD_END)return cfgManPtr();
		if (type < LAND::idx_adminType_begin || type > LAND::idx_adminType_end)return cfgManPtr();
		ADMIN::dataPtr data_ptr = Admin[iFeod][type];
		data_ptr->checkOver();
		playerManPtr man = Own().Man().findManRaw(data_ptr->manID);
		if (!man)return cfgManPtr();
		return man->getConfig();
	}

	unsigned playerAdmin::getVaildContain(const int iFeod, const LAND::LandAdminType type)
	{
		if (iFeod < LAND::FEOD_START || iFeod > LAND::FEOD_END)return 0;
		if (type < LAND::idx_adminType_begin || type > LAND::idx_adminType_end)return 0;
		ADMIN::dataPtr data_ptr = Admin[iFeod][type];
		data_ptr->checkOver();
		return data_ptr->containType;
	}

	void playerAdmin::adminTick(const structTimer& timerData, const int playerID)
	{
		playerDataPtr player = player_mgr.getOnlinePlayer(playerID);
		if (!player)return;
		for (int i = 0; i < LAND::FEOD_NUM; ++i)
		{
			if (bool(player->Admin().getVaildAdmin(i, LAND::idx_adminType_builder)))
			{
				//�����Ч
				player->BuildTeam().tryFullWork(i);
			}
		}
		player->Admin().addTimer();
	}

	void playerAdmin::addTimer()
	{
		timerID = Timer::AddEventSeconds(boostBind(playerAdmin::adminTick, _1, Own().ID()), Inter::event_land_admin_five_min, 5 * MINUTE);
	}

	void playerAdmin::delTimer()
	{
		if (timerID)
		{
			timerID->delTimer();
		}
		timerID = ptrTimerIdentify();
	}

}

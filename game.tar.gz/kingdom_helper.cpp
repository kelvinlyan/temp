#include "kingdom_helper.h"
#include "kingdom_system.h"
#include "heroparty_system.h"

namespace gg
{
	const static int KingdomRankSize = 100;
	const static std::string KeyRank[Kingdom::nation_num] = {"rank0", "rank1", "rank2"};
	const static std::string KeyInfo[Kingdom::nation_num] = {"info0", "info1", "info2"};

	KingdomConstructionConf::KingdomConstructionConf(const Json::Value& info)
	{
		_id = info["id"].asInt();
		_open_lv = info["kingdomLv"].asInt();
		const Json::Value& exps = info["exp"];
		ForEachC(Json::Value, it, exps)
			_exp.push_back((*it).asInt());
		const Json::Value& add_nums = info["addNum"];
		ForEachC(Json::Value, it, add_nums)
			_add_num.push_back((*it).asInt());
	}

	void KingdomContributionConf::load(const Json::Value& info)
	{
		const Json::Value& silver_num = info["silverNum"];
		ForEachC(Json::Value, it, silver_num)
			_silver_cost.push_back((*it).asInt());
		const Json::Value& silver_con = info["silverConNum"];
		ForEachC(Json::Value, it, silver_con)
			_silver_con.push_back((*it).asInt());
		const Json::Value& silver_con_self = info["silverConNumSelf"];
		ForEachC(Json::Value, it, silver_con_self)
			_silver_con_self.push_back((*it).asInt());

		const Json::Value& gold_num = info["goldNum"];
		ForEachC(Json::Value, it, gold_num)
			_gold_cost.push_back((*it).asInt());
		const Json::Value& gold_con = info["goldConNum"];
		ForEachC(Json::Value, it, gold_con)
			_gold_con.push_back((*it).asInt());
		const Json::Value& gold_con_self = info["goldConNumSelf"];
		ForEachC(Json::Value, it, gold_con_self)
			_gold_con_self.push_back((*it).asInt());
	}

	KingdomShopConf::KingdomShopConf(const Json::Value& info)
	{
		_id = info["id"].asInt();
		_consume_con = info["consumeCon"].asInt();
		_buy_times = info["buynum"].asInt();
		_weight = info["weight"].asInt();
		_kingdom_id = (Kingdom::NATION)info["nation"].asInt();
		Json::Value box = info["box"];
		_box = actionFormatBox(box);
	}

	KingdomConstructionData::KingdomConstructionData(int id)
		: _id(id), _total_exp(0)
	{
		init();
	}

	void KingdomConstructionData::load(const mongo::BSONElement& obj)
	{
		_total_exp = obj["t"].Int();
		init();
	}

	mongo::BSONObj KingdomConstructionData::toBSON() const
	{
		return BSON("i" << _id << "t" << _total_exp);
	}

	void KingdomConstructionData::getInfo(Json::Value& info) const
	{
		info.append(_lv);
		info.append(_exp);
	}

	void KingdomConstructionData::init()
	{
		_lv = 0;
		_exp = _total_exp;
		_add_num = 0;
		KingdomConstructionConfPtr conf = kingdom_sys.getConstructionConf(_id);
		if (conf)
		{
			_add_num = conf->_add_num[_lv];
			while (_lv < conf->_exp.size() 
				&& _exp >= conf->_exp[_lv])
			{
				_exp -= conf->_exp[_lv];
				++_lv;
				_add_num = (_lv >= conf->_add_num.size())?
					conf->_add_num.back() : conf->_add_num[_lv];
			}
		}
	}

	void KingdomConstructionData::alterExp(int num)
	{
		_exp += num;
		_total_exp += num;
		KingdomConstructionConfPtr conf = kingdom_sys.getConstructionConf(_id);
		if (conf)
		{
			while (_lv < conf->_exp.size() 
				&& _exp >= conf->_exp[_lv])
			{
				_exp -= conf->_exp[_lv];
				++_lv;
				_add_num = (_lv >= conf->_add_num.size())?
					conf->_add_num.back() : conf->_add_num[_lv];
			}
		}
	}

	bool KingdomConstructionData::upgradeAble() const
	{
		KingdomConstructionConfPtr conf = kingdom_sys.getConstructionConf(_id);
		return (conf && _lv < conf->_exp.size());
	}
	KingdomConInfo::KingdomConInfo(playerDataPtr d)
	{
		_pid = d->ID();
		_cons = d->KingDom().getTotalCon();
	}

	void KingdomConInfo::getInfo(Json::Value& info, int rk) const
	{
		info.append(rk);
		playerDataPtr d = player_mgr.getPlayer(_pid);
		info.append(d? d->Name() : "");
		info.append(_pid);
		info.append(_cons);
		info.append(d? d->KingDom().getJoinTime() : 0);
	}

	KingdomConRank::KingdomConRank()
		: _info(Json::arrayValue)
	{
	}

	std::string KingdomConRank::toBSON() const
	{
		return _info.toIndentString();
	}

	void KingdomConRank::load(const mongo::BSONElement& obj)
	{
		_info = Common::string2json(obj.String());
	}

	void KingdomConRank::tick()
	{
		_info = Json::arrayValue;
		_rk = 0;
		_rank.run(boostBind(KingdomConRank::packageInfo, this, _1), 0, KingdomRankSize);
	}

	void KingdomConRank::packageInfo(const KingdomConInfo& con)
	{
		Json::Value tmp;
		con.getInfo(tmp, ++_rk);
		_info.append(tmp);
	}
	
	void KingdomConRank::update(playerDataPtr d, int old_con)
	{
		if (d->KingDom().getTotalCon() < _rank.minV()
				&& _rank.size() >= KingdomRankSize)
			return;
		if (old_con < _rank.minV())
			old_con = 0;
		KingdomConPtr ptr = Creator<KingdomConInfo>::Create(d);
		_rank.update(ptr, old_con);
	}

	void KingdomConRank::insert(const KingdomConPtr& ptr)
	{
		_rank.update(ptr, 0);
	}

	KingdomInfo::KingdomInfo(Kingdom::NATION n)
		: _nation(n), _strength_rank(2), _hero_party_info(Json::arrayValue)
	{
		
	}

	void KingdomInfo::init()
	{
		for (unsigned i = Kingdom::CBegin + 1; i < Kingdom::CEnd; ++i)
			_constructions.push_back(Creator<KingdomConstructionData>::Create(i));
		loadInfo();
		loadRank();
	}

	void KingdomInfo::loadInfo()
	{
		mongo::BSONObj key = BSON("key" << KeyInfo[_nation]);
		mongo::BSONObj obj = db_mgr.FindOne(DBN::dbKingdom, key);

		if (obj.isEmpty())
			return;

		_player_num = obj["pn"].Int();
		_announcement = obj["an"].String();
		std::vector<mongo::BSONElement> ele = obj["cn"].Array();
		for (unsigned i = 0; i < ele.size(); ++i)
		{
			int id = ele[i]["i"].Int();
			if (id <= Kingdom::CBegin || id >= Kingdom::CEnd)
				continue;
			_constructions[id - 1]->load(ele[i]);
		}
	}

	static bool CmpKingdomConPtr(const KingdomConPtr& a, const KingdomConPtr& b)
	{
		if (a->value() == b->value())
			return a->id() < b->id();
		return a->value() > b->value();
	}

	void KingdomInfo::loadRank()
	{
		objCollection objs = db_mgr.Query(DBN::dbPlayerKingdom);
		std::vector<KingdomConPtr> sorted_player;
		ForEachC(objCollection, it, objs)
		{
			int pid = (*it)[strPlayerID].Int();
			int con = (*it)["to"].Int();
			if (con > 0)
				sorted_player.push_back(Creator<KingdomConInfo>::Create(pid, con));
		}
		
		std::sort(sorted_player.begin(), sorted_player.end(), CmpKingdomConPtr);
		for (unsigned i = 0; i < sorted_player.size(); ++i)
		{
			if (i >= KingdomRankSize 
				&& sorted_player[i]->value() != sorted_player[i-1]->value())
				break;
			_con_rank.insert(sorted_player[i]);
		}

		mongo::BSONObj key = BSON("key" << KeyRank[_nation]);
		mongo::BSONObj obj = db_mgr.FindOne(DBN::dbKingdom, key);

		if (obj.isEmpty())
			return;
		
		_con_rank.load(obj["cr"]);
		std::string hero_party_rank = obj["hr"].String();
		_hero_party_info = Common::string2json(hero_party_rank);
		_strength_rank = obj["sr"].Int();
	}

	void KingdomInfo::saveInfo()
	{
		mongo::BSONObj key = BSON("key" << KeyInfo[_nation]);
		mongo::BSONObjBuilder obj;
		obj << "key" << KeyInfo[_nation] << "pn" << _player_num << "an" << _announcement;
		{
			mongo::BSONArrayBuilder b;
			ForEachC(KingdomConstructionDatas, it, _constructions)
				b.append((*it)->toBSON());
			obj << "cn" << b.arr();
		}
		db_mgr.SaveMongo(DBN::dbKingdom, key, obj.obj());
	}

	void KingdomInfo::saveRank()
	{
		mongo::BSONObj key = BSON("key" << KeyRank[_nation]);
		mongo::BSONObjBuilder obj;
		obj << "key" << KeyRank[_nation] << "sr" << _strength_rank
		    << "cr" << _con_rank.toBSON() << "hr" << Common::json2string(_hero_party_info);
		db_mgr.SaveMongo(DBN::dbKingdom, key, obj.obj());
	}
	
	bool KingdomInfo::_auto_save()
	{
		saveInfo();
		return true;
	}

	void KingdomInfo::tickHeroParty()
	{
		_hero_party_info = Json::arrayValue;
		std::vector<heroPartyPtr> vec = heroparty_sys.sendChart(_nation);
		for (unsigned i = 0; i < vec.size(); ++i)
		{
			const heroPartyPtr& ptr = vec[i];
			Json::Value tmp;
			tmp.append(i + 1);
			tmp.append(ptr->sPlayerName);
			tmp.append(ptr->iPlayerID);
			tmp.append(ptr->iHeroNo);
			tmp.append(ptr->uiPlayerLV);
			_hero_party_info.append(tmp);
		}
	}

	void KingdomInfo::tick()
	{
		_con_rank.tick();
		tickHeroParty();
		_strength_rank = kingdom_sys.getStrengthRank(_nation);
		saveRank();
	}

	int KingdomInfo::join(playerDataPtr d)
	{
		int res = d->KingDom().addKingdom(_nation);
		if (res == res_sucess)
		{
			++_player_num;
			_sign_save();
		}
		return res;
	}

	int KingdomInfo::setAnnouncement(playerDataPtr d, const std::string& str)
	{
		if (d->Info().NationOf_() != Kingdom::GuoWang)
			return err_illedge;
		_announcement = str;
		_sign_save();
		return res_sucess;
	}

	void KingdomInfo::update(playerDataPtr d, int old_con)
	{
		_con_rank.update(d, old_con);
	}

	void KingdomInfo::getConRank(Json::Value& info) const
	{
		info = _con_rank.getInfo();
	}

	void KingdomInfo::getHeroPartyRank(Json::Value& info) const
	{
		info = _hero_party_info;
	}

	void KingdomInfo::getConstruction(Json::Value& info) const
	{
		const static std::string KeyConstruction[] = {"1", "2", "3", "4", "5", "6", "7", "8", "9"};
		Json::Value& ref = info["bi"];
		ref = Json::objectValue;
		ForEachC (KingdomConstructionDatas, it, _constructions)
		{
			const std::string& key = KeyConstruction[(*it)->id() - 1];
			(*it)->getInfo(ref[key]);
		}
		info["rt"] = kingdom_sys.getRate(_strength_rank);
	}

	int KingdomInfo::playerCon(playerDataPtr d, int id, int type)
	{
		const KingdomConstructionConfPtr conf = kingdom_sys.getConstructionConf(id);
		if (!conf) return err_illedge;
		if (id != Kingdom::CLevel && getLevel() < conf->_open_lv)
			return err_illedge;
		KingdomConstructionDataPtr ptr = _constructions[id-1];
		if (!ptr) return err_illedge;
		if (!ptr->upgradeAble())
			return err_illedge;
		int exp = 0;
		int res = d->KingDom().playerCon(type, exp);
		if (res == res_sucess)
		{
			ptr->alterExp(exp);
			d->Daily().tickTask(DAILY::kingdom_contribute);
			Log(DBLOG::strLogKingdom, d, 2, type, id, exp, ptr->lv(), getLevel());
			kingdom_sys.updateBuilding(d);
			_sign_save();
		}
		return res;
	}

	int KingdomInfo::addConstuctionExp(int id, int exp)
	{
		KingdomConstructionDataPtr ptr = _constructions[id-1];
		if (!ptr) return err_illedge;
		if (!ptr->upgradeAble())
			return err_illedge;
		ptr->alterExp(exp);
		_sign_save();
		return res_sucess;
	}

	void KingdomInfo::getBaseInfo(Json::Value& info) const
	{
		info["id"] = _nation;
		info["lv"] = getLevel();
		info["ann"] = _announcement; 
		info["st"] = _strength_rank;
		info["ra"] = getRate();
	}

	int KingdomInfo::getTotalLv() const
	{
		int sum = 0;
		ForEachC(KingdomConstructionDatas, it, _constructions)
			sum += (*it)->lv();
		return sum;
	}

	int KingdomInfo::getAddNum(int type) const
	{
		if (type <= Kingdom::CLevel || type >= Kingdom::CEnd)
			return 0;
		return _constructions[type-1]->addNum();
	}

	int KingdomInfo::getLevel() const
	{
		return _constructions[Kingdom::CLevel-1]->lv();
	}

	int KingdomInfo::getRate() const
	{
		return kingdom_sys.getRate(_strength_rank);
	}
}

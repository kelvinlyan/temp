#include "kingfight_system.h"
#include "game_time.h"
#include "chat.h"

namespace gg
{
	namespace KingFight
	{
		enum
		{
			LvLimit = 23,	
		};
	};

	kingfight_system* const kingfight_system::_Instance = new kingfight_system();

	kingfight_system::kingfight_system()
		: _silver_index(0)
	{
	}

	void kingfight_system::initData()
	{
		setSilverIndex();
		setBroadcastTimer();
		KingFight::Manager::setHandler();
		for(unsigned i = 0; i < Kingdom::nation_num; ++i)
		{
			KingFightManager ptr = Creator<KingFight::Manager>::Create(i);
			ptr->init();
			_manager.push_back(ptr);
		}
	}

	void kingfight_system::showUI(net::Msg& m, Json::Value& r)
	{
		playerDataPtr d = player_mgr.getPlayer(m.playerID);
		if (!d || d->Info().Nation() == Kingdom::null) 
			Return(r, err_illedge);
		if (d->LV() < KingFight::LvLimit)
			Return(r, err_lv_not_enough);
		
		_manager[d->Info().Nation()]->getInfo(d, r[strMsg][1u]);
		Return(r, res_sucess);
	}

	void kingfight_system::challengeCrown(net::Msg& m, Json::Value& r)
	{
		playerDataPtr d = player_mgr.getPlayer(m.playerID);
		if (!d || d->Info().Nation() == Kingdom::null) 
			Return(r, err_illedge);
		if (d->LV() < KingFight::LvLimit)
			Return(r, err_lv_not_enough);
		
		ReadJsonArray;
		int side = js_msg[0u].asInt();
		if (side < 1 || side > 2)
			Return(r, err_illedge);
		int res = _manager[d->Info().Nation()]->challenge(d, side-1);
		Return(r, res);
	}

	void kingfight_system::reFightTime(net::Msg& m, Json::Value& r)
	{
		playerDataPtr d = player_mgr.getPlayer(m.playerID);
		if (!d || d->Info().Nation() == Kingdom::null) 
			Return(r, err_illedge);
		if (d->LV() < KingFight::LvLimit)
			Return(r, err_lv_not_enough);
		
		int res = d->KingFight().clearCd();
		if (res == res_sucess)
			r[strMsg][1u] = 0;
		Return(r, res);
	}

	void kingfight_system::guessCrown(net::Msg& m, Json::Value& r)
	{
		playerDataPtr d = player_mgr.getPlayer(m.playerID);
		if (!d || d->Info().Nation() == Kingdom::null) 
			Return(r, err_illedge);
		if (d->LV() < KingFight::LvLimit)
			Return(r, err_lv_not_enough);

		ReadJsonArray;
		int side = js_msg[0u].asInt();
		int type = js_msg[1u].asInt();
		if (side < 1 || side > 2 || type < 1 || type > 2)
			Return(r, err_illedge);
		int res = _manager[d->Info().Nation()]->bet(d, side-1, type);
		Return(r, res);
	}

	void kingfight_system::receiveReward(net::Msg& m, Json::Value& r)
	{
		playerDataPtr d = player_mgr.getPlayer(m.playerID);
		if (!d || d->Info().Nation() == Kingdom::null) 
			Return(r, err_illedge);
		if (d->LV() < KingFight::LvLimit)
			Return(r, err_lv_not_enough);
		
		int res = d->KingFight().getReward();
		Return(r, res);
	}

	void kingfight_system::showOfficialsUI(net::Msg& m, Json::Value& r)
	{
		playerDataPtr d = player_mgr.getPlayer(m.playerID);
		if (!d || d->Info().Nation() == Kingdom::null) 
			Return(r, err_illedge);
		if (d->LV() < KingFight::LvLimit)
			Return(r, err_lv_not_enough);
		
		_manager[d->Info().Nation()]->getTitleInfo(r[strMsg][1u]);
		Return(r, res_sucess);
	}
	
	void kingfight_system::anOfficial(net::Msg& m, Json::Value& r)
	{
		playerDataPtr d = player_mgr.getPlayer(m.playerID);
		if (!d || d->Info().Nation() == Kingdom::null) 
			Return(r, err_illedge);
		if (d->LV() < KingFight::LvLimit)
			Return(r, err_lv_not_enough);
		
		ReadJsonArray;
		int autoed = js_msg[0u].asInt();	
		int res;
		if (autoed == 1)
			res = _manager[d->Info().Nation()]->autoSetTitle(d);
		else
		{
			int title = js_msg[1u].asInt();
			std::string name = js_msg[2u].asString();
			res = _manager[d->Info().Nation()]->setTitle(d, name, title);
		}
		Return(r, res);
	}

	void kingfight_system::showBeforOfficial(net::Msg& m, Json::Value& r)
	{
		playerDataPtr d = player_mgr.getPlayer(m.playerID);
		if (!d || d->Info().Nation() == Kingdom::null) 
			Return(r, err_illedge);
		if (d->LV() < KingFight::LvLimit)
			Return(r, err_lv_not_enough);
		ReadJsonArray;
		int begin = js_msg[0u].asInt();
		int end = js_msg[1u].asInt();
		
		_manager[d->Info().Nation()]->getTermInfo(r[strMsg][1u], begin, end);
		Return(r, res_sucess);
	}

	int kingfight_system::winSilver() const
	{
		static const int Silver[] = {600000, 700000, 800000};
		return Silver[_silver_index];
	}

	int kingfight_system::loseSilver() const
	{
		static const int Silver[] = {200000, 400000, 600000};
		return Silver[_silver_index];
	}

	int kingfight_system::betSilver() const
	{
		static const int Silver[] = {20000, 40000, 80000};
		return Silver[_silver_index];
	}

	void kingfight_system::setSilverIndex()
	{
		unsigned cur_time = Common::gameTime();
		unsigned day_time = Common::timeZero(cur_time) + 5 * HOUR;
		unsigned open_time = season_sys.openTime();
		if (day_time - open_time < 90 * DAY)
		{
			_silver_index = 0;
			Timer::AddEventTickTime(boostBind(kingfight_system::setSilverIndex, this), Inter::event_king_fight_timer, open_time + 90 * DAY);
			//Timer2::add(open_time + 90 * DAY, boostBind(kingfight_system::setSilverIndex, this));
		}
		else if (day_time - open_time < 180 * DAY)
		{
			_silver_index = 1;
			Timer::AddEventTickTime(boostBind(kingfight_system::setSilverIndex, this), Inter::event_king_fight_timer, open_time + 180 * DAY);
			//Timer2::add(open_time + 180 * DAY, boostBind(kingfight_system::setSilverIndex, this));
		}
		else
		{
			_silver_index = 2;
		}
	}

	const KingFightManager kingfight_system::getData(int nation) const
	{
		return _manager[nation];
	}

	void kingfight_system::broadcastAt2125()
	{
		Json::Value roll_msg;
		roll_msg.append(1);
		Json::Value extra_json;
		extra_json["weight"] = 0;
		extra_json["roll"] = 2;
		chat_sys.despatchAllSP(CHAT::server_kingfight_state, roll_msg, extra_json, CHATPOS::scroll_bar_top | CHATPOS::chat_windows);
		unsigned next_broadcast_time = season_sys.getNSTimeHMS(SEASON::Spring, 21, 25);
		Timer::AddEventSeconds(boostBind(kingfight_system::broadcastAt2125, this), Inter::event_king_fight_timer, next_broadcast_time);
		//Timer2::add(next_broadcast_time, boostBind(kingfight_system::broadcastAt2125, this));
	}

	void kingfight_system::setBroadcastTimer()
	{
		unsigned next_broadcast_time = season_sys.getNSTimeHMS(SEASON::Spring, 21, 25);
		Timer::AddEventTickTime(boostBind(kingfight_system::broadcastAt2125, this), Inter::event_king_fight_timer, next_broadcast_time);
		//Timer2::add(next_broadcast_time, boostBind(kingfight_system::broadcastAt2125, this));
	}

	void kingfight_system::updateName(playerDataPtr d)
	{
		if (d->Info().Nation() == Kingdom::null)
			return;

		_manager[d->Info().Nation()]->updateName(d);
	}
}

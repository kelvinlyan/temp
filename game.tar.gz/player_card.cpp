#include "player_card.h"
#include "dbDriver.h"
#include "card_system.h"
#include "task_mgr.h"

namespace gg
{
	static vector<unsigned> cfgExpSeq;
	static vector<unsigned> cfgTotalExpSeq;

	unsigned playerCard::MaxLevel()
	{
		return cfgExpSeq.size();
	}

	playerCard::playerCard(playerData* const own, const int cID) : _auto_player(own)
	{
		cardID = cID;
		level = 1;
		exp = 0;
		alive = true;
		bind = false;
		lock = false;
	}

	void playerCard::Delete()
	{
		alive = false;//������ڲ����, ��ô���¼�������
		if (lock)
		{
			Own().Card().tryRmFM(cardID);
		}
		_sign_auto();
	}

	void playerCard::setInfo(const unsigned lv, const unsigned ex)
	{
		const unsigned tmpLevel = level;
		if (lv >= cfgExpSeq.size())
		{
			level = cfgExpSeq.size();
		}
		else
		{
			level = lv;
		}
		exp = ex;
		upgrade();
		_sign_auto();
		if (tmpLevel != level)
		{
			if(lock)Own().Card().tryRecal(cardID);
			Log(DBLOG::strLogPlayerCard, Own().getOwnDataPtr(), 3, rawID(), ID(), tmpLevel, level);
		}
	}

	cfgCardPtr playerCard::getConfig()
	{
		if (!handlerCfg)handlerCfg = card_sys.getConfig(rawID());
		return handlerCfg;
	}

	unsigned playerCard::toExp()
	{
		return cfgTotalExpSeq[level] + exp;
	}

	void playerCard::upgrade()
	{
		for (unsigned idx = level; idx < cfgExpSeq.size(); ++idx)
		{
			if (exp >= cfgExpSeq[idx])
			{
				exp -= cfgExpSeq[idx];
				level = idx + 1;
				continue;
			}
			break;
		}
		if (level >= cfgExpSeq.size())
		{
			exp = 0;
		}
	}

	void playerCard::setBind(const bool bt /* = true */)
	{
		bind = bt;
		_sign_auto();
	}

	int playerCard::addExp(const unsigned num)
	{
		if (level >= cfgExpSeq.size())return err_card_level_max;
		if (num < 1)return err_illedge;
		int tmpLevel = level;
		exp += num;
		upgrade();
		if (tmpLevel != level)
		{
			if(lock)Own().Card().tryRecal(cardID);
			Log(DBLOG::strLogPlayerCard, Own().getOwnDataPtr(), 3, rawID(), ID(), tmpLevel, level);
			TaskMgr::update(Own().getOwnDataPtr(), Task::CardMaxLv);
		}
		_sign_auto();
		return res_sucess;
	}

	void playerCard::_auto_end()
	{
		if (!alive)
		{
			Own().Card().memDeleteCard(cardID);
		}
	}

	bool playerCard::_auto_save()
	{
		mongo::BSONObj key = BSON(strPlayerID << Own().ID() << "cid" << cardID);
		if (alive)
		{
			mongo::BSONObj obj = BSON(strPlayerID << Own().ID() << "cid" << cardID <<
				"exp" << exp << "lv" << level << "b" << bind);
			return db_mgr.SaveMongo(DBN::dbPlayeCard, key, obj);
		}
		else
		{
			db_mgr.RemoveCollection(DBN::dbPlayeCard, key);
			return true;
		}
	}

	bool playerCard::_on_sign_update()
	{
		Own().Card().tickCard(cardID);
		return false;
	}

	//mgr
	playerCardMgr::playerCardMgr(playerData* const own) : _auto_player(own)
	{
		mapCard.clear();
		mapFCard.clear();
		fmUpdate = false;
		operationTime = 0;
		memset(attri, 0x0, sizeof(attri));
	}

	void playerCardMgr::initData()
	{
		{//�����
			cfgExpSeq.clear();
			Json::Value json = Common::loadJsonFile("./instance/cardconfig/exp.json");
			for (unsigned i = 0; i < json.size(); ++i)
			{
				unsigned ug_exp = json[i].asUInt();
				cfgExpSeq.push_back(ug_exp);
			}
		};

		{//�ܾ����
			cfgTotalExpSeq.clear();
			for (unsigned i = 0; i < (cfgExpSeq.size() + 1); ++i)
			{
				cfgTotalExpSeq.push_back(i == 0 ? 0 : (cfgTotalExpSeq[i - 1] + cfgExpSeq[i - 1]));
			}
		};
	}

	const unsigned playerCardMgr::BagCap = 90;

// 	int playerCardMgr::zeroAttri[characterNum] = {
// 		0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
// 		0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
// 		0, 0, 0, 0, 0, 0, 0, 0, 0, 0 
// 	};
// 	double playerCardMgr::zeroAttriRate[characterNum] = {
// 		0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
// 		0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
// 		0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0
// 	};

	void playerCardMgr::tickCard(const int cardID)
	{
		updateList.insert(cardID);
		_sign_update();
	}

	void playerCardMgr::tryRecal(const int cardID)
	{
		for (unsigned i = 0; i < 5; ++i)
		{
			if (fomation[i] && fomation[i]->ID() == cardID)
			{
				recalAttri();
				break;
			}
		}
	}

	bool playerCardMgr::_auto_save()
	{
		mongo::BSONObj  key = BSON(strPlayerID << Own().ID());
		mongo::BSONArrayBuilder arr;
		for (unsigned i = 0; i < 5; ++i)
		{
			if (!fomation[i])arr << -1;
			else arr << fomation[i]->ID();
		}
		mongo::BSONObj obj = BSON(strPlayerID << Own().ID() << "fm" << arr.arr());
		return db_mgr.SaveMongo(DBN::dbPlayeCardFM, key, obj);
	}

	void playerCardMgr::_auto_update()
	{
		{
			qValue cardJson(qJson::qj_object), data_list(qJson::qj_array), cards(qJson::qj_array);
			for (INTSET::iterator it = updateList.begin(); it != updateList.end(); ++it)
			{
				playerCardPtr ptr = getCard(*it);
				if (!ptr)continue;
				qValue card(qJson::qj_array);
				card.append(ptr->ID());
				card.append(ptr->LV());
				card.append(ptr->EXP());
				card.append(ptr->Alive());
				card.append(ptr->Bind());
				cards.append(card);
			}
			data_list.append(res_sucess);
			data_list.append(cards);
			cardJson.addMember(strMsg, data_list);
			Own().sendToClient(gate_client::player_card_update_resp, cardJson);
			updateList.clear();
		};

		{
			if (fmUpdate)
			{
				fmUpdate = false;
				Json::Value fmJson;
				fmJson[strMsg][0u] = res_sucess;
				Json::Value& fm = fmJson[strMsg][1u] = Json::arrayValue;
				for (unsigned i = 0; i < 5; ++i)
				{
					if (!fomation[i])fm.append(-1);
					else fm.append(fomation[i]->ID());
				}
				fmJson[strMsg][2u] = operationTime + 2;
				Own().sendToClient(gate_client::player_card_format_resp, fmJson);
			}
		};
	}

	Json::Value playerCardMgr::gmFormatPackage()
	{
		Json::Value fmJson = Json::arrayValue;
		for (unsigned i = 0; i < 5; ++i)
		{
			if (!fomation[i])fmJson.append(Json::arrayValue);
			else
			{
				Json::Value card;
				card.append(fomation[i]->ID());
				card.append(fomation[i]->LV());
				card.append(fomation[i]->EXP());
				card.append(fomation[i]->Bind());
				fmJson.append(card);
			}
		}
		return fmJson;
	}

	Json::Value playerCardMgr::gmCardsPackage()
	{
		Json::Value cardJson;
		for (CardMap::iterator it = mapCard.begin(); it != mapCard.end(); ++it)
		{
			playerCardPtr ptr = it->second;
			if (ptr->Alive())
			{
				Json::Value card;
				card.append(ptr->ID());
				card.append(ptr->LV());
				card.append(ptr->EXP());
				card.append(ptr->Bind());
				cardJson.append(card);
			}
		}
		return cardJson;
	}

	qValue playerCardMgr::investPackage()
	{
		qValue data_list(qJson::qj_array);
		for (unsigned i = 0; i < 5; ++i)
		{
			playerCardPtr ptr = fomation[i];
			qValue tmp(qJson::qj_array);
			if (ptr)
			{
				tmp.append(ptr->rawID());
				tmp.append(ptr->LV());
				tmp.append(ptr->EXP());
			}
			data_list.append(tmp);
		}
		return data_list;
	}

	void playerCardMgr::updateAll()
	{
		{//��Ƭ��Ϣ
			qValue cardJson(qJson::qj_object), data_list(qJson::qj_array), cards(qJson::qj_array);
			for (CardMap::iterator it = mapCard.begin(); it != mapCard.end(); ++it)
			{
				playerCardPtr ptr = it->second;
				if (!ptr)continue;
				qValue card(qJson::qj_array);
				card.append(ptr->ID());
				card.append(ptr->LV());
				card.append(ptr->EXP());
				card.append(ptr->Alive());
				card.append(ptr->Bind());
				cards.append(card);
			}
			data_list.append(res_sucess);
			data_list.append(cards);
			cardJson.addMember(strMsg, data_list);
			Own().sendToClient(gate_client::player_card_update_resp, cardJson);
		};

		{
			Json::Value fmJson;
			fmJson[strMsg][0u] = res_sucess;
			Json::Value& fm = fmJson[strMsg][1u] = Json::arrayValue;
			for (unsigned i = 0; i < 5; ++i)
			{
				if (!fomation[i])fm.append(-1);
				else fm.append(fomation[i]->ID());
			}
			fmJson[strMsg][2u] = operationTime + 2;
			Own().sendToClient(gate_client::player_card_format_resp, fmJson);
		};
	}

	bool playerCardMgr::removeCard(const int cardID)
	{
		playerCardPtr ptr = getCard(cardID);
		if (!ptr)return false;
		ptr->Delete();
		return true;
	}

	vector<playerCardPtr> playerCardMgr::addCard(const int cardID, const unsigned num, const unsigned level /* = 0 */)
	{
		vector<playerCardPtr> vec;
		if (num < 1)return vec;
		if (isOver(num))return vec;
		cfgCardPtr config = card_sys.getConfig(cardID);
		if (!config)return vec;
		CreateNewCard(cardID, num, level == 0 ? config->beginLevel : level, vec);
		return vec;
	}

	int playerCardMgr::resAddCard(const int cardID, const unsigned num, const unsigned level /* = 0 */)
	{
		if (num < 1)return err_illedge;
		if (isOver(num))return err_card_bag_over;
		cfgCardPtr config = card_sys.getConfig(cardID);
		if (!config)return err_illedge;
		return CreateNewCard(cardID, num, level == 0 ? config->beginLevel : level);
	}

	int playerCardMgr::invest(const int fm[5])
	{
		const unsigned playerLV = Own().LV();
		if (playerLV < 30)return err_illedge;
		playerCardPtr cards[5];
		INTSET tmp_s;
		for (unsigned i = 0; i < 5; ++i)
		{
			if (fm[i] < 0)continue;
			if (!tmp_s.insert(fm[i] / 1000).second)return err_illedge;
			if (!(cards[i] = getCard(fm[i])))return err_card_no_find;
			if (i == 2 && playerLV < 40)return err_illedge;//����
			if (i == 3 && (playerLV < 50 || cards[i]->getConfig()->stars < 3))return err_illedge;//����
			if (i == 4 && (playerLV < 55 || cards[i]->getConfig()->stars < 4))return err_illedge;//�ʺ�
		}
		FMSET = tmp_s;
		for (unsigned i = 0; i < 5; ++i)
		{
			if (fomation[i])
			{
				fomation[i]->lock = false;
			}
			if (cards[i])
			{
				cards[i]->lock = true;
			}
			fomation[i] = cards[i];
		}
		fmUpdate = true;
		recalAttri();
		_sign_auto();
		TaskMgr::update(Own().getOwnDataPtr(), Task::CardInvestNum);
		TaskMgr::update(Own().getOwnDataPtr(), Task::CardGroupNum);
		return res_sucess;
	}

	void playerCardMgr::classLoad()
	{
		mongo::BSONObj key = BSON(strPlayerID << Own().ID());
		{//card
			mapCard.clear();
			objCollection collection = db_mgr.Query(DBN::dbPlayeCard, key);
			if (collection.empty())return;
			for (unsigned i = 0; i < collection.size(); ++i)
			{
				mongo::BSONObj cObj = collection[i];
				int id = cObj["cid"].Int();
				playerCardPtr card = Creator<playerCard>::Create(_Own, id);
				card->level = (unsigned)cObj["lv"].Int();
				card->exp = (unsigned)cObj["exp"].Int();
				card->bind = cObj["b"].Bool();
				mapCard[id] = card;
				mapFCard[card->rawID()][card->ID()] = card;
			}
		};
		//ͼ�����������Ůͷ��

		{//fm
			FMSET.clear();
			mongo::BSONObj obj = db_mgr.FindOne(DBN::dbPlayeCardFM, key);
			if (!obj.isEmpty())
			{
				vector<mongo::BSONElement> elems = obj["fm"].Array();
				for (unsigned i = 0; i < 5 && i < elems.size(); ++i)
				{
					fomation[i] = getCard(elems[i].Int());
					if (fomation[i])
					{
						fomation[i]->lock = true;
						FMSET.insert(fomation[i]->rawID());
					}
				}
			}
			recalAttri(false);
		};
	}

	void playerCardMgr::recalAttri(const bool recalMan /* = true */)
	{
		memset(attri, 0x0, sizeof(attri));
		for (unsigned i = 0; i < 5; ++i)
		{
			if (!fomation[i])continue;
			playerCardPtr card = fomation[i];
			cfgCardPtr config = card->getConfig();
			const vector<int>& tmp_attri = config->attriSeq[card->LV()];
			for (unsigned n = 0; n < characterNum; ++n)
			{
				attri[n] += tmp_attri[n];
			}
			//��ϼӳ�
			for (unsigned n = 0; n < config->groupSET.size();++n)
			{
				bool active = true;
				const cardConfig::Group& group = config->groupSET[n];
				for (unsigned loop_idx = 0; loop_idx < group.size(); ++loop_idx)
				{
					if (FMSET.find(group[loop_idx]) == FMSET.end())
					{
						active = false;
						break;
					}
				}
				if (active)
				{
					const vector<int>& gtmp_attri = config->groupAttri[n];
					for (unsigned idx = 0; idx < characterNum; ++idx)
					{
						attri[idx] += gtmp_attri[idx];
					}
				}
			}
		}
		if (recalMan)
		{
			Own().Man().recalMan();
		}
	}

	void playerCardMgr::tryRmFM(const int cardID)
	{
		if (FMSET.find(cardID) != FMSET.end())
		{
			FMSET.erase(cardID);
			for (unsigned i = 0; i < 5; ++i)
			{
				if (fomation[i] && fomation[i]->ID() == cardID)
				{
					fomation[i]->lock = false;
					fomation[i] = playerCardPtr();
					TaskMgr::update(Own().getOwnDataPtr(), Task::CardInvestNum);
					_sign_auto();
					break;
				}
			}
			recalAttri();
		}
	}

	void playerCardMgr::memDeleteCard(const int cardID)
	{
		mapCard.erase(cardID);
		mapFCard[cardID / 1000].erase(cardID);
		TaskMgr::update(Own().getOwnDataPtr(), Task::CardTotalNum);
	}

	playerCardPtr playerCardMgr::getCard(const int cardID)
	{
		CardMap::iterator it = mapCard.find(cardID);
		if (it ==mapCard.end())return playerCardPtr();
		return it->second;
	}

	int playerCardMgr::CreateNewCard(const int cardID, const unsigned num, const unsigned level)
	{
		vector<playerCardPtr> vec;
		return CreateNewCard(cardID, num, level, vec);
	}

	int playerCardMgr::CreateNewCard(const int cardID, const unsigned num, const unsigned level, vector<playerCardPtr>& vec)
	{
		if (level < 1 || num < 1)return err_illedge;
		int beginID = cardID * 1000;//��ʼID
		for (unsigned i = 0; i < num; ++i)
		{
			do
			{
				if (!getCard(beginID++))
				{
					playerCardPtr card = Creator<playerCard>::Create(_Own, beginID - 1);
					card->level = level;
					vec.push_back(card);
					break;
				}
				if (beginID / 1000 != cardID)
				{
					vec.clear();
					return err_card_bag_over;
				}
			} while (true);
		}
		for (unsigned i = 0; i < vec.size(); ++i)
		{
			playerCardPtr card = vec[i];
			mapCard[card->ID()] = card;
			mapFCard[cardID][card->ID()] = card;
			Own().Poke().signPoke(card->rawID());
			card->_sign_auto();
		}
		TaskMgr::update(Own().getOwnDataPtr(), Task::CardTotalNum);
		return res_sucess;
	}

	int playerCardMgr::fmSize() const
	{
		int sum = 0;
		for (unsigned i = 0; i < 5; ++i)
		{
			if (fomation[i])
				++sum;
		}
		return sum;
	}

	//playercard base
	playerCardTs::playerCardTs(playerData* const own) : _auto_player(own)
	{
		sT = 20;
		gT = 30;
		sL = 5;
		sLCD = 0;
		gLCD = 0;
		gLMTimes = 0;
		gLHMTimes = 0;
		ssLTimes = 0;
		ShowCardCD = 0;
		totalTimes = 0;
	}

	void playerCardTs::classLoad()
	{
		mongo::BSONObj key = BSON(strPlayerID << Own().ID());
		mongo::BSONObj obj = db_mgr.FindOne(DBN::dbPlayeCardBase, key);
		if (!obj.isEmpty())
		{
			sT = obj["st"].Int();
			gT = obj["gt"].Int();
			sL = obj["sl"].Int();
			sLCD = (unsigned)obj["slcd"].Int();
			gLCD = (unsigned)obj["glcd"].Int();
			gLMTimes = obj["glmts"].eoo() ? 0 : obj["glmts"].Int();
			gLHMTimes = obj["glhmts"].eoo() ? 0 : obj["glhmts"].Int();
			ssLTimes = obj["sslts"].eoo() ? 0 : obj["sslts"].Int();
			totalTimes = obj["ttlts"].eoo() ? 0 : obj["ttlts"].Int();
		}
	}

	void playerCardTs::subGT()
	{
		--gT;
		_sign_auto();
	}

	void playerCardTs::subST()
	{
		--sT;
		_sign_auto();
	}

	void playerCardTs::subSL()
	{
		--sL;
		_sign_auto();
	}

	void playerCardTs::setSLCD()
	{
		sLCD = Common::gameTime() + 5 * MINUTE;
		//tickTotalTimes();
		_sign_auto();
	}

	void playerCardTs::setGLCD()
	{
		gLCD = Common::gameTime() + 24 * HOUR;
		//tickTotalTimes();
		_sign_auto();
	}

	void playerCardTs::tickTotalTimes(int times)
	{
		totalTimes += times;
		TaskMgr::update(Own().getOwnDataPtr(), Task::CardLotteryTimes);
	}

	void playerCardTs::tickGLMT()
	{
		++gLMTimes;
		//tickTotalTimes();
		_sign_auto();
	}

	void playerCardTs::tickGLHMT()
	{
		++gLHMTimes;
		//tickTotalTimes();
		_sign_auto();
	}

	void playerCardTs::tickSSLottery()
	{
		++ssLTimes;
		//tickTotalTimes();
		_sign_auto();
	}

	bool playerCardTs::_auto_save()
	{
		mongo::BSONObj key = BSON(strPlayerID << Own().ID());
		mongo::BSONObj obj = BSON(strPlayerID << Own().ID() <<
			"st" << sT << "gt" << gT << "sl" << sL <<
			"slcd" << sLCD << "glcd"<< gLCD << "glmts" << gLMTimes <<
			"glhmts" << gLHMTimes << "sslts" << ssLTimes << "ttlts" << totalTimes);
		return db_mgr.SaveMongo(DBN::dbPlayeCardBase, key, obj);
	}
		
	void playerCardTs::_auto_update()
	{
		Json::Value upJson;
		upJson[strMsg][0u] = res_sucess;
		Json::Value& tmsJson = upJson[strMsg][1u] = Json::arrayValue;
		tmsJson.append(sT);
		tmsJson.append(gT);
		tmsJson.append(sL);
		tmsJson.append(sLCD);
		tmsJson.append(gLCD);
		tmsJson.append(gLMTimes);
		tmsJson.append(gLHMTimes);
		tmsJson.append(ssLTimes);
		tmsJson.append(ShowCardCD);
		Own().sendToClient(gate_client::player_card_upif_resp, upJson);
	}

	int playerCardMgr::cardMaxLv() const
	{
		int max = 0;
		ForEachC(CardMap, it, mapCard)
		{
			if (it->second->LV() > max)
				max = it->second->LV();
		}
		return max;
	}

	int playerCardMgr::groupNum() const
	{
		int num = 0;
		for (unsigned i = 0; i < 5; ++i)
		{
			if (!fomation[i])continue;
			playerCardPtr card = fomation[i];
			cfgCardPtr config = card->getConfig();
			for (unsigned n = 0; n < config->groupSET.size();++n)
			{
				bool active = true;
				const cardConfig::Group& group = config->groupSET[n];
				for (unsigned loop_idx = 0; loop_idx < group.size(); ++loop_idx)
				{
					if (FMSET.find(group[loop_idx]) == FMSET.end())
					{
						active = false;
						break;
					}
				}
				if (active)
					++num;
			}
		}
		return num;
	}
}

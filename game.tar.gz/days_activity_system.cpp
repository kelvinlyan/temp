#include "days_activity_system.h"
#include "game_time.h"

namespace gg
{
	namespace DaysActivity
	{
		enum
		{
			ConfigKeyID = 10086,
		};
	}

	DayTarget::DayTarget(const Json::Value& info)
	{
		_count = info["cn"].asInt();
		Json::Value rw = info["rw"];
		_reward = actionFormatBox(rw);
		_reward_info = jsonFormats2c(rw);
	}

	DayTask::DayTask(const Json::Value& info)
	{
		_id = info["id"].asInt();
		_check_ptr = Task::Checker::create(info["cnn"]);
		Json::Value rw = info["rw"];
		_reward = actionFormatBox(rw);
		_reward_info = jsonFormats2c(rw);
	}

	DayActivity::DayActivity(const Json::Value& info)
	{
		unsigned cur_time = Common::gameTime();
		_key_id = info["kid"].asInt();
		_modify_time = info["mdt"].asUInt();
		_name = info["kna"].asString();
		_timer_id = cur_time;
		_state = -1;

		_gm_config = info;
		Json::Value& al = _gm_config["al"];
		_max_day = al.size();
		_cur_day = 0;
		_task_lists.assign(al.size(), DayTaskList());
		int task_count = 0;
		for (unsigned i = 0; i < al.size(); ++i)
		{
			Json::Value& type2task = al[i];
			for(unsigned j = 0; j < type2task.size(); ++j)
			{
				Json::Value& task = type2task[j]["tl"];
				for (unsigned k = 0; k < task.size(); ++k)
				{
					DayTaskPtr ptr = Creator<DayTask>::Create(task[k]);
					_task_map[ptr->_id] = ptr;
					_task_lists[i].push_back(ptr);
					++task_count;
				}
			}
		}
		Json::Value& tl = _gm_config["tl"];
		for (unsigned i = 0; i < tl.size(); ++i)
			_targets.push_back(Creator<DayTarget>::Create(tl[i]));
		Json::Value& ar = _gm_config["ar"];
		Json::Value tmp;
		tmp["cn"] = task_count;
		tmp["rw"] = ar["ty"].asInt() == 2? ar["rw"] : Json::arrayValue;
		_targets.push_back(Creator<DayTarget>::Create(tmp));
	}

	void DayActivity::setTimer()
	{
		unsigned cur_time = Common::gameTime();
		unsigned show_begin_time = _gm_config["sbt"].asUInt() + Common::timeZone() * HOUR;
		unsigned show_end_time = _gm_config["set"].asUInt() + Common::timeZone() * HOUR;
		unsigned run_begin_time = _gm_config["rbt"].asUInt() + Common::timeZone() * HOUR;
		unsigned run_end_time = _gm_config["ret"].asUInt() + Common::timeZone() * HOUR;

		if (cur_time >= show_begin_time)
			days_activity_sys.tickBeginShow(shared_from_this());
		else
			Timer::AddEventTickTime(boostBind(days_activity_system::tick, days_activity_system::_Instance, _timer_id, _key_id, (int)BeginShow), Inter::event_days_activity_timer, show_begin_time);

		if (cur_time >= run_begin_time)
			days_activity_sys.tickBeginRun(shared_from_this());
		else
			Timer::AddEventTickTime(boostBind(days_activity_system::tick, days_activity_system::_Instance, _timer_id, _key_id, (int)BeginRun), Inter::event_days_activity_timer, run_begin_time);

		if (cur_time >= run_end_time)
			days_activity_sys.tickEndRun(shared_from_this());
		else
			Timer::AddEventTickTime(boostBind(days_activity_system::tick, days_activity_system::_Instance, _timer_id, _key_id, (int)EndRun), Inter::event_days_activity_timer, run_end_time);

		/*if (cur_time >= show_end_time)
			days_activity_sys.tickEndShow(shared_from_this());
		else
			Timer::AddEventTickTime(boostBind(days_activity_system::tick, days_activity_system::_Instance, _timer_id, _key_id, (int)EndShow), Inter::event_days_activity_timer, show_end_time);
		*/
	}

	void DayActivity::resetCurDay()
	{		
		unsigned cur_time = Common::gameTime();
		unsigned run_begin_time = _gm_config["rbt"].asUInt() + Common::timeZone() * HOUR;;
		unsigned base_time = Common::getLastTimeTS(run_begin_time, 5 * HOUR);
		if (base_time == run_begin_time - DAY)
			base_time = run_begin_time;
		_cur_day = (cur_time - base_time) / DAY + 1;
		if (_cur_day > _max_day)
			_cur_day = _max_day;
	}
	
	days_activity_system* const days_activity_system::_Instance = new days_activity_system;

	days_activity_system::days_activity_system()
	{
	}

	void days_activity_system::initData()
	{
		loadFile();
		classLoad();
		tickDay();
	}

	void days_activity_system::activityInfoReq(net::Msg& m, Json::Value& r)
	{
		playerDataPtr d = player_mgr.getPlayer(m.playerID);
		if (!d) Return(r, err_illedge);

		if (!_cur_activity)
			r[strMsg][1u]["kid"] = -1;
		else
		{
			r[strMsg][1u]["kid"] = _cur_activity->_key_id;
			d->DaysActivity().checkAndUpdate();
		}
		Return(r, res_sucess);
	}
		
	void days_activity_system::playerInfoReq(net::Msg& m, Json::Value& r)
	{
		if (!_cur_activity)
			Return(r, err_illedge);

		playerDataPtr d = player_mgr.getPlayer(m.playerID);
		if (!d) Return(r, err_illedge);

		d->DaysActivity().update();
	}

	void days_activity_system::getRewardReq(net::Msg& m, Json::Value& r)
	{
		if (!_cur_activity)
			Return(r, err_illedge);

		playerDataPtr d = player_mgr.getPlayer(m.playerID);
		if (!d) Return(r, err_illedge);
		
		ReadJsonArray;
		int type = js_msg[0u].asInt();
		int id = js_msg[1u].asInt();

		int res;

		if (type == 0)
			res = d->DaysActivity().getTaskReward(id);
		else
			res = d->DaysActivity().getCountReward(id);
			
		if (res == res_sucess)
		{
			r[strMsg][1u] = _param;
			_param = Json::nullValue;
		}
		
		Return(r, res);
	}

	void days_activity_system::redPointReq(net::Msg& m, Json::Value& r)
	{
		if (!_cur_activity)
			Return(r, err_illedge);

		playerDataPtr d = player_mgr.getPlayer(m.playerID);
		if (!d) Return(r, err_illedge);
		
		d->DaysActivity().updateRedPoint(false);
	}

	void days_activity_system::gmIDListReq(net::Msg& m, Json::Value& r)
	{
		r[strMsg][1u]["cur"] = getKeyId();
		r[strMsg][1u]["nor"] = Json::arrayValue;

		ForEachC(DayActivityMap, it, _activity_map)
		{
			if (it->first != getKeyId())
				r[strMsg][1u]["nor"].append(it->first);
		}

		Return(r, res_sucess);
	}

	void days_activity_system::gmInfoReq(net::Msg& m, Json::Value& r)
	{
		ReadJsonArray;
		int key_id = js_msg[0u].asInt();

		ForEachC(DayActivityMap, it, _activity_map)
		{
			if (it->first == key_id)
			{
				DayActivityPtr ptr = it->second;
				r[strMsg][1u] = ptr->_gm_config;
				Return(r, res_sucess);
			}
		}

		Return(r, err_illedge);
	}

	void days_activity_system::gmModifyReq(net::Msg& m, Json::Value& r)
	{
		ReadJsonArray;
		const Json::Value& info = js_msg[0u];

		LogI << "days activity modify: " << info.toIndentString() << LogEnd;

		int key_id = info["kid"].asInt();

		if (info["set"].asUInt() == 0)
		{
			DayActivityMap::iterator it = _activity_map.find(key_id);
			if (it == _activity_map.end())
				Return(r, err_illedge);

			if (_cur_activity && _cur_activity->_key_id == key_id)
			{
				_cur_activity.reset();
				updateActivityInfo();
			}

			_activity_map.erase(it);
			saveDB();
			Return(r, res_sucess);
		}

		if (_cur_activity && _cur_activity->_key_id == key_id)
		{
			//if (_cur_activity->_state >= (int)DayActivity::BeginRun)
			//	Return(r, err_illedge);
			_cur_activity.reset();
			updateActivityInfo();
		}

		unsigned begin_time = info["sbt"].asUInt();// + Common::timeZone() * HOUR;
		unsigned end_time = info["set"].asUInt();// + Common::timeZone() * HOUR;
		if (!timeConflict(key_id, begin_time, end_time))
			Return(r, err_illedge);

		DayActivityPtr p = Creator<DayActivity>::Create(info);
		_activity_map[p->_key_id] = p;
		p->setTimer();

		saveDB();
		Return(r, res_sucess);
	}
	
	void days_activity_system::tick(int timer_id, int key_id, int event)
	{
		DayActivityMap::iterator it = _activity_map.find(key_id);
		if (it == _activity_map.end() || it->second->_timer_id != timer_id)
			return;
		
		switch(event)
		{
			case DayActivity::BeginShow:
				tickBeginShow(it->second);
				break;
			case DayActivity::EndShow:
				tickEndShow(it->second);
				break;
			case DayActivity::BeginRun:
				tickBeginRun(it->second);
				break;
			case DayActivity::EndRun:
				tickEndRun(it->second);
				break;
			default:
				break;
		}
	}

	void days_activity_system::tickBeginShow(const DayActivityPtr& p)
	{
		_cur_activity = p;
		_cur_activity->_state = Showing;
		updateActivityInfo();
	}

	void days_activity_system::tickEndShow(const DayActivityPtr& p)
	{
		_cur_activity.reset();
		_activity_map.erase(p->_key_id);
	}

	void days_activity_system::tickBeginRun(const DayActivityPtr& p)
	{
		_cur_activity->_state = Running;
		_cur_activity->resetCurDay();
	}

	void days_activity_system::tickEndRun(const DayActivityPtr& p)
	{
		sendEmail();
		//_cur_activity->_state = Showing;
		_activity_map.erase(p->_key_id);
		_cur_activity.reset();
		updateActivityInfo();
		saveDB();
	}

	void days_activity_system::tickDay()
	{
		unsigned cur_time = Common::gameTime();
		unsigned next_tick_time = Common::getNextTimeHMS(cur_time, 5);
		Timer::AddEventTickTime(boostBind(days_activity_system::tickDay, this), Inter::event_days_activity_timer, next_tick_time);

		if (!_cur_activity || _cur_activity->_state != Running)
			return;

		_cur_activity->resetCurDay();
	}

	void days_activity_system::update(playerDataPtr d, int type, int arg1, int arg2)
	{
		if (!_cur_activity || _cur_activity->_state != Running)
			return;
		
		d->DaysActivity().update(type, arg1, arg2);
	}

	void days_activity_system::loadFile()
	{
		/*
		unsigned cur_time = Common::gameTime();
		unsigned close_time = season_sys.openTime() + 7 * DAY;
		if (cur_time < close_time)
		{
			Json::Value json = Common::loadJsonFile("./instance/days_activity/config.json");
			json["kid"] = DaysActivity::ConfigKeyID;
			json["mdt"] = 0;
			json["rbt"] = season_sys.openTime();
			json["ret"] = close_time;
			json["sbt"] = season_sys.openTime();
			json["set"] = close_time;

			DayActivityPtr ptr = Creator<DayActivity>::Create(json);
			_activity_map[ptr->_key_id] = ptr;
			ptr->setTimer();
		}
		*/
	}

	void days_activity_system::saveDB()
	{
		mongo::BSONObj key = BSON("key" << 0);
		mongo::BSONObjBuilder obj;
		obj << "key" << 0;
		{
			mongo::BSONArrayBuilder b;
			ForEachC(DayActivityMap, it, _activity_map)
			{
				const Json::Value& config = it->second->_gm_config;
				int kid = config["kid"].asInt();
				if (kid != DaysActivity::ConfigKeyID)
					b.append(Common::json2string(config));
			}
			obj << "activity" << b.arr();
		}
		db_mgr.SaveMongo(DBN::dbDaysActivity, key, obj.obj());
	}

	void days_activity_system::classLoad()
	{
		mongo::BSONObj key = BSON("key" << 0);
		mongo::BSONObj obj = db_mgr.FindOne(DBN::dbDaysActivity, key);
		if (!obj.isEmpty())
		{
			checkNotEoo(obj["activity"])
			{
				std::vector<mongo::BSONElement> ele = obj["activity"].Array();
				for (unsigned i = 0; i < ele.size(); ++i)
				{
					std::string str = ele[i].String();
					DayActivityPtr ptr = Creator<DayActivity>::Create(Common::string2json(str));
					_activity_map[ptr->_key_id] = ptr;
					ptr->setTimer();
				}
			}
		}
	}

	int days_activity_system::getKeyId() const
	{
		if (!_cur_activity)
			return -1;
		return _cur_activity->_key_id;
	}

	unsigned days_activity_system::getModifyTime() const
	{
		if (!_cur_activity)
			return 0;
		return _cur_activity->_modify_time;
	}

	int days_activity_system::getDay() const
	{
		if (!_cur_activity)
			return 0;
		return _cur_activity->_cur_day;
	}

	bool days_activity_system::timeConflict(int key_id, unsigned begin_time, unsigned end_time)
	{
		if(begin_time >= end_time)
			return false;

		ForEach(DayActivityMap, it, _activity_map)
		{
			DayActivityPtr ptr = it->second;
			if (ptr->_key_id == key_id)
				continue;

			unsigned tmp_begin_time = ptr->_gm_config["sbt"].asUInt();
			unsigned tmp_end_time = ptr->_gm_config["set"].asUInt();

			if (begin_time >= tmp_begin_time && begin_time <= tmp_end_time)
				return false;
			if (end_time >= tmp_begin_time && end_time <= tmp_end_time)
				return false;
			if (begin_time <= tmp_begin_time && end_time >= tmp_end_time)
				return false;
		}
		return true;
	}

	DayTaskList days_activity_system::getDaysTask(int day)
	{
		if (!_cur_activity)
			return DayTaskList();

		if (day < 1 || day > _cur_activity->_max_day)
			return DayTaskList();

		return _cur_activity->_task_lists[day - 1];
	}

	void days_activity_system::updateActivityInfo()
	{
		Json::Value msg;

		msg[strMsg][0u] = 0;
		if (!_cur_activity)
			msg[strMsg][1u]["kid"] = 0;
		else
			msg[strMsg][1u]["kid"] = _cur_activity->_key_id;
		
		player_mgr.sendToAll(gate_client::days_activity_config_info_resp, msg);
	}

	DayTaskPtr days_activity_system::getTask(int id)
	{
		if (!_cur_activity)
			return DayTaskPtr();

		DayTaskMap::iterator it = _cur_activity->_task_map.find(id);
		if (it == _cur_activity->_task_map.end())
			return DayTaskPtr();
		return it->second;
	}

	DayTargetPtr days_activity_system::getTarget(int id)
	{
		if (!_cur_activity)
			return DayTargetPtr();

		if (id < 1 || id > _cur_activity->_targets.size())
			return DayTargetPtr();
		return _cur_activity->_targets[id - 1];
	}

	int days_activity_system::getTargetCount() const
	{
		if (!_cur_activity)
			return 0;
		return _cur_activity->_targets.size();
	}

	void days_activity_system::sendEmail()
	{
		objCollection objs = db_mgr.Query(DBN::dbPlayerDaysActivity);
		for (unsigned i = 0; i < objs.size(); ++i)
		{
			const mongo::BSONObj& obj = objs[i];
			int pid = obj[strPlayerID].Int();
			int key_id = obj["kid"].Int();
			if (key_id != _cur_activity->_key_id)
				continue;

			playerDataPtr d = player_mgr.getPlayer(pid);
			d->DaysActivity().sendEmail();
		}
	}
}

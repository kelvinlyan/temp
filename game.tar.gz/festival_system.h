#pragma once

#include "activity_mgr.h"
#include "action_system.h"
#include "dbDriver.h"

#define festival_sys (*gg::festival_system::_Instance)

namespace gg
{
	namespace nFestival
	{
		struct RandItem
		{
			RandItem(const Json::Value& info)
			{
				Json::Value rw = info["rw"];
				reward = actionFormatBox(rw);
				percent = info["per"].asInt();
				if (info["bc"] != Json::nullValue)
					bc = info["bc"].asBool();
				else
					bc = false;
			}
			ActionBoxList reward;
			int percent;
			bool bc;
		};
		STDVECTOR(RandItem, ItemList);
		struct Material
		{
			Material(const Json::Value& info)
			{
				item = info[0u].asInt();
				num = info[1u].asInt();
			}
			int item;
			int num;
		};
		STDVECTOR(Material, MaterialList);
		struct ExchangeItem
		{
			ExchangeItem(const Json::Value& info)
			{
				Json::Value rw = info["rw"];
				reward = actionFormatBox(rw);
				const Json::Value& fd = info["fd"];
				ForEachC(Json::Value, it, fd)
					materials.push_back(Material(*it));
			}
			ActionBoxList reward;
			MaterialList materials;
		};
		STDVECTOR(ExchangeItem, ExchangeItems);
		struct NpcItem
		{
			NpcItem(const Json::Value& info)
			{
				rand_percent = info["rand"].asInt();
				const Json::Value& rwl = info["rwl"];
				ForEachC(Json::Value, it, rwl)
					reward.push_back(RandItem(*it));
				if (info["nm"] != Json::nullValue)
					name = info["nm"].asString();
			}
			int rand_percent;
			ItemList reward;
			std::string name;
		};
		STDVECTOR(NpcItem, NpcItems);

		class RewardRecord
			: public _auto_meta
		{	
			public:
				RewardRecord(int key_id);

				void loadDB();
				void removeDB();

				void push(qValue& r);
				void update(playerDataPtr d);

			private:
				virtual bool _auto_save();

			private:
				const int _key_id;
				STDLIST(std::string, RecordList);
				RecordList _records;
		};

		BOOSTSHAREPTR(RewardRecord, RecordPtr);
	}

	class Festival
		: public ActivityBase
	{
		public:
			Festival(const Json::Value& info);
			virtual mongo::BSONObj toBSON() const;

			const Json::Value& ClientInfo() const { return _client_info; }

			bool exchangeIndexValid(int idx) const
			{
				return idx >= 0 && idx < _exchange_items.size();
			}
			const nFestival::ExchangeItem& exchangeItem(int idx) const
			{
				return _exchange_items[idx];
			}
			const ActionBoxList& turnTableReward(int& idx, bool& bc) const;
			const ActionBoxList& eggReward(int& idx, bool& bc) const;
			ActionBoxList npcReward(int type) const;
			const std::string& npcName(int type) const;
			int npcType() const;

			ActionBoxList worldExtra() const;
			ActionBoxList chapterExtra() const;
			ActionBoxList teamwarExtra() const;

			const Json::Value& data() const { return _data; }

			virtual void start();
			virtual void update();
			virtual void stop(bool timer_tick);

			void addRecord(qValue& q);
			void sendRecord(playerDataPtr d);

		private:
			nFestival::ItemList _turntable_items;
			nFestival::ItemList _egg_items;
			nFestival::NpcItems _npc_items;	
			nFestival::ExchangeItems _exchange_items;
			
			nFestival::ItemList _world_extra;
			nFestival::ItemList _chapter_extra;
			nFestival::ItemList _teamwar_extra;

			nFestival::RecordPtr _record;

			const Json::Value _data;
			Json::Value _client_info;
	};

	class festival_system
		: public ActivityMgr<Festival>
	{
		public:
			static festival_system* const _Instance;

			festival_system();
			void initData();

			DeclareRegFunction(playerInfo);
			DeclareRegFunction(buyTurnTableTimes);
			DeclareRegFunction(turnTable);
			DeclareRegFunction(throwEgg);
			DeclareRegFunction(exchangeMaterial);
			DeclareRegFunction(fightNpc);
			DeclareRegFunction(buyThrowEggTimes);

			DeclareRegFunction(gmIDList);
			DeclareRegFunction(gmInfo);
			DeclareRegFunction(gmModify);

			void sendInfo(playerDataPtr d = playerDataPtr());
			void sendNpc();
			void startTickTimer();
			void stopTickTimer();
			void broadcast();

		private:
			void loadDB();
			void tick(unsigned cur_time, int tick_hour);

			unsigned _tick_timer;
	};
}

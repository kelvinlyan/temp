#include "kingdomwar_shadow.h"
#include "kingdomwar_system.h"
#include "man_system.h"

namespace gg
{
	namespace KingdomWar
	{
		ShadowData::ShadowData(const mongo::BSONObj& obj)
		{
			_dead = false;
			_id = obj[strNpcID].Int();
			_army_hp = obj["h"].Int();
			_pos.type = obj["p"]["t"].Int();
			_pos.id = obj["p"]["i"].Int();
			_pos.time = obj["p"]["tm"].Int();
			_pos.from_id = obj["p"]["f"].Int();
			_ptr = createBattlePtr(obj["b"]);
			_max_man_hp = obj["mh"].Int();
		}

		ShadowData::ShadowData(playerDataPtr d, int army_id, const Position& pos, int hp, double rate)
		{
			_dead = false;
			_id = NpcIDCreator::shared().get();
			_pos = pos;
			_army_hp = hp;
			int tmp_hp = 0;
			_ptr = kingdomwar_sys.getBattlePtr(d, army_id, _max_man_hp, tmp_hp);
			_ptr->isPlayer = false;
			_ptr->playerName = getShadowName(d, SHADOW::PLAYER);
			int buff = rate * 10000;
			_max_man_hp = 0;
			ForEach(manList, it, _ptr->battleMan)
			{
				(*it)->currentHP = (*it)->getTotalAttri(idx_hp);
				_max_man_hp += (*it)->currentHP;

				(*it)->battleAttri[idx_phyHurtRate] += buff;
				(*it)->battleAttri[idx_warHurtRate] += buff;
				(*it)->battleAttri[idx_magicHurtRate] += buff;
				(*it)->battleAttri[idx_cureRate] += buff;
				(*it)->battleAttri[idx_phyCutRate] += buff;
				(*it)->battleAttri[idx_warCutRate] += buff;
				(*it)->battleAttri[idx_magicCutRate] += buff;
			}
			_ptr->battleValue = (double)_ptr->battleValue * (1.0 + rate);
		}

		ShadowData::~ShadowData()
		{
			if (!_dead)
				LogE << "Error Shadow ID:" << _id << ", Pos:" << _pos.id << LogEnd;
			else
				removeDB();
		}

		sBattlePtr ShadowData::createBattlePtr(const mongo::BSONElement& obj)
		{
			sBattlePtr sb = Creator<sideBattle>::Create();
			sb->playerID = obj["pi"].Int();
			sb->playerLevel = obj["lv"].Int();
			sb->playerName = obj["na"].String();
			sb->battleValue = obj["bv"].Int();
			sb->playerFace = obj["fa"].Int();
			sb->playerNation = obj["kid"].Int();
			sb->isPlayer = false;
			vector<mongo::BSONElement> elems = obj["m"].Array();
			for (unsigned n = 0; n < elems.size(); ++n)
			{
				mongo::BSONElement& elem = elems[n];
				mBattlePtr mb = Creator<manBattle>::Create();
				mb->manID = elem["mid"].Int();
				mb->manLevel = elem["lv"].Int();
				mb->currentIdx = (unsigned)elem["idx"].Int();
				mb->currentHP = elem["hp"].Int();
				mb->battleValue = elem["bv"].Int();
				vector<mongo::BSONElement> ias = elem["ias"].Array();
				for (unsigned idx = 0; idx < ias.size(); ++idx)
				{
					mb->initialAttri[idx] = ias[idx].Int();
				}
				vector<mongo::BSONElement> bas = elem["bas"].Array();
				for (unsigned idx = 0; idx < bas.size(); ++idx)
				{
					mb->battleAttri[idx] = bas[idx].Int();
				}
				cfgManPtr config = man_sys.getConfig(mb->manID);
				if (!config)continue;
				mb->set_skill_1(config->skill_1);
				mb->set_skill_2(config->skill_2);
				mb->armsType = config->armsType;
				memcpy(mb->armsModule, config->armsModules, sizeof(mb->armsModule));
				vector < mongo::BSONElement > eqs = elem["eqs"].Array();
				for (unsigned idx = 0; idx < eqs.size(); ++idx)
				{
					mongo::BSONElement& elem = eqs[idx];
					mb->equipList.push_back(BattleEquip(elem["i"].Int(), elem["l"].Int()));
				}
				if (sb->battleMan.empty())
				{
					sb->leaderMan = mb;
				}
				sb->battleMan.push_back(mb);
			}
			return sb;
		}
		
		mongo::BSONObj ShadowData::battlePtrBSON() const
		{
			mongo::BSONObjBuilder obj_builder;
			mongo::BSONArrayBuilder arr_builder;
			for (unsigned i = 0; i < _ptr->battleMan.size(); ++i)
			{
				const mBattlePtr& m = _ptr->battleMan[i];
				mongo::BSONArrayBuilder ias_builder, bas_builder;
				for (unsigned idx = 0; idx < characterNum; ++idx)
				{
					ias_builder.append(m->initialAttri[idx]);
					bas_builder.append(m->battleAttri[idx]);
				}
				mongo::BSONArrayBuilder eqs_builder;
				for (unsigned idx = 0; idx < m->equipList.size(); ++idx)
				{
					eqs_builder.append(BSON("i" << m->equipList[idx].equipID << "l" << m->equipList[idx].equipLevel));
				}
				arr_builder << BSON("mid" << m->manID << "lv" << m->manLevel << "idx" <<
					m->currentIdx << "ias" << ias_builder.arr() << "bas" << bas_builder.arr() 
					<< "hp" << m->currentHP << "bv" << m->battleValue << "eqs" << eqs_builder.arr());
			}
			obj_builder << strPlayerID << _ptr->playerID << "lv" << _ptr->playerLevel 
				<< "na" << _ptr->playerName << "bv" << _ptr->battleValue << "fa" << _ptr->playerFace 
				<< "m" << arr_builder.arr() << "kid" << _ptr->playerNation;
			return obj_builder.obj();
		}

		bool ShadowData::_auto_save()
		{
			mongo::BSONObj key = BSON(strNpcID << _id);
			mongo::BSONObjBuilder obj;
			obj << strNpcID << _id << "h" << _army_hp << "t" << (int)Shadow
				<< "p" << BSON("t" << _pos.type << "i" << _pos.id << "tm" << _pos.time << "f" << _pos.from_id)
				<< "b" << battlePtrBSON() << "mh" << _max_man_hp;
			return db_mgr.SaveMongo(DBN::dbKingdomWarNpc, key, obj.obj());
		}

		void ShadowData::fmInfo(qValue& q) const
		{
			for (unsigned i = 0; i < _ptr->battleMan.size(); ++i)
			{
				qValue tmp;
				tmp << _ptr->battleMan[i]->manID
					<< _ptr->battleMan[i]->currentHP
					<< _ptr->battleMan[i]->getTotalAttri(idx_hp)
					<< _ptr->battleMan[i]->manLevel;
				q.append(tmp);
			}
		}

		void ShadowData::setDead(unsigned cur_time, Json::Value& tips)
		{
			_dead = true;
			playerDataPtr d = player_mgr.getOnlinePlayer(ownID());
			if (!d || !d->KingDomWar().onMain()) return;
			qValue m;
			m.append(res_sucess);
			qValue q(qJson::qj_object);
			q.addMember("r", qValue(tips.toIndentString().c_str()));
			m.append(q);
			d->sendToClientFillMsg(gate_client::kingdom_war_shadow_dead_resp, m);
		}

		int ShadowData::alterHp(int num)
		{
			int pre_hp = _army_hp;
			_army_hp += num;
			if (_army_hp < 0)
				_army_hp = 0;
			_sign_save();
			return _army_hp - pre_hp;
		}
		
		bool ShadowData::isDead() const
		{
			if (_army_hp <= 0)
				return true;
			for (unsigned i = 0; i < _ptr->battleMan.size(); ++i)
			{
				if (_ptr->battleMan[i]->currentHP > 0)
					return false;
			}
			return true;
		}

		sBattlePtr ShadowData::getBattlePtr(int& max_hp, int& cur_hp)
		{
			max_hp = _max_man_hp;
			cur_hp = 0;
			for (unsigned i = 0; i < _ptr->battleMan.size(); ++i)
			{
				cur_hp += _ptr->battleMan[i]->currentHP;
			}
			return _ptr;
		}

		void ShadowData::setPosition(int type, int id, unsigned time)
		{
			if (_pos.type == PosCity)
				_pos.from_id = _pos.id;

			_pos.type = type;
			_pos.id = id;
			_pos.time = time;
			_sign_save();
		}
		
		void ShadowData::removeDB()
		{
			mongo::BSONObj key = BSON(strNpcID << _id);
			db_mgr.RemoveCollection(DBN::dbKingdomWarNpc, key);
		}

		int ShadowData::face() const
		{
			int max_bv = 0;
			int man_id = 0;
			for (unsigned i = 0; i < _ptr->battleMan.size(); ++i)
			{
				if (_ptr->battleMan[i]->battleValue > max_bv)
				{
					max_bv = _ptr->battleMan[i]->battleValue;
					man_id = _ptr->battleMan[i]->manID;
				}
			}
			return man_id;
		}

		int ShadowData::manHp() const
		{
			int sum = 0;
			for (unsigned i = 0; i < _ptr->battleMan.size(); ++i)
				sum += _ptr->battleMan[i]->currentHP;
			return sum;
		}
	}
}

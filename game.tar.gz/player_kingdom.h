#pragma once

#include "auto_base.h"
#include "mongoDB.h"
#include "man_def.h"

namespace gg
{
	struct KingdomSkillData
	{
		KingdomSkillData(int id);
		KingdomSkillData(const mongo::BSONElement& obj);

		mongo::BSONObj toBSON() const;
		void getInfo(Json::Value& info) const;

		int _id;
		int _lv;
	};

	BOOSTSHAREPTR(KingdomSkillData, KingdomSkillDataPtr);
	STDMAP(int, KingdomSkillDataPtr, KingdomSkillDatas);

	class playerKingdom
		: public _auto_player
	{
		public:
			playerKingdom(playerData* const own);

			virtual void classLoad();
			virtual bool _auto_save();
			virtual void _auto_update(); 

			void getInfo(Json::Value& info);
			void getSkillInfo(Json::Value& info) const;
			void updateSkill();

			int playerCon(int type, int& exp);
			void alterCon(int num);
			int upSkill(int id, int batch, Json::Value& r);
			int getTotalCon() const { return _total_con; }
			int getCurCon() const { return _cur_con; }
			unsigned getJoinTime() const { return _join_time; }
			int getSkillLvSum() const;
			unsigned allConTimes() const { return _all_con_times; }

			const int* getAttr();
			int addKingdom(int nation);
			int getSalary(Json::Value& r);

			void dailyTick();
		private:
			void resetAttr();

		private:
			int _con_times;
			int _total_con;
			int _cur_con;
			unsigned _all_con_times;
			unsigned _join_time;
			KingdomSkillDatas _skill_datas;

			unsigned _flush_times;

			bool _attrs_inited;
			int _attrs[characterNum];

			bool _get_salary;
	};
}

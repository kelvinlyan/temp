#pragma once

#include "auto_base.h"

namespace gg
{
	class playerSign
		: public _auto_player
	{	
		public:
			playerSign(playerData* const own);

			virtual void classLoad();
			virtual bool _auto_save();
			virtual void _auto_update();
			
			void update();
			void dailyTick();
			int getReward(int id, Json::Value& r);
			bool signedToday() const;

		private:
			void checkAndUpdate();

		private:
			unsigned _next_sign_time;
			unsigned _days;
			bool _first_reward;

			unsigned _reset_time;
	};
}

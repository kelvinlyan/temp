#pragma once

#include "expedition_data.h"
#include "dbDriver.h"

#define expedition_sys (*gg::expedition_system::_Instance)

namespace gg
{
	class expedition_system
	{
		public:
			static expedition_system* const _Instance;

			void initData();
			DeclareRegFunction(playerInfo);
			DeclareRegFunction(manInfo);
			DeclareRegFunction(challenge);
			DeclareRegFunction(flush);
			DeclareRegFunction(buyTimes);
			DeclareRegFunction(strategyInfo);
			DeclareRegFunction(formationInfo);
			DeclareRegFunction(setFormation);
			DeclareRegFunction(changeFormation);
			DeclareRegFunction(shadowInfo);
			DeclareRegFunction(getReward);
			DeclareRegFunction(mapData);
			DeclareRegFunction(dailyRank);
			DeclareRegFunction(historyRank);
			DeclareRegFunction(buy);
			DeclareRegFunction(mopUp);

			DeclareRegFunction(GmModifyProgress);

		private:
			void loadStrategy();
			void sendEmptyStrategy(playerDataPtr d);
			void upFMInfo(playerDataPtr& d, Expedition::MapPtr& ptr);

		private:
			BOOSTSHAREPTR(Expedition::Strategy, StrategyPtr);
			STDMAP(int, StrategyPtr, StrategyMap);
			StrategyMap _stragety_map;
	};
}

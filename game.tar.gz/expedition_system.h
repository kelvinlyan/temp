#pragma once

namespace gg
{
	namespace Expedition
	{
		struct CmpStrategy
		{
			CmpStrategy(int l, int r, int d)
				: lv(l), round_num(r), damage(d){}
			CmpStrategy(const mongo::BSONElement& obj)
			{
				lv = obj["l"].Int();
				round_num = obj["r"].Int();
				damage = obj["d"].Int();
			}
			mongo::BSONObj toBSON() const
			{
				return BSON("l" << lv << "r" << round_num << "d" << damage);
			}
			int lv;
			int round_num;
			int damage;
		};

		class Strategy
			: public _auto_meta
		{
			public:
				Strategy(int mid);
				Strategy(const mongo::BSONObj& obj);

				int mID() const { return _mid; }
				void push(qValue& q, const CmpStrategy& cmp);
				void update(playerDataPtr d);

			private:
				virtual bool _auto_save();
				bool better(const CmpStrategy& cmp) const;

			private:
				int _mid;
				std::string _first;
				std::string _best;
				CmpStrategy _cmp_best;
				STDLIST(std::string, List);
				List _recent;
		};
		
		class MapDataMgr
		{
			SINGLETON(MapDataMgr);
			public:
				sBattlePtr getBattlePtr(playerDataPtr d, int pos) const;
			
			private:
				void loadFile();

			private:
				struct Rank
				{
					int start_rank;
					int end_rank;
				};
				struct MapItem
				{
					MapItem(const Json::Value& info);
					int type;
					union
					{
						int npc_id;
						Rank rank;
					};
				};
				struct MapData
				{
					MapData(const Json::Value& info);
					int start_lv;
					int end_lv;
					STDVECTOR(MapItem, MapItemList);
					MapItemList map_item;
				};
				STDVECTOR(MapData, MapDataList);
				MapDataList _map_data;
				STDMAP(mapDataConfig, NpcDataMap);
				NpcDataMap _npc_data;
		};
	}

	class expedition_system
	{
		public:
			void initData();
			DeclareRegFunction(playerInfo);
			DeclareRegFunction(challenge);
			DeclareRegFunction(flush);
			DeclareRegFunction(buyTimes);
			DeclareRegFunction(strategyInfo);

		private:
			void loadFile();
			void loadStrategy();
			void sendEmptyStrategy(playerDataPtr d);

		private:
			BOOSTSHAREPTR(Expedition::Strategy, StrategyPtr);
			STDMAP(int, StrategyPtr, StrategyMap);
			StrategyMap _stragety_map;
	};
}

#include "channel_accnouce.h"

namespace gg
{
	ChannelAccnouce* const ChannelAccnouce::_Instance = new ChannelAccnouce();

	void ChannelAccnouce::send_to_all()
	{
		playerManager::playerDataVec vec = player_mgr.allOnline();
		for (unsigned i = 0; i < vec.size(); ++i)
		{
			playerDataPtr player = vec[i];
			sendMessage(player);
		}
	}

	bool ChannelAccnouce::is_runing()
	{
		const unsigned now = Common::gameTime();
		return now <= _end_time && now >= _begin_time;
	}

	void ChannelAccnouce::sendMessage(playerDataPtr player)
	{
		player->sendToClientFillMsg(
			gate_client::player_channel_accnouce_resp,
			qValue(qJson::qj_array).
			append(res_sucess).
			append(_begin_time).
			append(_end_time).
			append(_title).
			append(player->Info().UID()).
			append(GetMessage(player))
		);
	}

	string ChannelAccnouce::GetMessage(playerDataPtr player)
	{
		return GetMessage(player->Info().CID());
	}

	string ChannelAccnouce::GetMessage(const string channel_key)
	{
		MessageMap::const_iterator it = _message_map.find(channel_key);
		if (it == _message_map.end())return "";
		return it->second;
	}

	void ChannelAccnouce::initData()
	{
		//��ʼ��
		_begin_time = 0;
		_end_time = 0;
		_title = "";
		_message_map.clear();

		{
			mongo::BSONObj key = BSON("key" << "base");
			mongo::BSONObj obj = db_mgr.FindOne(DBN::dbChannelAccnouce, key);
			if (!obj.isEmpty())
			{
				_begin_time = obj["bg"].Int();
				_end_time = obj["ed"].Int();
				_title = obj["tl"].String();
			}
		};

		{
			_message_map.clear();
			mongo::BSONObj key = BSON("key" << BSON("$ne" << "base"));
			objCollection objs = db_mgr.Query(DBN::dbChannelAccnouce, key);
			for (unsigned i = 0; i < objs.size(); ++i)
			{
				mongo::BSONObj& obj = objs[i];
				_message_map[obj["key"].String()] = obj["m"].String();
			}
		};
	}

	void ChannelAccnouce::UpdateAccnouce(net::Msg& m, Json::Value& r)
	{
		playerDataPtr player = player_mgr.getPlayer(m.playerID);
		if (!player)Return(r, err_illedge);
		sendMessage(player);
	}

	void ChannelAccnouce::GMUpdateAccnouce(net::Msg& m, Json::Value& r)
	{
		Json::Value& data_json = r[strMsg][1u] = Json::arrayValue;
		data_json.append(0 == _begin_time ? 0 : Common::toStampTime(_begin_time));
		data_json.append(0 == _end_time ? 0 : Common::toStampTime(_end_time));
		data_json.append(_title);
		Json::Value data_list = Json::arrayValue;
		for (MessageMap::const_iterator it = _message_map.begin(); it != _message_map.end(); ++it)
		{
			Json::Value single_data = Json::arrayValue;
			single_data.append(it->first);
			single_data.append(it->second);
			data_list.append(single_data);
		}
		data_json.append(data_list);
		Return(r, res_sucess);
	}

	void ChannelAccnouce::GMMotifyAccnouce(net::Msg& m, Json::Value& r)
	{
		ReadJsonArray;
		
		const unsigned begin_time = js_msg[0u].asUInt();
		const unsigned end_time = js_msg[1u].asUInt();
		const string title = js_msg[2u].asString();
		Json::Value& data_json = js_msg[3u];
		_message_map.clear();
		for (unsigned i = 0; i < data_json.size(); ++i)
		{
			Json::Value& single_json = data_json[i];
			const string channel_key = single_json[0u].asString();
			if (channel_key.empty() || channel_key == "base")continue;
			_message_map[channel_key] = single_json[1u].asString();
		}
		_begin_time = 0 == begin_time ? 0 : Common::toLocalTime(begin_time);
		_end_time = 0 == end_time ? 0 : Common::toLocalTime(end_time);
		_title = title;
		save_message();
		send_to_all();
		Return(r, res_sucess);
	}

	void ChannelAccnouce::save_message()
	{
		db_mgr.RemoveCollection(DBN::dbChannelAccnouce);
		{
			mongo::BSONObj key = BSON("key" << "base");
			mongo::BSONObj obj = BSON("key" << "base" << "bg" << _begin_time << "ed" << _end_time << "tl" << _title);
			db_mgr.SaveMongo(DBN::dbChannelAccnouce, key, obj);
		};
		{
			for (MessageMap::const_iterator it = _message_map.begin(); it != _message_map.end(); ++it)
			{
				mongo::BSONObj key = BSON("key" << it->first);
				mongo::BSONObj obj = BSON("key" << it->first <<
					"m" << it->second);
				db_mgr.SaveMongo(DBN::dbChannelAccnouce, key, obj);
			}
		};
	}

}
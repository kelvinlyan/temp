#include "map_war.h"
#include "skill.h"
#include "man_system.h"
#include "battle_helper.hpp"
#include "broadcast_check.h"
#include "chat.h"
#include "item_system.h"
#include "team_war.h"
#include "festival_system.h"

namespace gg
{
	map_war* const map_war::_Instance = new map_war();

	const static string chapterDataDirStr = "./instance/chapter/";
	const static std::string strRpChapter = "chapter/";

	static ActionRateMap staticRate;

	const static int sweepItemID = 10001;

	class MapWarCast :
		public actionResCheck
	{
	private:
		virtual void onItemBroadcast(playerDataPtr player, const unsigned channel, const Json::Value& info_json)
		{
			Json::Value data_json;
			data_json.append(chat_sys.ChatPackage(player));
			data_json.append(info_json[1u].asInt());
			if (channel == CHAT::chat_all)
			{
				chat_sys.despatchAll(CHAT::server_war_item_purple, data_json);
			}
			else if (channel == CHAT::chat_kingdom)
			{
				const int itemID = info_json[1u].asInt();
				cfgItemPtr config = item_sys.getConfig(itemID);
				if (config)
				{
					if (config->quality == itemDef::yellow)
					{
						chat_sys.despatchKingdom(CHAT::server_war_item_yellow, player->Info().Nation(), data_json);
					}
					else if (config->quality == itemDef::red)
					{
						chat_sys.despatchKingdom(CHAT::server_war_item_red, player->Info().Nation(), data_json);
					}
				}
			}
		}
		virtual void onManBroadcast(playerDataPtr player, const unsigned channel, const Json::Value& info_json)
		{
			Json::Value data_json;
			data_json.append(info_json[1u].asInt());
			data_json.append(chat_sys.ChatPackage(player));
			if (channel == CHAT::chat_all)
			{
				chat_sys.despatchAll(CHAT::server_war_man_rare, data_json);
			}
			else if (channel == CHAT::chat_kingdom)
			{
				chat_sys.despatchKingdom(CHAT::server_war_man_rare, player->Info().Nation(), data_json);
			}
		}
	};

	static MapWarCast Cast;
	
	static bool CmpMapConfigBV(const mapDataCfgPtr& a, const mapDataCfgPtr& b)
	{
		return a->battleValue < b->battleValue;
	}

	void map_war::initData()
	{
		cout << "load map war system ..." << endl;
		Common::createDirectories(strRpDirRoot + strRpChapter);

		Cast.initialCheck("map_war.json");

		for (unsigned i = 0; i < ACTION::ACTION_NUM;++i)
		{
			staticRate[i] = ACTION::Rate(2.0, 0);
		}

		minChapterNum = 0x7FFFFFFF;
		maxChapterNum = 0;

		chaperConfigData.clear();
		mapConfigData.clear();
		// ��ʼ���½�����
		{
			cout << "load " << chapterDataDirStr << endl;
			FileJsonSeq chapterList = Common::loadFileJsonFromDir(chapterDataDirStr);
			for (unsigned i = 0; i < chapterList.size(); ++i)
			{
				Json::Value& chapter = chapterList[i];


				chaperDataCfgPtr chaper_ptr = Creator<chaperDataConfig>::Create();
				//�½ڻ�������
				chaper_ptr->chaperID = chapter["id"].asInt();
				chaper_ptr->preChaperID = chapter["preChapterId"].asInt();
				chaper_ptr->nextChaperID = chapter["followChapterId"].asInt();
				chaper_ptr->beginMapID = chapter["fistArmyId"].asInt();
				chaper_ptr->endMapID = chapter["compltetKeyArmyId"].asInt();
				//�½��Ǽ����佱��
				for (unsigned n = 0; n < chapter["rewardItemArry"].size(); ++n)
				{
					Json::Value& chapterReward = chapter["rewardItemArry"][n];
					rewardItemCfgPtr rewardItemPtr = Creator<rewardItemConfig>::Create();
					rewardItemPtr->rewardID = chapterReward["rewardID"].asInt();
					rewardItemPtr->starNum = chapterReward["startNum"].asInt();
					const unsigned rwJsonID = chapterReward["itemArry"].asInt();
					rewardItemPtr->starBox = actionFormatBox(rwJsonID);
					chaper_ptr->passBox[rewardItemPtr->rewardID] = rewardItemPtr;
				}
				chaperConfigData[chaper_ptr->chaperID] = chaper_ptr;

				//
				std::set<int> all_in;
				for (int begin = chaper_ptr->beginMapID; begin <= chaper_ptr->endMapID; begin++)
				{
					all_in.insert(begin);
				}

				for (unsigned n = 0; n < chapter["mapData"].size(); ++n)
				{
					Json::Value& chapterMap = chapter["mapData"][n];	

					mapDataCfgPtr mapDataPtr = Creator<mapDataConfig>::Create();
					mapDataPtr->chaperPtr = chaper_ptr;

					mapDataPtr->mapID = chapterMap["mapId"].asInt();
					all_in.erase(mapDataPtr->mapID);
// 					if (n == 0 && mapDataPtr->mapID != mapDataPtr->chaperID() * DivMapChaperRealte)
// 					{
// 						LogE << "map begin id must be equal chaperid * 100 ..." << LogEnd;
// 						abort();
// 					}
					mapDataPtr->nextID = chapterMap["nextID"].asInt();
					mapDataPtr->background = chapterMap.isMember("background") ? chapterMap["background"].asInt() : 1;
					mapDataPtr->isBoss = chapterMap["isBoss"].asBool();
					mapDataPtr->eliteBox = chapterMap["eliteBox"].asInt();
					for (unsigned ebn = 0; ebn < chapterMap["eliteBoxAction"].size(); ++ebn)
					{
						Json::Value elite_box_action = Common::loadJsonFile("./instance/elite_box/" + 
						Common::toString(chapterMap["eliteBoxAction"][ebn].asInt()) + ".json");
						mapDataPtr->eliteBoxAction[ebn] = actionFormatBox(elite_box_action);
					}
					mapDataPtr->faceID = chapterMap["faceID"].asInt();
					mapDataPtr->mapName = chapterMap["mapName"].asString();
					mapDataPtr->mapLevel = chapterMap["mapLevel"].asUInt();
					mapDataPtr->battleValue = chapterMap["battleValue"].asInt();
					mapDataPtr->needFood = chapterMap["needfood"].asInt();
					mapDataPtr->needAction = chapterMap["needAction"].asInt();
					mapDataPtr->chanllengeTimes = chapterMap["challengeTimes"].asInt();
					mapDataPtr->manExp = chapterMap["manExp"].asUInt();
					mapDataPtr->levelLimit = chapterMap["levelLimit"].asUInt();
					mapDataPtr->robotIDX = chapterMap["robotIDX"].asInt();
					const unsigned rwJsonID = chapterMap["winBox"].asUInt();
					mapDataPtr->winBox = actionFormat(rwJsonID);
					for (unsigned nn = 0; nn < chapterMap["army"].size(); ++nn)
					{
						Json::Value& npcJson = chapterMap["army"][nn];
						armyNPC npc;
						npc.npcID = npcJson["npcID"].asInt();
						npc.holdMorale = npcJson["holdMorale"].asBool();
						for (unsigned cn = 0; cn < characterNum; ++cn)
						{
							npc.initAttri[cn] = npcJson["initAttri"][cn].asInt();
//							npc.addAttri[cn] = npcJson["addAttri"][cn].asInt();
						}
						npc.armsType = npcJson["armsType"].asInt();
						for (unsigned cn = 0; cn < armsModulesNum; ++cn)
						{
							npc.armsModule[cn] = npcJson["armsModule"][cn].asDouble();
						}
						npc.npcLevel = npcJson["npcLevel"].asInt();
						npc.npcPos = npcJson["npcPos"].asUInt() % 9;
						npc.battleValue = npcJson["battleValue"].asInt();
						npc.skill_1 = npcJson["skill_1"].asInt();
						npc.skill_2 = npcJson["skill_2"].asInt();
						for (unsigned eq_idx = 0; eq_idx < npcJson["equip"].size(); ++eq_idx)
						{
							npc.equipList.push_back(BattleEquip(npcJson["equip"][eq_idx][0u].asUInt(),
								npcJson["equip"][eq_idx][1u].asInt(),
								npcJson["equip"][eq_idx][2u].asUInt()));
						}
						mapDataPtr->npcList.push_back(npc);
					}

					mapConfigData[mapDataPtr->mapID] = mapDataPtr;
					mapConfigVec.push_back(mapDataPtr);
				}

				if (!all_in.empty())
				{
					LogE << "can not match chaper config ..." << chaper_ptr->chaperID << LogEnd;
					abort();
				}

				//���ݿ����Ӷ���
				db_mgr.EnsureIndex(DBN::dbPlayerWar + Common::toString(chaper_ptr->chaperID), BSON(strPlayerID << 1));
				if (maxChapterNum < chaper_ptr->chaperID){ maxChapterNum = chaper_ptr->chaperID; }
				if (minChapterNum > chaper_ptr->chaperID) { minChapterNum = chaper_ptr->chaperID; }
			}
		};

		{
			Json::Value actionVip = Common::loadJsonFile("./instance/vip/reNumVip.json");
			for (unsigned i = 0; i < actionVip.size(); ++i)
			{
				int iVip = actionVip[i]["vip"].asInt();
				int iAction = actionVip[i]["action"].asInt();
				mapVipReNum[iVip] = iAction;
			}
		}

		loadDb();
		std::sort(mapConfigVec.begin(), mapConfigVec.end(), CmpMapConfigBV);
	}

	void map_war::loadDb()
	{
		objCollection obj = db_mgr.Query(DBN::dbChapterReport);
		if (obj.empty()) return;
		for (objCollection::iterator it = obj.begin(); it != obj.end(); it++)
		{
			mongo::BSONObj obj = (*it);
			int mapId = obj["ci"].Int();
			if (!obj["frp"].eoo())
			{
				reportCfgPtr fPtr = Creator<reportConfig>::Create();
				fPtr->sNum = obj["frp"]["sn"].Int();
				fPtr->rTime = obj["frp"]["rt"].Int();
				fPtr->name = obj["frp"]["nm"].String();
				fPtr->playerNation = (Kingdom::NATION)obj["frp"]["pn"].Int();	
				fPtr->roundNum = obj["frp"]["rn"].Int();
				fPtr->damage = obj["frp"]["dm"].Int();
				fPtr->playerId = obj["frp"]["pi"].Int();
				fPtr->playerLV = obj["frp"]["lv"].Int();


				firstReport[mapId] = fPtr;
			}

			if (!obj["prp"].eoo())
			{
				reportCfgPtr fPtr = Creator<reportConfig>::Create();
				fPtr->sNum = obj["prp"]["sn"].Int();
				fPtr->rTime = obj["prp"]["rt"].Int();
				fPtr->name = obj["prp"]["nm"].String();
				fPtr->playerNation = (Kingdom::NATION)obj["prp"]["pn"].Int();
				fPtr->roundNum = obj["prp"]["rn"].Int();
				fPtr->damage = obj["prp"]["dm"].Int();
				fPtr->playerId = obj["prp"]["pi"].Int();
				fPtr->playerLV = obj["prp"]["lv"].Int();

				perReport[mapId] = fPtr;
			}

			if (!obj["rrp"].eoo())
			{
				vector<mongo::BSONElement> sets = obj["rrp"].Array();

				vector<reportCfgPtr> ptrVector;
				ptrVector.clear();

				for (unsigned i = 0; i < sets.size(); i++)
				{
					reportCfgPtr fPtr = Creator<reportConfig>::Create();
					fPtr->sNum = sets[i]["sn"].Int();
					fPtr->rTime = sets[i]["rt"].Int();
					fPtr->name = sets[i]["nm"].String();
					fPtr->playerNation = (Kingdom::NATION)sets[i]["pn"].Int();
					fPtr->roundNum = sets[i]["rn"].Int();
					fPtr->damage = sets[i]["dm"].Int();
					fPtr->playerId = sets[i]["pi"].Int();
					fPtr->playerLV = sets[i]["lv"].Int();

					ptrVector.push_back(fPtr);
				}

				recentReport[mapId] = ptrVector;
			}
		}

	}

	bool map_war::upateDb(int mapId)
	{
		mongo::BSONObj key = BSON("ci" << mapId);
		mongo::BSONObjBuilder obj;
		obj << "ci" << mapId;

		reportCfgMap::iterator it = firstReport.find(mapId);
		if (it != firstReport.end())
		{
			mongo::BSONObj firstRp = BSON("sn" << it->second->sNum << "rt" << it->second->rTime << "nm" << it->second->name << "lv" << it->second->playerLV << "pn" << it->second->playerNation << "rn" << it->second->roundNum << "dm" << it->second->damage << "pi" << it->second->playerId);
			obj << "frp" << firstRp;
		}

		reportCfgMap::iterator pIt = perReport.find(mapId);
		if (pIt != perReport.end())
		{
			mongo::BSONObj perRp = BSON("sn" << pIt->second->sNum << "rt" << pIt->second->rTime << "nm" << pIt->second->name << "lv" << pIt->second->playerLV << "pn" << pIt->second->playerNation << "rn" << pIt->second->roundNum << "dm" << pIt->second->damage << "pi" << pIt->second->playerId);
			obj << "prp" << perRp;
		}

		mongo::BSONArrayBuilder reRp;
		reportCfgMapVector::iterator rIt = recentReport.find(mapId);
		if (rIt != recentReport.end())
		{
			for (vector<reportCfgPtr>::iterator obIt = rIt->second.begin(); obIt != rIt->second.end(); obIt++)
			{
				mongo::BSONObj obj = BSON("sn" << (*obIt)->sNum << "rt" << (*obIt)->rTime << "nm" << (*obIt)->name << "lv" << (*obIt)->playerLV << "pn" << (*obIt)->playerNation << "rn" << (*obIt)->roundNum << "dm" << (*obIt)->damage << "pi" << (*obIt)->playerId);
				reRp << obj;
			}
		}
		obj << "rrp" << reRp.arr();

		//cout << "map_war_add" << endl;
		return db_mgr.SaveMongo(DBN::dbChapterReport, key, obj.obj());
	}

	int map_war::calCompleteChaperByMapID(const int mapID)
	{
		mapDataCfgPtr config = map_sys.getMapConfig(mapID);
		if (config)
		{
			if (config->isEndMap())return config->chaperID();
			return config->chaperPtr->preChaperID;//ǰ����½�
		}
		return -1;
	}

	const chaperDataCfgPtr map_war::getChaperConfig(const int chaperID)
	{
		chaperDataConfigMap::iterator it = chaperConfigData.find(chaperID);
		if (it != chaperConfigData.end()) return it->second;
		return chaperDataCfgPtr();
	}

	const mapDataCfgPtr map_war::getMapConfig(const int mapID)
	{
		mapDataConfigMap::iterator it = mapConfigData.find(mapID);
		if (it != mapConfigData.end()) return it->second;
		return mapDataCfgPtr();
	}

	const ActionBoxList map_war::getChapterRewardList(const int chaperID, const int rewardId)
	{
		chaperDataCfgPtr ptr = getChaperConfig(chaperID);
		if (!ptr) return ActionBoxList();
		rewardItemMap::iterator it = ptr->passBox.find(rewardId);
		if (it == ptr->passBox.end()) return ActionBoxList();
		return it->second->starBox;
	}

	const reportCfgPtr map_war::getFristReport(const int mapId)
	{
		reportCfgMap::iterator it = firstReport.find(mapId);
		if (it != firstReport.end()) return it->second;
		return reportCfgPtr();
	}

	const reportCfgPtr map_war::getPerReport(const int mapId)
	{
		reportCfgMap::iterator it = perReport.find(mapId);
		if (it != perReport.end()) return it->second;
		return reportCfgPtr();
	}

	const vector<reportCfgPtr> map_war::getRecentReport(const int mapId)
	{
		reportCfgMapVector::iterator it = recentReport.find(mapId);
		if (it != recentReport.end()) return it->second;
		vector<reportCfgPtr> a;
		a.clear();
		return a;
	}

	Json::Value map_war::formatJson(reportCfgPtr ptr)
	{
		Json::Value res;
		res["sn"] = ptr->sNum;
		res["rt"] = ptr->rTime;
		res["nm"] = ptr->name;
		res["lv"] = ptr->playerLV;
		res["pn"] = ptr->playerNation;
		//res["rn"] = ptr->roundNum;
		//res["dm"] = ptr->damage;
		//res["pi"] = ptr->playerId;
		return res;
	}

	//�ͻ��˲��� �鿴�½�����
	void map_war::mapDataUpdate(net::Msg& m, Json::Value& r)
	{
		ReadJsonArray;
		const int playerID = m.playerID;
		playerDataPtr player = player_mgr.getPlayer(playerID);
		if (!player)Return(r, err_illedge);
		int chId = 0;
		if (js_msg[0u].empty())
		{ 
			chId = player->War().currentChallengeChaper();
		}
		else 
		{ 
			chId = js_msg[0u].asInt(); 
		}
		playerChatperDataPtr chapterData = player->War().getChatperData(chId);
		if (!chapterData) Return(r, err_illedge);
		chapterData->_auto_update();
// 		qValue res_data(qJson::qj_array);
// 		res_data.append(res_sucess).append(chapterData->mapDataJson());
// 		player->sendToClientFillMsg(gate_client::map_war_base_resp, res_data);
	}

	//ս��
	int getDamage(sBattlePtr atk)
	{
		int damage = 0;
		for (manList::iterator it = atk->battleMan.begin(); it != atk->battleMan.end(); it++)
		{
			damage = damage + ((*it)->getTotalAttri(idx_hp) - (*it)->currentHP);
		}
		return damage;
	}

	//����
	bool comp(const reportCfgPtr& a, const reportCfgPtr& b)
	{
		if (a->playerLV != b->playerLV) return a->playerLV < b->playerLV;
		if (a->roundNum != b->roundNum) return a->roundNum < b->roundNum;
		if (a->damage != b->damage) return a->damage < b->damage;
		return true;
	}
	//������������ //ɨ����
	int map_war::checkConSweep(mapDataCfgPtr config, int times, playerDataPtr player)
	{
		int needFood = config->needFood * times;
		int needAction = config->needAction * times;
		if (player->Res().getFood() < needFood) return  err_food_not_enough;
		if (player->Res().getAction() < needAction) return err_action_not_enough;
		times = times < 0 ? 0 : times;
		if (!player->Items().overItem(sweepItemID, (unsigned)times))return err_item_not_enough;
		return res_sucess;
	}
	
	//�۳���������//ɨ����
	void map_war::subConSweep(mapDataCfgPtr config, int times, playerDataPtr player)
	{
		int needFood = config->needFood * times;
		int needAction = config->needAction * times;
		player->Res().alterFood(-needFood);
		player->Res().alterAction(-needAction);
		times = times < 0 ? 0 : times;
		player->Items().removeItem(sweepItemID, (unsigned)times);
	}

	//������������
	int map_war::checkCon(mapDataCfgPtr config, int times, playerDataPtr player)
	{
		int needFood = config->needFood * times;
		int needAction = config->needAction * times;
		if (player->Res().getFood() < needFood) return  err_food_not_enough;
		if (player->Res().getAction() < needAction) return err_action_not_enough;
		return res_sucess;
	}

	//�۳���������
	void map_war::subCon(mapDataCfgPtr config, int times, playerDataPtr player)
	{
		int needFood = config->needFood * times;
		int needAction = config->needAction * times;
		player->Res().alterFood(-needFood);
		player->Res().alterAction(-needAction);
	}

	//���ô���VIp
	int map_war::ReNum(int vipLv)
	{
		MapReNumVipMap::iterator it = mapVipReNum.find(vipLv);
		if (it != mapVipReNum.end()) return it->second;
		return 0;
	}

	//��ս���ߵ�ͼ
	void map_war::challengeMap(mapDataCfgPtr config, playerDataPtr player, Json::Value& r)
	{
		ActionBoxList boxes = preToBox(player, config->winBox);
		const int res = actionCheckAvailable(player, boxes);
		if (res != res_sucess)
		{
			r[strMsg][1u] = actionError();
			Return(r, res);
		}
		BattleReport reportData;
		sBattlePtr atk = BattleHelp::WarPlayer(player);
		sBattlePtr def = npcSide(config);
		O2ORes resultB = reportData.One2One(atk, def, typeBattle::war_story);
		reportData.addNotice(player->ID());//����������
		Json::Value rep_json = config->mapName;
		reportData.addCopyField("last_rep/" + Common::toString(player->ID()));
		reportData.addReportdeclare("bg", config->background);
		Json::Value playerJson;
		playerJson.append(player->LV());
		playerJson.append(player->Info().EXP());
		int actionNum = 0;
		if (resultB.res == resBattle::atk_win)
		{
			subCon(config, 1, player);
			actionNum = config->needAction;
		}
		else
		{
			player->Info().updateWarLose();//����ʧ�ܴ���
		}

		if (resultB.res == resBattle::atk_win)
		{
			//����
			Json::Value me_json;
			unsigned total_me = BattleHelp::AddManExp(player, config->manExp, me_json);
			const unsigned num = total_me / 100;
			if (num > 0)
			{
				player->Items().addItem(10004, num);
			}
			reportData.addReportdeclare("me", me_json);
			const int ap = player->Research().getResearchData(LAND::idx_home_type_merit);
			setActionRate(ACTION::merit, ACTION::Rate(1.0 + ap / 10000.0));
			actionDoBox(player, boxes);
			Json::Value res_json = actionRes();
			Cast.beginCheck(player, res_json);
			if (num > 0)
			{
				Json::Value exp_book_json;
				exp_book_json.append(ACTION::item);
				exp_book_json.append(10004);
				exp_book_json.append(num);
				res_json.append(exp_book_json);
			}
			if (100103 == config->mapID && !player->War().isChallengeMap(100103))
			{
				itemVec vec = player->Items().addItem(4003, 1);
				if (vec.size() > 0)
				{
					itemPtr item = vec[0];
// 					item->setBKReborn(itemDeclare::rb_idx_1, idx_crit, 50);
// 					item->setBKReborn(itemDeclare::rb_idx_2, idx_block, 50);
// 					item->replaceUncertainRB(false);
					Json::Value fix_equip_json;
					fix_equip_json.append(ACTION::item);
					fix_equip_json.append(4003);
					fix_equip_json.append(1);
					res_json.append(fix_equip_json);
				}
			}
			if (festival_sys.current())
			{
				ActionBoxList extra = festival_sys.current()->chapterExtra();
				actionDoBox(player, extra);
				Json::Value extra_json = actionRes();
				combineActionRes(extra_json, res_json);
			}
			reportData.addReportdeclare("wb", res_json);
			playerJson.append(player->LV());
			playerJson.append(player->Info().EXP());
			playerJson.append(actionNum * 10);
			playerJson.append(player->Info().isMaxLevel());
			reportData.addReportdeclare("plv", playerJson);
			unsigned roundNum = reportData.getLastRound();
			int rDamage = getDamage(atk);

			changeRep(reportData, config, player, roundNum, rDamage, resultB.star);
			player->War().alterMapStar(config->mapID, resultB.star);
			player->War().subChanllenge(config->mapID, 1);

			Log(DBLOG::strLogWar, player, 0, config->mapID, resultB.res, 0, 0, 0, 0, 0, res_json.toIndentString());

			team_war.insertRobot(config->robotIDX, atk);
		}
		else
		{
			Log(DBLOG::strLogWar, player, 0, config->mapID, resultB.res);
		}
		//������������͸��ͻ���
		reportData.Done(typeBattle::war_story);
		//�ճ�
		player->Daily().tickTask(DAILY::war_npc);
		r[strMsg][1u] = resultB.res;
		Return(r, res_sucess);
	}

	//�ͻ��˲��� ��ս��������
	void map_war::challenge(net::Msg& m, Json::Value& r)
	{
		const int playerID = m.playerID;
		playerDataPtr player = player_mgr.getPlayer(playerID);
		if (!player) Return(r, err_illedge);
		if (player->Info().CDLoseWar() > Common::gameTime())Return(r, err_war_lose_cd);

		ReadJsonArray;
		const int mapId = js_msg[0u].asInt();

		mapDataCfgPtr config = getMapConfig(mapId);
		if (!config) Return(r, err_illedge);

		if (player->LV() < config->levelLimit)Return(r, err_player_lv_too_low);

		int resultR = checkCon(config, 1, player);
		if (resultR != res_sucess) Return(r, resultR);

		int resultC = player->War().canChanllenge(mapId, 1, config->chanllengeTimes);
		if (resultC != res_sucess) Return(r, resultR);

		challengeMap(config, player, r);
	}

	void map_war::getChapterReward(net::Msg& m, Json::Value& r)
	{
		ReadJsonArray;
		const int playerID = m.playerID;
		playerDataPtr player = player_mgr.getPlayer(playerID);
		if (!player)Return(r, err_illedge);
		const int chapterId = js_msg[0u].asInt();
		const int rewardId = js_msg[1u].asInt();
		int res = player->War().getChapterReward(chapterId, rewardId);
		Return(r, res);
	}

	void map_war::getMapStrategy(net::Msg& m, Json::Value& r)
	{
		ReadJsonArray;
		const int playerID = m.playerID;
		playerDataPtr player = player_mgr.getPlayer(playerID);
		if (!player)Return(r, err_illedge);
		const int mapId = js_msg[0u].asInt();

		r[strMsg][1u] = Json::objectValue;
		reportCfgPtr fPtr = getFristReport(mapId);
		if (fPtr) r[strMsg][1u]["fp"] = formatJson(fPtr);

		reportCfgPtr pPtr = getPerReport(mapId);
		if (pPtr) r[strMsg][1u]["pp"] = formatJson(pPtr);

		vector<reportCfgPtr> vectorPtr = getRecentReport(mapId);
		Json::Value rpArry;
		for (vector<reportCfgPtr>::iterator it = vectorPtr.begin(); it != vectorPtr.end(); it++)
		{
			rpArry.append(formatJson(*it));
		}
		if (!rpArry.empty()) r[strMsg][1u]["rp"] = rpArry;
		Return(r, res_sucess);
	}
	
	void map_war::sweepMap(net::Msg& m, Json::Value& r)
	{
		ReadJsonArray;
		const int playerID = m.playerID;
		const int mapId = js_msg[0u].asInt();
		const int sTimes = js_msg[1u].asInt();
		if (sTimes < 1 || sTimes > 10)Return(r, err_illedge);

		playerDataPtr player = player_mgr.getPlayer(playerID);
		if (!player)Return(r, err_illedge);

		mapDataCfgPtr config = getMapConfig(mapId);
		if (!config) Return(r, err_illedge);

		int resultR = checkConSweep(config, sTimes, player);
		if (resultR != res_sucess) Return(r, resultR);

		int rsultS = player->War().canSweep(mapId, sTimes, config->chanllengeTimes);
		if (rsultS != res_sucess) Return(r, rsultS);

		subConSweep(config, sTimes, player);
		player->War().subChanllenge(mapId, sTimes);

		//����
		std::vector<playerManPtr> vec = player->WarFM().currentInvaildFM();
	
		Json::Value& rw_json = r[strMsg][1u] = Json::arrayValue;
		for (int i = 0; i < sTimes; ++i)
		{
			const int ap = player->Research().getResearchData(LAND::idx_home_type_merit);
			setActionRate(ACTION::merit, ACTION::Rate(1.0 + ap / 10000.0));

			actionDo(player, config->winBox);
 			Json::Value rwjson = actionRes();
			Cast.beginCheck(player, rwjson);
			const unsigned add_num = (config->manExp * vec.size()) / 100;
			if (add_num > 0)
			{
				player->Items().addItem(10004, add_num);
				Json::Value exp_book_json;
				exp_book_json.append(ACTION::item);
				exp_book_json.append(10004);
				exp_book_json.append(add_num);
				rwjson.append(exp_book_json);
			}
			if (config->needAction > 0)
			{
				Json::Value exp_json;
				exp_json.append(ACTION::exp);
				exp_json.append(config->needAction * 10);
				rwjson.append(exp_json);
			}
			if (festival_sys.current())
			{
				ActionBoxList extra = festival_sys.current()->chapterExtra();
				actionDoBox(player, extra);
				Json::Value extra_json = actionRes();
				combineActionRes(extra_json, rwjson);
			}
			Json::Value mdJson;
			mdJson["bj"] = 0;
			mdJson["rw"] = rwjson;
			rw_json.append(mdJson);

			Log(DBLOG::strLogWar, player, 1, mapId, 2.0, 0, 0, 0, 0, 0, rwjson.toIndentString());
		}
		//�ճ�
		player->Daily().tickTask(DAILY::war_npc, sTimes);
		Return(r, res_sucess);
	}

	void map_war::reqFlashSnap(net::Msg& m, Json::Value& r)
	{
		playerDataPtr player = player_mgr.getPlayer(m.playerID);
		if (!player)Return(r, err_illedge);
		player->War().sendFlashSnap();
	}

	void map_war::reqEliteBox(net::Msg& m, Json::Value& r)
	{
		playerDataPtr player = player_mgr.getPlayer(m.playerID);
		if (!player)Return(r, err_illedge);
		ReadJsonArray;
		const int mapID = js_msg[0u].asInt();
		Return(r, player->War().getEliteBox(mapID, r[strMsg][1u] = Json::arrayValue));
	}

	void map_war::reqNpcData(net::Msg& m, Json::Value& r)
	{
		playerDataPtr player = player_mgr.getPlayer(m.playerID);
		if (!player)Return(r, err_illedge);
		ReadJsonArray;
		const int mapID = js_msg[0u].asInt();//��ͼID
		mapDataCfgPtr config = getMapConfig(mapID);
		if (!config) Return(r, err_illedge);
		r[strMsg][2u] = mapID;
		Json::Value& npc_json = r[strMsg][1u] = Json::arrayValue;
		for (unsigned i = 0; i < config->npcList.size(); ++i)
		{
			const armyNPC& npc = config->npcList[i];
			Json::Value npc_single = Json::arrayValue;
			npc_single.append(npc.npcPos);
			npc_single.append(npc.initAttri[idx_hp]);
			npc_single.append(0);
			npc_json.append(npc_single);
		}
		Return(r, res_sucess);
	}

	void map_war::reChanllengeAcc(net::Msg& m, Json::Value& r)
	{
		ReadJsonArray;
		const int playerID = m.playerID;
		const int mapId = js_msg[0u].asInt();

		playerDataPtr player = player_mgr.getPlayer(playerID);
		if (!player)Return(r, err_illedge);

		if (player->Res().getCash() < 50) Return(r, err_cash_not_enough);
		int resutRes = player->War().reChanllengeAcc(mapId);
		if (resutRes == res_sucess)
		{
			Log(DBLOG::strLogWar, player, 2, mapId);
			player->Res().alterCash(-50);
		}
		
		Return(r, resutRes);
	}

	sBattlePtr map_war::npcSide(mapDataCfgPtr npcPtr)
	{
		sBattlePtr sb = Creator<sideBattle>::Create();
		sb->playerID = npcPtr->mapID;
		sb->playerName = npcPtr->mapName;
		sb->isPlayer = false;
		sb->playerLevel = npcPtr->mapLevel;
		sb->playerFace = npcPtr->faceID;
		sb->battleValue = npcPtr->battleValue;
		manList& ml = sb->battleMan;
		ml.clear();
		for (unsigned i = 0; i < npcPtr->npcList.size(); i++)
		{
			const armyNPC& npc = npcPtr->npcList[i];
			mBattlePtr man = Creator<manBattle>::Create();
			man->manID = npc.npcID;
			man->holdMorale = npc.holdMorale;
			man->set_skill_1(npc.skill_1);
			man->set_skill_2(npc.skill_2);
			man->armsType = npc.armsType;
			man->manLevel = npc.npcLevel;
			man->currentIdx = npc.npcPos;
			man->battleValue = npc.battleValue;
			memcpy(man->armsModule, npc.armsModule, sizeof(man->armsModule));
			memcpy(man->initialAttri, npc.initAttri, sizeof(man->initialAttri));
			memcpy(man->battleAttri, npc.initAttri, sizeof(man->battleAttri));
			//memcpy(man->battleAttri, npc.addAttri, sizeof(man->battleAttri));
			man->currentHP = man->getTotalAttri(idx_hp);
			man->equipList = npc.equipList;
			ml.push_back(man);
		}
		return sb;
	}

	void map_war::changeRep(BattleReport& reportData, mapDataCfgPtr config, playerDataPtr player, int roundNum, int rDamage, int starsNum)
	{
		//������ͼ����
		//�״�ͨ��
		bool	updateS = false;
		const int mapId = config->mapID;
		if (!getFristReport(mapId))
		{
			string rPath = strRpChapter + Common::toString(mapId) + "_first";

			reportCfgPtr reportPtr = Creator<reportConfig>::Create();
			reportPtr->name = player->Name();
			reportPtr->playerLV = player->LV();
			reportPtr->playerNation = player->Info().Nation();
			reportPtr->roundNum = roundNum;
			reportPtr->damage = rDamage;
			reportPtr->playerId = player->ID();
			reportPtr->rTime = Common::gameTime();
			firstReport[mapId] = reportPtr;

			reportData.addCopyField(rPath);
			updateS = true;

			//ȫ������
			if (config->isBoss)
			{
				qValue data_json(qJson::qj_array);
				data_json.append(chat_sys.ChatPackageQ(player)).
					append(mapId).
					append(config->mapName);
				chat_sys.despatchAll(CHAT::server_war_map_first, data_json);
			}
		}

		//����ͨ��
		//if (true)
		{
			reportCfgPtr perPTr = getPerReport(mapId);

			reportCfgPtr reportPtr = Creator<reportConfig>::Create();
			reportPtr->name = player->Name();
			reportPtr->playerLV = player->LV();
			reportPtr->playerNation = player->Info().Nation();
			reportPtr->roundNum = roundNum;
			reportPtr->damage = rDamage;
			reportPtr->playerId = player->ID();
			reportPtr->rTime = Common::gameTime();

			if (!perPTr || comp(reportPtr, perPTr))
			{
				updateS = true;
				perReport[mapId] = reportPtr;
				const string rPath = strRpChapter + Common::toString(mapId) + "_per";
				reportData.addCopyField(rPath);
			}
		};

		if (!player->War().isChallengeMap(mapId))
		{
			reportCfgPtr reportPtr = Creator<reportConfig>::Create();
			reportPtr->name = player->Name();
			reportPtr->playerLV = player->LV();
			reportPtr->playerNation = player->Info().Nation();
			reportPtr->roundNum = roundNum;
			reportPtr->damage = rDamage;
			reportPtr->playerId = player->ID();
			reportPtr->rTime = Common::gameTime();

			if (getRecentReport(mapId).empty())
			{
				vector<reportCfgPtr> vectorPtr;
				vectorPtr.push_back(reportPtr);
				reportPtr->sNum = 1;
				recentReport[mapId] = vectorPtr;
			}
			else
			{
				int sNum = recentReport[mapId].back()->sNum;
				if (sNum == 5) reportPtr->sNum = 1;
				else reportPtr->sNum = sNum + 1;
				recentReport[mapId].push_back(reportPtr);
				if (recentReport[mapId].size() > 5)
				{
					recentReport[mapId].erase(recentReport[mapId].begin());
				}
			}
			updateS = true;
			string rPath = strRpChapter + Common::toString(mapId) + "_" + Common::toString(reportPtr->sNum);
			reportData.addCopyField(rPath);
		}

		if (updateS) upateDb(mapId);
	}

	mapDataCfgPtr map_war::festivalNpc(int bv) const
	{
		ForEachC(std::vector<mapDataCfgPtr>, it, mapConfigVec)
		{
			if (bv < (*it)->battleValue + 15000)
				return *it;
		}
		return mapConfigVec.back();
	}
	
// 	mapDataCfgPtr map_war::getSpeMapData(int mapId)
// 	{
// 		mapDataMap::iterator it = speMapData.find(mapId);
// 		if (it != speMapData.end()) return it->second;
// 		return mapDataCfgPtr();
// 	}
}

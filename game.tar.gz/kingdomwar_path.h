#pragma once

#include "auto_base.h"
#include "battle_def.h"
#include "battle_system.h"
#include "kingdomwar_def.h"
#include "kingdomwar_npc.h"

namespace gg
{
	namespace KingdomWar
	{
		class Path;
		BOOSTSHAREPTR(Path, PathPtr);

		class PathItemBase;
		BOOSTSHAREPTR(PathItemBase, PItemPtr);

		struct PathReportData
		{
			PathReportData(unsigned time, PItemPtr& atk_ptr, PItemPtr& def_ptr);

			void one2one();
			void done();

			unsigned time;
			O2ORes result;
			std::string path;
			BattleReport data;
			sBattlePtr atk_ptr;
			sBattlePtr def_ptr;
		};

		class PathItemBase
		{
			public:
				PathItemBase(unsigned time, int side, int nation, PathPtr& ptr)
					: _nation(nation), _start_time(time), _side(side), _path(ptr)
					, _distance(0), _trigger_time(0){}

				virtual ~PathItemBase(){}
				virtual int type() const = 0;
				virtual std::string name() const = 0;
				virtual void getInfo(qValue& q) const = 0;
				virtual void getUpInfo(qValue& q, int type) const = 0;
				virtual sBattlePtr getBattlePtr() = 0;
				virtual void doneBattle(PathReportData& rep_data, PItemPtr& target, bool atk_side) = 0;
				virtual bool isDead() = 0;
				virtual void beDead(unsigned time, Json::Value& tips) = 0;
				virtual void arrive(unsigned time, int id) = 0;

				int nation() const { return _nation; }
				int side() const { return _side; }
				unsigned startTime() const { return _start_time; }
				unsigned distance() const { return _distance; }
				unsigned triggerTime() const { return _trigger_time; }

				void setTriggerTime(unsigned time) { _trigger_time = time; }
				void setStartTime(unsigned time) { _start_time = time; }
				void setDistance(unsigned distance) { _distance = distance; } 

			protected:
				PathPtr _path;

			private:
				int _nation;
				int _side;
				unsigned _start_time;
				unsigned _trigger_time;
				unsigned _distance;
		};

		STDLIST(PItemPtr, PathItemList);
		typedef PathItemList::iterator PLIter;

		class PathItemPlayer
			: public PathItemBase
		{
			public:
				PathItemPlayer(unsigned time, int side, playerDataPtr d, int army_id, PathPtr& ptr);
				
				virtual void getInfo(qValue& q) const;
				virtual void getUpInfo(qValue& q, int type) const;
				virtual int type() const { return Player; }
				virtual std::string name() const { return _name; }
				virtual sBattlePtr getBattlePtr();
				virtual void doneBattle(PathReportData& rep_data, PItemPtr& target, bool atk_side);
				virtual bool isDead();
				virtual void beDead(unsigned time, Json::Value& tips);
				virtual void arrive(unsigned time, int id);

				int pid() const { return _pid; }
				int armyId() const { return _army_id; }
				void resetHp(sBattlePtr& ptr);

			private:
				int _pid;
				int _army_id;
				std::string _name;
				int _title;
				int _face;
		};

		BOOSTSHAREPTR(PathItemPlayer, PItemPlayer);

		class PathItemNpc
			: public PathItemBase
		{
			public:
				PathItemNpc(unsigned time, int side, NpcDataPtr d, PathPtr& ptr);

				virtual void getInfo(qValue& q) const;
				virtual void getUpInfo(qValue& q, int type) const;
				virtual int type() const { return _npc_data->type(); }
				virtual std::string name() const { return _npc_data->name(); }
				virtual sBattlePtr getBattlePtr();
				virtual void doneBattle(PathReportData& rep_data, PItemPtr& target, bool atk_side);
				virtual bool isDead() { return _npc_data->isDead(); }
				virtual void beDead(unsigned time, Json::Value& tips);
				virtual void arrive(unsigned time, int id);

			private:
				NpcDataPtr _npc_data;
		};

		class PathItemSorter
		{
			public:
				bool getMin(PLIter& iter);
				inline void push(const PLIter& iter);
				void pop(const PLIter& iter);
				void clear() { _sort_list.clear(); }

			private:
				struct SortItem
				{
					SortItem(const PLIter& iter): target(iter){}
					bool operator<(const SortItem& rhs) const
					{
						return (*target)->triggerTime() < (*(rhs.target))->triggerTime();
					}
					bool operator==(const SortItem& rhs) const
					{
						return target == rhs.target;
					}
					PLIter target;
				};
				typedef multiset<SortItem> SortList;
				SortList _sort_list;
		};

		class PathUpdateItem
		{
			public:
				PathUpdateItem(int type, const PItemPtr& ptr)
					: _type(type), _ptr(ptr){}

				int side() const 
				{
					return _ptr->side(); 
				}
				void getInfo(qValue& q) const 
				{
					return _ptr->getUpInfo(q, _type); 
				}

			private:
				int _type;
				PItemPtr _ptr;
		};

		class PathItemMgr
		{
			public:
				typedef boost::function<void(const PItemPtr&)> Handler;

				PathItemMgr(const int& path_id);	
				void setPathType(int side, int path_type, int cost_time);
				bool access(int side) const { return _type[side] == 1; }

				void getMainInfo(qValue& q) const;
				void getUpdateInfo(qValue& q) const;

				bool empty() const;
				void push(const PItemPtr& item);
				bool find(int pid, int army_id, PLIter& iter) const;
				void pop(const PLIter& iter, int type);
				void addTips(const PLIter& iter, int type);
				void swap(PLIter& lfs, PLIter& rhs);
				bool getMin(PLIter& iter);
				void clear();
				void run(const Handler& h);
				void reset(unsigned time);
				void clear(unsigned time);

				PLIter getNext(const PLIter& iter);
				const PLIter& leftEnd() const { return _left_end; }
				const PLIter& rightEnd() const { return _right_end; }

			private:
				PathItemList getInitedPathItemList();
				int getTriggerTime(const PLIter& lft, const PLIter& rhs);
				void setTriggerTime(PLIter& iter, int trigger_time);

			private:
				int _path_id;
				int _type[MaxSide];
				PathItemList _item_list;
				PathItemSorter _sorter;
				PLIter _left_end;
				PLIter _right_end;
				int _distance;
				int _speed[MaxSide];
				double _rate;

				STDVECTOR(PathUpdateItem, UpdateItems);
				mutable UpdateItems _updates;
		};

		class City;
		BOOSTSHAREPTR(City, CityPtr);

		class Path
			: public boost::enable_shared_from_this<Path>
		{
			public:
				Path(int path_id, int from_id, int to_id);

				int id() const { return _id; }

				void setPathType(int from_id, int to_id, int path_type, unsigned time);
				bool access(int from_id, int to_id) const;

				int enter(unsigned time, playerDataPtr d, int army_id, int to_city_id);
				int enter(unsigned time, NpcDataPtr d, int to_city_id);
				int transferLimit(playerDataPtr d, int army_id, int to_city_id);
				int transfer(unsigned time, playerDataPtr d, int army_id, int to_city_id);
				int arrive(int timer_id, PLIter iter);
				int meet(int timer_id, PLIter lhs, PLIter rhs);
				int attack(int timer_id, PLIter lhs, PLIter rhs);

				void getMainInfo(qValue& q) { _manager.getMainInfo(q); }
				void getUpdateInfo(qValue& q) { _manager.getUpdateInfo(q); }

				void reset(unsigned cur_time);
				void clear(unsigned cur_time);

				int getOtherSideId(int side) const;
				int getLinkedId(int id) const;
				CityPtr getLinkedCity(int id) const;
			private:
				inline bool timerOverTime(int timer_id);
				void resetTimer();
				void setTimer(const PLIter& iter);

			private:
				int _id;
				CityPtr _linked_city[MaxSide];
				int _timer_id;
				PathItemMgr _manager;
		};

		BOOSTSHAREPTR(Path, PathPtr);

		class PathList
		{
			public:
				PathList();

				PathPtr getPath(int id);
				void push(const PathPtr& ptr);
				void update(bool is_first = false);

				void getMainInfo(qValue& q) { q = _main_info.Copy(); }
				void getUpdateInfo(qValue& q) { q = _update_info; } 

				void reset(unsigned cur_time);
				void clear(unsigned cur_time);

			private:
				STDMAP(int, PathPtr, PathMap);
				PathMap _paths;

				qValue _main_info;
				qValue _update_info;
		};
	}
}

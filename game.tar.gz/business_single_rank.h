//###################################
//create by Jim
//2016-11-07
//###################################

#pragma once

#include "dbDriver.h"

#define business_single_rank (*gg::BusinessSingleRank::_Instance)

namespace gg
{
	namespace NSBusinessSingleRank
	{
		struct Rankey
		{
			Rankey()
			{
				playerID = -1;
				businessMoney = 0;
			}
			Rankey(playerDataPtr player)
			{
				playerID = player->ID();
				businessMoney = player->Trade().historyMoney();
			}
			bool operator<(const Rankey& other)const
			{
				if (businessMoney != other.businessMoney)return businessMoney > other.businessMoney;
				return playerID < other.playerID;
			}
			bool operator>(const Rankey& other)const
			{
				return *this < other;
			}
			int playerID;
			int businessMoney;
		};

		struct RankData
		{
			Rankey Key()
			{
				Rankey key;
				key.playerID = playerID;
				key.businessMoney = businessMoney;
				return key;
			}
			RankData()
			{
				playerID = -1;
				playerName = "";
				playerNation = Kingdom::null;
				businessMoney = 0;
				rankNo = 0;
			}
			RankData(playerDataPtr player)
			{
				setNewData(player);
				rankNo = 0;
			}
			void setNewData(playerDataPtr player)
			{
				playerID = player->ID();
				playerName = player->Name();
				playerNation = player->Info().Nation();
				businessMoney = player->Trade().historyMoney();
			}
			int playerID;
			string playerName;
			int playerNation;
			int businessMoney;
			int rankNo;
		};

		BOOSTSHAREPTR(RankData, ptrRankData);

		STDMAP(Rankey, ptrRankData, RankMap);
		STDMAP(int, ptrRankData, PlayerMap);
	}

	class BusinessSingleRank
	{
	public:
		BusinessSingleRank() { isInitial = false; }
		static BusinessSingleRank* const _Instance;
		void initData();
		DeclareRegFunction(RankList);
	public:
		void updatePlayer(playerDataPtr player);
	private:
		NSBusinessSingleRank::ptrRankData getData(const int playerID);
		int getRank(const int playerID);

		NSBusinessSingleRank::RankMap Rank;
		NSBusinessSingleRank::PlayerMap Player;

		bool isInitial;
	};
}

#include "player_kingdomwar.h"
#include "kingdomwar_system.h"
#include "playerManager.h"
#include "man_system.h"
#include "task_mgr.h"
#include "chat.h"
#include "kingdomwar_task.h"

namespace gg
{
	namespace KingdomWar
	{
		enum
		{
			ReportSize = 20,
			HpItemID = 10002,
			upArmyHpPerSec = 6,
		};

		STDVECTOR(int, Times2Num);
		static int needHpItemNum(unsigned times)
		{
			static Times2Num times_num;
			if (times_num.empty())
			{
				Json::Value json = Common::loadJsonFile("./instance/kingdom_war/hp_item.json");
				Json::Value& num = json["num"];
				ForEach(Json::Value, it, num)
					times_num.push_back((*it).asInt());
				if (times_num.empty())
				{
					LogE << "kingdom war hp_item.json error" << LogEnd;
					return 1;
				}
			}
			if (times >= times_num.size())
				times = times_num.size() - 1;
			return times_num[times];
		}

		static int hpItemExploitBase()
		{
			Json::Value json = Common::loadJsonFile("./instance/kingdom_war/hp_item.json");
			return json["base"].asInt();
		}

		static double hpItemExploitRate()
		{
			Json::Value json = Common::loadJsonFile("./instance/kingdom_war/hp_item.json");
			return json["rate"].asDouble();
		}

		static int hpItemExploit(int lv)
		{
			static int base = hpItemExploitBase();
			static double rate = hpItemExploitRate();
			return base + lv * rate;
		}
	}

	int playerKingdomWar::ExploitReason = KingdomWar::Others;

	playerKingdomWar::playerKingdomWar(playerData* const own)
		: _auto_player(own), _report_id(0), _exploit(0), _total_exploit(0), _attach_city(-1), _siege_times(0), _rep_mgr(KingdomWar::ReportSize), _red_point(false)
		, _attach_main(false), _use_hp_item_times(0), _battle_times(0)
	{
		std::string path = "./report/kingdomwar/" + Common::toString(Own().ID());
		Common::createDirectories(path);

		_army_hp.assign(KingdomWar::ArmyNum, (int)KingdomWar::ArmyMaxHp);
		_army_hp_base.assign(KingdomWar::ArmyNum, 0);

		_win_streak.assign(KingdomWar::ArmyNum, 0);
	}

	void playerKingdomWar::classLoad()
	{
		mongo::BSONObj key = BSON(strPlayerID << Own().ID());
		mongo::BSONObj obj = db_mgr.FindOne(DBN::dbPlayerKingdomWar, key);
		if (obj.isEmpty())
			return;
		
		checkNotEoo(obj["mh"])
		{
			std::vector<mongo::BSONElement> ele = obj["mh"].Array();
			for (unsigned i = 0; i < ele.size(); ++i)
				_man_hp[ele[i]["i"].Int()] = ele[i]["h"].Int();
		}
		checkNotEoo(obj["ah"])
		{
			std::vector<mongo::BSONElement> ele = obj["ah"].Array();
			for (unsigned i = 0; i < ele.size(); ++i)
				_army_hp[i] = ele[i].Int();
		}
		checkNotEoo(obj["ahb"])
		{
			std::vector<mongo::BSONElement> ele = obj["ahb"].Array();
			for (unsigned i = 0; i < ele.size(); ++i)
				_army_hp_base[i] = ele[i].Int();
		}
		checkNotEoo(obj["rep"])
			_rep_mgr.load(obj["rep"]);
		checkNotEoo(obj["ri"])
			_report_id = obj["ri"].Int();
		checkNotEoo(obj["bt"])
			_battle_times = obj["bt"].Int();
		checkNotEoo(obj["ep"])
			_exploit = obj["ep"].Int();
		checkNotEoo(obj["te"])
			_total_exploit = obj["te"].Int();
		checkNotEoo(obj["st"])
			_siege_times = obj["st"].Int();
		checkNotEoo(obj["rp"])
			_red_point = obj["rp"].Bool();
		checkNotEoo(obj["uhit"])
			_use_hp_item_times = obj["uhit"].Int();
		checkNotEoo(obj["ws"])
		{
			std::vector<mongo::BSONElement> ele = obj["ws"].Array(); 
			for (unsigned i = 0; i < ele.size(); ++i)
				_win_streak[i] = ele[i].Int();
		}
	}

	bool playerKingdomWar::_auto_save()
	{
		mongo::BSONObj key = BSON(strPlayerID << Own().ID());
		mongo::BSONObjBuilder obj;
		obj << strPlayerID << Own().ID() << "ri" << _report_id << "ep" << _exploit
			<< "te" << _total_exploit << "st" << _siege_times << "rep" << _rep_mgr.toBSON()
			<< "rp" << _red_point << "uhit" << _use_hp_item_times << "bt" << _battle_times; //<< "ct" << _clear_time;
		if (!_man_hp.empty())
		{
			mongo::BSONArrayBuilder b;
			ForEach(Man2HpMap, it, _man_hp)
				b.append(BSON("i" << it->first << "h" << it->second));
			obj << "mh" << b.arr();
		}
		
		{
			mongo::BSONArrayBuilder b;
			ForEach(ArmyHp, it, _army_hp)
				b.append((*it));
			obj << "ah" << b.arr();
		}
		{
			mongo::BSONArrayBuilder b;
			ForEach(ArmyHp, it, _army_hp_base)
				b.append((*it));
			obj << "ahb" << b.arr();
		}
		{
			mongo::BSONArrayBuilder b;
			for (unsigned i = 0; i < 3; ++i)
				b.append(_win_streak[i]);
			obj << "ws" << b.arr();
		}
		return db_mgr.SaveMongo(DBN::dbPlayerKingdomWar, key, obj.obj());
	}

	void playerKingdomWar::_auto_update()
	{
	}

	int playerKingdomWar::manHp(int man_id) const
	{
		Man2HpMap::const_iterator it = _man_hp.find(man_id);
		return it != _man_hp.end()? it->second : 0;
	}

	void playerKingdomWar::setManHp(int man_id, int hp)
	{
		_man_hp[man_id] = hp;
		_sign_save();
	}

	bool playerKingdomWar::isDead(int army_id)
	{
		if (_army_hp[army_id] < 1)
			return true;
		else
			return Own().KingDomWarFM().isDead(army_id);
	}

	void playerKingdomWar::addShadowReport(qValue& report)
	{
		_rep_mgr.push(report);
		alterRedPoint(true);
		_sign_save();
	}

	void playerKingdomWar::addReport(qValue& report, int result, int state, int army_id)
	{
		++_battle_times;
		if (result == resBattle::atk_win)
		{
			TaskMgr::update(Own().getOwnDataPtr(), Task::KingdomWarWinTimes, 1);
			++_win_streak[army_id];
			kingdomwar_sys.updatePersonTask(Own().getOwnDataPtr(), KingdomWar::Task::WinStreakTimes, JARRAY(army_id << 1));
		}
		else
		{
			kingdomwar_sys.updatePersonTask(Own().getOwnDataPtr(), KingdomWar::Task::WinStreakTimes, JARRAY(army_id << 0));
		}

		if (state != KingdomWar::PosPath)
		{
			++_siege_times;
			TaskMgr::update(Own().getOwnDataPtr(), Task::KingdomWarSiegeAllTimes, 1);
		}

		_rep_mgr.push(report);
		alterRedPoint(true);
		kingdomwar_sys.updatePersonTask(Own().getOwnDataPtr(), KingdomWar::Task::BattleTimes, Json::Value(1));
	}

	std::string playerKingdomWar::getReportID()
	{
		++_report_id;
		if (_report_id > KingdomWar::ReportSize)
			_report_id = 1;
		return Common::toString(_report_id);
	}

	void playerKingdomWar::updateReport()
	{
		_rep_mgr.updateAll(Own().getOwnDataPtr(), gate_client::kingdom_war_report_info_resp);
		alterRedPoint(false);
	}

	int playerKingdomWar::alterExploit(int num)
	{
		if (num > 0)
		{
			int tmp = _exploit;
			_exploit += num;
			_total_exploit += num;
			kingdomwar_sys.updateRank(Own().getOwnDataPtr(), tmp);
			Log(DBLOG::strLogKingdomWar, Own().getOwnDataPtr(), 0, tmp, _exploit, ExploitReason);
			ExploitReason = KingdomWar::Others;
			TaskMgr::update(Own().getOwnDataPtr(), Task::GetExploitNum, num);
			Own().KingDomWarBox().resetRpStateAndUpdate();
			kingdomwar_sys.updateNationTask(Own().Info().Nation(), KingdomWar::Task::GetExploit2, Json::Value(num));
			kingdomwar_sys.updatePersonTask(Own().getOwnDataPtr(), KingdomWar::Task::GetExploit, Json::Value(num));
			KingdomWar::TaskParamHelper::shared().update(Own().ID());
		}
		else
		{
			Own().KingDomWarShop().alterUsedExploit(0 - num);
		}
		_sign_save();
		return 0;
	}

	void playerKingdomWar::resetArmyHp(int army_id, unsigned cur_time)
	{
		const KingdomWar::Position& pos = Own().KingDomWarPos().position(army_id);
		if (pos.type != KingdomWar::PosCity ||
			pos.id != KingdomWar::MainCity[Own().Info().Nation()])
			return;
		KingdomWar::CityPtr ptr = kingdomwar_sys.getMainCity(Own().Info().Nation());
		_army_hp_base[army_id] = ptr->getSup(cur_time);
		_sign_save();
	}

	int playerKingdomWar::alterArmyHp(int army_id, int num)
	{
		unsigned cur_time = Common::gameTime();
		int tmp = armyHp(army_id, cur_time, true);
		_army_hp[army_id] += num;
		if (_army_hp[army_id] < 0)
			_army_hp[army_id] = 0;
		if (_army_hp[army_id] > KingdomWar::ArmyMaxHp)
			_army_hp[army_id] = KingdomWar::ArmyMaxHp;
		_sign_save();
		Own().KingDomWarPos().updateHp(army_id);
		return _army_hp[army_id] - tmp;
	}

	void playerKingdomWar::fillArmyHp(int army_id)
	{
		_army_hp[army_id] = KingdomWar::ArmyMaxHp;
		_sign_save();
		Own().KingDomWarPos().updateHp(army_id);
	}

	int playerKingdomWar::armyHp(int army_id, unsigned cur_time, bool recal)
	{
		const KingdomWar::Position& pos = Own().KingDomWarPos().position(army_id);
		if ((recal || _army_hp[army_id] < KingdomWar::ArmyMaxHp)
			&& pos.type == KingdomWar::PosCity
			&& pos.id == KingdomWar::MainCity[Own().Info().Nation()])
		{
			KingdomWar::CityPtr ptr = kingdomwar_sys.getMainCity(Own().Info().Nation());
			if (cur_time == 0)
				cur_time = Common::gameTime();
			unsigned output_sup = ptr->getSup(cur_time);
			_army_hp[army_id] = _army_hp[army_id] + output_sup - _army_hp_base[army_id];
			_army_hp_base[army_id] = output_sup;
		}
		if (_army_hp[army_id] > KingdomWar::ArmyMaxHp)
			_army_hp[army_id] = KingdomWar::ArmyMaxHp;
		return _army_hp[army_id];
	}

	bool playerKingdomWar::armyHpFilled(int army_id)
	{
		return armyHp(army_id) >= KingdomWar::ArmyMaxHp;
	}
	
	int playerKingdomWar::buyHpItem(int num)
	{
		int cost = 50 * num;
		if (Own().Res().getCash() < cost)
			return err_gold_not_enough;

		if (!Own().Items().canAddItem(KingdomWar::HpItemID, num))
			return err_bag_full;
		Own().Res().alterCash(0 - cost);
		Own().Items().addItem(KingdomWar::HpItemID, num);
		Log(DBLOG::strLogKingdomWar, Own().getOwnDataPtr(), 5, num, cost);
		return res_sucess;
	}

	int playerKingdomWar::useHpItem(int army_id, int num)
	{
		int man_hp = Own().KingDomWarFM().getUpHpCost(army_id);
		if (man_hp == 0 && armyHpFilled(army_id))
			return err_kingdomwar_army_state_full;
		int cur_num = Own().Items().itemNum(KingdomWar::HpItemID);
		int need_num = KingdomWar::needHpItemNum(_use_hp_item_times);
		if (cur_num < need_num)
			return err_item_not_enough;
		Own().Items().removeItem(KingdomWar::HpItemID, need_num);
		alterArmyHp(army_id, 100 - _army_hp[army_id]);
		_army_hp[army_id] = 100;
		int add = Own().KingDomWarFM().upManHp(army_id);
		int per_exploit = KingdomWar::hpItemExploit(Own().LV());
		int exploit = need_num * per_exploit;
		if (exploit < 1)
			exploit = 1;
		ExploitReason = KingdomWar::UpManHp;
		Own().Res().alterExploit(exploit);
		++_use_hp_item_times;
		Log(DBLOG::strLogKingdomWar, Own().getOwnDataPtr(), 6, cur_num, cur_num - need_num);
		_sign_save();
		return res_sucess;
	}
		
	void playerKingdomWar::clearExploit()
	{
		int tmp = _exploit;
		_exploit = 0;
		Log(DBLOG::strLogKingdomWar, Own().getOwnDataPtr(), 0, tmp, _exploit, (int)KingdomWar::Clear);
		_sign_save();
	}

	void playerKingdomWar::alterRedPoint(bool rp)
	{
		if (_red_point != rp)
		{
			_red_point = rp;
			_sign_save();
			updateRedPoint();
		}
	}

	void playerKingdomWar::updateRedPoint()
	{
		qValue m;
		m.append(res_sucess);
		qValue q;
		q.append(_red_point? 1 : 0);
		q.append(Own().KingDomWarBox().rpState());
		q.append(KingdomWar::State::shared().get());
		q.append(kingdomwar_sys.supRate());
		q.append(Own().KingDomWarTask().nationTaskRP());
		q.append(Own().KingDomWarTask().personTaskRP());
		q.append(Own().KingDomWarBox().greatEventRP());
		m.append(q);
		Own().sendToClientFillMsg(gate_client::kingdom_war_red_point_resp, m);
	}

	void playerKingdomWar::attach(int id)
	{
		if (id == -1)
		{
			kingdomwar_sys.attach(Own().ID());
			_attach_main = true;
			return;
		}

		if (_attach_city >= 0)
		{
			KingdomWar::CityPtr ptr = kingdomwar_sys.getCity(_attach_city);
			if (ptr)
				ptr->detach(Own().ID());
			_attach_city = -1;
		}

		KingdomWar::CityPtr ptr = kingdomwar_sys.getCity(id);
		if (ptr)
		{
			ptr->attach(Own().ID());
			_attach_city = id;
		}
	}

	void playerKingdomWar::detach(int id)
	{
		if (_attach_city >= 0)
		{
			KingdomWar::CityPtr ptr = kingdomwar_sys.getCity(_attach_city);
			if (ptr)
				ptr->detach(Own().ID());
			_attach_city = -1;
		}

		if (id == -1)
		{
			kingdomwar_sys.detach(Own().ID());
			_attach_main = false;
		}
	}

	void playerKingdomWar::clearWinStreak(int army_id)
	{
		if (_win_streak[army_id] >= 4)
		{
			qValue m;
			if (_win_streak[army_id] >= 11)
				m.append(3);
			else if (_win_streak[army_id] >= 8)
				m.append(2);
			else
				m.append(1);
			m.append(chat_sys.ChatPackageQ(Own().getOwnDataPtr()));
			m.append(army_id);
			m.append(_win_streak[army_id]);
			m.append(Own().Info().Nation());
			qValue extra_json(qJson::qj_object);
			extra_json.addMember("weight", 0);
			extra_json.addMember("roll", 2);
			chat_sys.despatchAllSP(CHAT::server_kingdom_war, m, extra_json, CHATPOS::scroll_bar_top);
		}
		_win_streak[army_id] = 0;
		kingdomwar_sys.updatePersonTask(Own().getOwnDataPtr(), KingdomWar::Task::WinStreakTimes, JARRAY(army_id << 0));
		_sign_save();
	}

	void playerKingdomWar::dailyTick()
	{
		_battle_times = 0;
		_use_hp_item_times = 0;
		_sign_save();
	}
}

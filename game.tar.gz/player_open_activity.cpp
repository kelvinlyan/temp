#include "player_open_activity.h"
#include "open_activity_system.h"
#include "playerManager.h"
#include "email_system.h"

namespace gg
{
	enum
	{
		OpenActivityKeyID = 10086,
	};

	OpenActivityRecord::OpenActivityRecord(const mongo::BSONElement& obj)
		: Task::Record(obj){}

	OpenActivityRecord::OpenActivityRecord(int id, const Task::CheckPtr& ptr, playerDataPtr d)
		: Task::Record(id, ptr, d){}

	bool OpenActivityRecord::getCheckPtr() const
	{
		if (!_check_ptr)
		{
			DayTaskPtr ptr = open_activity_sys.getTask(_id);
			if (!ptr)
				return false;
			_check_ptr = ptr->_check_ptr;
		}
		return true;
	}

	playerOpenActivity::playerOpenActivity(playerData* const own)
		: _auto_player(own), _key_id(-1), _red_point(false)
	{
	}

	void playerOpenActivity::init()
	{
		_key_id = OpenActivityKeyID;
		_open_time = Common::getLastTime(5);
		_days = 0;
		_finished_count = 0;
		_target_states.assign(open_activity_sys.getTargetCount(), 0);
		_state = 1;
		dailyTick();
		_sign_save();
	}

	void playerOpenActivity::classLoad()
	{
		mongo::BSONObj key = BSON(strPlayerID << Own().ID());
		mongo::BSONObj obj = db_mgr.FindOne(DBN::dbPlayerOpenActivity, key);
		
		if (obj.isEmpty())
			return;

		_key_id = obj["kid"].Int();
		if (_key_id == -1)
			return;

		checkNotEoo(obj["st"])
			_state = obj["st"].Int();
		checkNotEoo(obj["dy"])
			_days = obj["dy"].Int();
		checkNotEoo(obj["fc"])
			_finished_count = obj["fc"].Int();
		checkNotEoo(obj["rl"])
			_record_mgr.load(obj["rl"]);
		checkNotEoo(obj["ot"])
			_open_time = obj["ot"].Int();
		checkNotEoo(obj["ts"])
		{
			std::vector<mongo::BSONElement> ele = obj["ts"].Array();
			for (unsigned i = 0; i < ele.size(); ++i)
				_target_states.push_back(ele[i].Int());
		}
		
		_red_point = getRedPoint();
	}

	bool playerOpenActivity::_auto_save()
	{
		mongo::BSONObj key = BSON(strPlayerID << Own().ID());
		mongo::BSONObjBuilder obj;
		obj << strPlayerID << Own().ID() << "kid" << _key_id;
		if (_key_id != -1)
		{ 
			obj << "dy" << _days << "fc" << _finished_count << "rl" << _record_mgr.toBSON()
				<< "ot" << _open_time << "st" << _state;
			{
				mongo::BSONArrayBuilder b;
				ForEachC(std::vector<int>, it, _target_states)
					b.append(*it);
				obj << "ts" << b.arr();
			}
		}
		return db_mgr.SaveMongo(DBN::dbPlayerOpenActivity, key, obj.obj());
	}

	void playerOpenActivity::_auto_update()
	{
		update();
	}

	void playerOpenActivity::update(int type, int arg1, int arg2)
	{
		if (_state != 1)
			return;
		bool modified = _record_mgr.check(Own().getOwnDataPtr(), type, arg1, arg2);
		if (modified)
		{
			const std::vector<int>& finished_list = _record_mgr.getFinishedList();
			if (!finished_list.empty())
			{
				alterFinishedCount(finished_list.size());
				updateRedPoint(true);
			}
			_sign_save();
		}
	}

	void playerOpenActivity::update()
	{
		Json::Value msg;
		msg[strMsg][0u] = res_sucess;
		_record_mgr.getInfo(msg[strMsg][1u]["rl"]);
		msg[strMsg][1u]["ot"] = _open_time;
		msg[strMsg][1u]["fc"] = _finished_count;
		Json::Value& tl = msg[strMsg][1u]["tl"];
		tl = Json::arrayValue;
		ForEachC(std::vector<int>, it, _target_states)
			tl.append(*it);
		msg[strMsg][1u]["dy"] = _days;
		
		Own().sendToClient(gate_client::open_activity_player_info_resp, msg);
	}

	int playerOpenActivity::getTaskReward(int id, Json::Value& r)
	{
		DayTaskPtr t = open_activity_sys.getTask(id);
		if (!t)
			return err_illedge;
		//Task::RecordPtr p = _record_mgr.getRecord(id);
		int state = _record_mgr.getState(id);
		if (state != Task::Finished)
			return err_illedge;
		int res = actionDoBox(Own().getOwnDataPtr(), t->_reward, false);
		if (res == res_sucess)
		{
			r[strMsg][1u] = actionRes();
			_record_mgr.setState(id, Task::Rewarded);
			updateRedPoint(true);
			_sign_auto();
		}
		else
		{
			Json::Value error_code = actionError();
			res = error_code[0u][1u].asInt();
		}
		return res;
	}

	int playerOpenActivity::getCountReward(int id, Json::Value& r)
	{
		if (id < 0 || id >= _target_states.size())
			return err_illedge;

		if (_target_states[id] != Task::Finished)
			return err_illedge;

		DayTargetPtr ptr = open_activity_sys.getTarget(id + 1);
		if (!ptr)
			return err_illedge;
			
		int res = actionDoBox(Own().getOwnDataPtr(), ptr->_reward, false);
		if (res == res_sucess)
		{
			_target_states[id] = Task::Rewarded;
			r[strMsg][1u] = actionRes();
			updateRedPoint(true);
			_sign_auto();
		}
		else
		{
			Json::Value error_code = actionError();
			res = error_code[0u][1u].asInt();
		}

		return res;
	}

	void playerOpenActivity::alterFinishedCount(int n)
	{
		_finished_count += n;
		for (unsigned id = 0; id < _target_states.size(); ++id)
		{
			if (_target_states[id] != Task::Running)
				continue;

			DayTargetPtr ptr = open_activity_sys.getTarget(id + 1);
			if (ptr && _finished_count >= ptr->_count)
			{
				_target_states[id] = Task::Finished;
				_sign_save();
				updateRedPoint(true);
			}
			else
				break;
		}
	}

	void playerOpenActivity::updateRedPoint(bool check)
	{
		bool rp = getRedPoint();
		if (check && _red_point == rp)
			return;

		_red_point = rp;
		Json::Value msg;
		msg[strMsg][0u] = res_sucess;
		msg[strMsg][1u] = _red_point;
		Own().sendToClient(gate_client::open_activity_red_point_resp, msg);
	}

	bool playerOpenActivity::getRedPoint()
	{
		if (!_record_mgr.taskFinished())
		{
			ForEachC(std::vector<int>, it, _target_states)
			{
				if (*it == Task::Finished)
					return true;
			}
			return false;
		}
		else
			return true;
	}

	static std::vector<int> finished_task;
	static void addFinishedTask(const Task::RecordPtr& ptr)
	{
		if (ptr->state() == Task::Finished)
			finished_task.push_back(ptr->id());
	}

	void playerOpenActivity::dailyTick()
	{
		if (_key_id == -1)
			return;

		int cur_day = (Common::gameTime() - _open_time) / DAY + 1;
		for (; _days < cur_day;)
		{
			DayTaskList day_tasks = open_activity_sys.getDaysTask(++_days);
			if (day_tasks.empty())
				break;
			ForEachC(DayTaskList, it, day_tasks)
			{
				DayTaskPtr ptr = *it;
				Task::RecordPtr r = Creator<OpenActivityRecord>::Create(ptr->_id, ptr->_check_ptr, Own().getOwnDataPtr());
				_record_mgr.push(r);
				if (r->state() == Task::Finished)
					alterFinishedCount(1);
			}
		}
		if (cur_day > open_activity_sys.taskDay())
		{
			_state = 0;

			_key_id = -1;
			Json::Value msg;
			msg[strMsg][0u] = res_sucess;
			msg[strMsg][1u]["kid"] = 0;
			Own().sendToClient(gate_client::open_activity_config_info_resp, msg);

			finished_task.clear();
			_record_mgr.run(boostBind(addFinishedTask, _1));
			Json::Value rw = Json::arrayValue;
			ForEachC(std::vector<int>, it, finished_task)
			{
				DayTaskPtr ptr = open_activity_sys.getTask(*it);
				if (!ptr) continue;
				combineActionRes(ptr->_reward_info, rw);
			}
			for (unsigned i = 0; i < _target_states.size(); ++i)
			{
				if (_target_states[i] != Task::Running)
					continue;

				DayTargetPtr ptr = open_activity_sys.getTarget(i + 1);
				if (ptr && _finished_count >= ptr->_count)
					combineActionRes(ptr->_reward_info, rw);
			}
			if (rw.size() != 0)
			{
				EmailPtr e = email_sys.createPackage(EmailDef::DaysActivityReward, JARRAY(open_activity_sys.getName()), rw);
				email_sys.sendToPlayer(Own().ID(), e);
			}
		}
		_sign_save();
	}
}


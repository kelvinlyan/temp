#include "player_market.h"
#include "ownerland_system.h"
#include "ownerland_def.h"
//#include "kingdom.h"
#include "kingdom_system.h"
#include "task_mgr.h"
#include "discount.h"

namespace gg
{
	playerMarket::playerMarket(playerData* const own)
		: _auto_player(own)
	{
		initialMarket();
	}

	void playerMarket::initialMarket()
	{
		marketAdminList[LAND::idx_building_res_cropland] =
			marketAdminList[LAND::idx_building_res_silver] =
			marketAdminList[LAND::idx_building_res_iron] =
			marketAdminList[LAND::idx_building_res_wood] =
			-MAX_MARKET_BUY_NUM;
	}

	void playerMarket::resetMarket()
	{
		// ���б��뿪��
		if (!Own().Builds().isBuildValid(LAND::idx_building_type_market)) { return; }
		initialMarket();
		_sign_auto();
	}

	int playerMarket::marketBuyRes(LAND::BuildResource eResource, int &riAddRes, float &rfOdds, int &riExtraRes)
	{
		if (!Own().Builds().isBuildValid(LAND::idx_building_type_market)) { return err_illedge; }
		MarketAdminList::iterator it_market = marketAdminList.find(eResource);
		if (it_market == marketAdminList.end()) { return err_illedge; }
		const int iBuyNum = it_market->second;

		riAddRes = 0;
		rfOdds = 0;
		riExtraRes = 0;

		int riCash = 0;
		getMarketBuyData(eResource, iBuyNum, riAddRes, riCash);
		riCash *= discout_sys.getRate(Discount::market_cost_rate);

		if (Own().Res().getCash() < riCash) { return err_cash_not_enough; }

		int iRandomNum = Common::randomBetween(0, 99);
		if (iRandomNum < 80) { rfOdds = 1; }
		else if (iRandomNum < 95) { rfOdds = 2; }
		else { rfOdds = 5; }

		++it_market->second;
		_sign_auto();

		riAddRes = riAddRes*rfOdds*discout_sys.getRate(Discount::market_buy_reward_rate);

		//�ó�������ֱ�
		//int kingdomAddPer = kingdom_sys.getBuildResNum(Own().Info().Nation(), eResource); //���ҽ������ӵ�����
		int kingdomAddPer = 0;
		const KingdomPtr ptr = kingdom_sys.getData(Own().Info().Nation());
		if (ptr)
			kingdomAddPer += ptr->getAddNum(getType(eResource));

		riExtraRes = riAddRes * ((double)kingdomAddPer / 10000.0);

		LAND::resMap kResource;
		kResource[eResource] = riAddRes + riExtraRes;
		updateTask(eResource, kResource[eResource]);
		ownerland_sys.alterResource(Own().getOwnDataPtr(), kResource, true);
		Own().Res().alterCash(riCash*(-1));

		Log(DBLOG::strLogMarket, Own().getOwnDataPtr(), -1, (int)eResource, riCash <= 0 ? 0 : 1, riCash, kResource[eResource]);
		return res_sucess;
	}

	bool playerMarket::getMarketBuyData(LAND::BuildResource eResource, int iBuyNum, int &riAddRes, int &riCash)
	{
		const marketResPtr marketResPtr_ptr = iBuyNum < 0 ? marketResPtr() : ownerland_sys.getMarketRes(iBuyNum + 1);
		if (eResource == LAND::idx_building_res_silver) { riAddRes = Own().Info().LV() * 120; riCash = marketResPtr_ptr ? marketResPtr_ptr->iSilver : 0; }
		else if (eResource == LAND::idx_building_res_cropland) { riAddRes = Own().Info().LV() * 500; riCash = marketResPtr_ptr ? marketResPtr_ptr->iCropland : 0; }
		else if (eResource == LAND::idx_building_res_wood) { riAddRes = 40000 + Own().Info().LV() * 1000; riCash = marketResPtr_ptr ? marketResPtr_ptr->iWood : 0; }
		else if (eResource == LAND::idx_building_res_iron) { riAddRes = 40000 + Own().Info().LV() * 1000; riCash = marketResPtr_ptr ? marketResPtr_ptr->iIron : 0; }
		else { return false; }
		return true;
	}

	void playerMarket::sendMarketData()
	{
		qValue json(qJson::qj_array), data_json(qJson::qj_array);

		for (MarketAdminList::iterator itr = marketAdminList.begin(); itr != marketAdminList.end(); ++itr)
		{
			int riAddRes = 0;
			int riCash = 0;
			getMarketBuyData(itr->first, itr->second, riAddRes, riCash);

			qValue tmp(qJson::qj_array);
			tmp.append(itr->first);
			tmp.append(MAX_MARKET_BUY_NUM);
			tmp.append(itr->second);
			tmp.append(riAddRes);
			tmp.append(riCash);
			data_json.append(tmp);
		}
		json.append(res_sucess).append(data_json);
		// [[��Դ����ID��ÿ����ѹ����������Ѵ��������Ѿ��������(������ʾ������Ѵ������Σ�������ʾ�Ѿ�����Ĵ���)�����ο��Թ����Ӧ��Դ����������Ҫ���ѵĽ������]
		Own().sendToClientFillMsg(gate_client::building_market_base_data_resp, json);
	}


	void playerMarket::classLoad()
	{
		//marketAdminList.clear();

		mongo::BSONObj keyFind = BSON(strPlayerID << Own().ID());
		mongo::BSONObj objFind = db_mgr.FindOne(DBN::dbPlayerMarket, keyFind);
		if (objFind.isEmpty())return;

		vector<mongo::BSONElement> vec = objFind["market"].Array();
		for (unsigned i = 0; i < vec.size(); i++)
		{
			mongo::BSONElement& elem = vec[i];
			LAND::BuildResource eResource = (LAND::BuildResource)elem["type"].Int();
			if (marketAdminList.find(eResource) == marketAdminList.end())continue;
			marketAdminList[eResource] = elem["num"].Int();
		}
	}

	bool playerMarket::_auto_save()
	{
		mongo::BSONObj key = BSON(strPlayerID << Own().ID());
		mongo::BSONArrayBuilder marketarray;
		for (MarketAdminList::iterator itr = marketAdminList.begin(); itr != marketAdminList.end(); ++itr)
		{
			mongo::BSONObjBuilder tmp;
			tmp.append("type", itr->first);
			tmp.append("num", itr->second);
			marketarray.append(tmp.obj());
		}
		mongo::BSONObj obj = BSON(strPlayerID << Own().ID() <<
			"market" << marketarray.arr());
		return db_mgr.SaveMongo(DBN::dbPlayerMarket, key, obj);
	}

	void playerMarket::_auto_update()
	{
		sendMarketData();
	}

	int playerMarket::getType(int resource)
	{
		switch (resource)
		{
			case LAND::idx_building_res_wood:
			case LAND::idx_building_res_silver:
			case LAND::idx_building_res_iron:
			case LAND::idx_building_res_cropland:
				return Kingdom::CAgriculture;
			case LAND::idx_building_res_fame:
				return Kingdom::CFame;
			default:
				return -1;
		}
	}

	void playerMarket::updateTask(int type, int resource)
	{
		TaskMgr::update(Own().getOwnDataPtr(), Task::MarketTimes, 1);

		switch(type)
		{
			case LAND::idx_building_res_cropland:
				TaskMgr::update(Own().getOwnDataPtr(), Task::MarketFoodTimes, 1);
				TaskMgr::update(Own().getOwnDataPtr(), Task::MarketFoodNum, resource);
				break;
			case LAND::idx_building_res_silver:
				TaskMgr::update(Own().getOwnDataPtr(), Task::MarketSilverTimes, 1);
				TaskMgr::update(Own().getOwnDataPtr(), Task::MarketSilverNum, resource);
				break;
			case LAND::idx_building_res_iron:
				TaskMgr::update(Own().getOwnDataPtr(), Task::MarketIronTimes, 1);
				TaskMgr::update(Own().getOwnDataPtr(), Task::MarketIronNum, resource);
				break;
			case LAND::idx_building_res_wood:
				TaskMgr::update(Own().getOwnDataPtr(), Task::MarketWoodTimes, 1);
				TaskMgr::update(Own().getOwnDataPtr(), Task::MarketWoodNum, resource);
				break;
			default:
				break;
		}
	}
}

//###################################
//create by Jim
//2016-02-04
//###################################

#pragma once 

#include "dbDriver.h"

#define business_sys (*gg::business::_Instance)

namespace gg
{
	class business
	{
	public:
		static business* const _Instance;
		void initData();

		ASTAR::Vec2 getAvailablePos();
		void playerOFFLine(const int playerID);
		bool availablePlace(const unsigned x, const unsigned y);//���Է��õ�Ԫ��
		bool inSharkArea(const unsigned x, const unsigned y);

		DeclareRegFunction(update_car);//update car pos
		DeclareRegFunction(update_base);//update base
		DeclareRegFunction(update_ware);//update ware
		DeclareRegFunction(update_buff);//update buff
		DeclareRegFunction(update_move);//update move
		DeclareRegFunction(end_move);//end move
		DeclareRegFunction(accept_task);//��������
		DeclareRegFunction(complete_task);//�������
		DeclareRegFunction(complete_task_ok);//�������
 		DeclareRegFunction(update_city);//��ȡ������Ϣ
 		DeclareRegFunction(buy_item);//��
 		DeclareRegFunction(sale_item);//��
		DeclareRegFunction(car_upgrade);//��ֻ����
		DeclareRegFunction(item_use);//ʹ�õ���
		DeclareRegFunction(open_box);//ʹ��Կ��
		DeclareRegFunction(challenge_pirate);//��ս����
		DeclareRegFunction(car_teleport);//˲��
		DeclareRegFunction(car_repair);//��ֻά��
		DeclareRegFunction(cancel_task);//ȡ������
		DeclareRegFunction(money_show);//չʾ��Ʊ
		DeclareRegFunction(city_event);//���³����¼�
		DeclareRegFunction(route_data);//·������
		DeclareRegFunction(sence_enter);//��������
		DeclareRegFunction(sence_exit);//�����˳�
		DeclareRegFunction(hit_shark_boss);//��������boss
		DeclareRegFunction(reward_shark_boss);//��ȡ����boss�Ľ���

		void updateName(playerDataPtr player);
		void insertDayRich(playerDataPtr player, const int money);
		void insertHisRich(playerDataPtr player, const int money);
		void insertTotalRich(playerDataPtr player, const int money);

		void updateMoveCar(playerDataPtr player);
	private:
		void cityPriceTick(const structTimer& timerData);
		void cityEventTick(const structTimer& timerData);
		void mapEventTick(const structTimer& timerData);
		void richTick(const structTimer& timerData);
		void dayRichTick(const structTimer& timerData);
		int cityPriceRate(const int cityID);

	private:
		void saveDayRich();
		void saveHistoryRich();
		void saveTotalRich();
		void saveTimerRich();
		void saveSharkBoss();
	};
}
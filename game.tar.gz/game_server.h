#pragma once

#include "Glog.h"
#include <boost/bind.hpp>
#include <boost/asio.hpp>
#include <boost/shared_ptr.hpp>
#include <boost/thread/thread_time.hpp>
#include <boost/thread/mutex.hpp>
#include <map>
#include <json/json.h>
#include <iostream>
#include "game_handle.h"
#include "core_helper.h"
#include "queue_server.h"

using namespace std;
#define game_svr (gg::game::getInstance())

namespace gg
{
	struct GGData
	{
		unsigned client_limit;
		int port;
		string _mongoDB;
		string _sql_ip;
		string _sql_port;
	};

	class game : 
		public net::queue_server
	{
		typedef boost::shared_ptr<handler> game_handle_pointer;
		BOOSTSHAREPTR(game, this_ptr);
	public:
		~game();
		static this_ptr getInstance();
		void async_send_to_db(net::Msg& mj);
		void async_send_to_gate(net::Msg& mj);
		//void async_send_to_gate(const short protocol, Json::Value& msg, const int netID = -1, const int playerID = -1);
		virtual void initial();
		virtual void stop();
		virtual void on_update();
		virtual void on_recv_msg(const net::ptrMsg recv_msg_ptr);
		virtual void socket_error(net::linkLocalPtr session, int error_value);
		const GGData& getGGData() const { return game_data; }
	protected:
		void InitialGame();
		virtual bool is_go_on_accept();
		virtual void begin_on_accept(net::linkLocalPtr conn_ptr);
		virtual void end_on_accept(net::linkLocalPtr conn_ptr);
		virtual void start_accept();
	private:
		void connect_log_svr();
		void sendheartbeat();
		void checkkick(boost::system_time& now);
		void kick(net::linkLocalPtr session, bool notify = false);
		void kick_async(net::linkLocalPtr session);
		boost::system_time tick;
		void connect(net::linkLocalPtr connector,const char* ip_str, const char* port_str);
		void handle_connect(net::linkLocalPtr connector, const boost::system::error_code& error);
		GGData game_data;
		net::linkLocalPtr log_connect;
		game_handle_pointer game_handler;
		bool been_initial;
		bool is_run;
	private:		
		game();
	};
}

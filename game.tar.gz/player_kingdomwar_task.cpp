#include "player_kingdomwar_task.h"
#include "kingdomwar_data.h"
#include "playerManager.h"
#include "kingdomwar_system.h"

namespace gg
{
	namespace KingdomWar
	{
		namespace Task
		{

#define CHECKER(name)\
	class name\
		: public ICheck\
	{\
		public:\
			static CheckPtr create(const Json::Value& info)\
			{\
				return Creator<name>::Create(info);\
			}\
			name(const Json::Value& info)\
				: ICheck(info["type"].asInt())\
			{\
				ForEachC(Json::Value, it, info["arg"])\
					_args.push_back((*it).asInt());\
			}\
			virtual int update(playerDataPtr d, ParamPtr& param, const Json::Value& arg);\
			virtual int init(playerDataPtr d, ParamPtr& param);\
			std::vector<int> _args;\
	}

			CHECKER(CBattleTimes);
			CHECKER(CWinStreakTimes);
			CHECKER(CGetExploit);
			CHECKER(CUseFood);

			int CBattleTimes::update(playerDataPtr d, ParamPtr& param_ptr, const Json::Value& arg)
			{
				int val = arg.asInt();
				OneInt& param = *(upCast<OneInt>(param_ptr));
				param[0] += val;
				if (param[0] > _args[0u])
					param[0] = _args[0u];
				return param[0] >= _args[0u]? Finished : Running;
			}

			int CBattleTimes::init(playerDataPtr d, ParamPtr& param_ptr)
			{
				param_ptr = Creator<OneInt>::Create();
				OneInt& param = *(upCast<OneInt>(param_ptr));
				param[0] = 0;
				return param[0] >= _args[0u]? Finished : Running;
			}

			int CWinStreakTimes::update(playerDataPtr d, ParamPtr& param_ptr, const Json::Value& arg)
			{
				FourInt& param = *(upCast<FourInt>(param_ptr));
				int army_id = arg[0u].asInt();
				int action = arg[1u].asInt();
				unsigned idx = army_id + 1;
				if (action == 0)
					param[idx] = 0;
				else
					++param[idx];
				if (param[idx] == _args[1u])
					++param[0];
				if (param[0] > _args[0u])
					param[0] = _args[0u];
				return param[0] >= _args[0u]? Finished : Running;
			}

			int CWinStreakTimes::init(playerDataPtr d, ParamPtr& param_ptr)
			{
				param_ptr = Creator<FourInt>::Create();
				FourInt& param = *(upCast<FourInt>(param_ptr));
				param[0] = 0;
				param[1] = 0;
				param[2] = 0;
				param[3] = 0;
				return param[0] >= _args[0u]? Finished : Running;
			}

			int CGetExploit::update(playerDataPtr d, ParamPtr& param_ptr, const Json::Value& arg)
			{
				TwoInt& param = *(upCast<TwoInt>(param_ptr));
				int val = arg.asInt();
				param[0] += val;
				if (param[0] > param[1])
					param[0] = param[1];
				return param[0] >= param[1]? Finished : Running;
			}

			int CGetExploit::init(playerDataPtr d, ParamPtr& param_ptr)
			{
				param_ptr = Creator<TwoInt>::Create();
				TwoInt& param = *(upCast<TwoInt>(param_ptr));
				param[0] = 0;
				param[1] = _args[0u] * d->LV() + _args[1u];
				return param[0] >= param[1]? Finished : Running;
			}

			int CUseFood::update(playerDataPtr d, ParamPtr& param_ptr, const Json::Value& arg)
			{
				TwoInt& param = *(upCast<TwoInt>(param_ptr));
				int val = arg.asInt();
				param[0] += val;
				if (param[0] > param[1])
					param[0] = param[1];
				return param[0] >= param[1]? Finished : Running;
			}

			int CUseFood::init(playerDataPtr d, ParamPtr& param_ptr)
			{
				param_ptr = Creator<TwoInt>::Create();
				TwoInt& param = *(upCast<TwoInt>(param_ptr));
				param[0] = 0;
				param[1] = _args[0u] * d->LV() + _args[1u];
				return param[0] >= param[1]? Finished : Running;
			}

			class CheckPtrFactory
			{
				public:
					typedef boost::function<CheckPtr(const Json::Value&)> CreateFunc;
					STDVECTOR(CreateFunc, CreateFuncMap);
					CheckPtrFactory()
					{
						_creator_map[BattleTimes] = boostBind(CBattleTimes::create, _1);
						_creator_map[GetExploit] = boostBind(CGetExploit::create, _1);
						_creator_map[WinStreakTimes] = boostBind(CWinStreakTimes::create, _1);
						_creator_map[UseFood] = boostBind(CUseFood::create, _1);
					}
					CheckPtr create(const Json::Value& info)
					{
						int type = info["type"].asInt();
						if (type <= Empty || type >= PTaskMax)
							return _creator_map[Empty](info);

						return _creator_map[type](info);
					}
				private:
					CreateFunc _creator_map[PTaskMax];
			};

			struct PersonTaskConfig
			{
				PersonTaskConfig(): id(-1){}
				PersonTaskConfig(const Json::Value& info)
				{
					static CheckPtrFactory factory;
					id = info["id"].asInt();
					weight = info["weight"].asInt();
					checker = factory.create(info);
					reward = info["reward"];
				}
				bool valid() const { return id != -1; }
				int id;
				int weight;
				CheckPtr checker;
				Json::Value reward;
			};

			class PersonTaskConfigMgr
			{
				public:
					static PersonTaskConfigMgr& shared()
					{
						static PersonTaskConfigMgr config_mgr; 
						return config_mgr;
					}
					
					PersonTaskConfigMgr()
					{
						Json::Value json = Common::loadJsonFile("./instance/kingdom_war/personal_task.json");
						ForEach(Json::Value, it, json)
						{
							_total_weight += (*it)["weight"].asUInt();
							_config_map.insert(make_pair((*it)["id"].asInt(), PersonTaskConfig(*it)));
						}
						if (_config_map.empty())
							LogE << "kingdom war personal_task.json error" << LogEnd;
					}

					const PersonTaskConfig& getConfig(int id) const
					{
						ConfigMap::const_iterator it = _config_map.find(id);
						return it == _config_map.end()? _null : it->second;
					}

					const PersonTaskConfig& randConfig() const
					{
						unsigned val = Common::randomUInt(1, _total_weight);
						unsigned tmp = 0;
						ForEachC(ConfigMap, it, _config_map)
						{
							if (val <= it->second.weight + tmp)
								return it->second;
							else
								tmp += it->second.weight;
						}
						return _null;
					}
					
				private:
					static PersonTaskConfig _null;
					STDMAP(int, PersonTaskConfig, ConfigMap);
					ConfigMap _config_map;
					unsigned _total_weight;
			};

			PersonTaskConfig PersonTaskConfigMgr::_null;

			void PRecord::load(const PersonTaskConfig& config, playerDataPtr d)
			{
				_id = config.id;
				_checker = config.checker;
				_state = _checker->init(d, _param);
			}

			void PRecord::load(const mongo::BSONElement& obj)
			{
				_id = obj["i"].Int();
				if (_id == -1)
					return;
				_state = obj["s"].Int();
				_param = ParamFactory::create(obj["p"]);
			}

			mongo::BSONObj PRecord::toBSON() const 
			{
				if (_id == -1)
					return BSON("i" << _id);
				else
					return BSON("i" << _id << "s" << _state << "p" << _param->toBSON());
			}

			void PRecord::getInfo(qValue& q) const
			{
				q.append(_id);
				if (_id == -1)
					return;
				q.append(_state);
				qValue p;
				_param->getInfo(p);
				q.append(p);
			}

			void PRecord::update(playerDataPtr d, const Json::Value& arg)
			{
				if (!_checker
					&& !getChecker())
					return;
				_state = _checker->update(d, _param, arg);			
			}

			bool PRecord::getChecker()
			{
				const PersonTaskConfig& config = PersonTaskConfigMgr::shared().getConfig(_id);
				if (!config.valid())
					return false;
				_checker = config.checker;
				return true;
			}

			int PRecord::getSchedule()
			{
				if (_id == -1)
					return 0;
				switch(type())
				{
					case BattleTimes:
					{
						OneInt& param = *(upCast<OneInt>(_param));
						return param[0];
					}
					case WinStreakTimes:
					{
						FourInt& param = *(upCast<FourInt>(_param));
						return param[0];
					}
					case GetExploit:
					case UseFood:
					{
						TwoInt& param = *(upCast<TwoInt>(_param));
						return param[0];
					}
					default:
						return 0;
				}
			}

			int PRecord::getTarget()
			{
				if (_id == -1)
					return 0;
				switch(type())
				{
					case BattleTimes:
					{
						boost::shared_ptr<CBattleTimes> check_ptr = upCast<CBattleTimes>(_checker);
						return check_ptr->_args[0u];
					}
					case WinStreakTimes:
					{
						boost::shared_ptr<CWinStreakTimes> check_ptr = upCast<CWinStreakTimes>(_checker);
						return check_ptr->_args[0u];
					
					}
					case GetExploit:
					case UseFood:
					{
						TwoInt& param = *(upCast<TwoInt>(_param));
						return param[1];
					}
					default:
						return 0;
				}
				
			}
		}
	}

	using namespace KingdomWar;

	playerKingdomWarTask::playerKingdomWarTask(playerData* const own)
		: _auto_player(own), _task_lv(0), _next_update_time(0)
	{
		_nation_task_state = -1;
		_pt_rp = -1;
		_nt_rp = -1;
	}

	void playerKingdomWarTask::classLoad()
	{
		mongo::BSONObj key = BSON(strPlayerID << Own().ID());
		mongo::BSONObj obj = db_mgr.FindOne(DBN::dbPlayerKingdomWarTask, key);
		if (!obj.isEmpty())
		{
			checkNotEoo(obj["ptk"])
				_person_task.load(obj["ptk"]);
			checkNotEoo(obj["tct"])
				_task_clear_time = obj["tct"].Int();
			checkNotEoo(obj["nts"])
				_nation_task_state = obj["nts"].Int();
			checkNotEoo(obj["tl"])
				_task_lv = obj["tl"].Int();
		}
	}

	bool playerKingdomWarTask::_auto_save()
	{
		mongo::BSONObj key = BSON(strPlayerID << Own().ID());
		mongo::BSONObjBuilder obj;
		obj << strPlayerID << Own().ID() << "tct" << _task_clear_time
			<< "ptk" << _person_task.toBSON() << "nts" << _nation_task_state
			<< "tl" << _task_lv;
		return db_mgr.SaveMongo(DBN::dbPlayerKingdomWarTask, key, obj.obj());
	}

	void playerKingdomWarTask::initUpdateTime()
	{
		unsigned cur_time = Common::gameTime();
		if (_person_task.id() == -1)
		{
			getNextResetTime(cur_time);
		}
		else
		{
			_next_update_time = _task_clear_time;
			_action = CLEAR;
		}
	}

	void playerKingdomWarTask::_auto_update()
	{
		update();
	}

	void playerKingdomWarTask::update()
	{
		checkAndUpdate();
		qValue m;
		m.append(res_sucess);
		qValue q(qJson::qj_object);
		qValue l;
		_person_task.getInfo(l);
		q.addMember("l", l);
		q.addMember("t", KingdomWar::PrimeState::shared()? KingdomWar::PrimeState::shared().nextTickTime() : 0);
		q.addMember("lv", _task_lv);
		m.append(q);
		Own().sendToClientFillMsg(gate_client::kingdom_war_person_task_resp, m);
	}

	void playerKingdomWarTask::getNextResetTime(unsigned cur_time)
	{
		unsigned zero_time = Common::timeZero(cur_time);
		unsigned close_time_1 = zero_time + PrimeCloseTime1;
		unsigned close_time_2 = zero_time + PrimeCloseTime2;
		if (cur_time < close_time_1)
			_next_update_time = zero_time + PrimeOpenTime1;
		else if (cur_time < close_time_2)
			_next_update_time = zero_time + PrimeOpenTime2;
		else
			_next_update_time = zero_time + PrimeOpenTime1 + DAY;
		_action = RESET;
	}

	void playerKingdomWarTask::getNextClearTime(unsigned cur_time)
	{
		unsigned zero_time = Common::timeZero(cur_time);
		unsigned secs = cur_time - zero_time;
		if (secs == PrimeOpenTime1)
			_task_clear_time = zero_time + PrimeOpenTime2;
		else
			_task_clear_time = Common::getNextTimeHMS(cur_time, 5);
		_next_update_time = _task_clear_time;
		_action = CLEAR;
	}

	void playerKingdomWarTask::checkAndUpdate()
	{
		if (Own().Info().Nation() == Kingdom::null)
			return;
		if (_next_update_time == 0)
			initUpdateTime();
			
		unsigned cur_time = Common::gameTime();
		while (cur_time >= _next_update_time)
		{
			if (_action == CLEAR)
			{
				clear();
				getNextResetTime(_next_update_time);
			}
			else
			{
				reset();
				getNextClearTime(_next_update_time);
			}
			_sign_save();
		}
	}

	void playerKingdomWarTask::clear()
	{
		_person_task.clear();
		_nation_task_state = 0;
		resetPersonTaskRPAndUpdate();
		resetNationTaskRPAndUpdate();
	}

	void playerKingdomWarTask::reset()
	{
		const KingdomWar::Task::PersonTaskConfig& config = KingdomWar::Task::PersonTaskConfigMgr::shared().randConfig();
		if (!config.valid())
		{
			LogE << "kingdom war person task rand error" << LogEnd;
			return;
		}
		_person_task.load(config, Own().getOwnDataPtr());
		_task_lv = Own().LV();
		_nation_task_state = 0;
		resetPersonTaskRPAndUpdate();
		resetNationTaskRPAndUpdate();
	}

	void playerKingdomWarTask::update(int type, const Json::Value& arg)
	{
		checkAndUpdate();

		if (_person_task.type() != type
				|| _person_task.state() != KingdomWar::Task::Running)
			return;

		_person_task.update(Own().getOwnDataPtr(), arg);
		if (_person_task.state() == KingdomWar::Task::Finished)
			resetPersonTaskRPAndUpdate();
		_sign_save();
	}

	int playerKingdomWarTask::getPersonTaskReward(int id, Json::Value& r)
	{
		checkAndUpdate();

		if (_person_task.state() != KingdomWar::Task::Finished)
			return err_illedge;

		const KingdomWar::Task::PersonTaskConfig& config = KingdomWar::Task::PersonTaskConfigMgr::shared().getConfig(_person_task.id());
		if (!config.valid())
			return err_illedge;

		const Json::Value& reward = config.reward;
		int arg1 = reward[0u].asInt();
		int arg2 = reward[1u].asInt();
		int arg3 = reward[2u].asInt();
		int arg4 = reward[3u].asInt();
		int silver = _task_lv * arg1 + arg2;
		int exploit = _task_lv * arg3 + arg4;
		silver = Own().Res().alterSilver(silver);
		Own().Res().alterExploit(exploit);
		Own().Items().addItem(10005, 5);
		{
			Json::Value tmp;
			tmp.append(ACTION::silver);
			tmp.append(silver);
			r.append(tmp);
		}
		{
			Json::Value tmp;
			tmp.append(ACTION::exploit_coin);
			tmp.append(exploit);
			r.append(tmp);
		}
		{
			Json::Value tmp;
			tmp.append(ACTION::item);
			tmp.append(10005);
			tmp.append(5);
			r.append(tmp);
		}
		_person_task.setState(KingdomWar::Task::Rewarded);
		resetPersonTaskRPAndUpdate();
		_sign_auto();
		return res_sucess;
	}

	int playerKingdomWarTask::nationTaskState()
	{
		checkAndUpdate();
		return _nation_task_state;
	}

	void playerKingdomWarTask::setNationRewarded()
	{
		checkAndUpdate();
		_nation_task_state = 1;
		resetNationTaskRPAndUpdate();
		_sign_save();
	}

	void playerKingdomWarTask::personalTaskLog(unsigned end_time)
	{
		if (_person_task.id() != -1)
		{
			Log(DBLOG::strLogKingdomWar, Own().getOwnDataPtr(), 10, end_time, _person_task.type()
				, _person_task.getSchedule(), _person_task.getTarget());
		}
	}

	int playerKingdomWarTask::personTaskRP()
	{
		if (_pt_rp == -1)
			resetPersonTaskRP();
		return _pt_rp;
	}

	void playerKingdomWarTask::resetPersonTaskRP()
	{
		if (_person_task.id() != -1
			&& _person_task.state() == KingdomWar::Task::Finished)
			_pt_rp = 1;
		else
			_pt_rp = 0;
	}

	void playerKingdomWarTask::resetPersonTaskRPAndUpdate()
	{
		int tmp = _pt_rp;
		resetPersonTaskRP();
		if (tmp != _pt_rp)
			Own().KingDomWar().updateRedPoint();
	}

	int playerKingdomWarTask::nationTaskRP()
	{
		if (_nt_rp == -1)
			resetNationTaskRP();
		return _nt_rp;
	}

	void playerKingdomWarTask::resetNationTaskRP()
	{
		if (_nation_task_state == 0
			&& KingdomWar::NationTaskMgr::shared().getState(Own().Info().Nation()) == KingdomWar::Task::Finished)
			_nt_rp = 1;
		else
			_nt_rp = 0;
	}

	void playerKingdomWarTask::resetNationTaskRPAndUpdate()
	{
		int tmp = _nt_rp;
		resetNationTaskRP();
		if (tmp != _nt_rp)
			Own().KingDomWar().updateRedPoint();
	}
}

#include "fund_system.h"
#include "commom.h"
//#include "dbDriver.h"


namespace gg
{
	fund_system* const fund_system::_Instance = new fund_system();

	fund_system::fund_system()
	{
	}

	void fund_system::initData()
	{
		cout << "load ./fund/fund.json..." << endl;
		Json::Value value = Common::loadJsonFile(std::string("./instance/fund/fund.json"));
		_vip_lv = value["vip_lv"].asInt();
		_gold = value["gold"].asInt();
		Json::Value items = value["items"];
		for (int i = 0; i < items.size(); ++i)
		{
			FundReward reward;
			reward.id = items[i]["reward_id"].asInt();
			reward.r_lv = items[i]["r_lv"].asInt();
			//��json����Ϊ����ACTION::BoxList
			reward.box_list = actionFormatBox(items[i]["box"]);
			//���ڻ�������ݣ���log�ȣ�
			Json::Value box = items[i]["box"];
			std::string boxStr("[");
			for (int j = 0; j < box.size(); ++j)
			{
				boxStr += std::string("[");
				boxStr += boost::lexical_cast<std::string>(box[j]["aID"].asInt());
				boxStr += std::string(",");
				boxStr += boost::lexical_cast<std::string>(box[j]["v"].asInt());
				boxStr += std::string("]");
				if (j != box.size() - 1)
				{
					boxStr += std::string(",");
				}
			}
			boxStr += std::string("]");

			_idBoxDesc[reward.id] = boxStr;
			_idBoxJson[reward.id] = items[i]["box"];
			_reward_list[reward.id] = reward;
		}
	}

	bool fund_system::isValidFundId(const int& id) const
	{
		return _reward_list.find(id) != _reward_list.end();
	}

	void fund_system::reqFundInfo(net::Msg& m, Json::Value& r)
	{
		playerDataPtr player = player_mgr.getPlayer(m.playerID);
		if (!player) Return(r, err_illedge);
		player->Fund()._auto_update();
	}

	void fund_system::reqFundBuy(net::Msg& m, Json::Value& r)
	{
		//1.parse the data.
		//2.business logic
		playerDataPtr player = player_mgr.getPlayer(m.playerID);
		if (!player)Return(r, err_illedge);//�Ƿ�����

		if (player->Info().VipLv() < VipLimit())//vip�ȼ�
		{
			Return(r, err_fund_vip_lv_not_enough);
		}
		if (player->Res().getCash() < GoldCost())//���
		{
			Return(r, err_fund_gold_not_enough);
		}

		//����
		int res = player->Fund().buyFund();
		Return(r, res);
	}

	void fund_system::reqFundGetReward(net::Msg& m, Json::Value& r)
	{
		//1.parse the data.
		//2.business logic
		playerDataPtr player = player_mgr.getPlayer(m.playerID);
		if (!player)Return(r, err_illedge);//�Ƿ�����

		ReadJsonArray;

		const int reward_id = js_msg[0u]["reward_id"].asInt();
		if (!player->Fund().hasBoughtFund())
		{//δ�������
			Return(r, err_fund_do_not_buy);
		}
		if (!isValidFundId(reward_id))
		{//��Чid
			Return(r, err_fund_invalid_id);
		}
		if (_reward_list[reward_id].r_lv > player->Info().LV())
		{//�ȼ�����
			Return(r, err_fund_lv_not_enough);
		}

		//��ý���
		const int res = player->Fund().getReward(reward_id, r);
		Return(r, res);

	}


	fund_system::~fund_system()
	{
	}
}

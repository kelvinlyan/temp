#include "player_shops.h"
#include "shop_mgr.h"
#include "res_code.h"
#include "playerManager.h"

namespace gg
{
	namespace PLAYERSHOP
	{
		Data::Data(playerData* const own, const int type)
			: _auto_player(own), ShopType(type)
		{
			_flush_times = 0;
			_records.clear();
		}

		void Data::classLoad()
		{
			mongo::BSONObj key = BSON(strPlayerID << Own().ID() << "type" << ShopType);
			mongo::BSONObj obj = db_mgr.FindOne(DBN::dbPlayerShops, key);
			if (obj.isEmpty())return;
			_flush_times = obj["ft"].Int();
			std::vector<mongo::BSONElement> ele = obj["d"].Array();
			for (unsigned i = 0; i < ele.size(); ++i)
				_records.push_back(PLAYERSHOP::Record(ele[i]["id"].Int(), ele[i]["bt"].Int()));
		}

		void Data::_auto_update()
		{
			update();
		}

		bool Data::_auto_save()
		{
			mongo::BSONObj key = BSON(strPlayerID << Own().ID() << "type" << ShopType);
			mongo::BSONArrayBuilder b;
			ForEachC(ListReord, it, _records)
				b.append(BSON("id" << it->_id << "bt" << it->_buy_times));
			mongo::BSONObj obj = BSON(strPlayerID << Own().ID() << "type" << ShopType << "ft" << _flush_times << "d" << b.arr());
			return db_mgr.SaveMongo(DBN::dbPlayerShops, key, obj);
		}

		void Data::update()
		{
			check();
			Json::Value res;
			res[strMsg][0u] = res_sucess;
			Json::Value& shop = res[strMsg][1u]["sl"];
			shop = Json::arrayValue;
			ForEachC(ListReord, it, _records)
			{
				Json::Value tmp;
				tmp.append(it->_id);
				tmp.append(it->_buy_times);
				shop.append(tmp);
			}
			res[strMsg][1u]["ft"] = _flush_times;
			res[strMsg][1u]["tp"] = ShopType;
			Own().sendToClient(gate_client::player_mine_shop_info_resp, res);
		}

		int Data::buy(const int pos, const int id, Json::Value& r)
		{
			if (pos <= 0 || pos > _records.size())
				return err_illedge;

			Record& rcd = _records[pos - 1];
			if (rcd._id != id)
				return err_illedge;

			SHOP::ptrData ptr = shops_mgr.getShopData(ShopType, id);
			if (!ptr)
				return err_illedge;

			if (rcd._buy_times >= ptr->_buy_num)
				return err_goods_sale_out;

			const int res_result = shops_mgr.checkRes(ptr->_type_price, ptr->_price_num, Own().getOwnDataPtr());
			if (res_result != res_sucess)
				return res_result;

			int res = actionDoBox(Own().getOwnDataPtr(), ptr->_box, false);
			if (res == res_sucess)
			{
				++rcd._buy_times;
				shops_mgr.cutRes(ptr->_type_price, ptr->_price_num, Own().getOwnDataPtr());
				update();
				_sign_save();
				r = actionRes();
				Log(DBLOG::strLogPlayerOwnShop, Own().getOwnDataPtr(), 0, ShopType, ptr->_type_price, ptr->_price_num, id,
					"", "", "", r.toIndentString());
			}
			else
			{
				r = actionError();
			}

			return res;
		}

		void Data::reset()
		{
			_flush_times = 0;
			_records.clear();
			check();
		}

		int Data::flush()
		{
			if (shops_mgr.flushLimit(ShopType, _flush_times))return err_flush_shop_limit_daily;
			int cost = shops_mgr.getFlushCost(ShopType, _flush_times);
			if (Own().Res().getCash() < cost)
				return err_gold_not_enough;
			Own().Res().alterCash(0 - cost);
			++_flush_times;
			_records.clear();
			check();
			update();
			Log(DBLOG::strLogPlayerOwnShop, Own().getOwnDataPtr(), 1, ShopType, cost, _flush_times);
			return res_sucess;
		}

		void Data::check()
		{
			if (_records.empty())
			{
				vector<SHOP::ptrData> vec = shops_mgr.getShopList(ShopType, Own().getOwnDataPtr());
				for (unsigned i = 0; i < vec.size(); ++i)
					_records.push_back(Record(vec[i]->_id, 0));
				_sign_save();
			}
		}
	}

	//gg
	playerShops::playerShops(playerData* const own)
		: _auto_player(own)
	{
		_shops.resize(PLAYERSHOP::shop_num);
		for (unsigned i = 0; i < _shops.size(); ++i)
		{
			_shops[i] = Creator<PLAYERSHOP::Data>::Create(own, i);
		}
	}

	void playerShops::classLoad()
	{
		for (unsigned i = 0; i < _shops.size(); ++i)
		{
			_shops[i]->classLoad();
		}
	}

	void playerShops::dailyReset()
	{
		for (unsigned i = 0; i < _shops.size(); ++i)
		{
			_shops[i]->reset();
		}
	}

	void playerShops::update(const int type)
	{
		if (type < 0 || type >= PLAYERSHOP::shop_num)return;
		_shops[type]->update();
	}
	
	int playerShops::buy(const int type, const int pos, const int id, Json::Value& r)
	{
		if (type < 0 || type >= PLAYERSHOP::shop_num)return err_illedge;
		return _shops[type]->buy(pos, id, r);
	}

	int playerShops::flush(const int type)
	{
		if (type < 0 || type >= PLAYERSHOP::shop_num)return err_illedge;
		return _shops[type]->flush();
	}

}
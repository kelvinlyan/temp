#include "patrol_event.h"

namespace gg{

	std::string parseJsonBox(Json::Value json_box)
	{
		std::string str("[");
		for (int i = 0; i < json_box.size(); ++i)
		{
			str.append("[");
			int aid = json_box[i]["aID"].asInt();
			str.append(boost::lexical_cast<std::string>(aid));//1.==>aID
			str.append(",");
			int v = json_box[i]["v"].asInt();//2.==>v
			str.append(boost::lexical_cast<std::string>(v));
			//����ǵ��ߺ���Ů  �ͻ���id������ID��12����ŮID��14 
			if (aid == ACTION::item
				|| aid == ACTION::kingdom_skill_exp
				|| aid == ACTION::lady)
			{
				int id = json_box[i]["id"].asInt();//3.==>id
				str.append(",");
				str.append(boost::lexical_cast<std::string>(id));
			}
			str.append("]");
			if (i != json_box.size() - 1)
			{
				str.append(",");
			}
		}
		str.append("]");
		return str;
	}

	Json::Value parseJson(Json::Value json_box)
	{
		Json::Value box = Json::arrayValue;
		for (unsigned i = 0; i < json_box.size(); ++i)
		{
			Json::Value ele;
			int aid = json_box[i]["aID"].asInt();
			ele[0u] = aid;
			if (aid == ACTION::item
				|| aid == ACTION::kingdom_skill_exp
				|| aid == ACTION::lady)
			{
				ele[1u] = json_box[i]["id"].asInt();
				ele[2u] = json_box[i]["v"].asInt();
			}
			else
			{
				ele[1u] = json_box[i]["v"].asInt();
			}
			box[i] = ele;
		}
		return box;
	}

	void combineJsonBox(const Json::Value& from, Json::Value& to)
	{
		Json::Value boxes = Json::arrayValue;
		//��ͬ�ĺϲ���ʣ�µĶ��ǻ�����ͬ�ġ�
		std::vector<int> first_done_list;
		std::vector<int> sec_done_list;
		int c = 0;
		for (int i = 0; i < from.size(); ++i)
		{
			int first_aid = from[i]["aID"].asInt();
			for (int j = 0; j < to.size(); ++j)
			{
				if (std::find(sec_done_list.begin(), sec_done_list.end(), j) != sec_done_list.end())
				{
					continue;
				}
				int sec_aid = to[j]["aID"].asInt();
				if (first_aid == sec_aid)
				{
					if ((first_aid == ACTION::item
						|| first_aid == ACTION::kingdom_skill_exp
						|| first_aid == ACTION::lady)
						&& from[i]["id"].asInt() == to[j]["id"].asInt())
					{
						boxes[c]["aID"] = first_aid;
						boxes[c]["id"] = from[i]["id"].asInt();
						boxes[c]["v"] = from[i]["v"].asInt() + to[j]["v"].asInt();
						first_done_list.push_back(i);
						sec_done_list.push_back(j);
						++c;
						break;
					}
					else if ((first_aid == ACTION::item
						|| first_aid == ACTION::kingdom_skill_exp
						|| first_aid == ACTION::lady)
						&& from[i]["id"].asInt() != to[j]["id"].asInt())
					{
						continue;
					}
					else
					{
						boxes[c]["aID"] = first_aid;
						boxes[c]["v"] = from[i]["v"].asInt() + to[j]["v"].asInt();
						first_done_list.push_back(i);
						sec_done_list.push_back(j);
						++c;
						break;
					}
				}

			}
		
		}
		//������ͬ��
		for (int i = 0; i < from.size(); ++i)
		{
			if (std::find(first_done_list.begin(), first_done_list.end(), i) != first_done_list.end())
			{
				continue;
			}
			else
			{
				boxes[c] = from[i];
				++c;
			}
		}

		for (int j = 0; j < to.size(); ++j)
		{
			if (std::find(sec_done_list.begin(), sec_done_list.end(), j) != sec_done_list.end())
			{
				continue;
			}
			else
			{
				boxes[c] = to[j];
				++c;
			}
		}
		to = boxes;
	}

	namespace patrol {
	
		size_t getProbIndex(const std::vector<int>& odds, int sum)
		{
			int target = Common::randomBetween(0, sum - 1);
			for (int i = 0; i < odds.size() - 1; ++i)
			{
				if (target >= odds[i] && target < odds[i + 1])
				{
					return i;
				}
			}
			return 0;
		}
	}

	patrol_event::patrol_event(patrol::EventType type)
		:_type(type)
	{
	}

	patrol::EventType patrol_event::Type()
	{
		return _type;
	}


	patrol_event::~patrol_event()
	{
	}

	/////////////////////////////////////////////////////

	patrol_fish_event::patrol_fish_event(FishConfigPtr config, patrol::EventType type)
		:patrol_event(type),
		_config(config)
	{
		//odds=>[0,2500,5000,10000]
		//��ʼ��������������
		int typeIdx = patrol::getProbIndex(_config->odds);
		if (typeIdx == 0)
		{
			_sub_type = patrol::GoodLuck;
		}
		else if (typeIdx == 1)
		{
			_sub_type = patrol::BeautyBesides;
		}
		else
		{
			_sub_type = patrol::BeautyGitf;
		}
		//����_sub_type��������
		if (_sub_type == patrol::GoodLuck)
		{
			_idx = patrol::getProbIndex(_config->oddsLuck);
		}
		else if (_sub_type == patrol::BeautyGitf)
		{
			_idx = patrol::getProbIndex(_config->oddsGift);
		}

	}

	patrol_fish_event::patrol_fish_event(FishConfigPtr config, int subType, int idx, patrol::EventType type)
		:patrol_event(type),
		_config(config),
		_idx(idx),
		_sub_type((patrol::FishResultType)subType)
	{
		//Ϊ��ֹ�����ļ����Ķ����±���
		if (_sub_type == patrol::GoodLuck && _idx >= _config->luck.size())
		{
			_idx = patrol::getProbIndex(_config->oddsLuck);
		}
		else if (_sub_type == patrol::BeautyGitf && _idx >= _config->gift.size())
		{
			_idx = patrol::getProbIndex(_config->oddsGift);
		}
	}

	void patrol_fish_event::getDetail(Json::Value& r)
	{
		r["sec"] = (int)_sub_type;
		if (_sub_type == patrol::GoodLuck)
		{
			r["box"] = _config->luck[_idx].jsonBox;
		}
		else if (_sub_type == patrol::BeautyGitf)
		{
			r["box"] = _config->gift[_idx].jsonBox;
		}
		else
		{
			r["box"] = _config->jsonEmptyBox;
		}
	}

	std::string patrol_fish_event::getStr(int flag)
	{
		if (_sub_type == patrol::GoodLuck)
		{
			return _config->luck[_idx].strBox;
		}
		else if (_sub_type == patrol::BeautyGitf)
		{
			return _config->gift[_idx].strBox;
		}
		else
		{
			return _config->strEmptyBox;
		}
	}

	ACTION::BoxList patrol_fish_event::getBox(int flag)
	{
		if (_sub_type == patrol::GoodLuck)
		{
			return _config->luck[_idx].box;
		}
		else if (_sub_type == patrol::BeautyGitf)
		{
			return _config->gift[_idx].box;
		}
		else
		{
			return _config->emptyBox;
		}
	}

	//////////////////////////////////////////////////////
	patrol_flower_event::patrol_flower_event(EnjoyFlowerConfigPtr config, patrol::EventType type)
		:patrol_event(type),
		_config(config)
	{
		int typeIdx = patrol::getProbIndex(_config->odds);
		if (typeIdx == 0)
		{
			_sub_type = patrol::MeetScholar;
			_idx = patrol::getProbIndex(_config->meetOdds);
		}
		else if (typeIdx == 1)
		{
			_sub_type = patrol::HoneyTalk;
			_idx = patrol::getProbIndex(_config->talkOdds);
		}
		else if (typeIdx == 2)
		{
			_sub_type = patrol::BeautyAgain;
			_idx = patrol::getProbIndex(_config->againOdds);
		}
		else
		{
			_sub_type = patrol::PlayOnly;
		}
	}

	patrol_flower_event::patrol_flower_event(EnjoyFlowerConfigPtr config, int subType, int idx, patrol::EventType type)
		:patrol_event(type),
		_config(config),
		_sub_type((patrol::EnjoyFlowerProcess)subType),
		_idx(idx)
	{
		//Ϊ��ֹ�����ļ����Ķ����±���
		if (_sub_type == patrol::MeetScholar && _idx >= _config->meetBoxes.size())
		{
			_idx = patrol::getProbIndex(_config->meetOdds);
		}
		else if (_sub_type == patrol::HoneyTalk && _idx >= _config->talkBoxes.size())
		{
			_idx = patrol::getProbIndex(_config->talkOdds);
		}
		else if (_sub_type == patrol::BeautyAgain && _idx >= _config->againBoxes.size())
		{
			_idx = patrol::getProbIndex(_config->againOdds);
		}
	}

	void patrol_flower_event::getDetail(Json::Value& r)
	{
		r["sec"] = (int)_sub_type;
		if (_sub_type == patrol::MeetScholar)
		{
			r["box"] = _config->meetBoxes[_idx].jsonBox;
		}
		else if (_sub_type == patrol::HoneyTalk)
		{
			r["box"] = _config->talkBoxes[_idx].jsonBox;
		}
		else if (_sub_type == patrol::BeautyAgain)
		{
			r["box"] = _config->againBoxes[_idx].jsonBox;
		}
		else
		{
			r["box"] = _config->jsonPlay;
		}
	}

	std::string patrol_flower_event::getStr(int flag)
	{
		if (_sub_type == patrol::MeetScholar)
		{
			return _config->meetBoxes[_idx].strBox;
		}
		else if (_sub_type == patrol::HoneyTalk)
		{
			return _config->talkBoxes[_idx].strBox;
		}
		else if (_sub_type == patrol::BeautyAgain)
		{
			return _config->againBoxes[_idx].strBox;
		}
		else
		{
			return _config->strPlay;
		}
	}

	ACTION::BoxList patrol_flower_event::getBox(int flag)
	{
		if (_sub_type == patrol::MeetScholar)
		{
			return _config->meetBoxes[_idx].box;
		}
		else if (_sub_type == patrol::HoneyTalk)
		{
			return _config->talkBoxes[_idx].box;
		}
		else if (_sub_type == patrol::BeautyAgain)
		{
			return _config->againBoxes[_idx].box;
		}
		else
		{
			return _config->boxPlay;
		}
	}

	//////////////////////////////////////////////////////

	patrol_aq_event::patrol_aq_event(AQConfigPtr config, patrol::EventType type)
		:patrol_event(type),
		_config(config)
	{
		_idx = Common::randomBetween(0, _config->questions.size() - 1);
	}

	patrol_aq_event::patrol_aq_event(AQConfigPtr config, int idx, patrol::EventType type)
		:patrol_event(type),
		_config(config),
		_idx(idx)
	{
		//Ϊ��ֹ�����ļ����Ķ����±���
		if (_idx >= _config->questions.size())
		{
			_idx = Common::randomBetween(0, _config->questions.size() - 1);
		}
	}

	ACTION::BoxList patrol_aq_event::getBox(int flag)
	{
		if (flag == 0)
		{
			return _config->questions[_idx].doubleBox;
		}
		return _config->questions[_idx].box;
	}

	void patrol_aq_event::getDetail(Json::Value& r)
	{
		r["topic"] = _config->questions[_idx].subject.topic;
		for (int i = 0; i < _config->questions[_idx].subject.options.size(); ++i)
		{
			r["opt"][i] = _config->questions[_idx].subject.options[i];
		}
		r["ans"] = _config->questions[_idx].subject.ans;
		r["box"] = _config->questions[_idx].jsonBox;
		r["ts"] = 2;
	}

	std::string patrol_aq_event::getStr(int flag)
	{
		return  _config->questions[_idx].strBox;
	}

	//////////////////////////////////////////////////////

	patrol_finger_event::patrol_finger_event(FingerGuessConfigPtr config, patrol::EventType type)
		:patrol_event(type),
		_config(config)
	{
		_idxSucc = patrol::getProbIndex(_config->succOdds);
		_idxFail = patrol::getProbIndex(_config->failOdds);
	}

	patrol_finger_event::patrol_finger_event(FingerGuessConfigPtr config, int idxSucc, int idxFail, patrol::EventType type)
		:patrol_event(type),
		_config(config),
		_idxSucc(idxSucc),
		_idxFail(idxFail)
	{
		//Ϊ��ֹ�����ļ����Ķ����±���
		if (_idxSucc >= _config->succ.size())
		{
			_idxSucc = patrol::getProbIndex(_config->succOdds);
		}
		if (_idxFail >= _config->fail.size())
		{
			_idxFail = patrol::getProbIndex(_config->failOdds);
		}
	}

	ACTION::BoxList patrol_finger_event::getBox(int flag)
	{
		if (flag == 0)
		{
			return _config->succ[_idxSucc].box;
		}
		return _config->fail[_idxFail].box;
	}

	void patrol_finger_event::getDetail(Json::Value& r)
	{
		r["succ"] = _config->succ[_idxSucc].jsonBox;
		r["fail"] = _config->succ[_idxFail].jsonBox;
	}

	std::string patrol_finger_event::getStr(int flag)
	{
		if (flag == 0)
		{
			return _config->succ[_idxSucc].strBox;
		}
		return _config->fail[_idxFail].strBox;
	}

	//////////////////////////////////////////////////////

	patrol_anecdote_event::patrol_anecdote_event(AnecdoteConfigPtr config, patrol::EventType type)
		:patrol_event(type),
		_config(config)
	{
		_idx = patrol::getProbIndex(_config->odds);
	}

	patrol_anecdote_event::patrol_anecdote_event(AnecdoteConfigPtr config, int idx, patrol::EventType type)
		:patrol_event(type),
		_config(config),
		_idx(idx)
	{
		//Ϊ��ֹ�����ļ����Ķ����±���
		if (_idx >= _config->anecdotes.size())
		{
			_idx = patrol::getProbIndex(_config->odds);
		}
	}

	ACTION::BoxList patrol_anecdote_event::getBox(int flag)
	{
		if (flag == 1)//ѡ���һ��ѡ��
		{
			return _config->anecdotes[_idx].boxes[0];
		}
		return _config->anecdotes[_idx].boxes[1];
	}

	void patrol_anecdote_event::getDetail(Json::Value& r)
	{
		r["topic"] = _config->anecdotes[_idx].subject.topic;
		for (int i = 0; i < _config->anecdotes[_idx].subject.options.size(); ++i)
		{
			r["opt"][i] = _config->anecdotes[_idx].subject.options[i];
			r["boxes"][i] = _config->anecdotes[_idx].jsonBoxes[i];
		}
	}

	std::string patrol_anecdote_event::getStr(int flag)
	{
		if (flag == 1)//ѡ���һ��ѡ��
		{
			return _config->anecdotes[_idx].strBoxes[0];
		}
		return _config->anecdotes[_idx].strBoxes[1];
	}

	//////////////////////////////////////////////////////

	void patrol_sleep_event::buildList()
	{
		for (SleepNodeList::iterator it = _list.begin(); it != _list.end(); ++it)
		{
			_list.erase(it);
		}
		SleepNodePtr first_node = Creator<patrol::sleep_node>::Create();
		first_node->idx = 0;
		first_node->weight = 0;
		first_node->sums = 0;
		_list.push_back(first_node);
		for (int i = 0; i < _config->beauty.size(); ++i)
		{
			SleepNodePtr node = Creator<patrol::sleep_node>::Create();
			node->idx = i + 1;
			node->weight = _config->beauty[i].weight;
			node->sums = _config->odds[i + 1];
			_list.push_back(node);
		}
	}

	void patrol_sleep_event::selectListItem()
	{
		int rest = 6;
		_ids.clear();
		while (rest-- && (!_list.empty()))
		{
			//1.ѡ��
			int target = Common::randomBetween(0, _list.back()->sums - 1);
			for (SleepNodeList::iterator it = _list.begin(); it != _list.end(); ++it)
			{
				SleepNodeList::iterator next = it;
				++next;
				if (next == _list.end())
				{
					break;
				}
				if (target >= (*it)->sums && target < (*next)->sums)
				{
					_ids.push_back((*it)->idx);
					_list.erase(it);
					break;
				}
			}
			//2.resum
			for (SleepNodeList::iterator it = _list.begin(); it != _list.end(); ++it)
			{
				SleepNodeList::iterator next = it;
				++next;
				if (next == _list.end())
				{
					break;
				}
				(*next)->sums = (*next)->weight + (*it)->sums;
			}
		}
	}

	patrol_sleep_event::patrol_sleep_event(SleepConfigPtr config, patrol::EventType type)
		:patrol_event(type),
		_config(config)
	{
		buildList();
		selectListItem();
	}

	patrol_sleep_event::patrol_sleep_event(SleepConfigPtr config, const std::vector<int>& ids, patrol::EventType type)
		:patrol_event(type),
		_config(config),
		_ids(ids)
	{
		//Ϊ��ֹ�����ļ����Ķ����±���
		for (int i = 0; i < _ids.size(); ++i)
		{
			if (_ids[i] >= _config->beauty.size())
			{
				buildList();
				selectListItem();
				break;
			}
		}
	}

	ACTION::BoxList patrol_sleep_event::getBox(int flag)
	{
		//option2
		//�ϲ�����json,
		//��jsonת��Ϊbox
		//��boxת��Ϊstr
		if (flag > 35 || flag < 0)
		{
			throw std::out_of_range("flag error");
		}
		int first_id = flag / 6;
		int sec_id = flag % 6;
		Json::Value box1 = _config->rawBox[_ids[first_id]];
		Json::Value box2 = _config->rawBox[_ids[sec_id]];
		combineJsonBox(box1, box2);
		_box = actionFormatBox(box2);
		_jsonBox = parseJson(box2);
		_strBox = parseJsonBox(box2);

		return _box;
	}

	void patrol_sleep_event::getDetail(Json::Value& r)
	{
		for (int i = 0; i < _ids.size(); ++i)
		{
			r["boxes"][i]["id"] = i;
			r["boxes"][i]["box"] = _config->beauty[_ids[i]].jsonBox;
		}
	}

	std::string patrol_sleep_event::getStr(int flag)
	{
		return _strBox;
	}

	//////////////////////////////////////////////////////

	patrol_end_event::patrol_end_event(EndBoxConfigPtr config, patrol::EventType type)
		:patrol_event(type),
		_config(config)
	{
		_idx = patrol::getProbIndex(_config->odds);
	}

	patrol_end_event::patrol_end_event(EndBoxConfigPtr config, int idx, patrol::EventType type)
		:patrol_event(type),
		_config(config),
		_idx(idx)
	{
		//��ֹ�������ļ�����ҳ���±���
		if (_idx >= _config->boxes.size())
		{
			_idx = patrol::getProbIndex(_config->odds);
		}
	}

	ACTION::BoxList patrol_end_event::getBox(int flag)
	{
		return _config->boxes[_idx].box;
	}

	void patrol_end_event::getDetail(Json::Value& r)
	{
		r["box"] = _config->boxes[_idx].jsonBox;
	}

	Json::Value patrol_end_event::getJson()
	{
		return _config->boxes[_idx].jsonBox;
	}

	std::string patrol_end_event::getStr(int flag)
	{
		return _config->boxes[_idx].strBox;
	}

	//////////////////////////////////////////////////////
	patrol_poker_event::patrol_poker_event(PokerConfigPtr config, patrol::EventType type)
		:patrol_event(type),
		_config(config)
	{
		int typeIdx = patrol::getProbIndex(_config->odds);
		//typeIdx = 2;//just for test.
		if (typeIdx == 0)
		{
			_sub_type = patrol::SameCard;
		}
		else if (typeIdx == 1)
		{
			_sub_type = patrol::AdjacentCard;
		}
		else
		{
			_sub_type = patrol::BiggerCard;
		}
		_idx = patrol::getProbIndex(_config->subOdds);
	}

	patrol_poker_event::patrol_poker_event(PokerConfigPtr config, int subType, int idx, patrol::EventType type)
		:patrol_event(type),
		_config(config),
		_idx(idx),
		_sub_type((patrol::PokerCalc)subType)
	{
		//Ϊ��ֹ�����ļ����Ķ����±���
		if (_idx >= _config->boxes.size())
		{
			_idx = patrol::getProbIndex(_config->subOdds);
		}
	}

	ACTION::BoxList patrol_poker_event::getBox(int flag)
	{
		if (flag == 0)
		{
			return _config->boxes[_idx].doubleBox;
		}
		return _config->boxes[_idx].box;
	}

	void patrol_poker_event::getDetail(Json::Value& r)
	{
		r["sec"] = (int)_sub_type;
		r["box"] = _config->boxes[_idx].jsonBox;
		r["ts"] = 2;
	}

	std::string patrol_poker_event::getStr(int flag)
	{
		if (flag == 0)
		{
			return _config->boxes[_idx].strDoubleBox;
		}
		return _config->boxes[_idx].strBox;
	}


	//////////////////////////////////////////////////////
	patrol_eye_event::patrol_eye_event(EyeConfigPtr config, patrol::EventType type)
		:patrol_event(type),
		_config(config)
	{
		_idx = patrol::getProbIndex(_config->odds);
	}

	patrol_eye_event::patrol_eye_event(EyeConfigPtr config, int idx, patrol::EventType type)
		:patrol_event(type),
		_config(config),
		_idx(idx)
	{
		//Ϊ��ֹ�����ļ����Ķ����±���
		if (_idx >= _config->fires.size())
		{
			_idx = patrol::getProbIndex(_config->odds);
		}
	}

	ACTION::BoxList patrol_eye_event::getBox(int flag)
	{
		if (flag == 0)
		{
			return _config->fires[_idx].doubleBox;
		}
		return _config->fires[_idx].box;
	}

	void patrol_eye_event::getDetail(Json::Value& r)
	{
		r["box"] = _config->fires[_idx].jsonBox;
		r["ts"] = 2;
	}

	std::string patrol_eye_event::getStr(int flag)
	{
		return _config->fires[_idx].strBox;
	}
}

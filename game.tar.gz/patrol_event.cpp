#include "patrol_event.h"

namespace gg{

	namespace patrol {
	
		size_t getProbIndex(const std::vector<int>& odds)
		{
			int target = Common::randomBetween(0, ODDS_SUM - 1);
			for (int i = 0; i < odds.size() - 1; ++i)
			{
				if (target >= odds[i] && target < odds[i + 1])
				{
					return i;
				}
			}
			return 0;
		}
	}

	patrol_event::patrol_event(patrol::EventType type)
		:_type(type)
	{
	}

	patrol::EventType patrol_event::Type()
	{
		return _type;
	}


	patrol_event::~patrol_event()
	{
	}

	/////////////////////////////////////////////////////

	patrol_fish_event::patrol_fish_event(FishConfigPtr config, patrol::EventType type)
		:patrol_event(type),
		_config(config)
	{
		//odds=>[0,2500,5000,10000]
		//��ʼ��������������
		int typeIdx = patrol::getProbIndex(_config->odds);
		if (typeIdx == 0)
		{
			_sub_type = patrol::GoodLuck;
		}
		else if (typeIdx == 1)
		{
			_sub_type = patrol::BeautyBesides;
		}
		else
		{
			_sub_type = patrol::BeautyGitf;
		}
		//����_sub_type��������
		if (_sub_type == patrol::GoodLuck)
		{
			_idx = patrol::getProbIndex(_config->oddsLuck);
		}
		else if (_sub_type == patrol::BeautyGitf)
		{
			_idx = patrol::getProbIndex(_config->oddsGift);
		}

	}

	patrol_fish_event::patrol_fish_event(FishConfigPtr config, int subType, int idx, patrol::EventType type)
		:patrol_event(type),
		_config(config),
		_idx(idx),
		_sub_type((patrol::FishResultType)subType)
	{
	}

	void patrol_fish_event::getDetail(Json::Value& r)
	{
		r["sec"] = (int)_sub_type;
		if (_sub_type == patrol::GoodLuck)
		{
			r["box"] = _config->luck[_idx].jsonBox;
		}
		else if (_sub_type == patrol::BeautyGitf)
		{
			r["box"] = _config->gift[_idx].jsonBox;
		}
		else
		{
			r["box"] = _config->jsonEmptyBox;
		}
	}

	std::string patrol_fish_event::getStr(int flag)
	{
		if (_sub_type == patrol::GoodLuck)
		{
			return _config->luck[_idx].strBox;
		}
		else if (_sub_type == patrol::BeautyGitf)
		{
			return _config->gift[_idx].strBox;
		}
		else
		{
			return _config->strEmptyBox;
		}
	}

	ACTION::BoxList patrol_fish_event::getBox(int flag)
	{
		if (_sub_type == patrol::GoodLuck)
		{
			return _config->luck[_idx].box;
		}
		else if (_sub_type == patrol::BeautyGitf)
		{
			return _config->gift[_idx].box;
		}
		else
		{
			return _config->emptyBox;
		}
	}

	//////////////////////////////////////////////////////
	patrol_flower_event::patrol_flower_event(EnjoyFlowerConfigPtr config, patrol::EventType type)
		:patrol_event(type),
		_config(config)
	{
		int typeIdx = patrol::getProbIndex(_config->odds);
		if (typeIdx == 0)
		{
			_sub_type = patrol::MeetScholar;
		}
		else if (typeIdx == 1)
		{
			_sub_type = patrol::HoneyTalk;
		}
		else if (typeIdx == 2)
		{
			_sub_type = patrol::BeautyAgain;
		}
		else
		{
			_sub_type = patrol::PlayOnly;
		}
	}

	patrol_flower_event::patrol_flower_event(EnjoyFlowerConfigPtr config, int subType, patrol::EventType type)
		:patrol_event(type),
		_config(config),
		_sub_type((patrol::EnjoyFlowerProcess)subType)
	{
	}

	void patrol_flower_event::getDetail(Json::Value& r)
	{
		r["sec"] = (int)_sub_type;
		if (_sub_type == patrol::MeetScholar)
		{
			r["box"] = _config->jsonMeet;
		}
		else if (_sub_type == patrol::HoneyTalk)
		{
			r["box"] = _config->jsonTalk;
		}
		else if (_sub_type == patrol::BeautyAgain)
		{
			r["box"] = _config->jsonAgain;
		}
		else
		{
			r["box"] = _config->jsonPlay;
		}
	}

	std::string patrol_flower_event::getStr(int flag)
	{
		if (_sub_type == patrol::MeetScholar)
		{
			return _config->strMeet;
		}
		else if (_sub_type == patrol::HoneyTalk)
		{
			return _config->strTalk;
		}
		else if (_sub_type == patrol::BeautyAgain)
		{
			return _config->strAgain;
		}
		else
		{
			return _config->strPlay;
		}
	}

	ACTION::BoxList patrol_flower_event::getBox(int flag)
	{
		if (_sub_type == patrol::MeetScholar)
		{
			return _config->boxMeet;
		}
		else if (_sub_type == patrol::HoneyTalk)
		{
			return _config->boxTalk;
		}
		else if (_sub_type == patrol::BeautyAgain)
		{
			return _config->boxAgain;
		}
		else
		{
			return _config->boxPlay;
		}
	}

	//////////////////////////////////////////////////////

	patrol_aq_event::patrol_aq_event(AQConfigPtr config, patrol::EventType type)
		:patrol_event(type),
		_config(config)
	{
		_idx = Common::randomBetween(0, _config->questions.size() - 1);
	}

	patrol_aq_event::patrol_aq_event(AQConfigPtr config, int idx, patrol::EventType type)
		:patrol_event(type),
		_config(config),
		_idx(idx)
	{

	}

	ACTION::BoxList patrol_aq_event::getBox(int flag)
	{
		if (flag == 0)
		{
			return _config->questions[_idx].doubleBox;
		}
		return _config->questions[_idx].box;
	}

	void patrol_aq_event::getDetail(Json::Value& r)
	{
		r["topic"] = _config->questions[_idx].subject.topic;
		for (int i = 0; i < _config->questions[_idx].subject.options.size(); ++i)
		{
			r["opt"][i] = _config->questions[_idx].subject.options[i];
		}
		r["ans"] = _config->questions[_idx].subject.ans;
		r["box"] = _config->questions[_idx].jsonBox;
		r["ts"] = 2;
	}

	std::string patrol_aq_event::getStr(int flag)
	{
		return  _config->questions[_idx].strBox;
	}

	//////////////////////////////////////////////////////

	patrol_finger_event::patrol_finger_event(FingerGuessConfigPtr config, patrol::EventType type)
		:patrol_event(type),
		_config(config)
	{
		_idxSucc = patrol::getProbIndex(_config->succOdds);
		_idxFail = patrol::getProbIndex(_config->failOdds);
	}

	patrol_finger_event::patrol_finger_event(FingerGuessConfigPtr config, int idxSucc, int idxFail, patrol::EventType type)
		:patrol_event(type),
		_config(config),
		_idxSucc(idxSucc),
		_idxFail(idxFail)
	{

	}

	ACTION::BoxList patrol_finger_event::getBox(int flag)
	{
		if (flag == 0)
		{
			return _config->succ[_idxSucc].box;
		}
		return _config->fail[_idxFail].box;
	}

	void patrol_finger_event::getDetail(Json::Value& r)
	{
		r["succ"] = _config->succ[_idxSucc].jsonBox;
		r["fail"] = _config->succ[_idxFail].jsonBox;
	}

	std::string patrol_finger_event::getStr(int flag)
	{
		if (flag == 0)
		{
			return _config->succ[_idxSucc].strBox;
		}
		return _config->fail[_idxFail].strBox;
	}

	//////////////////////////////////////////////////////

	patrol_anecdote_event::patrol_anecdote_event(AnecdoteConfigPtr config, patrol::EventType type)
		:patrol_event(type),
		_config(config)
	{
		_idx = patrol::getProbIndex(_config->odds);
	}

	patrol_anecdote_event::patrol_anecdote_event(AnecdoteConfigPtr config, int idx, patrol::EventType type)
		:patrol_event(type),
		_config(config),
		_idx(idx)
	{
	}

	ACTION::BoxList patrol_anecdote_event::getBox(int flag)
	{
		if (flag == 1)//ѡ���һ��ѡ��
		{
			return _config->anecdotes[_idx].boxes[0];
		}
		return _config->anecdotes[_idx].boxes[1];
	}

	void patrol_anecdote_event::getDetail(Json::Value& r)
	{
		r["topic"] = _config->anecdotes[_idx].subject.topic;
		for (int i = 0; i < _config->anecdotes[_idx].subject.options.size(); ++i)
		{
			r["opt"][i] = _config->anecdotes[_idx].subject.options[i];
			r["boxes"][i] = _config->anecdotes[_idx].jsonBoxes[i];
		}
	}

	std::string patrol_anecdote_event::getStr(int flag)
	{
		if (flag == 1)//ѡ���һ��ѡ��
		{
			return _config->anecdotes[_idx].strBoxes[0];
		}
		return _config->anecdotes[_idx].strBoxes[1];
	}

	//////////////////////////////////////////////////////

	patrol_sleep_event::patrol_sleep_event(SleepConfigPtr config, patrol::EventType type)
		:patrol_event(type),
		_config(config)
	{
		//��������ѡ��ص��㷨
		//д���뷵�ص�ʵ�����±꣬����������Ǳ������ñ��е�ID��
		//==>����ʵ��ȱ���е��
		_idx = patrol::getProbIndex(_config->odds);
		distIdx();
	}

	patrol_sleep_event::patrol_sleep_event(SleepConfigPtr config, int idx, patrol::EventType type)
		:patrol_event(type),
		_config(config),
		_idx(idx)
	{
		distIdx();
	}

	ACTION::BoxList patrol_sleep_event::getBox(int flag)
	{
		return _config->beauty[_ids[flag]].box;
	}

	void patrol_sleep_event::distIdx()
	{
		_ids.push_back(_idx);
		int i = _idx + 1;
		int c = 1;
		while (c < 6)
		{
			if (i < _config->beauty.size())
			{
				_ids.push_back(i);
			}
			else
			{
				i = 0;
				_ids.push_back(i);
			}
			++i;
			++c;
		}
	}

	void patrol_sleep_event::getDetail(Json::Value& r)
	{
		for (int i = 0; i < _ids.size(); ++i)
		{
			r["boxes"][i]["id"] = i;
			r["boxes"][i]["box"] = _config->beauty[_ids[i]].jsonBox;
		}
	}

	std::string patrol_sleep_event::getStr(int flag)
	{
		return _config->beauty[_ids[flag]].strBox;
	}

	//////////////////////////////////////////////////////

	patrol_end_event::patrol_end_event(EndBoxConfigPtr config, patrol::EventType type)
		:patrol_event(type),
		_config(config)
	{
		_idx = patrol::getProbIndex(_config->odds);
	}

	patrol_end_event::patrol_end_event(EndBoxConfigPtr config, int idx, patrol::EventType type)
		:patrol_event(type),
		_config(config),
		_idx(idx)
	{

	}

	ACTION::BoxList patrol_end_event::getBox(int flag)
	{
		return _config->boxes[_idx].box;
	}

	void patrol_end_event::getDetail(Json::Value& r)
	{
		r["box"] = _config->boxes[_idx].jsonBox;
	}

	Json::Value patrol_end_event::getJson()
	{
		return _config->boxes[_idx].jsonBox;
	}

	std::string patrol_end_event::getStr(int flag)
	{
		return _config->boxes[_idx].strBox;
	}

	//////////////////////////////////////////////////////
	patrol_poker_event::patrol_poker_event(PokerConfigPtr config, patrol::EventType type)
		:patrol_event(type),
		_config(config)
	{
		int typeIdx = patrol::getProbIndex(_config->odds);
		if (typeIdx == 0)
		{
			_sub_type = patrol::SameCard;
		}
		else if (typeIdx == 1)
		{
			_sub_type = patrol::AdjacentCard;
		}
		else
		{
			_sub_type = patrol::BiggerCard;
		}
		_idx = patrol::getProbIndex(_config->subOdds);
	}

	patrol_poker_event::patrol_poker_event(PokerConfigPtr config, int subType, int idx, patrol::EventType type)
		:patrol_event(type),
		_config(config),
		_idx(idx),
		_sub_type((patrol::PokerCalc)subType)
	{}

	ACTION::BoxList patrol_poker_event::getBox(int flag)
	{
		if (flag == 0)
		{
			return _config->boxes[_idx].doubleBox;
		}
		return _config->boxes[_idx].box;
	}

	void patrol_poker_event::getDetail(Json::Value& r)
	{
		r["sec"] = (int)_sub_type;
		r["box"] = _config->boxes[_idx].jsonBox;
		r["ts"] = 2;
	}

	std::string patrol_poker_event::getStr(int flag)
	{
		if (flag == 0)
		{
			return _config->boxes[_idx].strDoubleBox;
		}
		return _config->boxes[_idx].strBox;
	}


	//////////////////////////////////////////////////////
	patrol_eye_event::patrol_eye_event(EyeConfigPtr config, patrol::EventType type)
		:patrol_event(type),
		_config(config)
	{
		_idx = patrol::getProbIndex(_config->odds);
	}

	patrol_eye_event::patrol_eye_event(EyeConfigPtr config, int idx, patrol::EventType type)
		:patrol_event(type),
		_config(config),
		_idx(idx)
	{
	}

	ACTION::BoxList patrol_eye_event::getBox(int flag)
	{
		if (flag == 0)
		{
			return _config->fires[_idx].doubleBox;
		}
		return _config->fires[_idx].box;
	}

	void patrol_eye_event::getDetail(Json::Value& r)
	{
		r["box"] = _config->fires[_idx].jsonBox;
		r["ts"] = 2;
	}

	std::string patrol_eye_event::getStr(int flag)
	{
		return _config->fires[_idx].strBox;
	}
}

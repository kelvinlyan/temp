//###################################
//create by YeMing
//2015-11-18
//###################################

#pragma once

#include "dbDriver.h"
#include "man_def.h"
#include "skill_def.h"
#include "battle_system.h"

#define map_sys (*gg::map_war::_Instance)

namespace gg  
{	
	struct armyNPC
	{
		armyNPC()
		{
			memset(this, 0x0, sizeof(armyNPC) - sizeof(BattleEquipList));
			equipList.clear();
		}
		int npcID;
		bool holdMorale;
		int initAttri[characterNum];
		//int addAttri[characterNum];
		int armsType;
		double armsModule[armsModulesNum];
		int npcLevel;
		unsigned npcPos;
		int battleValue;
		int skill_1;
		int skill_2;
		BattleEquipList equipList;

		// used in kingdom war
		int maxHp;
	};

	///////////////////////////////////////////////////////////////////////////////////
	struct rewardItemConfig           //��Ʒ��������
	{
		int rewardID;					//����ID
		int starNum;					//����
		ActionBoxList starBox;	    //��Ӧ�Ľ���
	};

	BOOSTSHAREPTR(rewardItemConfig, rewardItemCfgPtr);
	UNORDERMAP(int, rewardItemCfgPtr, rewardItemMap);

	////////////////////////////////////////////////////////////////////////////////
	struct chaperDataConfig				//�½�����
	{
		chaperDataConfig()
		{
			passBox.clear();
		}
		int chaperID;					//�����½�ID
		int preChaperID;				//ǰ���½�ID
		int nextChaperID;				//�����½�ID
		int beginMapID;					//���½ڵĵ�һ����ͼID
		int endMapID;					//ͨ���½ڵĹؿ�
		rewardItemMap passBox;			//��������
	};
	UNORDERMAP(int, chaperDataCfgPtr, chaperDataConfigMap);

	////////////////////////////////////////////////////////////////////////////////
	struct mapDataConfig				//��ͼ����
	{
		mapDataConfig()
		{
			robotIDX = 0xFFFFFFFF;
		}
		chaperDataCfgPtr chaperPtr;
		inline int chaperID() { return chaperPtr->chaperID; }
		inline bool isBeginMap() { return mapID == chaperPtr->beginMapID; }
		inline bool isEndMap() { return mapID == chaperPtr->endMapID; }
		inline bool hasNextChaper() { return chaperPtr->nextChaperID > 0; }
		inline bool hasNextMap() { return (nextID > 0 && (nextID / DivMapChaperRealte == chaperID())); }
		int mapID;					//��ͼID
		int background;				//����ID
		int faceID;					//����ͷ��ID
		bool isBoss;				//�Ƿ��Ǿ�Ӣ����boss
		unsigned eliteBox;			//��Ӣ����
		ActionBoxList	eliteBoxAction[4];		//��Ӣ�����Ӧ����ID
		std::string mapName;			//��ͼ����
		unsigned mapLevel;					//��ͼ�ȼ�
		int battleValue;	////////////ս����
		unsigned robotIDX;//��Ҫ���ӵ������˵�idx
		int nextID;					//���õ�ͼID
		int needFood;					//��Ҫ�ľ���
		int needAction;				//��Ҫ�ľ���
		int chanllengeTimes;			//�õ�ͼ����ս�Ĵ���
		vector<armyNPC> npcList;		//�����б�
		int manExp;					//�佫���Ӿ���
		unsigned levelLimit;		//���ǵȼ����� >=
		ActionRandomList winBox;				//ʤ������
	};

	BOOSTSHAREPTR(mapDataConfig, mapDataCfgPtr);
	UNORDERMAP(int, mapDataCfgPtr, mapDataConfigMap);

	//ս��//////////////////////////////////////////////////////
	struct reportConfig
	{
		reportConfig()
		{
			rTime = 0;
			name = "";
			playerLV = 0;
			playerNation = Kingdom::null;
			roundNum = 0;
			damage = 0;
			playerId = 0;
			sNum = 0;
		}
		unsigned rTime;
		string name;
		Kingdom::NATION playerNation;
		unsigned playerLV;
		unsigned roundNum;
		int damage;
		int playerId;
		int sNum;
	};

	BOOSTSHAREPTR(reportConfig, reportCfgPtr);
	UNORDERMAP(int, reportCfgPtr, reportCfgMap);
	UNORDERMAP(int, vector<reportCfgPtr>, reportCfgMapVector);
	STDMAP(int, int, MapReNumVipMap);

	///////////////////////////////////////////////////////////////////////////
	class map_war
	{
	public:
		static map_war* const _Instance;

		void				initData();
		bool				upateDb(int mapId);
		void				loadDb();
		inline int			getMaxChapterNum()	{ return maxChapterNum; }
		inline int			getMinChapterNum()	{ return minChapterNum; }

		int calCompleteChaperByMapID(const int mapID);
		const chaperDataCfgPtr	getChaperConfig(const int chaperID);
		const mapDataCfgPtr	getMapConfig(const int mapID);
		const ActionBoxList getChapterRewardList(const int chapterId, const int rewardId);
		int					ReNum(int vipLv);
	public:
		DeclareRegFunction(mapDataUpdate);									//��ȡ���½�����
		DeclareRegFunction(challenge);									//��սĳ��ͼ
		DeclareRegFunction(getChapterReward);							//��ȡ�½ڱ��佱��
		DeclareRegFunction(getMapStrategy);								//��ȡ�½ڹ���
		DeclareRegFunction(sweepMap);									//ɨ��ĳ����ͼ
		DeclareRegFunction(reChanllengeAcc);							//������ս����
		DeclareRegFunction(reqFlashSnap);
		DeclareRegFunction(reqEliteBox);								//��Ӣ�ֱ���
		DeclareRegFunction(reqNpcData);								//սǰ����������Ϣ
		sBattlePtr npcSide(mapDataCfgPtr npcPtr);

		mapDataCfgPtr festivalNpc(int bv) const;
	private:
		int						checkCon(mapDataCfgPtr config, int times, playerDataPtr player);
		void					subCon(mapDataCfgPtr config, int times, playerDataPtr player);
		int						checkConSweep(mapDataCfgPtr config, int times, playerDataPtr player);
		void					subConSweep(mapDataCfgPtr config, int times, playerDataPtr player);
		void					challengeMap(mapDataCfgPtr config, playerDataPtr player, Json::Value& r);
		chaperDataConfigMap				chaperConfigData;			//�½�����
		mapDataConfigMap				mapConfigData;				//��ͼ����
		int					maxChapterNum;							//��ǰ����½���
		int					minChapterNum;							//��ǰ��С�½���
		MapReNumVipMap		mapVipReNum;								//VIP���ô���
	public:
		void					changeRep(BattleReport& reportData, mapDataCfgPtr config, playerDataPtr player, int roundNum, int rDamage, int starsNum);
		const reportCfgPtr	getFristReport(const int mapId);
		const reportCfgPtr	getPerReport(const int mapId);
		const vector<reportCfgPtr> getRecentReport(const int mapId);
		Json::Value			formatJson(reportCfgPtr ptr);
	private:
		reportCfgMap			firstReport;								//�״�ͨ��
		reportCfgMap			perReport;								//���ͨ��
		reportCfgMapVector	recentReport;								//���ͨ��
		std::vector<mapDataCfgPtr> mapConfigVec;
	};
} 

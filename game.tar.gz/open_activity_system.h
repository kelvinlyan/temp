#pragma once

#include "task_checker.h"
#include "action_system.h"
#include "auto_base.h"
#include "commom.h"
#include "dbDriver.h"
#include "days_activity_system.h"

#define open_activity_sys (*gg::open_activity_system::_Instance)

namespace gg
{
	class open_activity_system
	{
		public:
			static open_activity_system* const _Instance;

			open_activity_system();

			void initData();

			DeclareRegFunction(activityInfoReq);
			DeclareRegFunction(playerInfoReq);
			DeclareRegFunction(getRewardReq);
			DeclareRegFunction(redPointReq);

			void update(playerDataPtr d, int type, int arg1 = -1, int arg2 = -1);

			DayTaskList getDaysTask(int day) const
			{
				if (day < 1 || day > _task_lists.size())
					return DayTaskList();
				return _task_lists[day - 1];
			}
			DayTaskPtr getTask(int id) const
			{
				DayTaskMap::const_iterator it = _task_map.find(id);
				return it == _task_map.end()? DayTaskPtr() : it->second;
			}
			const std::string& getName() const
			{
				return _name;
			}
			DayTargetPtr getTarget(int id) const
			{
				if (id < 1 || id > _targets.size())
					return DayTargetPtr();
				return _targets[id - 1];
			}
			int getTargetCount() const
			{
				return _targets.size(); 
			}
			int taskDay() const
			{
				return _task_day;
			}
			int rewardDay() const
			{
				return _reward_day;
			}

		private:
			void loadFile();

		private:
			int _task_day;
			int _reward_day;
			std::string _name;
			DayTaskLists _task_lists;
			DayTaskMap _task_map;
			DayTargets _targets;
	};
}

#pragma once

#include "kingdomwar_task.h"

namespace gg
{
	namespace KingdomWar
	{
		namespace Task
		{
			class PersonTaskConfig;
			
			class PRecord
			{
				public:
					PRecord(): _id(-1){}

					void load(const mongo::BSONElement& obj);
					void load(const PersonTaskConfig& config, playerDataPtr d);
					mongo::BSONObj toBSON() const;
					void getInfo(qValue& q) const;
					
					int id() const { return _id; }
					int state() const { return _state; }
					int type()
					{
						if (!_checker && !getChecker())
							return Empty;
						return _checker->type();
					}
					void setState(int s) { _state = s; }
					void clear() { _id = -1; }

					void update(playerDataPtr d, const Json::Value& arg);

					int getSchedule();
					int getTarget();

				private:
					bool getChecker();

				private:
					int _id;
					int _state;
					ParamPtr _param;
					CheckPtr _checker;
			};
		}
	}

	class playerKingdomWarTask
		: public _auto_player
	{
		public:
			playerKingdomWarTask(playerData* const own);

			virtual void classLoad();
			void update();

			void update(int type, const Json::Value& arg);
			int getPersonTaskReward(int id, Json::Value& r);
			int nationTaskState();
			void setNationRewarded();
			void personalTaskLog(unsigned end_time);

			int personTaskRP();
			void resetPersonTaskRP();
			void resetPersonTaskRPAndUpdate();
			int nationTaskRP();
			void resetNationTaskRP();
			void resetNationTaskRPAndUpdate();
			void checkAndUpdate();

		private:
			void initUpdateTime();
			void getNextResetTime(unsigned cur_time);
			void getNextClearTime(unsigned cur_time);

			void clear();
			void reset();

			virtual bool _auto_save();
			virtual void _auto_update();
			
		private:
			KingdomWar::Task::PRecord _person_task;
			int _nation_task_state; // -1 uninited 0 not rewarded 1 rewarded
			int _task_lv;
			unsigned _task_clear_time;

			enum{
				CLEAR,
				RESET,
			};

			unsigned _next_update_time;
			int _action;

			int _pt_rp;
			int _nt_rp;
	};
}

#include "player_trade.h"
#include "business.h"
#include "business_daily_rank.h"
#include "business_single_rank.h"
#include "business_total_rank.h"

namespace gg
{
	void playerCarPos::staticLoopRoute(const structTimer& timerData, const int playerID)
	{
		playerDataPtr player = player_mgr.getCachePlayer(playerID);
		if (!player)return;
		player->CarPos().loopRoute();
	}

	void playerCarPos::loopRoute()
	{
		if (Own().isOnline())//�������
		{
			loopMove();
			if (moveList.size() > 0)
			{
				//1s ��ѯһ��
				Timer::AddEventSeconds(boostBind(playerCarPos::staticLoopRoute, _1, Own().ID()), 
					Inter::event_business_car_move_timer, 0);
				needTimer = false;
				return;
			}
		}
		else
		{
			resetMove();
			historyPos.clear();
		}
		needTimer = true;
	}

	void playerCarPos::sendFuturePos(const unsigned num /* = 5 */)
	{
		if (moveList.empty() || showIDX >= moveList.size())return;
		qValue move_json(qJson::qj_array);
		qValue x_move_json(qJson::qj_array);
		qValue y_move_json(qJson::qj_array);
		if(showIDX < 1)//��ʼ��
		{
			x_move_json.append(currentPos.x);
			y_move_json.append(currentPos.y);
		}
		else
		{
			x_move_json.append(moveList[showIDX - 1].x);
			y_move_json.append(moveList[showIDX - 1].y);
		}
		for (unsigned i = 0; i < num && showIDX < moveList.size(); i++)
		{
			WSTAR::Pos pos = moveList[showIDX];
			++showIDX;
			x_move_json.append(pos.x);
			y_move_json.append(pos.y);
		}
		move_json.append(x_move_json).append(y_move_json);
		Own().sendToClientFillMsg(gate_client::player_car_move_annouce_resp, move_json);
	}

	void playerCarPos::loopMove(const unsigned to_client /* = true */)
	{
		const unsigned size = moveList.size();
		if (currentIDX >= size) 
		{
			if (to_client && showIDX < size)
			{
				sendFuturePos(size - showIDX);
			}
			return;
		}
		boost::system_time now = boost::get_system_time();
		leftTime += (now - startMoveTime).total_milliseconds();
		startMoveTime = now;
		const unsigned step_speed = Own().Trade().getSpeed();
		const unsigned obli_speed = step_speed * 1.414;

		bool update = false;
		const bool weishe_buff = Own().Trade().checkBuff(TradeBuff::weishe);
		while (currentIDX < size)//��������Ҫ�ƶ�
		{
			WSTAR::Pos pos = moveList[currentIDX];
			const int dispart = pos - currentPos;
// 			cout << "now pos: " << currentPos.x << "," << currentPos.y <<
// 			" to move: " << pos.x << "," << pos.y << endl;
			if (dispart == 0)
			{
				++currentIDX;
				continue;
			}
// 			const double rate = currentIDX < 5 ? (currentIDX < 2 ? 0.4 : 0.8) : 1.0;
// 			const unsigned need_time = (dispart == 1 ? step_speed * rate : obli_speed * rate);
			const unsigned need_time = (dispart == 1 ? step_speed : obli_speed);
			if (leftTime < need_time)break;

			historyPos.push_back(pos);
			if (historyPos.size() > 5)
			{
				historyPos.pop_front();
			}
			++currentIDX;
			currentPos = pos;
			update = true;
			leftTime -= need_time;

			if (!weishe_buff && business_sys.inSharkArea(pos.x, pos.y))//�����
			{
				Own().Trade().alterDurable(-5);
			}
		}

		if (update)//�����ƶ���һ��
		{
			is_dirty = true;
			if (Own().isOnline())
			{
				business_sys.updateMoveCar(Own().getOwnDataPtr());
			}
		}

		if (to_client && currentIDX + 10 > showIDX)
		{
			sendFuturePos();
		}

		//��������ݱ仯
		if (currentIDX >= size)
		{
			if (to_client && showIDX < size)
			{
				sendFuturePos(size - showIDX);
			}
			resetMove();
		}
	}

	//pos
	playerCarPos::playerCarPos(playerData* const own) : _auto_player(own)
	{
		leftTime = 0;//����
		startMoveTime = boost::get_system_time();
		currentPos = business_sys.getAvailablePos();
		is_dirty = false;
		currentIDX = 0;
		needTimer = true;
		moveList.clear();
		historyPos.clear();
	}

	bool playerCarPos::_auto_save()
	{
		return toSave();
	}

	bool playerCarPos::isNearlyAim()
	{
		//�Ƿ��Ѿ�����Ŀ����	
		WSTAR::Pos aim = aimXY();
		WSTAR::Pos left_bottom;
		left_bottom.x = aim.x > 1 ? aim.x - 1 : aim.x;
		left_bottom.y = aim.y > 1 ? aim.y - 1 : aim.y;
		WSTAR::Pos right_top;
		right_top.x = aim.x + 1;
		right_top.y = aim.y + 1;
		return (
			currentPos.x >= left_bottom.x &&
			currentPos.x <= right_top.x &&
			currentPos.y >= left_bottom.y &&
			currentPos.y <= right_top.y
			);
	}

	void playerCarPos::newRoute(WSTAR::Pos start_pos, std::vector<WSTAR::Pos>& vec)
	{
		resetMove();
		moveList.swap(vec);
		startMoveTime = boost::get_system_time();
		currentPos = start_pos;
		//sendFuturePos();
		//�������ϵͳ��ѯ
		if (needTimer)
		{
			Timer::AddEventSeconds(boostBind(playerCarPos::staticLoopRoute, _1, Own().ID()),
				Inter::event_business_car_move_timer, 0);
			needTimer = false;
		}
	}

	bool playerCarPos::setPos(const int x, const int y)
	{
		if (business_sys.availablePlace(x, y))
		{
			currentPos = WSTAR::Pos(x, y);
			resetMove();
			historyPos.clear();
			is_dirty = true;
			_sign_auto();
			return true;
		}
		return false;
	}

	bool  playerCarPos::toSave()
	{
		if (is_dirty)
		{
			is_dirty = false;
			mongo::BSONObj key = BSON(strPlayerID << Own().ID());
			mongo::BSONObj obj = BSON(strPlayerID << Own().ID() <<
				"x" << currentPos.x << "y" << currentPos.y);
			return db_mgr.SaveMongo(DBN::dbPlayerCarPos, key, obj);
		}
		return true;
	}

	void playerCarPos::resetMove()
	{
		leftTime = 0;
		currentIDX = 0;
		showIDX = 0;
		moveList.clear();
	}

	void playerCarPos::classLoad()
	{
		mongo::BSONObj key = BSON(strPlayerID << Own().ID());
		mongo::BSONObj obj = db_mgr.FindOne(DBN::dbPlayerCarPos, key);
		if (obj.isEmpty())return;
		currentPos.x = obj["x"].Int();
		currentPos.y = obj["y"].Int();
		if (!business_sys.availablePlace(currentPos.x, currentPos.y))
		{
			currentPos = business_sys.getAvailablePos();
		}
	}

// 	void playerCarPos::sendRoute(const unsigned num /* = 100 */)
// 	{
// 		qValue json(qJson::qj_array);
// 		json.append(Own().Trade().getSpeed()).
// 			append(currentPos.x).append(currentPos.y).
// 			append(aimX()).append(aimY());
// 		qValue move_xjson(qJson::qj_array), move_yjson(qJson::qj_array);
// 		unsigned n = 0;
// 		for (unsigned i = currentIDX; i < moveList.size() && n < num; i++)
// 		{
// 			const WSTAR::Pos& pos = moveList[i];
// 			move_xjson.append(pos.x);
// 			move_yjson.append(pos.y);
// 			++n;
// 		}
// 		json.append(move_xjson).append(move_yjson);
// 		Own().sendToClientFillMsg(gate_client::player_car_route_data_resp, json);
// 	}

	bool playerCarPos::canSetStartPos(WSTAR::Pos pos)
	{
		loopMove(false);
		if (pos == currentPos)return true;
		for (std::list<WSTAR::Pos>::const_iterator it = historyPos.begin(); it != historyPos.end(); it++)
		{
			if (*it == pos)return true;
		}
		for (unsigned i = currentIDX; i < currentIDX + 1 && i < moveList.size(); i++)
		{
			if (moveList[i] == pos)return true;
		}
		return false;
	}

	void playerCarPos::stopMove()
	{
		//�����ƶ�����
		loopMove();
		resetMove();
	}

	//trade
	static struct CfgCar
	{
		vector<unsigned> speeds;
		vector<unsigned> exps;
		vector<int> durables;
		vector<unsigned> bags;
		vector<int> sales;
	}_cfg_Car;

	const CfgCar& staticCar()
	{
		return _cfg_Car;
	}

	playerTrade::playerTrade(playerData* const own) : _auto_player(own)
	{
		base_save = false;
		item_save = false;
		buff_save = false;
		base_update = false;
		item_update = false;
		buff_update = false;
		wares.clear();
		itemNum = 0;
		//��ֻ��Ϣ
		level = 1;
		exp = 0;
		durable = staticCar().durables[level];
		//durable = 0;
		//������Ϣ
		money = 0;
		completem = 0;
		tasktype = TradeType::null;
		tasktimes = 0;
		cuttask = false;
		hitPirTimes = 0;
		totaltask = 0;
		historyMax = 0;
		totalMoney = 0;
		hitSharkCD = 0;
		sharkBox.clear();
		//buff
		Buffs.clear();
	}

	void playerTrade::initData()
	{
		Json::Value json = Common::loadJsonFile("./instance/business/car.json");
		_cfg_Car.speeds.clear();
		for (unsigned i = 0; i < json["speed"].size(); i++)
		{
			_cfg_Car.speeds.push_back(json["speed"][i].asUInt());
		}
		_cfg_Car.exps.clear();
		for (unsigned i = 0; i < json["exp"].size(); i++)
		{
			_cfg_Car.exps.push_back(json["exp"][i].asUInt());
		}
		_cfg_Car.durables.clear();
		for (unsigned i = 0; i < json["durable"].size(); i++)
		{
			_cfg_Car.durables.push_back(json["durable"][i].asInt());
		}
		_cfg_Car.bags.clear();
		for (unsigned i = 0; i < json["bag"].size(); i++)
		{
			_cfg_Car.bags.push_back(json["bag"][i].asUInt());
		}
		_cfg_Car.sales.clear();
		for (unsigned i = 0; i < json["sale"].size(); i++)
		{
			_cfg_Car.sales.push_back(json["sale"][i].asInt());
		}
	}

	void playerTrade::tickPirate()
	{
		++hitPirTimes;
		base_save = true;
		base_update = true;
		_sign_auto();
	}

	int playerTrade::acceptTask(const int m, const int t)
	{
		if (taskType() != TradeType::null)return err_trade_has_task;
		money = m;
		completem = t;
		tasktype = TradeType::runing;
		if (tasktimes < 3)
		{
			cuttask = false;
		}
		else
		{
			cuttask = true;
		}
		++tasktimes;
		base_save = true;
		base_update = true;
		_sign_auto();
		return res_sucess;
	}

	void playerTrade::cancelTask()
	{
		tasktype = TradeType::null;
		money = 0;
		completem = 0;
		base_save = true;
		base_update = true;
		wares.clear();
		item_update = true;
		item_save = true;
		_sign_auto();
	}

	int playerTrade::overTask()
	{
		if (taskType() == TradeType::null)return err_illedge;
		tasktype = TradeType::null;//����Ϊ��
		int max_money = std::max(money, completem);
		if (max_money > historyMax)
		{
			historyMax = max_money;
		}
		totalMoney += max_money;
		const static long long int MaxTotal = 0x0FFFFFFFFFFFFFFF;
		totalMoney = totalMoney > MaxTotal ? MaxTotal : totalMoney;
		++totaltask;//�ۼ���ɴ���
		business_daily_rank.updatePlayer(Own().getOwnDataPtr(), max_money);//ÿ�յ�Ʊ
		business_single_rank.updatePlayer(Own().getOwnDataPtr());//��ʷ��Ʊ���
		business_total_rank.updatePlayer(Own().getOwnDataPtr());//��ʷ�������
		money = 0;
		completem = 0;
		base_save = true;
		base_update = true;

		wares.clear();
		itemNum = 0;
		item_update = true;
		item_save = true;
 		_sign_auto();
		return res_sucess;
	}

	playerTrade::playerWarePtr playerTrade::getWare(const int wareID)
	{
		WareMap::iterator it = wares.find(wareID);
		if (it == wares.end())return playerWarePtr();
		return it->second;
	}

	bool playerTrade::checkWare(const int wareID, const unsigned num)
	{
		playerWarePtr ware = getWare(wareID);
		if (!ware || ware->wareNum < num)return false;
		return true;
	}

	int playerTrade::addWare(const int wareID, const unsigned num, const int unit_price)
	{
		if (num < 1)return err_illedge;
		if (num + itemNum > staticCar().bags[level])return err_trade_bag_full;
		playerWarePtr ware = getWare(wareID);
		if (!ware)
		{
			ware = Creator<Ware>::Create();
			ware->wareID = wareID;
			wares[ware->wareID] = ware;
		}
		ware->avPrice = (ware->avPrice * ware->wareNum + unit_price * num) / (ware->wareNum + num);
		ware->wareNum += num;
		itemNum += num;
		item_update = true;
		item_save = true;
		_sign_auto();
		return res_sucess;
	}

	int playerTrade::removeWare(const int wareID, const unsigned num)
	{
		if (!checkWare(wareID, num))return err_illedge;
		playerWarePtr ware = getWare(wareID);
		ware->wareNum -= num;
		if (ware->wareNum == 0)
		{
			wares.erase(ware->wareID);
		}
		itemNum -= num;
		item_update = true;
		item_save = true;
		_sign_auto();
		return res_sucess;
	}

	void playerTrade::updateBase()
	{
		Json::Value json;
		json[strMsg][0u] = res_sucess;
		Json::Value& data_json = json[strMsg][1u];
		data_json["lv"] = level;
		data_json["e"] = exp;
		data_json["d"] = durable;
		data_json["m"] = money;
		data_json["cm"] = completem;
		data_json["tk"] = tasktimes;
		data_json["cut"] = cuttask;
		data_json["tt"] = totaltask;
		data_json["hm"] = historyMax;
		data_json["tp"] = tasktype;
		data_json["tm"] = totalMoney;
		data_json["hpt"] = hitPirTimes;
		data_json["hscd"] = hitSharkCD;
		Own().sendToClient(gate_client::player_trade_base_resp, json);
	}

	void playerTrade::updateWare()
	{
		Json::Value json;
		json[strMsg][0u] = res_sucess;
		Json::Value& data_json = json[strMsg][1u] = Json::arrayValue;
		for (WareMap::iterator it = wares.begin(); it != wares.end(); ++it)
		{
			playerWarePtr ware = it->second;
			Json::Value item_json;
			item_json.append(ware->wareID);
			item_json.append(ware->wareNum);
			item_json.append(ware->avPrice);
			data_json.append(item_json);
		}
		Own().sendToClient(gate_client::player_trade_ware_resp, json);
	}

	void playerTrade::updateBuff()
	{
		Json::Value json;
		json[strMsg][0u] = res_sucess;
		Json::Value& data_json = json[strMsg][1u] = Json::arrayValue;
		const unsigned now = Common::gameTime();
		for (BuffMap::iterator it = Buffs.begin(); it != Buffs.end();)
		{
			const TradeBuff::ID id = it->first;
			const unsigned over = it->second;
			++it;
			if (now >= over)continue;
			Json::Value buff_json;
			buff_json.append(id);
			buff_json.append(over);
			data_json.append(buff_json);
		}
		Own().sendToClient(gate_client::player_trade_buff_resp, json);
	}

	bool playerTrade::checkBuff(const TradeBuff::ID id)
	{
		unsigned now = Common::gameTime();
		BuffMap::iterator it = Buffs.find(id);
		if (it == Buffs.end())return false;
		if (now >= it->second)
		{
			Buffs.erase(it);
			buff_save = true;
			buff_update = true;
			_sign_auto();
			return false;
		}
		return true;
	}

	bool playerTrade::insertBuff(const TradeBuff::ID id, const unsigned time)
	{
		if (!checkBuff(id))
		{
			Buffs[id] = Common::gameTime() + time;
			buff_save = true;
			buff_update = true;
			_sign_auto();
			return true;
		}
		return false;
	}

	void playerTrade::_auto_update()
	{
		if (base_update)
		{
			base_update = false;
			updateBase();
		}
		if (item_update)
		{
			item_update = false;
			updateWare();
		}
		if (buff_update)
		{
			buff_update = false;
			updateBuff();
		}
	}

	bool playerTrade::_auto_save()
	{
		mongo::BSONObj key = BSON(strPlayerID << Own().ID());
		if (base_save)
		{
			base_save = false;
			mongo::BSONArrayBuilder arr;
			for (std::set<unsigned>::const_iterator it = sharkBox.begin(); it != sharkBox.end(); it++)
			{
				arr << *it;
			}
			mongo::BSONObj obj = BSON(
				strPlayerID << Own().ID() <<
				"lv" << level << "e" << exp << "d" << durable << "m" <<
				money << "cm" << completem << "tk" << tasktimes <<
				"tt" << totaltask << "hm" << historyMax << "tp" <<
				tasktype << "tm" << totalMoney << "hpt" << hitPirTimes <<
				"sb" << arr.arr() << "cut" << cuttask
			);
			db_mgr.SaveMongo(DBN::dbPlayerTrade, key, obj);
		}
		if (item_save)
		{
			item_save = false;
			mongo::BSONArrayBuilder arr;
			for (WareMap::iterator it = wares.begin(); it != wares.end(); ++it)
			{
				playerWarePtr ware = it->second;
				arr << BSON("i" << ware->wareID << "n" << ware->wareNum <<
					"p" << ware->avPrice);
			}
			mongo::BSONObj obj = BSON(strPlayerID << Own().ID() <<
				"v" << arr.arr());
			db_mgr.SaveMongo(DBN::dbPlayerTradeItem, key, obj);
		};
		if (buff_save)
		{
			buff_save = false;
			const unsigned now = Common::gameTime();
			mongo::BSONArrayBuilder arr;
			for (BuffMap::iterator it = Buffs.begin(); it != Buffs.end();)
			{
				const TradeBuff::ID id = it->first;
				const unsigned over = it->second;
				++it;
				if (now >= over)
				{
					Buffs.erase(id);
					continue;
				}
				arr << BSON("i" << id << "o" << over);
			}
			mongo::BSONObj obj = BSON(strPlayerID << Own().ID() <<
				"v" << arr.arr());
			db_mgr.SaveMongo(DBN::dbPlayerTradeBuff, key, obj);
		}
		return true;
	}

	//base
	int playerTrade::addExp(const unsigned num)
	{
		const vector<unsigned> exps = staticCar().exps;
		if (level >= exps.size())return err_trade_car_level_max;
		const unsigned old_level = level;
		this->exp += num;
		for (unsigned idx = level; idx < exps.size(); ++idx)
		{
			if (this->exp >= exps[idx])
			{
				this->exp -= exps[idx];
				level = idx + 1;
				continue;
			}
			break;
		}
		if (level >= exps.size())
		{
			this->exp = 0;
		}
		if (old_level != level)
		{
			Log(DBLOG::strLogBusiness, Own().getOwnDataPtr(), 5, old_level, level);
			durable = staticCar().durables[level];
		}
		base_update = true;
		base_save = true;
		_sign_auto();
		return 0;
	}
	unsigned playerTrade::getSpeed()
	{
		return staticCar().speeds[level];
	}
	int playerTrade::getSaleRate()
	{
		return staticCar().sales[level];
	}

	void playerTrade::alterMoney(const int num)
	{
		money += num;
		money = money < 0 ? 0 : money;
		if (tasktype == TradeType::runing && money >= completem)
		{
			tasktype = TradeType::complete;
		}
		base_update = true;
		base_save = true;
		_sign_auto();
	}
	
	double playerTrade::getDurableRate()
	{
		const double md = staticCar().durables[level];
		return durable / md;
	}

	unsigned playerTrade::getDurableLimit()
	{
		const int md = staticCar().durables[level];
		if (md > durable)return md - durable;
		return 0;
	}

	void playerTrade::fullDurable()
	{
		durable = staticCar().durables[level];
		base_update = true;
		base_save = true;
		_sign_auto();
	}

	void playerTrade::alterDurable(const int num)
	{
		durable += num;
		durable = durable < 0 ? 0 : durable;
		base_update = true;
		base_save = true;
		_sign_auto();
	}

	void playerTrade::classLoad()
	{
		mongo::BSONObj key = BSON(strPlayerID << Own().ID());
		{//base
			mongo::BSONObj obj = db_mgr.FindOne(DBN::dbPlayerTrade, key);
			if (!obj.isEmpty())
			{
				level = (unsigned)obj["lv"].Int();
				exp = (unsigned)obj["e"].Int();
				durable = obj["d"].Int();
				money = obj["m"].Int();
				tasktimes = (unsigned)obj["tk"].Int();
				cuttask = obj["cut"].eoo() ? false : obj["cut"].Bool();
				if (!obj["hpt"].eoo())hitPirTimes = obj["hpt"].Int();
				totaltask = (unsigned)obj["tt"].Int();
				historyMax = obj["hm"].Int();
				completem = obj["cm"].Int();
				tasktype = (TradeType::Type)obj["tp"].Int();
				totalMoney = obj["tm"].type() == mongo::NumberInt ? obj["tm"].Int() : obj["tm"].Long();
				if (!obj["sb"].eoo())
				{
					std::vector<mongo::BSONElement> vecs = obj["sb"].Array();
					for (unsigned i = 0; i < vecs.size(); i++)
					{
						sharkBox.insert(vecs[i].Int());
					}
				}
			}
		};//base
		{//item
			mongo::BSONObj obj = db_mgr.FindOne(DBN::dbPlayerTradeItem, key);
			if (!obj.isEmpty())
			{
				vector<mongo::BSONElement> elems = obj["v"].Array();
				for (unsigned i = 0; i < elems.size(); ++i)
				{
					mongo::BSONElement& elem = elems[i];
					playerWarePtr ware = Creator<Ware>::Create();
					ware->wareID = elem["i"].Int();
					ware->wareNum = (unsigned)elem["n"].Int();
					ware->avPrice = elem["p"].Int();
					wares[ware->wareID] = ware;
					itemNum += ware->wareNum;
				}
			}
		};//item
		{//buff
			mongo::BSONObj obj = db_mgr.FindOne(DBN::dbPlayerTradeBuff, key);
			if (!obj.isEmpty())
			{
				const unsigned now = Common::gameTime();
				vector<mongo::BSONElement> elems = obj["v"].Array();
				for (unsigned i = 0; i < elems.size(); ++i)
				{
					mongo::BSONElement& elem = elems[i];
					const TradeBuff::ID id = (TradeBuff::ID)elem["i"].Int();
					const unsigned over = (unsigned)elem["o"].Int();
					if (now >= over)continue;
					Buffs[id] = over;
				}
			}
		};//buff
	}
}
﻿//###################################
//create by Jim
//2016-09-18
//###################################

#pragma once

#include <vector>
#include "commom.h"

namespace WSTAR
{
	// 默认值未正三角的三角函数近似值 , 默认值不要修改了, 创建的时候, 最好传参数
	static const unsigned kStepValue = 10;//正向g影响值
	static const unsigned kObliqueValue = 14;//斜向g影响值

	//坐标
	struct Pos
	{
		int x;
		int y;

		Pos()
			: x(0)
			, y(0)
		{
		}

		Pos(const int _x, const int _y)
			: x(_x)
			, y(_y)
		{
		}

		void setXY(const int _x, const int _y) 
		{
			x = _x;
			y = _y;
		}

		bool operator== (const Pos &other) const
		{
			return x == other.x && y == other.y;
		}

		bool operator!= (const Pos &other) const
		{
			return x != other.x || y != other.y;
		}

		bool operator<(const Pos &other) const
		{
			if (x != other.x)return x < other.x;
			return y < other.y;
		}

		int operator-(const Pos &other)const 
		{
			return std::abs(x - other.x) + std::abs(y - other.y);
		}
	};

	typedef boost::function<bool(const int x, const int y)> ReachFunc;
}

class WStar
{
private:
	//节点状态
	enum NodeState
	{
		NOTEXIST,
		IN_OPENLIST,
		IN_CLOSELIST
	};

public:
	struct Node
	{
		unsigned		g;//开始点到当前点的消耗量
		unsigned		h;//当前点到目标点的消耗量
		WSTAR::Pos		pos;//坐标
		NodeState		state;//状态
		Node*			parent;//父节点

		int f() const//总值
		{
			return g + h;
		}
		inline Node()
			: g(0)
			, h(0)
			, pos(0,0)
			, parent(NULL)
			, state(NOTEXIST)
		{
		}
		inline Node(const WSTAR::Pos &p)
			: g(0)
			, h(0)
			, pos(p)
			, parent(NULL)
			, state(NOTEXIST)
		{
		}

		bool operator==(const WSTAR::Pos& p)const
		{
			return pos == p;
		}

		bool operator==(const Node& node)const
		{
			return pos == node.pos;
		}
	};

public:
	//参数配置
	bool				publicCorner;//是否允许斜角行走
	WSTAR::ReachFunc	publicReach;//判断能否移动的依据
	unsigned			publicStep;//非斜角消耗值
	unsigned			publicOblique;//斜角消耗值//一般为非斜角值的1.4倍

	//开始结束节点
	WSTAR::Pos			publicStart;
	WSTAR::Pos			publicEnd;

	WStar()
		: publicReach(NULL)
		, publicStep(WSTAR::kStepValue)
		, publicOblique(WSTAR::kObliqueValue)
		, publicStart()
		, publicEnd()
	{

	}
	~WStar();

public:
	bool isValidParam();

	std::vector<WSTAR::Pos> find();
private:
	void clear();

private:
	unsigned calculGValue(Node *parent_node, const WSTAR::Pos &current_pos);

	unsigned calculHValue(const WSTAR::Pos &current_pos, const WSTAR::Pos &end_pos);

	bool findInOpenList(const WSTAR::Pos &pos, Node *&out);

	bool isInCloseList(const WSTAR::Pos &pos);

	void findNearlyPos(const WSTAR::Pos &current_pos, bool allow_corner, std::vector<WSTAR::Pos> &nearly_pos);

	void handleInOpenNode(Node *current_node, Node *target_node);

	void handleNotInOpenNode(Node *current_node, Node *target_node, const WSTAR::Pos &end_pos);

private:
	UNORDERMAP(int, Node, XMap);
	UNORDERMAP(int, XMap, XYMap);
	XYMap _maps;

	struct lessNode
	{
		const bool operator()(WStar::Node* const &left, WStar::Node* const &right)const
		{
			return left->f() < right->f();
		}
	};
	typedef std::multiset< Node*, WStar::lessNode > multiList;
	multiList _openList;//小值在前的顺序
};

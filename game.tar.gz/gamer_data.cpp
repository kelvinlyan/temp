#include "gamer_data.h"
#include "dbDriver.h"
#include "gate_account_protocol.h"
#include "game_server.h"
#include "warlords_system.h"
#include "task_mgr.h"
#include "email_system.h"
#include "kingdom_def.h"
#include "heroparty_system.h"
#include "gamer_battle_rank.h"

namespace gg
{
	const static unsigned MaxLoginDay = 7;

	playerBase::playerBase(playerData* const own, const string pN) : _auto_player(own)
	{
		initial();
		playerName = pN;
	}

	playerBase::playerBase(playerData* const own, const int pID) : _auto_player(own)
	{
		initial();
		playerID = pID;
	}

// 	playerBase::playerBase(playerData* const own, const int pID, const string pN) : _auto_player(own)
// 	{
// 		initial();
// 		playerID = pID;
// 		playerName = pN;
// 	}

	static vector<unsigned> cfgExpSeq;
	static vector<unsigned> vipExpSeq;

	unsigned playerBase::MAXLEVEL()
	{
		return cfgExpSeq.size();
	}

	unsigned playerBase::MAXVIPLEVEL()
	{
		return vipExpSeq.size();
	}

	void playerBase::initData()
	{
		cfgExpSeq.clear();
		vipExpSeq.clear();
		Json::Value json = Common::loadJsonFile("./instance/gamer/exp.json");
		for (unsigned i = 0; i < json.size(); ++i)
		{
			cfgExpSeq.push_back(json[i].asUInt());
		}

		Json::Value ajson = Common::loadJsonFile("./instance/vip/vipexp.json");
		for (unsigned i = 0; i < ajson.size(); ++i)
		{
			vipExpSeq.push_back(ajson[i].asUInt());
		}
	}

	void playerBase::Online()
	{
		OnlineTime = Common::gameTime();
		_auto_save();
	}

	bool playerBase::motifyName(const string name)
	{
		if (name.empty())return false;
		if (name == playerName)return false;
		string tmpName = playerName;
		playerName = name;
		Log(DBLOG::strLogPlayerName, Own().getOwnDataPtr(), -1, tmpName, playerName);
		if (tmpName != playerName)
		{
			//���͸���̨
			Json::Value updateAccount;
			updateAccount[strMsg][0u] = playerName;
			string strSend = updateAccount.toIndentString();
			net::Msg mj(Own().ID(), service::process_id::ACCOUNT_NET_ID, protocol::l2c::notice_account_player_update_resp, strSend);
			game_svr->async_send_to_gate(mj);
			onNameMotify(tmpName);
		}
		_sign_auto();
		return true;
	}

	void playerBase::setSex(const Gender::SEX type)
	{
		playerGender = type;
		_sign_auto();
	}

	void playerBase::setNation(const Kingdom::NATION type)
	{
		const Kingdom::NATION old = playerNation;
		playerNation = type;
		onSetNation(old);
		_sign_auto();
		Log(DBLOG::strLogPlayerNation, Own().getOwnDataPtr(), -1, old, playerNation);
	}

	void playerBase::setFace(const int id, const bool init /* = false */)
	{
		if (init)
		{
			playerFaceID = id;
		}
		else
		{
			int iOld = playerFaceID;
			playerFaceID = id;
			onSetFace(iOld);
		}
		_sign_auto();
	}

	void playerBase::loginBoxPP()
	{
		if (LoginDays < MaxLoginDay)
		{
			++LoginDays;
			_sign_auto();
		}
	}

	bool playerBase::canGetBox(const unsigned day)
	{
		if (day >= MaxLoginDay)return false;
		return (LoginSign & (0x0001 << day)) == 0x0;
	}

	void playerBase::setLoginBox(const unsigned day)
	{
		if (day >= MaxLoginDay)return;
		LoginSign |= (0x0001 << day);
		_sign_auto();
	}

	void playerBase::setLevelInfo(const unsigned lv, const unsigned exp)
	{
		const unsigned old = playerLV;
		if (lv >= cfgExpSeq.size())
		{
			playerLV = cfgExpSeq.size();
		}
		else
		{
			playerLV = lv;
		}
		playerExp = exp;
		upgrade();//�鿴�Ƿ�����
		if (old != playerLV)
		{
			onLevelAlter(old, playerLV);
			Log(DBLOG::strLogPlayerLevel, Own().getOwnDataPtr(), -1, old, playerLV);
		}
		_sign_auto();
	}

	void playerBase::tickRename()
	{
		++renameTimes;
		_sign_auto();
	}

	void playerBase::setProcess(const unsigned pro)
	{
		Log(DBLOG::strLogClientProcess, Own().getOwnDataPtr(), -1, playerProcess, pro);
		playerProcess = pro;
		_sign_auto();
	}

	void playerBase::motifyNo_(const int no)
	{
		rankNo_ = no;
		TaskMgr::update(Own().getOwnDataPtr(), Task::HeroPartyEveryRank);
	}

	void playerBase::motifyNationOf_(const int of)
	{
		_sign_update();
		/*if (of == nationOfficial)return;
		nationOfficial = of;
		if (Own().isInitial())
		{
			_sign_update();
		}*/
	}

	void playerBase::motifyMaxBV(const int value)
	{
		if (value > MaxBattleValue)
		{
			MaxBattleValue = value;
			battle_rank.updatePlayer(Own().getOwnDataPtr());
			Own().ActivityRank().set_process(ActivityRankEnum::activity_battle_rank, MaxBattleValue);
			_sign_save();
		}
	}

	void playerBase::upgrade()
	{
		for (unsigned idx = playerLV; idx < cfgExpSeq.size(); ++idx)
		{
			if (playerExp >= cfgExpSeq[idx])
			{
				playerExp -= cfgExpSeq[idx];
				playerLV = idx + 1;
				continue;
			}
			break;
		}
		if (playerLV >= cfgExpSeq.size())
		{
			playerExp = 0;
		}
	}

	void playerBase::updateWarLose()
	{
		if (LoseWarTimes < 100)++LoseWarTimes;
		if (LoseWarTimes >= 100)
		{
			LoseWarCD = Common::gameTime() + 3 * MINUTE;
		}
		_sign_auto();
	}

	void playerBase::resetWarLose()
	{
		LoseWarTimes = 0;
		_sign_auto();
	}

	bool playerBase::isMaxLevel()
	{
		return (playerLV >= cfgExpSeq.size());
	}

	int playerBase::addExp(const unsigned val)
	{
		if (playerLV >= cfgExpSeq.size())return err_gamer_level_max;
		if (val < 1)return err_illedge;
		const int tmpLevel = playerLV;
		const int tmpExp = playerExp;
		playerExp += val;
		upgrade();
		if (tmpLevel != playerLV)
		{
			onLevelAlter(tmpLevel, playerLV);
			Log(DBLOG::strLogPlayerLevel, Own().getOwnDataPtr(), -1, tmpLevel, playerLV, tmpExp, playerExp);
		}
		_sign_auto();
		return res_sucess;
	}

	int playerBase::addVipExp(const unsigned val)
	{
		if (playerVipLv > vipExpSeq.size()) return err_vip_level_max;
		if (val < 1) return err_illedge;
		int temVipLevel = playerVipLv;
		int tmpVipExp = playerVipExp;
		playerVipExp += val;

// 		if (playerVipLv == 0 && tmpVipExp == 0 && playerVipExp > 0)
// 			Own().Vip().addVipGift(0);

		for (unsigned idx = playerVipLv; idx < vipExpSeq.size(); ++idx)
		{
			if (playerVipExp >= vipExpSeq[idx])
			{
				playerVipExp -= vipExpSeq[idx];
				playerVipLv = idx + 1;
				Own().Vip().addVipGift(playerVipLv);
				TaskMgr::update(Own().getOwnDataPtr(), Task::Vip);
				continue;
			}
			break;
		}
		/*
		if (playerVipLv >= vipExpSeq.size())
		{
			playerVipExp = 0;
		}
		*/
		if (temVipLevel != playerVipLv)
		{
			onVipAlter(temVipLevel, playerVipLv);
			Log(DBLOG::strLogPlayerVipLevel, Own().getOwnDataPtr(), -1, temVipLevel, playerVipLv);
		}
		_sign_auto();
		return res_sucess;
	}

	void playerBase::_auto_update()
	{
		qValue json(qJson::qj_object), list_json(qJson::qj_array), resJson(qJson::qj_object);
		resJson.addMember(strPlayerID, playerID);
		resJson.addMember(strPlayerName, playerName);
		resJson.addMember(strPlayerLV, playerLV);
		resJson.addMember("exp", playerExp);
		resJson.addMember("sex", playerGender);
		resJson.addMember("nat", playerNation);
		resJson.addMember("fid", playerFaceID);
		resJson.addMember("rn", renameTimes);
		resJson.addMember("vip", playerVipLv);
		resJson.addMember("vexp", playerVipExp);
		resJson.addMember("pp", playerProcess);
		resJson.addMember("nof", NationOf_());
		resJson.addMember("pc", playerCreate);
		resJson.addMember("lut", LVUpLast);
		resJson.addMember("lds", LoginDays);//�Ѿ����������
		resJson.addMember("lsg", LoginSign);//��ȡ��ʶ
		resJson.addMember("lwt", LoseWarTimes);//ʧ�ܴ���
		resJson.addMember("lwcd", LoseWarCD);//ʧ��CD
		resJson.addMember("mbv", MaxBattleValue);//max battle value
		list_json.append(res_sucess);
		list_json.append(resJson);
		json.addMember(strMsg, list_json);
		Own().sendToClient(gate_client::player_info_update_resp, json);
	}

	bool playerBase::_auto_save()
	{
		mongo::BSONObj key = BSON(strPlayerID << playerID);// << strPlayerName << playerName);
		mongo::BSONObj obj = BSON(strPlayerID << playerID << strPlayerName << playerName << strPlayerLV << playerLV <<
			"exp" << playerExp << "sex" << playerGender << "nat" << playerNation << "fid" << playerFaceID << "pc" << 
			playerCreate << "rn" << renameTimes << "vip" << 
			playerVipLv << "vexp" << playerVipExp << "pp" << playerProcess << "lut" << LVUpLast << "olt" << 
			OnlineTime << "mbv" << MaxBattleValue << "lds" << LoginDays << "lwt" << LoseWarTimes << "lwcd" <<
		LoseWarCD << "lsg" << LoginSign << "uid" << uidKey << "cid" << cidKey << "gid" << gidKey);
		return db_mgr.SaveMongo(DBN::dbPlayerBase ,key, obj);
	}


	void playerBase::classLoad()
	{
		mongo::BSONObj key;
		if (playerID > 0)key = BSON(strPlayerID << playerID);
		else if (!playerName.empty())key = BSON(strPlayerName << playerName);
		else return;
		mongo::BSONObj obj = db_mgr.FindOne(DBN::dbPlayerBase, key);
		if (obj.isEmpty())return;
		playerID = obj[strPlayerID].Int();
		playerName = obj[strPlayerName].String();
		playerLV = (unsigned)obj[strPlayerLV].Int();
		playerExp = obj["exp"].Int();
		playerGender = (Gender::SEX)obj["sex"].Int();
		playerNation = (Kingdom::NATION)obj["nat"].Int();
		playerFaceID = obj["fid"].Int();
		playerCreate = (unsigned)obj["pc"].Int();
		if (!obj["rn"].eoo())renameTimes = obj["rn"].Int();
		playerVipLv = obj["vip"].eoo() ? 0 : obj["vip"].Int();
		playerVipExp = obj["vexp"].eoo() ? 0 : obj["vexp"].Int();
		playerProcess = obj["pp"].eoo() ? 0 : obj["pp"].Int();
		if (!obj["lut"].eoo())LVUpLast = obj["lut"].Int();
		OnlineTime = obj["olt"].eoo() ? Common::gameTime() : obj["olt"].Int();
		MaxBattleValue = obj["mbv"].eoo() ? 0 : obj["mbv"].Int();
		LoginDays = obj["lds"].eoo() ? 1 : obj["lds"].Int();
		LoginDays = LoginDays > MaxLoginDay ? MaxLoginDay : LoginDays;
		LoginSign = (obj["lsg"].type() != mongo::NumberInt) ? 0 : obj["lsg"].Int();
		LoseWarTimes = obj["lwt"].eoo() ? 0 : obj["lwt"].Int();
		LoseWarCD = obj["lwcd"].eoo() ? 0 : obj["lwcd"].Int();
		cidKey = obj["cid"].eoo() ? "" : obj["cid"].String();
		uidKey = obj["uid"].eoo() ? "" : obj["uid"].String();
		gidKey = obj["gid"].eoo() ? "" : obj["gid"].String();
	}

	void playerBase::initial()
	{
		playerID = -1;
		cidKey = "";
		uidKey = "";
		gidKey = "";

		playerName = "";
		playerCreate = 0;
		playerExp = 0;
		playerFaceID = -1;
		playerGender = Gender::Other;
		playerNation = Kingdom::null;
		playerLV = 1;//��ҳ�ʼΪ1
		LVUpLast = Common::gameTime();
		renameTimes = 0;
		playerVipLv = 0;
		playerVipExp = 0;
		playerProcess = 0;
		rankNo_ = -1;//ȺӢ������//Ĭ��������
		MaxBattleValue = 0;
		OnlineTime = 0;
		LoginDays = 1;//������ɫ����ĳ�ʼ����
		LoginSign = 0;
		LoseWarTimes = 0;
		LoseWarCD = 0;
	}

	int playerBase::NationOf_()
	{
		return Own().KingFight().getTitle();
	}

	int playerBase::RankNo_()
	{
		if (rankNo_ < 0)
		{
			rankNo_ = heroparty_sys.getRankNo_(ID());
		}
		return rankNo_;
	}

	int playerBase::MaxBV()
	{
		if (MaxBattleValue < 1)
		{
			MaxBattleValue = Own().WarFM().currentBV();
			_auto_save();
		}
		return MaxBattleValue;
	}
}

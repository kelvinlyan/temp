#include "player_email.h"
#include "email_system.h"

namespace gg
{
	playerEmail::playerEmail(playerData* const own)
		: _auto_player(own), _owner_email_id(0), _common_email_id(0), _red_point(false), _rep_id(0)
	{
		std::string path = "./report/email/" + Common::toString(Own().ID());
		Common::createDirectories(path);
	}

	void playerEmail::classLoad()
	{
		mongo::BSONObj key = BSON(strPlayerID << Own().ID());
		mongo::BSONObj obj = db_mgr.FindOne(DBN::dbPlayerEmail, key);
		if (obj.isEmpty())
			return;

		int server_id = Own().Info().ServerID();

		checkNotEoo(obj["sys"])
		{
			std::vector<mongo::BSONElement> ele = obj["sys"].Array();
			for (unsigned i = 0; i < ele.size(); ++i)
			{
				if (ele[i]["k"].Int() == 0)
				{
					EmailPtr e = email_sys.getCommonEmail(server_id, ele[i]["v"].Int());
					if (e)
						_email_list[EmailDef::System].push_back(e);
				}
				else
				{
					_email_list[EmailDef::System].push_back(email_sys.createFromBSON(ele[i]["v"]));
				}
			}
		}
		checkNotEoo(obj["gmr"])
		{
			std::vector<mongo::BSONElement> ele = obj["gmr"].Array();
			for (unsigned i = 0; i < ele.size(); ++i)
				_email_list[EmailDef::Gamer].push_back(email_sys.createFromBSON(ele[i]));
		}
		checkNotEoo(obj["pkg"])
		{
			std::vector<mongo::BSONElement> ele = obj["pkg"].Array();
			for (unsigned i = 0; i < ele.size(); ++i)
			{
				if (ele[i]["k"].Int() == 0)
				{
					EmailPtr e = email_sys.getCommonEmail(server_id, ele[i]["v"].Int());
					if (e)
						_email_list[EmailDef::Package].push_back(e);
				}
				else
				{
					_email_list[EmailDef::Package].push_back(email_sys.createFromBSON(ele[i]["v"]));
				}
			}
		}
		checkNotEoo(obj["rep"])
		{
			std::vector<mongo::BSONElement> ele = obj["rep"].Array();
			for (unsigned i = 0; i < ele.size(); ++i)
				_email_list[EmailDef::Report].push_back(email_sys.createFromBSON(ele[i]));
		}
		checkNotEoo(obj["oid"])
			_owner_email_id = obj["oid"].Int();
		checkNotEoo(obj["cid"])
			_common_email_id = obj["cid"].Int();
		checkNotEoo(obj["ri"])
			_rep_id = obj["ri"].Int();

		_red_point = getRedPoint();
	}

	bool playerEmail::_auto_save()
	{
		mongo::BSONObj key = BSON(strPlayerID << Own().ID());
		mongo::BSONObjBuilder obj;
		obj << strPlayerID << Own().ID();
		{
			mongo::BSONArrayBuilder b;
			ForEach(EmailList, it, _email_list[EmailDef::System])
			{
				if ((*it)->common())
					b.append(BSON("k" << 0 << "v" << (*it)->id()));
				else
					b.append(BSON("k" << 1 << "v" << (*it)->toJson().toIndentString()));
			}
			obj << "sys" << b.arr();
		}
		{
			mongo::BSONArrayBuilder b;
			ForEach(EmailList, it, _email_list[EmailDef::Gamer])
				b.append((*it)->toJson().toIndentString());
			obj << "gmr" << b.arr();
		}
		{
			mongo::BSONArrayBuilder b;
			ForEach(EmailList, it, _email_list[EmailDef::Package])
			{
				if ((*it)->common())
					b.append(BSON("k" << 0 << "v" << (*it)->id()));
				else
					b.append(BSON("k" << 1 << "v" << (*it)->toJson().toIndentString()));
			}
			obj << "pkg" << b.arr();
		}
		{
			mongo::BSONArrayBuilder b;
			ForEach(EmailList, it, _email_list[EmailDef::Report])
				b.append((*it)->toJson().toIndentString());
			obj << "rep" << b.arr();
		}
		obj << "oid" << _owner_email_id << "cid" << _common_email_id << "ri" << _rep_id;

		return db_mgr.SaveMongo(DBN::dbPlayerEmail, key, obj.obj());
	}

	void playerEmail::_auto_update()
	{}

	void playerEmail::findEmailList(const EmailList& email_list, unsigned& cur_pos, unsigned& begin, unsigned end, Json::Value& el)
	{
		for (EmailList::const_iterator it = email_list.begin()
			; it != email_list.end(); ++it, ++cur_pos)
		{
			if (cur_pos < begin)
				continue;
			if (begin >= end)
				break;
			el.append((*it)->toJson());
			++begin;
		}
	}

	Json::Value playerEmail::getEmailList(unsigned begin, unsigned num)
	{
		addCommonEmail();

		Json::Value info;
		info["n"] =(unsigned)(_email_list[EmailDef::System].size()
			+ _email_list[EmailDef::Gamer].size()
			+ _email_list[EmailDef::Package].size()
			+ _email_list[EmailDef::Report].size());

		Json::Value& el = info["l"];
		unsigned cur_pos = 0;
		unsigned end = begin + num;
		findEmailList(_email_list[EmailDef::Package], cur_pos, begin, end, el);
		findEmailList(_email_list[EmailDef::System], cur_pos, begin, end, el);
		findEmailList(_email_list[EmailDef::Gamer], cur_pos, begin, end, el);
		findEmailList(_email_list[EmailDef::Report], cur_pos, begin, end, el);
		return info;
	}

	int playerEmail::removeEmail(int id)
	{
		ForEach(EmailList, it, _email_list[EmailDef::Package])
		{
			if ((*it)->id() == id)
			{
				_email_list[EmailDef::Package].erase(it);
				_sign_save();
				updateRedPoint(true);
				return res_sucess;
			}
		}
		ForEach(EmailList, it, _email_list[EmailDef::Gamer])
		{
			if ((*it)->id() == id)
			{
				_email_list[EmailDef::Gamer].erase(it);
				_sign_save();
				updateRedPoint(true);
				return res_sucess;
			}
		}
		ForEach(EmailList, it, _email_list[EmailDef::System])
		{
			if ((*it)->id() == id)
			{
				_email_list[EmailDef::System].erase(it);
				_sign_save();
				updateRedPoint(true);
				return res_sucess;
			}
		}
		ForEach(EmailList, it, _email_list[EmailDef::Report])
		{
			if ((*it)->id() == id)
			{
				_email_list[EmailDef::Report].erase(it);
				_sign_save();
				updateRedPoint(true);
				return res_sucess;
			}
		}
		return err_email_id_not_found;
	}

	Json::Value playerEmail::getEmailList()
	{
		Json::Value info;
		Json::Value& sys = info["sys"];
		Json::Value& gmr = info["gmr"];
		Json::Value& pkg = info["pkg"];
		Json::Value& rep = info["rep"];
		sys = Json::arrayValue;
		gmr = Json::arrayValue;
		pkg = Json::arrayValue;
		rep = Json::arrayValue;

		bool sign_save = false;

		if (!_email_list[EmailDef::System].empty())
		{
			ForEach(EmailList, it, _email_list[EmailDef::System])
			{
				if ((*it)->isDeleted())
					continue;
				sys.append((*it)->toJson());
			}
			_email_list[EmailDef::System].clear();
			sign_save = true;
		}
		if (!_email_list[EmailDef::Gamer].empty())
		{
			ForEach(EmailList, it, _email_list[EmailDef::Gamer])
				gmr.append((*it)->toJson());
			_email_list[EmailDef::Gamer].clear();
			sign_save = true;
		}
		if (!_email_list[EmailDef::Report].empty())
		{
			ForEach(EmailList, it, _email_list[EmailDef::Report])
				rep.append((*it)->toJson());
			_email_list[EmailDef::Report].clear();
			sign_save = true;
		}
		if (!_email_list[EmailDef::Package].empty())
		{
			ForEach(EmailList, it, _email_list[EmailDef::Package])
			{
				if ((*it)->isDeleted())
					continue;
				pkg.append((*it)->toJson());
			}
		}

		if (sign_save)
		{
			updateRedPoint(true);
			_sign_save();
		}

		return info;
	}

	void playerEmail::addEmail(EmailPtr& e)
	{
		int type = e->type();
		if (type < EmailDef::System || type >= EmailDef::TypeMax)
			return;
		
		if (!e->common())
		{
			e->setId(getId());
			doAddEmail(e);
			updateRedPoint(true);
			_sign_save();
		}
	}	

	void playerEmail::doAddEmail(const EmailPtr& e)
	{
		int type = e->type();

		_email_list[type].push_front(e);
		while (_email_list[type].size() > EmailDef::AmountLimit[type])
			_email_list[type].pop_back();
		if (e->type() == EmailDef::Package)
		{
			std::string str = e->getPackage().toIndentString();
			Log(DBLOG::strLogEmail, Own().getOwnDataPtr(), 1, e->id(), e->msgType(), 0, 0, 0, 0, 0, str);
		}
	}

	unsigned playerEmail::getId()
	{
		++_owner_email_id;
		if (_owner_email_id > 99999)
			_owner_email_id = 1;
		_sign_save();
		return _owner_email_id;
	}

	int playerEmail::getPackage(int id, Json::Value& r)
	{
		ForEach(EmailList, it, _email_list[EmailDef::Package])
		{
			if ((*it)->id() == id)
			{
				if ((*it)->isDeleted())
					return err_email_id_not_found;
				const Json::Value& reward = (*it)->getPackage();
				ActionBoxList box;
				if (reward[EmailDef::RewardType].asInt() == EmailDef::NormalReward)
					box = actionFormatBoxc2s(reward[EmailDef::ActionList]);
				else
				{
					Json::Value rw = Json::arrayValue;
					ForEachC(Json::Value, it, reward[EmailDef::GmGiftList])
					{
						ForEachC(Json::Value, itr, (*it)[EmailDef::ActionList])
							rw.append(*itr);
					}
					box = actionFormatBoxc2s(rw);
				}
				int res = actionDoBox(Own().getOwnDataPtr(), box, false);
				if (res == res_sucess)
				{
					int msg_type = (*it)->msgType();
					r = actionRes();
					_email_list[EmailDef::Package].erase(it);
					Log(DBLOG::strLogEmail, Own().getOwnDataPtr(), 0, id, msg_type, 0, 0, 0, 0, 0, r.toIndentString());
					updateRedPoint(true);
					_sign_save();
				}
				else
				{
					Json::Value error_code = actionError();
					res = error_code[0u][1u].asInt();
				}
				return res;
			}
		}
		return err_email_id_not_found;
	}

	bool playerEmail::getRedPoint()
	{
		for (unsigned i = 0; i < EmailDef::TypeMax; ++i)
		{
			if (!_email_list[i].empty())
				return true;
		}
		return false;
	}

	void playerEmail::updateRedPoint(bool check)
	{
		addCommonEmail();

		bool rp = getRedPoint();
		if (check && rp == _red_point)
			return;

		_red_point = rp;
		Json::Value msg;
		msg[strMsg][0u] = res_sucess;
		msg[strMsg][1u] = _red_point;
		Own().sendToClient(gate_client::email_red_point_resp, msg);
	}

	void playerEmail::addCommonEmail()
	{
		EmailVec vec;
		_common_email_id = email_sys.getCommonEmails(Own().getOwnDataPtr(), _common_email_id, vec);
		if (!vec.empty())
		{
			ForEachC(EmailVec, it, vec)
				doAddEmail(*it);
			updateRedPoint(true);
			_sign_save();
		}
	}

	std::string playerEmail::getRepId()
	{
		++_rep_id;
		if (_rep_id > 50)
			_rep_id = 1;
		return Common::toString(_rep_id);
	}
}

#include "card_system.h"
#include "chat.h"
#include "task_mgr.h"

namespace gg
{
	card_system* const card_system::_Instance = new card_system();
	static vector<unsigned> silverCost, goldCost, silverLotteryCost;
	static acPtrList LOTSilver, LOTGold, LOTHighGold, CMBFour, CMBFive, LOT4Gold, LOTHigh5Gold;
	UNORDERMAP(int, cfgCardPtr, MapCardCfg);
	static MapCardCfg mapCard;
	UNORDERMAP(unsigned, cfgCardPtr, MapCardOrderCfg);
	static MapCardOrderCfg mapCardOrder;
	//typedef vector<vector<int>> StarGroup;
	//STDVECTOR(vector<int>, StarIdGroup);
	//static StarIdGroup starGroupCard;//���Ǽ�����
	//starGroupCard.resize(5);

	const static unsigned systemLimit = 30;

	int CalSilverLotteryCost(const unsigned times)
	{
		if (times >= silverLotteryCost.size())return silverLotteryCost.back();
		return silverLotteryCost[times];
	}

	cfgCardPtr card_system::getConfig(const int ID)
	{
		MapCardCfg::iterator it = mapCard.find(ID);
		if (it == mapCard.end())return cfgCardPtr();
		return it->second;
	}

	cfgCardPtr card_system::getConfigByOrder(const unsigned ID)
	{
		MapCardOrderCfg::iterator it = mapCardOrder.find(ID);
		if (it == mapCardOrder.end())return cfgCardPtr();
		return it->second;
	}

	unsigned card_system::totalCard()
	{
		return mapCard.size();
	}

	unsigned card_system::cardOrderIdx(const int cardID)
	{
		cfgCardPtr config = getConfig(cardID);
		if (config)return config->orderID;
		return 0xFFFFFFFF;
	}

	void card_system::initData()
	{
		cout << "load card system ..." << endl;
		{
			silverCost.clear();
			Json::Value slJson = Common::loadJsonFile("./instance/cardconfig/silver_cost.json");
			for (unsigned i = 0; i < slJson.size(); ++i)
			{
				silverCost.push_back(slJson[i].asInt());
			}
		};
		{
			goldCost.clear();
			Json::Value glJson = Common::loadJsonFile("./instance/cardconfig/gold_cost.json");
			for (unsigned i = 0; i < glJson.size(); ++i)
			{
				goldCost.push_back(glJson[i].asInt());
			}
		};
		{
			silverLotteryCost.clear();
			Json::Value glJson = Common::loadJsonFile("./instance/cardconfig/silver_lottery_cost.json");
			for (unsigned i = 0; i < glJson.size(); ++i)
			{
				silverLotteryCost.push_back(glJson[i].asInt());
			}
		};
		{//��Ů��Ϣ
			cout << "load ./instance/cards/" << endl;
			mapCard.clear();
			FileJsonSeq vec = Common::loadFileJsonFromDir("./instance/cards/");
			for (unsigned i = 0; i < vec.size(); ++i)
			{
				Json::Value& json = vec[i];
				cfgCardPtr config = Creator<cardConfig>::Create();
				config->cardID = json["cardID"].asInt();
				config->faceID = json["faceID"].asInt();
				config->nameID = json["nameID"].asInt();
				config->orderID = json["orderID"].asUInt();
				config->stars = json["stars"].asInt();
				config->coin = json["coin"].asInt();
				config->silver = json["silver"].asInt();
				config->extraExp = json["extraExp"].asUInt();
				config->beginLevel = json["beginLevel"].asUInt();
				if (config->beginLevel < 1)config->beginLevel = 1;
				if (config->beginLevel > playerCard::MaxLevel())config->beginLevel = playerCard::MaxLevel();
				config->attriSeq.resize(json["seqAttri"].size());
				for (unsigned n = 0; n < json["seqAttri"].size(); ++n)
				{
					Json::Value& jattri_num = json["seqAttri"][n];
					vector<int>& attri_vec = config->attriSeq[n];
					attri_vec.resize(characterNum, 0);
					for (unsigned idx = 0; idx < characterNum; ++idx)
					{
						attri_vec[idx] = jattri_num[idx].asInt();
					}
				}
// 				config->attriRateSeq.resize(json["seqAttriRate"].size());
// 				for (unsigned n = 0; n < json["seqAttriRate"].size(); ++n)
// 				{
// 					Json::Value& jattri_num = json["seqAttriRate"][n];
// 					vector<double>& attri_vec = config->attriRateSeq[n];
// 					attri_vec.resize(characterNum);
// 					for (unsigned idx = 0; idx < characterNum; ++idx)
// 					{
// 						attri_vec[idx] = jattri_num[idx].asDouble();
// 					}
// 				}
				config->groupSET.resize(json["group"].size());
				for (unsigned n = 0; n < json["group"].size(); ++n)
				{
					Json::Value& jset = json["group"][n];
					cardConfig::Group& st = config->groupSET[n];
					for (unsigned idx = 0; idx < jset.size(); ++idx)
					{
						st.push_back(jset[idx].asInt());
					}
				}
				config->groupAttri.resize(json["groupAttri"].size());
				for (unsigned n = 0; n < json["groupAttri"].size(); ++n)
				{
					Json::Value& jattri_num = json["groupAttri"][n];
					vector<int>& attri_vec = config->groupAttri[n];
					attri_vec.resize(characterNum);
					for (unsigned idx = 0; idx < characterNum; ++idx)
					{
						attri_vec[idx] = jattri_num[idx].asInt();
					}
				}
// 				config->groupAttriRate.resize(json["groupAttriRate"].size());
// 				for (unsigned n = 0; n < json["groupAttriRate"].size(); ++n)
// 				{
// 					Json::Value& jattri_num = json["groupAttriRate"][n];
// 					vector<double>& attri_vec = config->groupAttriRate[n];
// 					attri_vec.resize(characterNum);
// 					for (unsigned idx = 0; idx < characterNum; ++idx)
// 					{
// 						attri_vec[idx] = jattri_num[idx].asDouble();
// 					}
// 				}
				mapCard[config->cardID] = config;
				mapCardOrder[config->orderID] = config;
			}
		};
		{//���ҳ鿨
			Json::Value json = Common::loadJsonFile("./instance/cardconfig/silver_lottery.json");
			LOTSilver = actionFormat(json);
		};
		{//��ҳ鿨
			Json::Value json = Common::loadJsonFile("./instance/cardconfig/gold_lottery.json");
			LOTGold = actionFormat(json);
		};
		{//�߼���ҳ鿨
			Json::Value json = Common::loadJsonFile("./instance/cardconfig/goldh_lottery.json");
			LOTHighGold = actionFormat(json);
		};
		{//�����ϳ� 4��
			Json::Value json = Common::loadJsonFile("./instance/cardconfig/combine_four.json");
			CMBFour = actionFormat(json);
		};
		{//�����ϳ� 5��
			Json::Value json = Common::loadJsonFile("./instance/cardconfig/combine_five.json");
			CMBFive = actionFormat(json);
		};
		{//��ν��10�� ��4��
			Json::Value json = Common::loadJsonFile("./instance/cardconfig/first_four_star.json");
			LOT4Gold = actionFormat(json);
		};
		{//��θ߼����10�� ��5��
			Json::Value json = Common::loadJsonFile("./instance/cardconfig/first_five_star.json");
			LOTHigh5Gold = actionFormat(json);
		};
	}

	void card_system::ladyBase(net::Msg& m, Json::Value& r)
	{
		playerDataPtr player = player_mgr.getPlayer(m.playerID);
		if (!player)Return(r, err_illedge);
		player->CardTs()._auto_update();
	}

	void card_system::ladyInvest(net::Msg& m, Json::Value& r)
	{
		playerDataPtr player = player_mgr.getPlayer(m.playerID);
		if (!player)Return(r, err_illedge);
		if (player->LV() < systemLimit)Return(r, err_player_lv_too_low);
		unsigned now = Common::gameTime();
		if (player->Card().operationTime + 2 > now)Return(r, err_operation_too_fast);
		player->Card().operationTime = now;
		ReadJsonArray;
		if (js_msg.size() != 5)Return(r, err_illedge);
		int fm[5];
		for (unsigned i = 0; i < js_msg.size(); ++i)fm[i] = js_msg[i].asInt();
		Return(r, player->Card().invest(fm));
	}

	void card_system::ladyExchange(net::Msg& m, Json::Value& r)
	{
		playerDataPtr player = player_mgr.getPlayer(m.playerID);
		if (!player)Return(r, err_illedge);
		if (player->LV() < systemLimit)Return(r, err_player_lv_too_low);
		const static int cost_gold = 30;
		if (player->Res().getCash() < cost_gold)Return(r, err_cash_not_enough);
		ReadJsonArray;
		playerCardPtr card_1 = player->Card().getCard(js_msg[0u].asInt());
		playerCardPtr card_2 = player->Card().getCard(js_msg[1u].asInt());
		if (!card_1 || !card_2)Return(r, err_illedge);
		int c1_lv = card_1->LV();
		int c1_exp = card_1->EXP();
		int c2_lv = card_2->LV();
		int c2_exp = card_2->EXP();
		card_1->setInfo(c2_lv, c2_exp);
		card_2->setInfo(c1_lv, c1_exp);
		player->Res().alterCash(-cost_gold);
		Log(DBLOG::strLogPlayerCard, player, 5, card_1->ID(), c1_lv, c1_exp, card_2->ID(), c2_lv, c2_exp, cost_gold);
		Return(r, res_sucess);
	}

	void card_system::ladyUpSilver(net::Msg& m, Json::Value& r)
	{
		playerDataPtr player = player_mgr.getPlayer(m.playerID);
		if (!player)Return(r, err_illedge);
		if (player->LV() < systemLimit)Return(r, err_player_lv_too_low);
		const int sTimes = player->CardTs().silverTimes();
		if (sTimes < 1)Return(r, err_illedge);
		const int cost_silver = silverCost[EachSilverTimes - sTimes];
		if (player->Res().getSilver() < cost_silver)Return(r, err_silver_not_enough);
		ReadJsonArray;
		playerCardPtr card = player->Card().getCard(js_msg[0u].asInt());
		if (!card)Return(r, err_card_no_find);
		unsigned add_exp = 1000;
		unsigned times = 1;
		const unsigned rd_num = Common::randomBetween(1, 10000);
		if (rd_num > 9500)times = 5;
		else if (rd_num > 8000)times = 2;
		card->addExp(add_exp * times);
		player->CardTs().subST();
		player->Res().alterSilver(-cost_silver);
		r[strMsg][1u] = add_exp;
		r[strMsg][2u] = times;
		TaskMgr::update(player, Task::CardUpSilver, 1);
		Return(r, res_sucess);
	}

	void card_system::ladyUpGold(net::Msg& m, Json::Value& r)
	{
		playerDataPtr player = player_mgr.getPlayer(m.playerID);
		if (!player)Return(r, err_illedge);
		if (player->LV() < systemLimit)Return(r, err_player_lv_too_low);
		const int gTimes = player->CardTs().goldTimes();
		if (gTimes < 1)Return(r, err_illedge);
		const int cost_gold = goldCost[EachGoldTimes - gTimes];
		if (player->Res().getCash() < cost_gold)Return(r, err_cash_not_enough);
		ReadJsonArray;
		playerCardPtr card = player->Card().getCard(js_msg[0u].asInt());
		if (!card)Return(r, err_card_no_find);
		unsigned add_exp = 5000;
		unsigned times = 1;
		const unsigned rd_num = Common::randomBetween(1, 10000);
		if (rd_num > 9500)times = 5;
		else if (rd_num > 8000)times = 2;
		card->addExp(add_exp * times);
		player->CardTs().subGT();
		player->Res().alterCash(-cost_gold);
		r[strMsg][1u] = add_exp;
		r[strMsg][2u] = times;
		TaskMgr::update(player, Task::CardUpGold, 1);
		Return(r, res_sucess);
	}

	void card_system::ladyUpFit(net::Msg& m, Json::Value& r)
	{
		playerDataPtr player = player_mgr.getPlayer(m.playerID);
		if (!player)Return(r, err_illedge);
		if (player->LV() < systemLimit)Return(r, err_player_lv_too_low);
		ReadJsonArray;
		if (js_msg[1u].size() > 30)Return(r, err_illedge);//���30��
		playerCardPtr mainCard = player->Card().getCard(js_msg[0u].asInt());
		vector<playerCardPtr> deleteList;
		unsigned add_exp = 0;
		qValue log_json(qJson::qj_array);
		for (unsigned i = 0; i < js_msg[1u].size(); ++i)
		{
			playerCardPtr delCard = player->Card().getCard(js_msg[1u][i].asInt());
			if (!delCard)Return(r, err_card_no_find);
			if (delCard == mainCard)Return(r, err_illedge);
			if (delCard->Lock())Return(r, err_card_been_bind);
			cfgCardPtr config = delCard->getConfig();
			deleteList.push_back(delCard);
			add_exp += (delCard->toExp() + (config ? config->extraExp : 0));
			log_json.append(delCard->ID());
		}
		const int silver_cost = int(add_exp / 4);
		if (player->Res().getSilver() < silver_cost)Return(r, err_silver_not_enough);
		mainCard->addExp(add_exp);
		for (unsigned i = 0; i < deleteList.size(); ++i)
		{
			playerCardPtr delCard = deleteList[i];
			delCard->Delete();
		}
		player->Res().alterSilver(-silver_cost);
		r[strMsg][1u] = add_exp;
		Log(DBLOG::strLogPlayerCard, player, 4, mainCard->rawID(),  mainCard->ID(), add_exp, "","","","", log_json.toIndentString());
		TaskMgr::update(player, Task::CardUpFit, deleteList.size());
		Return(r, res_sucess);
	}

// 	void card_system::ladyLotterySilver(net::Msg& m, Json::Value& r)
// 	{
// 		playerDataPtr player = player_mgr.getPlayer(m.playerID);
// 		if (!player)Return(r, err_illedge);
// 		if (player->LV() < systemLimit)Return(r, err_player_lv_too_low);
// 		if (player->Card().isOver(1))Return(r, err_card_bag_over);
// 		if (player->CardTs().sLotteryTimes() > 0 && player->CardTs().sLotteryCD() < Common::gameTime())
// 		{
// 			player->CardTs().subSL();
// 			player->CardTs().setSLCD();
// 		}
// 		else
// 		{
// 			const int cost = CalSilverLotteryCost(player->CardTs().ssLotteryTimes());
// 			if (player->Res().getSilver() < cost)Return(r, err_silver_not_enough);
// 			player->Res().alterSilver(-cost);
// 			player->CardTs().tickSSLottery();
// 		}
// 		actionDo(player, LOTSilver);
// 		r[strMsg][1u] = actionRes();
// 		Log(DBLOG::strLogPlayerCard, player, 0, "", "", "", "", "", "", "", r[strMsg][1u].toIndentString());
// 		player->Daily().tickTask(DAILY::lottery_lady, 1);
// 		player->CardTs().tickTotalTimes(1);
// 		Return(r, res_sucess);
// 	}

	void card_system::ladyLotteryGold(net::Msg& m, Json::Value& r)
	{
		playerDataPtr player = player_mgr.getPlayer(m.playerID);
		if (!player)Return(r, err_illedge);
		if (player->LV() < systemLimit)Return(r, err_player_lv_too_low);
		if (player->Card().isOver(1))Return(r, err_card_bag_over);
		if (player->CardTs().gLotteryCD() < Common::gameTime())
		{
			player->CardTs().setGLCD();
		}
		else
		{
			const int cost = 98;//200һ��
			if (player->Res().getCash() < cost)Return(r, err_cash_not_enough);
			player->Res().alterCash(-cost);
		}
		actionDo(player, LOTGold);
		r[strMsg][1u] = actionRes();
		Log(DBLOG::strLogPlayerCard, player, 1, "", "", "", "", "", "", "", r[strMsg][1u].toIndentString());
		//player->Res().alterLadyCoin(1);
		int oldDiceNum = player->Res().getDice();
		player->Res().alterDice(1);
		Log(DBLOG::strLogPlayerCard, player, 8, oldDiceNum, player->Res().getDice());
		player->Daily().tickTask(DAILY::lottery_lady, 1);
		player->CardTs().tickTotalTimes(1);
		Return(r, res_sucess);
	}

	void card_system::ladyLotteryGoldH(net::Msg& m, Json::Value& r)
	{
		playerDataPtr player = player_mgr.getPlayer(m.playerID);
		if (!player)Return(r, err_illedge);
		if (player->Info().VipLv() < 4)Return(r, err_vip_lv_too_low);
		if (player->LV() < systemLimit)Return(r, err_player_lv_too_low);
		if (player->Card().isOver(1))Return(r, err_card_bag_over);
		const int cost = 288;//400һ��
		if (player->Res().getCash() < cost)Return(r, err_cash_not_enough);
		player->Res().alterCash(-cost);
		actionDo(player, LOTHighGold);
		Json::Value& res_json = (r[strMsg][1u] = actionRes());
		Log(DBLOG::strLogPlayerCard, player, 2, "", "", "", "", "", "", "", res_json.toIndentString());
		for (unsigned i = 0; i < res_json.size(); ++i)
		{
			Json::Value& sg_json = res_json[i];
			const int actionID = sg_json[0u].asInt();
			if (actionID == ACTION::lady)
			{
				const int cardID = sg_json[1u].asInt();
				cfgCardPtr config = getConfig(cardID);
				if (config && config->stars >= 5)
				{
					Json::Value send_message;
					send_message.append(chat_sys.ChatPackage(player));
					send_message.append(config->cardID);
					send_message.append(config->beginLevel);
					send_message.append(0);
					chat_sys.despatchAll(CHAT::server_lady_lottery_5stars, send_message);
				}
			}
		}
		player->Res().alterLadyCoin(3);
		player->Daily().tickTask(DAILY::lottery_lady, 1);
		player->CardTs().tickTotalTimes(1);
		Return(r, res_sucess);
	}

// 	void card_system::ladyLotterySilverM(net::Msg& m, Json::Value& r)
// 	{
// 		playerDataPtr player = player_mgr.getPlayer(m.playerID);
// 		if (!player)Return(r, err_illedge);
// 		if (player->LV() < systemLimit)Return(r, err_player_lv_too_low);
// 		if (player->Card().isOver(10))Return(r, err_card_bag_over);
// 		int cost = 800000;//8wһ��
// 		if (player->Res().getSilver() < cost)Return(r, err_silver_not_enough);
// 		player->Res().alterSilver(-cost);
// 		actionDo(player, LOTSilver, 10);
// 		r[strMsg][1u] = actionRes();
// 		Log(DBLOG::strLogPlayerCard, player, 0, "", "", "", "", "", "", "", r[strMsg][1u].toIndentString());
// 		Return(r, res_sucess);
// 	}

	void card_system::ladyLotteryGoldM(net::Msg& m, Json::Value& r)
	{
		playerDataPtr player = player_mgr.getPlayer(m.playerID);
		if (!player)Return(r, err_illedge);
		if (player->LV() < systemLimit)Return(r, err_player_lv_too_low);
		if (player->Card().isOver(10))Return(r, err_card_bag_over);
		const int cost = 928;
		if (player->Res().getCash() < cost)Return(r, err_cash_not_enough);
		player->Res().alterCash(-cost);
		if (player->CardTs().gLotteryMTimes() < 1)
		{
			actionDo(player, LOTGold, 9);
			r[strMsg][1u] = actionRes();
			actionDo(player, LOT4Gold, 1);
			r[strMsg][1u].append(actionRes()[0u]);
			player->CardTs().tickGLMT();
		}
		else
		{
			actionDo(player, LOTGold, 10);
			r[strMsg][1u] = actionRes();
		}
		Json::Value& res_json = r[strMsg][1u];
		Log(DBLOG::strLogPlayerCard, player, 1, "", "", "", "", "", "", "", res_json.toIndentString());
		//player->Res().alterLadyCoin(10);
		int oldDiceNum = player->Res().getDice();
		player->Res().alterDice(10);
		Log(DBLOG::strLogPlayerCard, player, 8, oldDiceNum, player->Res().getDice());
		player->Daily().tickTask(DAILY::lottery_lady, 10);
		player->CardTs().tickTotalTimes(10);
		Return(r, res_sucess);
	}

	void card_system::ladyLotteryGoldHM(net::Msg& m, Json::Value& r)
	{
		playerDataPtr player = player_mgr.getPlayer(m.playerID);
		if (!player)Return(r, err_illedge);
		if (player->Info().VipLv() < 4)Return(r, err_vip_lv_too_low);
		if (player->LV() < systemLimit)Return(r, err_player_lv_too_low);
		if (player->Card().isOver(10))Return(r, err_card_bag_over);
		const int cost = 2688;
		if (player->Res().getCash() < cost)Return(r, err_cash_not_enough);
		player->Res().alterCash(-cost);
		if (player->CardTs().gLotteryHMTimes() < 1)
		{
			actionDo(player, LOTHighGold, 9);
			r[strMsg][1u] = actionRes();
			actionDo(player, LOTHigh5Gold, 1);
			r[strMsg][1u].append(actionRes()[0u]);
			player->CardTs().tickGLHMT();
		}
		else
		{
			actionDo(player, LOTHighGold, 10);
			r[strMsg][1u] = actionRes();
		}
		Json::Value& res_json = r[strMsg][1u];
		Log(DBLOG::strLogPlayerCard, player, 2, "", "", "", "", "", "", "", r[strMsg][1u].toIndentString());
		for (unsigned i = 0; i < res_json.size(); ++i)
		{
			Json::Value& sg_json = res_json[i];
			const int actionID = sg_json[0u].asInt();
			if (actionID == ACTION::lady)
			{
				const int cardID = sg_json[1u].asInt();
				cfgCardPtr config = getConfig(cardID);
				if (config && config->stars >= 5)
				{
					Json::Value send_message;
					send_message.append(chat_sys.ChatPackage(player));
					send_message.append(config->cardID);
					send_message.append(config->beginLevel);
					send_message.append(0);
					chat_sys.despatchAll(CHAT::server_lady_lottery_5stars, send_message);
				}
			}
		}
		player->Res().alterLadyCoin(30);
		player->Daily().tickTask(DAILY::lottery_lady, 10);
		player->CardTs().tickTotalTimes(10);
		Return(r, res_sucess);
	}

	void card_system::ladyPokeReq(net::Msg& m, Json::Value& r)
	{
		playerDataPtr player = player_mgr.getPlayer(m.playerID);
		if (!player)Return(r, err_illedge);
		player->Poke()._auto_update();
	}

	void card_system::ladyBindReq(net::Msg& m, Json::Value& r)
	{
		playerDataPtr player = player_mgr.getPlayer(m.playerID);
		if (!player)Return(r, err_illedge);
		ReadJsonArray;
		playerCardPtr card = player->Card().getCard(js_msg[0u].asInt());
		const bool bind_type = js_msg[1u].asBool();
		if (!card)Return(r, err_card_no_find);
		//if (card->Bind())Return(r, res_sucess);
		card->setBind(bind_type);
		Return(r, res_sucess);
	}

	void card_system::ladyDismissReq(net::Msg& m, Json::Value& r)
	{
		playerDataPtr player = player_mgr.getPlayer(m.playerID);
		if (!player)Return(r, err_illedge);
		ReadJsonArray;
		const int cardID = js_msg[0u].asInt();
		playerCardPtr card = player->Card().getCard(cardID);
		if (!card)Return(r, err_card_no_find);
		if (card->Lock())Return(r, err_card_been_bind);
		cfgCardPtr config = card->getConfig();
		const int won_silver = config->silver + card->toExp();
		const int won_coin = config->coin;
		Log(DBLOG::strLogPlayerCard, player, 7, won_silver, won_coin, cardID, card->LV());
		card->Delete();
		player->Res().alterSilver(won_silver);
		player->Res().alterLadyCoin(won_coin);
		r[strMsg][1u] = won_silver;
		r[strMsg][2u] = won_coin;
		Return(r, res_sucess);
	}

	void card_system::ladyCMB4Req(net::Msg& m, Json::Value& r)
	{
		playerDataPtr player = player_mgr.getPlayer(m.playerID);
		if (!player)Return(r, err_illedge);
		if (player->LV() < systemLimit)Return(r, err_player_lv_too_low);
		if (player->Card().isOver(1))Return(r, err_card_bag_over);
		int cost = 100;//10һ��
		if (player->Res().getLadyCoin() < cost)Return(r, err_lady_coin_not_enough);
		player->Res().alterLadyCoin(-cost);
		actionDo(player, CMBFour);
		r[strMsg][1u] = actionRes();
		Log(DBLOG::strLogPlayerCard, player, 6, cost, "", "", "", "", "", "", r[strMsg][1u].toIndentString());
		Return(r, res_sucess);
	}

	void card_system::ladyCMB5Req(net::Msg& m, Json::Value& r)
	{
		playerDataPtr player = player_mgr.getPlayer(m.playerID);
		if (!player)Return(r, err_illedge);
		if (player->LV() < systemLimit)Return(r, err_player_lv_too_low);
		if (player->Card().isOver(1))Return(r, err_card_bag_over);
		int cost = 400;//10һ��
		if (player->Res().getLadyCoin() < cost)Return(r, err_lady_coin_not_enough);
		player->Res().alterLadyCoin(-cost);
		actionDo(player, CMBFive);
		r[strMsg][1u] = actionRes();
		Json::Value& res_json = r[strMsg][1u];
		Log(DBLOG::strLogPlayerCard, player, 6, cost, "", "", "", "", "", "", res_json.toIndentString());
		for (unsigned i = 0; i < res_json.size(); ++i)
		{
			Json::Value& sg_json = res_json[i];
			const int actionID = sg_json[0u].asInt();
			if (actionID == ACTION::lady)
			{
				const int cardID = sg_json[1u].asInt();
				cfgCardPtr config = getConfig(cardID);
				if (config && config->stars >= 5)
				{
					Json::Value send_message;
					send_message.append(chat_sys.ChatPackage(player));
					send_message.append(config->cardID);
					send_message.append(config->beginLevel);
					send_message.append(0);
					chat_sys.despatchAll(CHAT::server_lady_combine_5stars, send_message);
				}
			}
		}
		Return(r, res_sucess);
	}

	void card_system::ShowLady(net::Msg& m, Json::Value& r)
	{
		playerDataPtr player = player_mgr.getPlayer(m.playerID);
		if (!player)Return(r, err_illedge);
		ReadJsonArray;
		const int cardID = js_msg[0u].asInt();
		const unsigned channel = js_msg[1u].asUInt();
		const string playerName = js_msg[2u].asString();
		if (channel >= CHAT::user_channel)Return(r, err_illedge);
		playerCardPtr card = player->Card().getCard(cardID);
		if (!card)Return(r, err_card_no_find);
		unsigned now = Common::gameTime();
		if (player->CardTs().ShowCardCD > now)Return(r, err_card_show_cd);
		qValue data_json(qJson::qj_array);
		data_json.append(chat_sys.ChatPackageQ(player)).
			append(cardID).append(card->LV()).append(card->EXP());
		if (channel == CHAT::chat_all)
		{
			chat_sys.despatchAll(CHAT::server_show_lady, data_json);
		}
		else if (channel == CHAT::chat_kingdom)
		{
			if (!chat_sys.despatchKingdom(CHAT::server_show_lady, player->Info().Nation(), data_json))
			{
				Return(r, err_no_join_kingdom);
			}
		}
		else
		{
			if (!chat_sys.despatchPlayer(CHAT::server_show_lady, playerName, data_json))
			{
				Return(r, err_chat_aim_not_find);
			}
		}
		player->CardTs().ShowCardCD = now + 60;//60s
		player->CardTs()._sign_update();
		Return(r, res_sucess);
	}

	void card_system::ShowLadyInvest(net::Msg& m, Json::Value& r)
	{
		playerDataPtr player = player_mgr.getPlayer(m.playerID);
		if (!player)Return(r, err_illedge);
		ReadJsonArray;
		const unsigned channel = js_msg[0u].asUInt();
		const string playerName = js_msg[1u].asString();
		if (channel >= CHAT::user_channel)Return(r, err_illedge);
		unsigned now = Common::gameTime();
		if (player->CardTs().ShowCardCD > now)Return(r, err_card_show_cd);
		qValue data_json(qJson::qj_array);
		data_json.append(chat_sys.ChatPackageQ(player)).append(player->Card().investPackage());
		if (channel == CHAT::chat_all)
		{
			chat_sys.despatchAll(CHAT::server_show_lady_invest, data_json);
		}
		else if (channel == CHAT::chat_kingdom)
		{
			if (!chat_sys.despatchKingdom(CHAT::server_show_lady_invest, player->Info().Nation(), data_json))
			{
				Return(r, err_no_join_kingdom);
			}
		}
		else
		{
			if (!chat_sys.despatchPlayer(CHAT::server_show_lady_invest, playerName, data_json))
			{
				Return(r, err_chat_aim_not_find);
			}
		}
		player->CardTs().ShowCardCD = now + 60;//60s
		player->CardTs()._sign_update();
		Return(r, res_sucess);
	}
}

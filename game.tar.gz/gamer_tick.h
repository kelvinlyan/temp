//###################################
//create by Jim
//2015-11-10
//###################################

#pragma once

#include "auto_do.h"

namespace gg
{
	class playerTick :
		public _auto_player
	{
	public:
		playerTick(playerData* const own);
		~playerTick(){}
		void loginTick();
		void tick5Event(const bool is_timer = true);
		void tick8Event(const bool is_timer = true);
		void tick18Event(const bool is_timer = true);
		void tick22Event(const bool is_timer = true);
		virtual void _auto_update();

		inline unsigned stander5(){ return tick5C; }
		inline unsigned stander8(){ return tick8C; }
		inline unsigned stander18(){ return tick18C; }
		inline unsigned stander22(){ return tick22C; }
		
		virtual void classLoad();
	private:
		//�����¼�
		void on5ClockTick(const bool is_timer, const unsigned per_timer, const bool is_login = false);
		void on8ClockTick(const bool is_timer, const unsigned per_timer, const bool is_login = false);
		void on18ClockTick(const bool is_timer, const unsigned per_timer, const bool is_login = false);
		void on22ClockTick(const bool is_timer, const unsigned per_timer, const bool is_login = false);

		virtual bool _auto_save();
		unsigned tick5C;//5��
		unsigned tick8C;//8��
		unsigned tick18C;//18��
		unsigned tick22C;//22

	};
}

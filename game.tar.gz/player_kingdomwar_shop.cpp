#include "player_kingdomwar_shop.h"
#include "kingdomwar_shop.h"
#include "kingdomwar_def.h"
#include "kingdomwar_data.h"

namespace gg
{
	namespace KingdomWar
	{
		class ShadowCD
		{
			SINGLETON(ShadowCD);
			public:
				unsigned cd(int type, int lv) const
				{
					if (type == SHADOW::DEFENSE_NPC)
						--type;
					if (lv > _cd[type].size())
						lv = _cd[type].size();
					return _cd[type][lv - 1];
				}
				unsigned limit(int type, int lv) const
				{
					if (type == SHADOW::DEFENSE_NPC)
						--type;
					if (lv > _limit[type].size())
						lv = _limit[type].size();
					return _limit[type][lv - 1];
				}

			private:
				void loadFile();
			private:
				STDVECTOR(unsigned, Vec);
				std::vector<Vec> _cd;
				std::vector<Vec> _limit;
		};

		ShadowCD::ShadowCD()
		{
			loadFile();
		}

		void ShadowCD::loadFile()
		{
			const Json::Value json = Common::loadJsonFile("./instance/kingdom_war/shadow_cd.json");
			ForEachC(Json::Value, it, json)
			{
				Vec c, l;
				const Json::Value& cd = (*it)["cd"];
				ForEachC(Json::Value, itc, cd)
					c.push_back((*itc).asUInt());
				const Json::Value& limit = (*it)["limit"];
				ForEachC(Json::Value, itl, limit)
					l.push_back((*itl).asUInt());
				_cd.push_back(c);
				_limit.push_back(l);
			}
		}
	}

	playerKingdomWarShop::playerKingdomWarShop(playerData* const own)
		: _auto_player(own), _used_exploit(0), _channel_cd(0)
	{
		_call_shadow_times.assign(KingdomWar::SHADOW::TYPEMAX, 0);
		_call_shadow_cd.assign(KingdomWar::SHADOW::TYPEMAX, 0);
		_in_shadow_cd.assign(KingdomWar::SHADOW::TYPEMAX, 0);
	}

	void playerKingdomWarShop::classLoad()
	{
		mongo::BSONObj key = BSON(strPlayerID << Own().ID());
		mongo::BSONObj obj = db_mgr.FindOne(DBN::dbPlayerKingdomWarShop, key);
		
		if (obj.isEmpty()) 
			return;

		checkNotEoo(obj["ep"])
			_used_exploit = obj["ep"].Int();
		checkNotEoo(obj["cst"])
		{
			std::vector<mongo::BSONElement> ele = obj["cst"].Array();
			for (unsigned i = 0; i < ele.size(); ++i)
				_call_shadow_times[i] = ele[i].Int();
		}
		checkNotEoo(obj["cscd"])
		{
			std::vector<mongo::BSONElement> ele = obj["cscd"].Array();
			for (unsigned i = 0; i < ele.size(); ++i)
				_call_shadow_cd[i] = ele[i].Int();
		}
		checkNotEoo(obj["isc"])
		{
			std::vector<mongo::BSONElement> ele = obj["isc"].Array();
			for (unsigned i = 0; i < ele.size(); ++i)
				_in_shadow_cd[i] = ele[i].Int();
		}
		checkNotEoo(obj["ccd"])
			_channel_cd = obj["ccd"].Int();
	}

	bool playerKingdomWarShop::_auto_save()
	{
		mongo::BSONObj key = BSON(strPlayerID << Own().ID());
		mongo::BSONObjBuilder obj;
		obj << strPlayerID << Own().ID() << "ep" << _used_exploit
			<< "ccd" << _channel_cd;
		{
			mongo::BSONArrayBuilder b;
			ForEachC(std::vector<unsigned>, it, _call_shadow_times)
				b.append(*it);
			obj << "cst" << b.arr();
		}
		{
			mongo::BSONArrayBuilder b;
			ForEachC(std::vector<unsigned>, it, _call_shadow_cd)
				b.append(*it);
			obj << "cscd" << b.arr();
		}
		{
			mongo::BSONArrayBuilder b;
			ForEachC(std::vector<int>, it, _in_shadow_cd)
				b.append(*it);
			obj << "isc" << b.arr();
		}
		return db_mgr.SaveMongo(DBN::dbPlayerKingdomWarShop, key, obj.obj());
	}

	void playerKingdomWarShop::_auto_update()
	{
	}

	void playerKingdomWarShop::dailyTick()
	{
		for (unsigned i = 0; i < _call_shadow_times.size(); ++i)
			_call_shadow_times[i] = 0;
		_sign_save();
	}

	void playerKingdomWarShop::alterUsedExploit(int num)
	{
		int cur = Own().Res().getExploit();
		if (cur < num)
			num = cur;
		_used_exploit += num;
		_sign_save();
	}

	void playerKingdomWarShop::channelSend()
	{
		_channel_cd = Common::gameTime() + 10;
		Own().KingDomWar().updateParam();
		_sign_save();
	}

	void playerKingdomWarShop::alterShadowTimes(int type)
	{
		++_call_shadow_times[type];
		unsigned cur_time = Common::gameTime();
		if (type != KingdomWar::SHADOW::ADVANCED_NPC)
		{
			int add_cd = KingdomWar::ShadowCD::shared().cd(type, Own().LV());
			int limit_cd = KingdomWar::ShadowCD::shared().limit(type, Own().LV());

			if (_call_shadow_cd[type] < cur_time)
				_call_shadow_cd[type] = cur_time + add_cd;
			else
				_call_shadow_cd[type] += add_cd;

			if (_call_shadow_cd[type] - cur_time >= limit_cd)
				_in_shadow_cd[type] = 1;
			else
				_in_shadow_cd[type] = 0;
		}

		updateShadowInfo();
		_sign_save();
	}

	bool playerKingdomWarShop::inShadowCd(int type) const
	{
		return (Common::gameTime() < _call_shadow_times[type] 
			&& _in_shadow_cd[type] == 1);
	}

	void playerKingdomWarShop::updateShadowInfo()
	{
		qValue m;
		m.append(res_sucess);
		qValue sl;
		for (unsigned i = 0; i < _call_shadow_times.size(); ++i)
		{
			qValue tmp(qJson::qj_object);
			unsigned max_times = KingdomWar::ShadowCost::shared().maxTimes(i, (i == KingdomWar::SHADOW::NPC || i == KingdomWar::SHADOW::DEFENSE_NPC)? Own().LV() : Own().Info().VipLv());
			if (max_times < _call_shadow_times[i])
				tmp.addMember("t", 0);
			else
				tmp.addMember("t", max_times - _call_shadow_times[i]);
			tmp.addMember("m", max_times);
			tmp.addMember("cd", _call_shadow_cd[i]);
			tmp.addMember("cdf", _in_shadow_cd[i]);
			const KingdomWar::nShadow::Cost& cost = KingdomWar::ShadowCost::shared().get(i, Own().getOwnDataPtr(), _call_shadow_times[i]);
			qValue c;
			c << cost.gold << cost.food;
			tmp.addMember("c", c);
			sl.append(tmp);
		}
		qValue q(qJson::qj_object);
		q.addMember("s", sl);
		m.append(q);
		Own().sendToClientFillMsg(gate_client::kingdom_war_shadow_info_resp, m);
	}
}

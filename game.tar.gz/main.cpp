#include "game_server.h"
#include "core_helper.h"
#include "mineHeader.h"
#include "commom.h"
#include "playerManager.h"
#include <stdlib.h>
#include <signal.h>


void ProcessEnd(const string err_str)
{
	LogS << "the last event : " << State::getState() << LogEnd;
	cout << "final info " << err_str << endl;
	game_svr->stop();

	//ȡ�������߳�
	//��ʹ�����߳�, �������ݸ���
	player_mgr.gameOver();
	LogS << color_pink("game process will over soon...") << LogEnd;
	exit(0);
}

void KillSignalHandler(int signal)
{
	ProcessEnd("kill process signal ...");
}

using namespace gg;

void threadOK(const int id)
{
	LogS << id << " is ok ..." << LogEnd;
}

int main(int argc, char* argv[])
{
	cout << "net msg base" << sizeof(net::MsgBase) << endl;
	cout << "net msg" << sizeof(net::Msg) << endl;

	signal(SIGINT, KillSignalHandler);
	signal(SIGTERM, KillSignalHandler);

#if defined(_WIN32) || defined(_WIN64)
	signal(SIGBREAK, KillSignalHandler);
#endif

	game_logger.readConfig("./server/game_cfg.json");
	game_logger.printConfig();
	game_svr->initial();
	while(true)
	{
		std::string input_str;
		getline(std::cin,input_str);
		if(input_str=="q")
			break;
		else if (input_str == "cthread")
		{
			getline(std::cin, input_str);
			try
			{
				int id = boost::lexical_cast<int>(input_str);
				if (id < 0 || id >= gg::DangerIO::gg_count)continue;
				IOMgr.otherIO(id).post(boost::bind(threadOK, id));
			}
			catch (boost::bad_lexical_cast& e)
			{
				LogE << e.what() << LogEnd << input_str << " is not a vaild thread ID ..." << LogEnd;
			}
		}
		else
		{
			LogW << color_red(input_str) << " is not a correct commands." << LogEnd;
		}
	}
	ProcessEnd("main close...");
	return 0;
}

#include "playerData.h"
#include "playerManager.h"
#include "service_config.h"

namespace gg
{
	playerData::playerData(const int pID, const unsigned dataState)
	{
		_Info = Creator<playerBase>::Create(this, pID);
		initial(dataState);
	}

	playerData::playerData(const string pName, const unsigned dataState)
	{
		_Info = Creator<playerBase>::Create(this, pName);
		initial(dataState);
	}
	
#define CreatePlayerClass(ClassType, VarName, StateValue) \
{\
_##VarName = Creator<ClassType>::Create(this);\
_##VarName->setClassState(StateValue);\
}


#define CreatePlayerClassM(ClassType, VarName, StateValue, ...) \
{\
_##VarName = Creator<ClassType>::Create(this, __VA_ARGS__);\
_##VarName->setClassState(StateValue);\
}


	void playerData::initial(const unsigned dataState)
	{
		//����ʵ��
		_Info->toLoad();
		_Info->setClassState(dataState);

		CreatePlayerClass(playerTick, Tick, dataState);
		CreatePlayerClass(playerManMgr, Man, dataState);
		CreatePlayerClass(playerResource, Res, dataState);
		CreatePlayerClass(playerMapWarMgr, War, dataState);//
		CreatePlayerClass(playerTask, Task, dataState);//
		CreatePlayerClass(playerWarFM, WarFM, dataState);
		CreatePlayerClass(playerCardMgr, Card, dataState);
		CreatePlayerClass(playerCardTs, CardTs, dataState);
		CreatePlayerClass(playerItemMgr, Items, dataState);
		CreatePlayerClass(playerSearch, Sch, dataState);
		CreatePlayerClass(playerFace, Face, dataState);
		CreatePlayerClass(playerPoke, Poke, dataState);
		CreatePlayerClass(playerCount, Count, dataState);
		CreatePlayerClass(playerCarPos, CarPos, dataState);
		CreatePlayerClass(playerTrade, Trade, dataState);//ó��
		CreatePlayerClass(playerKingFight, KingFight, dataState);//
		CreatePlayerClass(playerKingdom, KingDom, dataState);//
		CreatePlayerClass(playerRescue, RescueData, dataState);
		CreatePlayerClass(playerTeam, Team, dataState);//
		CreatePlayerClass(playerVipMgr, Vip, dataState);//
		CreatePlayerClass(playerWorldBoss, WorldBoss, dataState);//
		CreatePlayerClass(playerWarLords, WarLords, dataState);//
		CreatePlayerClass(playerResearch, Research, dataState);
		CreatePlayerClass(playerMarket, Market, dataState);
		CreatePlayerClass(playerOrders, Orders, dataState);
		CreatePlayerClass(playerMall, Malls, dataState);
		CreatePlayerClass(playerEmail, Email, dataState);
		CreatePlayerClass(playerDaily, Daily, dataState);
		CreatePlayerClass(playerBuildTeam, BuildTeam, dataState);
		CreatePlayerClass(playerBuilds, Builds, dataState);
		CreatePlayerClass(playerAdmin, Admin, dataState);
		CreatePlayerClass(playerOffline, Offline, dataState);
		CreatePlayerClass(playerCustom, Custom, dataState);
		CreatePlayerClass(playerDaysActivity, DaysActivity, dataState);
		CreatePlayerClass(playerOnlineBox, OnlineBox, dataState);
		CreatePlayerClass(playerAffair, Affair, dataState);
		CreatePlayerClass(playerSign, Sign, dataState);
		CreatePlayerClass(playerMoneyActivity, MoneyActivity, dataState);
		CreatePlayerClass(playerDailyCard, DailyCard, dataState);
		CreatePlayerClass(playerFund, Fund, dataState);
		CreatePlayerClass(playerKingdomWar, KingDomWar, dataState);
		CreatePlayerClass(playerKingdomWarShop, KingDomWarShop, dataState);
		CreatePlayerClass(playerKingdomWarOutput, KingDomWarOutput, dataState);
		CreatePlayerClass(playerKingdomWarFM, KingDomWarFM, dataState);
		CreatePlayerClass(playerKingdomWarPos, KingDomWarPos, dataState);
		CreatePlayerClass(playerKingdomWarBox, KingDomWarBox, dataState);
		CreatePlayerClass(playerKingdomWarTask, KingDomWarTask, dataState);
		CreatePlayerClass(playerPatrol1, Patrol, dataState);
		CreatePlayerClass(playerOpenActivity, OpenActivity, dataState);

		
		//���ݳ�ʼ��
		memset(Chat, 0x0, sizeof(Chat));
		Online = false;
		TeamCD = 0;
		BusinessCD = 0;
		EquipShowCD = 0;
		ShareLastCD = 0;
		TeamAnnCD = 0;
		CarMoveCD = boost::get_system_time();
		Dirty = false;
	}

	void playerData::clearData()
	{
		if (Dirty)
		{
			Tick().loginTick();
			Dirty = false;
		}
	}

	playerData::~playerData()
	{
//		cout << "~playerData call" << endl;
	}

	void playerData::Login()
	{
		if (!isOnline())
		{
			Online = true;
			onLogin();
		}
	}

	void playerData::Logout()
	{
		if (isOnline())
		{
			Online = false;
			onOFFLine();
		}
	}

	void playerData::sendToClient(const short protocol, Json::Value& msg)
	{
		if (!isOnline())return;
		string str = msg.toIndentString();
		net::Msg mj(ID(), service::process_id::INVAILD_PLAYER_ID, protocol, str);
		player_mgr.sendToPlayer(mj);
	}

	void playerData::sendToClient(const short protocol, qValue& msg)
	{
		if (!isOnline())return;
		string str = msg.toIndentString();
		net::Msg mj(ID(), service::process_id::INVAILD_PLAYER_ID, protocol, str);
		player_mgr.sendToPlayer(mj);
	}

	void playerData::sendToClientFillMsg(const short protocol, qValue& msg)
	{
		if (!isOnline())return;
		qValue cmMsg(qJson::qj_object);
		cmMsg.addMember(strMsg, msg);
		string str = cmMsg.toIndentString();
		net::Msg mj(ID(), service::process_id::INVAILD_PLAYER_ID, protocol, str);
		player_mgr.sendToPlayer(mj);
	}

	void playerData::sendToClient(const short protocol, string& msg)
	{
		if (!isOnline())return;
		net::Msg mj(ID(), service::process_id::INVAILD_PLAYER_ID, protocol, msg);
		player_mgr.sendToPlayer(mj);
	}

	void playerData::sendToClientFillMsg(const short protocol, string& msg)
	{
		if (!isOnline())return;
		string str = "{\"msg\":[" + msg + "]";
		net::Msg mj(ID(), service::process_id::INVAILD_PLAYER_ID, protocol, str);
		player_mgr.sendToPlayer(mj);
	}


// 	bool playerData::outLine()
// 	{
// 		if (isOnline())return false;
// 		unsigned now = Common::gameTime();
// 		if (now < OFFTime || now - OFFTime > 7200)return true;
// 		return false;
// 	}

	bool playerData::isVaild()
	{
		return (ID() > 0 && Name().size() > 0);
	}
}

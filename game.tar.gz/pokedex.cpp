#include "pokedex.h"
#include "card_system.h"

namespace gg
{
	playerPoke::playerPoke(playerData* const own) : _auto_player(own)
	{
		pokeData.resize(card_sys.totalCard(), '0');
	}

	void playerPoke::classLoad()
	{
		mongo::BSONObj key = BSON(strPlayerID << Own().ID());
		mongo::BSONObj obj = db_mgr.FindOne(DBN::dbPlayerCardPoke, key);
		if (obj.isEmpty())return;
		std::string db_data = obj["pk"].String();
		if (pokeData.size() > db_data.size())
		{
			memmove((void*)pokeData.c_str(), db_data.c_str(), db_data.size());
		}
		else
		{
			pokeData = db_data;
		}
		for (unsigned i = 0; i < pokeData.size(); ++i)
		{
			if (pokeData[i] == '1')
			{
				cfgCardPtr config = card_sys.getConfigByOrder(i);
				if (config)
				{
					Own().Face().insertFace(config->faceID);
				}
			}
		}
	}

	void playerPoke::signPoke(const int pokeID)
	{
		cfgCardPtr config = card_sys.getConfig(pokeID);
		if (config && config->orderID < pokeData.size())
		{
			pokeData[config->orderID] = '1';
			Own().Face().insertFace(config->faceID);
			_sign_auto();
		}
	}

	void playerPoke::removePoke(const int pokeID)
	{
		cfgCardPtr config = card_sys.getConfig(pokeID);
		if (config && config->orderID < pokeData.size())
		{
			pokeData[config->orderID] = '0';
			Own().Face().removeFace(config->faceID);
			_sign_auto();
		}
	}

	void playerPoke::_auto_update()
	{
		Json::Value json;
		json[strMsg][0u] = res_sucess;
		Json::Value& resJson = json[strMsg][1u];
		resJson = pokeData;
		Own().sendToClient(gate_client::player_card_poke_update_resp, json);
	}

	bool playerPoke::_auto_save()
	{
		mongo::BSONObj key = BSON(strPlayerID << Own().ID());
		mongo::BSONObj obj = BSON(strPlayerID << Own().ID() << "pk" <<
			pokeData);
		return db_mgr.SaveMongo(DBN::dbPlayerCardPoke, key, obj);
	}
}
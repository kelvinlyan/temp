//###################################
//create by Jim
//2015-11-16
//###################################

#pragma once

#include "quickjson.h"
#include "commom.h"
#include "battle_def.h"
#include "skill_def.h"

namespace gg
{
	const static std::string strRpDirRoot = "./report/";
	namespace typeBattle
	{
		enum TYPE
		{
			war_story,//ս��
			crown_fight,//�����������ᴢ��
			trade_pirate,//ó�״򺣵�
			hero_party,//ȺӢ��
			world_boss,//����BOSS
			warlords,//Ⱥ������
			kingdomwar,
			trade_shark,//ó�״�����ˮ��
			expedition,
			festival_npc,

			team_battle = 1000,
			team_war_story = 1001,//���ս �ַ�����

			child_battle = -1,
		};
	}

	namespace resBattle
	{
		enum RES
		{
			atk_win,
			def_win,
			res_unknown,//���ط�ʵ����Ϊ��
		};
	}

	struct O2ORes
	{
		O2ORes()
		{
			res = resBattle::def_win;
			star = 0;
		}
		O2ORes(const resBattle::RES r, const int s)
		{
			res = r;
			star = s;
		}
		resBattle::RES res;//ս�����
		int star;//�Ǽ�
	};

	namespace runBattle
	{
		enum RUN // << 0 -> << 9
		{
			hp_recovery = (0x0001 << 0),//ս��������ָ�hp
		};
	}

	namespace BattleData
	{
		class unit;
		BOOSTSHAREPTR(unit, unitPtr);
		class environment;
		BOOSTSHAREPTR(environment, envPtr);
		typedef vector<envPtr> EnvSeq;
	}

	class battleLogic;
	class BattleReport
	{
		friend class battleLogic;
	public:
		O2ORes One2One(sBattlePtr atk, sBattlePtr def, typeBattle::TYPE type, const unsigned runType = 0);//0����ʤ�� �����ط�ʤ��
		resBattle::RES Group2Group(teamSideBattle atk, teamSideBattle def, typeBattle::TYPE type, const unsigned step = 3, const unsigned runType = 0);//0����ʤ�� �����ط�ʤ��
	public://������������
		BattleReport();
		~BattleReport(){}
		BattleReport& addNotice(const int playerID);//����������
		BattleReport& addCopyField(const string toPath);//���ӱ�ѡ�ļ���ַ
	public://���Ե�ս������
		inline vector<ManDamage> getDamageList() { return DamageResList; }
		inline unsigned getLastRound() { return LastRound; }
		void addReportdeclare(const string key, const int val);
		void addReportdeclare(const string key, const double val);
		void addReportdeclare(const string key, const unsigned val);
		void addReportdeclare(const string key, const string str);
		void addReportdeclare(const string key, Json::Value& json);
		void addReportdeclare(const string key, qValue& json);
		void Done(const typeBattle::TYPE type, Json::Value extra = Json::objectValue);
	public://��Զ�ս������
		void addReportdeclareT(const string key, const int val);
		void addReportdeclareT(const string key, const double val);
		void addReportdeclareT(const string key, const unsigned val);
		void addReportdeclareT(const string key, const string str);
		void addReportdeclareT(const string key, Json::Value& json);
		void addReportdeclareT(const string key, qValue& json);
		void DoneT(const typeBattle::TYPE type, Json::Value extra = Json::objectValue);
	private://����//ָ����һ�����ܻ���//Ϊ�˼���Ƕ��
		BattleData::EnvSeq seqENV_;//��ǰ�����ڵ�
		BattleData::envPtr PushEnv(BattleData::envPtr env);
		void jDoneAndClear(qValue& reportDelare);
		void ClearActionEnv();
	private:
		//���ò���
		STDSET(string, STRSET);
		STRSET dirList;
		STDSET(int, SENDSET);
		SENDSET noticeList;
		//��Զ�غ�����Ч
		qValue reportTeam;//���ս���ڵ�
		//���Ե��غ�����Ч
		qValue reportRoot;//���ڵ�
		unsigned LastRound;//�����Ե��غ�����Ч
		vector<ManDamage> DamageResList;//ÿ�غ�˫���佫�˺�����
		//initials
		void resetT2TReport();
		void resetO2OReport();//����ȫ�ֱ���
	};

	class battleLogic
	{
		friend class BattleReport;
	public:
		~battleLogic(){}
		static void initData();

	private:
		//����ս�����Բ��ô���runType  Ĭ��ֵ����
		battleLogic(BattleReport& data) : reportData(data){}
		resBattle::RES Group2Group(teamSideBattle atk, teamSideBattle def, typeBattle::TYPE type, const unsigned step = 3, const unsigned runType = 0);//0����ʤ�� �����ط�ʤ��
		O2ORes One2One(sBattlePtr atk, sBattlePtr def, typeBattle::TYPE type, const unsigned runType = 0);//0����ʤ�� �����ط�ʤ��
		BattleReport& reportData;
	private:
		typedef boost::function<void(sBattlePtr, sBattlePtr)> dealPerFunc;
		typedef boost::unordered_map<int, dealPerFunc> perDealMap;
		static perDealMap mapPerDeal;//ÿһ��ս��
		static void per_hp_recovery(sBattlePtr atk, sBattlePtr def);
	private://������ѵ
		bool begin_attack(sBattlePtr atk, sBattlePtr def, const unsigned round);
		void on_attack(sBattlePtr atk, sBattlePtr def, const unsigned round, const bool ac, mBattlePtr sign_aim = mBattlePtr());//���������￪ʼ
		void on_detail_attack(BattleData::envPtr env, const SKILL::skillEntity& entity, 
			mBattlePtr sign_aim = mBattlePtr(), const bool is_main = false);//�Ӽ��ܴ����￪ʼ
		void run_attack(BattleData::envPtr env, BattleData::unitPtr uni, const SKILL::skillEntity::entityList& declare);
		void run_attack_no_aim(BattleData::envPtr env, BattleData::unitPtr uni, const SKILL::skillEntity::entityList& declare);
		void end_attack(BattleData::envPtr env);
	private://ѡ��Ŀ��

		//big big
		static void find_aim(battleLogic* logic, BattleData::envPtr env, BattleData::unitPtr uni, const AIM::structAIM& declare, mBattlePtr sign_aim = mBattlePtr());
		typedef boost::function<void(battleLogic*, BattleData::envPtr, BattleData::unitPtr, const AIM::structAIM&)> FindAimF;
		typedef boost::unordered_map<int, FindAimF> aimDealMap;
		
		//new new
		static void find_aim_new(battleLogic* logic, BattleData::envPtr env, BattleData::unitPtr uni, const AIM::structAIM& declare);//�����ƶ�Ŀ��
		static aimDealMap newAimDeal;
		static void aim_follow_new(battleLogic* logic, BattleData::envPtr ptr, BattleData::unitPtr uni, const AIM::structAIM& declare);
		static void aim_single_new(battleLogic* logic, BattleData::envPtr ptr, BattleData::unitPtr uni, const AIM::structAIM& declare);
		static void aim_line_new(battleLogic* logic, BattleData::envPtr ptr, BattleData::unitPtr uni, const AIM::structAIM& declare);
		static void aim_row_new(battleLogic* logic, BattleData::envPtr ptr, BattleData::unitPtr uni, const AIM::structAIM& declare);
		static void aim_cross_new(battleLogic* logic, BattleData::envPtr ptr, BattleData::unitPtr uni, const AIM::structAIM& declare);
		static void aim_random_new(battleLogic* logic, BattleData::envPtr ptr, BattleData::unitPtr uni, const AIM::structAIM& declare);
		static void aim_current_new(battleLogic* logic, BattleData::envPtr ptr, BattleData::unitPtr uni, const AIM::structAIM& declare);
		static void aim_other_new(battleLogic* logic, BattleData::envPtr ptr, BattleData::unitPtr uni, const AIM::structAIM& declare);
		static void aim_all_new(battleLogic* logic, BattleData::envPtr ptr, BattleData::unitPtr uni, const AIM::structAIM& declare);

		//sign sign
		static void find_aim_sign(battleLogic* logic, BattleData::envPtr env, BattleData::unitPtr uni, const AIM::structAIM& declare);//����Ŀ��
		static aimDealMap signAimDeal;
		static void aim_follow_sign(battleLogic* logic, BattleData::envPtr ptr, BattleData::unitPtr uni, const AIM::structAIM& declare);
		static void aim_single_sign(battleLogic* logic, BattleData::envPtr ptr, BattleData::unitPtr uni, const AIM::structAIM& declare);
		static void aim_line_sign(battleLogic* logic, BattleData::envPtr ptr, BattleData::unitPtr uni, const AIM::structAIM& declare);
		static void aim_row_sign(battleLogic* logic, BattleData::envPtr ptr, BattleData::unitPtr uni, const AIM::structAIM& declare);
		static void aim_cross_sign(battleLogic* logic, BattleData::envPtr ptr, BattleData::unitPtr uni, const AIM::structAIM& declare);
		static void aim_random_sign(battleLogic* logic, BattleData::envPtr ptr, BattleData::unitPtr uni, const AIM::structAIM& declare);
		static void aim_current_sign(battleLogic* logic, BattleData::envPtr ptr, BattleData::unitPtr uni, const AIM::structAIM& declare);
		static void aim_other_sign(battleLogic* logic, BattleData::envPtr ptr, BattleData::unitPtr uni, const AIM::structAIM& declare);
		static void aim_all_sign(battleLogic* logic, BattleData::envPtr ptr, BattleData::unitPtr uni, const AIM::structAIM& declare);

	private://����Ч��
		typedef boost::function<void(battleLogic*, BattleData::envPtr, BattleData::unitPtr, const SKILL::declare&)> RunDeclareF;
		typedef boost::unordered_map<int, RunDeclareF> SkillDealMap;
		static SkillDealMap SkillDeal;
		static void phy_attack(battleLogic* logic, BattleData::envPtr ptr, BattleData::unitPtr uni, const SKILL::declare& declare);
		static void war_attack(battleLogic* logic, BattleData::envPtr ptr, BattleData::unitPtr uni, const SKILL::declare& declare);
		static void rage_attack(battleLogic* logic, BattleData::envPtr ptr, BattleData::unitPtr uni, const SKILL::declare& declare);
		static void magic_attack(battleLogic* logic, BattleData::envPtr ptr, BattleData::unitPtr uni, const SKILL::declare& declare);
		static void mp_attack(battleLogic* logic, BattleData::envPtr ptr, BattleData::unitPtr uni, const SKILL::declare& declare);
		static void absorb_hp(battleLogic* logic, BattleData::envPtr ptr, BattleData::unitPtr uni, const SKILL::declare& declare);
		static void absorb_mp(battleLogic* logic, BattleData::envPtr ptr, BattleData::unitPtr uni, const SKILL::declare& declare);
		static void cure_hp(battleLogic* logic, BattleData::envPtr ptr, BattleData::unitPtr uni, const SKILL::declare& declare);
		static void cure_mp(battleLogic* logic, BattleData::envPtr ptr, BattleData::unitPtr uni, const SKILL::declare& declare);
		static void child_skill(battleLogic* logic, BattleData::envPtr ptr, BattleData::unitPtr uni, const SKILL::declare& declare);
		static void set_buff(battleLogic* logic, BattleData::envPtr ptr, BattleData::unitPtr uni, const SKILL::declare& declare);
		static void direct_attack(battleLogic* logic, BattleData::envPtr ptr, BattleData::unitPtr uni, const SKILL::declare& declare);
		static void clear_debuff(battleLogic* logic, BattleData::envPtr ptr, BattleData::unitPtr uni, const SKILL::declare& declare);
		static void add_shield(battleLogic* logic, BattleData::envPtr ptr, BattleData::unitPtr uni, const SKILL::declare& declare);
		static void mp_set(battleLogic* logic, BattleData::envPtr ptr, BattleData::unitPtr uni, const SKILL::declare& declare);
		static void mp_alter_formula_1(battleLogic* logic, BattleData::envPtr ptr, BattleData::unitPtr uni, const SKILL::declare& declare);
	private://buff ����
		void effect_to_clear(const unsigned round, sBattlePtr atk, sBattlePtr def, mBattlePtr user);//����Ч��
		void effect_to_run(const unsigned round, sBattlePtr atk, sBattlePtr def, mBattlePtr user, const unsigned sr);//ִ��Ч��
	private://buff ʵ��Ч��ִ�� //�ж�ǰ �ж��� ÿ���ж�����һ����ʽ�Ļغ� // ������Ч����
		static void effect_stun(battleLogic* logic, BattleData::envPtr env, BattleData::unitPtr uni, mBattlePtr user, ptrManBuff ef, const unsigned sr);
		static void effect_alter_hp(battleLogic* logic, BattleData::envPtr env, BattleData::unitPtr uni, mBattlePtr user, ptrManBuff ef, const unsigned sr);
		static void effect_alter_mp(battleLogic* logic, BattleData::envPtr env, BattleData::unitPtr uni, mBattlePtr user, ptrManBuff ef, const unsigned sr);

		typedef boost::function<void(battleLogic*, BattleData::envPtr, BattleData::unitPtr, mBattlePtr, ptrManBuff, const unsigned)> EffectRunF;
		UNORDERMAP(int, EffectRunF, EffectRunMap);
		static EffectRunMap EffectRun;
	private://buff ע���¼�
		static bool buff_regist(battleLogic* logic, BattleData::envPtr env, BattleData::unitPtr uni, mBattlePtr user, mBattlePtr aim, ptrManBuff ef);

		//���������¼�
		static void stun_regist(battleLogic* logic, BattleData::envPtr env, BattleData::unitPtr uni, mBattlePtr user, mBattlePtr aim, const BUFF::Data& entity);
		static void bonus_attri_regist(battleLogic* logic, BattleData::envPtr env, BattleData::unitPtr uni, mBattlePtr user, mBattlePtr aim, const BUFF::Data& entity);
		static void bonus_attri_rate_regist(battleLogic* logic, BattleData::envPtr env, BattleData::unitPtr uni, mBattlePtr user, mBattlePtr aim, const BUFF::Data& entity);
		static void last_alter_regist(battleLogic* logic, BattleData::envPtr env, BattleData::unitPtr uni, mBattlePtr user, mBattlePtr aim, const BUFF::Data& entity);

		typedef boost::function<void(battleLogic*, BattleData::envPtr, BattleData::unitPtr, mBattlePtr, mBattlePtr, const BUFF::Data&)> RegEffectF;
		UNORDERMAP(int, RegEffectF, RegEffectMap);
		static RegEffectMap RegEffect;
	private://buff ��ע���¼�
		static void stun_antiregist(battleLogic* logic, mBattlePtr user, ptrManBuff ef);
		static void bonus_attri_antiregist(battleLogic* logic, mBattlePtr user, ptrManBuff ef);
		static void bonus_attri_rate_antiregist(battleLogic* logic, mBattlePtr user, ptrManBuff ef);

		typedef boost::function<void(battleLogic*, mBattlePtr, ptrManBuff)> AntiRegEffectF;
		UNORDERMAP(int, AntiRegEffectF, AntiRegEffectMap);
		static AntiRegEffectMap AntiRegEffect;
	private://ʩ��ִ������
		static bool user_runOK(battleLogic* logic, mBattlePtr user, mBattlePtr aim, const SKILL::declare& declare);

		static bool user_alive(battleLogic* logic, mBattlePtr user, mBattlePtr aim);
		static bool aim_alive(battleLogic* logic, mBattlePtr user, mBattlePtr aim);
		static bool user_hp_greater(battleLogic* logic, mBattlePtr user, mBattlePtr aim);
		static bool user_hp_less(battleLogic* logic, mBattlePtr user, mBattlePtr aim);
		static bool user_hp_equal(battleLogic* logic, mBattlePtr user, mBattlePtr aim);

		typedef boost::function<bool(battleLogic*, mBattlePtr, mBattlePtr)> UserRunF;
		UNORDERMAP(int, UserRunF, UserRunMap);
		static UserRunMap UserRun;
	private://�����¼���
		enum EventResult
		{
			adopt,//�¼�ͨ��
			intercept,//�¼�����
		};
		static EventResult onRun(BattleData::envPtr ptr, BattleData::unitPtr uni, const SKILL::declare& declare, mBattlePtr user, mBattlePtr aim, const bool visible = true);//����ʹ��ʧ��
		static EventResult onPhyAttack(BattleData::envPtr ptr, BattleData::unitPtr uni, mBattlePtr user, mBattlePtr aim);
		static EventResult onWarAttack(BattleData::envPtr ptr, BattleData::unitPtr uni, mBattlePtr user, mBattlePtr aim);
		static EventResult onRageAttack(BattleData::envPtr ptr, BattleData::unitPtr uni, mBattlePtr user, mBattlePtr aim);
		static EventResult onMagicAttack(BattleData::envPtr ptr, BattleData::unitPtr uni, mBattlePtr user, mBattlePtr aim);
		static EventResult onAttack(BattleData::envPtr ptr, BattleData::unitPtr uni, mBattlePtr user, mBattlePtr aim);
		static EventResult onPhyDamage(BattleData::envPtr ptr, BattleData::unitPtr uni, mBattlePtr user, mBattlePtr aim, int& damage);
		static EventResult onWarDamage(BattleData::envPtr ptr, BattleData::unitPtr uni, mBattlePtr user, mBattlePtr aim, int& damage);
		static EventResult onRageDamage(BattleData::envPtr ptr, BattleData::unitPtr uni, mBattlePtr user, mBattlePtr aim, int& damage);
		static EventResult onMagicDamage(BattleData::envPtr ptr, BattleData::unitPtr uni, mBattlePtr user, mBattlePtr aim, int& damage);
		static EventResult onDamage(BattleData::envPtr ptr, BattleData::unitPtr uni, mBattlePtr user, mBattlePtr aim, int& damage, const bool common = true);
		static EventResult onDodge(BattleData::envPtr ptr, BattleData::unitPtr uni, mBattlePtr user, mBattlePtr aim);
		static EventResult onBlock(BattleData::envPtr ptr, BattleData::unitPtr uni, mBattlePtr user, mBattlePtr aim);
		static EventResult onCrit(BattleData::envPtr ptr, BattleData::unitPtr uni, mBattlePtr user, mBattlePtr aim);
		static EventResult onCounter(BattleData::envPtr ptr, BattleData::unitPtr uni, mBattlePtr user, mBattlePtr aim);
		//EventResult onDead(BattleData::envPtr ptr, BattleData::unitPtr uni, mBattlePtr who);
	private://��ʽ����������
		static int damageFM(
			BattleData::envPtr ptr, BattleData::unitPtr uni, const SKILL::declare& declare,
			mBattlePtr user, const AttributeIDX user_pro, const AttributeIDX user_atk, const AttributeIDX user_final, const AttributeIDX user_final_val, const ArmsModule user_midx,
			mBattlePtr aim, const AttributeIDX aim_pro, const AttributeIDX aim_def, const AttributeIDX aim_final, const AttributeIDX aim_final_val, const ArmsModule aim_midx,
			const double damageRate = 1.0);
	private://һЩ˽�еı���
		static vector< vector<armsRestraint> > armsR;//���ֿ��ƹ�ϵ
		static double calArmsRes(const int atk_type, const int aim_type);
	};
}

#pragma once

namespace gg
{
	namespace ActivityRankEnum
	{
		enum
		{
			activity_battle_rank,
			activity_recharge_rank,
			activity_consume_rank,

			activity_rank_num,
		};
	}
}

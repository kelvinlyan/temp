#include "kingdomwar_task.h"
#include "kingdomwar_city.h"
#include "kingdomwar_system.h"
#include "playerManager.h"
#include "kingdom_system.h"
#include "heroparty_system.h"

namespace gg
{
	namespace KingdomWar
	{
		namespace Task
		{

#define NCHECKER(name)\
	class name\
		: public ICheck2\
	{\
		public:\
			static CheckPtr2 create(const Json::Value& info)\
			{\
				return Creator<name>::Create(info);\
			}\
			name(const Json::Value& info)\
				: ICheck2(info["type"].asInt())\
			{\
				ForEachC(Json::Value, it, info["arg"])\
					_args.push_back((*it).asInt());\
			}\
			virtual int update(int nation, ParamPtr& param_ptr, const Json::Value& arg);\
			virtual int init(int nation, ParamPtr& param_ptr);\
		protected:\
			std::vector<int> _args;\
	}

	class COccupySpecified
		: public ICheck2
	{
		public:
			STDVECTOR(int, IDList);
			static CheckPtr2 create(const Json::Value& info)
			{
				return Creator<COccupySpecified>::Create(info);
			}
			COccupySpecified(const Json::Value& info)
				: ICheck2(info["type"].asInt())
			{
				ForEachC(Json::Value, it, info["arg"])
				{
					const Json::Value& id_list = *it;
					IDList tmp;
					ForEachC(Json::Value, itl, id_list)
						tmp.push_back((*itl).asInt());
					_args.push_back(tmp);
				}
			}
			virtual int update(int nation, ParamPtr& param_ptr, const Json::Value& arg);
			virtual int init(int nation, ParamPtr& param_ptr);
			std::vector<IDList> _args;
	};

			NCHECKER(CGetExploit2);
			NCHECKER(COccupyNum);
			typedef COccupyNum COccupyNum1;
			typedef COccupyNum COccupyNum2;

			int COccupySpecified::update(int nation, ParamPtr& param, const Json::Value& arg)
			{
				const IDList& id_list = _args[nation];
				VecIntPtr param_ptr = upCast<VecInt>(param);
				if (arg.isInt()) // start or stop
				{
					int action = arg.asInt();
					if (action == 1) // start
					{
						ForEachC(IDList, it, id_list)
						{
							CityPtr ptr = kingdomwar_sys.getCity(*it);
							if (ptr && ptr->nation() == nation)
								param_ptr->_values.push_back(*it);
						}
						return Running;
					}
					else // stop
					{
						return param_ptr->_values.size() >= id_list.size()? 
							Finished : Running;
					}
				}

				int id = arg[0u].asInt();
				int action = arg[1u].asInt();
				ForEachC(IDList, it, id_list)
				{
					if (*it == id)
					{
						if (action == 1)
							param_ptr->_values.push_back(id);
						else
						{
							ForEach(IDList, itp, param_ptr->_values)
							{
								if (*itp == id)
								{
									param_ptr->_values.erase(itp);
									break;
								}
							}
						}
						return Running;
					}
				}
				return NoChanged;
			}

			int COccupySpecified::init(int nation, ParamPtr& param)
			{
				param = Creator<VecInt>::Create();
				return Running;
			}

			int CGetExploit2::update(int nation, ParamPtr& param_ptr, const Json::Value& arg)
			{
				int val = arg.asInt();
				TwoInt& param = *(upCast<TwoInt>(param_ptr));
				param[0] += val;
				if (param[0] > param[1])
					param[0] = param[1];
				return param[0] >= param[1]? Finished : Running;
			}

			int CGetExploit2::init(int nation, ParamPtr& param_ptr)
			{
				param_ptr = Creator<TwoInt>::Create();
				TwoInt& param = *(upCast<TwoInt>(param_ptr));
				param[0] = 0;
				param[1] = _args[0] * heroparty_sys.getKingdomWarTaskParam() * TaskParamHelper::shared().param() + _args[1];
				return param[0] >= param[1]? Finished : Running;
			}

			int COccupyNum::update(int nation, ParamPtr& param_ptr, const Json::Value& arg)
			{
				int action = arg.asInt();
				TwoInt& param = *(upCast<TwoInt>(param_ptr));
				if (action == 1)
				{
					param[0] = CityCounter::shared().num(nation);
					if (param[0] > param[1])
						param[0] = param[1];
					return Running;
				}
				else
				{
					return param[0] >= param[1]? Finished : Running;
				}
			}

			int COccupyNum::init(int nation, ParamPtr& param_ptr)
			{
				int num = CityCounter::shared().num(nation);
				param_ptr = Creator<TwoInt>::Create();
				TwoInt& param = *(upCast<TwoInt>(param_ptr));
				param[0] = 0;
				param[1] = num + _args[0];
				if (param[1] > CityCounter::shared().allNum() - 2)
					param[1] = CityCounter::shared().allNum() - 2;
				return Running;
			}

			class CheckPtr2Factory
			{
				public:
					typedef boost::function<CheckPtr2(const Json::Value&)> CreateFunc;
					STDVECTOR(CreateFunc, CreateFuncMap);
					CheckPtr2Factory()
					{
						_creator_map[OccupySpecified] = boostBind(COccupySpecified::create, _1);
						_creator_map[GetExploit2] = boostBind(CGetExploit2::create, _1);
						_creator_map[OccupyNum1] = boostBind(COccupyNum1::create, _1);
						_creator_map[OccupyNum2] = boostBind(COccupyNum2::create, _1);
					}
					CheckPtr2 create(const Json::Value& info)
					{
						int type = info["type"].asInt();
						if (type <= Empty || type >= NTaskMax)
							return _creator_map[Empty](info);

						return _creator_map[type](info);
					}
				private:
					CreateFunc _creator_map[PTaskMax];
			};
		}

		NationTaskConfig::NationTaskConfig(const Json::Value& info)
		{
			static Task::CheckPtr2Factory factory;
			id = info["id"].asInt();
			weight = info["weight"].asInt();
			const Json::Value& task = info["task"];
			for (unsigned i = 0; i < Kingdom::nation_num; ++i)
				checker.push_back(factory.create(task[i]));
			reward = info["reward"];
		}

		NationTask::NationTask(int nation)
			: _nation(nation), _id(-1), _state(Task::Running)
		{
		}

		void NationTask::loadDB()
		{
			mongo::BSONObj key = BSON("nt" << _nation);
			mongo::BSONObj obj = db_mgr.FindOne(DBN::dbKingdomWarNationTask, key);
			if (obj.isEmpty())
				return;

			_id = obj["i"].Int();
			if (_id != -1)
			{
				_state = obj["s"].Int();
				_param = Task::ParamFactory::create(obj["p"]);
				_strength = obj["st"].Int();
				_nation_lv = obj["nl"].Int();
			}
		}

		bool NationTask::_auto_save()
		{
			mongo::BSONObj key = BSON("nt" << _nation);
			mongo::BSONObjBuilder obj;
			obj << "nt" << _nation << "i" << _id;
			if (_id != -1)
				obj << "s" << _state << "p" << _param->toBSON() << "st" << _strength << "nl" << _nation_lv;
			return db_mgr.SaveMongo(DBN::dbKingdomWarNationTask, key, obj.obj());
		}

		void NationTask::update(int type, const Json::Value& arg)
		{
			if (!_checker && !getChecker())
				return;
			if (_checker->type() != type)
				return;
			int s = _checker->update(_nation, _param, arg);
			if (s != Task::NoChanged)
			{
				_state = s;
				_sign_save();
			}
			if (_state == Task::Finished)
			{
				playerManager::playerDataVec vec = player_mgr.nationOnline((Kingdom::NATION)_nation);
				ForEach(playerManager::playerDataVec, it, vec)
					(*it)->KingDomWarTask().resetNationTaskRPAndUpdate();
			}
		}

		bool NationTask::getChecker()
		{
			const NationTaskConfig& config = NationTaskMgr::shared().getConfig(_id);
			if (!config.valid())
				return false;
			_checker = config.checker[_strength];
			return true;
		}

		int NationTask::getSchedule()
		{
			switch(_checker->type())
			{
				case Task::OccupySpecified:
				{
					Task::VecIntPtr ptr = upCast<Task::VecInt>(_param);
					return ptr->_values.size();
				}
				case Task::GetExploit2:
				case Task::OccupyNum1:
				case Task::OccupyNum2:
				{
					Task::TwoInt& param = *(upCast<Task::TwoInt>(_param));
					return param[0];
				}
				default:
					return 0;
			}
		}

		int NationTask::getTarget()
		{
			switch(_checker->type())
			{
				case Task::OccupySpecified:
				{
					boost::shared_ptr<Task::COccupySpecified> ptr = upCast<Task::COccupySpecified>(_checker);
					return ptr->_args[_nation].size();
				}
				case Task::GetExploit2:
				case Task::OccupyNum1:
				case Task::OccupyNum2:
				{
					Task::TwoInt& param = *(upCast<Task::TwoInt>(_param));
					return param[1];
				}
				default:
					return 0;
			}

		}

		void NationTask::reset(int strength, const NationTaskConfig& config)
		{
			_strength = strength;
			_id = config.id;
			_checker = config.checker[_strength];
			_state = _checker->init(_nation, _param);
			_nation_lv = kingdom_sys.getData(_nation)->getLevel();
			_sign_save();
		}

		void NationTask::clear()
		{
			_id = -1;
			_state = Task::Running;
			_sign_save();
		}

		void NationTask::getInfo(playerDataPtr d, qValue& q) const
		{
			q.append(_id);
			if (_id != -1)
			{
				q.append(_state == Task::Running? _state : d->KingDomWarTask().nationTaskState() == 1? Task::Rewarded : Task::Finished);
				qValue p;
				_param->getInfo(p);
				q.append(p);
				q.append(_strength);
				q.append(_nation_lv);
			}
		}

		void NationTask::stop(unsigned cur_time)
		{
			if (!_checker && !getChecker())
				return;
			Log(DBLOG::strLogKingdomWar, 9, cur_time, _nation, _checker->type(), getSchedule(), getTarget());
			if (_state == Task::Finished)
			{
				playerManager::playerDataVec vec = player_mgr.nationOnline((Kingdom::NATION)_nation);
				ForEach(playerManager::playerDataVec, it, vec)
					(*it)->KingDomWarTask().resetNationTaskRPAndUpdate();
			}
		}

		int NationTask::getReward(playerDataPtr d, Json::Value& r)
		{
			if (_state != Task::Finished
					|| d->KingDomWarTask().nationTaskState() != 0)
				return err_illedge;

			const NationTaskConfig& config = NationTaskMgr::shared().getConfig(_id);
			if (!config.valid())
				return err_illedge;

			const Json::Value& reward = config.reward;
			int arg1 = reward[0u].asInt();
			int arg2 = reward[1u].asInt();
			int arg3 = reward[2u].asInt();
			int arg4 = reward[3u].asInt();
			int silver = _nation_lv * arg1 + arg2;
			int exploit = _nation_lv * arg3 + arg4;
			silver = d->Res().alterSilver(silver);
			d->Res().alterExploit(exploit);
			{
				Json::Value tmp;
				tmp.append(ACTION::silver);
				tmp.append(silver);
				r.append(tmp);
			}
			{
				Json::Value tmp;
				tmp.append(ACTION::exploit_coin);
				tmp.append(exploit);
				r.append(tmp);
			}
			d->KingDomWarTask().setNationRewarded();
			return res_sucess;
		}

		NationTaskConfig NationTaskMgr::_null;

		NationTaskMgr::NationTaskMgr()
		{
			for (unsigned i = 0; i < Kingdom::nation_num; ++i)
				_nation_tasks.push_back(Creator<NationTask>::Create(i));
			loadFile();
			loadDB();
			_last_stop_time = Common::getLastTimeHMS(Common::gameTime(), 20, 55);
		}

		const NationTaskConfig& NationTaskMgr::getConfig(int id) const
		{
			ConfigMap::const_iterator it = _config_map.find(id);
			return it == _config_map.end()? _null : it->second;
		}

		void NationTaskMgr::loadFile()
		{
			Json::Value json = Common::loadJsonFile("./instance/kingdom_war/nation_task.json");
			ForEach(Json::Value, it, json)
			{
				int rand_type = (*it)["randtype"].asInt();
				_total_weight[rand_type] += (*it)["weight"].asUInt();
				_rand_config[rand_type].push_back(NationTaskConfig(*it));
				_config_map.insert(make_pair((*it)["id"].asInt(), NationTaskConfig(*it)));
			}
			if (_config_map.empty())
				LogE << "kingdom war nation_task.json error" << LogEnd;
		}

		void NationTaskMgr::loadDB()
		{
			for (unsigned i = 0; i < Kingdom::nation_num; ++i)
				_nation_tasks[i]->loadDB();
		}

		const NationTaskConfig& NationTaskMgr::randConfig(int type) const
		{
			unsigned val = Common::randomUInt(1, _total_weight[type]);
			unsigned tmp = 0;
			ForEachC(RandConfig, it, _rand_config[type])
			{
				if (val <= it->weight + tmp)
					return *it;
				else
					tmp += it->weight;
			}
			return _null;
		}

		struct Strength
		{
			Strength(int n, int c)
				: nation(n), city_num(c){}
			bool operator<(const Strength& s) const
			{
				if (city_num == s.city_num)
					return nation < s.nation;
				return city_num > s.city_num;
			}
			int nation;
			int city_num;
		};

		static int getRandType(const std::vector<Strength>& sort_strength)
		{
			if (sort_strength[0].city_num == sort_strength[1].city_num
					&& sort_strength[1].city_num == sort_strength[2].city_num)
				return 0;
			if (sort_strength[0].city_num == sort_strength[1].city_num)
				return 1;
			if (sort_strength[1].city_num == sort_strength[2].city_num)
				return 2;
			return 3;
		}

		void NationTaskMgr::reset()
		{
			std::vector<Strength> sort_strength;
			for (unsigned i = 0; i < Kingdom::nation_num; ++i)
				sort_strength.push_back(Strength(i, CityCounter::shared().num(i)));
			std::sort(sort_strength.begin(), sort_strength.end());

			int type = getRandType(sort_strength);
			const NationTaskConfig& config = randConfig(type);
			if (!config.valid())
			{
				LogE << "kingdom war nation task rand config error" << LogEnd;
				return;
			}

			for (unsigned i = 0; i < Kingdom::nation_num; ++i)
				_nation_tasks[sort_strength[i].nation]->reset(i, config);
		}

		void NationTaskMgr::clear()
		{
			for (unsigned i = 0; i < _nation_tasks.size(); ++i)
			{
				_nation_tasks[i]->clear();
			}
		}

		int NationTaskMgr::getReward(playerDataPtr d, int id, Json::Value& r)
		{
			return _nation_tasks[d->Info().Nation()]->getReward(d, r);
		}

		void NationTaskMgr::getInfo(playerDataPtr d, qValue& q) const
		{
			if (d->KingDomWarTask().nationTaskState() == -1)
				q.append(-1);
			else
				_nation_tasks[d->Info().Nation()]->getInfo(d, q); 
		}

		void NationTaskMgr::start(unsigned cur_time)
		{
			for (unsigned i = 0; i < _nation_tasks.size(); ++i)
			{
				update(Task::OccupySpecified, i, Json::Value(1));
				update(Task::OccupyNum1, i, Json::Value(1));
				update(Task::OccupyNum2, i, Json::Value(1));
			}
			TaskParamHelper::shared().clear();
		}

		void NationTaskMgr::stop(unsigned cur_time)
		{
			for (unsigned i = 0; i < _nation_tasks.size(); ++i)
			{
				update(Task::OccupySpecified, i, Json::Value(0));
				update(Task::OccupyNum1, i, Json::Value(0));
				update(Task::OccupyNum2, i, Json::Value(0));
				_nation_tasks[i]->stop(cur_time);
			}
			_last_stop_time = cur_time;
		}

		TaskParamHelper::TaskParamHelper()
		{
			loadDB();
		}

		void TaskParamHelper::loadDB()
		{
			mongo::BSONObj key = BSON("nt" << -1);
			mongo::BSONObj obj = db_mgr.FindOne(DBN::dbKingdomWarNationTask, key);
			if (obj.isEmpty())
				return;

			std::vector<mongo::BSONElement> ele = obj["ps"].Array();
			for (unsigned i = 0; i < ele.size(); ++i)
				_player_set.insert(ele[i].Int());
		}

		bool TaskParamHelper::_auto_save()
		{
			mongo::BSONObj key = BSON("nt" << -1);
			mongo::BSONObjBuilder obj;
			obj << "nt" << -1;
			{
				mongo::BSONArrayBuilder b;
				ForEachC(std::set<int>, it, _player_set)
					b.append(*it);
				obj << "ps" << b.arr();
			}
			return db_mgr.SaveMongo(DBN::dbKingdomWarNationTask, key, obj.obj());
		}

		void TaskParamHelper::update(int pid)
		{
			if (KingdomWar::State::shared().get() != PrimeTime)
				return;
			if (_player_set.find(pid) != _player_set.end())
				return;
			_player_set.insert(pid);
			_sign_save();
		}

		void TaskParamHelper::clear()
		{
			_player_set.clear();
			_sign_save();
		}
	}
}

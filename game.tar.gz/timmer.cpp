#include "timmer.hpp"
#include "auto_base.h"
#include "auto_do.h"

Timer::CallList Timer::_callList;
Timer::CallMap Timer::_callMap;
unsigned Timer::_IDBegin = 0;
std::vector<unsigned> Timer::_IDCreator;


TimerIdentify::TimerIdentify(const int id) : IDTimer(id)
{
	//LogS << IDTimer << " timer create ..." << LogEnd;
}

TimerIdentify::~TimerIdentify()
{
	Timer::RecoverTimerID(IDTimer);
}

void TimerIdentify::delTimer()
{
//	LogS << State::getState() << " try to del timer ..." << IDTimer << LogEnd;
	TimerPost(boostBind(Timer::delTickImpl, IDTimer));
}

structTimer::structTimer(ptrTimerIdentify id, TIMER::Handler h, const unsigned tt, const int eid)
{
	timerID = id;
	handler = h;
	tickTime = tt;
	postTime = Common::gameTime();
	eventID = eid;
}

void Timer::RecoverTimerID(const unsigned ID)
{
	if (ID >= _IDBegin)return;
	_IDCreator.push_back(ID);
	//LogS << ID << " timer recover ..." << LogEnd;
}

void Timer::delTickImpl(const int timerID)
{
	CallMap::iterator it = _callMap.find(timerID);
	if (it == _callMap.end())
	{
//		LogS << "try to remove timer " << timerID << " failed ... can not find this id..." << LogEnd;
		return;
	}
	ptr_structTimer tD = it->second;
	_callList.erase(tD);
	_callMap.erase(it);
//	LogS << "try to remove timer " << timerID << " sucessed ..." << LogEnd;
}

void Timer::EventUpdate()
{
	const unsigned now = Common::gameTime();
	do
	{
		for (CallList::iterator it = _callList.begin(); it != _callList.end();)
		{
			CallList::iterator Oldit = it;
			++it;
			ptr_structTimer tD = *Oldit;
			if (now > tD->tickTime)
			{
				_callList.erase(Oldit);
				_callMap.erase(tD->timerID->IDTimer);
				LogicPost(boost::bind(&Timer::TickEvent, tD));
				continue;
			}
			break;
		}
	} while (false);

	Common::sleep(500000);//500ms
	TimerPost(boost::bind(Timer::EventUpdate));
}

void Timer::TickEvent(const ptr_structTimer timerData)
{
	try
	{
		TIMER::Handler handler = timerData->handler;
		if (handler)
		{
			State::setState(timerData->eventID);
			NumberCounter::Step();
			handler(*timerData);
			helper_mgr._run_tick();
		}
	}
	catch (std::exception& e)
	{
		LogW << "timer callback wrong throw ..." << 
			timerData->eventID << "\t" << e.what() << LogEnd;
	}
}

namespace TIMER
{
	void CycleTime::run(const structTimer& tD)
	{
		handler(tD);
		if (type == every_ntime)
		{
			unsigned tickTime = Common::gameTime() + arg;
			TIMER::CTPtr ptr(Creator<TIMER::CycleTime>::Create(handler, eventID, TIMER::every_ntime, arg));
			::Timer::_InternalAddEvent(boostBind(TIMER::CycleTime::run, ptr, _1), eventID, tickTime, tD.timerID);
		}
		else if (type == every_pertime)
		{
			unsigned tickTime = tD.tickTime + arg;
			TIMER::CTPtr ptr(Creator<TIMER::CycleTime>::Create(handler, eventID, TIMER::every_pertime, arg));
			::Timer::_InternalAddEvent(boostBind(TIMER::CycleTime::run, ptr, _1), eventID, tickTime, tD.timerID);
		}
	}

}

#include "chat.h"
#include "playerManager.h"
#include "timmer.hpp"
#include "common_protocol.h"
#include "game_server.h"

namespace gg
{
	chat_system* const chat_system::_Instance = new chat_system();

	typedef boost::function<bool(playerDataPtr, Json::Value&, Json::Value&, Json::Value&)> ChatFunction;
	UNORDERMAP(int, ChatFunction, ChatMap);
	static ChatMap mapChat;

	//�������컺��
	typedef std::list<string> CHATBUFFER;
	const static unsigned AllLimit = 30;
	static CHATBUFFER ChatALL[Kingdom::nation_num + 1];//0 ����ͨ��

	//�����б�
	UNORDERMAP(int, unsigned, ChatForbidMap);
	static ChatForbidMap staticForbidMap;
	unsigned endForbidChat(const int playerID)
	{
		ChatForbidMap::iterator it =
		staticForbidMap.find(playerID);
		if (it == staticForbidMap.end())return 0;
		const unsigned now = Common::gameTime();
		if (now > it->second)
		{
			mongo::BSONObj key = BSON(strPlayerID << playerID);
			db_mgr.RemoveCollection(DBN::dbChatForbid, key);
			staticForbidMap.erase(it);
			return 0;
		}
		return it->second;
	}


	Json::Value chat_system::ChatPackage(playerDataPtr player)
	{
		Json::Value json;
		json.append(player->ID());
		json.append(player->Name());
		json.append(player->Info().Nation());
 		json.append(player->Info().NationOf_());//���ҹ�λ
		return json;
	}

	qValue chat_system::ChatPackageQ(playerDataPtr player)
	{
		qValue json(qJson::qj_array);
		json.append(player->ID());
		json.append(player->Name());
		json.append(player->Info().Nation());
 		json.append(player->Info().NationOf_());//���ҹ�λ
		return json;
	}
	
	qValue chat_system::ServerPackageQ(const int ID)
	{
		qValue json(qJson::qj_array);
		json.append(ID);
		const static string serverName = "server";
		json.append(serverName);
		return json;
	}

	Json::Value chat_system::ServerPackage(const int ID)
	{
		Json::Value json;
		json.append(ID);
		json.append("server");
		return json;
	}

	bool ChatAll(playerDataPtr player, Json::Value& custom, Json::Value& supple, Json::Value& r)
	{
		unsigned now = Common::gameTime();
		if (player->Chat[CHAT::chat_all] > now)resReturn(r, err_chat_too_fast, false);
		player->Chat[CHAT::chat_all] = now + 20;
		Json::Value chatReq;
		chatReq[strMsg][0u] = res_sucess;
		chatReq[strMsg][1u] = CHAT::chat_all;
		chatReq[strMsg][2u] = chat_sys.ChatPackage(player);
		chatReq[strMsg][3u] = custom;
		chatReq[strMsg][4u] = CHATPOS::chat_windows;
		string chat_str = chatReq.toIndentString();
		for (unsigned i = 0; i < Kingdom::nation_num + 1; ++i)
		{
			ChatALL[i].push_back(chat_str);
			if (ChatALL[i].size() > AllLimit)
			{
				ChatALL[i].pop_front();
			}
		}
		player_mgr.sendToAll(gate_client::player_chat_resp, chatReq);
		return true;
	}

	bool ChatKingdom(playerDataPtr player, Json::Value& custom, Json::Value& supple, Json::Value& r)
	{
		unsigned now = Common::gameTime();
		if (player->Chat[CHAT::chat_kingdom] > now)resReturn(r, err_chat_too_fast, false);
		player->Chat[CHAT::chat_kingdom] = now + 10;
		const Kingdom::NATION nation = player->Info().Nation();
		if (nation == Kingdom::null)resReturn(r, err_illedge, false);
		Json::Value chatReq;
		chatReq[strMsg][0u] = res_sucess;
		chatReq[strMsg][1u] = CHAT::chat_kingdom;
		chatReq[strMsg][2u] = chat_sys.ChatPackage(player);
		chatReq[strMsg][3u] = custom;
		chatReq[strMsg][4u] = CHATPOS::chat_windows;
		string chat_str = chatReq.toIndentString();
		const unsigned idx = player->Info().Nation() + 1;
		ChatALL[idx].push_back(chat_str);
		if (ChatALL[idx].size() > AllLimit)
		{
			ChatALL[idx].pop_front();
		}
		player_mgr.sendToKingdom(nation, gate_client::player_chat_resp, chatReq);
		return true;
	}

	bool ChatPlayer(playerDataPtr player, Json::Value& custom, Json::Value& supple, Json::Value& r)
	{
		unsigned now = Common::gameTime();
		if (player->Chat[CHAT::chat_player] > now)resReturn(r, err_chat_too_fast, false);
		playerDataPtr aim_player;
		if (supple[0u].isInt())
		{
			aim_player = player_mgr.getOnlinePlayer(supple[0u].asInt());
		}
		else if (supple[0u].isString())
		{
			aim_player = player_mgr.getOnlinePlayer(supple[0u].asString());
		}
		if (!aim_player)resReturn(r, err_chat_aim_not_find, false);
		player->Chat[CHAT::chat_player] = now + 10;
		Json::Value chatReq;
		chatReq[strMsg][0u] = res_sucess;
		chatReq[strMsg][1u] = CHAT::chat_player;
		chatReq[strMsg][2u] = chat_sys.ChatPackage(player);
		chatReq[strMsg][3u] = custom;
		chatReq[strMsg][4u] = CHATPOS::chat_windows;
		chatReq[strMsg][5u] = chat_sys.ChatPackage(aim_player);
		player->sendToClient(gate_client::player_chat_resp, chatReq);
		aim_player->sendToClient(gate_client::player_chat_resp, chatReq);
		return true;
	}

	struct RollNoticeData
	{
		RollNoticeData()
		{
			timerID = ptrTimerIdentify();
		}
		~RollNoticeData()
		{
			if (timerID)
			{
				timerID->delTimer();
			}
		}
		void TryToTimer();//���Կ�ʼ��ʱ��
		void setDead()
		{
			noticeTimes = 0;
			startTime = 0;
			endTime = 0;
		}
		bool isDead()
		{
			const unsigned now = Common::gameTime();
			return (noticeTimes < 1 || now > endTime);
		}
		Json::Value toJson()
		{
			Json::Value json;
			json["nid"] = noticeID;
			json["st"] = Common::toStampTime(startTime);
			json["et"] = Common::toStampTime(endTime);
			json["nt"] = noticeTimes;
			json["w"] = words;
			json["sp"] = showPos;
			json["pt"] = perTime;
			json["wgt"] = weight;
			return json;
		}
		mongo::BSONObj toBson()
		{
			return BSON("nid" << noticeID << "st" << startTime << "et" << endTime <<
				"nt" << noticeTimes << "w" << words << "sp" << showPos << "pt" << perTime <<
				"wgt" << weight);
		}
		void fromBson(mongo::BSONObj& obj)
		{
			noticeID = obj["nid"].Int();
			startTime = (unsigned)obj["st"].Int();
			endTime = (unsigned)obj["et"].Int();
			noticeTimes = (unsigned)obj["nt"].Int();
			words = obj["w"].String();
			showPos = (unsigned)obj["sp"].Int();
			perTime = (unsigned)obj["pt"].Int();
			weight = obj["wgt"].eoo() ? 0 : obj["wgt"].Int();
		}
		int noticeID;//ID
		unsigned startTime;//��ʼʱ��
		unsigned endTime;//����ʱ��
		unsigned perTime;//���ʱ��
		unsigned noticeTimes;//֪ͨ����
		unsigned showPos;//��ʾλ��
		ptrTimerIdentify timerID;//��ʱ��ID
		string words;//ת��������
		unsigned weight;//���ȼ� Խ��Խ�Ȳ���
	};
	BOOSTSHAREPTR(RollNoticeData, rnDataPtr);
	UNORDERMAP(int, rnDataPtr, rnDataMap);
	static rnDataMap mapRoll;
	rnDataPtr getRollData(const int noticeID)
	{
		rnDataMap::iterator it = mapRoll.find(noticeID);
		if (it == mapRoll.end())return rnDataPtr();
		return it->second;
	}
	void removeRollData(const int noticeID)
	{
		mapRoll.erase(noticeID);
	}
	void saveRollData(rnDataPtr ptr)
	{
		if (!ptr)return;
		mongo::BSONObj key = BSON("nid" << ptr->noticeID);
		if (ptr->isDead())
		{
			if (ptr->timerID)
			{
				ptr->timerID->delTimer();
			}
			ptr->timerID = ptrTimerIdentify();
			removeRollData(ptr->noticeID);
			db_mgr.RemoveCollection(DBN::dbRollData, key);
		}
		else
		{
			db_mgr.SaveMongo(DBN::dbRollData, key, ptr->toBson());
		}
	}

	static void RollNoticeCallBack(const int noticeID)
	{
		rnDataPtr ptr = getRollData(noticeID);
		if (!ptr)return;
		if (!ptr->isDead())
		{
			Json::Value json_words = ptr->words;
			Json::Value extra_json;
			extra_json["weight"] = ptr->weight;
			extra_json["roll"] = 2;
			chat_sys.despatchAllSP(CHAT::server_roll_announce, json_words, extra_json, ptr->showPos);
			--ptr->noticeTimes;//���ٴ���
		}
		saveRollData(ptr);
		if (!ptr->isDead())
		{
			ptr->timerID = Timer::AddEventTickTime(boostBind(RollNoticeCallBack, noticeID), Inter::event_roll_broadcast_timer, Common::gameTime() + ptr->perTime);
		}
	}
	void RollNoticeData::TryToTimer()
	{
		if (timerID)
		{
			timerID->delTimer();
		}
		timerID = Timer::AddEventTickTime(boostBind(RollNoticeCallBack, noticeID), Inter::event_roll_broadcast_timer, startTime);
	}

	void chat_system::UpdateRollNotice(net::Msg& m, Json::Value& r)
	{
		r[strMsg][0u] = res_sucess;
		Json::Value& data_json = r[strMsg][1u];
		for (rnDataMap::iterator it = mapRoll.begin(); it != mapRoll.end(); ++it)
		{
			rnDataPtr ptr = it->second;
			data_json.append(ptr->toJson());
		}
	}

	void chat_system::RemoveRollNotice(net::Msg& m, Json::Value& r)
	{
		ReadJsonArray;
		for (unsigned i = 0; i < js_msg.size() &&  i < 300; ++i)
		{
			rnDataPtr ptr = getRollData(js_msg[i].asInt());
			if (!ptr)continue;
			ptr->setDead();
			saveRollData(ptr);
		}
		Return(r, res_sucess);
	}

	void chat_system::RollNotice(net::Msg& m, Json::Value& r)
	{
		ReadJsonArray;
		for (unsigned i = 0; i < js_msg.size(); ++i)
		{
			Json::Value& sg_json = js_msg[i];
			const int noticeID = sg_json["nid"].asInt();//����Ѱ�ҵ�����
			const string words = sg_json["bc"].asString();
			const unsigned startTime = sg_json["st"].asUInt();
			const unsigned endTime = sg_json["et"].asUInt();
			const unsigned perTime = sg_json["pt"].asUInt();
			const unsigned noticeTimes = sg_json["nts"].asUInt();
			const unsigned showPos = sg_json["sp"].asUInt();
			const unsigned weight = sg_json["wgt"].asUInt();
			rnDataPtr ptr = Creator<RollNoticeData>::Create();
			ptr->noticeID =  noticeID;
			ptr->words = words;
			ptr->startTime = Common::toLocalTime(startTime);
			ptr->endTime = Common::toLocalTime(endTime);
			ptr->perTime = perTime;
			ptr->noticeTimes = noticeTimes;
			ptr->showPos = showPos;
			ptr->weight = weight;
			ptr->TryToTimer();
			mapRoll[ptr->noticeID] = ptr;
			saveRollData(ptr);
		}
		Return(r, res_sucess);
	}

	void chat_system::ChatReq(net::Msg& m, Json::Value& r)
	{
		const unsigned endTime = endForbidChat(m.playerID);
		if (endTime > 0)
		{
			r[strMsg][1u] = endTime;
			Return(r, err_been_chat_forbid);
		}
		playerDataPtr player = player_mgr.getPlayer(m.playerID);
		if (!player)Return(r, err_illedge);
		ReadJsonArray;
		const int channel = js_msg[0u].asInt();
		ChatMap::iterator it = mapChat.find(channel);
		if (it == mapChat.end())Return(r, err_illedge);
		Json::Value& custom = js_msg[1u];//ת������
		Json::Value& supple = js_msg[2u];//��������
		if (it->second(player, custom, supple, r))
		{
			Json::Value recordJson;
			recordJson[0u] = channel;
			recordJson[1u] = custom;
			playerDataPtr aim_player;
			if (supple[0u].isInt())
			{
				aim_player = player_mgr.getOnlinePlayer(supple[0u].asInt());
			}
			else if (supple[0u].isString())
			{
				aim_player = player_mgr.getOnlinePlayer(supple[0u].asString());
			}
			recordJson[2u] = aim_player ? aim_player->ID() : -1;
			recordJson[1u]["w"] = js_msg[3u];//ԭʼ�ַ���
			string str = recordJson.toIndentString();
			net::Msg mj(player->ID(), service::process_id::SERVER_ROOT_ID, game_protocol::comomon::game_chat_record_resp, str);
			game_svr->async_send_to_gate(mj);
		}
	}

	//ȫ��
	bool chat_system::impl_despatchAll(Json::Value& chatReq)
	{
		player_mgr.sendToAll(gate_client::player_chat_resp, chatReq);
		return true;
	}

	bool chat_system::impl_despatchAll(qValue& chat_data)
	{
		qValue chatReq(qJson::qj_object);
		chatReq.addMember(strMsg, chat_data);
		player_mgr.sendToAll(gate_client::player_chat_resp, chatReq);
		return true;
	}

	//����
	bool chat_system::impl_despatchKingdom(const Kingdom::NATION nation, Json::Value& chatReq)
	{
		player_mgr.sendToKingdom(nation, gate_client::player_chat_resp, chatReq);
		return true;
	}

	bool chat_system::impl_despatchKingdom(const Kingdom::NATION nation, qValue& chat_data)
	{
		qValue chatReq(qJson::qj_object);
		chatReq.addMember(strMsg, chat_data);
		player_mgr.sendToKingdom(nation, gate_client::player_chat_resp, chatReq);
		return true;
	}

	//����
	bool chat_system::impl_despatchPlayer(const int playerID, Json::Value& chatReq)
	{
		playerDataPtr aim_player = player_mgr.getOnlinePlayer(playerID);
		if (!aim_player)return false;
		chatReq[strMsg][6u] = ChatPackage(aim_player);
		aim_player->sendToClient(gate_client::player_chat_resp, chatReq);
		return true;
	}

	bool chat_system::impl_despatchPlayer(const string playerName, Json::Value& chatReq)
	{
		playerDataPtr aim_player = player_mgr.getOnlinePlayer(playerName);
		if (!aim_player)return false;
		chatReq[strMsg][6u] = ChatPackage(aim_player);
		aim_player->sendToClient(gate_client::player_chat_resp, chatReq);
		return true;
	}

	bool chat_system::impl_despatchPlayer(const int playerID, qValue& chat_data)
	{
		playerDataPtr aim_player = player_mgr.getOnlinePlayer(playerID);
		if (!aim_player)return false;
		chat_data.append(ChatPackageQ(aim_player));
		aim_player->sendToClientFillMsg(gate_client::player_chat_resp, chat_data);
		return true;
	}

	bool chat_system::impl_despatchPlayer(const string playerName, qValue& chat_data)
	{
		playerDataPtr aim_player = player_mgr.getOnlinePlayer(playerName);
		if (!aim_player)return false;
		chat_data.append(ChatPackageQ(aim_player));
		aim_player->sendToClientFillMsg(gate_client::player_chat_resp, chat_data);
		return true;
	}

	void chat_system::initData()
	{
		Common::createDirectories("./report/chat_rep/");

		mapChat[CHAT::chat_all] = boostBind(ChatAll, _1, _2, _3, _4);
		mapChat[CHAT::chat_kingdom] = boostBind(ChatKingdom, _1, _2, _3, _4);
//		mapChat[CHAT::chat_area] = boostBind(ChatArea, _1, _2, _3, _4);
		mapChat[CHAT::chat_player] = boostBind(ChatPlayer, _1, _2, _3, _4);
	}

	static int chatRepID = 0;//���촰ս��ID
	int chat_system::toChatWindowsRep(const string source_path)
	{
		++chatRepID;
		chatRepID %= 100;
		const string target_path = "./report/chat_rep/" + Common::toString(chatRepID);
		boost::system::error_code code;
		boost::filesystem::copy_file(source_path, target_path, boost::filesystem::copy_option::overwrite_if_exists, code);
		if (code)return -1;
		return chatRepID;
	}

	void chat_system::sendBufferChat(playerDataPtr player)
	{
		const unsigned idx = player->Info().Nation() + 1;
		if (idx >= (Kingdom::nation_num + 1))return;
		CHATBUFFER& checkChat = ChatALL[idx];
		for (CHATBUFFER::iterator it = checkChat.begin(); it != checkChat.end(); ++it)
		{
			string str = *it;
			player->sendToClient(gate_client::player_chat_resp, str);
		}
	}


	void chat_system::gmForbidChat(net::Msg& m, Json::Value& r)
	{
		ReadJsonArray;
		for (unsigned i = 0; i < js_msg.size(); ++i)
		{
			Json::Value& val = js_msg[i];
			const int playerID = val[0u].asInt();
			const unsigned seconds = val[1u].asUInt();
			const unsigned endTime = Common::gameTime() + seconds;
			staticForbidMap[playerID] = endTime;
			playerDataPtr player = player_mgr.getOnlinePlayer(playerID);
			mongo::BSONObj key = BSON(strPlayerID << playerID);
			mongo::BSONObj obj = BSON(strPlayerID << playerID << "ed" << endTime);
			db_mgr.SaveMongo(DBN::dbChatForbid, key, obj);
			if (player)
			{
				qValue json(qJson::qj_array);
				json.append(res_sucess).append(endTime);
				player->sendToClientFillMsg(gate_client::player_chat_forbid_announce_resp, json);
			}
		}
		r[strMsg][1u] = js_msg.size();
		Return(r, res_sucess);
	}

	void chat_system::gmOpenChat(net::Msg& m, Json::Value& r)
	{
		unsigned sucess_num = 0;
		ReadJsonArray;
		for (unsigned i = 0; i < js_msg.size(); ++i)
		{
			const int playerID = js_msg[i].asInt();
			if (staticForbidMap.erase(playerID) > 0)
			{
				mongo::BSONObj key = BSON(strPlayerID << playerID);
				db_mgr.RemoveCollection(DBN::dbChatForbid, key);
				++sucess_num;
			}
		}
		r[strMsg][2u] = js_msg.size() - sucess_num;
		r[strMsg][1u] = sucess_num;
		Return(r, res_sucess);
	}


	void chat_system::gmSetChatUpdate(net::Msg& m, Json::Value& r)
	{
		const static unsigned PageNum = 100;
		ReadJsonArray;
		const unsigned page = js_msg[0u].asUInt();
		const unsigned page_start = page * PageNum;
		Json::Value& data_json = (r[strMsg][1u] = Json::arrayValue);
		unsigned cNum = 0;
		const unsigned now = Common::gameTime();
		for (ChatForbidMap::iterator it = staticForbidMap.begin(); it != staticForbidMap.end();)
		{
			const int playerID = it->first;
			const unsigned endTime = it->second;
			if (now > endTime)
			{
				staticForbidMap.erase(it++);
				mongo::BSONObj key = BSON(strPlayerID << playerID);
				db_mgr.RemoveCollection(DBN::dbChatForbid, key);
				continue;
			}
			else
			{
				++it;
			}
			if (cNum++ < page_start)continue;
			Json::Value sg_json = Json::arrayValue;
			sg_json.append(playerID);
			sg_json.append(Common::toStampTime(endTime));
			data_json.append(sg_json);
			if (data_json.size() >= PageNum)break;
		}
		r[strMsg][2u] = unsigned(staticForbidMap.size() / PageNum + ((staticForbidMap.size() % PageNum > 0) ? 1 : 0));
		Return(r, res_sucess);
	}
}

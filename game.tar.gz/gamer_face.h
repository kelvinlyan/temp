//###################################
//create by Jim
//2016-01-26
//###################################

#pragma once

#include "auto_do.h"

namespace gg
{
	class playerFace :
		public _auto_player
	{
	public:
		playerFace(playerData* const own);
		~playerFace(){}
		bool openFace(const int faceID);
		void insertFace(const int faceID);
		void removeFace(const int faceID);
	private:
		UNORDERSET(int, FaceList);
		FaceList _FaceList;
	};
}
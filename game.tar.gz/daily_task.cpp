#include "daily_task.h"
#include "game_time.h"

namespace gg
{
	daily_system* const daily_system::_Instance = new daily_system();

	static DAILY::CONFIGMAP Configs;
	const DAILY::CONFIGMAP& daily_system::getAll()
	{
		return Configs;
	}

	struct DailyBox
	{
		DailyBox()
		{
			rateLV.clear();
			box.clear();
		}
		std::map<int, double> rateLV;//����
		ACTION::BoxList box;
	};
	BOOSTSHAREPTR(DailyBox, DailyBoxPtr);
	UNORDERMAP(int, DailyBoxPtr, POINTBOXMAP);
	static POINTBOXMAP PointBoxes;
	DailyBoxPtr getPointBox(const int id)
	{
		POINTBOXMAP::iterator it = PointBoxes.find(id);
		if (it == PointBoxes.end())return DailyBoxPtr();
		return it->second;
	}

	struct PointLevelLimit
	{
		unsigned level;
		int max_point;
	};
	static vector<PointLevelLimit> PointMax;

	DAILY::ptrCONFIG daily_system::getConfig(const int type)
	{
		DAILY::CONFIGMAP::iterator it = Configs.find(type);
		if (it == Configs.end())return DAILY::ptrCONFIG();
		return it->second;
	}

	int daily_system::getMaxPoint(const unsigned level)
	{
		for (unsigned i = 0; i < PointMax.size(); ++i)
		{
			const PointLevelLimit& cData = PointMax[i];
			if (level >= cData.level)return cData.max_point;
		}
		return 0;
	}

	void daily_system::initData()
	{
		{//��������
			Configs.clear();
			Json::Value json = Common::loadJsonFile("./instance/daily/task.json");
			for (unsigned i = 0; i < json.size(); ++i)
			{
				Json::Value& sg_json = json[i];
				const DAILY::TYPE type = (DAILY::TYPE)sg_json["type"].asInt();
				if (type < DAILY::daily_begin || type > DAILY::daily_end)continue;
				DAILY::ptrCONFIG config = Creator<DAILY::CONFIG>::Create();
				config->type = type;
				config->kingdomLimit = sg_json["kingdom"].asBool();
				config->levelLimit = sg_json["level"].asUInt();
				config->seasonLimit = sg_json["season"].asInt();
				//if (config->seasonLimit < SEASON::Quarter_Begin || config->seasonLimit >SEASON::Quarter_End)continue;
				config->num = sg_json["num"].asInt();
				config->active_num = sg_json["point"].asInt();
				config->per_step = sg_json["step"].asInt();
				config->per_step = config->per_step < 1 ? 1 : config->per_step;
				config->per_step = config->per_step > config->num ? config->num : config->per_step;
				Json::Value box = sg_json["box"];
				config->box = actionFormatBox(box);
				config->rateLV.clear();
				for (unsigned idx = 0; idx < sg_json["module"].size(); ++idx)
				{
					config->rateLV[sg_json["module"][idx][0u].asInt()] = sg_json["module"][idx][1u].asDouble();
				}
				Configs[config->type] = config;
			}
		};
		{//���佱������
			PointBoxes.clear();
			Json::Value json = Common::loadJsonFile("./instance/daily/point_box.json");
			for (unsigned i = 0; i < json.size(); ++i)
			{
				Json::Value& sg_json = json[i];
				const int idPoint = sg_json["idPoint"].asInt();
				DailyBoxPtr box_ptr = Creator<DailyBox>::Create();
				Json::Value& box = sg_json["box"];
				box_ptr->box = actionFormatBox(box);
				for (unsigned idx = 0; idx < sg_json["module"].size(); ++idx)
				{
					box_ptr->rateLV[sg_json["module"][idx][0u].asInt()] = sg_json["module"][idx][1u].asDouble();
				}
				PointBoxes[idPoint] = box_ptr;
			}
		};
		{//��һ�������
			PointMax.clear();
			Json::Value json = Common::loadJsonFile("./instance/daily/point_max.json");
			for (unsigned i = 0; i < json.size(); ++i)
			{
				Json::Value& sg_json = json[i];
				PointLevelLimit sg_data;
				sg_data.level = sg_json["level"].asUInt();
				sg_data.max_point = sg_json["max_point"].asUInt();
				PointMax.push_back(sg_data);
			}
		};
	}

	void daily_system::update(net::Msg& m, Json::Value& r)
	{
		playerDataPtr player = player_mgr.getPlayer(m.playerID);
		if (!player)Return(r, err_illedge);//�Ƿ�����
		player->Daily()._auto_update();
	}

	void daily_system::getBox(net::Msg& m, Json::Value& r)
	{
		playerDataPtr player = player_mgr.getPlayer(m.playerID);
		if (!player)Return(r, err_illedge);//�Ƿ�����
		ReadJsonArray;
		const int idPoint = js_msg[0u].asInt();
		if (player->Daily().checkBox(idPoint))Return(r, err_daily_box_has_been_get);
		DailyBoxPtr box_ptr = getPointBox(idPoint);
		if (!box_ptr)Return(r, err_illedge);
		if (player->Daily().Points() < idPoint)Return(r, err_illedge);
		const unsigned playerLV = player->LV();
		for (std::map<int, double>::iterator it = box_ptr->rateLV.begin();
			it != box_ptr->rateLV.end(); ++it)
		{
			setActionRate(it->first, ACTION::Rate(1.0, playerLV * it->second));
		}
		const int res = actionDoBox(player, box_ptr->box, false);
		r[strMsg][1u] = actionError();
		if (res == res_sucess)
		{
			player->Daily().trueBox(idPoint);
			Log(DBLOG::strLogDailyTask, player, 2, idPoint, "", "", "", "", "", "", actionRes().toIndentString());
		}
		Return(r, res);
	}

	void daily_system::getTaskBox(net::Msg& m, Json::Value& r)
	{
		playerDataPtr player = player_mgr.getPlayer(m.playerID);
		if (!player)Return(r, err_illedge);//�Ƿ�����
		ReadJsonArray;
		const int taskID = js_msg[0u].asInt();
		if (player->Daily().checkTaskBox(DAILY::TYPE(taskID)))Return(r, err_daily_task_box_has_been_get);
		if (!player->Daily().checkTaskCompelete(DAILY::TYPE(taskID)))Return(r, err_illedge);
		DAILY::ptrCONFIG config = getConfig(taskID);
		if (!config)Return(r, err_illedge);
		const unsigned playerLV = player->LV();
		for (std::map<int, double>::iterator it = config->rateLV.begin();
			it != config->rateLV.end(); ++it)
		{
			setActionRate(it->first, ACTION::Rate(1.0, playerLV * it->second));
		}
		const int res = actionDoBox(player, config->box, false);
		r[strMsg][1u] = actionError();
		if (res == res_sucess)
		{
			player->Daily().trueTaskBox(DAILY::TYPE(taskID));
			Log(DBLOG::strLogDailyTask, player, 1, taskID, "","","","","","", actionRes().toIndentString());
		}
		Return(r, res);
	}

}
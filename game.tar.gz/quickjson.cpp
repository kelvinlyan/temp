#include "quickjson.h"

namespace gg
{
	qValue qValue::Copy()
	{
		qValue nq;
		nq.doc->CopyFrom(*doc, nq.doc->GetAllocator());
		return nq;
	}
}
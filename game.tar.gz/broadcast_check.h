//###################################
//create by Jim
//2016-04-05
//###################################s

#pragma once

#include "dbDriver.h"

namespace gg
{
	class actionResCheck
	{
	public:
		actionResCheck();
		virtual ~actionResCheck(){}
		void initialCheck(const string& file_name);//��ʼ��
		void beginCheck(playerDataPtr player, const Json::Value& check_json);
		virtual void onItemBroadcast(playerDataPtr player, const unsigned channel, const Json::Value& info_json){}
		virtual void onManBroadcast(playerDataPtr player, const unsigned channel, const Json::Value& info_json){}
		virtual void onLadyBroadcast(playerDataPtr player, const unsigned channel, const Json::Value& info_json){}
	private:
		bool beenInitial;//�Ƿ��Ѿ���ʼ��
		void CheckItemMatch(playerDataPtr player,const Json::Value& json);
		void CheckManMatch(playerDataPtr player, const Json::Value& json);
		void CheckLadyMatch(playerDataPtr player, const Json::Value& json);
		typedef boost::unordered_map<int, unsigned> CHECKMAP;
		typedef boost::function<void(playerDataPtr, const Json::Value&)> CheckFunction;
		typedef boost::unordered_map<int, CheckFunction> CheckFuncMap;
		CHECKMAP itemCheck, manCheck, ladyCheck;
		CheckFuncMap FuncMap;
	};
}
#include "battle_system.h"
#include "playerManager.h"
#include "skill.h"
#include "net_helper.hpp"
#include "man_system.h"

namespace gg
{
	//��ʵ��
	battleLogic::perDealMap battleLogic::mapPerDeal;
	battleLogic::aimDealMap battleLogic::newAimDeal;
	battleLogic::aimDealMap battleLogic::signAimDeal;
	battleLogic::SkillDealMap battleLogic::SkillDeal;
	battleLogic::EffectRunMap battleLogic::EffectRun;
	battleLogic::RegEffectMap battleLogic::RegEffect;
	battleLogic::AntiRegEffectMap battleLogic::AntiRegEffect;
	battleLogic::UserRunMap battleLogic::UserRun;
	vector< vector<armsRestraint> > battleLogic::armsR;


	const static unsigned BigRound_ = 30;
	const static unsigned LittleRound_ = 9;
	const static unsigned PriorityXY_[3][3] = { { 0, 1, 2 }, { 1, 0, 2 }, { 2, 1, 0 } };//ս��˳��

	//���˵��Ĺؼ���
	UNORDERSET(string, KEYSET);
	static KEYSET ReserveKey, ReserveKeyT;

	namespace BattleData
	{
		//���ܵ�Ԫ
		class unit
		{
		public:
			unit(const unsigned idx_, const unsigned round_,
				const sBattlePtr atk_, const sBattlePtr def_,
				const bool bring, const unsigned counter)
				: envIdx_(idx_), currentRound_(round_), atkHand_(atk_), defHand_(def_),
				bring_(bring), counter_(counter),
				junit_(qJson::qj_array)
			{
				currentIdx = 0;
				aim.clear();
			}
			~unit(){}
			void nextAim()
			{
				++currentIdx;
			}
			inline unsigned currentIDX()
			{
				return currentIdx;
			}
			bool isLastAim()
			{
				return ((currentIdx + 1) == aim.size());
			}
			class aimData;
			BOOSTSHAREPTR(aimData, aimPtr);
			class aimData
			{
			public:
				aimData(const unsigned pos, mBattlePtr aim) : pos_(pos)
				{
					aim_ = aim;
					state_ = 0;
					statusList_.clear();
					currentIdx_ = 0;
				}
				aimData(const unsigned pos, aimPtr aPtr) : pos_(pos)
				{
					aim_ = aPtr->aim_;
					state_ = aPtr->state_;
					statusList_ = aPtr->statusList_;
					currentIdx_ = 0;
				}
				bool satisfyGlobal(const unsigned require)
				{
					if (require == 0x0 || require == 0x80000000)return true;
					return (
						(bool((0x80000000 & require) != 0) && bool((state_ & require) != 0)) || //������
						(bool((0x80000000 & require) == 0) && bool((state_ & require) == require))//������
						);
				}
				bool satisfy(const int part, const unsigned require)
				{
					if (require == 0x0 || require == 0x80000000)return true;
					if (part < 0 || part >= (int)statusList_.size())return satisfyGlobal(require);
					return (
						(bool((0x80000000 & require) != 0) && bool((statusList_[part] & require) != 0)) || //������
						(bool((0x80000000 & require) == 0) && bool((statusList_[part] & require) == require))//������
						);
				}
				void setState(const int state)
				{
					state_ |= state;
					if (statusList_.empty())return;
					statusList_[currentIdx_] |= state;
				}
				void initialState(const unsigned size)
				{
					statusList_.resize(size);
					currentIdx_ = 0;
				}
				void nextState()
				{
					if (currentIdx_ + 1 < statusList_.size())return;
					++currentIdx_;
				}
				const unsigned pos_;//λ��
				mBattlePtr aim_;//Ŀ��
			private:
				unsigned currentIdx_;
				unsigned state_;//ȫ��״̬
				vector<int> statusList_;//���ܿ�״̬
			};
			void initialCurrentAim(const unsigned size)
			{
				aimPtr ptr = currenAim();
				if (!ptr)ptr->initialState(size);
			}
			bool satisfy(const int refaim, const int part, const unsigned require)
			{
				if (require == 0x0)return true;
				if (refaim < 0)return (currenAim() ? currenAim()->satisfy(part, require) : false);
				if (refaim >= (int)aim.size())return false;
				return aim[refaim]->satisfy(part, require);
			}
			aimPtr currenAim()
			{
				if (currentIdx < aim.size())return aim[currentIdx];
				return aimPtr();
			}
			aimPtr mainAim()
			{
				if (aim.empty())return aimPtr();
				return aim[0];
			}
			inline bool hasMainAim()
			{
				return !aim.empty();
			}
			inline void pushAim(aimPtr aPtr)
			{
				aim.push_back(Creator<aimData>::Create(aim.size(), aPtr));
			}
			inline void pushAim(mBattlePtr mPtr)
			{
				aim.push_back(Creator<aimData>::Create(aim.size(), mPtr));
			}
			inline void clearAim()
			{
				aim.clear();
			}
			inline unsigned sizeAim()
			{
				return aim.size();
			}
			inline bool noAim()
			{
				return aim.empty();
			}
			void copyAimTo(unitPtr uni, const bool nstate = true)
			{
				uni->clearAim();
				for (unsigned i = 0; i < aim.size(); ++i)
				{
					aimPtr c_aim = aim[i];
					if (nstate)uni->pushAim(c_aim->aim_);
					else uni->pushAim(c_aim);
				}
			}
			qValue toJaim()
			{
				qValue jaim(qJson::qj_array);
				for (unsigned i = 0; i < aim.size(); ++i)
				{
					jaim.append(aim[i]->aim_->currentIdx);
				}
				return jaim;
			}
			qValue junit_;//�����Ϣ//�ض����ڵ�
			const unsigned envIdx_;//��ǰ������idx
			const unsigned currentRound_;//��ǰ�غ�
			const sBattlePtr atkHand_, defHand_;//���ط�
			const unsigned counter_;//����������
			const bool bring_;//�Ƿ����������
		private:
			unsigned currentIdx;//��ǰĿ���IDX
			vector<aimPtr> aim;
		};

		class environment
		{
		public:
			environment(const unsigned round, const sBattlePtr atk,
				const sBattlePtr def, const bool action)
				:nowRound(round), handAtk(atk), handDef(def),isAction(action),
				jsonVal(qJson::qj_array)
			{
				pubPoolHP = 0;
				pubPoolMP = 0;
				unitList.clear();
			}
			~environment(){};
			unit::aimPtr FirstCounter()
			{
				for (unsigned i = 0; i < unitList.size(); ++i)
				{
					unitPtr ptr = unitList[i];
					unit::aimPtr aimMain = ptr->mainAim();
					if (!aimMain)continue;
					if (ptr->bring_ && aimMain->satisfyGlobal(ptr->counter_))return aimMain;
				}
				return unit::aimPtr();
			}
			inline mBattlePtr currentUser()
			{
				return handAtk->currentHand();
			}
			inline unsigned unitLength(){ return unitList.size(); }
			inline bool unitEmpty(){ return unitList.empty(); }
			unitPtr newUnit(const bool bring = false, const unsigned counter = 0)//���ӻ���
			{
				unitPtr ptr = Creator<unit>::Create(unitList.size(), nowRound, handAtk, handDef, bring, counter);
				unitList.push_back(ptr);
				return ptr;
			}
			unitPtr getUnit(const unsigned idx_)//��ȡ����
			{
				if (idx_ < unitList.size())return unitList[idx_];
				return unitPtr();
			}
			inline unsigned getNextIDX()
			{
				return unitList.size();
			}
			inline unsigned getUnitSize()
			{
				return unitList.size();
			}
			void jSkillDone()
			{
				for (unsigned i = 0; i < 1 && i < unitList.size(); ++i)
				{
					unitPtr uni = unitList[i];
					jsonVal.append(uni->toJaim()).
						append(uni->junit_);
				}
			}
			void jEffectDone()
			{
				qValue roundjson(qJson::qj_array);
				for (unsigned i = 0; i < unitList.size(); ++i)
				{
					unitPtr uni = unitList[i];
					roundjson.append(uni->junit_);
				}
				jsonVal.append(roundjson);
			}
			const bool isAction;//true �������� //false ��������
			const unsigned nowRound;//��ǰ�غ�
			const sBattlePtr handAtk, handDef;//���ط�
			int pubPoolHP;//Ѫ��
			int pubPoolMP;//����
			qValue jsonVal;//һ����������������
		private:
			vector<unitPtr> unitList;
		};
	}

	//battle data recall
	const static std::string strRpUnify = "temp/";
	static unsigned rpLoopID = 0;
	const string writeToFile(const string& report)
	{
		const static unsigned long mlength = 3145728;
		static unsigned char* buffer = (unsigned char*)::GNew(mlength);//3m
		rpLoopID = ++rpLoopID % 3000;
		const string ePath = strRpUnify + Common::toString(rpLoopID);
		const string tofilePath = strRpDirRoot + ePath;
		try
		{
			std::ofstream f(tofilePath.c_str(), std::ios::out | std::ios::trunc | std::ios::binary);
			unsigned long lsize = mlength;
			int res = compress(buffer, &lsize, (const unsigned char*)report.c_str(), report.length());
			if (res != Z_OK){
				LogE << "zlib compress failed ... error code :" << res << LogEnd;
				f.close();
				return "";
			}
			else{
				f.write((const char*)buffer, lsize);
				f.flush();
				f.close();
			}
		}
		catch (std::exception& e)
		{
			LogE << e.what() << LogEnd;
			return "";
		}
		return ePath;
	}

	static void noticeClient(const int type, const string report, Json::Value extra, std::set<int> noticeList, std::set<string> bkList)
	{
		string write_path = writeToFile(report);
		if (!write_path.empty())
		{
			const string fullPath_from = strRpDirRoot + write_path;
			Json::Value json;
			json[strMsg][0u] = res_sucess;
			json[strMsg][1u] = type;//ս������
			json[strMsg][2u] = write_path;//ս����ַ
			json[strMsg][3u] = extra;//��������
			Json::Value& bkjson = json[strMsg][4u] = Json::arrayValue;//���õ�ַ
			for(std::set<string>::iterator it = bkList.begin(); it != bkList.end(); ++it)
			{
				const string fullPath_to = strRpDirRoot + (*it);
				boost::system::error_code code;
				boost::filesystem::copy_file(fullPath_from, fullPath_to, boost::filesystem::copy_option::overwrite_if_exists, code);
				if (!code)
				{
					if (bkjson.size() < 10)bkjson.append(*it);
				}
				else
				{
					LogW << fullPath_from << "\tto\t" << fullPath_to << "\t" <<
						code.message() << LogEnd;//����
				}
			}
			detail::batchOnline(noticeList, json, gate_client::report_notice_resp);
		}
	}

	//battle data collection
	O2ORes BattleReport::One2One(sBattlePtr atk, sBattlePtr def, typeBattle::TYPE type, const unsigned runType /* = 0 */)
	{
		battleLogic logic(*this);
		return logic.One2One(atk, def, type, runType);
	}

	resBattle::RES BattleReport::Group2Group(teamSideBattle atk, teamSideBattle def, typeBattle::TYPE type, const unsigned step /* = 3 */, const unsigned runType /* = 0 */)
	{
		battleLogic logic(*this);
		return logic.Group2Group(atk, def, type, step, runType);
	}


	BattleReport::BattleReport()
	{
		resetO2OReport();
		resetT2TReport();
	}

	BattleData::envPtr BattleReport::PushEnv(BattleData::envPtr env)
	{
		seqENV_.push_back(env);
		return env;
	}

	void BattleReport::jDoneAndClear(qValue& reportDelare)
	{
		qValue round(qJson::qj_array);
		for (unsigned i = 0; i < seqENV_.size(); ++i)
		{
			qValue& qVal = seqENV_[i]->jsonVal;
			if (qVal.isEmpty())continue;
			round.append(qVal);
		}
		reportDelare.append(round);
		ClearActionEnv();
	}

	void BattleReport::ClearActionEnv()
	{
		seqENV_.clear();
	}

	void BattleReport::resetT2TReport()
	{
		reportTeam.toObject();
	}

	void BattleReport::resetO2OReport()
	{
		LastRound = 0;
		reportRoot.toObject();
		DamageResList.clear();
	}

	void BattleReport::addReportdeclare(const string key, qValue& json)
	{
		if (ReserveKey.find(key) != ReserveKey.end())return;
		reportRoot.removeMember(key);
		reportRoot.addMember(key, json);
	}
	void BattleReport::addReportdeclare(const string key, Json::Value& json)
	{
		if (ReserveKey.find(key) != ReserveKey.end())return;
		reportRoot.removeMember(key);
		string str_json = json.toIndentString();
		qValue toqV(str_json.c_str());
		reportRoot.addMember(key, toqV);
	}
	void BattleReport::addReportdeclare(const string key, const int val)
	{
		if (ReserveKey.find(key) != ReserveKey.end())return;
		reportRoot.removeMember(key);
		reportRoot.addMember(key, val);
	}

	void BattleReport::addReportdeclare(const string key, const unsigned val)
	{
		if (ReserveKey.find(key) != ReserveKey.end())return;
		reportRoot.removeMember(key);
		reportRoot.addMember(key, val);
	}

	void BattleReport::addReportdeclare(const string key, const double val)
	{
		if (ReserveKey.find(key) != ReserveKey.end())return;
		reportRoot.removeMember(key);
		reportRoot.addMember(key, val);
	}
	void BattleReport::addReportdeclare(const string key, const string str)
	{
		if (ReserveKey.find(key) != ReserveKey.end())return;
		reportRoot.removeMember(key);
		reportRoot.addMember(key, str);
	}

	void BattleReport::addReportdeclareT(const string key, qValue& json)
	{
		if (ReserveKeyT.find(key) != ReserveKeyT.end())return;
		reportTeam.removeMember(key);
		reportTeam.addMember(key, json);
	}
	void BattleReport::addReportdeclareT(const string key, Json::Value& json)
	{
		if (ReserveKeyT.find(key) != ReserveKeyT.end())return;
		reportTeam.removeMember(key);
		string str_json = json.toIndentString();
		qValue toqV(str_json.c_str());
		reportTeam.addMember(key, toqV);
	}
	void BattleReport::addReportdeclareT(const string key, const int val)
	{
		if (ReserveKeyT.find(key) != ReserveKeyT.end())return;
		reportTeam.removeMember(key);
		reportTeam.addMember(key, val);
	}
	void BattleReport::addReportdeclareT(const string key, const unsigned val)
	{
		if (ReserveKeyT.find(key) != ReserveKeyT.end())return;
		reportTeam.removeMember(key);
		reportTeam.addMember(key, val);
	}
	void BattleReport::addReportdeclareT(const string key, const double val)
	{
		if (ReserveKeyT.find(key) != ReserveKeyT.end())return;
		reportTeam.removeMember(key);
		reportTeam.addMember(key, val);
	}
	void BattleReport::addReportdeclareT(const string key, const string val)
	{
		if (ReserveKeyT.find(key) != ReserveKeyT.end())return;
		reportTeam.removeMember(key);
		reportTeam.addMember(key, val);
	}

	BattleReport& BattleReport::addNotice(const int playerID)
	{
		noticeList.insert(playerID);
		return *this;
	}

	BattleReport& BattleReport::addCopyField(const string toPath)
	{
		dirList.insert(toPath);
		return *this;
	}

	void BattleReport::Done(const typeBattle::TYPE type, Json::Value extra /* = Json::objectValue */)
	{
		const string str_report = reportRoot.toIndentString();
		reportPost(boostBind(noticeClient, type, str_report, extra, noticeList, dirList));
		dirList.clear();
		noticeList.clear();
	}

	void BattleReport::DoneT(const typeBattle::TYPE type, Json::Value extra /* = Json::objectValue */)
	{
		const string str_report = reportTeam.toIndentString();
		reportPost(boostBind(noticeClient, type, str_report, extra, noticeList, dirList));
		dirList.clear();
		noticeList.clear();
	}


	//man to do
	void manBattle::set_skill_1(const int id)
	{
		skill_1 = const_cast<skillDeclare*>(skill_mgr.getSkill(id));
	}

	void manBattle::set_skill_2(const int id)
	{
		skill_2 = const_cast<skillDeclare*>(skill_mgr.getSkill(id));
	}

	sideBattle::sideBattle()
	{
		playerFace = -1;
		playerID = -1;
		isPlayer = false;
		playerName = "";
		playerLevel = 0;
		playerNation = Kingdom::null;
		sideID = 0;
		battleMan.clear();
		for (unsigned x = 0; x < 3; ++x)
			for (unsigned y = 0; y < 3; ++y)
				deployment[x][y] = mBattlePtr();//�յ�
		findIdx = InvalidBattleIDX;
		settingIdx = InvalidBattleIDX;
		priorityIdx = InvalidBattleIDX;
		winNum = 0;
		winMax = 0;
		battleValue = 0;
		leaderMan = mBattlePtr();
	}

	void sideBattle::initial(const int side)
	{
		for (unsigned x = 0; x < 3; ++x)
			for (unsigned y = 0; y < 3; ++y)
				deployment[x][y] = mBattlePtr();//�յ�
		useManList.clear();

		for (unsigned i = 0; i < battleMan.size(); ++i)
		{
			mBattlePtr ptr = battleMan[i];
			ptr->orderPos(side);
			ptr->resetInitial();
			ptr->dispatchBuffs.clear();//��������¿�ʼս���Ļ�
			if (ptr->isDead())continue;
			if (deployment[ptr->X()][ptr->Y()])continue;
			deployment[ptr->X()][ptr->Y()] = ptr;
			useManList.push_back(ptr);
		}
		sideID = side;
		resetHand();
	}

	void sideBattle::resetHand()
	{
		findIdx = 0;
		settingIdx = InvalidBattleIDX;
		priorityIdx = InvalidBattleIDX;
	}

	void sideBattle::setLogDamage(int* pointer)
	{
		for (unsigned i = 0; i < battleMan.size(); ++i)
		{
			mBattlePtr ptr = battleMan[i];
			ptr->logDamage = pointer;
		}
	}

	void battleLogic::initData()
	{
		//ս���ؼ���
		{
			//���Ե�
			ReserveKey.insert("p");
			ReserveKey.insert("m");
			ReserveKey.insert("r");
			ReserveKey.insert("rl");
			ReserveKey.insert("t");
			ReserveKey.insert("st");
			ReserveKey.insert("al");
			ReserveKey.insert("dl");
			//��Զ�
			ReserveKeyT.insert("t");
			ReserveKeyT.insert("st");
			ReserveKeyT.insert("atk");
			ReserveKeyT.insert("def");
			ReserveKeyT.insert("rl");
			ReserveKeyT.insert("r");
		};

		rpLoopID = Common::randomBetween(0, 2999);
		//�����ļ���
		Common::createDirectories(strRpDirRoot + strRpUnify);

		cout << "load battle system" << endl;
		{//���ֿ��ƹ�ϵ��
			Json::Value json = Common::loadJsonFile("./instance/battle/soldier_restraint.json");
			for (unsigned i = 0; i < json.size(); ++i)
			{
				vector<armsRestraint> v_arms;
				for (unsigned n = 0; n < json[i].size(); ++n)
				{
					armsRestraint m;
					m.atkModule = json[i][n][0u].asDouble();
					m.defModule = json[i][n][1u].asDouble();
					v_arms.push_back(m);
				}
				armsR.push_back(v_arms);
			}
		};

		//Ŀ����Ѱ

		//���¶�λ
		newAimDeal[AIM::follow] = boostBind(battleLogic::aim_follow_new, _1, _2, _3, _4);//�޷������ڵ�һ������//��Ϊʼ�ն��ǿյ�Ŀ�����
		newAimDeal[AIM::single] = boostBind(battleLogic::aim_single_new, _1, _2, _3, _4);
		newAimDeal[AIM::line] = boostBind(battleLogic::aim_line_new, _1, _2, _3, _4);
		newAimDeal[AIM::row] = boostBind(battleLogic::aim_row_new, _1, _2, _3, _4);
		newAimDeal[AIM::cross] = boostBind(battleLogic::aim_cross_new, _1, _2, _3, _4);
		newAimDeal[AIM::current] = boostBind(battleLogic::aim_current_new, _1, _2, _3, _4);
		newAimDeal[AIM::all] = boostBind(battleLogic::aim_all_new, _1, _2, _3, _4);
		newAimDeal[AIM::other] = boostBind(battleLogic::aim_other_new, _1, _2, _3, _4);
		newAimDeal[AIM::random] = boostBind(battleLogic::aim_random_new, _1, _2, _3, _4);
		//ָ����Ŀ��
		signAimDeal[AIM::follow] = boostBind(battleLogic::aim_follow_sign, _1, _2, _3, _4);//�޷������ڵ�һ������//��Ϊʼ�ն��ǿյ�Ŀ�����
		signAimDeal[AIM::single] = boostBind(battleLogic::aim_single_sign, _1, _2, _3, _4);
		signAimDeal[AIM::line] = boostBind(battleLogic::aim_line_sign, _1, _2, _3, _4);
		signAimDeal[AIM::row] = boostBind(battleLogic::aim_row_sign, _1, _2, _3, _4);
		signAimDeal[AIM::cross] = boostBind(battleLogic::aim_cross_sign, _1, _2, _3, _4);
		signAimDeal[AIM::current] = boostBind(battleLogic::aim_current_sign, _1, _2, _3, _4);
		signAimDeal[AIM::all] = boostBind(battleLogic::aim_all_sign, _1, _2, _3, _4);
		signAimDeal[AIM::other] = boostBind(battleLogic::aim_other_sign, _1, _2, _3, _4);
		signAimDeal[AIM::random] = boostBind(battleLogic::aim_random_sign, _1, _2, _3, _4);


		//Ч��ִ��
		SkillDeal[SKILL::action_phy] = boostBind(battleLogic::phy_attack, _1, _2, _3, _4);
		SkillDeal[SKILL::action_war] = boostBind(battleLogic::war_attack, _1, _2, _3, _4);
		SkillDeal[SKILL::action_rage] = boostBind(battleLogic::rage_attack, _1, _2, _3, _4);
		SkillDeal[SKILL::action_magic] = boostBind(battleLogic::magic_attack, _1, _2, _3, _4);
		SkillDeal[SKILL::action_attack_mp] = boostBind(battleLogic::mp_attack, _1, _2, _3, _4);
		SkillDeal[SKILL::action_cure_hp] = boostBind(battleLogic::cure_hp, _1, _2, _3, _4);
		SkillDeal[SKILL::action_cure_mp] = boostBind(battleLogic::cure_mp, _1, _2, _3, _4);
		SkillDeal[SKILL::action_absorb_hp] = boostBind(battleLogic::absorb_hp, _1, _2, _3, _4);
		SkillDeal[SKILL::action_absorb_mp] = boostBind(battleLogic::absorb_mp, _1, _2, _3, _4);
		SkillDeal[SKILL::action_child_skill] = boostBind(battleLogic::child_skill, _1, _2, _3, _4);
		SkillDeal[SKILL::action_set_buff] = boostBind(battleLogic::set_buff, _1, _2, _3, _4);
		SkillDeal[SKILL::action_direct_damage] = boostBind(battleLogic::direct_attack, _1, _2, _3, _4);
		SkillDeal[SKILL::action_shield] = boostBind(battleLogic::add_shield, _1, _2, _3, _4);
		SkillDeal[SKILL::action_mp_set] = boostBind(battleLogic::mp_set, _1, _2, _3, _4);
		SkillDeal[SKILL::action_alter_mp_formula_1] = boostBind(battleLogic::mp_alter_formula_1, _1, _2, _3, _4);

		//buffЧ��
		EffectRun[BUFF::stun] = boostBind(battleLogic::effect_stun, _1, _2, _3, _4, _5, _6);
		EffectRun[BUFF::last_alter_hp] = boostBind(battleLogic::effect_alter_hp, _1, _2, _3, _4, _5, _6);
		EffectRun[BUFF::last_alter_mp] = boostBind(battleLogic::effect_alter_mp, _1, _2, _3, _4, _5, _6);

		//buffע��
		RegEffect[BUFF::stun] = boostBind(battleLogic::stun_regist, _1, _2, _3, _4, _5, _6);
		RegEffect[BUFF::bonus_attri] = boostBind(battleLogic::bonus_attri_regist, _1, _2, _3, _4, _5, _6);
		RegEffect[BUFF::bonus_attri_rate] = boostBind(battleLogic::bonus_attri_rate_regist, _1, _2, _3, _4, _5, _6);
		RegEffect[BUFF::last_alter_hp] = boostBind(battleLogic::last_alter_regist, _1, _2, _3, _4, _5, _6);
		RegEffect[BUFF::last_alter_mp] = boostBind(battleLogic::last_alter_regist, _1, _2, _3, _4, _5, _6);

		//buff ��ע��
		AntiRegEffect[BUFF::stun] = boostBind(battleLogic::stun_antiregist, _1, _2, _3);
		AntiRegEffect[BUFF::bonus_attri] = boostBind(battleLogic::bonus_attri_antiregist, _1, _2, _3);
		AntiRegEffect[BUFF::bonus_attri_rate] = boostBind(battleLogic::bonus_attri_rate_antiregist, _1, _2, _3);

		//ʩ��ʱʩ��������
		UserRun[SKILL::limit_user_alive] = boostBind(battleLogic::user_alive, _1, _2, _3);
		UserRun[SKILL::limit_aim_alive] = boostBind(battleLogic::aim_alive, _1, _2, _3);
		UserRun[SKILL::limit_user_hp_greater] = boostBind(battleLogic::user_hp_greater, _1, _2, _3);
		UserRun[SKILL::limit_user_hp_less] = boostBind(battleLogic::user_hp_less, _1, _2, _3);
		UserRun[SKILL::limit_user_hp_equal] = boostBind(battleLogic::user_hp_equal, _1, _2, _3);

		//����ս������
		mapPerDeal[runBattle::hp_recovery] = boostBind(battleLogic::per_hp_recovery, _1, _2);
	}

	void battleLogic::per_hp_recovery(sBattlePtr atk, sBattlePtr def)
	{
		for (unsigned i = 0; i < atk->battleMan.size(); ++i)
		{
			mBattlePtr man = atk->battleMan[i];
			man->currentHP = man->getTotalAttri(idx_hp);
		}
		for (unsigned i = 0; i < def->battleMan.size(); ++i)
		{
			mBattlePtr man = def->battleMan[i];
			man->currentHP = man->getTotalAttri(idx_hp);
		}
	}

	sBattlePtr popToList(teamSideBattle& back)
	{
		if (!back.empty())
		{
			sBattlePtr sb = *back.begin();
			back.erase(back.begin());
			return sb;
		}
		return sBattlePtr();
	}

	resBattle::RES battleLogic::Group2Group(teamSideBattle atk, teamSideBattle def, typeBattle::TYPE type, 
		const unsigned step /* = 3 */, const unsigned runType /* = 0 */)
	{
		resBattle::RES battleResult = resBattle::def_win;//ս�����
		reportData.resetT2TReport();
		qValue& reportTeam = reportData.reportTeam;
		reportTeam.addMember("t", type);
		{
			qValue jT(qJson::qj_array);
			for (unsigned i = 0; i < atk.size(); ++i)
			{
				qValue jM(qJson::qj_array);
				sBattlePtr sb = atk[i];
				jM.append(sb->playerID).append(sb->playerName).append(sb->isPlayer).
					append(sb->playerNation);
				qValue mainMan(qJson::qj_array);
				if (sb->leaderMan)
				{
					mBattlePtr man = sb->leaderMan;
					const BattleEquipList& equipList = man->equipList;
					qValue eqList_json(qJson::qj_array);
					for (unsigned pos = 0; pos < equipList.size(); ++pos)
					{
						qValue sg_eq_json(qJson::qj_array);
						const BattleEquip& def = equipList[pos];
						sg_eq_json.append(def.equipPos).append(def.equipID).append(def.equipLevel);
						eqList_json.append(sg_eq_json);
					}
					mainMan.append(man->manID);
					mainMan.append(eqList_json);
				}
				jM.append(mainMan);
				jT.append(jM);
			}
			reportTeam.addMember("atk", jT);
		};
		{
			qValue jT(qJson::qj_array);
			for (unsigned i = 0; i < def.size(); ++i)
			{
				qValue jM(qJson::qj_array);
				sBattlePtr sb = def[i];
				jM.append(sb->playerID).append(sb->playerName).append(sb->isPlayer).
					append(sb->playerNation);
				qValue mainMan(qJson::qj_array);
				if (sb->leaderMan)
				{
					mBattlePtr man = sb->leaderMan;
					const BattleEquipList& equipList = man->equipList;
					qValue eqList_json(qJson::qj_array);
					for (unsigned pos = 0; pos < equipList.size(); ++pos)
					{
						qValue sg_eq_json(qJson::qj_array);
						const BattleEquip& def = equipList[pos];
						sg_eq_json.append(def.equipPos).append(def.equipID).append(def.equipLevel);
						eqList_json.append(sg_eq_json);
					}
					mainMan.append(man->manID);
					mainMan.append(eqList_json);
				}
				jM.append(mainMan);
				jT.append(jM);
			}
			reportTeam.addMember("def", jT);
		};
		const unsigned real_run = runType;//��ʵִ��
		const unsigned real_step = step < 1 ? 1 : step;
		reportTeam.addMember("st", real_step);//n �� n
		teamSideBattle atkCopy = atk;
		teamSideBattle defCopy = def;
		teamSideBattle atkField;
		teamSideBattle defField;
		atkField.resize(real_step);
		defField.resize(real_step);
		vector<qValue> declareFiled;
		declareFiled.resize(real_step);
		for (unsigned i = 0; i < declareFiled.size(); ++i)
		{
			declareFiled[i].toArray();
		}
		while (true)
		{
			for (unsigned i = 0; i < real_step; i++)//���Ŀ��
			{
				if (!atkField[i])atkField[i] = popToList(atkCopy);
				if (!defField[i])defField[i] = popToList(defCopy);
			}
			for (unsigned i = 0; i < real_step; ++i)//����Ŀ��
			{
				if (atkField[i] && !defField[i])
				{
					for (unsigned di = 0; di < real_step; ++di)
					{
						if (defField[di] && !atkField[di])
						{
							defField[i] = defField[di];
							defField[di] = sBattlePtr();
							break;
						}
					}
				}
			}//Ŀ�����
			bool isBreak = true;
			for (unsigned i = 0; i < atkField.size(); ++i)
			{
				if (atkField[i])
				{
					isBreak = false;
					break;
				}
			}
			if (isBreak)
			{
				battleResult = resBattle::def_win;
				break;
			}
			isBreak = true;
			for (unsigned i = 0; i < defField.size(); ++i)
			{
				if (defField[i])
				{
					isBreak = false;
					break;
				}
			}
			if (isBreak)
			{
				battleResult = resBattle::atk_win;
				break;
			}
			for (unsigned idx = 0; idx < real_step; ++idx)//ս��
			{
				sBattlePtr c_atk = atkField[idx];
				sBattlePtr c_def = defField[idx];
				O2ORes res = One2One(c_atk, c_def, typeBattle::child_battle, real_run);
				if (c_atk)reportData.addReportdeclare("akwn", c_atk->winNum);
				if (c_def)reportData.addReportdeclare("dfwn", c_def->winNum);
				if (c_atk || c_def)
				{
					if (resBattle::atk_win == res.res)
					{
						if (c_def)//���û�ж��ֲ���Ӯ
						{
							++c_atk->winNum;
						}
						if (c_atk->overWin())
						{
							atkField[idx] = sBattlePtr();
							reportData.addReportdeclare("tat", BATTLEEVENT::leave);
						}
						else
						{
							reportData.addReportdeclare("tat", BATTLEEVENT::nothing);
						}
						defField[idx] = sBattlePtr();
						reportData.addReportdeclare("tdt", BATTLEEVENT::lose);
					}
					else if (resBattle::def_win == res.res)
					{
						if (c_atk)//���û�ж��ֲ���Ӯ
						{
							++c_def->winNum;
						}
						if (c_def->overWin())
						{
							defField[idx] = sBattlePtr();
							reportData.addReportdeclare("tdt", BATTLEEVENT::leave);
						}
						else
						{
							reportData.addReportdeclare("tdt", BATTLEEVENT::nothing);
						}
						atkField[idx] = sBattlePtr();
						reportData.addReportdeclare("tat", BATTLEEVENT::lose);
					}
				}
				declareFiled[idx].append(reportData.reportRoot);
			}
		}
		qValue reportTeamR(qJson::qj_array);
		for (unsigned i = 0; i < declareFiled.size(); ++i)
		{
			reportTeamR.append(declareFiled[i]);
		}
		reportTeam.addMember("r", reportTeamR);//ս�����
		reportTeam.addMember("rl", battleResult);//ս�����
		return battleResult;
	}

	int getLoseHP(const manList& battleList)
	{
		int num = 0;
		for (manList::const_iterator it = battleList.begin(); it != battleList.end(); it++)
		{
			mBattlePtr m = *it;
			num += m->loseHP();
		}
		return num;
	}

	int getStar(const manList& battleList)
	{
		int deadT = 0;
		for (manList::const_iterator it = battleList.begin(); it != battleList.end(); it++)
		{
			const mBattlePtr m = *it;
			if (m->isDead()) ++deadT;
		}
		//if (deadT > 4)return 0;
		if (deadT > 3)return 1;//4,5,6,7...etc
		if (deadT > 2)return 2;
		if (deadT > 1)return 3;
		if (deadT > 0)return 4;
		return 5;
	}

	O2ORes battleLogic::One2One(sBattlePtr atk, sBattlePtr def, typeBattle::TYPE type, const unsigned runType /* = 0 */)
	{
		reportData.resetO2OReport();
		reportData.ClearActionEnv();
		qValue& reportRoot = reportData.reportRoot;
		if (!atk && !def)O2ORes(resBattle::res_unknown, 0);
		qValue jPlayer(qJson::qj_array);
		{
			qValue jSide(qJson::qj_array);
			if (atk)
				jSide.append(atk->playerID).
				append(atk->playerName).
				append(atk->playerLevel).
				append(atk->isPlayer).
				append(atk->battleValue).
				append(atk->playerFace);
			jPlayer.append(jSide);
		};
		{
			qValue jSide(qJson::qj_array);
			if(def)
				jSide.append(def->playerID).
				append(def->playerName).
				append(def->playerLevel).
				append(def->isPlayer).
				append(def->battleValue).
				append(def->playerFace);
			jPlayer.append(jSide);
		};
		reportRoot.addMember("p", jPlayer);
		reportRoot.addMember("t", type);

		qValue jDeployment(qJson::qj_array);
		//������
		if (atk)
		{
			atk->initial(0);//�����ʼ������ҵĶ�λ
			for (unsigned i = 0; i < atk->useManList.size(); ++i)
			{
				mBattlePtr man = atk->useManList[i];
				if (man->isDead())continue;
				qValue jMan(qJson::qj_array);
				jMan.append(man->currentIdx).append(man->manID).append(man->manLevel).append(man->currentHP).
					append(man->getTotalAttri(idx_hp)).append(man->holdMorale).append(man->irrelateMorale()).append(man->shield);
				const BattleEquipList& equipList = man->equipList;
				qValue eqList_json(qJson::qj_array);
				for (unsigned pos = 0; pos < equipList.size(); ++pos)
				{
					qValue sg_eq_json(qJson::qj_array);
					const BattleEquip& def = equipList[pos];
					sg_eq_json.append(def.equipPos).append(def.equipID).append(def.equipLevel);
					eqList_json.append(sg_eq_json);
				}
				jMan.append(man->battleValue);
				jMan.append(eqList_json);
				jDeployment.append(jMan);
			}
		}
		//���ط�
		if (def)
		{
			def->initial(1);
			for (unsigned i = 0; i < def->useManList.size(); ++i)
			{
				mBattlePtr man = def->useManList[i];
				if (man->isDead())continue;
				qValue jMan(qJson::qj_array);
				jMan.append(man->currentIdx).append(man->manID).append(man->manLevel).append(man->currentHP).
					append(man->getTotalAttri(idx_hp)).append(man->holdMorale).append(man->irrelateMorale()).append(man->shield);
				const BattleEquipList& equipList = man->equipList;
				qValue eqList_json(qJson::qj_array);
				for (unsigned pos = 0; pos < equipList.size(); ++pos)
				{
					qValue sg_eq_json(qJson::qj_array);
					const BattleEquip& def = equipList[pos];
					sg_eq_json.append(def.equipPos).append(def.equipID).append(def.equipLevel);
					eqList_json.append(sg_eq_json);
				}
				jMan.append(man->battleValue);
				jMan.append(eqList_json);
				jDeployment.append(jMan);
			}
		}
		reportRoot.addMember("m", jDeployment);
		if (!atk)return O2ORes(resBattle::def_win, 0);
		if (!def)return O2ORes(resBattle::atk_win, 0);

		qValue reportDelare(qJson::qj_array);//ս���������
		resBattle::RES battleResult = resBattle::def_win;//ս�����
		for (unsigned r = 0; ; ++r)
		{
			if (atk->isDeadAll())
			{
				battleResult = resBattle::def_win;
				break;
			}
			if (def->isDeadAll())
			{
				battleResult = resBattle::atk_win;
				break;
			}
			if (BigRound_ == r)break;
			reportData.LastRound = r + 1;
			reportData.DamageResList.push_back(O2ODamageRes());
			atk->resetHand();//����
			atk->setLogDamage(&(reportData.DamageResList[r].atkDamage));
			def->resetHand();//����
			def->setLogDamage(&(reportData.DamageResList[r].defDamage));
			for (unsigned l = 0; l < LittleRound_; ++l)
			{
				//����ѭ��
				if (begin_attack(atk, def, r + 1))break;
				if (begin_attack(def, atk, r + 1))break;
			}
			reportData.jDoneAndClear(reportDelare);//�ѵ�ǰ�غϵ���Ϣд��ս��
		}
		reportRoot.addMember("r", reportDelare);//����û����ȸ���//
		reportRoot.addMember("rl", battleResult);
		for (unsigned i = 0; i < 10; ++i)
		{
			unsigned sign = (0x0001 << i) & runType;
			if (!sign)continue;
			perDealMap::iterator it = mapPerDeal.find(sign);
			if (it != mapPerDeal.end())
			{
				it->second(atk, def);
			}
		}
		int star = 0;
		if (resBattle::atk_win == battleResult)star = getStar(atk->useManList);
		if (resBattle::def_win == battleResult)star = -getStar(def->useManList);
		reportRoot.addMember("st", star);
		reportRoot.addMember("al", getLoseHP(atk->useManList));
		reportRoot.addMember("dl", getLoseHP(def->useManList));
		return O2ORes(battleResult, star);
	}

	void battleLogic::effect_to_clear(const unsigned round, sBattlePtr atk, sBattlePtr def, mBattlePtr user)
	{
		std::list<ptrManBuff>& checkList = user->dispatchBuffs;
		if (checkList.empty())return;
		boost::unordered_map<manBattle*, qValue> clearJsonMap;
		for (std::list<ptrManBuff>::iterator it = checkList.begin(); it != checkList.end();)
		{
			ptrManBuff ptr_buff = *it;
			const int buffID = ptr_buff->declare->buffID;
			if (ptr_buff->holderMan->isDead())
			{
				checkList.erase(it++);
				continue;
			}
			manBattle* const man_pointer = ptr_buff->holderMan;
			ptrManBuff compare_buff = man_pointer->getEffect(buffID);
			if (!compare_buff || ptr_buff != compare_buff)//�Ҳ������buff ���� �ҵ���buff�����
			{
				checkList.erase(it++);
				continue;
			}
			if (ptr_buff->isNew)
			{
				++it;
				ptr_buff->isNew = false;
				continue;
			}
			if(ptr_buff->lastRound > 0)--ptr_buff->lastRound;//û������ʱ��, ���ʱ��ض�����
			if (ptr_buff->lastRound < 1)
			{
				man_pointer->holdBuffs.erase(buffID);
				checkList.erase(it++);
				qValue& json = clearJsonMap[man_pointer];
				if (json.isEmpty())
				{
					json.toArray();
				}
				json.append(buffID);
				//����д��ɾ����Ϣ
				AntiRegEffectMap::iterator ef_it = AntiRegEffect.find(buffID % BUFF::BUFFOFFSET);//��ע��buff
				if (ef_it != AntiRegEffect.end())
				{
					ef_it->second(this, man_pointer->OwnPtr(), ptr_buff);
				}
			}
			else
			{
				++it;
			}
		}
		for (boost::unordered_map<manBattle*, qValue>::iterator 
			it = clearJsonMap.begin(); 
			it != clearJsonMap.end(); 
			++it)
		{
			reportData.PushEnv(Creator<BattleData::environment>::Create(round, atk, def, true))->
				jsonVal.append(it->first->currentIdx).append(BATTLEEVENT::effect_delete).append(it->second);
		}
	}

	void battleLogic::effect_to_run(const unsigned round, sBattlePtr atk, sBattlePtr def, mBattlePtr user, const unsigned sr)
	{
		BattleData::envPtr run_env = Creator<BattleData::environment>::Create(round, atk, def, (sr & BUFF::attack_round) > 0);//ִ��run
		run_env->jsonVal.append(user->currentIdx).append(BATTLEEVENT::effect_run);
		//Ҫ����map
		manBattle::HoldBuffMap& EffectMap = user->holdBuffs;
		for (manBattle::HoldBuffMap::const_iterator it = EffectMap.begin(); it != EffectMap.end();)
		{
			ptrManBuff ef = it->second.lock();
			if (!ef)
			{
				EffectMap.erase(it++);
				continue;
			}
			const int buffID = ef->declare->buffID;
			const int effectID = buffID % BUFF::BUFFOFFSET;

			//��ִ��
			const bool runOK = (
				sr > 0 && //����Ҫ��Ч
				(ef->declare->runTick & sr) == sr
				);
			if (runOK)
			{
				EffectRunMap::iterator find_deal = EffectRun.find(effectID);
				if (find_deal != EffectRun.end())
				{
					BattleData::unitPtr uni = run_env->newUnit();
					uni->junit_.append(buffID);
					find_deal->second(this, run_env, uni, user, ef, sr);
				}
			}
			++it;
		}
		run_env->jEffectDone();
		if (!run_env->unitEmpty())//�Ż�����Ҫ������
		{
			reportData.PushEnv(run_env);
		}
	}

	void battleLogic::effect_stun(battleLogic* logic, BattleData::envPtr env, BattleData::unitPtr uni, mBattlePtr user, ptrManBuff ef, const unsigned sr)
	{
		const BUFF::Data& config = *(ef->declare);
		const BUFF::stunEffect& stunCfg = config.otherData._stun;//����
		MANEFFECT::Stun& stunData = ef->otherData._stun;//�佫״̬
		const unsigned type_add = stunCfg.stateLock;//����״̬

		if ((stunCfg.stunClear & sr) == sr)//����
		{
			if (stunData.isEffect && stunData.tickTimes > 0)
			{
				stunData.isEffect = false;
				for (unsigned i = 0; i < BUFF::lock_type_num; i++)
				{
					const unsigned check_type = 0x0001 << i;
					if ((type_add & check_type) > 0)
					{
						user->minusLockType((BUFF::lockType)check_type);
					}
				}
			}
		}

		if ((stunCfg.stunRun & sr) == sr)//��Ч
		{
			if (stunData.tickTimes > 0)
			{
				if (false == stunData.isEffect && Common::randomOk(stunCfg.effectRate))
				{
					stunData.isEffect = true;
					for (unsigned i = 0; i < BUFF::lock_type_num; i++)
					{
						const unsigned check_type = 0x0001 << i;
						if ((type_add & check_type) > 0)
						{
							user->plusLockType((BUFF::lockType)check_type);
						}
					}
				}
			}
			else
			{
				++stunData.tickTimes;
			}
		}
	}

	void battleLogic::effect_alter_hp(battleLogic* logic, BattleData::envPtr env, BattleData::unitPtr uni, mBattlePtr user, ptrManBuff ef, const unsigned sr)
	{
		const BUFF::Data& config = *(ef->declare);
		const int alter_num = ef->otherData._value.valEffect;
		if (0 != alter_num)
		{
			user->alterHP(alter_num);
			qValue qVal(qJson::qj_array);
			qVal.append(user->currentIdx).append(BATTLEEVENT::hp_alter).append(BATTLEEVENT::hp_effect).
				append(alter_num).append(user->currentHP);
			uni->junit_.append(qVal);
		}
	}

	void battleLogic::effect_alter_mp(battleLogic* logic, BattleData::envPtr env, BattleData::unitPtr uni, mBattlePtr user, ptrManBuff ef, const unsigned sr)
	{
		const BUFF::Data& config = *(ef->declare);
		const int alter_num = ef->otherData._value.valEffect;;
		if (0 != alter_num)
		{
			user->alterMorale(alter_num);
			qValue qVal(qJson::qj_array);
			qVal.append(user->currentIdx).append(BATTLEEVENT::mp_alter).append(BATTLEEVENT::mp_effect).
				append(alter_num).append(user->irrelateMorale());
			uni->junit_.append(qVal);
		}
	}

	bool battleLogic::begin_attack(sBattlePtr atk, sBattlePtr def, const unsigned round)
	{
		if (atk->isDeadAll() || def->isDeadAll())return true;//��һ��������
		while (atk->toNextHand())//����һ��Ŀ��
		{
			mBattlePtr user = atk->currentHand();//ֻ��һ����ǰʩ����
			if (user->isDead())
			{
				effect_to_clear(round, atk, def, user);
				continue;
			}
			on_attack(atk, def, round, true);//ִ��
			effect_to_clear(round, atk, def, user);
			break;
		}
		return false;
	}

	void battleLogic::on_attack(sBattlePtr atk, sBattlePtr def, const unsigned round, const bool ac, mBattlePtr sign_aim /* = mBattlePtr() */)//���������￪ʼ
	{
		const unsigned action_type = ac ? BUFF::attack_round : BUFF::counter_round;
		mBattlePtr user = atk->currentHand();//ֻ��һ����ǰʩ����
		effect_to_run(round, atk, def, user, action_type | BUFF::action_begin);//�������� ����Ҳ�����buff
		if (user->checkLockType(BUFF::lock_action))
		{
			//user->stateLock = 0;
			BattleData::envPtr env = reportData.PushEnv(Creator<BattleData::environment>::Create(round, atk, def, ac));
			env->jsonVal.append(user->currentIdx).append(BATTLEEVENT::user_lock);
			effect_to_run(round, atk, def, user, action_type | BUFF::action_end);
			return;
		}
		BattleData::envPtr env = reportData.PushEnv(Creator<BattleData::environment>::Create(round, atk, def, ac));
		const skillDeclare* skill = user->useSkill();
		if (!skill)return;
		if (user->isDead())return;
		const bool useSkill = user->isUsePowerSkill();
		if (ac)
			env->jsonVal.append(user->currentIdx).append(BATTLEEVENT::attack).append(skill->skillID).append(useSkill);
		else
			env->jsonVal.append(user->currentIdx).append(BATTLEEVENT::counter_attack).append(skill->skillID).append(useSkill);
		on_detail_attack(env, skill->skillRun, sign_aim, true);
		env->jSkillDone();
	}

	void battleLogic::on_detail_attack(BattleData::envPtr env, const SKILL::skillEntity& entity, 
		mBattlePtr sign_aim /* = mBattlePtr() */, const bool is_main /* = false */)
		//�Ӽ��ܴ����￪ʼ
	{
		BattleData::unitPtr uni = env->newUnit(entity.bringCounter, entity.counterLimit);
		find_aim(this, env, uni, entity.aim, sign_aim);//���ﱣ֤���ݶ�����Ч��
		mBattlePtr user = env->currentUser();
		if (is_main && user->isUsePowerSkill())
		{
			qValue val(qJson::qj_array);
			val.append(user->currentIdx).append(BATTLEEVENT::mp_alter).append(BATTLEEVENT::mp_power).
				append(-user->useSkillMorale()).append(user->irrelateMorale());
			uni->junit_.append(val);//ʿ������		
		}
		if (!uni->noAim())
		{
			run_attack(env, uni, entity.entity);//ֻ������������ִ��Ч��
		}
		else
		{
			run_attack_no_aim(env, uni, entity.entity);//����ֻ�Ǽ���Ƿ������������Ӽ��ܿ��Է���
		}
		if (is_main)
		{
			end_attack(env);//�����ͷŽ���
		}
	}

	void battleLogic::end_attack(BattleData::envPtr env)
	{
		//��������
		const unsigned action_type = env->isAction ? BUFF::attack_round : BUFF::counter_round;
		mBattlePtr user = env->currentUser();//��ǰʩ����
		user->skillEnd();//ʹ�����Ǽ��ܵı仯
		effect_to_run(env->nowRound, env->handAtk, env->handDef, user, action_type | BUFF::action_end);//����ִ����Ч���ڵ�buffЧ��
		if (env->isAction)
		{
			do
			{
				if (env->handAtk->isDeadAll() || env->handDef->isDeadAll())break;
				BattleData::unit::aimPtr uni = env->FirstCounter();//��һ��������//�����Ѿ����˷����ж�
				if (!uni)break;
				mBattlePtr aim = uni->aim_;
				if (
					aim && !aim->isDead() &&
					!aim->checkLockType(BUFF::lock_couter) &&//Ŀ�꽡��
					user && !user->isDead() && //ʩ���߽���
					Common::randomOk(aim->getTotalAttri(idx_counter))
					)
				{
					env->handDef->setPriorityIDX(aim);
					on_attack(env->handDef, env->handAtk, env->nowRound, false, user);
					env->handDef->clearPriorityIDX();
				}
			} while (false);
		}
	}

	void battleLogic::run_attack_no_aim(BattleData::envPtr env, BattleData::unitPtr uni, const SKILL::skillEntity::entityList& declare)
	{
		mBattlePtr user = env->currentUser();
		for (unsigned n = 0; n < declare.size(); ++n)//�����Ӽ���
		{
			const SKILL::declare& decl = declare[n];//��ǰ���ܶ�
			const int runID = decl._Base.runID;
			if (runID == SKILL::action_child_skill)
			{
				if (decl._Base.dependent)//�����ļ���
				{
					if (//�����ͷųɹ����
						onRun(env, uni, decl, user, mBattlePtr()) == intercept
						)continue;
					qValue qUser(qJson::qj_array);
					qUser.append(user->currentIdx).append(BATTLEEVENT::user_child).append(decl._Child.childID);//ʹ�ü���
					const unsigned future_idx = env->getNextIDX();
					on_detail_attack(env, *decl._Child.child);
					BattleData::unitPtr last = env->getUnit(future_idx);
					if (!last->junit_.isEmpty())
					{
						qUser.append(last->toJaim()).
							append(last->junit_);
						uni->junit_.append(qUser);
					}
				}
			}
		}
	}

	void battleLogic::run_attack(BattleData::envPtr env, BattleData::unitPtr uni, const SKILL::skillEntity::entityList& declare)
	{
		sBattlePtr atk = env->handAtk;
		sBattlePtr def = env->handDef;
		mBattlePtr user = env->currentUser();
		while (uni->currenAim())
		{
			BattleData::unit::aimPtr aim = uni->currenAim();
			aim->initialState(declare.size());
			for (unsigned n = 0; n < declare.size(); ++n)
			{
				const SKILL::declare& decl = declare[n];
				mBattlePtr cr_aim = aim->aim_;
				if (!user_runOK(this, user, cr_aim, decl))continue;
//				if (aim->satisfyGlobal(SKILL::ref_dead) && SKILL::action_child_skill != decl._Base.runID)continue;
				if (
					!(
					(SKILL::aim_expect_main == decl._Base.sign && uni->currentIDX() != 0) ||
					(SKILL::aim_last == decl._Base.sign && uni->isLastAim()) ||
					(SKILL::aim_all == decl._Base.sign) ||
					(uni->currentIDX() == decl._Base.sign)
					)
					)
				{//��ЧĿ�긲��
					aim->setState(SKILL::ref_not_satisfy_sign);
					continue;
				}
				if (!uni->satisfy(decl._Base.refaim, decl._Base.refdelare, decl._Base.condition))//����������
				{
					aim->setState(SKILL::ref_not_satisfy);
					continue;
				}//�����ж��Ƿ��л���//�������ô�滻Ŀ��
				SkillDealMap::iterator it = SkillDeal.find(decl._Base.runID);
				if (it != SkillDeal.end())
				{
					it->second(this, env, uni, decl);
				}
				if (user->aliveToDead())
				{
					aim->setState(SKILL::ref_user_dead);
					qValue dead_value(qJson::qj_array);
					dead_value.append(user->currentIdx).append(BATTLEEVENT::dead);
					uni->junit_.append(dead_value);
				}
				if (cr_aim->aliveToDead())
				{
					aim->setState(SKILL::ref_dead);
					qValue dead_value(qJson::qj_array);
					dead_value.append(cr_aim->currentIdx).append(BATTLEEVENT::dead);
					uni->junit_.append(dead_value);
				}
				aim->nextState();
			}
			uni->nextAim();
		}
	}

	double battleLogic::calArmsRes(const int atk_type, const int aim_type)
	{
		double atk_module = 0.0;
		double aim_module = 0.0;
		if (atk_type >= 0 && atk_type < (int)armsR.size() && aim_type < (int)armsR[atk_type].size())
		{
			atk_module = armsR[atk_type][aim_type].atkModule;
		}
		if (aim_type >= 0 && aim_type < (int)armsR.size() && atk_type < (int)armsR[aim_type].size())
		{
			aim_module = armsR[aim_type][atk_type].defModule;
		}
		double module = 1.0 + atk_module - aim_module;
		return module < 0.0 ? 0.0 : module;
	}

	int battleLogic::damageFM( 
		BattleData::envPtr ptr, BattleData::unitPtr uni, const SKILL::declare& declare, 
		mBattlePtr user, const AttributeIDX user_pro, const AttributeIDX user_atk, const AttributeIDX user_final, const AttributeIDX user_final_val, const ArmsModule user_midx,
		mBattlePtr aim, const AttributeIDX aim_pro, const AttributeIDX aim_def, const AttributeIDX aim_final, const AttributeIDX aim_final_val, const ArmsModule aim_midx,
		const double damageRate /*= 1.0*/
		)
	{
		//1 45���� //2 67ս�� //3 89ħ�� //������
		double talent = (
			1 +
			(user->getTotalAttri(user_pro) - aim->getTotalAttri(aim_pro)) * 0.0045 +
			(user->getTalent(user_pro) - aim->getTalent(aim_pro))*0.0025
			);
		talent = talent < 0.1 ? 0.1 : talent;

		//���Բ�
		double atrr_diff = user->getTotalAttri(user_atk) * 0.5 -
			aim->getTotalAttri(aim_def) * 0.5 + 50.0;
		if (atrr_diff < 50.0)
			atrr_diff = (user->getTotalAttri(user_atk) * 0.5 + 50.0) * 50.0 /
			(aim->getTotalAttri(aim_def) * 0.5 + 50.0);
		//���ֲ�
		double arms_diff = user->getModule(user_midx) - aim->getModule(aim_midx);
		arms_diff = arms_diff < 0.0 ? 0.0 : arms_diff;
		//hp����Ӱ��
		double rm_percent = (0.7 + 0.3 * (double)user->currentHP / user->getTotalAttri(idx_hp));
		//�غ���Ӱ��
		double round_eff = (ptr->nowRound - 1)*0.03 + 1;
		//���ñ�//����ϵ��//����ϵ��
		const bool tick_cri = !aim->checkLockType(BUFF::lock_crit) && (declare._Attack.critical && Common::randomOk(user->getTotalAttri(idx_crit)));
		//���հٷֱ�ѪԽ���˺�Խ��
		double backHitModule = 1.0;
		if (0.0 != declare._Attack.againstModule)
		{
			backHitModule = 1.0 + int((double)user->loseHP() / user->getTotalAttri(idx_hp) * 100) * declare._Attack.againstModule;
		}
		//ʿ���˺�����
		double  moraleModule = 1.0;
		if (declare._Attack.moraleJoin)
		{
			moraleModule = 1.0 + (double)(user->totalMorale() - 100)*0.004;
		}
		//�����˺�
		double finalDamageModule = 1.0 + (user->getTotalAttri(user_final) - aim->getTotalAttri(aim_final)) / 10000.0;
		finalDamageModule = finalDamageModule < 0.0 ? 0.0 : finalDamageModule;
		int finalDamageVal = user->getTotalAttri(user_final_val) - aim->getTotalAttri(aim_final_val);
		finalDamageVal = finalDamageVal < 0 ? 0 : finalDamageVal;
		//������BUFF//�����

		//�������
		double armsR = calArmsRes(user->armsType, aim->armsType);

		//�ȼ�˥��
		double  damageDecay = 1.0;
		if (0.0 != declare._Attack.damageDecay)
		{
			damageDecay = 1.0 - user->manLevel * declare._Attack.damageDecay;
			damageDecay = damageDecay < 0.5 ? 0.5 : damageDecay;
			damageDecay = damageDecay > 1.0 ? 1.0 : damageDecay;
		}

		//����ϵ�� * hp����Ӱ�� * �غ���Ӱ�� * ����ϵ�� * ��ˮһսϵ�� * �������ϵ�� * ʿ��Ӱ��ϵ�� * �ȼ�˥��
		double final_module = finalDamageModule * rm_percent * round_eff * declare._Attack.module * backHitModule * armsR * moraleModule * damageDecay;
		if (tick_cri)
		{
			final_module *= declare._Attack.critModule;//����ϵ��
		}

		//����˺�
		int total_damage = (int)(pow(talent * atrr_diff, arms_diff) * final_module) + finalDamageVal;
		total_damage *= damageRate;//���յ�80%���˺�
		total_damage = total_damage < 0 ? 0 : total_damage;
		if (aim != user)//�Լ����Լ������ʶ
		{
			if (declare._Base.runID == SKILL::action_phy)
			{
				onPhyDamage(ptr, uni, user, aim, total_damage);
			}
			else if (declare._Base.runID == SKILL::action_war)
			{
				onWarDamage(ptr, uni, user, aim, total_damage);
			}
			else if (declare._Base.runID == SKILL::action_rage)
			{
				onRageDamage(ptr, uni, user, aim, total_damage);
			}
			else if (declare._Base.runID == SKILL::action_magic)
			{
				onMagicDamage(ptr, uni, user, aim, total_damage);
			}
			else
			{
				onDamage(ptr, uni, user, aim, total_damage, false);
			}
		}
		//���ﴥ���¼�
		manBattle::damageRes res = aim->acceptDamage(-total_damage);
		if (declare._Attack.usePool)
		{
			ptr->pubPoolHP += std::abs(res.totalDamage());
		}
		if (tick_cri)
		{
			onCrit(ptr, uni, user, aim);
		}
		if (0 != res.shp)
		{
			qValue value(qJson::qj_array);
			value.append(aim->currentIdx).append(BATTLEEVENT::shiled_alter).append(BATTLEEVENT::hp_attack).
				append(declare._Base.runID).append(res.shp).append(aim->shield).append(tick_cri);
			uni->junit_.append(value);//�Ƚ����˺�
		}

		qValue value(qJson::qj_array);
		if (aim == user)
		{
			value.append(aim->currentIdx).append(BATTLEEVENT::hp_alter).append(BATTLEEVENT::hp_block).
				append(declare._Base.runID).append(res.hp).append(aim->currentHP).append(tick_cri);
		}
		else
		{
			value.append(aim->currentIdx).append(BATTLEEVENT::hp_alter).append(BATTLEEVENT::hp_attack).
				append(declare._Base.runID).append(res.hp).append(aim->currentHP).append(tick_cri);
		}
		uni->junit_.append(value);//�Ƚ����˺�

		unsigned mMode = declare._Attack.moraleMode;
		if ((mMode & SKILL::morale_atk_create) == SKILL::morale_atk_create)
		{
			if (user->holdMorale)
			{
				user->alterMorale(declare._Attack.moraleNum);
				qValue userM(qJson::qj_array);
				userM.append(user->currentIdx).append(BATTLEEVENT::mp_alter).append(BATTLEEVENT::mp_natural).
					append(declare._Attack.moraleNum).append(user->irrelateMorale());
				uni->junit_.append(userM);//ʿ������
			}
		}
		if (aim != user)
		{
			if ((mMode & SKILL::morale_def_create) == SKILL::morale_def_create)
			{
				if (aim->holdMorale)
				{
					aim->alterMorale(declare._Attack.moraleNum);
					qValue aimM(qJson::qj_array);
					aimM.append(aim->currentIdx).append(BATTLEEVENT::mp_alter).append(BATTLEEVENT::mp_natural).
						append(declare._Attack.moraleNum).append(aim->irrelateMorale());
					uni->junit_.append(aimM);//ʿ������
				}
			}
		}
		return res.totalDamage();
	}

	void battleLogic::phy_attack(battleLogic* logic, BattleData::envPtr ptr, BattleData::unitPtr uni, const SKILL::declare& declare)
	{
		BattleData::unit::aimPtr aPtr = uni->currenAim();
		mBattlePtr user = ptr->currentUser();
		mBattlePtr aim = aPtr->aim_;
		do 
		{
			if (
				onPhyAttack(ptr, uni, user, aim) == intercept
				)break;
			if (//�����ͷųɹ����
				onRun(ptr, uni, declare, user, aim) == intercept
				)break;
			if (//����
				declare._Attack.dodge &&
				onDodge(ptr, uni, user, aim) == intercept
				)break;
			if (//��
				declare._Attack.block &&
				onBlock(ptr, uni, user, aim) == intercept
				)
			{
				damageFM(ptr, uni, declare,
					user, idx_tl_phy, idx_phy, idx_phyHurtRate, idx_phyHurt, idx_atkModule,
					user, idx_tl_phy_def, idx_phy_def, idx_phyCutRate, idx_phyCut, idx_defModule,
					0.8);
				break;
			}
			int damage = damageFM(ptr, uni, declare,
				user, idx_tl_phy, idx_phy, idx_phyHurtRate, idx_phyHurt, idx_atkModule,
				aim, idx_tl_phy_def, idx_phy_def, idx_phyCutRate, idx_phyCut, idx_defModule);
		} while (false);
	}

	void battleLogic::war_attack(battleLogic* logic, BattleData::envPtr ptr, BattleData::unitPtr uni, const SKILL::declare& declare)
	{
		BattleData::unit::aimPtr aPtr = uni->currenAim();
		mBattlePtr user = ptr->currentUser();
		mBattlePtr aim = aPtr->aim_;
		do
		{
			if (
				onRageAttack(ptr, uni, user, aim) == intercept
				)break;
			if (//�����ͷųɹ����
				onRun(ptr, uni, declare, user, aim) == intercept
				)break;
			if (//����
				declare._Attack.dodge &&
				onDodge(ptr, uni, user, aim) == intercept
				)break;
			if (//��
				declare._Attack.block &&
				onBlock(ptr, uni, user, aim) == intercept
				)			
			{
				damageFM(ptr, uni, declare,
					user, idx_tl_war, idx_war, idx_warHurtRate, idx_warHurt, idx_warModule,
					user, idx_tl_war_def, idx_war_def, idx_warCutRate, idx_warCut, idx_warDefModule,
					0.8);
				break;
			}
			int damage = damageFM(ptr, uni, declare,
				user, idx_tl_war, idx_war, idx_warHurtRate, idx_warHurt, idx_warModule,
				aim, idx_tl_war_def, idx_war_def, idx_warCutRate, idx_warCut, idx_warDefModule);
		} while (false);
	}

	void battleLogic::rage_attack(battleLogic* logic, BattleData::envPtr ptr, BattleData::unitPtr uni, const SKILL::declare& declare)
	{
		BattleData::unit::aimPtr aPtr = uni->currenAim();
		mBattlePtr user = ptr->currentUser();
		mBattlePtr aim = aPtr->aim_;
		do
		{
			if (
				onRageAttack(ptr, uni, user, aim) == intercept
				)break;
			if (//�����ͷųɹ����
				onRun(ptr, uni, declare, user, aim) == intercept
				)break;
			if (//����
				declare._Attack.dodge &&
				onDodge(ptr, uni, user, aim) == intercept
				)break;
			if (//��
				declare._Attack.block &&
				onBlock(ptr, uni, user, aim) == intercept
				)
			{
				damageFM(ptr, uni, declare,
					user, idx_tl_war, idx_war, idx_warHurtRate, idx_warHurt, idx_warModule,
					user, idx_tl_war_def, idx_war_def, idx_warCutRate, idx_warCut, idx_warDefModule,
					0.8);
				break;
			}
			int damage = damageFM(ptr, uni, declare,
				user, idx_tl_war, idx_war, idx_warHurtRate, idx_warHurt, idx_warModule,
				aim, idx_tl_war_def, idx_war_def, idx_warCutRate, idx_warCut, idx_warDefModule);
		} while (false);
	}

	void battleLogic::magic_attack(battleLogic* logic, BattleData::envPtr ptr, BattleData::unitPtr uni, const SKILL::declare& declare)
	{
		BattleData::unit::aimPtr aPtr = uni->currenAim();
		mBattlePtr user = ptr->currentUser();
		mBattlePtr aim = aPtr->aim_;
		do
		{
			if (
				onMagicAttack(ptr, uni, user, aim) == intercept
				)break;
			if (//�����ͷųɹ����
				onRun(ptr, uni, declare, user, aim) == intercept
				)break;
			if (//����
				declare._Attack.dodge &&
				onDodge(ptr, uni, user, aim) == intercept
				)break;
			if (//��
				declare._Attack.block &&
				onBlock(ptr, uni, user, aim) == intercept
				)
			{
				damageFM(ptr, uni, declare,
					user, idx_tl_magic, idx_magic, idx_magicHurtRate, idx_magicHurt, idx_magicModule,
					user, idx_tl_magic_def, idx_magic_def, idx_magicCutRate, idx_magicCut, idx_magicDefModule,
					0.8);
				break;
			}
			int damage = damageFM(ptr, uni, declare,
				user, idx_tl_magic, idx_magic, idx_magicHurtRate, idx_magicHurt, idx_magicModule,
				aim, idx_tl_magic_def, idx_magic_def, idx_magicCutRate, idx_magicCut, idx_magicDefModule);
		} while (false);
	}

	void battleLogic::mp_attack(battleLogic* logic, BattleData::envPtr ptr, BattleData::unitPtr uni, const SKILL::declare& declare)
	{
		BattleData::unit::aimPtr aPtr = uni->currenAim();
		mBattlePtr user = ptr->currentUser();
		mBattlePtr aim = aPtr->aim_;
		do
		{
			if (//�����ͷųɹ����
				onRun(ptr, uni, declare, user, aim) == intercept
				)break;
			const int mp = aim->irrelateMorale();
			aim->alterMorale(declare._MPAlter.num);
			if (declare._MPAlter.usePool && mp > aim->irrelateMorale())
			{
				ptr->pubPoolMP += (mp - aim->irrelateMorale());
			}
			qValue val(qJson::qj_array);
			val.append(aim->currentIdx).append(BATTLEEVENT::mp_alter).append(BATTLEEVENT::mp_skill).
				append(declare._MPAlter.num).append(aim->irrelateMorale());
			uni->junit_.append(val);//ʿ������
		} while (false);
	}

	void battleLogic::mp_alter_formula_1(battleLogic* logic, BattleData::envPtr ptr, BattleData::unitPtr uni, const SKILL::declare& declare)
	{
		BattleData::unit::aimPtr aPtr = uni->currenAim();
		mBattlePtr user = ptr->currentUser();
		mBattlePtr aim = aPtr->aim_;
		do
		{
			if (//�����ͷųɹ����
				onRun(ptr, uni, declare, user, aim) == intercept
				)break;
			//�ı�ʿ��=�ж�������-Ŀ�귽����+20�������ֵΪ80������ֵΪ20��
			int num = user->getTotalAttri((AttributeIDX)declare._AlterMPF1.userIDX) -
				aim->getTotalAttri((AttributeIDX)declare._AlterMPF1.aimIDX) +
				declare._AlterMPF1.fixValue;
			num = std::min(num, declare._AlterMPF1.maxValue);
			num = std::max(num, declare._AlterMPF1.minValue);
			num = declare._AlterMPF1.reduce ? -num : num;
			if (aim->holdMorale && num != 0)
			{
				aim->alterMorale(num);
				qValue val(qJson::qj_array);
				val.append(aim->currentIdx).append(BATTLEEVENT::mp_alter).append(BATTLEEVENT::mp_skill).
					append(num).append(aim->irrelateMorale());
				uni->junit_.append(val);//ʿ������
			}
		} while (false);
	}

	void battleLogic::mp_set(battleLogic* logic, BattleData::envPtr ptr, BattleData::unitPtr uni, const SKILL::declare& declare)
	{
		BattleData::unit::aimPtr aPtr = uni->currenAim();
		mBattlePtr user = ptr->currentUser();
		mBattlePtr aim = aPtr->aim_;
		do
		{
			if (//�����ͷųɹ����
				onRun(ptr, uni, declare, user, aim) == intercept
				)break;
			if (aim->holdMorale)
			{
				const int old_num = aim->irrelateMorale();
				aim->setMorale(declare._MPAlter.num);
				const int alter_num = aim->irrelateMorale() - old_num;
				if (declare._MPAlter.usePool && old_num > aim->irrelateMorale())
				{
					ptr->pubPoolMP += (old_num - aim->irrelateMorale());
				}
				qValue val(qJson::qj_array);
				val.append(aim->currentIdx).append(BATTLEEVENT::mp_alter).append(BATTLEEVENT::mp_skill).
					append(alter_num).append(aim->irrelateMorale());
				uni->junit_.append(val);//ʿ������
			}
		} while (false);
	}

	void battleLogic::absorb_hp(battleLogic* logic, BattleData::envPtr ptr, BattleData::unitPtr uni, const SKILL::declare& declare)
	{
		BattleData::unit::aimPtr aPtr = uni->currenAim();
		mBattlePtr user = ptr->currentUser();
		mBattlePtr aim = aPtr->aim_;
		do
		{
			if (//�����ͷųɹ����
				onRun(ptr, uni, declare, user, aim) == intercept
				)break;
			int cure = declare._Absorb.rate * ptr->pubPoolHP + declare._Absorb.fix;
			if (declare._Absorb.clear)
			{
				ptr->pubPoolHP = 0;
			}
			if (cure > 0)
			{
				int cure_val = aim->alterHP(cure);
				qValue value(qJson::qj_array);
				value.append(aim->currentIdx).append(BATTLEEVENT::hp_alter).append(BATTLEEVENT::hp_absorb).append(declare._Base.runID).
					append(cure_val).append(aim->currentHP);
				uni->junit_.append(value);
			}
		} while (false);
	}

	void battleLogic::absorb_mp(battleLogic* logic, BattleData::envPtr ptr, BattleData::unitPtr uni, const SKILL::declare& declare)
	{
		BattleData::unit::aimPtr aPtr = uni->currenAim();
		mBattlePtr user = ptr->currentUser();
		mBattlePtr aim = aPtr->aim_;
		do
		{
			if (//�����ͷųɹ����
				onRun(ptr, uni, declare, user, aim) == intercept
				)break;
			int cure = declare._Absorb.rate * ptr->pubPoolMP + declare._Absorb.fix;
			if (declare._Absorb.clear)
			{
				ptr->pubPoolMP = 0;
			}
			if (cure > 0)
			{
				aim->alterMorale(cure);
				qValue val(qJson::qj_array);
				val.append(aim->currentIdx).append(BATTLEEVENT::mp_alter).append(BATTLEEVENT::mp_absorb).
					append(cure).append(aim->irrelateMorale());
				uni->junit_.append(val);//ʿ������
// 				RegEffectMap::iterator it = RegEffect.find(BUFF::last_alter_mp);
// 				if (it == RegEffect.end())break;
// 				const BUFF::Data& effect_ = declare._AbsorbMp._effect;
// 				memmove((void*)(&effect_.otherData._alter.fixValue), &cure, sizeof(effect_.otherData._alter.fixValue));
// 				it->second(ptr, uni, user, aim, effect_);
// 				memset((void*)(&effect_.otherData._alter.fixValue), 0x0, sizeof(effect_.otherData._alter.fixValue));
			}
		} while (false);
	}

	void battleLogic::cure_hp(battleLogic* logic, BattleData::envPtr ptr, BattleData::unitPtr uni, const SKILL::declare& declare)
	{
		BattleData::unit::aimPtr aPtr = uni->currenAim();
		mBattlePtr user = ptr->currentUser();
		mBattlePtr aim = aPtr->aim_;
		do
		{
			if (//�����ͷųɹ����
				onRun(ptr, uni, declare, user, aim) == intercept
				)break;
			int cure = int( 
				( aim->manLevel * declare._Cure.module_1 + 
				declare._Cure.module_2 + 
				user->getTotalAttri(idx_magic) * declare._Cure.module_3 )
				*
				( 1.0 + 
				user->getTotalAttri(idx_tl_magic) * declare._Cure.module_4 )
				*
				( 0.7 +
				0.3 * (double)user->currentHP / user->getTotalAttri(idx_hp)
					)
				);
			double module = (user->getTotalAttri(idx_cureRate) + aim->getTotalAttri(idx_beCureRate)) / 10000.0;
			int fix = user->getTotalAttri(idx_cure) + aim->getTotalAttri(idx_beCure);
			cure = int(cure * (1.0 + module) + fix);
			if (cure > 0)
			{
				aim->alterHP(cure);
				qValue value(qJson::qj_array);
				value.append(aim->currentIdx).append(BATTLEEVENT::hp_alter).append(BATTLEEVENT::hp_cure).append(declare._Base.runID).
					append(cure).append(aim->currentHP);
				uni->junit_.append(value);
			}
		} while (false);
	}

	void battleLogic::cure_mp(battleLogic* logic, BattleData::envPtr ptr, BattleData::unitPtr uni, const SKILL::declare& declare)
	{
		BattleData::unit::aimPtr aPtr = uni->currenAim();
		mBattlePtr user = ptr->currentUser();
		mBattlePtr aim = aPtr->aim_;
		do
		{
			if (//�����ͷųɹ����
				onRun(ptr, uni, declare, user, aim) == intercept
				)break;
			int cure = int(
				(aim->manLevel * declare._Cure.module_1 +
				declare._Cure.module_2 +
				user->getTotalAttri(idx_magic) * declare._Cure.module_3)
				*
				(1.0 +
				user->getTotalAttri(idx_tl_magic) * declare._Cure.module_4)
				);
			double module = (user->getTotalAttri(idx_cureRate) + aim->getTotalAttri(idx_beCureRate)) / 10000.0;
			int fix = user->getTotalAttri(idx_cure) + aim->getTotalAttri(idx_beCure);
			cure = int(cure * (1.0 + module) + fix);
			if (cure > 0)
			{
				aim->alterMorale(cure);
				qValue value(qJson::qj_array);
				value.append(aim->currentIdx).append(BATTLEEVENT::mp_alter).append(BATTLEEVENT::mp_cure).append(declare._Base.runID).
					append(cure).append(aim->irrelateMorale());
				uni->junit_.append(value);
			}
		} while (false);
	}

	void battleLogic::stun_antiregist(battleLogic* logic, mBattlePtr user, ptrManBuff ef)
	{
		const BUFF::Data& config = *(ef->declare);
		const unsigned type_add = config.otherData._stun.stateLock;
		if (ef->otherData._stun.isEffect)
		{
			ef->otherData._stun.isEffect = false;
			for (unsigned i = 0; i < BUFF::lock_type_num; i++)
			{
				const unsigned check_type = 0x0001 << i;
				if ((type_add & check_type) > 0)
				{
					user->minusLockType((BUFF::lockType)check_type);
				}
			}
		}
	}

	void battleLogic::bonus_attri_antiregist(battleLogic* logic, mBattlePtr user, ptrManBuff ef)
	{
		const BUFF::Data& config = *(ef->declare);
		const int* ef_attri = config.otherData._attri.attri;
		int* attri_init = user->addAttri;
		for (unsigned i = 0; i < characterNum; ++i){ attri_init[i] -= ef_attri[i]; }
	}

	void battleLogic::bonus_attri_rate_antiregist(battleLogic* logic, mBattlePtr user, ptrManBuff ef)
	{
		const BUFF::Data& config = *(ef->declare);
		const int* ef_attri = config.otherData._attri.attri;
		int* attri_init = user->rateAttri;
		for (unsigned i = 0; i < characterNum; ++i){ attri_init[i] -= ef_attri[i]; }
	}

	bool battleLogic::user_runOK(battleLogic* logic, mBattlePtr user, mBattlePtr aim, const SKILL::declare& declare)
	{
		if (0x0 == declare._Base.userLimit || 0x8000000 == declare._Base.userLimit)return true;
		
		if ((0x8000000 & declare._Base.userLimit) == SKILL::limit_logic_and)
		{
			for (unsigned i = 0; i < SKILL::limit_user_num; ++i)
			{
				const unsigned limit_id = (0x0001 << i) & declare._Base.userLimit;
				UserRunMap::iterator it = UserRun.find(limit_id);
				if (it != UserRun.end())
				{
					if (!(it->second(logic, user, aim)))return false;
				}
			}
			return true;
		}
		else
		{
			for (unsigned i = 0; i < SKILL::limit_user_num; ++i)
			{
				const unsigned limit_id = (0x0001 << i) & declare._Base.userLimit;
				UserRunMap::iterator it = UserRun.find(limit_id);
				if (it != UserRun.end())
				{
					if (it->second(logic, user, aim))return true;
				}
			}
			return false;
		}
	}

	bool battleLogic::user_alive(battleLogic* logic, mBattlePtr user, mBattlePtr aim)
	{
		return !user->isDead();
	}

	bool battleLogic::aim_alive(battleLogic* logic, mBattlePtr user, mBattlePtr aim)
	{
		return !aim->isDead();
	}

	bool battleLogic::user_hp_greater(battleLogic* logic, mBattlePtr user, mBattlePtr aim)
	{
		return user->currentHP > aim->currentHP;
	}

	bool battleLogic::user_hp_less(battleLogic* logic, mBattlePtr user, mBattlePtr aim)
	{
		return user->currentHP < aim->currentHP;
	}

	bool battleLogic::user_hp_equal(battleLogic* logic, mBattlePtr user, mBattlePtr aim)
	{
		return user->currentHP == aim->currentHP;
	}

	bool battleLogic::buff_regist(battleLogic* logic, BattleData::envPtr env, BattleData::unitPtr uni, mBattlePtr user, mBattlePtr aim, ptrManBuff ef)
	{
		const int buffID = ef->declare->buffID;
		if (aim->resistBuff(buffID))return false;
		const int effectID = buffID % BUFF::BUFFOFFSET;
		ptrManBuff old_ef = aim->getEffect(buffID);
		if (old_ef && old_ef->declare->weight > ef->declare->weight)return false;
		//BATTLEEVENT::effect_reset 
		int set_event = BATTLEEVENT::effect_set;
		if (old_ef)
		{//��ע��
			set_event = BATTLEEVENT::effect_reset;
			AntiRegEffectMap::iterator it = AntiRegEffect.find(effectID);//��ע��buff
			if (it != AntiRegEffect.end())
			{
				it->second(logic, aim, ef);
			}
		}
		qValue jVal(qJson::qj_array);
		jVal.append(aim->currentIdx).append(set_event).append(buffID);
		uni->junit_.append(jVal);

		//����buff����
		ef->isNew = env->isAction;
		ef->holderMan = aim.get();
		user->dispatchBuffs.push_back(ef);
		aim->holdBuffs[buffID] = ef;//����buff

		return true;
	}

	void battleLogic::stun_regist(battleLogic* logic, BattleData::envPtr env, BattleData::unitPtr uni, mBattlePtr user, mBattlePtr aim, const BUFF::Data& entity)
	{
		ptrManBuff new_ef = Creator<MANEFFECT::Data>::Create();
		new_ef->declare = &entity;
		new_ef->lastRound = entity.lastRound;
		new_ef->otherData._stun.tickTimes = 1;
		new_ef->otherData._stun.isEffect = false;
		if (buff_regist(logic, env, uni, user, aim, new_ef))
		{
			if (entity.otherData._stun.immediately)
			{
				new_ef->otherData._stun.tickTimes = 0;
				if (false == new_ef->otherData._stun.isEffect && Common::randomOk(entity.otherData._stun.effectRate))
				{
					new_ef->otherData._stun.isEffect = true;
					const unsigned type_add = entity.otherData._stun.stateLock;
					for (unsigned i = 0; i < BUFF::lock_type_num; i++)
					{
						const unsigned check_type = 0x0001 << i;
						if ((type_add & check_type) > 0)
						{
							aim->plusLockType((BUFF::lockType)check_type);
						}
					}
				}
			}
		}
	}

	void battleLogic::bonus_attri_regist(battleLogic* logic, BattleData::envPtr env, BattleData::unitPtr uni, mBattlePtr user, mBattlePtr aim, const BUFF::Data& entity)
	{
		ptrManBuff new_ef = Creator<MANEFFECT::Data>::Create();
		new_ef->declare = &entity;
		new_ef->lastRound = entity.lastRound;
		if (buff_regist(logic, env, uni, user, aim, new_ef))
		{
			//ע������
			const int* ef_attri = entity.otherData._attri.attri;
			int* attri_init = aim->addAttri;
			for (unsigned i = 0; i < characterNum; ++i){ attri_init[i] += ef_attri[i]; }
		}
	}

	void battleLogic::bonus_attri_rate_regist(battleLogic* logic, BattleData::envPtr env, BattleData::unitPtr uni, mBattlePtr user, mBattlePtr aim, const BUFF::Data& entity)
	{
		ptrManBuff new_ef = Creator<MANEFFECT::Data>::Create();
		new_ef->declare = &entity;
		new_ef->lastRound = entity.lastRound;
		if (buff_regist(logic, env, uni, user, aim, new_ef))
		{
			//ע������
			const int* ef_attri = entity.otherData._attri.attri;
			int* attri_init = aim->rateAttri;
			for (unsigned i = 0; i < characterNum; ++i){ attri_init[i] += ef_attri[i]; }
		}
	}

	void battleLogic::last_alter_regist(battleLogic* logic, BattleData::envPtr env, BattleData::unitPtr uni, mBattlePtr user, mBattlePtr aim, const BUFF::Data& entity)
	{
		ptrManBuff new_ef = Creator<MANEFFECT::Data>::Create();
		new_ef->declare = &entity;
		new_ef->lastRound = entity.lastRound;
		if (buff_regist(logic, env, uni, user, aim, new_ef))
		{
			new_ef->otherData._value.valEffect = 
				aim->getTotalAttri((AttributeIDX)entity.otherData._alter.idxAttri) * 
				entity.otherData._alter.rate +
				entity.otherData._alter.fixValue;
		}
	}

	void battleLogic::set_buff(battleLogic* logic, BattleData::envPtr ptr, BattleData::unitPtr uni, const SKILL::declare& declare)
	{
		BattleData::unit::aimPtr aPtr = uni->currenAim();
		mBattlePtr user = ptr->currentUser();
		mBattlePtr aim = aPtr->aim_;
		do
		{
			if (//�����ͷųɹ����
				onRun(ptr, uni, declare, user, aim, false) == intercept
				)break;
			int effectID = declare._Effect._effect.buffID % BUFF::BUFFOFFSET;
			RegEffectMap::iterator it = RegEffect.find(effectID);
			if (it == RegEffect.end())break;
			it->second(logic, ptr, uni, user, aim, declare._Effect._effect);
		} while (false);
	}

	void battleLogic::add_shield(battleLogic* logic, BattleData::envPtr ptr, BattleData::unitPtr uni, const SKILL::declare& declare)
	{
		BattleData::unit::aimPtr aPtr = uni->currenAim();
		mBattlePtr user = ptr->currentUser();
		mBattlePtr aim = aPtr->aim_;
		do
		{
			if (//�����ͷųɹ����
				onRun(ptr, uni, declare, user, aim, false) == intercept
				)break;
			const int shield = declare._Shield.precentAttri * user->getTotalAttri((AttributeIDX)declare._Shield.idxAttri) + declare._Shield.fixValue;
			aim->alterShield(shield);
			qValue value(qJson::qj_array);
			value.append(aim->currentIdx).append(BATTLEEVENT::shield_alter).append(BATTLEEVENT::hp_effect).
				append(declare._Base.runID).append(shield).append(aim->shield);
		} while (false);
	}

	void battleLogic::direct_attack(battleLogic* logic, BattleData::envPtr ptr, BattleData::unitPtr uni, const SKILL::declare& declare)
	{
		BattleData::unit::aimPtr aPtr = uni->currenAim();
		mBattlePtr user = ptr->currentUser();
		mBattlePtr aim = aPtr->aim_;
		do
		{
			if (//�����ͷųɹ����
				onRun(ptr, uni, declare, user, aim) == intercept
				)break;
			int damage = declare._TrueDamage.fixDamage + declare._TrueDamage.precentTotalHP * aim->getTotalAttri(idx_hp) +
				declare._TrueDamage.precentHP * aim->currentHP + user->getTotalAttri((AttributeIDX)declare._TrueDamage.idxAttri) * declare._TrueDamage.precentAttri;
			if (damage > 0)
			{
				manBattle::damageRes res = aim->acceptDamage(-damage);
				if (0 != res.shp)
				{
					qValue value(qJson::qj_array);
					value.append(aim->currentIdx).append(BATTLEEVENT::shiled_alter).append(BATTLEEVENT::hp_direct).
						append(declare._Base.runID).append(res.shp).append(aim->shield);
					uni->junit_.append(value);//�Ƚ����˺�
				}
// 				if (0 != res.hp)
// 				{
					qValue value(qJson::qj_array);
					value.append(aim->currentIdx).append(BATTLEEVENT::hp_alter).append(BATTLEEVENT::hp_direct).
						append(declare._Base.runID).append(res.hp).append(aim->currentHP);
					uni->junit_.append(value);//�Ƚ����˺�
//				}
				int final_damage = res.totalDamage();
				onDamage(ptr, uni, user, aim, final_damage, false);
			}
		} while (false);
	}

	void battleLogic::child_skill(battleLogic* logic, BattleData::envPtr ptr, BattleData::unitPtr uni, const SKILL::declare& declare)
	{
		BattleData::unit::aimPtr aPtr = uni->currenAim();
		mBattlePtr user = ptr->currentUser();
		mBattlePtr aim = aPtr->aim_;
		do
		{
			if (//�����ͷųɹ����
				onRun(ptr, uni, declare, user, mBattlePtr()) == intercept
				)break;
			qValue qUser(qJson::qj_array);
			qUser.append(user->currentIdx).append(BATTLEEVENT::user_child).append(declare._Child.childID);//ʹ�ü���
			const unsigned future_idx = ptr->getNextIDX();
			logic->on_detail_attack(ptr, *declare._Child.child);
			BattleData::unitPtr last = ptr->getUnit(future_idx);//��Ϊ����Ƕ�׵�����������ȡֵ����������
			if (!last->junit_.isEmpty())
			{
				qUser.append(last->toJaim()).
					append(last->junit_);
				uni->junit_.append(qUser);
			}
		} while (false);
	}

	battleLogic::EventResult battleLogic::onRun(BattleData::envPtr ptr, BattleData::unitPtr uni, const SKILL::declare& declare, mBattlePtr user, mBattlePtr aim, const bool visible /* = true */)
	{
		if (!Common::randomOk(declare._Base.runRate))
		{
			if (visible)
			{
				qValue value(qJson::qj_array);
				if (aim)value.append(aim->currentIdx).append(BATTLEEVENT::run_failed).append(declare._Base.runID);
				else value.append(user->currentIdx).append(BATTLEEVENT::run_failed).append(declare._Base.runID);
				uni->junit_.append(value);
			}
			uni->currenAim()->setState(SKILL::ref_run_failed);
			return intercept;
		}
		if (aim)//Ŀ����Ч
		{

		}
		return adopt;
	}

	battleLogic::EventResult battleLogic::onPhyAttack(BattleData::envPtr ptr, BattleData::unitPtr uni, mBattlePtr user, mBattlePtr aim)
	{
		battleLogic::EventResult res = onAttack(ptr, uni, user, aim);
		if (res != adopt)return res;
		return adopt;
	}

	battleLogic::EventResult battleLogic::onWarAttack(BattleData::envPtr ptr, BattleData::unitPtr uni, mBattlePtr user, mBattlePtr aim)
	{
		battleLogic::EventResult res = onAttack(ptr, uni, user, aim);
		if (res != adopt)return res;
		return adopt;
	}

	battleLogic::EventResult battleLogic::onRageAttack(BattleData::envPtr ptr, BattleData::unitPtr uni, mBattlePtr user, mBattlePtr aim)
	{
		battleLogic::EventResult res = onAttack(ptr, uni, user, aim);
		if (res != adopt)return res;
		return adopt;
	}

	battleLogic::EventResult battleLogic::onMagicAttack(BattleData::envPtr ptr, BattleData::unitPtr uni, mBattlePtr user, mBattlePtr aim)
	{
		battleLogic::EventResult res = onAttack(ptr, uni, user, aim);
		if (res != adopt)return res;
		return adopt;
	}

	battleLogic::EventResult battleLogic::onAttack(BattleData::envPtr ptr, BattleData::unitPtr uni, mBattlePtr user, mBattlePtr aim)
	{
		return adopt;
	}

	battleLogic::EventResult battleLogic::onPhyDamage(BattleData::envPtr ptr, BattleData::unitPtr uni, mBattlePtr user, mBattlePtr aim, int& damage)
	{
		battleLogic::EventResult res = onDamage(ptr, uni, user, aim, damage);
		if (res != adopt)return res;
		uni->currenAim()->setState(SKILL::ref_phy_hurt);
		return adopt;
	}

	battleLogic::EventResult battleLogic::onWarDamage(BattleData::envPtr ptr, BattleData::unitPtr uni, mBattlePtr user, mBattlePtr aim, int& damage)
	{
		battleLogic::EventResult res = onDamage(ptr, uni, user, aim, damage);
		if (res != adopt)return res;
		uni->currenAim()->setState(SKILL::ref_war_hurt);
		return adopt;
	}

	battleLogic::EventResult battleLogic::onRageDamage(BattleData::envPtr ptr, BattleData::unitPtr uni, mBattlePtr user, mBattlePtr aim, int& damage)
	{
		battleLogic::EventResult res = onDamage(ptr, uni, user, aim, damage);
		if (res != adopt)return res;
		uni->currenAim()->setState(SKILL::ref_rage_hurt);
		return adopt;
	}

	battleLogic::EventResult battleLogic::onMagicDamage(BattleData::envPtr ptr, BattleData::unitPtr uni, mBattlePtr user, mBattlePtr aim, int& damage)
	{
		battleLogic::EventResult res = onDamage(ptr, uni, user, aim, damage);
		if (res != adopt)return res;
		uni->currenAim()->setState(SKILL::ref_magic_hurt);
		return adopt;
	}

	battleLogic::EventResult battleLogic::onDamage(BattleData::envPtr ptr, BattleData::unitPtr uni, mBattlePtr user, mBattlePtr aim, int& damage, const bool common /* = true */)
	{
		if (!common)
		{
			uni->currenAim()->setState(SKILL::ref_other_damage);
		}
		return adopt;
	}

// 	battle_system::EventResult battle_system::onDead(BattleData::envPtr ptr, BattleData::unitPtr uni, mBattlePtr who)
// 	{
// 		if (who->isDead())
// 		{
// 			qValue value(qJson::qj_array);
// 			value.append(who->currentIdx).append(BATTLEEVENT::dead);
// 			uni->junit_.append(value);
// 			return intercept;
// 		}
// 		return adopt;
// 	}

	battleLogic::EventResult battleLogic::onDodge(BattleData::envPtr ptr, BattleData::unitPtr uni, mBattlePtr user, mBattlePtr aim)
	{
		if (!aim->checkLockType(BUFF::lock_dodge) && Common::randomOk(aim->getTotalAttri(idx_dodge)))
		{
			qValue value(qJson::qj_array);
			value.append(aim->currentIdx).append(BATTLEEVENT::dodge);
			uni->junit_.append(value);
			uni->currenAim()->setState(SKILL::ref_dodge);
			return intercept;
		}
		return adopt;
	}

	battleLogic::EventResult battleLogic::onBlock(BattleData::envPtr ptr, BattleData::unitPtr uni, mBattlePtr user, mBattlePtr aim)
	{
		if (!aim->checkLockType(BUFF::lock_block) && Common::randomOk(aim->getTotalAttri(idx_block)))
		{
			qValue value(qJson::qj_array);
			value.append(aim->currentIdx).append(BATTLEEVENT::block);
			uni->junit_.append(value);
			uni->currenAim()->setState(SKILL::ref_block);
			return intercept;
		}
		return adopt;
	}

	battleLogic::EventResult battleLogic::onCrit(BattleData::envPtr ptr, BattleData::unitPtr uni, mBattlePtr user, mBattlePtr aim)
	{
		uni->currenAim()->setState(SKILL::ref_crit);
		return adopt;
	}

	battleLogic::EventResult battleLogic::onCounter(BattleData::envPtr ptr, BattleData::unitPtr uni, mBattlePtr user, mBattlePtr aim)
	{
		return adopt;
	}

	void battleLogic::find_aim(battleLogic* logic, BattleData::envPtr env, BattleData::unitPtr uni, const AIM::structAIM& declare, mBattlePtr sign_aim /* = mBattlePtr() */)
	{
		if (sign_aim)
		{
			mBattlePtr user = env->currentUser();
			const int user_camp = (user->currentIdx % 18) / 9;//�Լ�����Ӫ
			const int sign_camp = (sign_aim->currentIdx % 18) / 9;//�Է�����Ӫ
			if (
				(declare.camp == 0 && user_camp == sign_camp) ||
				(declare.camp != 0 && user_camp != sign_camp)
				)
			{
				if (sign_aim->passLimit(declare))
				{
					uni->clearAim();
					uni->pushAim(sign_aim);
					find_aim_sign(logic, env, uni, declare);
					return;
				}
			}
		}
		find_aim_new(logic, env, uni, declare);
	}

	void battleLogic::find_aim_new(battleLogic* logic, BattleData::envPtr env, BattleData::unitPtr uni, const AIM::structAIM& declare)
	{
		aimDealMap::iterator it = newAimDeal.find(declare.selectID);
		if (it != newAimDeal.end())
		{
			uni->clearAim();
			it->second(logic, env, uni, declare);
		}
	}

	void battleLogic::find_aim_sign(battleLogic* logic, BattleData::envPtr env, BattleData::unitPtr uni, const AIM::structAIM& declare)
	{
		aimDealMap::iterator it = signAimDeal.find(declare.selectID);
		if (it != signAimDeal.end())
		{
			it->second(logic, env, uni, declare);
		}
	}

#define CopyRule(_Dst, _Val)\
	unsigned _Dst[3];\
	memmove(_Dst, _Val, sizeof(unsigned[3]));
	

	void battleLogic::aim_follow_new(battleLogic* logic, BattleData::envPtr ptr, BattleData::unitPtr uni, const AIM::structAIM& declare)
	{
		BattleData::unitPtr res_unit = ptr->getUnit(declare.otherData.Follow.followIdx);
		if (res_unit == uni)return;
		res_unit->copyAimTo(uni, declare.otherData.Follow.newStatus);
	}

	void battleLogic::aim_follow_sign(battleLogic* logic, BattleData::envPtr ptr, BattleData::unitPtr uni, const AIM::structAIM& declare)
	{
		uni->clearAim();
	}

	void battleLogic::aim_single_new(battleLogic* logic, BattleData::envPtr ptr, BattleData::unitPtr uni, const AIM::structAIM& declare)
	{
		mBattlePtr user = ptr->currentUser();
		CopyRule(rule, PriorityXY_[user->Y()]);
		sBattlePtr useSide = ptr->handAtk;
		if (declare.camp != 0)
		{
			useSide = ptr->handDef;
		}
		if (declare.isOpp)
		{
			for (unsigned i = 0; i < 3; ++i)
				for (unsigned x = 2; x < 3; --x)	{
					mBattlePtr aim = useSide->getUser(x, rule[i]);
					if (!aim || !aim->passLimit(declare))continue;
					uni->pushAim(aim);
					return;
				}
		}
		else
		{
			for (unsigned i = 0; i < 3; ++i)
				for (unsigned x = 0; x < 3; ++x)	{
					mBattlePtr aim = useSide->getUser(x, rule[i]);
					if (!aim || !aim->passLimit(declare))continue;
					uni->pushAim(aim);
					return;
				}
		}
	}

	void battleLogic::aim_single_sign(battleLogic* logic, BattleData::envPtr ptr, BattleData::unitPtr uni, const AIM::structAIM& declare)
	{
		//ʲôҲ����
	}

	void battleLogic::aim_line_new(battleLogic* logic, BattleData::envPtr ptr, BattleData::unitPtr uni, const AIM::structAIM& declare)
	{
		aim_single_new(logic, ptr, uni, declare);
		BattleData::unit::aimPtr aimD = uni->mainAim();
		if (!aimD || !aimD->aim_)return;
		mBattlePtr m_aim = aimD->aim_;
		sBattlePtr useSide = ptr->handAtk;
		if (declare.camp != 0)
		{
			useSide = ptr->handDef;
		}
		const unsigned y = m_aim->Y();
		if (declare.isOpp)
		{
			for (unsigned x = 2; x < 3; --x)
			{
				mBattlePtr c_aim = useSide->getUser(x, y);
				if (!c_aim || (m_aim == c_aim) || !c_aim->passLimit(declare))continue;
				uni->pushAim(c_aim);
			}
		}
		else
		{
			for (unsigned x = 0; x < 3; ++x)
			{
				mBattlePtr c_aim = useSide->getUser(x, y);
				if (!c_aim || (m_aim == c_aim) || !c_aim->passLimit(declare))continue;
				uni->pushAim(c_aim);
			}
		}
	}

	void battleLogic::aim_line_sign(battleLogic* logic, BattleData::envPtr ptr, BattleData::unitPtr uni, const AIM::structAIM& declare)
	{
		BattleData::unit::aimPtr aimD = uni->mainAim();
		if (!aimD || !aimD->aim_)return;
		mBattlePtr m_aim = aimD->aim_;
		sBattlePtr useSide = ptr->handAtk;
		if (declare.camp != 0)
		{
			useSide = ptr->handDef;
		}
		const unsigned y = m_aim->Y();
		if (declare.isOpp)
		{
			for (unsigned x = 2; x < 3; --x)
			{
				mBattlePtr c_aim = useSide->getUser(x, y);
				if (!c_aim || (m_aim == c_aim) || !c_aim->passLimit(declare))continue;
				uni->pushAim(c_aim);
			}
		}
		else
		{
			for (unsigned x = 0; x < 3; ++x)
			{
				mBattlePtr c_aim = useSide->getUser(x, y);
				if (!c_aim || (m_aim == c_aim) || !c_aim->passLimit(declare))continue;
				uni->pushAim(c_aim);
			}
		}
	}

	void battleLogic::aim_row_new(battleLogic* logic, BattleData::envPtr ptr, BattleData::unitPtr uni, const AIM::structAIM& declare)
	{
		aim_single_new(logic, ptr, uni, declare);
		BattleData::unit::aimPtr aimD = uni->mainAim();
		if (!aimD || !aimD->aim_)return;
		mBattlePtr m_aim = aimD->aim_;
		sBattlePtr useSide = ptr->handAtk;
		if (declare.camp != 0)
		{
			useSide = ptr->handDef;
		}
		const unsigned x = m_aim->X();
		if (declare.isOpp)
		{
			for (unsigned y = 2; y < 3; --y)
			{
				mBattlePtr c_aim = useSide->getUser(x, y);
				if (!c_aim || (m_aim == c_aim) || !c_aim->passLimit(declare))continue;
				uni->pushAim(c_aim);
			}
		}
		else
		{
			for (unsigned y = 0; y < 3; ++y)
			{
				mBattlePtr c_aim = useSide->getUser(x, y);
				if (!c_aim || (m_aim == c_aim) || !c_aim->passLimit(declare))continue;
				uni->pushAim(c_aim);
			}
		}
	}

	void battleLogic::aim_row_sign(battleLogic* logic, BattleData::envPtr ptr, BattleData::unitPtr uni, const AIM::structAIM& declare)
	{
		BattleData::unit::aimPtr aimD = uni->mainAim();
		if (!aimD || !aimD->aim_)return;
		mBattlePtr m_aim = aimD->aim_;
		sBattlePtr useSide = ptr->handAtk;
		if (declare.camp != 0)
		{
			useSide = ptr->handDef;
		}
		const unsigned x = m_aim->X();
		if (declare.isOpp)
		{
			for (unsigned y = 2; y < 3; --y)
			{
				mBattlePtr c_aim = useSide->getUser(x, y);
				if (!c_aim || (m_aim == c_aim) || !c_aim->passLimit(declare))continue;
				uni->pushAim(c_aim);
			}
		}
		else
		{
			for (unsigned y = 0; y < 3; ++y)
			{
				mBattlePtr c_aim = useSide->getUser(x, y);
				if (!c_aim || (m_aim == c_aim) || !c_aim->passLimit(declare))continue;
				uni->pushAim(c_aim);
			}
		}
	}

	void battleLogic::aim_cross_new(battleLogic* logic, BattleData::envPtr ptr, BattleData::unitPtr uni, const AIM::structAIM& declare)
	{
		aim_single_new(logic, ptr, uni, declare);
		BattleData::unit::aimPtr aimD = uni->mainAim();
		if (!aimD || !aimD->aim_)return;
		mBattlePtr m_aim = aimD->aim_;
		sBattlePtr useSide = ptr->handAtk;
		if (declare.camp != 0)
		{
			useSide = ptr->handDef;
		}
		const unsigned X = m_aim->X();
		const unsigned Y = m_aim->Y();
		for (unsigned y = 0; y < 3; ++y)
		{
			mBattlePtr c_aim = useSide->getUser(X, y);
			if (!c_aim || (m_aim == c_aim) || !c_aim->passLimit(declare))continue;
			uni->pushAim(c_aim);
		}
		for (unsigned x = 0; x < 3; ++x)
		{
			mBattlePtr c_aim = useSide->getUser(x, Y);
			if (!c_aim || (m_aim == c_aim) || !c_aim->passLimit(declare))continue;
			uni->pushAim(c_aim);
		}
	}

	void battleLogic::aim_cross_sign(battleLogic* logic, BattleData::envPtr ptr, BattleData::unitPtr uni, const AIM::structAIM& declare)
	{
		BattleData::unit::aimPtr aimD = uni->mainAim();
		if (!aimD || !aimD->aim_)return;
		mBattlePtr m_aim = aimD->aim_;
		sBattlePtr useSide = ptr->handAtk;
		if (declare.camp != 0)
		{
			useSide = ptr->handDef;
		}
		const unsigned X = m_aim->X();
		const unsigned Y = m_aim->Y();
		for (unsigned y = 0; y < 3; ++y)
		{
			mBattlePtr c_aim = useSide->getUser(X, y);
			if (!c_aim || (m_aim == c_aim) || !c_aim->passLimit(declare))continue;
			uni->pushAim(c_aim);
		}
		for (unsigned x = 0; x < 3; ++x)
		{
			mBattlePtr c_aim = useSide->getUser(x, Y);
			if (!c_aim || (m_aim == c_aim) || !c_aim->passLimit(declare))continue;
			uni->pushAim(c_aim);
		}
	}

	void battleLogic::aim_random_new(battleLogic* logic, BattleData::envPtr ptr, BattleData::unitPtr uni, const AIM::structAIM& declare)
	{
		sBattlePtr useSide = ptr->handAtk;
		if (declare.camp != 0)
		{
			useSide = ptr->handDef;
		}
		manList mL = useSide->getALLUser(declare);
		random_shuffle(mL.begin(), mL.end());
		for (unsigned num = 0; num < mL.size() && num < declare.otherData.Romdom.rNum; ++num)
		{
			uni->pushAim(mL[num]);
		}
	}

	void battleLogic::aim_random_sign(battleLogic* logic, BattleData::envPtr ptr, BattleData::unitPtr uni, const AIM::structAIM& declare)
	{
		sBattlePtr useSide = ptr->handAtk;
		if (declare.camp != 0)
		{
			useSide = ptr->handDef;
		}
		manList mL = useSide->getALLUser(declare);
		random_shuffle(mL.begin(), mL.end());
		mBattlePtr main_aim = uni->mainAim() ? uni->mainAim()->aim_ : mBattlePtr();
		for (unsigned num = 0; num < mL.size() && num < declare.otherData.Romdom.rNum && num < uni->sizeAim(); ++num)
		{
			if (main_aim == mL[num])continue;
			uni->pushAim(mL[num]);
		}
	}

	void battleLogic::aim_current_new(battleLogic* logic, BattleData::envPtr ptr, BattleData::unitPtr uni, const AIM::structAIM& declare)
	{
		if (declare.camp == 0)
		{
			mBattlePtr user = ptr->currentUser();
			if (user->passLimit(declare))
			{
				uni->pushAim(user);
			}
		}
		else
		{
			aim_single_new(logic, ptr, uni, declare);
		}
	}

	void battleLogic::aim_current_sign(battleLogic* logic, BattleData::envPtr ptr, BattleData::unitPtr uni, const AIM::structAIM& declare)
	{
		//ʲôҲ����
	}

	void battleLogic::aim_other_new(battleLogic* logic, BattleData::envPtr ptr, BattleData::unitPtr uni, const AIM::structAIM& declare)
	{
		if (declare.camp == 0)
		{
			sBattlePtr useSide = ptr->handAtk;
			manList mL = useSide->getALLUser(declare);
			for (unsigned num = 0; num < mL.size(); ++num)
			{
				mBattlePtr m = mL[num];
				if (m == ptr->currentUser())continue;
				uni->pushAim(m);
			}
		}
		else
		{
			aim_single_new(logic, ptr, uni, declare);
			if (!uni->hasMainAim())return;
			mBattlePtr aimMain = uni->mainAim()->aim_;
			uni->clearAim();//�����״�ѡ������Ŀ��
			sBattlePtr useSide = ptr->handDef;
			manList mL = useSide->getALLUser(declare);
			for (unsigned num = 0; num < mL.size(); ++num)
			{
				mBattlePtr m = mL[num];
				if (aimMain == m)continue;
				uni->pushAim(mL[num]);
			}
		}
	}

	void battleLogic::aim_other_sign(battleLogic* logic, BattleData::envPtr ptr, BattleData::unitPtr uni, const AIM::structAIM& declare)
	{
		mBattlePtr main_aim = uni->mainAim() ? uni->mainAim()->aim_ : mBattlePtr();
		uni->clearAim();//�����״�ѡ������Ŀ��
		if (declare.camp == 0)
		{
			sBattlePtr useSide = ptr->handAtk;
			manList mL = useSide->getALLUser(declare);
			for (unsigned num = 0; num < mL.size(); ++num)
			{
				mBattlePtr m = mL[num];
				if (m == ptr->currentUser())continue;
				uni->pushAim(m);
			}
		}
		else
		{
			sBattlePtr useSide = ptr->handDef;
			manList mL = useSide->getALLUser(declare);
			for (unsigned num = 0; num < mL.size(); ++num)
			{
				mBattlePtr m = mL[num];
				if (main_aim == m)continue;
				uni->pushAim(mL[num]);
			}
		}
	}

	void battleLogic::aim_all_new(battleLogic* logic, BattleData::envPtr ptr, BattleData::unitPtr uni, const AIM::structAIM& declare)
	{
		if (declare.camp == 0)
		{
			sBattlePtr useSide = ptr->handAtk;
			manList mL = useSide->getALLUser(declare);
			for (unsigned num = 0; num < mL.size(); ++num)
			{
				uni->pushAim(mL[num]);
			}
		}
		else
		{
			aim_single_new(logic, ptr, uni, declare);
			if (!uni->hasMainAim())return;
			mBattlePtr aimMain = uni->mainAim()->aim_;
			sBattlePtr useSide = ptr->handDef;
			manList mL = useSide->getALLUser(declare);
			for (unsigned num = 0; num < mL.size(); ++num)
			{
				mBattlePtr m = mL[num];
				if (aimMain == m)continue;
				uni->pushAim(mL[num]);
			}
		}
	}


	void battleLogic::aim_all_sign(battleLogic* logic, BattleData::envPtr ptr, BattleData::unitPtr uni, const AIM::structAIM& declare)
	{
		mBattlePtr main_aim = uni->mainAim() ? uni->mainAim()->aim_ : mBattlePtr();
		if (declare.camp == 0)
		{
			sBattlePtr useSide = ptr->handAtk;
			manList mL = useSide->getALLUser(declare);
			for (unsigned num = 0; num < mL.size(); ++num)
			{
				mBattlePtr m = mL[num];
				if (main_aim == m)continue;
				uni->pushAim(mL[num]);
			}
		}
		else
		{
			sBattlePtr useSide = ptr->handDef;
			manList mL = useSide->getALLUser(declare);
			for (unsigned num = 0; num < mL.size(); ++num)
			{
				mBattlePtr m = mL[num];
				if (main_aim == m)continue;
				uni->pushAim(mL[num]);
			}
		}
	}

	//////////////////////////////////////////////////////////////////////////end
}
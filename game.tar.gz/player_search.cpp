#include "player_search.h"
#include "search_system.h"
#include "res_code.h"
#include "playerManager.h"
#include "task_mgr.h"
#include "item_system.h"

namespace gg
{
	playerSearch::playerSearch(playerData* const own)
		: _auto_player(own)
	{
		_first_search_ww = 0;
		_first_search_cs = 0;
		_single_cd = 0;
		_multi_cd = 0;
		_free_search_ww = 0;
		_free_search_cs = 0;

		_ww_search_times = 0;
		_cs_search_times = 0;
		
		//�̵�
		_ww_flush_times = 0;
		_cs_flush_times = 0;

		_ww_records.clear();
		_cs_records.clear();
	}

	void playerSearch::classLoad()
	{
		mongo::BSONObj key = BSON(strPlayerID << Own().ID());
		mongo::BSONObj obj = db_mgr.FindOne(DBN::dbPlayerSearch, key);
		
		if (obj.isEmpty()) 
			return;

		checkNotEoo(obj["cdww"])
			_free_search_ww = obj["cdww"].Int();
		checkNotEoo(obj["cdcs"])
			_free_search_cs = obj["cdcs"].Int();
		checkNotEoo(obj["fww"])
			_first_search_ww = obj["fww"].Int();
		checkNotEoo(obj["fcs"])
			_first_search_cs = obj["fcs"].Int();
		checkNotEoo(obj["wwft"])
			_ww_flush_times = obj["wwft"].Int();
		checkNotEoo(obj["csft"])
			_cs_flush_times = obj["csft"].Int();
		checkNotEoo(obj["wwst"])
			_ww_search_times = obj["wwst"].Int();
		checkNotEoo(obj["csst"])
			_cs_search_times = obj["csst"].Int();
		checkNotEoo(obj["wwsr"])
		{
			std::vector<mongo::BSONElement> ele = obj["wwsr"].Array();
			for (unsigned i = 0; i < ele.size(); ++i)
				_ww_records.push_back(Search::ShopRecord(ele[i]["id"].Int(), ele[i]["bt"].Int()));
		}
		checkNotEoo(obj["cssr"])
		{
			std::vector<mongo::BSONElement> ele = obj["cssr"].Array();
			for (unsigned i = 0; i < ele.size(); ++i)
				_cs_records.push_back(Search::ShopRecord(ele[i]["id"].Int(), ele[i]["bt"].Int()));
		}
	}

	bool playerSearch::_auto_save()
	{
		mongo::BSONObj key = BSON(strPlayerID << Own().ID());
		mongo::BSONObjBuilder obj;
		obj << strPlayerID << Own().ID() <<
			"wwft" << _ww_flush_times << "csft" << _cs_flush_times <<
			"wwst" << _ww_search_times << "csst" << _cs_search_times <<
			"cdww" << _free_search_ww << "cdcs" << _free_search_cs <<
			"fww" << _first_search_ww << "fcs" << _first_search_cs;
		{
			mongo::BSONArrayBuilder b;
			ForEachC(SearchShopRecords, it, _ww_records)
				b.append(BSON("id" << it->_id << "bt" << it->_buy_times));
			obj << "wwsr" << b.arr();
		}
		{
			mongo::BSONArrayBuilder b;
			ForEachC(SearchShopRecords, it, _cs_records)
				b.append(BSON("id" << it->_id << "bt" << it->_buy_times));
			obj << "cssr" << b.arr();
		}
		return db_mgr.SaveMongo(DBN::dbPlayerSearch, key, obj.obj());
	}

	void playerSearch::_auto_update()
	{
		update();
	}

	void playerSearch::update()
	{
		Json::Value res;
		res[strMsg][0u] = res_sucess;
		res[strMsg][1u]["scd"] = _single_cd;
		res[strMsg][1u]["mcd"] = _multi_cd;
		res[strMsg][1u]["wwst"] = _ww_search_times;//��n��
		res[strMsg][1u]["csst"] = _cs_search_times;//��n��
		res[strMsg][1u]["fww"] = _first_search_ww;
		res[strMsg][1u]["fcs"] = _first_search_cs;
		res[strMsg][1u]["cdww"] = _free_search_ww;
		res[strMsg][1u]["cdcs"] = _free_search_cs;
		Own().sendToClient(gate_client::player_search_data_resp, res);
	}

	void playerSearch::updateShopWW()
	{
		checkShopRecord();

		Json::Value res;
		res[strMsg][0u] = res_sucess;
		Json::Value& shop = res[strMsg][1u]["sl"];
		shop = Json::arrayValue;
		ForEachC(SearchShopRecords, it, _ww_records)
		{
			Json::Value tmp;
			tmp.append(it->_id);
			tmp.append(it->_buy_times);
			shop.append(tmp);
		}
		res[strMsg][1u]["ft"] = _ww_flush_times;
		Own().sendToClient(gate_client::player_search_ww_shop_info_resp, res);
	}

	int playerSearch::buyWW(int pos, int id, Json::Value& r)
	{
		if(pos <= 0 || pos > _ww_records.size())
			return err_illedge;

		Search::ShopRecord& rcd = _ww_records[pos - 1];
		if (rcd._id != id)
			return err_illedge;

		SearchShopData ptr = search_sys.getWWShopData(id);
		if (!ptr)
			return err_illedge;

		if (rcd._buy_times >= ptr->_buy_times)
			return err_goods_sale_out;
		
		if (Own().Res().getFame() < ptr->_consume_con)
			return err_fame_not_enough;

		int res = actionDoBox(Own().getOwnDataPtr(), ptr->_box, false);
		if (res == res_sucess)
		{
			int tmp = Own().Res().getFame();
			++rcd._buy_times;
			Own().Res().alterSearchPoints(0 - ptr->_consume_con);
			updateShopWW();
			_sign_save();
			r = actionRes();
			Log(DBLOG::strLogSearch, Own().getOwnDataPtr(), 1, tmp, Own().Res().getFame(), id, 1);
		}
		else
		{
			Json::Value error_code = actionError();
			res = error_code[0u][1u].asInt();
		}

		return res;
	}

	int playerSearch::flushWW()
	{
		int cost = search_sys.getWWFlushCost(_ww_flush_times);
		if (Own().Res().getCash() < cost)
			return err_gold_not_enough;
		Own().Res().alterCash(0 - cost);
		++_ww_flush_times;
		_ww_records.clear();
		checkShopRecord();
		updateShopWW();
		return res_sucess;
	}

	void playerSearch::updateShopCS()
	{
		checkShopRecord();

		Json::Value res;
		res[strMsg][0u] = res_sucess;
		Json::Value& shop = res[strMsg][1u]["sl"];
		shop = Json::arrayValue;
		ForEachC(SearchShopRecords, it, _cs_records)
		{
			Json::Value tmp;
			tmp.append(it->_id);
			tmp.append(it->_buy_times);
			shop.append(tmp);
		}
		res[strMsg][1u]["ft"] = _cs_flush_times;
		Own().sendToClient(gate_client::player_search_cs_shop_info_resp, res);
	}

	int playerSearch::buyCS(int pos, int id, Json::Value& r)
	{
		if (pos <= 0 || pos > _cs_records.size())
			return err_illedge;

		Search::ShopRecord& rcd = _cs_records[pos - 1];
		if (rcd._id != id)
			return err_illedge;

		SearchShopData ptr = search_sys.getCSShopData(id);
		if (!ptr)
			return err_illedge;

		if (rcd._buy_times >= ptr->_buy_times)
			return err_goods_sale_out;

		if (Own().Res().getSearchPoints() < ptr->_consume_con)
			return err_search_point_not_enough;

		int res = actionDoBox(Own().getOwnDataPtr(), ptr->_box, false);
		if (res == res_sucess)
		{
			int tmp = Own().Res().getSearchPoints();
			++rcd._buy_times;
			Own().Res().alterSearchPoints(0 - ptr->_consume_con);
			updateShopCS();
			_sign_save();
			r = actionRes();
			Log(DBLOG::strLogSearch, Own().getOwnDataPtr(), 2, tmp, Own().Res().getSearchPoints(), id, 1);
		}
		else
		{
			Json::Value error_code = actionError();
			res = error_code[0u][1u].asInt();
		}

		return res;
	}

	int playerSearch::flushCS()
	{
		int cost = search_sys.getCSFlushCost(_cs_flush_times);
		if (Own().Res().getCash() < cost)
			return err_gold_not_enough;
		Own().Res().alterCash(0 - cost);
		++_cs_flush_times;
		_cs_records.clear();
		checkShopRecord();
		updateShopCS();
		return res_sucess;
	}

	void playerSearch::checkShopRecord()
	{
		if (_ww_records.empty())
		{
			std::vector<int> id_list;	

			search_sys.getWWShopList(Own().Info().Nation(), id_list);

			for (unsigned i = 0; i < id_list.size(); ++i)
				_ww_records.push_back(Search::ShopRecord(id_list[i], 0));

			_sign_save();
		}

		if (_cs_records.empty())
		{
			std::vector<int> id_list;

			search_sys.getCSShopList(Own().Info().Nation(), id_list);

			for (unsigned i = 0; i < id_list.size(); ++i)
				_cs_records.push_back(Search::ShopRecord(id_list[i], 0));

			_sign_save();
		}
	}

	void playerSearch::dailyTick()
	{
		_ww_records.clear();
		_cs_records.clear();
		checkShopRecord();
		_ww_flush_times = 0;
		_cs_flush_times = 0;
		
		_ww_search_times = 0;
		_sign_auto();
	}
}

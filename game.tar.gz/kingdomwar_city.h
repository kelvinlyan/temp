#pragma once

#include "mongoDB.h"
#include "auto_base.h"
#include "battle_def.h"
#include "battle_system.h"
#include "kingdomwar_def.h"
#include "kingdomwar_helper.h"
#include "kingdomwar_npc.h"
#include "kingdomwar_shadow.h"

namespace gg
{
	namespace KingdomWar
	{
		enum
		{
			UseHpItem = 0,
			UpManHpByFood,
		};

		const static int MainCity[] = {7, 18, 29};

		inline static bool isMainID(int id)
		{
			return id == MainCity[0]
				|| id == MainCity[1]
				|| id == MainCity[2];
		}

		class City;
		BOOSTSHAREPTR(City, CityPtr);
		class Path;
		BOOSTSHAREPTR(Path, PathPtr);
		class BattleField;
		BOOSTSHAREPTR(BattleField, BattleFieldPtr);

		namespace nCity
		{
			class ItemBase;
			BOOSTSHAREPTR(ItemBase, ItemPtr);
			STDLIST(ItemPtr, ItemList);

			struct BattleInfo
			{
				sBattlePtr ptr;
				std::vector<int> max_hp;
				std::vector<int> pre_hp;
				int cur_hp;
				int win_streak;
				int silver;
				int exploit;
				std::string rep_id;
			};

			class ReportData
			{
				public:
					ReportData(unsigned time, ItemPtr& atk_ptr, ItemPtr& def_ptr);

					void one2one();
					void done();
					void getInfo(qValue& q);

					unsigned time;
					O2ORes result;
					std::string path;
					BattleReport data;

					BattleInfo atk_info;
					BattleInfo def_info;
			};

			BOOSTSHAREPTR(ReportData, ReportDataPtr);

			enum
			{
				ELECTOWER = 0,
				TOWER_MAX,
			};

			class TowerBase
				: public boost::enable_shared_from_this<TowerBase>
			{
				public:
					TowerBase(int nation, unsigned remain_time, unsigned dead_time, BattleFieldPtr bf);
					virtual ~TowerBase(){}

					int id() const { return _id; }
					unsigned deadTime() const { return _dead_time; }
					unsigned remainTime() const { return _remain_time; }
					int nation() const { return _nation; }

					void alterLifeTime(unsigned cur_time, int secs);
					void setDeadTimer(unsigned cur_time = 0);
					void stopDeadTimer(unsigned cur_time = 0);
					void tickDead(unsigned timer_id, unsigned tick_time);
					virtual void tickPrimeState(unsigned tick_time);
					virtual void setDead(unsigned tick_time);

					virtual int type() const = 0;
					virtual void getInfo(qValue& q) const = 0;
					virtual mongo::BSONObj toBSON() const = 0;

				protected:
					BattleFieldPtr _battle_field;

				private:
					int _id;
					int _nation;
					unsigned _dead_timer;
					unsigned _dead_time;
					int _remain_time;
			};

			BOOSTSHAREPTR(TowerBase, TowerPtr);

			class ElecTower
				: public TowerBase
			{
				public:
					ElecTower(const mongo::BSONElement& obj, BattleFieldPtr bf);
					ElecTower(unsigned cur_time, int nation, BattleFieldPtr bf);

					void setAttackTimer(unsigned cur_time = 0);

					virtual int type() const { return ELECTOWER; }
					virtual mongo::BSONObj toBSON() const;
					virtual void getInfo(qValue& q) const;

				private:
					void tickAttack(unsigned timer_id, unsigned tick_time);
					virtual void tickPrimeState(unsigned tick_time);
					virtual void setDead(unsigned tick_time);

				private:
					unsigned _attack_timer;
					unsigned _next_attack_time;
			};

			BOOSTSHAREPTR(ElecTower, ElecTowerPtr);

			class ItemBase
			{
				public:
					ItemBase(CityPtr& ptr)
						: _city(ptr){}
					
					virtual ~ItemBase(){}
					virtual mongo::BSONObj toBSON() const = 0;
					virtual void getInfo(qValue& q) const = 0;
					virtual void getUpInfo(int type, qValue& q) const = 0;
					virtual void getStateInfo(qValue& q, int state) const = 0;
					virtual void getTableInfo(qValue& q) const = 0;
					virtual void getManInfo(qValue& q) const = 0;

					virtual int id() const = 0;
					virtual int type() const = 0;
					virtual std::string name() const = 0;
					virtual int nation() const = 0;
					virtual BattleInfo getBattleInfo() = 0;
					virtual void tickBattle(ReportDataPtr& rep_data, ItemPtr& target, bool atk_side) = 0;
					virtual void doneBattle(ReportDataPtr& rep_data, ItemPtr& target, bool atk_side) = 0;
					virtual bool isDead() = 0;
					virtual void beDead(unsigned time, Json::Value& tips) = 0;
					virtual void enter(unsigned time){}
					virtual int tickElecAttack(unsigned time) = 0;

				protected:
					CityPtr _city;
			};

			class IPlayer
				: public ItemBase
			{
				public:
					IPlayer(playerDataPtr& d, int army_id, CityPtr& ptr);

					virtual int id() const { return _pid; }
					virtual mongo::BSONObj toBSON() const;
					virtual void getInfo(qValue& q) const;
					virtual void getUpInfo(int type, qValue& q) const;
					virtual void getStateInfo(qValue& q, int state) const;
					virtual void getTableInfo(qValue& q) const;
					virtual void getManInfo(qValue& q) const;

					virtual int type() const { return Player; }
					virtual std::string name() const { return _name; }
					virtual int nation() const { return _nation; }
					virtual BattleInfo getBattleInfo();
					virtual void tickBattle(ReportDataPtr& rep_data, ItemPtr& target, bool atk_side);
					virtual void doneBattle(ReportDataPtr& rep_data, ItemPtr& target, bool atk_side);
					virtual bool isDead();
					virtual void beDead(unsigned time, Json::Value& tips);
					virtual void enter(unsigned time);
					virtual int tickElecAttack(unsigned time);

					int pid() const { return _pid; }
					int armyId() const { return _army_id; } 
					int lv() const { return _lv; }
					void alterName(const std::string& name) { _name = name; }
					void tryUpHp();

				private:
					void resetHp(sBattlePtr& ptr);

				private:
					int _pid;
					int _army_id;
					std::string _name;
					int _lv;
					int _face;
					int _nation;
					BattleEquipList _equip;
			};

			BOOSTSHAREPTR(IPlayer, PlayerPtr);
			STDVECTOR(PlayerPtr, PlayerList);

			class INpc
				: public ItemBase
			{
				public:
					INpc(NpcDataPtr npc_data, CityPtr& ptr);

					virtual mongo::BSONObj toBSON() const;
					virtual void getInfo(qValue& q) const;
					virtual void getUpInfo(int type, qValue& q) const;
					virtual void getStateInfo(qValue& q, int state) const;
					virtual void getTableInfo(qValue& q) const;
					virtual void getManInfo(qValue& q) const;

					virtual int type() const { return _data->type(); }
					virtual std::string name() const { return _data->name(); }
					virtual int nation() const { return _data->nation(); }
					virtual BattleInfo getBattleInfo();
					virtual void tickBattle(ReportDataPtr& rep_data, ItemPtr& target, bool atk_side);
					virtual void doneBattle(ReportDataPtr& rep_data, ItemPtr& target, bool atk_side);
					virtual bool isDead() { return _data->isDead(); }
					virtual void beDead(unsigned time, Json::Value& tips);
					virtual int tickElecAttack(unsigned time);

					bool valid() const { return _data->valid(); }
					virtual int id() const { return _data->id(); }
					const NpcDataPtr& npcData() const { return _data; }

				private:
					inline int face() const;
					inline int lv() const;

				private:
					NpcDataPtr _data;
			};

			BOOSTSHAREPTR(INpc, NpcPtr);
			STDLIST(NpcPtr, NpcList);

			class IShadow
				: public ItemBase
			{
				public:
					IShadow(ShadowDataPtr npc_data, CityPtr& ptr);

					virtual mongo::BSONObj toBSON() const;
					virtual void getInfo(qValue& q) const;
					virtual void getUpInfo(int type, qValue& q) const;
					virtual void getStateInfo(qValue& q, int state) const;
					virtual void getTableInfo(qValue& q) const;
					virtual void getManInfo(qValue& q) const;

					virtual int type() const { return Shadow; }
					virtual std::string name() const { return _data->data()->playerName; }
					virtual int nation() const { return _data->nation(); }
					virtual BattleInfo getBattleInfo();
					virtual void tickBattle(ReportDataPtr& rep_data, ItemPtr& target, bool atk_side);
					virtual void doneBattle(ReportDataPtr& rep_data, ItemPtr& target, bool atk_side);
					virtual bool isDead() { return _data->isDead(); }
					virtual void beDead(unsigned time, Json::Value& tips);
					virtual int tickElecAttack(unsigned time);

					virtual int id() const { return _data->id(); }
					const ShadowDataPtr& shadowData() const { return _data; }
					const BattleEquipList& equipList() const;

				private:
					inline int lv() const;
					inline int face() const;
					int ownID() const { return _data->ownID(); }

				private:
					ShadowDataPtr _data;
			};

			BOOSTSHAREPTR(IShadow, ShadowPtr);

			class IShadowNpc
				: public ItemBase
			{
				public:
					IShadowNpc(ShadowNpcDataPtr data, CityPtr& ptr);

					virtual mongo::BSONObj toBSON() const;
					virtual void getInfo(qValue& q) const;
					virtual void getUpInfo(int type, qValue& q) const;
					virtual void getStateInfo(qValue& q, int state) const;
					virtual void getTableInfo(qValue& q) const;
					virtual void getManInfo(qValue& q) const;

					virtual int type() const { return _data->type(); }
					virtual std::string name() const { return _data->name(); }
					virtual int nation() const { return _data->nation(); }
					virtual BattleInfo getBattleInfo();
					virtual void tickBattle(ReportDataPtr& rep_data, ItemPtr& target, bool atk_side);
					virtual void doneBattle(ReportDataPtr& rep_data, ItemPtr& target, bool atk_side);
					virtual bool isDead() { return _data->isDead(); }
					virtual void beDead(unsigned time, Json::Value& tips);
					virtual int tickElecAttack(unsigned time);

					bool valid() const { return _data->valid(); }
					virtual int id() const { return _data->id(); }
					int ownID() const { return _data->ownID(); }
					const ShadowNpcDataPtr& shadowData() const { return _data; }

				private:
					inline int face() const;
					inline int lv() const;

				private:
					ShadowNpcDataPtr _data;
			};

			BOOSTSHAREPTR(IShadowNpc, ShadowNpcPtr);

			class ItemCounter
			{
				public:
					STDMAP(int, PlayerList, PlayerMap);
					STDVECTOR(int, NumVec);

					ItemCounter(CityPtr ptr);

					void push(ItemPtr ptr);
					void pop(ItemPtr ptr);
					void updateName(playerDataPtr& d);
					void clear();

					const NumVec& num() const { return _num; }

				private:
					bool pushPlayer(PlayerMap& cmap, PlayerPtr& ptr);
					bool popPlayer(PlayerMap& cmap, PlayerPtr& ptr);

				private:
					NumVec _num;
					PlayerMap _player_map;
					CityPtr _city;
			};

			BOOSTSHAREPTR(ItemCounter, Counter);

			class UpBase
			{
				public:
					virtual ~UpBase(){}
					virtual void getInfo(qValue& q) const = 0;
			};

			BOOSTSHAREPTR(UpBase, UpBasePtr);

			class UpDataMgr
			{
				public:
					void push(const UpBasePtr& ptr)
					{
						_up_list.push_back(ptr);
					}
					void getInfo(qValue& q) const
					{
						ForEachC(UpList, it, _up_list)
						{
							qValue tmp;
							(*it)->getInfo(tmp);
							q.append(tmp);
						}
					}
					void clear()
					{
						_up_list.clear();
					}
					unsigned size() const
					{
						return _up_list.size();
					}
					unsigned capacity() const
					{
						return _up_list.capacity();
					}

				private:
					STDVECTOR(UpBasePtr, UpList);
					UpList _up_list;
			};

			class ReadyQueue
			{
				public:
					ReadyQueue();

					bool empty() const { return _real_size == 0; }
					unsigned size() const { return _queue.size(); }
					unsigned realSize() const { return _real_size; }

					ItemPtr find(int id, int& pos) const;
					ItemPtr find(int pid, int army_id, int& pos) const;
					ItemPtr findFirst(int pid, int& pos) const;
					ItemPtr front() const;
					ItemPtr pop(int pos);
					ItemPtr popFront();
					bool pop(const ItemPtr& ptr);

					void pushBack(const ItemPtr& ptr);
					bool swap(const ItemPtr& in_ptr, int& in_pos, ItemPtr& out_ptr, int& out_pos);

					void clear();

					int getNpcPos() const;
					void getInfo(qValue& q) const;
					void getStateInfo(qValue& q) const;
					void toDead(unsigned cur_time, Json::Value& tips);
					const std::deque<ItemPtr>& getQueue() const { return _queue; }

				private:
					unsigned nullNum() const;
					void popFrontNull();

				private:
					unsigned _real_size;
					std::deque<ItemPtr> _queue;
			};
		}

		class BattleField
			: public _auto_meta
		{
			public:
				friend class City;
				BattleField(CityPtr& ptr);

				void init();
				void tick();
				int state() const { return _state; }
				bool inBattle() const
				{
					return _state != Closed && _state != Protected;
				}
				unsigned protectedTime() const
				{
					return _state == Protected? _next_tick_time : 0;
				}

				void handleAddAttacker(unsigned tick_time);
				void handleAddDefender(unsigned tick_time);
				int callElecTower(unsigned cur_time, playerDataPtr d);
				int fight(unsigned cur_time, playerDataPtr d);

				void getInfo(qValue& q) const;
				void getItemList(qValue& q, int side);
				int getTableInfo(qValue& q, int id, int army_id = 0) const;
				bool onFight(playerDataPtr& d, int army_id);
				bool onFight(NpcDataPtr d);
				bool inBattle(playerDataPtr d, int army_id) const;
				int upHpNumInBattle(playerDataPtr d, int army_id) const;
				void clear(unsigned tick_time);
				void tickPrimeState(unsigned cur_time);

				bool getTowerPos(int id, int& side, int& pos);
				void removeTower(unsigned cur_time, int id);
				nCity::TowerPtr moveTower(nCity::TowerPtr& ptr);
				void tickElecAttack(unsigned cur_time, int id);
				void upTowerLifeTime(int id);
				int alterTowerLifeTime(unsigned cur_time, playerDataPtr d, int id, int secs);

				void resetData();
				void DebugInfo();
				
			private:
				void loadDB();
				virtual bool _auto_save();
				virtual void _sign_save();

				void setBattleTimer(unsigned tick_time, int queue_id);
				unsigned getOpenTime(unsigned cur_time);
				unsigned getProtectedTime(unsigned cur_time);
				void setOpenTimer();
				void setCloseTimer();
				void setAttackerWaitTimer();
				void setDefenderWaitTimer();
				void changeState(int state, unsigned cur_time = 0);

				void tickStartWait(unsigned tick_time);
				void tickProtected(unsigned tick_time, int nation);
				void tickClose(unsigned tick_time);
				void tickOpen(unsigned timer_id, unsigned tick_time);
				void tickAttackerWait(unsigned timer_id, unsigned tick_time);
				void tickDefenderWait(unsigned timer_id, unsigned tick_time);
				void tickCloseFromProtected(unsigned timer_id, unsigned tick_time);
				void tickBattle(unsigned timer_id, unsigned tick_time, int queue_id);
				void doneBattle(unsigned timer_id, unsigned tick_time, int queue_id, nCity::ReportDataPtr& rep_data);
				void tryUpHp(int side, int idx, nCity::ItemPtr& ptr);
				
				bool toAttackerWait(unsigned tick_time);
				bool toDefenderWait(unsigned tick_time);
				bool tryLoadReadyAttacker(unsigned tick_time);
				bool doLoadReadyAttacker(unsigned tick_time);
				bool tryLoadReadyDefender(unsigned tick_time);
				bool doLoadReadyDefender(unsigned tick_time, int pos);
				void initReadyAttacker(unsigned tick_time);
				void initReadyDefender(unsigned tick_time);
				int getNpcPosIdx() const;
				bool tryMoveAttacker(unsigned tick_time);
				bool tryMoveDefender(unsigned tick_time);
				bool tryGetBoth(unsigned tick_time, int queue_id);
				void crossDefender(unsigned tick_time, int qid_from, int qid_to);
				bool tryResetDefender(unsigned tick_time, int queue_id);
				void getPlayer(unsigned tick_time, int side, int queue_id);
				bool tryGetAttacker(unsigned tick_time, int queue_id);
				bool tryGetDefender(unsigned tick_time, int queue_id);
				void startTowerTimer(unsigned tick_time);
				nCity::ItemPtr getElecAttackPlayer(unsigned tick_time, int side);
				nCity::ItemPtr getElecAttackPlayerFromBattleQueue(int side);
				nCity::TowerPtr getElecAttackTower(unsigned tick_time, int side, int& pos) const;
				nCity::ItemPtr getFightAttacker(playerDataPtr d);
				void popFightAttacker(const Json::Value& tips, nCity::ItemPtr& ptr);
				bool noAttackers() const;
				bool noDefenders() const;
				bool noTower(int side) const;

				int getWinNation();
				void addWins(int res, nCity::ItemPtr atk_ptr, nCity::ItemPtr def_ptr);

				void push(int queue_id, bool is_attacker_queue, nCity::ItemPtr ptr);
				void pop(int queue_id, bool is_attacker_queue, int type);
				void resetMainInfo() const;
				void reset(unsigned cur_time);
				nCity::ItemPtr makeItem(const mongo::BSONElement& obj, int side);
				nCity::TowerPtr createTower(const mongo::BSONElement& obj);
				void removeTowerFromType(int side, int type, int id);
				void resetTowerAfterBattle(unsigned tick_time, int nation);
				void clearTower(unsigned tick_time);

				void siegeInfo(bool result, unsigned tick_time);
				void emailReward(int nation);

				nCity::ItemPtr find(int id, int army_id = 0) const;
				bool match(const nCity::ItemPtr& ptr, int id, int army_id = 0) const;

			private:
				CityPtr _city;
				int _state;
				bool _modified;
				
				nCity::UpDataMgr _updater;
				mutable qValue _main_info;
				std::vector<nCity::ReportDataPtr> _rep_data;

				struct BattleQueue
				{
					BattleQueue(): battle_timer(0){}

					bool in_battle;

					unsigned battle_timer;
					unsigned next_battle_time;

					unsigned atk_ready_time;
					nCity::ItemPtr atk_side;

					unsigned def_ready_time;
					nCity::ItemPtr def_side;
				};

				std::vector<BattleQueue> _battle_queues;
				nCity::ReadyQueue _ready_attackers;
				nCity::ReadyQueue _ready_defenders;
				unsigned _tick_timer;
				unsigned _next_tick_time;
				int _first_battle_nation;
				std::vector<int> _wins;
				
				STDMAP(int, unsigned, ExploitMap);
				ExploitMap _exploit_map;

				nCity::Counter _counter;

				STDVECTOR(nCity::TowerPtr, TowerList);
				TowerList _atk_tower;
				TowerList _def_tower;
				unsigned _end_wait_times;
		};


		class City
			: public _auto_meta, public Observer
		{
			public:
				friend class BattleField;

				City(const Json::Value& info);

				void loadDB();
				void init();
				int id() const { return _id; }
				int state() const { return _battle_field->state(); }
				int clientState() const;
				int nation() const { return _nation; }
				unsigned protectedTime() const { return _battle_field->protectedTime(); }
				int rewardBoxNum() const { return _cur_box_num; }
				bool boxState(playerDataPtr d) const;
				bool onFired() const { return _battle_field && _battle_field->state() != Closed && _battle_field->state() != Protected; }
				bool inBattle(playerDataPtr d, int army_id) const { return _battle_field->inBattle(d, army_id); }
				int upHpNumInBattle(playerDataPtr d, int army_id) const { return _battle_field->upHpNumInBattle(d, army_id); }

				void updateAll();

				void attach(int id);
				void addExploit(int pid, int num);
				void getTowerInfo(qValue& q) const;
				void getNumInfo(qValue& q) const;

				void tryLoadPlayer(playerDataPtr& d, int army_id);
				void tryLoadNpc(NpcDataPtr& d);
				void tryLoadShadow(ShadowDataPtr& d);
				void tryLoadShadowNpc(ShadowNpcDataPtr& d);
				void addPath(const PathPtr& ptr) { _paths.push_back(ptr); }
				int getTableInfo(qValue& q, int id, int army_id = 0) const { return _battle_field->getTableInfo(q, id, army_id); }

				int enter(unsigned time, playerDataPtr d, int army_id, Json::Value& tips);
				int enter(unsigned time, NpcDataPtr d);
				int enter(unsigned time, ShadowDataPtr d);
				int enter(unsigned time, ShadowNpcDataPtr d);
				int enter(unsigned time, nCity::ItemPtr d);
				int leave(unsigned time, playerDataPtr d, int army_id, int to_city_id);
				int transfer(unsigned time, playerDataPtr d, int army_id, int to_city_id);
				int fight(unsigned cur_time, playerDataPtr d) { return _battle_field->fight(cur_time, d); }
				int callShadow(unsigned cur_time, playerDataPtr d, int type, int use_res, Json::Value& r);
				int callElecTower(unsigned cur_time, playerDataPtr d);
				int useTowerItem(unsigned cur_time, playerDataPtr d, int type, int tid, Json::Value& r);
				int getSilverBox(playerDataPtr d, Json::Value& r);

				void getMainInfo(qValue& q);
				void getMilitaryInfo(qValue& q);
				void getFighterList(qValue& q, int side);

				bool onFight(playerDataPtr d, int army_id);
				bool onFight(NpcDataPtr d);

				int getOutput(int nation) const { return _output[nation]; }
				int outputType() const { return _output_type; }
				int maxOutput() const { return _output_max; }

				void addBuff(playerDataPtr& d, sBattlePtr ptr);
				void addBuff(sBattlePtr ptr, int nation);

				unsigned getSup(unsigned cur_time);	

				void updateName(playerDataPtr d) { _counter->updateName(d); }

				void tickUnity(unsigned tick_time);
				void tickResetUnity(unsigned tick_time);
				void tickPrimeState(unsigned tick_time);

				void clearTower(unsigned cur_time) { _battle_field->clearTower(cur_time); }

			private:
				virtual bool _auto_save();
				void tickOutput(unsigned cur_time);
				void tickCreateNpc(unsigned cur_time);
				void tickCreateActiveNpc(unsigned cur_time);
				void doTickCreateActiveNpc(unsigned cur_time, PathPtr& ptr, int to_id);
				void resetSupRate(unsigned tick_time);
				void initNpc(unsigned cur_time);
				void initMaxNpc(unsigned cur_time);
				void alterNation(int nation);
				void initNation(int nation = -1);

				void noticeAddAttacker(unsigned tick_time);
				void noticeAddDefender(unsigned tick_time);
				void handleBattleResult(unsigned tick_time, bool result, int nation = -1);
				void handleEndProtected(unsigned tick_time);

				nCity::ItemPtr getAttacker();
				nCity::ItemPtr getAttacker(int pid, int army_id);
				nCity::ItemPtr getAttacker(int npc_id);
				nCity::ItemPtr getDefender();
				nCity::ItemPtr getDefender(int pid, int army_id);
				nCity::ItemPtr getDefender(int npc_id);

				PathPtr getPath(int to_id) const;
				bool eraseItem(playerDataPtr d, int army_id);

				ShadowDataPtr createShadow(unsigned cur_time, playerDataPtr d, int army_id, int type);
				ShadowNpcDataPtr createShadowDefenseNpc(unsigned cur_time, playerDataPtr d);
				ShadowNpcDataPtr createShadowNpc(unsigned cur_time, playerDataPtr d);
				ShadowNpcDataPtr createShadowAdvancedNpc(unsigned cur_time, playerDataPtr d);
				nCity::NpcPtr createNpc(unsigned cur_time, int type, int map_id);

				inline bool inProtected(int nation) const;
				int getShadowIndex(int side) const;
				
			private:
				int _id;
				int _nation;
				int _belong_nation;
				bool _is_main;
				std::vector<PathPtr> _paths;

				nCity::ItemList _npc_list;
				nCity::ItemList _attacker_backup;
				nCity::ItemList _defender_backup;
				BattleFieldPtr _battle_field;
				nCity::Counter _counter;

				STDVECTOR(int, Output);
				Output _output;
				int _output_type;
				int _output_max;

				std::vector<int> _npc_add;
				std::vector<int> _npc_max;
				std::vector<int> _npc_start;

				int _buff_type;
				std::vector<int> _buff_value;

				unsigned _sup_base;
				unsigned _sup_time;
				double _sup_rate;

				unsigned _npc2_interval;
				unsigned _npc2_num;
				unsigned _next_npc2_time;
				int _broadcast_1;
				int _broadcast_2;

				int _max_box_num;
				int _cur_box_num;
				std::set<int> _get_box_players;

				int _state_helper;
		};

		class CityCounter
		{
			SINGLETON(CityCounter);
			public:
				void alter(int nation, int old_nation = -1);

				int unityNation() const;
				unsigned num(int nation) const { return _num[nation]; }
				int strength(int nation) const;

			private:
				std::vector<unsigned> _num;
		};

		STDVECTOR(CityPtr, CityList);

		class CityMgr
		{
			SINGLETON(CityMgr);
			public:
				void loadDB();
				void init();

				CityPtr getCity(int id);
				void push(const CityPtr& ptr);
				int size() const { return _city_list.size(); }
				void clearTower(unsigned cur_time);

				void stateInfo(qValue& q);
				void nationInfo(qValue& q);
				void protectedTimeInfo(qValue& q);
				void boxInfo(qValue& q);

				const CityList& boxList() const { return _box_list; }
				void addBox(CityPtr ptr);
				void rmBox(CityPtr ptr);

				void resetUpInfo();
				void getUpInfo(qValue& up_state, qValue& up_nation, qValue& up_box);
				void tickUpdate(int type, CityPtr ptr);

				void tickPrimeState(unsigned tick_time);
				void tickUnity(unsigned tick_time);
				void tickResetUnity(unsigned tick_time);
				void getTowerInfo(qValue& q);

			private:
				CityList _city_list;

				CityList _up_state_info;
				CityList _up_nation_info;

				qValue _main_state_info;
				qValue _main_nation_info;
				qValue _main_protected_time_info;

				CityList _box_list;
		};

		class TowerMgr
		{
			SINGLETON(TowerMgr);
			public:
				void tick();
				void update(playerDataPtr d);
				void push(CityPtr ptr)
				{
					_up_list.push_back(ptr);
				}

			private:
				std::vector<CityPtr> _up_list;
				qValue _main_info;
				bool _valid;
		};

		class BattleNumMgr
		{
			SINGLETON(BattleNumMgr);
			public:
				void tick();
				void update(playerDataPtr d);
				void addOnFired(CityPtr ptr)
				{
					_on_fired_list.push_back(ptr);
					addUp(ptr);
				}
				void rmOnFired(CityPtr ptr)
				{
					ForEach(CityList, it, _on_fired_list)
					{
						if (*it == ptr)
						{
							_on_fired_list.erase(it);
							break;
						}
					}
				}
				void addUp(CityPtr ptr)
				{
					if (_up_flag.test(ptr->id()))
						return;
					_up_list.push_back(ptr);
					_up_flag.set(ptr->id());
				}

			private:
				CityList _on_fired_list;

				std::bitset<64> _up_flag;
				CityList _up_list;
				qValue _main_info;
				bool _valid;
		};
	}
}

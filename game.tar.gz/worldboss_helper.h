#pragma once

#include "man_def.h"
#include "commom.h"
#include "mongoDB.h"
#include "auto_base.h"
#include "battle_def.h"
#include "action_system.h"
#include "report_mgr.h"
#include "rank_list.h"

namespace gg
{
	namespace WorldBoss
	{
		enum{
			Closed = 0,
			Opened,

			OpenTime = 21 * HOUR,
			CloseTime = 21 * HOUR + 20 * MINUTE,

			UseMerit = 1,
			UseGold,

			KingdomType = 1,
			PersonType,

			DefaultFace = 200,
			CacheSize = 8,

			UISize = 8,
			RankSize = 20,
		};
		
		class Npc
		{
			public:
				friend class BossMgr;
				Npc(const Json::Value& obj);

			private:
				int _npc_id;
				bool _hold_morale;
				int _init_attr[characterNum];
				int _add_attr[characterNum]; // ?
				int _arms_type;
				double _arms_module[armsModulesNum];
				int _npc_level;
				unsigned _npc_pos;
				int _skill_1;
				int _skill_2;
				int _battle_value;
				std::set<int> _resist;
				BattleEquipList _equip_vec;
		};

		class Boss
		{
			public:
				friend class BossMgr;
				Boss(const Json::Value& obj);
			
			private:
				STDVECTOR(Npc, NpcList);
				int _map_id;
				std::string _map_name;
				int _map_level;
				int _face_id;
				int _bg_id;
				int _battle_value;
				NpcList _npc_list;
		};

		BOOSTSHAREPTR(Boss, BossPtr);
		STDMAP(int, BossPtr, BossMap);

		class BossMgr
		{
			public:
				void init();

				sBattlePtr getBattlePtr(int type, int map_id) const;

				int getMinMapId(int type) const
				{
					return type == 0? _min_map_id_1 : _min_map_id_2;
				}
				int getMaxMapId(int type) const
				{
					return type == 0? _max_map_id_1 : _max_map_id_2;
				}
				int getMinMapHp(int type) const
				{
					return type == 0? _min_map_hp_1 : _min_map_hp_2;
				}
				int getBgId(int type, int map_id) const;

			private:
				BossMap _boss_map_1;
				BossMap _boss_map_2;

				int _min_map_id_1;
				int _max_map_id_1;
				int _min_map_id_2;
				int _max_map_id_2;

				int _min_map_hp_1;
				int _min_map_hp_2;
		};

		class RewardRate
		{
			public:
				void init();
				double getRewardRate(unsigned cur_time) const;

			private:
				struct Item
				{
					Item(const Json::Value& obj);

					unsigned _up_time;
					unsigned _down_time;
					double _rate;
				};

				STDVECTOR(Item, Items);
				Items _items;
		};

		class IncentMgr
		{
			public:
				void init();

				int getIncentMaxId(int type) const;
				int getIncentCost(int type, int resource, int id) const;
				int getIncentBuff(int type, int id) const;
				double getIncentSucRate(int type, int id) const;
				
			private:
				struct Item
				{
					Item(const Json::Value& obj);

					int _need_merit;
					int _need_gold;
					int _buff;
					double _suc_rate;
				};

				STDVECTOR(Item, Items);
				Items _kingdom_incent;
				Items _person_incent;
		};

		class CleanCdCost
		{
			public:
				void init();
				int getCleanCdCost(unsigned times) const;

			private:
				STDVECTOR(int, CostList);
				CostList _costs;
		};

		class DamageBuff
		{
			public:
				void init();

				int getDamageBuffId(double damage_rate) const;
				int getDamageBuff(int id) const;

			private:
				struct Item
				{
					Item(const Json::Value& obj);
					double _hp_rate;
					int _buff;
				};
				STDVECTOR(Item, Items);
				Items _items;
		};

		class WeakBuff
		{
			public:
				void init();
				int getWeakBuff(int rank) const;

			private:
				STDVECTOR(int, Buffs);
				Buffs _buffs;
		};

		class RankReward
		{
			public:
				void init();
				const ACTION::BoxList& getRankReward(int rank) const;
				const Json::Value& getRankValue(int rank) const;

			private:
				STDVECTOR(ACTION::BoxList, RewardList);
				RewardList _rank_reward;
		};

		class Config
			: public BossMgr, public IncentMgr
			, public RewardRate, public CleanCdCost
			, public DamageBuff, public WeakBuff
			, public RankReward
		{
			public:
				void init();
		};

		class PrevInfo
		{
			public:
				PrevInfo();

				void load(const mongo::BSONElement& obj);
				mongo::BSONArray toBSON() const;

				int getMapId(int type) const;
				int getKillTime(int type) const;
				void setInfo(int type, int map_id, int kill_time);

			private:
				struct Item
				{
					int _map_id;
					int _kill_time;
				};
				Item _items[2];
		};

		class KingdomRank
		{
			public:
				KingdomRank();

				void clear();
				void addDamage(int nation, int damage);
				int getRank(int nation) const;
				int getDamage(int nation) const;

				void getInfo(Json::Value& info) const;

			private:
				struct Item
				{
					bool operator<(const Item& r) const
					{
						if (damage != r.damage)
							return damage > r.damage;
						return nation < r.nation;
					}

					int nation;
					unsigned damage;
					double rate;
				};

				STDVECTOR(Item, Items);
				Items items;
		};
		
		class PlayerInfo
		{
			public:
				PlayerInfo(playerDataPtr d);
				
				void getUIInfo(Json::Value& info) const;
				void getRankInfo(Json::Value& info) const;

				int id() const { return _pid; }
				int value() const { return _damage; }

			private:
				int _pid;
				std::string _name;
				int _face;
				int _nation;
				int _damage;
				double _rate;
				BattleEquipList _equip_vec;
		};

		BOOSTSHAREPTR(PlayerInfo, PlayerPtr);

		class RankList
		{
			public:
				typedef boost::function<void(const PlayerInfo&)> Handler;

				void getUIInfo(Json::Value& info);
				void getRankInfo(Json::Value& info);

				int getRank(playerDataPtr d) const;
				void update(playerDataPtr d, int old_damage);
				void clear();

				void run(Handler h);

			private:
				void packageUIInfo(const PlayerInfo& p);
				void packageRankInfo(const PlayerInfo& p);

			private:
				typedef RankList1<PlayerInfo> RankMgr;
				RankMgr _rank_mgr;

				mutable Json::Value _json;
		};

		class OwnReport
		{
			public:
				friend class ComReport;
					
				OwnReport(int damage, int map_id, int buff, const std::string& rep_id);
				OwnReport(const mongo::BSONElement& obj);

				mongo::BSONObj toBSON() const;
				void getInfo(Json::Value& info) const;
			
			private:
				int _damage;
				int _map_id;
				int _buff;
				std::string _rep_id;
		};

		BOOSTSHAREPTR(OwnReport, OwnReportPtr);

		class ComReport
			: public OwnReport
		{
			public:
				ComReport(int damage, int map_id, int buff, const std::string& rep_id, int pid, const std::string& name);
				ComReport(const mongo::BSONElement& obj);
				mongo::BSONObj toBSON() const;
				void getInfo(Json::Value& info) const;
			
			private:
				int _pid;
				std::string _name;
		};	

		BOOSTSHAREPTR(ComReport, ComReportPtr);
		

		typedef ReportMgr<OwnReport> OwnReportMgr;
		typedef ReportMgr<ComReport> ComReportMgr;
	}
}

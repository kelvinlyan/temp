#pragma once

#include "task_checker.h"
#include "action_system.h"
#include "auto_base.h"
#include "commom.h"
#include "dbDriver.h"

#define days_activity_sys (*gg::days_activity_system::_Instance)

namespace gg
{
	struct DayTarget
	{
		DayTarget(const Json::Value& info);

		int _count;
		ACTION::BoxList _reward;
		Json::Value _reward_info;
	};

	BOOSTSHAREPTR(DayTarget, DayTargetPtr);
	STDVECTOR(DayTargetPtr, DayTargets);

	struct DayTask
	{
		DayTask(const Json::Value& info);

		int _id;

		Json::Value _reward_info;
		ACTION::BoxList _reward;
		Task::CheckPtr _check_ptr;
	};

	BOOSTSHAREPTR(DayTask, DayTaskPtr);
	UNORDERMAP(int, DayTaskPtr, DayTaskMap);
	
	STDVECTOR(DayTaskPtr, DayTaskList);
	STDVECTOR(DayTaskList, DayTaskLists);

	class DayActivity
		: public boost::enable_shared_from_this<DayActivity>
	{
		public:
			enum
			{
				BeginShow = 0,
				BeginRun,
				EndRun,
				EndShow,
			};

			DayActivity(const Json::Value& info);

			int makeTimerId()
			{
				return ++_timer_id;
			}

			void resetCurDay();
			virtual void setTimer();

			int _key_id;
			unsigned _modify_time;
			std::string _name;
			int _timer_id;
			int _state;
			int _cur_day;
			int _max_day;

			Json::Value _gm_config;
		//	Json::Value _client_config;

			DayTaskLists _task_lists;
			DayTaskMap _task_map;
			DayTargets _targets;
	};

	BOOSTSHAREPTR(DayActivity, DayActivityPtr);
	STDMAP(int, DayActivityPtr, DayActivityMap);

	class days_activity_system
	{
		public:
			enum
			{
				Showing = 0,
				Running,

			};

			static days_activity_system* const _Instance;

			days_activity_system();

			void initData();

			DeclareRegFunction(activityInfoReq);
			DeclareRegFunction(playerInfoReq);
			DeclareRegFunction(getRewardReq);
			DeclareRegFunction(redPointReq);

			DeclareRegFunction(gmIDListReq);
			DeclareRegFunction(gmInfoReq);
			DeclareRegFunction(gmModifyReq);

			void update(playerDataPtr d, int type, int arg1 = -1, int arg2 = -1);
			int getKeyId() const;
			const std::string& getName() const { return _cur_activity->_name; }
			unsigned getModifyTime() const;
			int getDay() const;

			DayTaskList getDaysTask(int day);
			DayTaskPtr getTask(int id);
			DayTargetPtr getTarget(int id);
			int getTargetCount() const;

			void tickDay();
			void tick(int timer_id, int key_id, int state);
			void tickBeginShow(const DayActivityPtr& ptr);
			void tickEndShow(const DayActivityPtr& ptr);
			void tickBeginRun(const DayActivityPtr& ptr);
			void tickEndRun(const DayActivityPtr& ptr);

			Json::Value& param(){ return _param; }
			
		private:
			void updateActivityInfo();
			bool timeConflict(int key_id, unsigned begin_time, unsigned end_time);


			void loadFile();
			void saveDB();
			void sendEmail();

		private:
			virtual void classLoad();
			DayActivityPtr _cur_activity;
			DayActivityMap _activity_map;

			Json::Value _param;
	};
}

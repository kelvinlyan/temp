#pragma once

#include "kingdom_def.h"
#include "kingdom_helper.h"
#include "shop_mgr.h"

#define kingdom_sys (*gg::kingdom_system::_Instance)

namespace gg
{
	BOOSTSHAREPTR(KingdomInfo, KingdomPtr);

	class kingdom_system
	{
		public:
			static kingdom_system* const _Instance;
			kingdom_system();
			void initData();
			
			DeclareRegFunction(addKingdom);
			DeclareRegFunction(showBuild);
			DeclareRegFunction(playerCon);
			DeclareRegFunction(showSkill);
			DeclareRegFunction(upSkill);
			DeclareRegFunction(showRank);
			DeclareRegFunction(showKingdom);
			DeclareRegFunction(changeAnnouncement);
			DeclareRegFunction(changeClientParam);
			DeclareRegFunction(getSalary);

			void tickRank();

			void updateConRank(playerDataPtr d, int old_con);
			int upgradeConstruction(int nation, int id, int exp);

			const KingdomPtr getData(int nation) const;

			const KingdomConstructionConfPtr getConstructionConf(int id);
			const KingdomContributionConf& getContributionConf() const;
			unsigned getMaxConTimes(int vip) const;

			void updateBuilding(playerDataPtr d);

			int getStrengthRank(int nation) const { return _strength_rank[nation]; }
			int getRate(int strength_rank) const;
			int timerId() const { return _timer_id; }
			void testTimer();

		private:
			virtual void classLoad();
			void loadFile();

			int getRandKingdom() const;
			void resetStrengthRank();
			void updateKingdom(playerDataPtr d);

		private:
			std::vector<KingdomPtr> _kingdom;

			KingdomConstructionConfMap _construction_conf;
			KingdomContributionConf _contribution_conf;
			STDVECTOR(int, Vip2Times);
			Vip2Times _vip_times;

			int _strength_rank[Kingdom::nation_num];
			int _timer_id;
	};
}

//###################################
//create by YeMing
//2016-3-3
//###################################

#pragma once

namespace gg
{
	namespace Kingdom
	{
		enum // title type
		{
			None = 0,
			GuoWang,
			ZuoChengXiang,
			YouChengXiang,
			SiMa,
			SiKong,
			SiTu,
			ZongZheng,
			DaChang,
			HongLu,
			GuangLu,
			WeiWei,
			SiNong,
			PingMin
		};

		enum // construction type
		{
			CBegin = 0,
			CLevel,
			CFame,
			CAgriculture,
			CBoss,
			CTeamWar,

			CEnd,
		};
	}
}

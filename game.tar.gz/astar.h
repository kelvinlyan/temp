﻿//###################################
//create by Jim
//2016-09-18
//###################################

#ifndef __ASTAR_H__
#define __ASTAR_H__

#include <vector>
#include "commom.h"

namespace ASTAR
{
	// 默认值未正三角的三角函数近似值 , 默认值不要修改了, 创建的时候, 最好传参数
	static const int kStepValue = 10;//正向g影响值
	static const int kObliqueValue = 14;//斜向g影响值

	/**
	* 二维坐标
	*/
	struct Vec2
	{
		unsigned x;
		unsigned y;

		Vec2()
			: x(0)
			, y(0)
		{
		}

		Vec2(unsigned _x, unsigned _y)
			: x(_x)
			, y(_y)
		{
		}

		void set(unsigned x, unsigned y)
		{
			this->x = x;
			this->y = y;
		}

		bool operator== (const Vec2 &other) const
		{
			return x == other.x && y == other.y;
		}
	};
}

/**
 * A-Star algorithm
 */
class AStar
{
public:
	typedef boost::function<bool(const ASTAR::Vec2&)> QueryFunction;

	/**
	 * 搜索参数
	 */
	struct Param
	{
		bool			corner;//是否允许斜角行走
		unsigned		height;//高度
		unsigned		width;//宽度 
		ASTAR::Vec2		start;//开始坐标
		ASTAR::Vec2		end;//结束坐标
		QueryFunction	can_reach;//判断能否移动的依据

		Param()
			: height(0)
			, width(0)
			, corner(true)
			, can_reach(NULL)
		{
		}
	};

private:
	/**
	 * 路径节点状态
	 */
	enum NodeState
	{
		NOTEXIST,
		IN_OPENLIST,
		IN_CLOSELIST
	};

public:
	/**
	 * 路径节点
	 */
	struct Node
	{
		unsigned		g;
		unsigned		h;
		ASTAR::Vec2			pos;
		NodeState		state;
		Node*			parent;

		int f() const
		{
			return g + h;
		}

		inline Node(const ASTAR::Vec2 &pos)
			: g(0)
			, h(0)
			, pos(pos)
			, parent(NULL)
			, state(NOTEXIST)
		{
		}

		void* operator new(std::size_t size)
		{
			return GNew(size);
		}

		void operator delete(void* p) throw()
		{
			if (p != NULL)
			{
				GDelete(p);
			}
		}
	};

public:
	AStar(const int kStep = ASTAR::kStepValue, const int kOblique = ASTAR::kObliqueValue);
	~AStar();

public:
	int stepValue() const;

	int obliqueValue() const;

	void setStepValue(int value);

	void setObliqueValue(int value);

	bool isValidParam(const Param &param);

	std::vector<ASTAR::Vec2> find(const Param &param);
private:
	void clear();

	void initParam(const Param &param);


private:
	void percolateUp(size_t hole);

	bool getNodeIndex(Node *node, size_t &index);

	unsigned calculGValue(Node *parent_node, const ASTAR::Vec2 &current_pos);

	unsigned calculHValue(const ASTAR::Vec2 &current_pos, const ASTAR::Vec2 &end_pos);

	bool hasNodeInOpenList(const ASTAR::Vec2 &pos, Node *&out);

	bool hasNodeInCloseList(const ASTAR::Vec2 &pos);

	bool canReach(const ASTAR::Vec2 &pos);

	bool canReach(const ASTAR::Vec2 &current_pos, const ASTAR::Vec2 &target_pos, bool allow_corner);

	void findCanReachPos(const ASTAR::Vec2 &current_pos, bool allow_corner, std::vector<ASTAR::Vec2> &can_reach);

	void handleFoundNode(Node *current_node, Node *target_node);

	void handleNotFoundNode(Node *current_node, Node *target_node, const ASTAR::Vec2 &end_pos);

private:
	int						step_value_;
	int						oblique_value_;
	std::vector<Node *>		maps_;
	unsigned				height_;
	unsigned				width_;
	QueryFunction			query_;
	std::vector<Node *>		open_list_;
};

#endif
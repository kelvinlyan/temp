//###################################
//create by Jim
//2015-11-12
//###################################

#pragma once

#include "auto_base.h"
#include "man_def.h"

namespace gg
{
	namespace itemDef
	{
		enum
		{
			common = 0,
			equipment = (0x0001 << 0),//װ��//�����ļ������
			gem = (0x0001 << 1),//��ʯ//��ͻ, ����ֻ��һ��
		};

		enum Position
		{
			pos_bag = (0x0001 << 0),
			pos_man = (0x0001 << 1),
		};

		enum Quality
		{
			white = 0,
			green = 1,
			blue = 2,
			yellow = 3,
			red = 4,
			purple = 5,

			//����ϴ����׼��Ʒ������
			reborn_color_num = 3,
		};

		enum Type
		{
			type_common = 0,//��ͨ����
			type_equipment = 1,//װ��
			type_paper = 2,//ͼֽ
			type_man_material = 3,//�佫���ײ���
			type_gem = 4,//��ʯ
			type_man_soul = 5,//�佫����
			type_other = 6,//����
		};
	}

	struct itemConfig
	{
		~itemConfig()
		{
			if (isEquip())
			{
				_declare._equip.equipAttri->~vector();
				::GDelete(_declare._equip.equipAttri);
				_declare._equip.equipAttri = NULL;
				_declare._equip.equipAttriRate->~vector();
				::GDelete(_declare._equip.equipAttriRate);
				_declare._equip.equipAttriRate = NULL;
			}
		}
		int itemID;
		unsigned type;//���߿�ͷ����
		unsigned state;//״̬��//����״̬, ��ʾ����һ��ʲô���ĵ���//0������ͨ����
		unsigned quality;//���ߵ�Ʒ��
		inline bool isGem(){ return (::itemDef::gem & state) == ::itemDef::gem; }
		inline bool isEquip(){ return (::itemDef::equipment & state) == ::itemDef::equipment; }
		inline bool isComon(){ return 0 == state; }
		bool canStack()
		{
			if (!isEquip()){
				return _declare._com.stackNum > 1;//>1 ������Զѵ�
			}
			return false;
		}
		unsigned stackNum()
		{
			if (isEquip())return 1;
			return _declare._com.stackNum;
		}
		//��װ������������//�ض�����
		struct COM
		{
			unsigned stackNum;//���Զѵ�������
		};
		//��ʯӵ����������
		struct GEM :
			public COM
		{
			unsigned level;//��ʯ�ȼ�
			double rate;//���ӱ���
		};
		//װ������������
		struct EQUIP
		{
			unsigned equipLimit;//װ������
			unsigned equipPos;//��װ����λ��
			unsigned upgradeUse;//ʹ�õ������б����
			typedef vector< vector<int> > AttriList;
			AttriList *equipAttri;//�ȼ�����ָ��
			typedef vector< vector<double> > AttriRateList;
			AttriRateList *equipAttriRate;//�ȼ�����ָ��
			unsigned rebornIdx;//ϴ������
		};
		union DEC
		{
			COM _com;
			GEM _gem;
			EQUIP _equip;
		}_declare;//����
	};
	BOOSTSHAREPTR(itemConfig, cfgItemPtr);


	namespace itemDeclare
	{
		const static unsigned rbNum = 3;//���3����������
		struct comon
		{
			unsigned num;//�ѵ�
		};

		struct rbAttri
		{
			rbAttri(const int i, const int v)
			{
				idx = i;
				val = v;
			}
			rbAttri()
			{
				idx = -1;
				val = 0;
			}
			int idx;//����ID -1����û��
			int val;//������ֵ
		};

		struct equip :
			public comon
		{
			unsigned level;
			int hold;//������, û����Ϊ-1
			typedef vector< rbAttri > rbAttriList;
			rbAttriList *rba, *rba_bk;
			int gemID;//��ʯID
		};

		union Declare
		{
			comon _com;
			equip _equip;
		};

		enum rbIDX
		{
			rb_idx_1,
			rb_idx_2,
			rb_idx_3,
		};//ϴ��3����
	}

	class playerItemMgr;
	class playerItem :
		public _auto_player
	{
		friend class playerItemMgr;
	public:
		playerItem(playerData* const own, const int id, const unsigned num = 1);
		~playerItem();
		inline int itemID(){ return localID / 1000; }
		inline int ID(){ return localID; }
		unsigned Num();//������������
		inline unsigned Pos(){ return pos; }
		cfgItemPtr getConfig();
		Json::Value toGMJson();
		qValue toJson();
		bool stackFull();
		inline bool Alive(){ return alive; }
		unsigned addNum(const unsigned num);
		unsigned cutNum(const unsigned num);
		bool deleteItem(const bool update = true);
		void setPos(const itemDef::Position p);
		int getHandler();
		bool hasHandler();
		void setHandler (const int manID);//װ��ר��
		unsigned getLv();
		int riseUpLv(const unsigned lv, const bool recal = true);
		int setLv(const unsigned lv, const bool recal = true);
		bool uncertainRB();
		void clearUncertainRB();
		void replaceUncertainRB(const bool recal = true);
		void tryRecal();
		void deleteAllReborn();
		unsigned activeRBNum();//��Ч�ĸ���������
		int activeReborn(const AttributeIDX atIdx, const int val);//����һ����Ч�ĸ�����
		int activeReborn(const itemDeclare::rbAttri attri);
		int setReborn(const itemDeclare::rbIDX idx, const AttributeIDX atIdx, const int val, const bool recal = true, const bool force = false);
		int setReborn(const itemDeclare::rbIDX idx, const itemDeclare::rbAttri attri, const bool recal = true, const bool force = false);
		vector<AttributeIDX> rebornIdxList();
		const itemDeclare::rbAttri& getReborn(const itemDeclare::rbIDX idx);
		const itemDeclare::rbAttri& getBKReborn(const itemDeclare::rbIDX idx);
		void setBKReborn(const itemDeclare::rbIDX idx, const AttributeIDX atIdx, const int val);
		void setBKReborn(const itemDeclare::rbIDX idx, const itemDeclare::rbAttri attri);
		bool hasGem();//�Ƿ���б�ʯ
		int canOFFGem();
		int canOnGem();
		int OnGem(const int itemID, const bool recal = true);
		int OFFGem(const bool recal = true);
		int gemID();
		cfgItemPtr getGemConfig();
	private:
		virtual bool _auto_save();
		virtual void _auto_end();
		virtual bool _on_sign_update();
		void checkOver();
		void setNum(const unsigned num, const bool update = true);
		int localID;//����ID
		bool alive;//�Ƿ���//�ڴ�ֵ
		itemDef::Position pos;
		itemDeclare::Declare declare;
		cfgItemPtr handlerCfg;
	};
	BOOSTSHAREPTR(playerItem, itemPtr);
	STDVECTOR(itemPtr, itemVec);
	UNORDERMAP(int, itemPtr, itemMap);//

	class playerItemMgr ://������������, ������ΪӲ����
		public _auto_player
	{
		friend class playerItem;
	public:
		playerItemMgr(playerData* const own);
		~playerItemMgr(){}
		Json::Value gmPackage();
		void updateAll();
		unsigned itemUsePos(const int itemID, const unsigned num = 1);
		bool canAddItem(const int itemID, const unsigned num = 1);
		itemVec addItem(const int itemID, const unsigned num = 1);//�Զ��ѵ�//ֻ�ܼ��뵽�ֿ�
		int removeItem(const int itemID, const unsigned num = 1, const unsigned pos_set = itemDef::pos_bag);//�Զ��ѵ�
		unsigned itemNum(const int itemID, const unsigned pos_set = itemDef::pos_bag);//ָ��ӵ�еĵ���
		bool overItem(const int itemID, const unsigned num, const unsigned pos_set = itemDef::pos_bag);//�Ƿ�ӵ����ô�����
		itemPtr getLocalItem(const int localID, const unsigned pos_set = itemDef::pos_bag);
		itemVec getItem(const int itemID, const unsigned pos_set = itemDef::pos_bag);
		inline bool isOver(){ return mapBagItem.size() >= 999; }
		inline bool isOver(const unsigned pos_num){
			if (pos_num < 1)return isOver();
			return (pos_num > 999 || (mapBagItem.size() + pos_num) > 999);
		}
		inline bool tryOver(const unsigned pos_num){
			if (pos_num > 0)
			{
				return (mapBagItem.size() >= 999 || pos_num > 999 || (mapBagItem.size() + pos_num) > 999);
			}
			return false;
		}
		void sortOut(const bool update = true);//���������ռ�
		void updateUpCD();
		void clearUpCD();
		bool UpOK();
		void addUpCD(const unsigned cd);
		inline unsigned getUpCD() { return UpCD; }
		inline bool canHelpUpCD() { return !UpOK() && !CDHelp; }
		void setCDHelp(const bool state = true) { CDHelp = state; ownUpdate = true; _sign_auto(); }
		bool reduceUpCD(const unsigned num);
		unsigned getMaxEquipLv();
		unsigned getEquipNumOfColor(int color);
		unsigned getOnGemNumOfLv(int lv = 0);
		unsigned equipBuildTimes() const { return _equipBuildTimes; }
		void tickEquipBuild();
	private:
		virtual void classLoad();
		virtual void classFinal();
		virtual bool _auto_save();
		virtual void _auto_update();
		itemPtr CreateItem(cfgItemPtr config, const unsigned num);
		itemPtr directGetItem(const int localID, const unsigned pos_set = itemDef::pos_bag);
		void tickItem(const int localID);//���µ���
		void rmItem(const int localID);
		void tickFull(const int localID);
		void tickNotFull(const int localID);
		void moveToBag(const int localID);
		void moveToMan(const int localID);
		UNORDERMAP(int, itemMap, itemFMap);
		itemMap mapItem, mapBagItem, mapManItem, updateItem;
		itemFMap mapFItem, mapFVItem;//û�г����ĵ���
		static unsigned CalNum(itemMap& checkMap);

		unsigned UpCD;
		bool UpCDLock;
		bool CDHelp;

		bool ownUpdate;
		unsigned _equipBuildTimes;
	};
}

#pragma once

#include "auto_base.h"
#include "mongoDB.h"

namespace gg
{
	class playerMan;
	BOOSTSHAREPTR(playerMan, playerManPtr);
	STDVECTOR(playerManPtr, ManList);

	class playerKingdomWarSGFM
		: public _auto_player
	{
		public:
			playerKingdomWarSGFM(int army_id, playerData* const own);

			bool empty() const;
			void load(const mongo::BSONObj& obj);
			void getInfo(qValue& q);
			void getHpInfo(qValue& q);
			void getFMInfo(qValue& q);
			void getManInfo(qValue& q);
			int getUpHpCost();

			int setFormation(int fm_id, const int fm[9]);
			const ManList& manList() const { return _man_list; }
			int fmId() const { return _fm_id; }
			int bv();
			int face();
			bool inFM(int id) const;

			int upManHp();
			int getUpHpNum();
			void clearManHp();
			void defaultFm();
			void clearBV();
			bool isDead();
			bool inited() const { return _inited; }

		private:
			virtual void _auto_update();
			virtual bool _auto_save(); 
			void recalFM();

		private:
			const int _army_id;
			int _fm_id;
			int _power;
			ManList _man_list;
			int _face;
			bool _inited;
	};

	class playerKingdomWarFM
		: public _auto_player
	{
		public:
			playerKingdomWarFM(playerData* const own);

			virtual void classLoad();
			void update();

			void getHpInfo(int army_id, qValue& q);
			void getFMInfo(int army_id, qValue& q) { _fm_list[army_id]->getFMInfo(q); }
			void getManInfo(int army_id, qValue& q) { _fm_list[army_id]->getManInfo(q); }

			int face(int army_id) { return _fm_list[army_id]->face(); }
			const ManList& getFM(int army_id) const { return _fm_list[army_id]->manList(); }
			int getCurrentHp(int army_id);
			int getMaxHp(int army_id);
			int getFMId(int army_id) const { return _fm_list[army_id]->fmId(); }
			int getBV(int army_id) { return _fm_list[army_id]->bv(); }
			int getUpHpCost(int army_id);
			int getUpHpNum(int army_id);

			int setFormation(int army_id, int fm_id, const int fm[9]);
			void clearManHp(int army_id) { _fm_list[army_id]->clearManHp(); }
			int upManHp(int army_id) { return _fm_list[army_id]->upManHp(); }
			int upManHpByFood(std::vector<int> army_id_vec, int& cost);

			bool manUsed(int army_id, int man_id) const;
			bool isDead(int army_id) { return _fm_list[army_id]->isDead(); }
			void recalFM(int id);

			bool inited() const { return _fm_list[0]->inited(); }
			bool empty(int army_id) const { return _fm_list[army_id]->empty(); }

		private:
			virtual bool _auto_save();
			virtual void _auto_update();

		private:
			BOOSTSHAREPTR(playerKingdomWarSGFM, FMPtr);
			STDVECTOR(FMPtr, FMVec);
			FMVec _fm_list;
	};
}

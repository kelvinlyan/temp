#include "recharge_log_system.h"

namespace gg
{
	static recharge_log::RechargeLogConfig config;

	recharge_log_system* const recharge_log_system::_Instance = new recharge_log_system();

	recharge_log_system::recharge_log_system()
	{
	}

	void recharge_log_system::ReChargePlayerLog(playerDataPtr player, int gold)
	{
		if (!player)
		{
			return;
		}
		player->RechargeLog().addRecharge(gold, config.rate);
		player->SecondaryCompensation().perception(config.gold, gold);

	}

	void recharge_log_system::initData()
	{
		config.rate = 10;
		std::cout << "load ./secondary_day/girls.json START	" << std::endl;
		Json::Value girls = Common::loadJsonFile(std::string("./instance/secondary_day/girls.json"));
		config.rate = girls["rate"].asInt();
		config.gold = girls["gold"].asInt();

		std::cout << "load ./secondary_day/girls.json END	" << std::endl;
	}

	recharge_log_system::~recharge_log_system()
	{
	}
}

#include "compensate.h"

namespace gg
{
	compensate* const compensate::_Instance = new compensate();

	const static unsigned SingleMax = 1000000000;//10�ڴ�
	struct LevelOpen
	{
		bool isOpen()const
		{
			return (BeenNum > OpenNum);
		}
		unsigned Limit; //  > ����ȼ� ���Ƶȼ�
		unsigned OpenNum;// > ������� ���Ž���
		unsigned Open;// <= ����ȼ� ���Ի�ý���
		unsigned BeenNum;// �Ѿ����������
	};
	static vector<LevelOpen> LevelTick;
	static unsigned useMaxIDX;
	static vector<ActionBoxList> Boxes;//�����б�

	void saveDB()
	{
		mongo::BSONObj key = BSON("key" << 1);
		mongo::BSONArrayBuilder arr;
		for (unsigned i = 0; i < LevelTick.size(); ++i)
		{
			const LevelOpen& open = LevelTick[i];
			arr << open.BeenNum;
		}
		mongo::BSONObj obj = BSON("key" << 1 << "arr" << arr.arr());
		db_mgr.SaveMongo(DBN::dbCompensate, key, obj);
	}

	void compensate::initData()
	{
		cout << "load compensate system ..." << endl;
		{//�ͼ���������
			Json::Value json = Common::loadJsonFile("./instance/gamer/compensate.json");
			for (unsigned i = 0; i < json.size(); ++i)
			{
				Json::Value& sg_json = json[i];
				LevelOpen open;
				open.Limit = sg_json["Limit"].asUInt();
				open.OpenNum = sg_json["OpenNum"].asUInt();
				open.Open = sg_json["Open"].asUInt();
				open.BeenNum = 0;
				LevelTick.push_back(open);
			}
			mongo::BSONObj key = BSON("key" << 1);
			mongo::BSONObj obj = db_mgr.FindOne(DBN::dbCompensate, key);
			if (!obj.isEmpty())
			{
				vector<mongo::BSONElement> elems = obj["arr"].Array();
				for (unsigned i = 0; i < LevelTick.size() && i < elems.size(); ++i)
				{
					LevelTick[i].BeenNum = (unsigned)elems[i].Int();
				}
			}
			useMaxIDX = 0;
			for (unsigned i = 0; i < LevelTick.size(); ++i)
			{
				const LevelOpen& open = LevelTick[i];
				if (useMaxIDX < open.Open && open.isOpen())
				{
					useMaxIDX = open.Open;
				}
			}
		};

		{//��ҵͼ�������������
			Boxes.clear();
			Json::Value json = Common::loadJsonFile("./instance/gamer/compensate_box.json");
			for (unsigned i = 0; i < json.size(); ++i)
			{
				Json::Value& sg_json = json[i];
				Boxes.push_back(actionFormatBox(sg_json));
			}
		};
	}

	const static int upgradeLevelAction = 1;
	void compensate::tryGetCompenstate(playerDataPtr player, const unsigned from, const unsigned to)
	{
		Json::Value json_from;
		json_from[strMsg][0u] = State::getState();
		if (to <= from)return;
		if (player->isOnline())
		{
			player->sendToClient(gate_client::player_compensate_begin_resp, json_from);
		}
		for (unsigned i = from + 1; i <= to; ++i)
		{
			const bool isCompensate = (i <= useMaxIDX);
			if (isCompensate)
			{
				actionDoBox(player, Boxes[i]);
			}
			player->Res().alterAction(upgradeLevelAction);//�̶�����1������һ������
			if (player->isOnline())
			{
				Json::Value json;
				Json::Value& data_json = json[strMsg];
				data_json.append(res_sucess);
				data_json.append(i);
				data_json.append(upgradeLevelAction);
				data_json.append(isCompensate);
				data_json.append(isCompensate ? actionRes() : Json::arrayValue);
				player->sendToClient(gate_client::player_compensate_resp, json);
			}
		}
		if (player->isOnline())
		{
			player->sendToClient(gate_client::player_compensate_end_resp, json_from);
		}
	}

	void compensate::tickLevel(const unsigned from, const unsigned to)
	{
		if (from == to)return;
		bool motify = false;
		for (unsigned i = 0; i < LevelTick.size(); ++i)
		{
			LevelOpen& open = LevelTick[i];
			if (open.Limit > from && open.Limit <= to)
			{
				motify = true;
				++open.BeenNum;
				open.BeenNum = open.BeenNum > SingleMax ? SingleMax : open.BeenNum;
			}
			else if (open.Limit >= to && open.Limit < from)
			{
				if (open.BeenNum > 0)
				{
					motify = true;
					--open.BeenNum;
				}
			}
		}

		useMaxIDX = 0;
		for (unsigned i = 0; i < LevelTick.size(); ++i)
		{
			const LevelOpen& open = LevelTick[i];
			if (useMaxIDX < open.Open && open.isOpen())
			{
				useMaxIDX = open.Open;
			}
		}

		if (motify)
		{
			saveDB();
		}
	}

}
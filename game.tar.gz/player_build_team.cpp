#include "player_build_team.h"
#include "dbDriver.h"
#include "ownerland_system.h"
#include "rescue_system.h"
#include "task_mgr.h"

namespace gg
{
	namespace BUILDTEAM
	{
		static void TimerBuildTeam(const structTimer& timerData, const int playerID, const int iF, const int iBT, const int iBP)
		{
			playerDataPtr player = player_mgr.getOnlinePlayer(playerID);
			if (!player)return;
			player->BuildTeam().clearCD(iF, iBT, iBP);
		}

		buildWork::buildWork(const int mid, const unsigned idx, playerData* const own) : MainID(mid), InIDX(idx), _auto_player(own)
		{
			iTimer = ptrTimerIdentify();
			clear();
		}

		void buildWork::clear()
		{
			if (!isFree() && iHelp)
			{
				rescue_sys.removeRescue(Rescue::TYPE(MainID * MAX_BUILD_TEAM_NUM + InIDX + 1), Own().getOwnDataPtr());
			}
			iFeod = -1;
			iBuildType = -1;
			iBuildPos = -1;
			iBuildCD = 0;
			iHelp = false;
			delTimer();
		}

		void buildWork::reduceCD(const int playerID, const unsigned iCD)
		{
			if (iCD > iBuildCD)iBuildCD = 0;
			else iBuildCD -= iCD;
			Own().Builds().tickUpdateBuild(iFeod, iBuildType, iBuildPos);
			addTimer(playerID);
		}

		void buildWork::addTimer(const int playerID)//�����Լ����������Ӷ�ʱ��
		{
			delTimer();
			if (isFree())return;
			iTimer = Timer::AddEventTickTime(boostBind(TimerBuildTeam, _1, playerID, iFeod, iBuildType, iBuildPos), Inter::event_build_team_timer, iBuildCD);
		}

		void buildWork::addTimer(const int playerID, const int iF, const int iBT, const int iBP, const int iCD)
		{
			clear();
			iFeod = iF;
			iBuildType = iBT;
			iBuildPos = iBP;
			iBuildCD = iCD;
			iTimer = Timer::AddEventTickTime(boostBind(TimerBuildTeam, _1, playerID, iF, iBT, iBP), Inter::event_build_team_timer, iBuildCD);
		}
	}


	playerBuildTeam::playerBuildTeam(playerData* const own) :_auto_player(own)
	{
		buildWorkMap.clear();
		for (int i = LAND::FEOD_START; i < LAND::FEOD_NUM; ++i)
		{
			buildTeamList[i] = Creator<BUILDTEAM::buildTeam>::Create(i);
		}
		xia_kou_dwelling_up_times = 0;
	}

	unsigned playerBuildTeam::buildTeamSize(const int iFeod)
	{
		if (iFeod < LAND::FEOD_START || iFeod > LAND::FEOD_END)return 0;
		return buildTeamList[iFeod]->TeamList.size();
	}

	void playerBuildTeam::checkBuildTeam()
	{
		for (unsigned i = 0; i < LAND::FEOD_NUM; ++i)
		{
			BUILDTEAM::buildTeamPtr cTeam = buildTeamList[i];
			if (cTeam->TeamList.empty())
			{
				cTeam->TeamList.push_back(Creator<BUILDTEAM::buildWork>::Create(i, cTeam->TeamList.size(), _Own));
			}
		}
	}

	void playerBuildTeam::classFinal()
	{
		checkBuildTeam();
	}

	void playerBuildTeam::classLoad()
	{
		mongo::BSONObj key = BSON(strPlayerID << Own().ID());
		mongo::BSONObj obj = db_mgr.FindOne(DBN::dbPlayerBuildTeams, key);
		if (obj.isEmpty())return;
		{//������ж�ȡ
			vector<mongo::BSONElement> vec = obj["arr"].Array();
			for (unsigned i = 0; i < vec.size(); ++i)
			{
				mongo::BSONElement& elem = vec[i];
				const int mainID = elem["mid"].Int();
				if (mainID < LAND::FEOD_START || mainID > LAND::FEOD_END)continue;
				BUILDTEAM::buildTeamPtr cTeam = buildTeamList[mainID];
				BUILDTEAM::workPtr ptr = Creator<BUILDTEAM::buildWork>::Create(mainID, cTeam->TeamList.size(), _Own);
				ptr->iFeod = elem["if"].Int();
				ptr->iBuildType = elem["ibt"].Int();
				ptr->iBuildPos = elem["ibp"].Int();
				ptr->iBuildCD = (unsigned)elem["cd"].Int();
				ptr->iHelp = elem["ih"].Bool();
				if (!ptr->isFree())
				{
					const LAND::BuildKey key(ptr->iFeod, ptr->iBuildType, ptr->iBuildPos);
					buildWorkMap[key] = ptr;
				}
				cTeam->TeamList.push_back(ptr);
			}
		};
		if (!obj["state"].eoo())
		{//����״̬
			vector<mongo::BSONElement> vec = obj["state"].Array();
			for (unsigned i = 0; i < vec.size(); ++i)
			{
				mongo::BSONElement& elem = vec[i];
				const int mainID = elem["mid"].Int();
				if (mainID < LAND::FEOD_START || mainID > LAND::FEOD_END)continue;
				buildTeamList[mainID]->state = elem["state"].Bool();
			}
		}
		checkNotEoo(obj["xkdut"])
			xia_kou_dwelling_up_times = obj["xkdut"].Int();
	}

	BUILDTEAM::workPtr playerBuildTeam::getWork(const int iFeod, const int iType, const int iPos)
	{
		WORKMAP::iterator it = buildWorkMap.find(LAND::BuildKey(iFeod, iType, iPos));
		if (it == buildWorkMap.end())return BUILDTEAM::workPtr();
		return it->second;
	}

	void playerBuildTeam::_auto_update()
	{
		qValue list_json(qJson::qj_array), state_json(qJson::qj_array);
		for (unsigned i = 0; i < LAND::FEOD_NUM; ++i)
		{
			{//״̬��Ϣ
				qValue _json(qJson::qj_array);
				_json.append(i);
				_json.append(buildTeamList[i]->state);
				state_json.append(_json);
			};
			const vector<BUILDTEAM::workPtr>& teamList = buildTeamList[i]->TeamList;
			for (unsigned n = 0; n < teamList.size(); ++n)
			{
				qValue _json(qJson::qj_array);
				BUILDTEAM::workPtr t_work = teamList[n];

				_json.append(i);
				_json.append(t_work->iBuildType);
				_json.append(t_work->iBuildPos);
				_json.append(t_work->iBuildCD);
				_json.append(t_work->iHelp);

				list_json.append(_json);
			}
			
		}

		qValue list_json_send(qJson::qj_array);
		list_json_send.append(res_sucess);
		list_json_send.append(list_json);
		list_json_send.append(state_json);

		Own().sendToClientFillMsg(gate_client::building_build_team_data_resp, list_json_send);
	}

	bool playerBuildTeam::_auto_save()
	{
		mongo::BSONObj key = BSON(strPlayerID << Own().ID());
		mongo::BSONArrayBuilder arr, state_arr;
		for (unsigned i = 0; i < LAND::FEOD_NUM; ++i)
		{
			BUILDTEAM::buildTeamPtr buildteam_ptr = buildTeamList[i];
			const int mainID = buildteam_ptr->mainID;
			//build team state
			state_arr << BSON("mid" << mainID << "state" << buildteam_ptr->state);
			//build team everyone
			const vector<BUILDTEAM::workPtr>& teamList = buildteam_ptr->TeamList;
			for (unsigned n = 0; n < teamList.size(); ++n)
			{
				BUILDTEAM::workPtr cWork = teamList[n];
				arr.append(BSON("mid" << mainID << "if" << cWork->iFeod <<
					"ibt" << cWork->iBuildType << "ibp" << cWork->iBuildPos <<
					"cd" << cWork->iBuildCD << "ih" << cWork->iHelp));
			}
		}
		mongo::BSONObj obj = BSON(strPlayerID << Own().ID() << "arr" << arr.arr() << "state" << state_arr.arr() << "xkdut" << xia_kou_dwelling_up_times);
		return db_mgr.SaveMongo(DBN::dbPlayerBuildTeams, key, obj);
	}

	unsigned playerBuildTeam::calBuildFinCDTime(const unsigned iBuildCD)
	{
		if (iBuildCD < 1) { return 0; }
		int kAdd = Own().Research().getResearchData(LAND::idx_home_type_build);
		kAdd = kAdd < 0 ? 0 : kAdd;
		kAdd = kAdd > 10000 ? 10000 : kAdd;

		return (unsigned)(iBuildCD * (1.0 - kAdd / 10000.0));
	}

	void playerBuildTeam::addTimer()
	{
		for (WORKMAP::iterator it = buildWorkMap.begin(); it != buildWorkMap.end(); ++it)
		{
			BUILDTEAM::workPtr work_ptr = it->second;
			work_ptr->addTimer(Own().ID());
		}
	}

	void playerBuildTeam::delTimer()
	{
		for (WORKMAP::iterator it = buildWorkMap.begin(); it != buildWorkMap.end(); ++it)
		{
			BUILDTEAM::workPtr work_ptr = it->second;
			work_ptr->delTimer();
		}
	}

	void playerBuildTeam::clearTeam()
	{
		const unsigned offLine = Own().Offline().OffTime();//��ȡ����ʱ��
		unsigned startTime[LAND::FEOD_NUM][MAX_BUILD_TEAM_NUM] =
		{ { offLine, offLine, offLine }, { offLine, offLine, offLine }, { offLine, offLine, offLine }, { offLine, offLine, offLine } };
		for (WORKMAP::iterator it = buildWorkMap.begin(); it != buildWorkMap.end();)
		{
			WORKMAP::iterator old_it = it;
			++it;
			BUILDTEAM::workPtr work_ptr = old_it->second;
			if (work_ptr->isOver())
			{
				if (!work_ptr->isFree())//�����ж���
				{
					startTime[work_ptr->MainID][work_ptr->InIDX] = work_ptr->iBuildCD;//��ʼ��CDʱ��
				}
				const int iFeod = work_ptr->iFeod;
				const int iType = work_ptr->iBuildType;
				const int iPos = work_ptr->iBuildPos;
				clearCD(iFeod, iType, iPos, false, true);
			}
		}

		const unsigned now = Common::gameTime();
		bool is_change = false;
		const unsigned playerLV = Own().LV();
		for (int i = 0; i < LAND::FEOD_NUM; ++i)
		{
			const unsigned use_time = std::min(now, Own().Admin().getNoFreshEndTime(i, LAND::idx_adminType_builder));
			cfgManPtr man_config = Own().Admin().getNoFreshAdmin(i, LAND::idx_adminType_builder);
			if (!man_config)continue;//û��ί����
			const unsigned containType = Own().Admin().getNoFreshContain(i, LAND::idx_adminType_builder);
			BUILDTEAM::buildTeamPtr teamList = buildTeamList[i];
			for (unsigned idx = 0; idx < teamList->TeamList.size(); ++idx)
			{
				BUILDTEAM::workPtr work_ptr = teamList->TeamList[idx];
				if (!work_ptr->isFree())continue;//�����Ѿ�������, ������ڹ�����, ��ô�������в�����
				unsigned& start_time = startTime[i][idx];
				if (start_time >= use_time)continue;//û�п���ʱ��
				std::list<FEOD::buildPtr> useBuilds = Own().Builds().getFreeBuild(i, containType);//������map
				while (useBuilds.size() > 0)
				{
					FEOD::buildPtr build_ptr = useBuilds.front();
					useBuilds.pop_front();
					while (playerLV > build_ptr->iBuildLv)
					{
						LANDCONFIG::landCFGPtr config = ownerland_sys.getBuildConfig(build_ptr->iBuildType);
						if (!config)break;//��ȡ���������ļ�
						LANDCONFIG::buildPtr config_level = config->findLV(build_ptr->iBuildLv);
						if (!config_level)break;//��ȡ��ǰ�ȼ���������

						double rate = 1.0;//���ļ��ٱ���
						if (man_config)rate = 1.0 - man_config->costRes / 10000.0;
						rate = rate < 0.0 ? 0.0 : rate;

						//�鿴�Ƿ����㹻����Դ
						int res = ownerland_sys.checkResource(Own().getOwnDataPtr(), config_level->upCost, rate);
						if (res != res_sucess)break;//��Դ����// �Ǿ�����
						ownerland_sys.alterResource(Own().getOwnDataPtr(), config_level->upCost, false, rate);

						const unsigned buildCD = calBuildFinCDTime(config_level->iBuildCD);//CDʱ��
						if ((start_time + buildCD) > use_time)break;

						//ֱ��������
						start_time += buildCD;
						Own().Builds().upgradeBuild(build_ptr->iBuildFeod, build_ptr->iBuildType, build_ptr->iBuildPos, build_ptr->iBuildLv + 1, true);
					}
				}
			}

			//����
			std::list<FEOD::buildPtr> useBuilds = Own().Builds().getFreeBuild(i, containType);//������map
			for (unsigned idx = 0; idx < teamList->TeamList.size(); ++idx)
			{
				BUILDTEAM::workPtr work_ptr = teamList->TeamList[idx];
				if (!work_ptr->isFree())continue;//�����Ѿ�������, ������ڹ�����, ��ô�������в�����
				unsigned& start_time = startTime[i][idx];
				if (start_time >= use_time)continue;//û�п���ʱ��
				while (useBuilds.size() > 0)
				{
					FEOD::buildPtr build_ptr = useBuilds.front();
					useBuilds.pop_front();
					LANDCONFIG::landCFGPtr config = ownerland_sys.getBuildConfig(build_ptr->iBuildType);
					if (!config)continue;//��ȡ���������ļ�
					LANDCONFIG::buildPtr config_level = config->findLV(build_ptr->iBuildLv);
					if (!config_level)continue;//��ȡ��ǰ�ȼ���������

					double rate = 1.0;//���ļ��ٱ���
					if (man_config)rate = 1.0 - man_config->costRes / 10000.0;
					rate = rate < 0.0 ? 0.0 : rate;

					//�鿴�Ƿ����㹻����Դ
					int res = ownerland_sys.checkResource(Own().getOwnDataPtr(), config_level->upCost, rate);
					if (res != res_sucess)continue;//��Դ����// �Ǿ�����
					ownerland_sys.alterResource(Own().getOwnDataPtr(), config_level->upCost, false, rate);

					const unsigned buildCD = calBuildFinCDTime(config_level->iBuildCD);//CDʱ��

					//ǰ���Ѿ�clear����
					work_ptr->iFeod = build_ptr->iBuildFeod;
					work_ptr->iBuildType = build_ptr->iBuildType;
					work_ptr->iBuildPos = build_ptr->iBuildPos;
					work_ptr->iBuildCD = start_time;
					const LAND::BuildKey key(build_ptr->iBuildFeod, build_ptr->iBuildType, build_ptr->iBuildPos);
					buildWorkMap[key] = work_ptr;
					is_change = true;
					break;
				}
			}
		}
		if (is_change)_sign_auto();
	}

	void playerBuildTeam::setHelpTrue(const int iFeod, const unsigned iIDX)
	{
		if (iFeod < LAND::FEOD_START || iFeod > LAND::FEOD_END)return;
		BUILDTEAM::buildTeamPtr team_ptr = buildTeamList[iFeod];
		if (iIDX >= team_ptr->TeamList.size())return;
		team_ptr->TeamList[iIDX]->iHelp = true;
		_sign_auto();
	}

	LAND::BuildKey playerBuildTeam::getMinWork(const int iFeod)
	{
		if (iFeod < LAND::FEOD_START || iFeod > LAND::FEOD_END)return LAND::BuildKey();
		BUILDTEAM::buildTeamPtr team_ptr = buildTeamList[iFeod];
		unsigned minCD = 0xFFFFFFFF;
		LAND::BuildKey minKey;
		for (unsigned i = 0; i < team_ptr->TeamList.size(); ++i)
		{
			BUILDTEAM::workPtr work_ptr = team_ptr->TeamList[i];
			if (work_ptr->isFree())continue;//û���ڹ���,����
			if (work_ptr->iBuildCD < minCD)
			{
				minCD = work_ptr->iBuildCD;
				minKey = LAND::BuildKey(work_ptr->iFeod, work_ptr->iBuildType, work_ptr->iBuildType);
			}
		}
		return minKey;
	}

	void playerBuildTeam::clearCD(const int iFeod, const int iType, const int iPos,
		const bool auto_build /* = true */, const bool initial /* = false */)
	{
		BUILDTEAM::workPtr work_ptr = getWork(iFeod, iType, iPos);
		if (!work_ptr)return;
		work_ptr->clear();
		FEOD::buildPtr build_ptr = Own().Builds().getBuild(iFeod, iType, iPos);
		if (!build_ptr)return;
		Own().Builds().upgradeBuild(iFeod, iType, iPos, build_ptr->iBuildLv + 1, initial);
		buildWorkMap.erase(LAND::BuildKey(iFeod, iType, iPos));
		if (auto_build)
		{
			bool admin = bool(Own().Admin().getVaildAdmin(iFeod, LAND::idx_adminType_builder));//��ί���Զ������Ĺ�Ա
			if (admin)
			{
				tryFullWork(iFeod);
			}
		}
		_sign_auto();
	}

	void playerBuildTeam::tryFullWork(const int iFeod)
	{
		if (iFeod < LAND::FEOD_START || iFeod > LAND::FEOD_END)return;
		BUILDTEAM::buildTeamPtr team_ptr = buildTeamList[iFeod];
		const unsigned containType = Own().Admin().getVaildContain(iFeod, LAND::idx_adminType_builder);
		std::list<FEOD::buildPtr> useBuild = Own().Builds().getFreeBuild(iFeod, containType);//����ͨ���������ʹ�õĽ���
		for (unsigned i = 0; i < team_ptr->TeamList.size(); ++i)
		{
			BUILDTEAM::workPtr work_ptr = team_ptr->TeamList[i];
			if (work_ptr->isFree())
			{
				while (useBuild.size() > 0)
				{
					FEOD::buildPtr build_ptr = useBuild.front();
					useBuild.pop_front();
					if (res_sucess == ownerland_sys.buildToWork(Own().getOwnDataPtr(), build_ptr->iBuildFeod, build_ptr->iBuildType, build_ptr->iBuildPos))
					{
						break;
					}
				}
				if (useBuild.empty())break;
			}
		}
	}

	BUILDTEAM::workPtr playerBuildTeam::getTeamWork(const int iFeod, const int iType, const int iPos)
	{
		if (iFeod < LAND::FEOD_START || iFeod > LAND::FEOD_END)return BUILDTEAM::workPtr();
		BUILDTEAM::buildTeamPtr team_ptr = buildTeamList[iFeod];
		const vector<BUILDTEAM::workPtr>& team_list = team_ptr->TeamList;
		for (unsigned i = 0; i < team_list.size(); ++i)
		{
			BUILDTEAM::workPtr work_ptr = team_list[i];
			if (work_ptr->isFree())continue;
			if (iFeod == work_ptr->iFeod && iType == work_ptr->iBuildType && iPos == work_ptr->iBuildPos)return work_ptr;
		}
		return BUILDTEAM::workPtr();
	}

	BUILDTEAM::workPtr playerBuildTeam::getTeamWork(const int iFeod, const unsigned iIDX)
	{
		if (iFeod < LAND::FEOD_START || iFeod > LAND::FEOD_END)return BUILDTEAM::workPtr();
		BUILDTEAM::buildTeamPtr team_ptr = buildTeamList[iFeod];
		if (iIDX >= team_ptr->TeamList.size())return BUILDTEAM::workPtr();
		return team_ptr->TeamList[iIDX];
	}

	unsigned playerBuildTeam::getCD(const int iFeod, const unsigned iIDX)
	{
		if (iFeod < LAND::FEOD_START || iFeod > LAND::FEOD_END)return 0;
		BUILDTEAM::buildTeamPtr team_ptr = buildTeamList[iFeod];
		if (iIDX >= team_ptr->TeamList.size())return 0;
		return team_ptr->TeamList[iIDX]->iBuildCD;
	}

	unsigned playerBuildTeam::getCD(const int iFeod, const int iType, const int iPos)
	{
		BUILDTEAM::workPtr work_ptr = getWork(iFeod, iType, iPos);
		if (!work_ptr)return 0;
		return work_ptr->iBuildCD;
	}

	int playerBuildTeam::upgradeBuilding(const int iFeod, const int iType, const int iPos, const LAND::BuildKey replaceKey /* = LAND::BuildKey() */)
	{
		if (iFeod < LAND::FEOD_START || iFeod > LAND::FEOD_END)return err_illedge;

		LANDCONFIG::landCFGPtr config = ownerland_sys.getBuildConfig(iType);
		if (!config)return err_illedge;
		FEOD::buildPtr build_ptr = Own().Builds().getBuild(iFeod, iType, iPos);
		if (!build_ptr)return err_illedge;
		if (build_ptr->iBuildLv >= Own().LV())return err_player_lv_too_low;
		if (build_ptr->iBuildLv >= config->endLevel)return err_building_level_max;
		LANDCONFIG::buildPtr config_level = config->findLV(build_ptr->iBuildLv);
		if (!config_level)return err_illedge;
		if (config_level->iBuildCD == 0)
		{
			Own().Builds().upgradeBuild(iFeod, iType, iPos, build_ptr->iBuildLv + 1);
		}
		else
		{
			BUILDTEAM::buildTeamPtr team_ptr = buildTeamList[iFeod];
			if (getWork(iFeod, iType, iPos))return err_building_build_again;//�Ƿ����ڽ�����
			BUILDTEAM::workPtr work_ptr;
			const bool is_replace = (!replaceKey.isNull());
			if (is_replace)
			{
				work_ptr = getWork(replaceKey.iFeod, replaceKey.iBuildType, replaceKey.iBuildPos);
				if (!work_ptr)return err_illedge;//�滻�����Ƿ���Ч
			}
			else
			{
				work_ptr = team_ptr->getFree();
				if (!work_ptr)return err_build_team_full;//�Ƿ��п������
			}


			if (is_replace)
			{
				clearCD(replaceKey.iFeod, replaceKey.iBuildType, replaceKey.iBuildPos, false);
			}
			work_ptr->addTimer(Own().ID(), iFeod, iType, iPos, Common::gameTime() + calBuildFinCDTime(config_level->iBuildCD));
			const LAND::BuildKey key(iFeod, iType, iPos);
			buildWorkMap[key] = work_ptr;
			Own().Builds().tickUpdateBuild(iFeod, iType, iPos);
		}

		//����
		TaskMgr::update(Own().getOwnDataPtr(), Task::BuildTimes, 1);
		if (iFeod == LAND::xia_kou)
		{
			++xia_kou_dwelling_up_times;
			TaskMgr::update(Own().getOwnDataPtr(), Task::XiaKouDwellingUpAllTimes);
		}

		_sign_auto();
		return res_sucess;
	}

	int playerBuildTeam::setFeodState(const int iFeod, const bool state)
	{
		if (iFeod < LAND::FEOD_START || iFeod > LAND::FEOD_END)return err_illedge;
		buildTeamList[iFeod]->state = state;
		_sign_auto();
		return res_sucess;
	}

	bool playerBuildTeam::reduceBuildCDPer(const int btiID, const unsigned btIDX, const unsigned uiCDPer, const unsigned limitCD /* = 5 */)
	{
		if (uiCDPer < 1)return false;
		BUILDTEAM::workPtr work_ptr = getTeamWork(btiID, btIDX);
		if (!work_ptr)return false;
		if (work_ptr->isFree())return false;
		const unsigned now = Common::gameTime();
		if (work_ptr->iBuildCD <= (FREE_BUILD_CD_TIME + now))return false;

		LANDCONFIG::landCFGPtr config = ownerland_sys.getBuildConfig(work_ptr->iBuildType);
		if (!config)return false;
		FEOD::buildPtr build_ptr = Own().Builds().getBuild(work_ptr->iFeod, work_ptr->iBuildType, work_ptr->iBuildPos);
		if (!build_ptr)return false;
		LANDCONFIG::buildPtr config_level = config->findLV(build_ptr->iBuildLv);
		if (!config_level)return false;
		
		const unsigned cutCD = config_level->iBuildCD * (uiCDPer / 10000.0);
		const unsigned final_cut = cutCD < limitCD ? limitCD : cutCD;

		work_ptr->reduceCD(Own().ID(), final_cut);
		_sign_auto();
		return true;
	}

	bool playerBuildTeam::reduceBuildCD(const int btiID, const unsigned btIDX, const unsigned uiCD)
	{
		if (uiCD < 1)return false;
		BUILDTEAM::workPtr work_ptr = getTeamWork(btiID, btIDX);
		if (!work_ptr)return false;
		if (work_ptr->isFree())return false;
		const unsigned now = Common::gameTime();
		if (work_ptr->iBuildCD <= (FREE_BUILD_CD_TIME + now))return false;
		work_ptr->reduceCD(Own().ID(), uiCD);
		_sign_auto();
		return true;
	}

	bool playerBuildTeam::reduceBuildCD(const int iFeod, const int iType, const int iPos, const unsigned uiCD)
	{
		if (uiCD < 1)return false;
		BUILDTEAM::workPtr work_ptr = getWork(iFeod, iType, iPos);
		if (!work_ptr)return false;
		if (work_ptr->isFree())return false;
		const unsigned now = Common::gameTime();
		if (work_ptr->iBuildCD <= (FREE_BUILD_CD_TIME + now))return false;
		work_ptr->reduceCD(Own().ID(), uiCD);
		_sign_auto();
		return true;
	}

	int playerBuildTeam::addBuildTeam(const int iFeod)
	{
		if (iFeod < LAND::FEOD_START || iFeod > LAND::FEOD_END)return err_illedge;
		BUILDTEAM::buildTeamPtr team_ptr = buildTeamList[iFeod];
		if (team_ptr->TeamList.size() >= MAX_BUILD_TEAM_NUM)return err_illedge;
		team_ptr->TeamList.push_back(Creator<BUILDTEAM::buildWork>::Create(iFeod, team_ptr->TeamList.size(), _Own));
		_sign_auto();
		return res_sucess;
	}

}

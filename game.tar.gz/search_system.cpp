#include "search_system.h"
#include "chat.h"
#include "item_system.h"
#include "man_system.h"
#include "task_mgr.h"

namespace gg
{
	search_system* const search_system::_Instance = new search_system();

	void search_system::initData()
	{
		loadFile();
	}

	void search_system::loadFile()
	{
		Json::Value json = Common::loadJsonFile("./instance/search/search.json");

		_WeiWangBoxes = actionFormat(json["WWBoxes"].asInt());
		_CashBoxes = actionFormat(json["CSBoxes"].asInt());
		_SPCashBoxes = actionFormat(json["SPCSBoxes"].asInt());
		_FirstWWBoxes.clear();
		_FirstCSBoxes.clear();
		for (unsigned i = 0; i < json["FSTWWBoxes"].size(); i++)
		{
			_FirstWWBoxes.push_back(actionFormat(json["FSTWWBoxes"][i].asInt()));
		}
		for (unsigned i = 0; i < json["FSTCSBoxes"].size(); i++)
		{
			_FirstCSBoxes.push_back(actionFormat(json["FSTCSBoxes"][i].asInt()));
		}
	}

	void search_system::getData(net::Msg& m, Json::Value& r)
	{
		playerDataPtr player = player_mgr.getPlayer(m.playerID);
		if (!player)Return(r, err_illedge);
		player->Sch().update();
	}

	void search_system::searchFor_WeiWang(net::Msg& m, Json::Value& r)
	{
		playerDataPtr player = player_mgr.getPlayer(m.playerID);
		if (!player)Return(r, err_illedge);
		if (player->LV() < 15)Return(r, err_illedge);
		ReadJsonArray;
		const unsigned times = js_msg[0u].asUInt();
		if (!(times == 1 || times == 10))Return(r, err_illedge);
		if (player->Items().isOver(times))Return(r, err_bag_full);
		playerSearch& sch = player->Sch();
		const unsigned lv = player->LV();
		if (lv < 40 &&
			((times == 1 && !sch.isFreeWW() && sch.singleCD() > Common::gameTime()) || (times == 10 && sch.multiCD() > Common::gameTime()))
			)Return(r, err_search_in_cd);
		const int cost_total = sch.isFreeWW() ? (1 == times ? 0 : 8500) : (1 == times ? 1000 : 9500);
		if (cost_total > player->Res().getFame())Return(r, err_fame_not_enough);
		Json::Value& reward_json = r[strMsg][1u] = Json::arrayValue;
		for (unsigned i = 0; i < times; i++)
		{
			bool is_frist = false;
			if (sch.isFirstWW())
			{
				is_frist = true;
				actionDo(player, _FirstWWBoxes[sch.FirstWW()], 1);
			}
			else
			{
				actionDo(player, _WeiWangBoxes, 1);
			}
			Json::Value val = actionRes();
			for (unsigned i = 0; i < val.size(); i++)
			{
				Json::Value& sg_val = val[i];
				reward_json.append(sg_val);
				const int actionID = sg_val[0u].asInt();
				if (actionID == ACTION::item)
				{
					cfgItemPtr config = item_sys.getConfig(sg_val[1u].asInt());
					if (config)
					{
						if (
							config->quality >= itemDef::purple &&
							(config->type == itemDef::type_equipment || config->type == itemDef::type_paper)
							)
						{
							qValue json(qJson::qj_array);
							json.append(chat_sys.ChatPackageQ(player));
							json.append(config->itemID);
							chat_sys.despatchAll(CHAT::server_search_purple_item, json);
						}
						TaskMgr::update(player, Task::SearchPaperNumOfColor, config->quality, 1);
						TaskMgr::update(player, Task::SearchPaperNum, 1);
					}
				}
				else if (actionID == ACTION::man)
				{
					cfgManPtr config = man_sys.getConfig(sg_val[1u].asInt());
					if (config)
					{
						if (config->rating >= ManConfig::legendary)
						{
							qValue json(qJson::qj_array);
							json.append(chat_sys.ChatPackageQ(player));
							json.append(config->manID);
							chat_sys.despatchAll(CHAT::server_search_excellent_man, json);
						}
					}
				}
			}
			if (is_frist)sch.nextFirstWW();//��һ���̶�
			if (sch.isFreeWW())
			{
				sch.nextFreeWW();
			}
			else
			{
				sch.nextWWSearch();
			}
		}
		player->Res().alterFame(-cost_total);
		if (lv < 40)
		{
			if (times == 1)sch.nextSingleCD();
			else sch.nextMultiCD();
		}
		Log(DBLOG::strLogSearch, player, 3, times, cost_total, "", "", "", "", "", reward_json.toIndentString());
		player->Sch().tickSearch(false, times);
		player->Daily().tickTask(DAILY::player_search, times);
		Return(r, res_sucess);
	}

	void search_system::searchFor_Cash(net::Msg& m, Json::Value& r)
	{
		playerDataPtr player = player_mgr.getPlayer(m.playerID);
		if (!player)Return(r, err_illedge);
		if (player->LV() < 15)Return(r, err_illedge);
		//if (player->Info().VipLv() < 1 && player->LV() < 28)Return(r, err_illedge);
		ReadJsonArray;
		const unsigned times = js_msg[0u].asUInt();
		if (!(times == 1 || times == 10))Return(r, err_illedge);
		if (player->Items().isOver(times))Return(r, err_bag_full);

		playerSearch& sch = player->Sch();
		const int cost_total = sch.isFreeCS() ? (1 == times ? 0 : 2470) : (1 == times ? 288 : 2750);
		if (cost_total > player->Res().getCash())Return(r, err_gold_not_enough);
		Json::Value& reward_json = r[strMsg][1u] = Json::arrayValue;
		for (unsigned i = 0; i < times; i++)
		{
			bool is_frist = false;
			if (sch.isFirstCS())//ʹ�ù̶�����
			{
				is_frist = true;
				actionDo(player, _FirstCSBoxes[sch.FirstCS()], 1);
			}
			else if (0 == sch.CSSearch())
			{
				actionDo(player, _SPCashBoxes, 1);
			}
			else
			{
				actionDo(player, _CashBoxes, 1);
			}
			Json::Value val = actionRes();
			for (unsigned i = 0; i < val.size(); i++)
			{
				Json::Value& sg_val = val[i];
				reward_json.append(sg_val);
				const int actionID = sg_val[0u].asInt();
				if (actionID == ACTION::item)
				{
					cfgItemPtr config = item_sys.getConfig(sg_val[1u].asInt());
					if (config)
					{
						if (
							config->quality >= itemDef::purple &&
							(config->type == itemDef::type_equipment || config->type == itemDef::type_paper)
							)
						{
							qValue json(qJson::qj_array);
							json.append(chat_sys.ChatPackageQ(player));
							json.append(config->itemID);
							chat_sys.despatchAll(CHAT::server_search_purple_item, json);
						}
						TaskMgr::update(player, Task::SearchPaperNumOfColor, config->quality, 1);
						TaskMgr::update(player, Task::SearchPaperNum, 1);
					}
				}
				else if (actionID == ACTION::man)
				{
					cfgManPtr config = man_sys.getConfig(sg_val[1u].asInt());
					if (config)
					{
						if (config->rating >= ManConfig::legendary)
						{
							qValue json(qJson::qj_array);
							json.append(chat_sys.ChatPackageQ(player));
							json.append(config->manID);
							chat_sys.despatchAll(CHAT::server_search_excellent_man, json);
						}
					}
				}
			}
			if (is_frist)sch.nextFirstCS();//��һ���̶�
			if (sch.isFreeCS())
			{
				sch.nextFreeCS();
			}
			sch.nextCSSearch();
		}
		player->Res().alterCash(-cost_total);
		Log(DBLOG::strLogSearch, player, 4, times, cost_total, "", "", "", "", "", reward_json.toIndentString());
		player->Sch().tickSearch(true, times);
		player->Daily().tickTask(DAILY::player_search, times);
		Return(r, res_sucess);
	}
}

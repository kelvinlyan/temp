#include "search_system.h"
#include "chat.h"

namespace gg
{
	namespace Search
	{
		ShopData::ShopData(Json::Value& info)
		{
			_id = info["id"].asInt();
			_consume_con = info["consumeCon"].asInt();
			_buy_times = info["buynum"].asInt();
			_weight = info["weight"].asInt();
			_kingdom_id = (Kingdom::NATION)info["nation"].asInt();
			_box = actionFormatBox(info["box"]);
		}
	}

	search_system* const search_system::_Instance = new search_system();

	void search_system::initData()
	{
		//initialCheck("search.json");
		loadFile();
	}

	void search_system::loadFile()
	{
		Json::Value json = Common::loadJsonFile("./instance/search/search.json");

		_WeiWangBoxes = actionFormat(json["WWBoxes"].asInt());
		_CashBoxes = actionFormat(json["CSBoxes"].asInt());
		_SPCashBoxes = actionFormat(json["SPCSBoxes"].asInt());
		_FirstWWBoxes.clear();
		_FirstCSBoxes.clear();
		for (unsigned i = 0; i < json["FSTWWBoxes"].size(); i++)
		{
			_FirstWWBoxes.push_back(actionFormat(json["FSTWWBoxes"][i].asInt()));
		}
		for (unsigned i = 0; i < json["FSTCSBoxes"].size(); i++)
		{
			_FirstCSBoxes.push_back(actionFormat(json["FSTCSBoxes"][i].asInt()));
		}

		_ww_flush_costs.clear();
		_cs_flush_costs.clear();

		json = Common::loadJsonFile("./instance/search/ww_shop_cost.json");
		for (unsigned i = 0; i < json.size(); ++i)
			_ww_flush_costs.push_back(json[i].asInt());
		json = Common::loadJsonFile("./instance/search/cs_shop_cost.json");
		for (unsigned i = 0; i < json.size(); ++i)
			_cs_flush_costs.push_back(json[i].asInt());

		{//�����̵�
			memset(_ww_weight, 0x0, sizeof(_ww_weight));
			json = Common::loadJsonFile("./instance/search/ww_shop.json");
			for (unsigned i = 0; i < json.size(); ++i)
			{
				SearchShopData ptr = Creator<Search::ShopData>::Create(json[i]);
				_ww_shop_map.insert(make_pair(ptr->_id, ptr));
				if (ptr->_weight == 0)
				{
					if (ptr->_kingdom_id != -1)
						_ww_shopFix[ptr->_kingdom_id].push_back(ptr);
					else
					{
						for (unsigned j = 0; j < Kingdom::nation_num; ++j)
							_ww_shopFix[j].push_back(ptr);
						_ww_shopFix[Kingdom::nation_num].push_back(ptr);
					}
				}
				else
				{
					if (ptr->_kingdom_id != -1)
					{
						_ww_shopRd[ptr->_kingdom_id].push_back(ptr);
						_ww_weight[ptr->_kingdom_id] += ptr->_weight;
					}
					else
					{
						for (int j = 0; j < Kingdom::nation_num; ++j)
						{
							_ww_shopRd[j].push_back(ptr);
							_ww_weight[j] += ptr->_weight;
						}
						_ww_shopRd[Kingdom::nation_num].push_back(ptr);
						_ww_weight[Kingdom::nation_num] += ptr->_weight;
					}
				}
			}
		};
		{//�����̵�
			memset(_cs_weight, 0x0, sizeof(_cs_weight));
			json = Common::loadJsonFile("./instance/search/cs_shop.json");
			for (unsigned i = 0; i < json.size(); ++i)
			{
				SearchShopData ptr = Creator<Search::ShopData>::Create(json[i]);
				_cs_shop_map.insert(make_pair(ptr->_id, ptr));
				if (ptr->_weight == 0)
				{
					if (ptr->_kingdom_id != -1)
						_cs_shopFix[ptr->_kingdom_id].push_back(ptr);
					else
					{
						for (unsigned j = 0; j < Kingdom::nation_num; ++j)
							_cs_shopFix[j].push_back(ptr);
						_cs_shopFix[Kingdom::nation_num].push_back(ptr);
					}
				}
				else
				{
					if (ptr->_kingdom_id != -1)
					{
						_cs_shopRd[ptr->_kingdom_id].push_back(ptr);
						_cs_weight[ptr->_kingdom_id] += ptr->_weight;
					}
					else
					{
						for (int j = 0; j < Kingdom::nation_num; ++j)
						{
							_cs_shopRd[j].push_back(ptr);
							_cs_weight[j] += ptr->_weight;
						}
						_cs_shopRd[Kingdom::nation_num].push_back(ptr);
						_cs_weight[Kingdom::nation_num] += ptr->_weight;
					}
				}
			}
		};
	}

	void search_system::getData(net::Msg& m, Json::Value& r)
	{
		playerDataPtr player = player_mgr.getPlayer(m.playerID);
		if (!player)Return(r, err_illedge);
		player->Sch().update();
	}

	void search_system::searchFor_WeiWang(net::Msg& m, Json::Value& r)
	{
		playerDataPtr player = player_mgr.getPlayer(m.playerID);
		if (!player)Return(r, err_illedge);
		ReadJsonArray;
		const unsigned times = js_msg[0u].asUInt();
		if (!(times == 1 || times == 10))Return(r, err_illedge);
		if (player->Items().isOver(times))Return(r, err_bag_full);
		playerSearch& sch = player->Sch();
		const unsigned lv = player->LV();
		if (lv < 40 &&
			((times == 1 && sch.singleCD() > Common::gameTime()) || (times == 10 && sch.multiCD() > Common::gameTime()))
			)Return(r, err_search_in_cd);
		int cost_total = 0;
		const unsigned ww_times = sch.WWSearch();
		const unsigned reduce = sch.isFreeWW() ? 1 : 0;
		for (unsigned i = 0; i < times - reduce; i++)
		{
			//(100+�ȼ�*2)*(1+����*0.05) ----(1+����*0.05)���ֵΪ5
			cost_total += (100 + 2 * lv) * (1.0 + (ww_times + i) * 0.05);
		}
		if (cost_total > player->Res().getFame())Return(r, err_fame_not_enough);
		Json::Value& reward_json = r[strMsg][1u] = Json::arrayValue;
		for (unsigned i = 0; i < times; i++)
		{
			bool is_frist = false;
			if (sch.isFirstWW())
			{
				is_frist = true;
				actionDo(player, _FirstWWBoxes[sch.FirstWW()], 1);
			}
			else
			{
				actionDo(player, _WeiWangBoxes, 1);
			}
			Json::Value val = actionRes();
			for (unsigned i = 0; i < val.size(); i++)
			{
				reward_json.append(val[i]);
			}
			if (is_frist)sch.nextFirstWW();//��һ���̶�
			if (sch.isFreeWW())
			{
				sch.nextFreeWW();
			}
			else
			{
				sch.nextWWSearch();
			}
		}
		player->Res().alterFame(-cost_total);
		if (lv < 40)
		{
			if (times == 1)sch.nextSingleCD();
			else sch.nextMultiCD();
		}
		Log(DBLOG::strLogSearch, player, 3, times, cost_total, "", "", "", "", "", reward_json.toIndentString());
		Return(r, res_sucess);
	}

	void search_system::searchFor_Cash(net::Msg& m, Json::Value& r)
	{
		playerDataPtr player = player_mgr.getPlayer(m.playerID);
		if (!player)Return(r, err_illedge);
		if (player->Info().VipLv() < 1 && player->LV() < 28)Return(r, err_illedge);
		ReadJsonArray;
		const unsigned times = js_msg[0u].asUInt();
		if (!(times == 1 || times == 10))Return(r, err_illedge);
		if (player->Items().isOver(times))Return(r, err_bag_full);

		playerSearch& sch = player->Sch();
		const unsigned reduce = sch.isFreeCS() ? 1 : 0;
		const int cost_total = 20 * (times - reduce);
		if (cost_total > player->Res().getCash())Return(r, err_gold_not_enough);
		Json::Value& reward_json = r[strMsg][1u] = Json::arrayValue;
		for (unsigned i = 0; i < times; i++)
		{
			bool is_frist = false;
			if (sch.isFirstCS())
			{
				is_frist = true;
				actionDo(player, _FirstCSBoxes[sch.FirstCS()], 1);
			}
			else
			{
				actionDo(player, _CashBoxes, 1);
			}
			Json::Value val = actionRes();
			for (unsigned i = 0; i < val.size(); i++)
			{
				reward_json.append(val[i]);
			}
			if (is_frist)sch.nextFirstCS();//��һ���̶�
			if (sch.isFreeCS())
			{
				sch.nextFreeCS();
			}
			sch.nextCSSearch();
		}
		player->Res().alterCash(-cost_total);
		Log(DBLOG::strLogSearch, player, 4, times, cost_total, "", "", "", "", "", reward_json.toIndentString());
		Return(r, res_sucess);
	}

	void search_system::WWshopInfo(net::Msg& m, Json::Value& r)
	{
		playerDataPtr player = player_mgr.getPlayer(m.playerID);
		if (!player) Return(r, err_illedge);
		player->Sch().updateShopWW();
	}

	void search_system::WWbuy(net::Msg& m, Json::Value& r)
	{
		playerDataPtr player = player_mgr.getPlayer(m.playerID);
		if (!player) Return(r, err_illedge);
		ReadJsonArray;
		int pos = js_msg[0u].asInt();
		int id = js_msg[1u].asInt();
		int res = player->Sch().buyWW(pos, id, r[strMsg][1u]);
		Return(r, res);
	}

	void search_system::WWflush(net::Msg& m, Json::Value& r)
	{
		playerDataPtr player = player_mgr.getPlayer(m.playerID);
		if (!player) Return(r, err_illedge);
		int res = player->Sch().flushWW();
		Return(r, res);
	}

	void search_system::CSshopInfo(net::Msg& m, Json::Value& r)
	{
		playerDataPtr player = player_mgr.getPlayer(m.playerID);
		if (!player) Return(r, err_illedge);
		player->Sch().updateShopCS();
	}

	void search_system::CSbuy(net::Msg& m, Json::Value& r)
	{
		playerDataPtr player = player_mgr.getPlayer(m.playerID);
		if (!player) Return(r, err_illedge);
		ReadJsonArray;
		int pos = js_msg[0u].asInt();
		int id = js_msg[1u].asInt();
		int res = player->Sch().buyCS(pos, id, r[strMsg][1u]);
		Return(r, res);
	}

	void search_system::CSflush(net::Msg& m, Json::Value& r)
	{
		playerDataPtr player = player_mgr.getPlayer(m.playerID);
		if (!player) Return(r, err_illedge);
		int res = player->Sch().flushCS();
		Return(r, res);
	}

	void search_system::onItemBroadcast(playerDataPtr player, const unsigned channel, int item_id)
	{
		Json::Value data_json;
		data_json.append(chat_sys.ChatPackage(player));
		data_json.append(item_id);
		if (channel == CHAT::chat_all)
		{
			chat_sys.despatchAll(CHAT::server_search_purple, data_json);
		}
		else if (channel == CHAT::chat_kingdom)
		{
			chat_sys.despatchKingdom(CHAT::server_search_ry, player->Info().Nation(), data_json);
		}
	}

	SearchShopData search_system::getWWShopData(int id)
	{
		SearchShopMap::iterator it = _ww_shop_map.find(id);
		if (it != _ww_shop_map.end())
			return it->second;
		return SearchShopData();
	}

	SearchShopData search_system::getCSShopData(int id)
	{
		SearchShopMap::iterator it = _cs_shop_map.find(id);
		if (it != _cs_shop_map.end())
			return it->second;
		return SearchShopData();
	}

	void search_system::getWWShopList(int nation, std::vector<int>& id_list)
	{
		if (nation <= Kingdom::null || nation >= Kingdom::nation_num)
			nation = Kingdom::nation_num;

		SearchShopList fix = _ww_shopFix[nation];
		SearchShopList rd = _ww_shopRd[nation];

		unsigned rdNum = 0;
		if (fix.size() < Search::ShopItemCount)
			rdNum = Search::ShopItemCount - fix.size();
		for (unsigned i = 0; i < fix.size(); i++)
		{
			if (i < Search::ShopItemCount)
				id_list.push_back(fix[i]->_id);
		}

		unsigned tmp_total = _ww_weight[nation];
		for (unsigned i = 0; i < rdNum; i++)
		{
			const unsigned rd_num = Common::randomBetween(0, tmp_total - 1);
			unsigned real_num = 0;
			for (unsigned idx = 0; idx < rd.size(); idx++)
			{
				real_num += rd[idx]->_weight;
				if (real_num > rd_num)
				{
					id_list.push_back(rd[idx]->_id);

					tmp_total -= rd[idx]->_weight;
					rd.erase(rd.begin() + idx);
					break;
				}
			}
		}
	}

	void search_system::getCSShopList(int nation, std::vector<int>& id_list)
	{
		if (nation <= Kingdom::null || nation >= Kingdom::nation_num)
			nation = Kingdom::nation_num;

		SearchShopList fix = _cs_shopFix[nation];
		SearchShopList rd = _cs_shopRd[nation];

		unsigned rdNum = 0;
		if (fix.size() < Search::ShopItemCount)
			rdNum = Search::ShopItemCount - fix.size();
		for (unsigned i = 0; i < fix.size(); i++)
		{
			if (i < Search::ShopItemCount)
				id_list.push_back(fix[i]->_id);
		}

		unsigned tmp_total = _cs_weight[nation];
		for (unsigned i = 0; i < rdNum; i++)
		{
			const unsigned rd_num = Common::randomBetween(0, tmp_total - 1);
			unsigned real_num = 0;
			for (unsigned idx = 0; idx < rd.size(); idx++)
			{
				real_num += rd[idx]->_weight;
				if (real_num > rd_num)
				{
					id_list.push_back(rd[idx]->_id);

					tmp_total -= rd[idx]->_weight;
					rd.erase(rd.begin() + idx);
					break;
				}
			}
		}
	}

	int search_system::getWWFlushCost(unsigned times)
	{
		if (times >= _ww_flush_costs.size())
			times = _ww_flush_costs.size() - 1;
		return _ww_flush_costs[times];
	}

	int search_system::getCSFlushCost(unsigned times)
	{
		if (times >= _cs_flush_costs.size())
			times = _cs_flush_costs.size() - 1;
		return _cs_flush_costs[times];
	}
}
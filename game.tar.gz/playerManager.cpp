#include "mongoDB.h"
#include "json/json.h"
#include <boost/thread/thread.hpp>
#include "game_server.h"
#include "mongoDB.h"
#include "core_helper.h"
#include <boost/bind.hpp>
#include "gate_game_protocol.h"
//#include "record_system.h"
#include "timmer.hpp"
#include "net_helper.hpp"
#include "service_config.h"
#include "dbDriver.h"
//#include "kingdom.h"
#include "kingdom_system.h"
#include "gate_account_protocol.h"
#include "despatch_task.h"
#include "kingdomwar_data.h"
#include "expedition_data.h"

namespace gg
{
	playerManager* const playerManager::playerMgr = new playerManager();
	const static unsigned CheckHours = 14400;
	const static unsigned LogOnlineTimes = 300;
	const static unsigned removeHours = 7200;
	const static unsigned BackOfflinePerTime = 1800;


	static unsigned stander5Tick = 0;
	static unsigned stander8Tick = 0;
	static unsigned stander18Tick = 0;
	static unsigned stander22Tick = 0;
	static void saveStander()
	{
		mongo::BSONObj key = BSON("key" << 1);
		mongo::BSONObj obj = BSON("key" << 1 << "s5" << stander5Tick <<
			"s8" << stander8Tick << "s18" << stander18Tick << "s22" << stander22Tick);
		db_mgr.SaveMongo(DBN::dbTickStander, key, obj);
	}

	playerManager::playerManager()
	{
		//onlineNum = 0;
	}

	playerManager::~playerManager()
	{

	}

	unsigned playerManager::stander5()
	{
		return stander5Tick;
	}

	unsigned playerManager::stander8()
	{
		return stander8Tick;
	}

	unsigned playerManager::stander18()
	{
		return stander18Tick;
	}

	unsigned playerManager::stander22()
	{
		return stander22Tick;
	}

	void playerManager::initData()
	{
		mongo::BSONObj key = BSON("key" << 1);
		mongo::BSONObj obj = db_mgr.FindOne(DBN::dbTickStander, key);
		if (obj.isEmpty())
		{
			stander5Tick = Common::getNextTime(5);
			stander8Tick = Common::getNextTime(8);
			stander18Tick = Common::getNextTime(18);
			stander22Tick = Common::getNextTime(22);
			saveStander();
		}
		else
		{
			stander5Tick = (unsigned)obj["s5"].Int();
			stander8Tick = (unsigned)obj["s8"].Int();
			stander18Tick = (unsigned)obj["s18"].Int();
			checkNotEoo(obj["s22"])
				stander22Tick = (unsigned)obj["s22"].Int();
			else
				stander22Tick = Common::getNextTime(22);
		}

		playerMap.clear();
		nameMap.clear();
		onlineIDMap.clear();
		onlineNAMap.clear();

		const unsigned now = Common::gameTime();
		const std::tm now_tm = Common::toTm(now);
		const unsigned current_zero_ms = now + HOUR - now_tm.tm_min * MINUTE - now_tm.tm_sec;
		Timer::AddEventTickTime(boostBind(playerManager::timePerHourTick, this, _1), Inter::event_system_common_recall, current_zero_ms);
		Timer::AddEventNextTimeCT(boostBind(playerManager::playerOnlineLog, this, _1), Inter::event_log_player_online, Common::gameTime() + LogOnlineTimes, LogOnlineTimes);
		Timer::AddEventSeconds(boostBind(playerManager::playerManagerUpdate, this, _1), Inter::event_clean_server, CheckHours);
		Timer::AddEventTickTime(boostBind(playerManager::time5ClockTick, this, _1), Inter::event_time_5clock, stander5Tick + 1);
		Timer::AddEventTickTime(boostBind(playerManager::time8ClockTick, this, _1), Inter::event_time_8clock, stander8Tick + 1);
		Timer::AddEventTickTime(boostBind(playerManager::time18ClockTick, this, _1), Inter::event_time_18clock, stander18Tick + 1);
		Timer::AddEventTickTime(boostBind(playerManager::time22ClockTick, this, _1), Inter::event_time_22clock, stander22Tick + 1);

		//ÿ��30���ӵı���
		Timer::AddEventNextTimeCT(boostBind(playerManager::playerOfflineBackUp, this, _1), Inter::event_timer_offline_backup, Common::gameTime() + BackOfflinePerTime, BackOfflinePerTime);
	}

	void playerManager::time5ClockTick(const structTimer& timerData)
	{
		stander5Tick += DAY;
		//for (BHIDMAP::iterator it = onlineIDMap.begin(); it != onlineIDMap.end(); ++it)
		for (BHIDMAP::iterator it = playerMap.begin(); it != playerMap.end(); ++it)
		{
			playerDataPtr player = it->second;
			if (!player)continue;
			if (player->isOnline())
			{
				player->Tick().tick5Event();
			}
			else
			{
				player->Dirty = true;
			}
		}
		kingdom_sys.tickRank();
		Expedition::RankMgr::shared().tick();

		saveStander();
		Timer::AddEventTickTime(boostBind(playerManager::time5ClockTick, this, _1), Inter::event_time_5clock, stander5Tick + 1);
	}

	void playerManager::time22ClockTick(const structTimer& timerData)
	{
		stander22Tick += DAY;
		//for (BHIDMAP::iterator it = onlineIDMap.begin(); it != onlineIDMap.end(); ++it)
		for (BHIDMAP::iterator it = playerMap.begin(); it != playerMap.end(); ++it)
		{
			playerDataPtr player = it->second;
			if (!player)continue;
			if (player->isOnline())
			{
				player->Tick().tick22Event();
			}
			else
			{
				player->Dirty = true;
			}
		}

		saveStander();
		Timer::AddEventTickTime(boostBind(playerManager::time22ClockTick, this, _1), Inter::event_time_22clock, stander22Tick + 1);
	}

	void playerManager::time8ClockTick(const structTimer& timerData)
	{
		stander8Tick += DAY;
		//for (BHIDMAP::iterator it = onlineIDMap.begin(); it != onlineIDMap.end(); ++it)
		for (BHIDMAP::iterator it = playerMap.begin(); it != playerMap.end(); ++it)
		{
			playerDataPtr player = it->second;
			if (!player)continue;
			if (player->isOnline())
			{
				player->Tick().tick8Event();
			}
			else
			{
				player->Dirty = true;
			}
		}

		saveStander();
		Timer::AddEventTickTime(boostBind(playerManager::time8ClockTick, this, _1), Inter::event_time_8clock, stander8Tick + 1);
	}

	void playerManager::time18ClockTick(const structTimer& timerData)
	{
		stander18Tick += DAY;
		//for (BHIDMAP::iterator it = onlineIDMap.begin(); it != onlineIDMap.end(); ++it)
		for (BHIDMAP::iterator it = playerMap.begin(); it != playerMap.end(); ++it)
		{
			playerDataPtr player = it->second;
			if (!player)continue;
			if (player->isOnline())
			{
				player->Tick().tick18Event();
			}
			else
			{
				player->Dirty = true;
			}
		}

		saveStander();
		Timer::AddEventTickTime(boostBind(playerManager::time18ClockTick, this, _1), Inter::event_time_18clock, stander18Tick + 1);
	}

	static void DoOfflineBackUp(const int playerID)
	{
		playerDataPtr player = player_mgr.getOnlinePlayer(playerID);
		if (player)
		{
			//���߱������߱���
			player->OnlineBox().offline();
			//���߼�¼
			player->Offline().Off();
		}
	}

	void playerManager::playerOfflineBackUp(const structTimer& timerData)
	{
		for (BHIDMAP::iterator it = onlineIDMap.begin(); it != onlineIDMap.end(); ++it)
		{
			playerDataPtr player = it->second;
			if (!player)continue;
			UserTask::Add(boostBind(DoOfflineBackUp, player->ID()), Inter::event_timer_offline_backup);
		}
	}

	void playerManager::playerOnlineLog(const structTimer& timerData)
	{
		Log(DBLOG::strLogPlaying, -1, onlineIDMap.size());
	}

	void playerManager::gateResetReq()
	{
		//for (BHIDMAP::iterator it = playerMap.begin(); it != playerMap.end(); ++it)
		for (BHIDMAP::iterator it = onlineIDMap.begin(); it != onlineIDMap.end();)
		{
			playerDataPtr player = it->second;
			++it;
			if (!player)continue;
			playerLogout(player);
		}
	}

	void playerManager::playerManagerUpdate(const structTimer& timerData)
	{
		Timer::AddEventSeconds(boostBind(playerManager::playerManagerUpdate, this, _1), Inter::event_clean_server, CheckHours);
		const unsigned memory_size = playerMap.size();
		LogS << "memory " << memory_size << " been used in map" << LogEnd;
		if (memory_size >= 10000)
		{
			const unsigned num = playerMap.size() - onlineIDMap.size();
			playerMap = onlineIDMap;
			nameMap = onlineNAMap;
			LogS << num << color_pink(" player memory cache has been free ~") << LogEnd;
		}
		//�˻�ID���
		accountIDMap.clear();
	}

	bool playerManager::hasRegisterName(const string name)
	{
		mongo::BSONObj key = BSON(strPlayerName << name);
		mongo::BSONObj obj = db_mgr.FindOne(DBN::dbPlayerBase, key);
		if (!obj.isEmpty())return true;
		return false;
	}

	void playerManager::playerLogout(const int playerID)
	{
		playerDataPtr player = findPlayer(playerID);
		playerLogout(player);
	}

	void playerManager::playerLogout(playerDataPtr player)
	{
		if (!player)return;
		player->Logout();
		if (!player->isOnline())
		{
			onlineIDMap.erase(player->ID());
			onlineNAMap.erase(player->Name());
		}
	}

	void playerManager::playerLogin(const int playerID)
	{
		playerDataPtr player = getPlayer(playerID);
		playerLogin(player);
	}

	void playerManager::playerLogin(playerDataPtr player)
	{
		if (!player)return;
		player->Login();
		if (player->isOnline())
		{
			onlineIDMap[player->ID()] = player;
			onlineNAMap[player->Name()] = player;
		}
	}

	int playerManager::createNewPlayer(playerDataPtr player, const string playerName)
	{
		if (playerName.empty())return err_illedge;
		if (player->isVaild())return err_illedge;
		if (hasRegisterName(playerName))return err_role_name_conflict;

		player->Info().playerCreate = Common::gameTime();
		player->Info().playerName = playerName;
		player->Info()._auto_save();

		//���͸���̨
		Json::Value updateAccount;
		updateAccount[strMsg][0u] = playerName;
		string strSend = updateAccount.toIndentString();
		net::Msg mj(player->ID(), service::process_id::ACCOUNT_NET_ID, protocol::l2c::notice_account_player_update_resp, strSend);
		game_svr->async_send_to_gate(mj);

		//������ɫ������Ϣ�ɹ�
		accountIDMap.erase(player->ID());
		playerMap[player->ID()] = player;
		nameMap[player->Name()] = player;
		player->onCreateRole();
		playerLogin(player);
		return res_sucess;
	}

	playerDataPtr playerManager::createNewAccount( const int playerID, const string uidKey, const string cidKey, const string gidKey)
	{
		playerDataPtr player = playerData::Create(playerID, AutoPlayer::class_all_over);
		if (!player)throw "cant malloc new player data ...";
		player->Info().uidKey = uidKey;
		player->Info().cidKey = cidKey;
		player->Info().gidKey = gidKey;
		player->Info()._auto_save();

		//������ɫ������Ϣ�ɹ�
		accountIDMap[player->ID()] = player;
		return player;
	}

	playerDataPtr playerManager::getCachePlayer(const int playerID)
	{
		playerDataPtr player = findPlayer(playerID);
		if (player)
		{
			player->clearData();
			return player;
		}
		return playerDataPtr();
	}

	playerDataPtr playerManager::getCachePlayer(const string playerName)
	{
		playerDataPtr player = findPlayer(playerName);
		if (player)
		{
			player->clearData();
			return player;
		}
		return playerDataPtr();
	}

	playerDataPtr playerManager::getOnlinePlayer(const int playerID)
	{
		playerDataPtr player = findPlayer(playerID);
		if (player && player->isOnline())return player;
		return playerDataPtr();
	}

	playerDataPtr playerManager::getOnlinePlayer(const string playerName)
	{
		playerDataPtr player = findPlayer(playerName);
		if (player && player->isOnline())return player;
		return playerDataPtr();
	}

	playerDataPtr playerManager::findPlayer(const int playerID)
	{
		BHIDMAP::iterator it = playerMap.find(playerID);
		if (it != playerMap.end())return it->second;
		return playerDataPtr();
	}

	void playerManager::rebindPlayer(const string oldName, playerDataPtr player)
	{
		onlineNAMap.erase(oldName);
		nameMap.erase(oldName);
		insertData(player);
	}

	playerDataPtr playerManager::loadFromDB(const int playerID)
	{
		playerDataPtr player = playerData::Create(playerID);
		if (!player)throw "cant malloc new player data";
		if (!player->isVaild())return playerDataPtr();
		insertData(player);
		return player;
	}

	playerDataPtr playerManager::loadFromDB(const string playerName)
	{
		playerDataPtr player = playerData::Create(playerName);
		if (!player)throw "cant malloc new player data";
		if (!player->isVaild())return playerDataPtr();
		insertData(player);
		return player;
	}

	bool playerManager::insertData(playerDataPtr player)
	{
		if (!player || !player->isVaild())return false;
		playerMap[player->ID()] = player;
		nameMap[player->Name()] = player;
		if (player->isOnline())
		{
			onlineIDMap[player->ID()] = player;
			onlineNAMap[player->Name()] = player;
		}
		return true;
	}

	playerDataPtr playerManager::findPlayer(const string name)
	{
		BHNMAP::iterator it = nameMap.find(name);
		if (it != nameMap.end())return it->second;
		return playerDataPtr();
	}

	playerManager::playerDataVec playerManager::allOnline()
	{
		playerDataVec vec;
		for (BHIDMAP::iterator it = onlineIDMap.begin(); it != onlineIDMap.end(); ++it)
		{
			playerDataPtr player = it->second;
			vec.push_back(player);
		}
		return vec;
	}

	playerManager::playerDataVec playerManager::nationAllOnline()
	{
		playerDataVec vec;
		for (BHIDMAP::iterator it = onlineIDMap.begin(); it != onlineIDMap.end(); ++it)
		{
			playerDataPtr player = it->second;
			if (Kingdom::null != player->Info().Nation())vec.push_back(player);
		}
		return vec;
	}

	playerManager::playerDataVec playerManager::nationOnline(const Kingdom::NATION nation)
	{
		playerDataVec vec;
		for (BHIDMAP::iterator it = onlineIDMap.begin(); it != onlineIDMap.end(); ++it)
		{
			playerDataPtr player = it->second;
			if (nation == player->Info().Nation())vec.push_back(player);
		}
		return vec;
	}

	playerDataPtr playerManager::getAccount(const int playerID)
	{
		if (playerID < 1)return playerDataPtr();
		playerDataPtr player;
		BHIDMAP::iterator it = accountIDMap.find(playerID);
		if (it != accountIDMap.end())
		{
			player = it->second;
		}
		else
		{
			player = getCachePlayer(playerID);
			if (player)return player;
			player = playerData::Create(playerID);
			if (player->isVaild())
			{
				insertData(player);
			}
			else
			{
				if (player->ID() < 1)return playerDataPtr();
				accountIDMap[player->ID()] = player;
			}
		}
		return player;
	}

	playerDataPtr playerManager::getPlayer(const int playerID)
	{
		playerDataPtr player = findPlayer(playerID);
		if (!player)player = loadFromDB(playerID);
		if (player)
		{
			player->clearData();
		}
		return player;
	}

	playerDataPtr playerManager::getPlayer(const string playerName)
	{
		playerDataPtr player = findPlayer(playerName);
		if (!player)player = loadFromDB(playerName);
		if (player)
		{
			player->clearData();
		}
		return player;
	}

	bool playerManager::IsOnline(const int playerID)
	{
		playerDataPtr player = findPlayer(playerID);
		if (!player || !player->isOnline())return false;
		return true;
	}

	void playerManager::sendToAll(const short pcl, Json::Value& m)
	{
		playerDataVec vec = allOnline();
		detail::batchOnline(vec, m, pcl);
	}

	void playerManager::sendToAll(const short pcl, qValue& m)
	{
		playerDataVec vec = allOnline();
		detail::batchOnline(vec, m, pcl);
	}

	void playerManager::sendToKingdom(const Kingdom::NATION kingdom, const short pcl, Json::Value& m)
	{
		playerDataVec vec = nationOnline(kingdom);
		detail::batchOnline(vec, m, pcl);
	}

	void playerManager::sendToKingdom(const Kingdom::NATION kingdom, const short pcl, qValue& m)
	{
		playerDataVec vec = nationOnline(kingdom);
		detail::batchOnline(vec, m, pcl);
	}

	void playerManager::sendToPlayer(const int playerID, const short pcl, Json::Value& m)
	{
		playerDataPtr player = getOnlinePlayer(playerID);
		if (!player)return;
		string str = m.toIndentString();
		net::Msg mj(player->ID(), service::process_id::INVAILD_PLAYER_ID, pcl, str);
		sendToPlayer(mj);
	}

	void playerManager::sendToPlayer(const int playerID, const short pcl, qValue& m)
	{
		playerDataPtr player = getOnlinePlayer(playerID);
		if (!player)return;
		string str = m.toIndentString();
		net::Msg mj(player->ID(), service::process_id::INVAILD_PLAYER_ID, pcl, str);
		sendToPlayer(mj);
	}

	void playerManager::sendToPlayer(net::Msg& mj)
	{
		if (mj.playerID > 0 && mj.netID == service::process_id::INVAILD_PLAYER_ID)game_svr->async_send_to_gate(mj);
	}

}

#include "playerManager.h"
#include "task_checker.h"
#include "heroparty_system.h"

namespace gg
{
	namespace Task
	{
		Checker::CreateFunc Checker::_creator_map[TypeMax];

		const static unsigned StoneItemId = 80001;
		
		void Checker::init()
		{
			_creator_map[Empty] = boostBind(CEmpty::create, _1);
			_creator_map[RechargeNum] = boostBind(CRechargeNum::create, _1); 
			_creator_map[Vip] = boostBind(CVip::create, _1); 
			_creator_map[ConsumeNum] = boostBind(CConsumeNum::create, _1); 
			_creator_map[ConsumeTimes] = boostBind(CConsumeTimes::create, _1); 
			_creator_map[GetSilverNum] = boostBind(CGetSilverNum::create, _1); 
			_creator_map[GetMeritNum] = boostBind(CGetMeritNum::create, _1); 
			_creator_map[GetFameNum] = boostBind(CGetFameNum::create, _1); 
			_creator_map[GetFoodNum] = boostBind(CGetFoodNum::create, _1); 
			_creator_map[GetWoodNum] = boostBind(CGetWoodNum::create, _1); 
			_creator_map[GetIronNum] = boostBind(CGetIronNum::create, _1); 
			_creator_map[UseActionNum] = boostBind(CUseActionNum::create, _1); 
			_creator_map[UseSilverNum] = boostBind(CUseSilverNum::create, _1); 
			_creator_map[UseMeritNum] = boostBind(CUseMeritNum::create, _1); 
			_creator_map[UseFameNum] = boostBind(CUseFameNum::create, _1); 
			_creator_map[UseFoodNum] = boostBind(CUseFoodNum::create, _1); 
			_creator_map[UseWoodNum] = boostBind(CUseWoodNum::create, _1); 
			_creator_map[UseIronNum] = boostBind(CUseIronNum::create, _1); 
			_creator_map[Lv] = boostBind(CLv::create, _1); 
			_creator_map[Power] = boostBind(CPower::create, _1); 
			_creator_map[WarCharpter] = boostBind(CWarCharpter::create, _1); 
			_creator_map[WarStarSum] = boostBind(CWarStarSum::create, _1); 
			_creator_map[EquipNumOfColor] = boostBind(CEquipNumOfColor::create, _1); 
			_creator_map[StrengthenTimes] = boostBind(CStrengthenTimes::create, _1); 
			_creator_map[ForgeTimes] = boostBind(CForgeTimes::create, _1); 
			_creator_map[HighForgeTimes] = boostBind(CHighForgeTimes::create, _1); 
			_creator_map[ForgeNumOfColor] = boostBind(CForgeNumOfColor::create, _1); 
			_creator_map[WashTimes] = boostBind(CWashTimes::create, _1); 
			_creator_map[HighWashTimes] = boostBind(CHighWashTimes::create, _1); 
			_creator_map[TransferTimes] = boostBind(CTransferTimes::create, _1); 
			_creator_map[ResolveTimes] = boostBind(CResolveTimes::create, _1); 
			_creator_map[ManNum] = boostBind(CManNum::create, _1); 
			_creator_map[ManNumOfColor] = boostBind(CManNumOfColor::create, _1); 
			_creator_map[ManMaxLv] = boostBind(CManMaxLv::create, _1); 
			_creator_map[UseExpItemTimes] = boostBind(CUseExpItemTimes::create, _1); 
			_creator_map[AdvanceTimes] = boostBind(CAdvanceTimes::create, _1); 
			_creator_map[TemperTimes] = boostBind(CTemperTimes::create, _1); 
			_creator_map[InheritTimes] = boostBind(CInheritTimes::create, _1); 
			_creator_map[StoneNum] = boostBind(CStoneNum::create, _1); 
			_creator_map[GemStoneNumOfLv] = boostBind(CGemStoneNumOfLv::create, _1); 
			_creator_map[InLayTimes] = boostBind(CInLayTimes::create, _1); 
			_creator_map[WarLordsAttackTimes] = boostBind(CWarLordsAttackTimes::create, _1); 
			_creator_map[WarLordsGetFameNum] = boostBind(CWarLordsGetFameNum::create, _1); 
			_creator_map[WarLordsGetTitle] = boostBind(CWarLordsGetTitle::create, _1); 
			_creator_map[HeroPartyTimes] = boostBind(CHeroPartyTimes::create, _1); 
			_creator_map[HeroPartyRank] = boostBind(CHeroPartyRank::create, _1); 
			_creator_map[HeroPartyShopTimes] = boostBind(CHeroPartyShopTimes::create, _1); 
			_creator_map[HeroPartyShopFlushTimes] = boostBind(CHeroPartyShopFlushTimes::create, _1); 
			_creator_map[TeamWarTimes] = boostBind(CTeamWarTimes::create, _1); 
			_creator_map[TeamWarPaperNum] = boostBind(CTeamWarPaperNum::create, _1); 
			_creator_map[TeamWarShopTimes] = boostBind(CTeamWarShopTimes::create, _1); 
			_creator_map[BuildTimes] = boostBind(CBuildTimes::create, _1); 
			_creator_map[InfantryLv] = boostBind(CInfantryLv::create, _1); 
			_creator_map[SowarLv] = boostBind(CSowarLv::create, _1); 
			_creator_map[SapperLv] = boostBind(CSapperLv::create, _1); 
			_creator_map[InstrumentLv] = boostBind(CInstrumentLv::create, _1); 
			_creator_map[AdviserLv] = boostBind(CAdviserLv::create, _1); 
			_creator_map[AssistLv] = boostBind(CAssistLv::create, _1); 
			_creator_map[DwellingsLvSum] = boostBind(CDwellingsLvSum::create, _1); 
			_creator_map[CroplandLvSum] = boostBind(CCroplandLvSum::create, _1); 
			_creator_map[MineLvSum] = boostBind(CMineLvSum::create, _1); 
			_creator_map[WoodFarmLvSum] = boostBind(CWoodFarmLvSum::create, _1); 
			_creator_map[FiefNum] = boostBind(CFiefNum::create, _1); 
			_creator_map[SearchTimes] = boostBind(CSearchTimes::create, _1); 
			_creator_map[SearchPaperNum] = boostBind(CSearchPaperNum::create, _1); 
			_creator_map[SearchPaperNumOfColor] = boostBind(CSearchPaperNumOfColor::create, _1); 
			_creator_map[MilitaryTechLvSum] = boostBind(CMilitaryTechLvSum::create, _1); 
			_creator_map[WarTechLvSum] = boostBind(CWarTechLvSum::create, _1); 
			_creator_map[HomeTechLvSum] = boostBind(CHomeTechLvSum::create, _1); 
			_creator_map[FormationTechLvSum] = boostBind(CFormationTechLvSum::create, _1); 
			_creator_map[MarketTimes] = boostBind(CMarketTimes::create, _1); 
			_creator_map[MarketSilverTimes] = boostBind(CMarketSilverTimes::create, _1); 
			_creator_map[MarketIronTimes] = boostBind(CMarketIronTimes::create, _1); 
			_creator_map[MarketFoodTimes] = boostBind(CMarketFoodTimes::create, _1); 
			_creator_map[MarketWoodTimes] = boostBind(CMarketWoodTimes::create, _1); 
			_creator_map[MarketSilverNum] = boostBind(CMarketSilverNum::create, _1); 
			_creator_map[MarketIronNum] = boostBind(CMarketIronNum::create, _1); 
			_creator_map[MarketFoodNum] = boostBind(CMarketFoodNum::create, _1); 
			_creator_map[MarketWoodNum] = boostBind(CMarketWoodNum::create, _1); 
			_creator_map[AppointManNum] = boostBind(CAppointManNum::create, _1); 
			_creator_map[MilitaryRank] = boostBind(CMilitaryRank::create, _1); 
			_creator_map[KingdomSkillLvSum] = boostBind(CKingdomSkillLvSum::create, _1); 
			_creator_map[KingdomUpSkillTimes] = boostBind(CKingdomUpSkillTimes::create, _1); 
			_creator_map[KingdomShopTimes] = boostBind(CKingdomShopTimes::create, _1); 
			_creator_map[KingdomShopFlushTimes] = boostBind(CKingdomShopFlushTimes::create, _1); 
			_creator_map[KingTitleTimes] = boostBind(CKingTitleTimes::create, _1); 
			_creator_map[KingdomContributeTimes] = boostBind(CKingdomContributeTimes::create, _1); 
			_creator_map[KingdomContributeNum] = boostBind(CKingdomContributeNum::create, _1); 
			_creator_map[KingdomLv] = boostBind(CKingdomLv::create, _1); 
			_creator_map[KingdomFoodLv] = boostBind(CKingdomFoodLv::create, _1); 
			_creator_map[KingdomSilverLv] = boostBind(CKingdomSilverLv::create, _1); 
			_creator_map[KingdomWoodLv] = boostBind(CKingdomWoodLv::create, _1); 
			_creator_map[KingdomIronLv] = boostBind(CKingdomIronLv::create, _1); 
			_creator_map[KingdomFameLv] = boostBind(CKingdomFameLv::create, _1); 
			_creator_map[CardTotalNum] = boostBind(CCardTotalNum::create, _1);
			_creator_map[CardInvestNum] = boostBind(CCardInvestNum::create, _1);
			_creator_map[CardLotteryTimes] = boostBind(CCardLotteryTimes::create, _1);
			_creator_map[CardMaxLv] = boostBind(CCardMaxLv::create, _1);
			_creator_map[CardGroupNum] = boostBind(CCardGroupNum::create, _1);
			_creator_map[CardUpFit] = boostBind(CCardUpFit::create, _1);
			_creator_map[CardUpSilver] = boostBind(CCardUpSilver::create, _1);
			_creator_map[CardUpGold] = boostBind(CCardUpGold::create, _1);
			_creator_map[WorldBossDamage] = boostBind(CWorldBossDamage::create, _1); 
			_creator_map[WorldBossIncentTimes] = boostBind(CWorldBossIncentTimes::create, _1); 
			_creator_map[WorldBossKingdomIncentTimes] = boostBind(CWorldBossKingdomIncentTimes::create, _1); 
			_creator_map[WorldBossLastShotTimes] = boostBind(CWorldBossLastShotTimes::create, _1); 
			_creator_map[KingdomWarWinTimes] = boostBind(CKingdomWarWinTimes::create, _1);
			_creator_map[GetExploitNum] = boostBind(CGetExploitNum::create, _1);
			_creator_map[KingdomWarUseFoodNum] = boostBind(CKingdomWarUseFoodNum::create, _1);
			_creator_map[MallTimes] = boostBind(CMallTimes::create, _1); 
			_creator_map[MallConsumeNum] = boostBind(CMallConsumeNum::create, _1);
			_creator_map[SignDayNum] = boostBind(CSignDayNum::create, _1); 
			_creator_map[WarMapStar] = boostBind(CWarMapStar::create, _1); 
			_creator_map[ResolveTargetNum] = boostBind(CResolveTargetNum::create, _1);
			_creator_map[MilitaryTechMaxLv] = boostBind(CMilitaryTechMaxLv::create, _1); 
			_creator_map[WarTechNum] = boostBind(CWarTechNum::create, _1); 
			_creator_map[HomeTechNum] = boostBind(CHomeTechNum::create, _1);
			_creator_map[FormationTechNum] = boostBind(CFormationTechNum::create, _1); 
			_creator_map[RescueTimes] = boostBind(CRescueTimes::create, _1); 
			_creator_map[OfficialLv] = boostBind(COfficialLv::create, _1); 
			_creator_map[ManSpecified] = boostBind(CManSpecified::create, _1); 
			_creator_map[EquipMaxLv] = boostBind(CEquipMaxLv::create, _1); 
			_creator_map[BusinessTimes] = boostBind(CBusinessTimes::create, _1); 
			_creator_map[InlayGemOfLv] = boostBind(CInlayGemOfLv::create, _1); 
			_creator_map[ChangeFace] = boostBind(CChangeFace::create, _1); 
			_creator_map[AffairsAllTimes] = boostBind(CAffairsAllTimes::create, _1); 
			_creator_map[AffairsTimes] = boostBind(CAffairsTimes::create, _1); 
			_creator_map[SpeedUpTimes] = boostBind(CSpeedUpTimes::create, _1); 
			_creator_map[DwellingsLv] = boostBind(CDwellingsLv::create, _1); 
			_creator_map[CroplandLv] = boostBind(CCroplandLv::create, _1); 
			_creator_map[MineLv] = boostBind(CMineLv::create, _1); 
			_creator_map[WoodFarmLv] = boostBind(CWoodFarmLv::create, _1); 
			_creator_map[NewProgress] = boostBind(CNewProgress::create, _1);
			_creator_map[KingdomWarSiegeAllTimes] = boostBind(CKingdomWarSiegeAllTimes::create, _1);
			_creator_map[EnterKingdomWar] = boostBind(CEnterKingdomWar::create, _1);
			_creator_map[KingdomContributeAllTimes] = boostBind(CKingdomContributeAllTimes::create, _1);
			_creator_map[BusinessAllTimes] = boostBind(CBusinessAllTimes::create, _1);
			_creator_map[XiaKouDwellingUpAllTimes] = boostBind(CXiaKouDwellingUpAllTimes::create, _1);
			_creator_map[PatrolThrowAllTimes] = boostBind(CPatrolThrowAllTimes::create, _1);
			_creator_map[AdvanceAllTimes] = boostBind(CAdvanceAllTimes::create, _1);
			_creator_map[ForgeAllTimes] = boostBind(CForgeAllTimes::create, _1);
			_creator_map[FirstExpedition] = boostBind(CFirstExpedition::create, _1);
			_creator_map[AttriColorNum] = boostBind(CAttriColorNum::create, _1);
			_creator_map[NormalSearchTimes] = boostBind(CNormalSearchTimes::create, _1);
			_creator_map[HighSearchTimes] = boostBind(CHighSearchTimes::create, _1);
			_creator_map[MaxTrainNum] = boostBind(CMaxTrainNum::create, _1);
			_creator_map[MilitaryTechLv] = boostBind(CMilitaryTechLv::create, _1);
			_creator_map[BarracksLvSum] = boostBind(CBarracksLvSum::create, _1);
			_creator_map[BusinessBattleTimes] = boostBind(CBusinessBattleTimes::create, _1);
			_creator_map[BusinessWinTimes] = boostBind(CBusinessWinTimes::create, _1);
			_creator_map[BusinessOpenBoxTimes] = boostBind(CBusinessOpenBoxTimes::create, _1);
			_creator_map[ShopDealTimes] = boostBind(CShopDealTimes::create, _1);
			_creator_map[ShopFlushTimes] = boostBind(CShopFlushTimes::create, _1);
			_creator_map[ZhuChengResourceBuildingLvSum] = boostBind(CZhuChengResourceBuildingLvSum::create, _1);
			_creator_map[KingdomWarShadowNpc] = boostBind(CKingdomWarShadowNpc::create, _1);
			_creator_map[KingdomWarShadowAdvancedNpc] = boostBind(CKingdomWarShadowAdvancedNpc::create, _1);
			_creator_map[KingdomWarShadowPlayer] = boostBind(CKingdomWarShadowPlayer::create, _1);
			_creator_map[ExpeditionChapterTimes] = boostBind(CExpeditionChapterTimes::create, _1);
			_creator_map[ZhuChengAllHarvestAllTimes] = boostBind(CZhuChengAllHarvestAllTimes::create, _1);
			_creator_map[StrengthenAllTimes] = boostBind(CStrengthenAllTimes::create, _1);
			_creator_map[DailyAllPoints] = boostBind(CDailyAllPoints::create, _1);
			_creator_map[NormalSearchAllTimes] = boostBind(CNormalSearchAllTimes::create, _1);
			_creator_map[HighSearchAllTimes] = boostBind(CHighSearchAllTimes::create, _1);
			_creator_map[HeroPartyEveryRank] = boostBind(CHeroPartyEveryRank::create, _1);
			_creator_map[WarLordsBeatHigherBV] = boostBind(CWarLordsBeatHigherBV::create, _1);
			_creator_map[KingdomWarWinAllTimes] = boostBind(CKingdomWarWinAllTimes::create, _1);
			_creator_map[TeamWarAllTimes] = boostBind(CTeamWarAllTimes::create, _1);
			_creator_map[TeamWarChapterWinTimes] = boostBind(CTeamWarChapterWinTimes::create, _1);
			_creator_map[KingdomTitleTimes] = boostBind(CKingdomTitleTimes::create, _1);
			_creator_map[FestivalGetGoldNum] = boostBind(CFestivalGetGoldNum::create, _1);
			_creator_map[FestivalThrowEggTimes] = boostBind(CFestivalThrowEggTimes::create, _1);
			_creator_map[FestivalExchangeTimes] = boostBind(CFestivalExchangeTimes::create, _1);
			_creator_map[BusinessTicketValueTimes] = boostBind(CBusinessTicketValueTimes::create, _1);
			_creator_map[HighWashTimes2] = boostBind(CHighWashTimes2::create, _1);
			_creator_map[CardLotteryTimes2] = boostBind(CCardLotteryTimes2::create, _1);
			_creator_map[HurtTrainNum] = boostBind(CHurtTrainNum::create, _1);
			_creator_map[FriendUpgradeTimes] = boostBind(CFriendUpgradeTimes::create, _1);
			_creator_map[FriendItemCostNum] = boostBind(CFriendItemCostNum::create, _1);
		}

		CheckPtr Checker::create(const Json::Value& info)
		{
			int type = info["ty"].asInt();
			if (type <= Empty || type >= TypeMax)
				return _creator_map[Empty](info);

			return _creator_map[type](info);
		}

		int ICheck::run(playerDataPtr d, int& value, int action, int arg1, int arg2)
		{
			return Running;
		}

		int CVip::run(playerDataPtr d, int& value, int action, int arg1, int arg2)
		{
			value = d->Info().VipLv();
			return getResult(value);
		}

		int CLv::run(playerDataPtr d, int& value, int action, int arg1, int arg2)
		{
			value = d->LV();
			return getResult(value);
		}

		int CPower::run(playerDataPtr d, int& value, int action, int arg1, int arg2)
		{
			if (action == Init)
				value = 0;
			int tmp = d->WarFM().currentBV();
			if (value < tmp)
				value = tmp;
			return getResult(value);
		}

		int CWarCharpter::run(playerDataPtr d, int& value, int action, int arg1, int arg2)
		{
			if (action == Init)
				value = 0;
			if (d->War().lastWinMap() >= _args[0u])
				value = 1;
			return value > 0? Finished : Running;
		}

		int CWarStarSum::run(playerDataPtr d, int& value, int action, int arg1, int arg2)
		{
			if (action == Init)
				value = d->War().getStarSum();
			else if (action == Update)
				value += arg1;
			return getResult(value);
		}

		int CEquipNumOfColor::run(playerDataPtr d, int& value, int action, int arg1, int arg2)
		{
			if (_args.size() != 2)
			{
				LogE << "args size error: EquipNumOfColor" << LogEnd;
				return Running;
			}

			value = d->Items().getEquipNumOfColor(_args[1u]);
			return getResult(value);
		}

		int CForgeNumOfColor::run(playerDataPtr d, int& value, int action, int arg1, int arg2)
		{
			if (_args.size() != 2)
			{
				LogE << "args size error: ForgeNumOfColor" << LogEnd;
				return Running;
			}
			if (action == Init)
				value = 0;
			else if (action == Update)
			{
				if (arg1 == _args[1u])
					++value;
			}
			return getResult(value);
		}

		int CManNum::run(playerDataPtr d, int& value, int action, int arg1, int arg2)
		{
			value = d->Man().getManCount();
			return getResult(value);
		}

		int CManNumOfColor::run(playerDataPtr d, int& value, int action, int arg1, int arg2)
		{
			if (_args.size() != 2)
			{
				LogE << "args size error: ManNumOfColor" << LogEnd;
				return Running;
			}
			value = d->Man().getManCountByQuality(_args[1u]);
			return getResult(value);
		}

		int CManMaxLv::run(playerDataPtr d, int& value, int action, int arg1, int arg2)
		{
			value = d->Man().getManMaxLv();
			return getResult(value);
		}

		int CGemStoneNumOfLv::run(playerDataPtr d, int& value, int action, int arg1, int arg2)
		{
			if (_args.size() != 2)
			{
				LogE << "args size error: GemStoneNumOfLv" << LogEnd;
				return Running;
			}
			value = d->Items().getGemNumOfLv(_args[1u]);
			return getResult(value);
		}

		int CWarLordsGetTitle::run(playerDataPtr d, int& value, int action, int arg1, int arg2)
		{
			if (action == Init)
				value = 0;
			if (d->Info().Nation() == Kingdom::null)
				return Running;
			for (unsigned i = 0; i < Kingdom::nation_num; ++i)
			{
				if (d->Info().Nation() == i)
					continue;
				if (d->WarLords().getTitle(i) == _args[0u])
					++value;
			}
			return value > 0? Finished : Running;
		}

		int CHeroPartyRank::run(playerDataPtr d, int& value, int action, int arg1, int arg2)
		{
			if (action == Init)
				value = 0;
			else if (action == Update)
			{
				if (arg1 <= _args[0u])
					++value;
			}
			return value > 0? Finished : Running;
		}
	
		int CInfantryLv::run(playerDataPtr d, int& value, int action, int arg1, int arg2)
		{
			if (action == Init)
				value = d->Builds().getBuildLv(LAND::idx_building_type_infantry);
			else if (action == Update)
			{
				if (value < arg1)
					value = arg1;
			}
			return getResult(value);
		}

		int CSowarLv::run(playerDataPtr d, int& value, int action, int arg1, int arg2)
		{
			if (action == Init)
				value = d->Builds().getBuildLv(LAND::idx_building_type_sowar);
			else if (action == Update)
			{
				if (value < arg1)
					value = arg1;
			}
			return getResult(value);
		}

		int CSapperLv::run(playerDataPtr d, int& value, int action, int arg1, int arg2)
		{
			if (action == Init)
				value = d->Builds().getBuildLv(LAND::idx_building_type_sapper);
			else if (action == Update)
			{
				if (value < arg1)
					value = arg1;
			}
			return getResult(value);
		}

		int CInstrumentLv::run(playerDataPtr d, int& value, int action, int arg1, int arg2)
		{
			if (action == Init)
				value = d->Builds().getBuildLv(LAND::idx_building_type_instrument);
			else if (action == Update)
			{
				if (value < arg1)
					value = arg1;
			}
			return getResult(value);
		}

		int CAdviserLv::run(playerDataPtr d, int& value, int action, int arg1, int arg2)
		{
			if (action == Init)
				value = d->Builds().getBuildLv(LAND::idx_building_type_adviser);
			else if (action == Update)
			{
				if (value < arg1)
					value = arg1;
			}
			return getResult(value);
		}

		int CAssistLv::run(playerDataPtr d, int& value, int action, int arg1, int arg2)
		{
			if (action == Init)
				value = d->Builds().getBuildLv(LAND::idx_building_type_assist);
			else if (action == Update)
			{
				if (value < arg1)
					value = arg1;
			}
			return getResult(value);
		}

		int CDwellingsLvSum::run(playerDataPtr d, int& value, int action, int arg1, int arg2)
		{
			value = d->Builds().getBuildLvSum(LAND::idx_building_type_dwellings);
			return getResult(value);
		}

		int CCroplandLvSum::run(playerDataPtr d, int& value, int action, int arg1, int arg2)
		{
			value = d->Builds().getBuildLvSum(LAND::idx_building_type_cropland);
			return getResult(value);
		}

		int CMineLvSum::run(playerDataPtr d, int& value, int action, int arg1, int arg2)
		{
			value = d->Builds().getBuildLvSum(LAND::idx_building_type_mine);
			return getResult(value);
		}

		int CWoodFarmLvSum::run(playerDataPtr d, int& value, int action, int arg1, int arg2)
		{
			value = d->Builds().getBuildLvSum(LAND::idx_building_type_wood);
			return getResult(value);
		}

		int CFiefNum::run(playerDataPtr d, int& value, int action, int arg1, int arg2)
		{
			value = d->Builds().getFeodNum();	
			return getResult(value);
		}

		int CMilitaryTechLvSum::run(playerDataPtr d, int& value, int action, int arg1, int arg2)
		{
			value = d->Research().getLvSum();
			return getResult(value);
		}

		int CWarTechLvSum::run(playerDataPtr d, int& value, int action, int arg1, int arg2)
		{
			value = d->Research().getLvSum(LAND::idx_tech_type_war);
			return getResult(value);
		}

		int CHomeTechLvSum::run(playerDataPtr d, int& value, int action, int arg1, int arg2)
		{
			value = d->Research().getLvSum(LAND::idx_tech_type_home);
			return getResult(value);
		}

		int CFormationTechLvSum::run(playerDataPtr d, int& value, int action, int arg1, int arg2)
		{
			value = d->Research().getLvSum(LAND::idx_tech_type_formation);
			return getResult(value);
		}

		int CWarMapStar::run(playerDataPtr d, int& value, int action, int arg1, int arg2)
		{
			if (_args.size() != 2)
			{
				LogE << "args size error: WarMapStar" << LogEnd;
				return Running;
			}
			if (action == Init)
			{
				SelfMapDataPtr ptr = d->War().getMapData(_args[1u]);
				if (ptr)
					value = ptr->starNum;
				else
					value = 0;
			}
			else if (action == Update)
			{
				if (arg1 == _args[1u] && value < arg2)
					value = arg2;
			}
			return getResult(value);
		}

		int CMilitaryTechMaxLv::run(playerDataPtr d, int& value, int action, int arg1, int arg2)
		{
			value = d->Research().getMaxLv();
			return getResult(value);
		}

		int CWarTechNum::run(playerDataPtr d, int& value, int action, int arg1, int arg2)
		{
			value = d->Research().getTechNum(LAND::idx_tech_type_war);
			return getResult(value);
		}

		int CHomeTechNum::run(playerDataPtr d, int& value, int action, int arg1, int arg2)
		{
			value = d->Research().getTechNum(LAND::idx_tech_type_home);
			return getResult(value);
		}

		int CFormationTechNum::run(playerDataPtr d, int& value, int action, int arg1, int arg2)
		{
			value = d->Research().getTechNum(LAND::idx_tech_type_formation);
			return getResult(value);
		}

		int CEquipMaxLv::run(playerDataPtr d, int& value, int action, int arg1, int arg2)
		{
			if (action == Init)
				value = d->Items().getMaxEquipLv();
			else if (action == Update)
			{
				if (arg1 == 0)
				{
					if (value <= arg2)
						value = d->Items().getMaxEquipLv();
				}
				else
				{
					if (value < arg2)
						value = arg2;
				}
			}
			return getResult(value);
		}

		int CKingdomSkillLvSum::run(playerDataPtr d, int& value, int action, int arg1, int arg2)
		{
			value = d->KingDom().getSkillLvSum();
			return getResult(value);
		}

		int CSignDayNum::run(playerDataPtr d, int& value, int action, int arg1, int arg2)
		{
			if (action == Init)
				value = d->Sign().signedToday()? 1 : 0;
			else if (action == Update)
				++value;
			return getResult(value);
		}

		int CResolveTargetNum::run(playerDataPtr d, int& value, int action, int arg1, int arg2)
		{
			if (action == Init)
				value = 0;
			else if (action == Update)
			{
				if (arg1 >= _args[0u])
					++value;
			}
			return value > 0? Finished : Running;
		}

 		int COfficialLv::run(playerDataPtr d, int& value, int action, int arg1, int arg2)
 		{
			return Finished;
 		}

		int CManSpecified::run(playerDataPtr d, int& value, int action, int arg1, int arg2)
		{
			if (action == Init)
				value = 0;
			if (d->Man().findManRaw(_args[0u] / 100))
				++value;
			return value > 0? Finished : Running;
		}

		int CInlayGemOfLv::run(playerDataPtr d, int& value, int action, int arg1, int arg2)
		{
			if (_args.size() != 2)
			{
				LogE << "args size error: InlayGemOfLv" << LogEnd;
				return Running;
			}
			value = d->Items().getOnGemNumOfLv(_args[1u]);
			return getResult(value);
		}
		
 		int CMilitaryRank::run(playerDataPtr d, int& value, int action, int arg1, int arg2)
 		{
			return Finished;
 		}

		int CAppointManNum::run(playerDataPtr d, int& value, int action, int arg1, int arg2)
		{
			if (action == Init)
				value = 0;
			int tmp = d->Admin().getUseManNum();
			if (value < tmp)
				value = tmp;
			return getResult(value);
		}

		int CSearchPaperNumOfColor::run(playerDataPtr d, int& value, int action, int arg1, int arg2)
		{
			if (action == Init)
				value = 0;
			else if (action == Update)
			{
				if (arg1 == _args[1u])
					value += arg2;
			}
			return getResult(value);
		}

		int CAffairsAllTimes::run(playerDataPtr d, int& value, int action, int arg1, int arg2)
		{
			value = d->Affair().getAllTimes();
			return getResult(value);
		}

		int CDwellingsLv::run(playerDataPtr d, int& value, int action, int arg1, int arg2)
		{
			if (action == Init)
				value = d->Builds().getBuildLv(LAND::idx_building_type_dwellings);
			else if (action == Update)
			{
				if (value < arg1)
					value = arg1;
			}
			return getResult(value);
					
		}

		int CCroplandLv::run(playerDataPtr d, int& value, int action, int arg1, int arg2)
		{
			if (action == Init)
				value = d->Builds().getBuildLv(LAND::idx_building_type_cropland);
			else if (action == Update)
			{
				if (value < arg1)
					value = arg1;
			}
			return getResult(value);
					
		}

		int CMineLv::run(playerDataPtr d, int& value, int action, int arg1, int arg2)
		{
			if (action == Init)
				value = d->Builds().getBuildLv(LAND::idx_building_type_mine);
			else if (action == Update)
			{
				if (value < arg1)
					value = arg1;
			}
			return getResult(value);
		}

		int CWoodFarmLv::run(playerDataPtr d, int& value, int action, int arg1, int arg2)
		{
			if (action == Init)
				value = d->Builds().getBuildLv(LAND::idx_building_type_wood);
			else if (action == Update)
			{
				if (value < arg1)
					value = arg1;
			}
			return getResult(value);
		}

		int CNewProgress::run(playerDataPtr d, int& value, int action, int arg1, int arg2)
		{
			if (_args.size() != 2)
			{
				LogE << "args size error: CNewProgress" << LogEnd;
				return Running;
			}
			if (action == Init)
				value = 0;
			else if (action == Update)
			{
				if (arg1 == _args[0u])
					++value;
			}
			return getResult(value);
		}

		int CCardInvestNum::run(playerDataPtr d, int& value, int action, int arg1, int arg2)
		{
			if (action == Init)
				value = d->Card().fmSize();
			else if (action == Update)
			{
				if (value < d->Card().fmSize())
					value = d->Card().fmSize();
			}
			return getResult(value);
		}

		int CCardLotteryTimes::run(playerDataPtr d, int& value, int action, int arg1, int arg2)
		{
			value = d->CardTs().totalLotteryTimes();
			return getResult(value);
		}

		int CKingdomWarSiegeAllTimes::run(playerDataPtr d, int& value, int action, int arg1, int arg2)
		{
			value = d->KingDomWar().siegeTimes();
			return getResult(value);
		}

		int CEnterKingdomWar::run(playerDataPtr d, int& value, int action, int arg1, int arg2)
		{
			if (action == Init)
				value = 0;
			else if (action == Update)
				++value;
			return getResult(value);
		}

		int CKingdomContributeAllTimes::run(playerDataPtr d, int& value, int action, int arg1, int arg2)
		{
			value = d->KingDom().allConTimes();
			return getResult(value);
		}

		int CBusinessAllTimes::run(playerDataPtr d, int& value, int action, int arg1, int arg2)
		{
			value = d->Trade().totalTask();
			return getResult(value);
		}

		int CXiaKouDwellingUpAllTimes::run(playerDataPtr d, int& value, int action, int arg1, int arg2)
		{
			value = d->BuildTeam().xiaKouDwellingUpTimes();
			return getResult(value);
		}

		int CPatrolThrowAllTimes::run(playerDataPtr d, int& value, int action, int arg1, int arg2)
		{
			value = d->Patrol().getTotalThrowTime();
			return getResult(value);
		}

		int CAdvanceAllTimes::run(playerDataPtr d, int& value, int action, int arg1, int arg2)
		{
			value = d->Man().starUpTimes();
			return getResult(value);
		}

		int CForgeAllTimes::run(playerDataPtr d, int& value, int action, int arg1, int arg2)
		{
			value = d->Items().equipBuildTimes();
			return getResult(value);
		}

		int CCardTotalNum::run(playerDataPtr d, int& value, int action, int arg1, int arg2)
		{
			value = d->Card().Size();
			return getResult(value);
		}

		int CCardMaxLv::run(playerDataPtr d, int& value, int action, int arg1, int arg2)
		{
			value = d->Card().cardMaxLv();
			return getResult(value);
		}

		int CCardGroupNum::run(playerDataPtr d, int& value, int action, int arg1, int arg2)
		{
			value = d->Card().groupNum();
			return getResult(value);
		}

		int CAttriColorNum::run(playerDataPtr d, int& value, int action, int arg1, int arg2)
		{
			if (action == Init)
				value = 0;
			else if (action == Update)
			{
				if (arg1 >= _args[1u])
					++value;
			}
			return getResult(value);
		}

		int CMaxTrainNum::run(playerDataPtr d, int& value, int action, int arg1, int arg2)
		{
			value = d->Man().getMaxTrainManNum();
			return getResult(value);
		}

		int CMilitaryTechLv::run(playerDataPtr d, int& value, int action, int arg1, int arg2)
		{
			if (action == Init)
				value = d->Research().getForLV(_args[1u]);
			else if (action == Update)
			{
				if (arg1 == _args[1u])
					value = d->Research().getForLV(_args[1u]);
			}
			return getResult(value);
		}

		int CHighWashTimes::run(playerDataPtr d, int& value, int action, int arg1, int arg2)
		{
			value = d->Items().highWashTimes();
			return getResult(value);
		}

		int CBarracksLvSum::run(playerDataPtr d, int& value, int action, int arg1, int arg2)
		{
			value = d->Builds().getBarracksLvSum();
			return getResult(value);
		}

		int CZhuChengResourceBuildingLvSum::run(playerDataPtr d, int& value, int action, int arg1, int arg2)
		{
			value = d->Builds().getZCResBuildingLvSum();
			return getResult(value);
		}

		int CExpeditionChapterTimes::run(playerDataPtr d, int& value, int action, int arg1, int arg2)
		{
			if (action == Init)
				value = d->Expedition().curPos() >= _args[1u]? 1 : 0;
			else if (action == Update)
			{
				if (arg1 == _args[1u])
					value += arg2;
			}
			return getResult(value);
		}

		int CZhuChengAllHarvestAllTimes::run(playerDataPtr d, int& value, int action, int arg1, int arg2)
		{
			value = d->Builds().ZCAHAllTimes();
			return getResult(value);
		}

		int CStrengthenAllTimes::run(playerDataPtr d, int& value, int action, int arg1, int arg2)
		{
			value = d->Items().equipStrengthenTimes();
			return getResult(value);
		}

		int CDailyAllPoints::run(playerDataPtr d, int& value, int action, int arg1, int arg2)
		{
			value = d->Daily().AllPoints();
			return getResult(value);
		}

		int CNormalSearchAllTimes::run(playerDataPtr d, int& value, int action, int arg1, int arg2)
		{
			value = d->Sch().normalSearchTimes();
			return getResult(value);
		}

		int CHighSearchAllTimes::run(playerDataPtr d, int& value, int action, int arg1, int arg2)
		{
			value = d->Sch().highSearchTimes();
			return getResult(value);
		}

		int CHeroPartyEveryRank::run(playerDataPtr d, int& value, int action, int arg1, int arg2)
		{
			int rk = heroparty_sys.getRankNo_(d->ID());
			if (rk != -1 && rk <= _args[0u])
				return Finished;
			else
				return Running;
		}

		int CKingdomWarWinAllTimes::run(playerDataPtr d, int& value, int action, int arg1, int arg2)
		{
			value = d->KingDomWar().winTimes();
			return getResult(value);
		}

		int CTeamWarAllTimes::run(playerDataPtr d, int& value, int action, int arg1, int arg2)
		{
			value = d->Team().allTimes();
			return getResult(value);
		}

		int CTeamWarChapterWinTimes::run(playerDataPtr d, int& value, int action, int arg1, int arg2)
		{
			if (action == Init)
				value = 0;
			else if (action == Update)
			{
				if (arg1 == _args[1u])
					++value;
			}
			return getResult(value);
		}

		int CKingdomTitleTimes::run(playerDataPtr d, int& value, int action, int arg1, int arg2)
		{
			if (action == Init)
			{
				int title = d->KingFight().getTitle();
				if (title <= _args[1u])
					value = 1;
				else
					value = 0;
			}
			else if (action == Update)
			{
				int title = d->KingFight().getTitle();
				if (title <= _args[1u])
					++value;
			}
			return getResult(value);
		}

		int CBusinessTicketValueTimes::run(playerDataPtr d, int& value, int action, int arg1, int arg2)
		{
			if (action == Init)
				value = 0;
			else if (action == Update)
			{
				if (arg1 >= _args[1u])
					++value;
			}
			return getResult(value);
		}

		int CHurtTrainNum::run(playerDataPtr d, int& value, int action, int arg1, int arg2)
		{
			value = d->Man().getHurtTrainManNum(_args[1u]);
			return getResult(value);
		}
	}
}

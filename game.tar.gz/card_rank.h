//###################################
//create by Jim
//2016-11-07
//###################################

#pragma once

#include "dbDriver.h"

#define card_rank (*gg::CardRank::_Instance)

namespace gg
{
	namespace NSCardRank
	{
		struct Rankey
		{
			Rankey()
			{
				playerID = -1;
				cardQua = 4;
				cardLV = 0;
				cardEXP = 0;
				cardID = 0x7FFFFFFF;
			}
			Rankey(playerDataPtr player)
			{
				playerID = player->ID();
				const playerCardMgr::CardMx& mx = player->Card().getMax();
				cardQua = mx.cardQua;
				cardLV = mx.cardLV;
				cardEXP = mx.cardEXP;
				cardID = mx.cardID;
			}
			bool operator<(const Rankey& other)const
			{
				if (cardQua != other.cardQua)return cardQua > other.cardQua;
				if (cardLV != other.cardLV)return cardLV > other.cardLV;
				if (cardEXP != other.cardEXP)return cardEXP > other.cardEXP;
				if (cardID != other.cardID)return cardID < other.cardID;
				return playerID < other.playerID;
			}
			bool operator>(const Rankey& other)const
			{
				return *this < other;
			}
			inline bool nullData()const
			{
				return cardID == 0x7FFFFFFF;
			}
			int playerID;
			int cardID;
			int cardQua;
			unsigned cardLV;
			unsigned cardEXP;
		};

		struct RankData
		{
			Rankey Key()
			{
				Rankey key;
				key.playerID = playerID;
				key.cardQua = cardQua;
				key.cardLV = cardLV;
				key.cardEXP = cardEXP;
				key.cardID = cardID;
				return key;
			}
			RankData()
			{
				playerID = -1;
				playerName = "";
				cardQua = 4;
				cardLV = 0;
				cardEXP = 0;
				cardID = 0x7FFFFFFF;
				rankNo = 0;
			}
			RankData(playerDataPtr player)
			{
				setNewData(player);
				rankNo = 0;
			}
			void setNewData(playerDataPtr player)
			{
				playerID = player->ID();
				playerName = player->Name();
				playerNation = player->Info().Nation();
				const playerCardMgr::CardMx& mx = player->Card().getMax();
				cardQua = mx.cardQua;
				cardLV = mx.cardLV;
				cardEXP = mx.cardEXP;
				cardID = mx.cardID;
			}
			inline bool isNull()const
			{
				return cardID == 0x7FFFFFFF;
			}
			int playerID;
			string playerName;
			int playerNation;
			int cardID;
			int cardQua;
			unsigned cardLV;
			unsigned cardEXP;
			int rankNo;
		};

		BOOSTSHAREPTR(RankData, ptrRankData);

		STDMAP(Rankey, ptrRankData, RankMap);
		STDMAP(int, ptrRankData, PlayerMap);
	}

	class CardRank
	{
	public:
		CardRank() { isInitial = false; }
		static CardRank* const _Instance;
		void initData();
		DeclareRegFunction(RankList);
		DeclareRegFunction(CardDetail);
	public:
		void updatePlayer(playerDataPtr player);
	private:
		NSCardRank::ptrRankData getData(const int playerID);
		int getRank(const int playerID);

		NSCardRank::RankMap Rank;
		NSCardRank::PlayerMap Player;

		bool isInitial;
	};
}

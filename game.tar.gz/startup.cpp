#include "game_handle.h"
#include "gate_game_protocol.h"
#include "game_server.h"
#include "common_protocol.h"

//game system
#include "gm_tools.h"
#include "game_time.h"
#include "man_system.h"
#include "gamer.h"
#include "item_system.h"
#include "skill.h"
#include "battle_system.h"
#include "ownerland_system.h"
#include "map_war.h"
#include "task_system.h"
#include "card_system.h"
#include "search_system.h"
#include "action_system.h"
#include "chat.h"
#include "business.h"
#include "heroparty_system.h"
#include "kingfight_system.h"
#include "rescue_system.h"
#include "team_war.h"
#include "kingdom_system.h"
#include "vip_system.h"
#include "worldboss_system.h"
#include "team_war.h"
#include "compensate.h"
#include "mall_system.h"
#include "warlords_system.h"
#include "email_system.h"
#include "daily_task.h"
#include "days_activity_system.h"
#include "despatch_task.h"
#include "net_helper.hpp"
#include "money_activity.h"
#include "sign_system.h"
#include "fund_system.h"
#include "kingdomwar_system.h"
#include "kingdomwar_shop.h"
#include "patrol_system.h"
#include "open_activity_system.h"

using namespace gate_client;
using namespace game_protocol::comomon;
namespace gg
{
#define RegisterFunction(REQ_PROTOCOL, RESP_PROTOCOL, FUNCTION) \
	{\
	f = boost::bind(&FUNCTION, system_response::respSys, _1, _2); \
	reg_func(REQ_PROTOCOL, RESP_PROTOCOL, f);\
}

#define RegisterNoResponFunction(REQ_PROTOCOL, FUNCTION) \
	{\
	f = boost::bind(&FUNCTION, system_response::respSys, _1, _2); \
	reg_func(REQ_PROTOCOL, -1, f);\
}

#define RegisterFunctionPlus(REQ_PROTOCOL, RESP_PROTOCOL, FUNCTION, POINTER) \
	{\
	f = boost::bind(&FUNCTION, POINTER, _1, _2); \
	reg_func(REQ_PROTOCOL, RESP_PROTOCOL, f);\
}

#define RegisterUpdateFunction(STATE_VALUE, FUNCTION, POINTER) \
	{\
		uf = boost::bind(&FUNCTION, POINTER, _1); \
		updateFunction func;\
		func.state_ = STATE_VALUE;\
		func.f_ = uf;\
		func_vector.push_back(func);\
	}

#define RegisterNoResponFunctionPlus(REQ_PROTOCOL, FUNCTION, POINTER) \
	{\
	f = boost::bind(&FUNCTION, POINTER, _1, _2); \
	reg_func(REQ_PROTOCOL, -1, f);\
}

	void handler::Regist()
	{
		handler_function f;
		//������ע���
		

		//gm
		//��½
		RegisterFunctionPlus(notice_player_login_req, notice_player_login_resp, Gamer::LinkLogin, Gamer::_Instance);
		//�ǳ�
		RegisterFunctionPlus(notice_player_out_req, notice_player_out_resp, Gamer::LinkLogout, Gamer::_Instance);
		//�������ȫ������
		RegisterFunctionPlus(gate_restart_req, gate_restart_resp, Gamer::GateReset, Gamer::_Instance);

		//���
		//������ɫ
		RegisterFunctionPlus(player_create_role_req, player_create_role_resp, Gamer::CreateRole, Gamer::_Instance);
		//����ҵ�¼ʱ���Ĵ���
		RegisterFunctionPlus(player_login_req, player_login_resp, Gamer::Login, Gamer::_Instance);
		//�޸�����
		RegisterFunctionPlus(player_motify_name_req, player_motify_name_resp, Gamer::motifyName, Gamer::_Instance);
		//�޸�ͷ��
		RegisterFunctionPlus(player_set_face_req, player_set_face_resp, Gamer::motifyFace, Gamer::_Instance);
		//�޸Ŀͻ��˽���������ʾ
		RegisterFunctionPlus(player_set_leader_process_req, player_set_leader_process_resp, Gamer::motifyProcess, Gamer::_Instance);
		//����ս��
		RegisterFunctionPlus(player_shared_rep_req, player_shared_rep_resp, Gamer::SharePathRep, Gamer::_Instance);
		//�㲥���Խӿ�
		RegisterFunctionPlus(player_test_annouce_req, player_test_annouce_resp, Gamer::TestAnnouce, Gamer::_Instance);
		//����������
		RegisterFunctionPlus(player_info_table_req, player_info_table_resp, Gamer::GamerTable, Gamer::_Instance);
		RegisterFunctionPlus(player_custom_list_req, player_custom_list_resp, gm_tools::updateCustomTitle, gm_tools::_Instance);
		RegisterFunctionPlus(player_custom_update_req, player_custom_update_resp, gm_tools::updateCustom, gm_tools::_Instance);
		RegisterFunctionPlus(player_get_custom_req, player_get_custom_resp, gm_tools::getCustomBox, gm_tools::_Instance);
		RegisterFunctionPlus(player_online_box_update_req, player_online_box_update_resp, Gamer::OnlineBoxUpdate, Gamer::_Instance);
		RegisterFunctionPlus(player_online_box_get_req, player_online_box_get_resp, Gamer::OnlineBoxGet, Gamer::_Instance);
		RegisterFunctionPlus(player_process_record_req, player_process_record_resp, Gamer::logProcess, Gamer::_Instance);
		RegisterFunctionPlus(player_money_activity_award_req, player_money_activity_award_resp, MoneyActivity::WonReward, MoneyActivity::_Instance);
		RegisterFunctionPlus(player_money_activity_get_title_req, player_money_activity_get_title_resp, MoneyActivity::GetTitle, MoneyActivity::_Instance);
		RegisterFunctionPlus(player_money_activity_get_detail_req, player_money_activity_get_detail_resp, MoneyActivity::GetDetail, MoneyActivity::_Instance);
		RegisterFunctionPlus(player_money_activity_update_own_req, player_money_activity_update_own_resp, MoneyActivity::UpdateOwn, MoneyActivity::_Instance);
		RegisterFunctionPlus(player_money_activity_update_red_req, player_money_activity_update_red_resp, MoneyActivity::UpdateRed, MoneyActivity::_Instance);
		RegisterFunctionPlus(player_daily_card_update_req, player_daily_card_update_resp, Gamer::DailyCardUpdate, Gamer::_Instance);
		RegisterFunctionPlus(player_daily_card_buy_req, player_daily_card_buy_resp, Gamer::DailyCardBuy, Gamer::_Instance);
		RegisterFunctionPlus(player_daily_card_award_req, player_daily_card_award_resp, Gamer::DailyCardAward, Gamer::_Instance);
		RegisterFunctionPlus(player_offday_award_req, player_offday_award_resp, Gamer::OfflineReward, Gamer::_Instance);
		RegisterFunctionPlus(seven_day_login_get_box_req, seven_day_login_get_box_resp, Gamer::LoginDayBox, Gamer::_Instance);
		//��������Ϣ
		RegisterFunctionPlus(server_info_req, server_info_resp, season::serverInfoReq, season::_Instance);
	

		//�佫ϵͳ//����
		RegisterFunctionPlus(player_man_fly_update_req, player_man_fly_update_resp, man_system::updateFlyCD, man_system::_Instance);
		RegisterFunctionPlus(player_man_fly_jg_req, player_man_fly_jg_resp, man_system::manUgJG, man_system::_Instance);
		RegisterFunctionPlus(player_man_fly_clear_req, player_man_fly_clear_resp, man_system::clearFlyCD, man_system::_Instance);
		RegisterFunctionPlus(war_format_update_req, war_format_update_resp, man_system::updateAllWarFm, man_system::_Instance);
		RegisterFunctionPlus(war_format_update_single_req, war_format_update_single_resp, man_system::updateSingleWarFm, man_system::_Instance);
		RegisterFunctionPlus(war_format_req, war_format_resp, man_system::warFmFormat, man_system::_Instance);
		RegisterFunctionPlus(war_format_default_req, war_format_default_resp, man_system::warFormatDefalut, man_system::_Instance);
		RegisterFunctionPlus(player_man_star_up_req, player_man_star_up_resp, man_system::starsUp, man_system::_Instance);
		RegisterFunctionPlus(player_man_active_attri_req, player_man_active_attri_resp, man_system::activeAttri, man_system::_Instance);
		RegisterFunctionPlus(player_man_on_equip_req, player_man_on_equip_resp, man_system::manEquip, man_system::_Instance);
		RegisterFunctionPlus(player_man_off_equip_req, player_man_off_equip_resp, man_system::manOffEquip, man_system::_Instance);
		RegisterFunctionPlus(player_man_fly_gold_req, player_man_fly_gold_resp, man_system::manUgGold, man_system::_Instance);
		RegisterFunctionPlus(player_man_fly_item_req, player_man_fly_item_resp, man_system::manUgItem, man_system::_Instance);
		RegisterFunctionPlus(player_man_train_req, player_man_train_resp, man_system::trainMan, man_system::_Instance);
		RegisterFunctionPlus(player_man_train_gold_req, player_man_train_gold_resp, man_system::trainManGold, man_system::_Instance);
		RegisterFunctionPlus(player_man_train_keep_req, player_man_train_keep_resp, man_system::trainKeep, man_system::_Instance);
		RegisterFunctionPlus(player_man_train_replace_req, player_man_train_replace_resp, man_system::trainReplace, man_system::_Instance);
		RegisterFunctionPlus(player_man_train_recover_req, player_man_train_recover_resp, man_system::trainReconver, man_system::_Instance);
		RegisterFunctionPlus(player_man_active_attri_all_req, player_man_active_attri_all_resp, man_system::activeAttriAll, man_system::_Instance);
		RegisterFunctionPlus(player_man_equip_one_key_exchange_req, player_man_equip_one_key_exchange_resp, man_system::oneKeyEquip, man_system::_Instance);

		// ���Ǻͷ��
		RegisterFunctionPlus(building_get_all_req, building_get_all_resp, ownerland_system::getBaseData, ownerland_system::_Instance);
		RegisterFunctionPlus(building_get_building_data_req, building_get_building_data_resp, ownerland_system::getOneData, ownerland_system::_Instance);
		RegisterFunctionPlus(building_upgrade_req, building_upgrade_resp, ownerland_system::buildingUpgrade, ownerland_system::_Instance);
		RegisterFunctionPlus(building_harvest_req, building_harvest_resp, ownerland_system::buildingHarvest, ownerland_system::_Instance);
		RegisterFunctionPlus(building_fast_build_req, building_fast_build_resp, ownerland_system::fastBuild, ownerland_system::_Instance);
		RegisterFunctionPlus(building_get_fast_build_req, building_get_fast_build_resp, ownerland_system::getFastBuild, ownerland_system::_Instance);
		RegisterFunctionPlus(building_buy_build_team_req, building_buy_build_team_resp, ownerland_system::buyBuildTeam, ownerland_system::_Instance);
		RegisterFunctionPlus(building_buy_action_req, building_buy_action_resp, ownerland_system::buyAction, ownerland_system::_Instance);
		RegisterFunctionPlus(building_affairs_req, building_affairs_resp, ownerland_system::setAffairs, ownerland_system::_Instance);
		RegisterFunctionPlus(building_land_appoint_req, building_land_appoint_resp, ownerland_system::landAppoint, ownerland_system::_Instance);
		RegisterFunctionPlus(building_land_not_appoint_req, building_land_not_appoint_resp, ownerland_system::landNotAppoint, ownerland_system::_Instance);
		RegisterFunctionPlus(building_land_add_time_req, building_land_add_time_resp, ownerland_system::landAddAppointTime, ownerland_system::_Instance);
		RegisterFunctionPlus(building_tech_upgrade_req, building_tech_upgrade_resp, ownerland_system::militaryTechUpgrade, ownerland_system::_Instance);
		RegisterFunctionPlus(building_market_buy_req, building_market_buy_resp, ownerland_system::marketBuyRes, ownerland_system::_Instance);
		RegisterFunctionPlus(building_free_remove_cd_req, building_free_remove_cd_resp, ownerland_system::freeRemoveBuildingCD, ownerland_system::_Instance);
		RegisterFunctionPlus(building_team_rescue_req, building_team_rescue_resp, ownerland_system::buildTeamRescue, ownerland_system::_Instance);
		RegisterFunctionPlus(building_item_fast_buid_req, building_item_fast_buid_resp, ownerland_system::itemFastBuild, ownerland_system::_Instance); 
		RegisterFunctionPlus(building_affairs_update_req, building_affairs_update_resp, ownerland_system::affairsUpdate, ownerland_system::_Instance);
		RegisterFunctionPlus(building_force_build_req, building_force_build_resp, ownerland_system::replaceBuild, ownerland_system::_Instance);
		RegisterFunctionPlus(building_set_build_state_req, building_set_build_state_resp, ownerland_system::setBuildState, ownerland_system::_Instance);

		//ս��ϵͳ
		RegisterFunctionPlus(map_war_base_req, map_war_base_resp, map_war::mapDataUpdate, map_war::_Instance);
		RegisterFunctionPlus(map_war_fight_req, map_war_fight_resp, map_war::challenge, map_war::_Instance);
		RegisterFunctionPlus(map_war_getchapter_req, map_war_getchapter_resp, map_war::getChapterReward, map_war::_Instance);
		RegisterFunctionPlus(map_war_strategy_req, map_war_strategy_resp, map_war::getMapStrategy, map_war::_Instance);
		RegisterFunctionPlus(map_war_sweep_req, map_war_sweep_resp, map_war::sweepMap, map_war::_Instance);
		RegisterFunctionPlus(map_war_flash_snap_req, map_war_flash_snap_resp, map_war::reqFlashSnap, map_war::_Instance);//�����¼���ս, ����
		RegisterFunctionPlus(map_war_re_chanllenge_req, map_war_re_chanllenge_resp, map_war::reChanllengeAcc, map_war::_Instance);

		//����ϵͳ
		RegisterFunctionPlus(task_player_info_req, task_player_info_resp, task_system::playerInfoReq, task_system::_Instance);
		RegisterFunctionPlus(task_get_reward_req, task_get_reward_resp, task_system::getRewardReq, task_system::_Instance);
		RegisterFunctionPlus(task_red_point_req, task_red_point_resp, task_system::redPointReq, task_system::_Instance);

		//��ϵͳ
		RegisterFunctionPlus(player_card_upif_req, player_card_upif_resp, card_system::ladyBase, card_system::_Instance);
		RegisterFunctionPlus(player_card_invest_req, player_card_invest_resp, card_system::ladyInvest, card_system::_Instance);
		RegisterFunctionPlus(player_card_silver_up_req, player_card_silver_up_resp, card_system::ladyUpSilver, card_system::_Instance);
		RegisterFunctionPlus(player_card_gold_up_req, player_card_gold_up_resp, card_system::ladyUpGold, card_system::_Instance);
		RegisterFunctionPlus(player_card_fit_up_req, player_card_fit_up_resp, card_system::ladyUpFit, card_system::_Instance);
		RegisterFunctionPlus(player_lady_exchange_req, player_lady_exchange_resp, card_system::ladyExchange, card_system::_Instance);
//		RegisterFunctionPlus(silver_lottery_card_req, silver_lottery_card_resp, card_system::ladyLotterySilver, card_system::_Instance);
		RegisterFunctionPlus(gold_lottery_card_req, gold_lottery_card_resp, card_system::ladyLotteryGold, card_system::_Instance);
		RegisterFunctionPlus(goldh_lottery_card_req, goldh_lottery_card_resp, card_system::ladyLotteryGoldH, card_system::_Instance);
//		RegisterFunctionPlus(silver_10_lottery_card_req, silver_10_lottery_card_resp, card_system::ladyLotterySilverM, card_system::_Instance);
		RegisterFunctionPlus(gold_10_lottery_card_req, gold_10_lottery_card_resp, card_system::ladyLotteryGoldM, card_system::_Instance);
		RegisterFunctionPlus(goldh_10_lottery_card_req, goldh_10_lottery_card_resp, card_system::ladyLotteryGoldHM, card_system::_Instance);
		RegisterFunctionPlus(player_card_poke_update_req, player_card_poke_update_resp, card_system::ladyPokeReq, card_system::_Instance);
		RegisterFunctionPlus(player_card_dismiss_req, player_card_dismiss_resp, card_system::ladyDismissReq, card_system::_Instance);
		RegisterFunctionPlus(player_card_bind_req, player_card_bind_resp, card_system::ladyBindReq, card_system::_Instance);
		RegisterFunctionPlus(player_card_combine_four_req, player_card_combine_four_resp, card_system::ladyCMB4Req, card_system::_Instance);
		RegisterFunctionPlus(player_card_combine_five_req, player_card_combine_five_resp, card_system::ladyCMB5Req, card_system::_Instance);
		RegisterFunctionPlus(player_card_show_req, player_card_show_resp, card_system::ShowLady, card_system::_Instance);
		RegisterFunctionPlus(player_card_show_invest_req, player_card_show_invest_resp, card_system::ShowLadyInvest, card_system::_Instance);
		RegisterFunctionPlus(player_patrol_throw_dice_req, player_patrol_throw_dice_resp, patrol_system1::reqPatrolThrowDice, patrol_system1::_Instance);
		RegisterFunctionPlus(player_patrol_get_curr_event_req, player_patrol_get_curr_event_resp, patrol_system1::reqPatrolGetCurrEvent, patrol_system1::_Instance);
		RegisterFunctionPlus(player_patrol_get_reward_req, player_patrol_get_reward_resp, patrol_system1::reqPatrolGetReward, patrol_system1::_Instance);
		RegisterFunctionPlus(player_patrol_info_update_req, player_patrol_info_update_resp, patrol_system1::reqPatrolInfo, patrol_system1::_Instance);
		

		//gm
		RegisterFunctionPlus(gm_get_player_base_req, gm_get_player_base_resp, gm_tools::BaseGet, gm_tools::_Instance);
		RegisterFunctionPlus(gm_get_player_res_req, gm_get_player_res_resp, gm_tools::ResGet, gm_tools::_Instance);
		RegisterFunctionPlus(gm_get_player_man_req, gm_get_player_man_resp, gm_tools::ManGet, gm_tools::_Instance);
		RegisterFunctionPlus(gm_get_player_lady_req, gm_get_player_lady_resp, gm_tools::LadyGet, gm_tools::_Instance);
		RegisterFunctionPlus(gm_get_player_item_req, gm_get_player_item_resp, gm_tools::ItemGet, gm_tools::_Instance);
		RegisterFunctionPlus(gm_motify_player_base_req, gm_motify_player_base_resp, gm_tools::BaseSet, gm_tools::_Instance);
		RegisterFunctionPlus(gm_motify_player_res_req, gm_motify_player_res_resp, gm_tools::ResSet, gm_tools::_Instance);
		RegisterFunctionPlus(gm_motify_player_man_req, gm_motify_player_man_resp, gm_tools::ManSet, gm_tools::_Instance);
		RegisterFunctionPlus(gm_motify_player_lady_req, gm_motify_player_lady_resp, gm_tools::LadySet, gm_tools::_Instance);
		RegisterFunctionPlus(gm_motify_player_item_req, gm_motify_player_item_resp, gm_tools::ItemSet, gm_tools::_Instance);
		RegisterFunctionPlus(gm_set_time_dev_req, gm_set_time_dev_resp, gm_tools::TimeSet, gm_tools::_Instance);
		RegisterFunctionPlus(gm_get_time_dev_req, gm_get_time_dev_resp, gm_tools::TimeGet, gm_tools::_Instance);
		RegisterFunctionPlus(gm_add_man_req, gm_add_man_resp, gm_tools::ManAdd, gm_tools::_Instance);
		RegisterFunctionPlus(gm_add_item_req, gm_add_item_resp, gm_tools::ItemAdd, gm_tools::_Instance);
		RegisterFunctionPlus(gm_remove_item_req, gm_remove_item_resp, gm_tools::ItemRemove, gm_tools::_Instance);
		RegisterFunctionPlus(gm_add_lady_req, gm_add_lady_resp, gm_tools::CardAdd, gm_tools::_Instance);
		RegisterFunctionPlus(gm_remove_lady_req, gm_remove_lady_resp, gm_tools::CardRemove, gm_tools::_Instance);
		RegisterFunctionPlus(gm_recharge_req, gm_recharge_resp, gm_tools::Recharge, gm_tools::_Instance);
		RegisterFunctionPlus(gm_war_process_req, gm_war_process_resp, gm_tools::motifyWarProcess, gm_tools::_Instance);
		RegisterFunctionPlus(gm_despatach_gift_req, gm_despatach_gift_resp, gm_tools::GiftCard, gm_tools::_Instance);
		RegisterFunctionPlus(gm_update_roll_req, gm_update_roll_resp, chat_system::UpdateRollNotice, chat_system::_Instance);
		RegisterFunctionPlus(gm_set_roll_req, gm_set_roll_resp, chat_system::RollNotice, chat_system::_Instance);
		RegisterFunctionPlus(gm_remove_roll_req, gm_remove_roll_resp, chat_system::RemoveRollNotice, chat_system::_Instance);
		RegisterFunctionPlus(gm_reply_client_announce_req, gm_reply_client_announce_resp, gm_tools::ReplyTickGamer, gm_tools::_Instance);
		RegisterFunctionPlus(gm_motify_mall_good_req, gm_motify_mall_good_resp, mall::gmMotify, mall::_Instance);
		RegisterFunctionPlus(gm_update_mall_good_req, gm_update_mall_good_resp, mall::gmUpdate, mall::_Instance);
		RegisterFunctionPlus(gm_update_customer_gift_req, gm_update_customer_gift_resp, gm_tools::gmUpdateCustom, gm_tools::_Instance);
		RegisterFunctionPlus(gm_motify_customer_gift_req, gm_motify_customer_gift_resp, gm_tools::gmMotifyCustom, gm_tools::_Instance);
		RegisterFunctionPlus(gm_motify_money_activity_req, gm_motify_money_activity_resp, MoneyActivity::GmMotify, MoneyActivity::_Instance);
		RegisterFunctionPlus(gm_udpate_money_activity_req, gm_udpate_money_activity_resp, MoneyActivity::GmUpdate, MoneyActivity::_Instance);
		RegisterFunctionPlus(gm_annouce_push_message_req, gm_annouce_push_message_resp, Gamer::GMPushAnnouce, Gamer::_Instance);
		RegisterFunctionPlus(gm_get_card_poke_req, gm_get_card_poke_resp, gm_tools::LadyPokeGet, gm_tools::_Instance);
		RegisterFunctionPlus(gm_motify_card_poke_req, gm_motify_card_poke_resp, gm_tools::LadyPokeMotify, gm_tools::_Instance);

		//Ѱ��
		RegisterFunctionPlus(player_search_data_req, player_search_data_resp, search_system::getData, search_system::_Instance);
		RegisterFunctionPlus(player_search_for_weiwang_req, player_search_for_weiwang_resp, search_system::searchFor_WeiWang, search_system::_Instance);
		RegisterFunctionPlus(player_search_for_cash_req, player_search_for_cash_resp, search_system::searchFor_Cash, search_system::_Instance);
		RegisterFunctionPlus(player_search_ww_shop_info_req, player_search_ww_shop_info_resp, search_system::WWshopInfo, search_system::_Instance);
		RegisterFunctionPlus(player_search_ww_buy_req, player_search_ww_buy_resp, search_system::WWbuy, search_system::_Instance);
		RegisterFunctionPlus(player_search_ww_flush_req, player_search_ww_flush_resp, search_system::WWflush, search_system::_Instance);
		RegisterFunctionPlus(player_search_cs_shop_info_req, player_search_cs_shop_info_resp, search_system::CSshopInfo, search_system::_Instance);
		RegisterFunctionPlus(player_search_cs_buy_req, player_search_cs_buy_resp, search_system::CSbuy, search_system::_Instance);
		RegisterFunctionPlus(player_search_cs_flush_req, player_search_cs_flush_resp, search_system::CSflush, search_system::_Instance);

		//����
		RegisterFunctionPlus(item_buy_silver_req, item_buy_silver_resp, item_system::silverShopReq, item_system::_Instance);//���ҹ���
		RegisterFunctionPlus(item_buy_gold_req, item_buy_gold_resp, item_system::goldShopReq, item_system::_Instance);//���+��ȯ����
		RegisterFunctionPlus(item_sale_req, item_sale_resp, item_system::pawnReq, item_system::_Instance);
		RegisterFunctionPlus(equip_rise_up_req, equip_rise_up_resp, item_system::equipRiseUp, item_system::_Instance);
		RegisterFunctionPlus(equip_degrade_req, equip_degrade_resp, item_system::equipDegrade, item_system::_Instance);
		RegisterFunctionPlus(equip_cd_update_req, equip_cd_update_resp, item_system::equipCDReq, item_system::_Instance);
		RegisterFunctionPlus(equip_cd_clear_req, equip_cd_clear_resp, item_system::equipCDClearReq, item_system::_Instance);
		RegisterFunctionPlus(item_use_req, item_use_resp, item_system::itemOpen, item_system::_Instance);
		RegisterFunctionPlus(equip_reborn_req, equip_reborn_resp, item_system::equipReborn, item_system::_Instance);
		RegisterFunctionPlus(equip_reborn_custom_req, equip_reborn_custom_resp, item_system::equipRebornCus, item_system::_Instance);
		RegisterFunctionPlus(equip_reborn_keep_req, equip_reborn_keep_resp, item_system::equipRBKeep, item_system::_Instance);
		RegisterFunctionPlus(equip_reborn_replace_req, equip_reborn_replace_resp, item_system::equipRBReplace, item_system::_Instance);
		RegisterFunctionPlus(equip_reborn_exchange_req, equip_reborn_exchange_resp, item_system::equipRBExchange, item_system::_Instance);
		RegisterFunctionPlus(equip_dispart_req, equip_dispart_resp, item_system::equipDp, item_system::_Instance);
		RegisterFunctionPlus(equip_dispart_gold_req, equip_dispart_gold_resp, item_system::equipDpGD, item_system::_Instance);
		RegisterFunctionPlus(equip_gem_compose_req, equip_gem_compose_resp, item_system::gemCompose, item_system::_Instance);
		RegisterFunctionPlus(equip_on_gem_req, equip_on_gem_resp, item_system::gemEquip, item_system::_Instance);
		RegisterFunctionPlus(equip_off_gem_req, equip_off_gem_resp, item_system::gemOffEquip, item_system::_Instance);
		RegisterFunctionPlus(equip_active_reborn_req, equip_active_reborn_resp, item_system::equipLight, item_system::_Instance);
		RegisterFunctionPlus(equip_gold_build_req, equip_gold_build_resp, item_system::equipBuildGold, item_system::_Instance);
		RegisterFunctionPlus(equip_silver_build_req, equip_silver_build_resp, item_system::equipBuildSilver, item_system::_Instance);
		RegisterFunctionPlus(equip_show_req, equip_show_resp, item_system::equipShow, item_system::_Instance);

		//chat
		RegisterFunctionPlus(player_chat_req, player_chat_resp, chat_system::ChatReq, chat_system::_Instance);
		RegisterFunctionPlus(gm_chat_forbid_req, gm_chat_forbid_resp, chat_system::gmForbidChat, chat_system::_Instance);
		RegisterFunctionPlus(gm_chat_release_forbid_req, gm_chat_release_forbid_resp, chat_system::gmOpenChat, chat_system::_Instance);
		RegisterFunctionPlus(gm_chat_forbid_update_req, gm_chat_forbid_update_resp, chat_system::gmSetChatUpdate, chat_system::_Instance);

		//business
		RegisterFunctionPlus(player_car_pos_req, player_car_pos_resp, business::update_car, business::_Instance);
		RegisterFunctionPlus(player_trade_base_req, player_trade_base_resp, business::update_base, business::_Instance);
		RegisterFunctionPlus(player_trade_ware_req, player_trade_ware_resp, business::update_ware, business::_Instance);
		RegisterFunctionPlus(player_trade_buff_req, player_trade_buff_resp, business::update_buff, business::_Instance);
		RegisterFunctionPlus(player_city_event_update_req, player_city_event_update_resp, business::city_event, business::_Instance);
		RegisterFunctionPlus(player_car_move_update_req, player_car_move_update_resp, business::update_move, business::_Instance);
		RegisterFunctionPlus(player_car_move_end_req, player_car_move_end_resp, business::end_move, business::_Instance);
		RegisterFunctionPlus(player_trade_task_accept_req, player_trade_task_accept_resp, business::accept_task, business::_Instance);
		RegisterFunctionPlus(player_trade_task_complete_req, player_trade_task_complete_resp, business::complete_task, business::_Instance);
		RegisterFunctionPlus(player_trade_task_ok_complete_req, player_trade_task_ok_complete_resp, business::complete_task_ok, business::_Instance);
		RegisterFunctionPlus(player_trade_city_update_req, player_trade_city_update_resp, business::update_city, business::_Instance);
		RegisterFunctionPlus(player_trade_buy_req, player_trade_buy_resp, business::buy_item, business::_Instance);
		RegisterFunctionPlus(player_trade_sale_req, player_trade_sale_resp, business::sale_item, business::_Instance);
//		RegisterFunctionPlus(player_trade_map_area_update_req, player_trade_map_area_update_resp, business::update_area, business::_Instance);
		RegisterFunctionPlus(player_car_upgrade_req, player_car_upgrade_resp, business::car_upgrade, business::_Instance);
		RegisterFunctionPlus(player_trade_use_item_req, player_trade_use_item_resp, business::item_use, business::_Instance);
//		RegisterFunctionPlus(player_update_trade_map_event_req, player_update_trade_map_event_resp, business::update_map, business::_Instance);
		RegisterFunctionPlus(player_challenge_pirate_req, player_challenge_pirate_resp, business::challenge_pirate, business::_Instance); 
		RegisterFunctionPlus(player_open_trade_box_req, player_open_trade_box_resp, business::open_box, business::_Instance);
		RegisterFunctionPlus(player_car_teleport_req, player_car_teleport_resp, business::car_teleport, business::_Instance);
		RegisterFunctionPlus(player_car_repair_req, player_car_repair_resp, business::car_repair, business::_Instance);
		RegisterFunctionPlus(player_cancel_trade_task_req, player_cancel_trade_task_resp, business::cancel_task, business::_Instance);
		RegisterFunctionPlus(player_trade_money_show_req, player_trade_money_show_resp, business::money_show, business::_Instance);
		RegisterFunctionPlus(player_car_route_data_req, player_car_route_data_resp, business::route_data, business::_Instance);
		RegisterFunctionPlus(player_car_enter_req, player_car_enter_resp, business::sence_enter, business::_Instance);
		RegisterFunctionPlus(player_car_exit_req, player_car_exit_resp, business::sence_exit, business::_Instance);
		RegisterFunctionPlus(player_hit_shark_boss_req, player_hit_shark_boss_resp, business::hit_shark_boss, business::_Instance);
		RegisterFunctionPlus(player_get_shark_reward_req, player_get_shark_reward_resp, business::reward_shark_boss, business::_Instance);

		//��������
		RegisterFunctionPlus(player_king_ui_req, player_king_ui_resp, kingfight_system::showUI, kingfight_system::_Instance);
		RegisterFunctionPlus(player_king_challenge_req, player_king_challenge_resp, kingfight_system::challengeCrown, kingfight_system::_Instance);
		RegisterFunctionPlus(player_king_retime_req, player_king_retime_resp, kingfight_system::reFightTime, kingfight_system::_Instance);
		RegisterFunctionPlus(player_king_guess_req, player_king_guess_resp, kingfight_system::guessCrown, kingfight_system::_Instance);
		RegisterFunctionPlus(player_king_rereward_req, player_king_rereward_resp, kingfight_system::receiveReward, kingfight_system::_Instance);
		RegisterFunctionPlus(player_king_officials_req, player_king_officials_resp, kingfight_system::showOfficialsUI, kingfight_system::_Instance);
		RegisterFunctionPlus(player_king_onOfficials_req, player_king_onOfficials_resp, kingfight_system::anOfficial, kingfight_system::_Instance);
		RegisterFunctionPlus(player_king_beforoff_req, player_king_beforoff_resp, kingfight_system::showBeforOfficial, kingfight_system::_Instance);

		//ȺӢ��
		RegisterFunctionPlus(player_hero_party_req, player_hero_party_resp, heroparty_system::get_hero_base, heroparty_system::_Instance);
		RegisterFunctionPlus(player_hero_party_get_chart_req, player_hero_party_get_chart_resp, heroparty_system::get_chart, heroparty_system::_Instance);
		RegisterFunctionPlus(player_hero_party_get_cost_fight_num_req, player_hero_party_get_cost_fight_num_resp, heroparty_system::get_fight_num_cost, heroparty_system::_Instance);
		RegisterFunctionPlus(player_hero_party_set_fight_num_req, player_hero_party_set_fight_num_resp, heroparty_system::set_fight_num, heroparty_system::_Instance);
		RegisterFunctionPlus(player_hero_party_set_box_req, player_hero_party_set_box_resp, heroparty_system::set_box, heroparty_system::_Instance);
		RegisterFunctionPlus(player_hero_party_shop_req, player_hero_party_shop_base_data_resp, heroparty_system::get_shop_data, heroparty_system::_Instance);
		RegisterFunctionPlus(player_hero_party_reflash_shop_req, player_hero_party_reflash_shop_resp, heroparty_system::flash_shop, heroparty_system::_Instance);
		RegisterFunctionPlus(player_hero_party_buy_shop_req, player_hero_party_buy_shop_resp, heroparty_system::buy_shop, heroparty_system::_Instance);
		RegisterFunctionPlus(player_hero_party_challenge_req, player_hero_party_challenge_resp, heroparty_system::heroparty_challenge, heroparty_system::_Instance);
		RegisterFunctionPlus(player_hero_party_fight_data_req, player_hero_party_fight_data_resp, heroparty_system::get_fight_data, heroparty_system::_Instance);
		RegisterFunctionPlus(player_hero_party_fight_list_req, player_hero_party_fight_list_resp, heroparty_system::get_fight_list, heroparty_system::_Instance);
		RegisterFunctionPlus(player_hero_party_fight_cd_clear_req, player_hero_party_fight_cd_clear_resp, heroparty_system::clear_fight_cd, heroparty_system::_Instance);
		RegisterFunctionPlus(player_hero_party_fight_npc_req, player_hero_party_fight_npc_resp, heroparty_system::fight_npc_leader, heroparty_system::_Instance);
		RegisterFunctionPlus(player_hero_party_first_req, player_hero_party_first_resp, heroparty_system::first_player, heroparty_system::_Instance);

		//��������
		RegisterFunctionPlus(player_rescue_update_req, player_rescue_update_resp, rescue_system::UpdateOwnRescue, rescue_system::_Instance);
		RegisterFunctionPlus(system_rescue_update_req, system_rescue_update_resp, rescue_system::UpdateRescue, rescue_system::_Instance);
		RegisterFunctionPlus(player_tick_help_req, player_tick_help_resp, rescue_system::TickRescue, rescue_system::_Instance);

		//����ϵͳ
		RegisterFunctionPlus(player_kingdom_add_req, player_kingdom_add_resp, kingdom_system::addKingdom, kingdom_system::_Instance);
		RegisterFunctionPlus(player_kingdom_showbuild_req, player_kingdom_showbuild_resp, kingdom_system::showBuild, kingdom_system::_Instance);
		RegisterFunctionPlus(player_kingdom_playercon_req, player_kingdom_playercon_resp, kingdom_system::playerCon, kingdom_system::_Instance);
		RegisterFunctionPlus(player_kingdom_showshop_req, player_kingdom_showshop_resp, kingdom_system::showShop, kingdom_system::_Instance);
		RegisterFunctionPlus(player_kingdom_reshop_req, player_kingdom_reshop_resp, kingdom_system::refShop, kingdom_system::_Instance);
		RegisterFunctionPlus(player_kingdom_buyshop_req, player_kingdom_buyshop_resp, kingdom_system::playershop, kingdom_system::_Instance);
		RegisterFunctionPlus(player_kingdom_showskill_req, player_kingdom_showskill_resp, kingdom_system::showSkill, kingdom_system::_Instance);
		RegisterFunctionPlus(player_kingdom_upskill_req, player_kingdom_upskill_resp, kingdom_system::upSkill, kingdom_system::_Instance);
		RegisterFunctionPlus(player_kingdom_showrank_req, player_kingdom_showrank_resp, kingdom_system::showRank, kingdom_system::_Instance);
		RegisterFunctionPlus(player_kingdom_showbase_req, player_kingdom_showbase_resp, kingdom_system::showKingdom, kingdom_system::_Instance);
		RegisterFunctionPlus(player_kingdom_announcement_req, player_kingdom_announcement_resp, kingdom_system::changeAnnouncement, kingdom_system::_Instance);

		//VIP
		RegisterFunctionPlus(player_vip_show_req, player_vip_show_resp, vip_system::showGift, vip_system::_Instance);
		RegisterFunctionPlus(player_vip_get_req, player_vip_get_resp, vip_system::getGift, vip_system::_Instance);
		RegisterFunctionPlus(player_vip_add_req, player_vip_add_resp, vip_system::addVip, vip_system::_Instance);
		RegisterFunctionPlus(player_vip_get_first_gift_req, player_vip_get_first_gift_resp, vip_system::getFirstGift, vip_system::_Instance);

		//worldBoss
		RegisterFunctionPlus(player_worldboss_ui_req, player_worldboss_ui_resp, worldboss_system::showUI, worldboss_system::_Instance);
		RegisterFunctionPlus(player_worldboss_figth_req, player_worldboss_figth_resp, worldboss_system::fight, worldboss_system::_Instance);
		RegisterFunctionPlus(player_worldboss_report_req, player_worldboss_report_resp, worldboss_system::showrep, worldboss_system::_Instance);
		RegisterFunctionPlus(player_worldboss_iui_req, player_worldboss_iui_resp, worldboss_system::showIncentive, worldboss_system::_Instance);
		RegisterFunctionPlus(player_worldboss_inc_req, player_worldboss_inc_resp, worldboss_system::incentive, worldboss_system::_Instance);
		RegisterFunctionPlus(player_worldboss_rankk_req, player_worldboss_rankk_resp, worldboss_system::rankKingdom, worldboss_system::_Instance);
		RegisterFunctionPlus(player_worldboss_ranks_req, player_worldboss_ranks_resp, worldboss_system::rankSelf, worldboss_system::_Instance);
		RegisterFunctionPlus(player_worldBoss_cleanCD_req, player_worldBoss_cleanCD_resp, worldboss_system::cleanCd, worldboss_system::_Instance);
		RegisterFunctionPlus(player_worldBoss_getreward_req, player_worldBoss_getreward_resp, worldboss_system::getReward, worldboss_system::_Instance);
	
		//team war
		RegisterFunctionPlus(player_team_update_req, player_team_update_resp, TeamWar::team_own_update, TeamWar::_Instance);
		RegisterFunctionPlus(war_team_create_req, war_team_create_resp, TeamWar::team_create, TeamWar::_Instance);
		RegisterFunctionPlus(war_team_leave_req, war_team_leave_resp, TeamWar::team_leave, TeamWar::_Instance);
		RegisterFunctionPlus(war_team_join_req, war_team_join_resp, TeamWar::team_join, TeamWar::_Instance);
		RegisterFunctionPlus(war_team_update_req, war_team_update_resp, TeamWar::team_update, TeamWar::_Instance);
		RegisterFunctionPlus(war_team_first_req, war_team_first_resp, TeamWar::team_first, TeamWar::_Instance);
		RegisterFunctionPlus(war_team_robot_req, war_team_robot_resp, TeamWar::team_robot, TeamWar::_Instance);
		RegisterFunctionPlus(war_team_fight_req, war_team_fight_resp, TeamWar::team_fight, TeamWar::_Instance);
		RegisterFunctionPlus(war_team_detail_info_req, war_team_detail_info_resp, TeamWar::team_info_update, TeamWar::_Instance);
		RegisterFunctionPlus(war_team_kick_req, war_team_kick_resp, TeamWar::team_kick, TeamWar::_Instance);
		RegisterFunctionPlus(war_team_show_robot_req, war_team_show_robot_resp, TeamWar::show_robot, TeamWar::_Instance);
		RegisterFunctionPlus(war_team_buy_times_req, war_team_buy_times_resp, TeamWar::buy_times, TeamWar::_Instance);
		RegisterFunctionPlus(war_team_change_position_req, war_team_change_position_resp, TeamWar::change_position, TeamWar::_Instance);

		//mall
		RegisterFunctionPlus(player_mall_info_update_req, player_mall_info_update_resp, mall::UpdatePlayer, mall::_Instance);
		RegisterFunctionPlus(mall_goods_update_req, mall_goods_update_resp, mall::Update, mall::_Instance);
		RegisterFunctionPlus(mall_buy_good_req, mall_buy_good_resp, mall::Buy, mall::_Instance);

		//warlords
		RegisterFunctionPlus(warlords_player_info_req, warlords_player_info_resp, warlords_system::playerInfoReq, warlords_system::_Instance);
		RegisterFunctionPlus(warlords_battle_info_req, warlords_battle_info_resp, warlords_system::battleInfoReq, warlords_system::_Instance);
		RegisterFunctionPlus(warlords_attack_req, warlords_attack_resp, warlords_system::attackReq, warlords_system::_Instance);
		RegisterFunctionPlus(warlords_report_list_req, warlords_report_list_resp, warlords_system::reportListReq, warlords_system::_Instance);
		RegisterFunctionPlus(warlords_table_req, warlords_table_resp, warlords_system::tableReq, warlords_system::_Instance);
		RegisterFunctionPlus(warlords_search_req, warlords_search_resp, warlords_system::searchReq, warlords_system::_Instance);
		RegisterFunctionPlus(warlords_look_up_req, warlords_look_up_resp, warlords_system::lookUpReq, warlords_system::_Instance);
		RegisterFunctionPlus(warlords_set_message_req, warlords_set_message_resp, warlords_system::setMessageReq, warlords_system::_Instance);

		// email
		RegisterFunctionPlus(email_player_info_req, email_player_info_resp, email_system::playerInfoReq, email_system::_Instance);
		RegisterFunctionPlus(email_send_player_req, email_send_player_resp, email_system::sendEmailReq, email_system::_Instance);
		RegisterFunctionPlus(email_get_package_req, email_get_package_resp, email_system::getPackageReq, email_system::_Instance);
		RegisterFunctionPlus(email_red_point_req, email_red_point_resp, email_system::redPointReq, email_system::_Instance);
		RegisterFunctionPlus(gm_email_send_player_req, gm_email_send_player_resp, email_system::gmSendEmailReq, email_system::_Instance);

		//daily task
		RegisterFunctionPlus(player_daily_info_update_req, player_daily_info_update_resp, daily_system::update, daily_system::_Instance);
		RegisterFunctionPlus(player_daily_get_box_req, player_daily_get_box_resp, daily_system::getBox, daily_system::_Instance);
		RegisterFunctionPlus(player_daily_get_task_box_req, player_daily_get_task_box_resp, daily_system::getTaskBox, daily_system::_Instance);


		// days_activity
		RegisterFunctionPlus(days_activity_config_info_req, days_activity_config_info_resp, days_activity_system::activityInfoReq, days_activity_system::_Instance);
		RegisterFunctionPlus(days_activity_player_info_req, days_activity_player_info_resp, days_activity_system::playerInfoReq, days_activity_system::_Instance);
		RegisterFunctionPlus(days_activity_get_reward_req, days_activity_get_reward_resp, days_activity_system::getRewardReq, days_activity_system::_Instance);
		RegisterFunctionPlus(days_activity_red_point_req, days_activity_red_point_resp, days_activity_system::redPointReq, days_activity_system::_Instance);

		RegisterFunctionPlus(gm_days_activity_info_req, gm_days_activity_info_resp, days_activity_system::gmInfoReq, days_activity_system::_Instance);
		RegisterFunctionPlus(gm_days_activity_modify_req, gm_days_activity_modify_resp, days_activity_system::gmModifyReq, days_activity_system::_Instance);
		RegisterFunctionPlus(gm_days_activity_id_list_req, gm_days_activity_id_list_resp, days_activity_system::gmIDListReq, days_activity_system::_Instance);

		// sign
		RegisterFunctionPlus(sign_player_info_req, sign_player_info_resp, sign_system::playerInfo, sign_system::_Instance);
		RegisterFunctionPlus(sign_get_reward_req, sign_get_reward_resp, sign_system::getReward, sign_system::_Instance);

		//�ȼ�����
		RegisterFunctionPlus(player_fund_info_update_req, player_fund_info_update_resp, fund_system::reqFundInfo, fund_system::_Instance);
		RegisterFunctionPlus(player_fund_buy_req, player_fund_buy_resp, fund_system::reqFundBuy, fund_system::_Instance);
		RegisterFunctionPlus(player_fund_get_reward_req, player_fund_get_reward_resp, fund_system::reqFundGetReward, fund_system::_Instance);

		// kingdom war
		RegisterFunctionPlus(kingdom_war_quit_req, kingdom_war_quit_resp, kingdomwar_system::quitReq, kingdomwar_system::_Instance);
		RegisterFunctionPlus(kingdom_war_main_info_req, kingdom_war_main_info_resp, kingdomwar_system::mainInfoReq, kingdomwar_system::_Instance);
		RegisterFunctionPlus(kingdom_war_move_req, kingdom_war_move_resp, kingdomwar_system::moveReq, kingdomwar_system::_Instance);
		RegisterFunctionPlus(kingdom_war_player_info_req, kingdom_war_player_info_resp, kingdomwar_system::playerInfoReq, kingdomwar_system::_Instance);
		RegisterFunctionPlus(kingdom_war_set_formation_req, kingdom_war_set_formation_resp, kingdomwar_system::setFormationReq, kingdomwar_system::_Instance);
		RegisterFunctionPlus(kingdom_war_city_battle_info_req, kingdom_war_city_battle_info_resp, kingdomwar_system::cityBattleInfoReq, kingdomwar_system::_Instance);
		RegisterFunctionPlus(kingdom_war_retreat_req, kingdom_war_retreat_resp, kingdomwar_system::retreatReq, kingdomwar_system::_Instance);
		RegisterFunctionPlus(kingdom_war_report_info_req, kingdom_war_report_info_resp, kingdomwar_system::reportInfoReq, kingdomwar_system::_Instance);
		RegisterFunctionPlus(kingdom_war_rank_info_req, kingdom_war_rank_info_resp, kingdomwar_system::rankInfoReq, kingdomwar_system::_Instance);
		RegisterFunctionPlus(kingdom_war_buy_hp_item_req, kingdom_war_buy_hp_item_resp, kingdomwar_system::buyHpItemReq, kingdomwar_system::_Instance);
		RegisterFunctionPlus(kingdom_war_use_hp_item_req, kingdom_war_use_hp_item_resp, kingdomwar_system::useHpItemReq, kingdomwar_system::_Instance);
		RegisterFunctionPlus(kingdom_war_all_formation_req, kingdom_war_all_formation_resp, kingdomwar_system::formationReq, kingdomwar_system::_Instance);
		RegisterFunctionPlus(kingdom_war_sign_gather_req, kingdom_war_sign_gather_resp, kingdomwar_system::signGatherReq, kingdomwar_system::_Instance);
		RegisterFunctionPlus(kingdom_war_army_info_req, kingdom_war_army_info_resp, kingdomwar_system::armyInfoReq, kingdomwar_system::_Instance);
		RegisterFunctionPlus(kingdom_war_change_formation_req, kingdom_war_change_formation_resp, kingdomwar_system::changeFormationReq, kingdomwar_system::_Instance);
		RegisterFunctionPlus(kingdom_war_military_info_req, kingdom_war_military_info_resp, kingdomwar_system::militaryInfoReq, kingdomwar_system::_Instance);
		RegisterFunctionPlus(kingdom_war_city_player_list_req, kingdom_war_city_player_list_resp, kingdomwar_system::playerListReq, kingdomwar_system::_Instance);
		RegisterFunctionPlus(kingdom_war_up_man_hp_cost_req, kingdom_war_up_man_hp_cost_resp, kingdomwar_system::upManHpCostReq, kingdomwar_system::_Instance);
		RegisterFunctionPlus(kingdom_war_up_man_hp_req, kingdom_war_up_man_hp_resp, kingdomwar_system::upManHpReq, kingdomwar_system::_Instance);
		RegisterFunctionPlus(kingdom_war_output_info_req, kingdom_war_output_info_resp, kingdomwar_system::outputInfoReq, kingdomwar_system::_Instance);
		RegisterFunctionPlus(kingdom_war_get_output_req, kingdom_war_get_output_resp, kingdomwar_system::getOutputReq, kingdomwar_system::_Instance);
		RegisterFunctionPlus(kingdom_war_look_up_player_req, kingdom_war_look_up_player_resp, kingdomwar_system::lookUpPlayerReq, kingdomwar_system::_Instance);
		RegisterFunctionPlus(kingdom_war_person_task_req, kingdom_war_person_task_resp, kingdomwar_system::personTaskReq, kingdomwar_system::_Instance);
		RegisterFunctionPlus(kingdom_war_person_task_reward_req, kingdom_war_person_task_reward_resp, kingdomwar_system::personTaskRewardReq, kingdomwar_system::_Instance);
		RegisterFunctionPlus(kingdom_war_nation_task_req, kingdom_war_nation_task_resp, kingdomwar_system::nationTaskReq, kingdomwar_system::_Instance);
		RegisterFunctionPlus(kingdom_war_nation_task_reward_req, kingdom_war_nation_task_reward_resp, kingdomwar_system::nationTaskRewardReq, kingdomwar_system::_Instance);
		RegisterFunctionPlus(kingdom_war_great_event_req, kingdom_war_great_event_resp, kingdomwar_system::greatEventReq, kingdomwar_system::_Instance);
		RegisterFunctionPlus(kingdom_war_great_event_reward_req, kingdom_war_great_event_reward_resp, kingdomwar_system::greatEventRewardReq, kingdomwar_system::_Instance);
		RegisterFunctionPlus(kingdom_war_call_shadow_req, kingdom_war_call_shadow_resp, kingdomwar_system::callShadowReq, kingdomwar_system::_Instance);
		RegisterFunctionPlus(kingdom_war_call_tower_req, kingdom_war_call_tower_resp, kingdomwar_system::callTowerReq, kingdomwar_system::_Instance);
		RegisterFunctionPlus(kingdom_war_use_tower_item_req, kingdom_war_use_tower_item_resp, kingdomwar_system::useTowerItemReq, kingdomwar_system::_Instance);

		// kingdom_war_shop
		RegisterFunctionPlus(kingdom_war_shop_info_req, kingdom_war_shop_info_resp, kingdomwar_shop_system::shopInfo, kingdomwar_shop_system::_Instance);
		RegisterFunctionPlus(kingdom_war_shop_buy_req, kingdom_war_shop_buy_resp, kingdomwar_shop_system::buy, kingdomwar_shop_system::_Instance);
		RegisterFunctionPlus(kingdom_war_shop_flush_req, kingdom_war_shop_flush_resp, kingdomwar_shop_system::flush, kingdomwar_shop_system::_Instance);
		RegisterFunctionPlus(kingdom_war_box_reward_req, kingdom_war_box_reward_resp, kingdomwar_shop_system::boxRewardReq, kingdomwar_shop_system::_Instance);
		RegisterFunctionPlus(kingdom_war_get_box_reward_req, kingdom_war_get_box_reward_resp, kingdomwar_shop_system::getBoxRewardReq, kingdomwar_shop_system::_Instance);

		// open_activity
		RegisterFunctionPlus(open_activity_config_info_req, open_activity_config_info_resp, open_activity_system::activityInfoReq, open_activity_system::_Instance);
		RegisterFunctionPlus(open_activity_player_info_req, open_activity_player_info_resp, open_activity_system::playerInfoReq, open_activity_system::_Instance);
		RegisterFunctionPlus(open_activity_get_reward_req, open_activity_get_reward_resp, open_activity_system::getRewardReq, open_activity_system::_Instance);
		RegisterFunctionPlus(open_activity_red_point_req, open_activity_red_point_resp, open_activity_system::redPointReq, open_activity_system::_Instance);
	}

	void game::InitialGame()
	{
		ensureIndex();
		detail::initDetail();
		// initial game system here
		Task::Checker::init();
		actionInitData();
		player_mgr.initData();
		gamer.initData();
		playerBase::initData();
		season_sys.initData();
		man_sys.initData();
		item_sys.initData();
		skill_mgr.initData();
		battleLogic::initData();
		ownerland_sys.initData();
		map_sys.initData();
		task_sys.initData();
		playerSGFM::initData();
		playerManMgr::initData();
		playerCardMgr::initData();
		card_sys.initData();
		search_sys.initData();
		chat_sys.initData();
		business_sys.initData();
		heroparty_sys.initData();
		rescue_sys.initData();
		team_war.initData();
		vip_sys.initData();
		team_war.initData();
		compensate_sys.initData();
		mall_sys.initData();
		email_sys.initData();
		daily_sys.initData();
		days_activity_sys.initData();
		open_activity_sys.initData();
		gm_mgr.initData();
		UserTask::initData();
		money_sys.initData();
		sign_sys.initData();
		fund_sys.initData();
		kingdomwar_shop.initData();
		patrol_sys.initData();

		// LAST
		kingfight_sys.initData();
		warlords_sys.initData();
		worldboss_sys.initData();
		kingdom_sys.initData();
		kingdomwar_sys.initData();
	}

}

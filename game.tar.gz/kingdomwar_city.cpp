#include "kingdomwar_city.h"
#include "kingdomwar_system.h"
#include "map_war.h"
#include "net_helper.hpp"
#include "kingdomwar_task.h"
#include "kingdom_system.h"
#include "email_system.h"
#include "action_system.h"
#include "game_time.h"
#include "task_mgr.h"

namespace gg
{
	namespace KingdomWar
	{
		enum
		{
			// param
			BattleQueueNum = 4,
			WaitQueueNum = 5,
			WaitQueueMemNum = 4,
			ReadyMemNum = WaitQueueNum * WaitQueueMemNum,

			DefSpeed = 10,

			CacheSize = 63,

			BattleWaitInterval = 2,
			AttackerWaitInterval = 30,
			DefenderWaitInterval = 30,
			StartWaitInterval = 2 * MINUTE,
			ProtectedInterval = 30 * MINUTE,
			
			TowerLifeTime = 30 * MINUTE,
			TowerLifeTimePrimeRate = 2,

			ElecAttackInterval = 30,
			ElecAttackIntervalPrimeRate = 2,

			TowerMaxNum = 2,

			StartWaitPrimeRate = 4,
			ProtectedPrimeRate = 30,
			//WaitPrimeRate = 3,

			NpcOutTime = 3,
			ElecAttackTowerDamage = 30,
			ElecAttackPrimeRate = 2,
			ElecTowerLifeTimePrimeRate = 2,
//			CallTowerMaxTimes = 3,
		};

		static unsigned getEndWaitInterval(unsigned times)
		{
			const static unsigned EndWaitInterval[] = {30, 25, 20, 15, 10};
			if (times >= sizeof(EndWaitInterval) / sizeof(EndWaitInterval[0]))
				times = sizeof(EndWaitInterval) / sizeof(EndWaitInterval[0]) - 1;
			return EndWaitInterval[times];
		}

		const static double TimePerRound = 0.7;
		const static double SupSpeed = 100.0 / 60.0;

#define PUSH_UPDATER(PTR)\
	{\
		if (!_city->empty())\
		{\
			_updater.push(PTR);\
			_modified = true;\
			if (_updater.size() > CacheSize)\
				tick();\
		}\
	}

#define PUSH_UPDATER2(TYPE, PTR)\
	{\
		CityMgr::shared().tickUpdate(TYPE, PTR);\
	}

#define TRYLOAD(TYPE)\
	void City::tryLoad##TYPE(TYPE##DataPtr& d)\
	{\
		using namespace nCity;\
		if (_is_main)\
			return;\
		TYPE##Ptr ptr = Creator<I##TYPE>::Create(d, upCast<City>(shared_from_this()));\
		Json::Value tips;\
		tips.append((int)TIPS::DEFEATED);\
		tips.append(_id);\
		if (_state_helper == Closed\
			|| _state_helper == Protected\
			|| _state_helper == DefenderWait)\
		{\
			if (ptr->nation() == _nation)\
			{\
				if (ptr->type() == Npc)\
					_npc_list.push_back(ptr);\
				else\
					_defender_backup.push_back(ptr);\
				_counter->push(ptr);\
			}\
			else\
				ptr->beDead(0, tips);\
		}\
		else if (_state_helper == AttackerWait)\
		{\
			if (ptr->nation() != _nation\
				&& ptr->type() != Npc)\
			{\
				_attacker_backup.push_back(ptr);\
				_counter->push(ptr);\
			}\
			else\
				ptr->beDead(0, tips);\
		}\
		else\
		{\
			if (ptr->type() == Npc)\
			{\
				if (ptr->nation() == _nation)\
					_npc_list.push_back(ptr);\
				else\
				{\
					ptr->beDead(0, tips);\
					return;\
				}\
			}\
			else if (ptr->nation() != _nation)\
				_attacker_backup.push_back(ptr);\
			else\
				_defender_backup.push_back(ptr);\
			_counter->push(ptr);\
		}\
	}

#define ENTER(TYPE)\
	int City::enter(unsigned time, TYPE##DataPtr d)\
	{\
		using namespace nCity;\
		if (_is_main)\
			return err_illedge;\
		if (inProtected(d->nation()))\
		{\
			d->setDead(time, JARRAY((int)TIPS::CITYPROTECTED << _id));\
			return res_sucess;\
		}\
		TYPE##Ptr ptr = Creator<I##TYPE>::Create(d, upCast<City>(shared_from_this()));\
		d->setPosition(PosCity, _id, time);\
		return enter(time, ptr);\
	}

		namespace nCity
		{
			class BoxConfig
			{
				SINGLETON(BoxConfig);
				public:
					int minExploit() const;
					int getGoldBoxNumByExploit(int exploit) const;
					int getGoldBoxID() const { return _gold_box_id; }
					const ActionRandomList& getSilverBox() const { return _silver_box; }

				private:
					void loadFile();
					
				private:
					struct Item
					{
						Item(const Json::Value& info)
						{
							start = info["exploit_start"].asInt();
							end = info["exploit_end"].asInt();
							num = info["box_num"].asInt();
						}
						int start;
						int end;
						int num;
					};
					std::vector<Item> _items;
					int _gold_box_id;
					ActionRandomList _silver_box;
			};

			BoxConfig::BoxConfig()
			{
				loadFile();
			}

			int BoxConfig::minExploit() const
			{
				if (_items.empty())
					return 0;
				else
					return _items.front().start;
			}

			void BoxConfig::loadFile()
			{
				Json::Value json = Common::loadJsonFile("./instance/kingdom_war/city_reward.json");
				const Json::Value& rw1 = json["reward1"];
				ForEachC(Json::Value, it, rw1)
					_items.push_back(Item(*it));
				_gold_box_id = json["reward1_box_id"].asInt();
				_silver_box = actionFormat(json["reward2_box_id"].asInt());
			}

			int BoxConfig::getGoldBoxNumByExploit(int exploit) const
			{
				if (_items.empty()
					|| exploit < _items.front().start)
					return 0;
				ForEachC(std::vector<Item>, it, _items)
				{
					if (it->end == -1)
						return it->num;
					if (exploit >= it->start
						&& exploit <= it->end)
						return it->num;
				}
				return 0;
			}

			enum
			{
				Up_Swap = 0,
				Up_Add,
				Up_Move,
				Up_Del,
				Up_Report,
				Up_Cross,
				Up_Clear,
				Up_Tower,
				Up_DelTower,
				Up_ElecAttackPlayer,
				Up_ElecAttackTower,
				Up_DelReadyItem,
				Up_QueueItem,

				Up_Nation = 0,
				Up_State,
			};

			class UpSwap
				: public UpBase
			{
				public:
					UpSwap(int side, int player_pos, int npc_pos, const ItemPtr& ptr)
						: _side(side), _player_pos(player_pos), _npc_pos(npc_pos), _ptr(ptr){}
					virtual void getInfo(qValue& q) const
					{
						q << (int)Up_Swap << _side << _player_pos << _npc_pos;
						qValue tmp;
						_ptr->getUpInfo(Up_Swap, tmp);
						q << tmp;
					}
				private:
					int _side;
					int _player_pos;
					int _npc_pos;
					ItemPtr _ptr;
			};

			class UpAdd
				: public UpBase
			{
				public:
					UpAdd(int side, const ItemPtr& ptr)
						: _side(side), _ptr(ptr){}
					virtual void getInfo(qValue& q) const
					{
						q << (int)Up_Add << _side;
						qValue tmp;
						_ptr->getUpInfo(Up_Add, tmp);
						q << tmp;
					}
				private:
					int _side;
					ItemPtr _ptr;
			};

			class UpMove
				: public UpBase
			{
				public:
					UpMove(int side, int qid, unsigned time, const ItemPtr& ptr)
						: _side(side), _qid(qid), _ready_time(time), _ptr(ptr)
					{
					}
					virtual void getInfo(qValue& q) const
					{
						q << (int)Up_Move << _side << _qid << _ready_time;
						qValue tmp;
						_ptr->getManInfo(tmp);
						q << tmp;
					}
				private:
					int _side;
					int _qid;
					unsigned _ready_time;
					ItemPtr _ptr;
			};

			class UpDel
				: public UpBase
			{
				public:
					UpDel(int side, int qid, Json::Value& tips, const ItemPtr& ptr)
						: _side(side), _qid(qid), _ptr(ptr), _tips(tips)
					{
					}
					virtual void getInfo(qValue& q) const
					{
						q << (int)Up_Del << _qid << _side << qValue(_tips.toIndentString().c_str());
						qValue tmp;
						_ptr->getUpInfo(Up_Del, tmp);
						q << tmp;
					}
				private:
					int _side;
					int _qid;
					Json::Value _tips;
					ItemPtr _ptr;
			};

			class UpReport
				: public UpBase
			{
				public:
					UpReport(int qid, const ReportDataPtr& ptr)
						: _qid(qid), _rep(ptr){}
					virtual void getInfo(qValue& q) const
					{
						q << (int)Up_Report << _qid;
						qValue tmp;
						_rep->getInfo(tmp);
						q << tmp;
					}
				private:
					int _qid;
					ReportDataPtr _rep;
			};
			
			class UpCross
				: public UpBase
			{
				public:
					UpCross(int qid_from, int qid_to, unsigned time)
						:_qid_from(qid_from), _qid_to(qid_to), _ready_time(time){}
					virtual void getInfo(qValue& q) const
					{
						q << (int)Up_Cross << _qid_from << _qid_to << _ready_time;
					}
				private:
					int _qid_from;
					int _qid_to;
					unsigned _ready_time;
			};

			class UpClear
				: public UpBase
			{
				public:
					virtual void getInfo(qValue& q) const
					{
						q << (int)Up_Clear;
					}
			};

			class UpTower
				: public UpBase
			{
				public:
					UpTower(int side, int pos, const TowerPtr& ptr)
						: _side(side), _pos(pos), _ptr(ptr)
					{
					}
					virtual void getInfo(qValue& q) const
					{
						q << (int)Up_Tower << _side << _pos;
						_ptr->getInfo(q);
					}
				private:
					int _side;
					int _pos;
					TowerPtr _ptr;
			};

			class UpDelTower
				: public UpBase
			{
				public:
					UpDelTower(int side, int pos)
						: _side(side), _pos(pos){}
					virtual void getInfo(qValue& q) const
					{
						q << (int)Up_DelTower << _side << _pos;
					}
				private:
					int _side;
					int _pos;
			};

			class UpElecAttackPlayer
				: public UpBase
			{
				public:
					UpElecAttackPlayer(int side, int pos, const ItemPtr& ptr, int hp)
						: _side(side), _pos(pos), _ptr(ptr), _hp(hp){}
					virtual void getInfo(qValue& q) const
					{
						q << (int)Up_ElecAttackPlayer << _side << _pos;
						qValue tmp;
						_ptr->getUpInfo(Up_ElecAttackPlayer, tmp);
						q << tmp;
						q << _hp;
					}
				private:
					int _side;
					int _pos;
					ItemPtr _ptr;
					int _hp;
			};

			class UpElecAttackTower
				: public UpBase
			{
				public:
					UpElecAttackTower(int side, int pos, int target_pos, int sub_sec)
						: _side(side), _pos(pos), _target_pos(target_pos), _sub_sec(sub_sec){}
					virtual void getInfo(qValue& q) const
					{
						q << (int)Up_ElecAttackTower << _side << _pos << _target_pos
							<< _sub_sec;
					}
				private:
					int _side;
					int _pos;
					int _target_pos;
					int _sub_sec;
			};

			class UpDelReadyItem
				: public UpBase
			{
				public:
					UpDelReadyItem(int side, Json::Value& tips, const ItemPtr& ptr)
						: _side(side), _ptr(ptr), _tips(tips){}
					virtual void getInfo(qValue& q) const
					{
						q << (int)Up_DelReadyItem << _side;
						qValue tmp;
						_ptr->getUpInfo(Up_DelReadyItem, tmp);
						q << tmp << qValue(_tips.toIndentString().c_str());
					}
				private:
					int _side;
					Json::Value _tips;
					ItemPtr _ptr;
			};

			class UpQueueItem
				: public UpBase
			{
				public:
					UpQueueItem(int side, int qid, const ItemPtr& ptr)
						: _side(side), _qid(qid), _ptr(ptr){}
					virtual void getInfo(qValue& q) const
					{
						q << (int)Up_QueueItem << _side << _qid;
						qValue tmp;
						_ptr->getManInfo(tmp);
						q << tmp;
					}
				private:
					int _side;
					int _qid;
					ItemPtr _ptr;
			};

			TowerBase::TowerBase(int nation, unsigned remain_time, unsigned dead_time, BattleFieldPtr bf)
				: _nation(nation), _remain_time(remain_time), _dead_time(dead_time), _battle_field(bf), _dead_timer(0)
			{
				static int ID = 0;
				_id = ++ID;
			}

			void TowerBase::setDeadTimer(unsigned cur_time)
			{
				++_dead_timer;
				if (cur_time != 0)
					_dead_time = cur_time + _remain_time;
				kingdomwar_sys.addTimer(_dead_time, boostBind(TowerBase::tickDead, shared_from_this(), _dead_timer, _dead_time));
				_battle_field->upTowerLifeTime(_id);
			}

			void TowerBase::stopDeadTimer(unsigned cur_time)
			{
				++_dead_timer;
				_remain_time = _dead_time - cur_time;
				_dead_time = 0;
				_battle_field->upTowerLifeTime(_id);
			}

			void TowerBase::tickDead(unsigned timer_id, unsigned tick_time)
			{
				if (timer_id != _dead_timer)
					return;
				setDead(tick_time);
			}

			void TowerBase::alterLifeTime(unsigned cur_time, int secs)
			{
				if (_dead_time == 0)
				{
					_remain_time += secs;
					if (_remain_time < 1)
						setDead(cur_time);
					else
						_battle_field->upTowerLifeTime(_id);
				}
				else
				{
					_remain_time = _dead_time - cur_time;
					_remain_time += secs;
					setDeadTimer(cur_time);
					_battle_field->upTowerLifeTime(_id);
				}
			}

			void TowerBase::tickPrimeState(unsigned tick_time)
			{
				if (_dead_time != 0)
				{
					if (PrimeState::shared())
						_dead_time = tick_time + (_dead_time - tick_time) / TowerLifeTimePrimeRate;
					else
						_dead_time = tick_time + (_dead_time - tick_time) * TowerLifeTimePrimeRate;
					setDeadTimer(0);
					_battle_field->upTowerLifeTime(_id);
				}
				else
				{
					if (PrimeState::shared())
						_remain_time /= TowerLifeTimePrimeRate;
					else
						_remain_time *= TowerLifeTimePrimeRate;
					_battle_field->upTowerLifeTime(_id);
				}
			}

			void TowerBase::setDead(unsigned tick_time)
			{
				_dead_timer = 0;
				_battle_field->removeTower(tick_time, _id);
			}

			static int getTowerLifeTime()
			{
				return PrimeState::shared()? 
					(TowerLifeTime / TowerLifeTimePrimeRate) : TowerLifeTime;
			}

			ElecTower::ElecTower(const mongo::BSONElement& obj, BattleFieldPtr bf)
				: TowerBase(obj["nt"].Int(), (unsigned)obj["rt"].Int(), (unsigned)obj["dt"].Int(), bf)
			{
				_attack_timer = 0;
				_next_attack_time = obj["nat"].Int();
			}

			ElecTower::ElecTower(unsigned cur_time, int nation, BattleFieldPtr bf)
				: TowerBase(nation, getTowerLifeTime(), 0, bf)
			{
				_attack_timer = 0;
			}

			mongo::BSONObj ElecTower::toBSON() const
			{
				return BSON("t" << (int)ELECTOWER << "nat" << _next_attack_time << "dt" << deadTime() << "rt" << remainTime() << "nt" << nation());
			}

			void ElecTower::getInfo(qValue& q) const
			{
				q << id() << (int)ELECTOWER << deadTime() << nation() << remainTime();
			}

			void ElecTower::setAttackTimer(unsigned cur_time)
			{
				++_attack_timer;
				if (cur_time != 0)
				{
					if (PrimeState::shared())
						_next_attack_time = cur_time + ElecAttackInterval / ElecAttackPrimeRate;
					else
						_next_attack_time = cur_time + ElecAttackInterval;
				}
				kingdomwar_sys.addTimer(_next_attack_time, boostBind(ElecTower::tickAttack, upCast<ElecTower>(shared_from_this()), _attack_timer, _next_attack_time));
			}

			void ElecTower::setDead(unsigned tick_time)
			{
				TowerBase::setDead(tick_time);
				_attack_timer = 0;
			}

			void ElecTower::tickAttack(unsigned timer_id, unsigned tick_time)
			{
				if (_attack_timer != timer_id)
					return;
				_battle_field->tickElecAttack(tick_time, id());
				setAttackTimer(tick_time);
			}

			void ElecTower::tickPrimeState(unsigned cur_time)
			{
				TowerBase::tickPrimeState(cur_time);
				if (PrimeState::shared())
					_next_attack_time = cur_time + (_next_attack_time - cur_time) / ElecAttackPrimeRate;
				else
					_next_attack_time = cur_time + (_next_attack_time - cur_time) * ElecAttackPrimeRate;
				setAttackTimer();
			}

			ReportData::ReportData(unsigned cur_time, ItemPtr& atk_ptr, ItemPtr& def_ptr)
				: path("")
			{
				time = cur_time;
				atk_info = atk_ptr->getBattleInfo();
				def_info = def_ptr->getBattleInfo();
				if (cur_time - season_sys.openTime() < 2 * DAY 
					|| cur_time - season_sys.openTime() > 5 * DAY)
					return;
				if (atk_ptr->type() != Player || def_ptr->type() != Npc)
					return;
				if (upCast<IPlayer>(atk_ptr)->lv() > 35)
					return;
				int npc_id = upCast<INpc>(def_ptr)->npcData()->npcData()->mapID;
				npc_id %= 10;
				if (npc_id < 5 || npc_id > 8)
					return;
				npc_id = NpcRuleMgr::shared().npcID();
				if (npc_id % 10 == 0)
					npc_id -= 2;
				else if (npc_id % 10 == 9)
					npc_id -= 8;
				NpcDataCfgPtr npc_cfg = kingdomwar_sys.getNpcData(npc_id);
				if (!npc_cfg || npc_cfg->npcList.empty()) return;
				armyNPC& npc = npc_cfg->npcList.front();
				ForEach(manList, it, atk_info.ptr->battleMan)
				{
					for (unsigned i = 0; i < characterNum; ++i)
						(*it)->battleAttri[i] += npc.initAttri[i];
				}
			}

			void ReportData::one2one()
			{
				result = data.One2One(atk_info.ptr, def_info.ptr, typeBattle::kingdomwar);
				if (result.res == resBattle::atk_win)
					++atk_info.win_streak;
				else
					++def_info.win_streak;
				//atk_info.cur_hp = getCurrentHp(atk_info.ptr);
				//def_info.cur_hp = getCurrentHp(def_info.ptr);
			}

			void ReportData::done()
			{
				data.Done(typeBattle::kingdomwar);
			}

			void ReportData::getInfo(qValue& q)
			{
				std::vector<ManDamage> damage = data.getDamageList();
				qValue atk_max_hp, atk_pre_hp;
				for (unsigned i = 0; i < atk_info.max_hp.size(); ++i)
				{
					atk_max_hp << atk_info.max_hp[i];
					atk_pre_hp << atk_info.pre_hp[i];
				}
				qValue def_max_hp, def_pre_hp;
				for (unsigned i = 0; i < def_info.max_hp.size(); ++i)
				{
					def_max_hp << def_info.max_hp[i];
					def_pre_hp << def_info.pre_hp[i];
				}
				qValue atk_damage, def_damage;
 				for (unsigned i = 0; i < damage.size(); ++i)
 				{
					qValue atk_tmp;
					const ManDamage& d = damage[i];
					for (unsigned j = 0; j < atk_info.ptr->battleMan.size(); ++j)
					{
						if (atk_info.ptr->battleMan[j])
						{
							ManDamage::const_iterator it = d.find(atk_info.ptr->battleMan[j]->currentIdx);
							if (it != d.end())
								atk_tmp << it->second;
						}
					}
					atk_damage << atk_tmp;
					qValue def_tmp;
					for (unsigned j = 0; j < def_info.ptr->battleMan.size(); ++j)
					{
						if (def_info.ptr->battleMan[j])
						{
							ManDamage::const_iterator it = d.find(def_info.ptr->battleMan[j]->currentIdx);
							if (it != d.end())
								def_tmp << it->second;
						}
					}
					def_damage << def_tmp;
 				}
				q << path << (int)result.res
					<< atk_max_hp << atk_pre_hp << atk_damage << atk_info.win_streak
					<< def_max_hp << def_pre_hp << def_damage << def_info.win_streak;
			}

			IPlayer::IPlayer(playerDataPtr& d, int army_id, CityPtr& ptr)
				: ItemBase(ptr)
			{
				_pid = d->ID();
				_name = d->Name();
				_nation = d->Info().Nation();
				_army_id = army_id;
				_face = d->KingDomWarFM().face(_army_id);
				_equip = getEquipList(d->KingDomWarFM().getFM(army_id));
				_lv = d->LV();
			}

			mongo::BSONObj IPlayer::toBSON() const
			{
				return BSON("t" << (int)Player << "p" << _pid << "a" << _army_id);
			}

			void IPlayer::getInfo(qValue& q) const
			{
				q << (int)Player << _pid << _army_id << _name << _nation
					<< _face << equipQ(_equip);
			}

			void IPlayer::getManInfo(qValue& q) const
			{
				q << (int)Player << _pid << _army_id << _name << _nation;
				playerDataPtr d = player_mgr.getPlayer(_pid);
				if (!d) return;
				qValue tmp;
				d->KingDomWarFM().getManInfo(_army_id, tmp);
				q << tmp;
			}

			void IPlayer::getUpInfo(int type, qValue& q) const
			{
				q << (int)Player << _pid << _army_id;
				if (type == nCity::Up_Add 
					|| type == nCity::Up_Swap
					|| type == nCity::Up_ElecAttackPlayer)
					q << _name << _nation << _face << equipQ(_equip);
			}

			void IPlayer::getStateInfo(qValue& q, int state) const
			{
				q << (int)Player << _name << _lv << _nation << state;
			}

			void IPlayer::getTableInfo(qValue& q) const
			{
				playerDataPtr d = player_mgr.getPlayer(_pid);
				if (!d) return;
				q.addMember("na", _name);
				q.addMember("nt", _nation);
				q.addMember("lv", _lv);
				q.addMember("hp", d->KingDomWar().armyHp(_army_id));
				q.addMember("bv", d->KingDomWarFM().getBV(_army_id));
				qValue fm;
				d->KingDomWarFM().getFMInfo(_army_id, fm);
				q.addMember("fm", fm);
			}

			BattleInfo IPlayer::getBattleInfo()
			{
				playerDataPtr d = player_mgr.getPlayer(_pid);
				BattleInfo info;
				info.ptr = kingdomwar_sys.getBattlePtr(d, _army_id);
				for (unsigned i = 0; i < info.ptr->battleMan.size(); ++i)
				{
					mBattlePtr& mb = info.ptr->battleMan[i];
					if (mb->currentHP > 0)	
					{
						info.max_hp.push_back(mb->getTotalAttri(idx_hp));
						info.pre_hp.push_back(mb->currentHP);
					}
				}
				info.win_streak = d->KingDomWar().winStreak(_army_id);
				return info;
			}

			void IPlayer::resetHp(sBattlePtr& ptr)
			{
				playerDataPtr d = player_mgr.getPlayer(_pid);
				manList& ml = ptr->battleMan;
				for (unsigned i = 0; i < ml.size(); ++i)
				{
					if (!ml[i])
						continue;
					d->KingDomWar().setManHp(ml[i]->manID, ml[i]->currentHP);
				}
			}

			void IPlayer::tryUpHp()
			{
				playerDataPtr d = player_mgr.getPlayer(_pid);
				d->KingDomWar().tryUpHp(_army_id);
			}

			bool IPlayer::isDead()
			{
				playerDataPtr d = player_mgr.getPlayer(_pid);	
				return d->KingDomWar().isDead(_army_id);
			}

			void IPlayer::beDead(unsigned time, Json::Value& tips)
			{
				playerDataPtr d = player_mgr.getPlayer(_pid);	
				kingdomwar_sys.goBackMainCity(time, d, _army_id, tips);
			}

			void IPlayer::tickBattle(ReportDataPtr& rep_data, ItemPtr& target, bool atk_side)
			{
				playerDataPtr d = player_mgr.getPlayer(_pid);
				BattleInfo& b = atk_side? rep_data->atk_info : rep_data->def_info;

				// result
				int result = repResult(rep_data->result.res, atk_side);
				int star = rep_data->result.star;

				// exploit
				b.exploit = result == Win?
					kingdomwar_sys.winExploit(star) : kingdomwar_sys.loseExploit(star);

				// silver
				b.silver = kingdomwar_sys.battleSilver(d, result);
				int silver = b.silver;
				KingdomPtr kingdom_ptr = kingdom_sys.getData(d->Info().Nation());
				if (kingdom_ptr)
					silver += silver * (double)kingdom_ptr->getAddNum(Kingdom::CBoss) / 10000.0;

				// report declare
				qValue rw;
				if (b.exploit > 0)
				{
					qValue tmp;
					tmp.append(ACTION::exploit_coin);
					tmp.append(b.exploit);
					rw.append(tmp);
				}
				if (b.silver > 0)
				{
					qValue tmp;
					tmp.append(ACTION::silver);
					tmp.append(silver);
					rw.append(tmp);
				}
				rep_data->data.addReportdeclare(atk_side? "rwa" : "rwb", rw);

				// report path
				b.rep_id = d->KingDomWar().getReportID();
				std::string rpath = "kingdomwar/" + Common::toString(d->ID()) + "/" + b.rep_id;
				rep_data->data.addCopyField(rpath);
				if (rep_data->path == "")
					rep_data->path = rpath;
			}

			void IPlayer::doneBattle(ReportDataPtr& rep_data, ItemPtr& target, bool atk_side)
			{
				playerDataPtr d = player_mgr.getPlayer(_pid);
				BattleInfo& b = atk_side? rep_data->atk_info : rep_data->def_info;

				// man hp
				resetHp(b.ptr);

				// result
				int result = repResult(rep_data->result.res, atk_side);
				int star = rep_data->result.star;

				// exploit
				playerKingdomWar::ExploitReason = KingdomWar::Battle;
				d->Res().alterExploit(b.exploit);
				_city->addExploit(d->ID(), b.exploit);

				// army hp
				int hp_cost = result == Win?
					kingdomwar_sys.winHpCost(star) : kingdomwar_sys.loseHpCost(star);
				hp_cost = d->KingDomWar().alterArmyHp(_army_id, 0 - hp_cost);

				// silver
				d->Res().alterSilver(b.silver);

				// rep
				int pos = PosCity;
				int tips = repTips(result, d, _army_id);
				qValue rep;
				rep << (int)REP::BATTLE << rep_data->time << _city->id() << _army_id << _face << target->name() 
					<< target->nation() << target->type() << pos << result << b.exploit << tips 
					<< hp_cost << b.silver << b.rep_id;
				d->KingDomWar().addReport(rep, result, pos, _army_id);
			}

			void IPlayer::enter(unsigned time)
			{
				playerDataPtr d = player_mgr.getPlayer(_pid);
				if (!d)	return;

				d->KingDomWarPos().sign_update(_army_id);
			}

			int IPlayer::tickElecAttack(unsigned time)
			{
				playerDataPtr d = player_mgr.getPlayer(_pid);
				if (!d)	return 0;
				
				int result = Lose;

				int silver = kingdomwar_sys.battleSilver(d, result);
				silver = d->Res().alterSilver(silver);

				int exploit = kingdomwar_sys.elecAttackExploit();
				playerKingdomWar::ExploitReason = KingdomWar::Battle;
				d->Res().alterExploit(exploit);
				_city->addExploit(d->ID(), exploit);

				int hp = kingdomwar_sys.elecAttackHp();
				hp = d->KingDomWar().alterArmyHp(_army_id, 0 - hp);

				int side = d->Info().Nation() == _city->nation()? Left : Right;
				
				qValue rep;
				rep << (int)REP::ELECATTACK << time << _city->id() << _army_id << _face
					<< side << exploit << hp << silver;
				d->KingDomWar().addShadowReport(rep, Lose);

				int man_hp = d->KingDomWarFM().getCurrentHp(_army_id);
				beDead(time, JARRAY((int)TIPS::ELECATTACK << _city->id() << side));
				return man_hp;
			}

			INpc::INpc(NpcDataPtr npc_data, CityPtr& ptr)
				: ItemBase(ptr), _data(npc_data)
			{
			}

			mongo::BSONObj INpc::toBSON() const
			{
				return BSON("t" << _data->type() << "i" << _data->id());
			}

			inline int INpc::face() const
			{
				return _data->npcData()->npcList.front().npcID;
			}

			inline int INpc::lv() const
			{
				return _data->npcData()->mapLevel;
			}

			void INpc::getInfo(qValue& q) const
			{
				q << _data->type() << _data->id() << face() << nation();
			}

			void INpc::getManInfo(qValue& q) const
			{
				q << _data->type() << _data->id();
				qValue tmp;
				_data->getManInfo(tmp);
				q << tmp << nation();
			}

			void INpc::getUpInfo(int type, qValue& q) const
			{
				q << _data->type() << _data->id();
				if (type == nCity::Up_Add 
					|| type == nCity::Up_Swap
					|| type == nCity::Up_ElecAttackPlayer)
					q << face() << nation();
			}

			void INpc::getStateInfo(qValue& q, int state) const
			{
				q << _data->type() << face() << lv() << nation() << state;
			}

			void INpc::getTableInfo(qValue& q) const
			{
				q.addMember("na", name());
				q.addMember("nt", nation());
				q.addMember("lv", lv());
				q.addMember("hp", _data->hp());
				q.addMember("bv", _data->bv());
				qValue fm;
				_data->fmInfo(fm);
				q.addMember("fm", fm);
			}

			int INpc::tickElecAttack(unsigned time)
			{
				int side = nation() == _city->nation()? Left : Right;
				beDead(time, JARRAY((int)TIPS::ELECATTACK << _city->id() << side));
				return _data->manHp();
			}


			void INpc::beDead(unsigned time, Json::Value& tips)
			{
				_data->setDead(time, tips);
			}

			void INpc::tickBattle(ReportDataPtr& rep_data, ItemPtr& target, bool atk_side)
			{
				qValue rw;
				rep_data->data.addReportdeclare(atk_side? "rwa" : "rwb", rw);
			}

			void INpc::doneBattle(ReportDataPtr& rep_data, ItemPtr& target, bool atk_side)
			{
				// result
				int result = repResult(rep_data->result.res, atk_side);
				int star = rep_data->result.star;

				// hp
				int hp_cost = result == Win?
					kingdomwar_sys.winHpCost(star) : kingdomwar_sys.loseHpCost(star);
				hp_cost = _data->alterHp(0 - hp_cost);

				// man_hp
				_data->resetManHp(atk_side? rep_data->atk_info.ptr : rep_data->def_info.ptr);
			}

			BattleInfo INpc::getBattleInfo()
			{
				BattleInfo info;
				info.ptr = _data->getBattlePtr();
				for (unsigned i = 0; i < info.ptr->battleMan.size(); ++i)
				{
					mBattlePtr& mb = info.ptr->battleMan[i];
					if (mb->currentHP > 0)	
					{
						info.max_hp.push_back(mb->getTotalAttri(idx_hp));
						info.pre_hp.push_back(mb->currentHP);
					}
				}
				info.win_streak = 0;
				return info;
			}

			IShadow::IShadow(ShadowDataPtr data, CityPtr& ptr)
				: ItemBase(ptr), _data(data)
			{
			}

			mongo::BSONObj IShadow::toBSON() const
			{
				return BSON("t" << (int)Shadow << "i" << _data->id());
			}

			const BattleEquipList& IShadow::equipList() const
			{
				static BattleEquipList eq;
				for (unsigned i = 0; i < _data->data()->battleMan.size(); ++i)
				{
					const mBattlePtr& ptr = _data->data()->battleMan[i];
					return ptr->equipList;
				}
				return eq;
			}

			inline int IShadow::face() const
			{
				return _data->face();
			}

			void IShadow::getInfo(qValue& q) const
			{
				q << (int)Shadow << _data->id() << name() << nation() << face() << equipQ(equipList()) << ownID();
			}

			void IShadow::getManInfo(qValue& q) const
			{
				q << (int)Shadow << _data->id() << name() << nation();
				qValue tmp;
				_data->getManInfo(tmp);
				q << tmp << ownID();
			}

			void IShadow::getUpInfo(int type, qValue& q) const
			{
				q << (int)Shadow << _data->id();
				if (type == nCity::Up_Add 
					|| type == nCity::Up_Swap
					|| type == nCity::Up_ElecAttackPlayer)
					q << name() << nation() << face() << equipQ(equipList()) << ownID();
			}

			inline int IShadow::lv() const
			{
				return _data->data()->playerLevel;
			}

			void IShadow::getStateInfo(qValue& q, int state) const
			{
				q <<  (int)Shadow << name() << lv() << nation() << state;
			}

			void IShadow::getTableInfo(qValue& q) const
			{
				q.addMember("na", name());
				q.addMember("nt", nation());
				q.addMember("lv", lv());
				q.addMember("hp", _data->hp());
				q.addMember("bv", _data->bv());
				qValue fm;
				_data->fmInfo(fm);
				q.addMember("fm", fm);
			}

			void IShadow::beDead(unsigned time, Json::Value& tips)
			{
				_data->setDead(time, tips);
			}

			void IShadow::tickBattle(ReportDataPtr& rep_data, ItemPtr& target, bool atk_side)
			{
				playerDataPtr d = player_mgr.getPlayer(ownID());
				BattleInfo& b = atk_side? rep_data->atk_info : rep_data->def_info;

				// result
				int result = repResult(rep_data->result.res, atk_side);
				int star = rep_data->result.star;

				// exploit
				b.exploit = result == Win?
					kingdomwar_sys.winExploit(star) : kingdomwar_sys.loseExploit(star);

				// silver
				b.silver = 100;

				// report declare
				qValue rw;
				if (b.exploit > 0)
				{
					qValue tmp;
					tmp.append(ACTION::exploit_coin);
					tmp.append(b.exploit);
					rw.append(tmp);
				}
				if (b.silver > 0)
				{
					qValue tmp;
					tmp.append(ACTION::silver);
					tmp.append(b.silver);
					rw.append(tmp);
				}
				rep_data->data.addReportdeclare(atk_side? "rwa" : "rwb", rw);

				// report path
				b.rep_id = d->KingDomWar().getReportID();
				std::string rpath = "kingdomwar/" + Common::toString(d->ID()) + "/" + b.rep_id;
				rep_data->data.addCopyField(rpath);
				if (rep_data->path == "")
					rep_data->path = rpath;
			}

			void IShadow::doneBattle(ReportDataPtr& rep_data, ItemPtr& target, bool atk_side)
			{
				playerDataPtr d = player_mgr.getPlayer(ownID());
				BattleInfo& b = atk_side? rep_data->atk_info : rep_data->def_info;

				// result
				int result = repResult(rep_data->result.res, atk_side);
				int star = rep_data->result.star;

				// exploit
				playerKingdomWar::ExploitReason = KingdomWar::Battle;
				d->Res().alterExploit(b.exploit);
				_city->addExploit(d->ID(), b.exploit);

				// silver
				d->Res().alterSilver(b.silver);

				// hp
				int hp_cost = result == Win?
					kingdomwar_sys.winHpCost(star) : kingdomwar_sys.loseHpCost(star);
				hp_cost = _data->alterHp(0 - hp_cost);
				
				// rep
				int pos = PosCity;
				int tips = -1;//repTips(result, d, _army_id);
				qValue rep;
				rep << (int)REP::BATTLE << rep_data->time << _city->id() << -1 << name() << target->name() 
					<< target->nation() << target->type() << pos << result << b.exploit << tips 
					<< hp_cost << b.silver << b.rep_id;
				d->KingDomWar().addShadowReport(rep, result);
			}

			int IShadow::tickElecAttack(unsigned time)
			{
				playerDataPtr d = player_mgr.getPlayer(ownID());
				if (!d)	return 0;

				int silver = kingdomwar_sys.battleSilver(d, Lose);
				silver = d->Res().alterSilver(silver);

				int exploit = kingdomwar_sys.elecAttackExploit();
				playerKingdomWar::ExploitReason = KingdomWar::Battle;
				d->Res().alterExploit(exploit);
				_city->addExploit(d->ID(), exploit);

				int hp = _data->hp();
				//hp = d->KingDomWar().alterArmyHp(_army_id, hp);

				int side = d->Info().Nation() == _city->nation()? Left : Right;

				qValue rep;
				rep << (int)REP::ELECATTACK << time << _city->id() << -1 << name() 
					<< side << exploit << hp << silver;
				d->KingDomWar().addShadowReport(rep, Lose);

				beDead(time, JARRAY((int)TIPS::ELECATTACK << _city->id() << side));
				return _data->manHp();
			}

			BattleInfo IShadow::getBattleInfo()
			{
				BattleInfo info;
				info.ptr = _data->getBattlePtr();
				for (unsigned i = 0; i < info.ptr->battleMan.size(); ++i)
				{
					mBattlePtr& mb = info.ptr->battleMan[i];
					if (mb->currentHP > 0)	
					{
						info.max_hp.push_back(mb->getTotalAttri(idx_hp));
						info.pre_hp.push_back(mb->currentHP);
					}
				}
				info.win_streak = 0;
				return info;
			}

			IShadowNpc::IShadowNpc(ShadowNpcDataPtr data, CityPtr& ptr)
				: ItemBase(ptr), _data(data)
			{
			}

			mongo::BSONObj IShadowNpc::toBSON() const
			{
				return BSON("t" << _data->type() << "i" << _data->id());
			}

			inline int IShadowNpc::lv() const
			{
				return _data->npcData()->mapLevel;
			}

			void IShadowNpc::getInfo(qValue& q) const
			{
				q << _data->type() << _data->id() << face() << nation() << name() << ownID();
			}

			void IShadowNpc::getManInfo(qValue& q) const
			{
				q << _data->type() << _data->id();
				qValue tmp;
				_data->getManInfo(tmp);
				q << tmp << nation() << name() << ownID();
			}

			void IShadowNpc::getUpInfo(int type, qValue& q) const
			{
				q << _data->type() << _data->id();
				if (type == nCity::Up_Add 
					|| type == nCity::Up_Swap
					|| type == nCity::Up_ElecAttackPlayer)
					q << face() << nation() << name() << ownID();
			}

			void IShadowNpc::getStateInfo(qValue& q, int state) const
			{
				q << _data->type() << name() << lv() << nation() << state;
			}

			void IShadowNpc::getTableInfo(qValue& q) const
			{
				q.addMember("na", name());
				q.addMember("nt", nation());
				q.addMember("lv", lv());
				q.addMember("hp", _data->hp());
				q.addMember("bv", _data->bv());
				qValue fm;
				_data->fmInfo(fm);
				q.addMember("fm", fm);
			}

			void IShadowNpc::beDead(unsigned time, Json::Value& tips)
			{
				_data->setDead(time, tips);
			}

			void IShadowNpc::tickBattle(ReportDataPtr& rep_data, ItemPtr& target, bool atk_side)
			{
				playerDataPtr d = player_mgr.getPlayer(ownID());
				BattleInfo& b = atk_side? rep_data->atk_info : rep_data->def_info;

				// result
				int result = repResult(rep_data->result.res, atk_side);
				int star = rep_data->result.star;

				// exploit
				b.exploit = result == Win?
					kingdomwar_sys.winExploit(star) : kingdomwar_sys.loseExploit(star);

				// silver
				b.silver = 100;

				// report declare
				qValue rw;
				if (b.exploit > 0)
				{
					qValue tmp;
					tmp.append(ACTION::exploit_coin);
					tmp.append(b.exploit);
					rw.append(tmp);
				}
				if (b.silver > 0)
				{
					qValue tmp;
					tmp.append(ACTION::silver);
					tmp.append(b.silver);
					rw.append(tmp);
				}
				rep_data->data.addReportdeclare(atk_side? "rwa" : "rwb", rw);

				// report path
				b.rep_id = d->KingDomWar().getReportID();
				std::string rpath = "kingdomwar/" + Common::toString(d->ID()) + "/" + b.rep_id;
				rep_data->data.addCopyField(rpath);
				if (rep_data->path == "")
					rep_data->path = rpath;
			}

			inline int IShadowNpc::face() const
			{
				return _data->npcData()->npcList.front().npcID;
			}

			void IShadowNpc::doneBattle(ReportDataPtr& rep_data, ItemPtr& target, bool atk_side)
			{
				playerDataPtr d = player_mgr.getPlayer(ownID());
				BattleInfo& b = atk_side? rep_data->atk_info : rep_data->def_info;

				// result
				int result = repResult(rep_data->result.res, atk_side);
				int star = rep_data->result.star;

				// exploit
				playerKingdomWar::ExploitReason = KingdomWar::Battle;
				d->Res().alterExploit(b.exploit);
				_city->addExploit(d->ID(), b.exploit);

				// silver
				d->Res().alterSilver(b.silver);

				// man_hp
				_data->resetManHp(atk_side? rep_data->atk_info.ptr : rep_data->def_info.ptr);

				// hp
				int hp_cost = result == Win?
					kingdomwar_sys.winHpCost(star) : kingdomwar_sys.loseHpCost(star);
				hp_cost = _data->alterHp(0 - hp_cost);
				
				// rep
				int pos = PosCity;
				int tips = -1;//repTips(result, d, _army_id);
				qValue rep;
				rep << (int)REP::BATTLE << rep_data->time << _city->id() << -1 << name() << target->name() 
					<< target->nation() << target->type() << pos << result << b.exploit << tips 
					<< hp_cost << b.silver << b.rep_id;
				d->KingDomWar().addShadowReport(rep, result);
			}

			int IShadowNpc::tickElecAttack(unsigned time)
			{
				playerDataPtr d = player_mgr.getPlayer(ownID());
				if (!d)	return 0;

				int silver = kingdomwar_sys.battleSilver(d, Lose);
				silver = d->Res().alterSilver(silver);

				int exploit = kingdomwar_sys.elecAttackExploit();
				playerKingdomWar::ExploitReason = KingdomWar::Battle;
				d->Res().alterExploit(exploit);
				_city->addExploit(d->ID(), exploit);

				int hp = _data->hp();

				int side = d->Info().Nation() == _city->nation()? Left : Right;

				qValue rep;
				rep << (int)REP::ELECATTACK << time << _city->id() << -1 << name() 
					<< side << exploit << hp << silver;
				d->KingDomWar().addShadowReport(rep, Lose);

				beDead(time, JARRAY((int)TIPS::ELECATTACK << _city->id() << side));
				return _data->manHp();
			}

			BattleInfo IShadowNpc::getBattleInfo()
			{
				BattleInfo info;
				info.ptr = _data->getBattlePtr();
				for (unsigned i = 0; i < info.ptr->battleMan.size(); ++i)
				{
					mBattlePtr& mb = info.ptr->battleMan[i];
					if (mb->currentHP > 0)	
					{
						info.max_hp.push_back(mb->getTotalAttri(idx_hp));
						info.pre_hp.push_back(mb->currentHP);
					}
				}
				info.win_streak = 0;
				return info;
			}

			ItemCounter::ItemCounter(CityPtr ptr)
				: _city(ptr)
			{
				_num.assign(Kingdom::nation_num + 1, 0);
			}

			void ItemCounter::push(ItemPtr ptr)
			{
				int idx = ptr->type() == Npc?
					Kingdom::nation_num : ptr->nation();
				++_num[idx];
				if (ptr->type() == Player)
				{
					PlayerPtr pptr = upCast<IPlayer>(ptr);
					pushPlayer(_player_map, pptr);
				}
				if (_city->onFired())
					BattleNumMgr::shared().addUp(_city);
			}

			void ItemCounter::pop(ItemPtr ptr)
			{
				int idx = ptr->type() == Npc?
					Kingdom::nation_num : ptr->nation();
				--_num[idx];
				if (ptr->type() == Player)
				{
					PlayerPtr pptr = upCast<IPlayer>(ptr);
					popPlayer(_player_map, pptr);
				}
				if (_city->onFired())
					BattleNumMgr::shared().addUp(_city);
			}

			void ItemCounter::clear()
			{

			}

			bool ItemCounter::pushPlayer(PlayerMap& cmap, PlayerPtr& ptr)
			{
				PlayerMap::iterator it = cmap.find(ptr->pid());
				if (it == cmap.end())
				{
					cmap[ptr->pid()] = PlayerList(1, ptr); 
					return true;
				}
				PlayerList& vec = it->second;
				ForEach(PlayerList, itp, vec)
				{
					if ((*itp) == ptr)
						return false;
				}
				vec.push_back(ptr);
				return true;
			}

			bool ItemCounter::popPlayer(PlayerMap& cmap, PlayerPtr& ptr)
			{
				PlayerMap::iterator it = cmap.find(ptr->pid());
				if (it == cmap.end())
					return false;
				PlayerList& vec = it->second;
				ForEach(PlayerList, itp, vec)
				{
					if ((*itp) == ptr)
					{
						vec.erase(itp);
						if (vec.empty())
							cmap.erase(it);
						return true;
					}
				}
				return false;
			}

			void ItemCounter::updateName(playerDataPtr& d)
			{
				PlayerMap::iterator it = _player_map.find(d->ID());
				if (it == _player_map.end())
				{
					LogE << "kingdom war update name error: " << d->ID() << LogEnd;
					return;
				}
				PlayerList& vec = it->second;
				ForEach(PlayerList, itp, vec)
					(*itp)->alterName(d->Name());
			}

			ReadyQueue::ReadyQueue()
			{
				_real_size = 0;
			}

			ItemPtr ReadyQueue::find(int id, int& pos) const
			{
				for (unsigned i = 0; i < _queue.size(); ++i)
				{
					if (!_queue[i])
						continue;
					if (_queue[i]->id() != id) 
						continue;
					pos = i;
					return _queue[i];
				}
				return ItemPtr();
			}

			ItemPtr ReadyQueue::find(int pid, int army_id, int& pos) const
			{
				for (unsigned i = 0; i < _queue.size(); ++i)
				{
					if (!_queue[i])
						continue;
					PlayerPtr ptr = upCast<IPlayer>(_queue[i]);
					if (ptr && ptr->pid() == pid && ptr->armyId() == army_id)
					{
						pos = i;
						return _queue[i];
					}
				}
				return ItemPtr();
			}

			ItemPtr ReadyQueue::findFirst(int pid, int& pos) const
			{
				for (unsigned i = 0; i < _queue.size(); ++i)
				{
					if (!_queue[i])
						continue;
					PlayerPtr ptr = upCast<IPlayer>(_queue[i]);
					if (ptr && ptr->pid() == pid)
					{
						pos = i;
						return _queue[i];
					}
				}
				return ItemPtr();
			}

			ItemPtr ReadyQueue::front() const
			{
				for (unsigned i = 0; i < _queue.size(); ++i)
				{
					if (!_queue[i])
						continue;
					return _queue[i];
				}
				return ItemPtr();
			}

			bool ReadyQueue::pop(const ItemPtr& ptr)
			{
				int pos = 0;
				for (; pos < _queue.size(); ++pos)
				{
					if (ptr == _queue[pos])
						break;
				}
				if (pos == _queue.size())
					return false;
				pop(pos);
				return true;
			}

			unsigned ReadyQueue::nullNum() const
			{
				for (unsigned i = 0; i < _queue.size(); ++i)
				{
					if (_queue[i])
						return i;
				}
				return _queue.size();
			}

			void ReadyQueue::popFrontNull()
			{
				for (unsigned i = 0; i < WaitQueueNum; ++i)
					_queue.pop_front();
			}

			ItemPtr ReadyQueue::pop(int pos)
			{
				if (pos >= _queue.size())
					return ItemPtr();
				if (!_queue[pos])
					return ItemPtr();
				ItemPtr ptr = _queue[pos];
				_queue[pos].reset();
				--_real_size;
				while(!_queue.empty() && !_queue.back())
				{
					_queue.pop_back();
				}
				unsigned null_num = nullNum();
				if (null_num >= WaitQueueNum)
					popFrontNull();
				return ptr;
			}

			ItemPtr ReadyQueue::popFront()
			{
				unsigned null_num = nullNum();
				return pop(null_num);
			}

			void ReadyQueue::pushBack(const ItemPtr& ptr)
			{
				_queue.push_back(ptr);
				++_real_size;
			}

			bool ReadyQueue::swap(const ItemPtr& in_ptr, int& in_pos, ItemPtr& out_ptr, int& out_pos)
			{
				unsigned pos = 0;
				for (; pos < _queue.size(); ++pos)
				{
					if (!_queue[pos])
						continue;
					if (_queue[pos]->type() == Npc)
					{
						out_ptr = _queue[pos];
						_queue[pos] = in_ptr;
						in_pos = pos;
						if (_queue.size() < ReadyMemNum)
						{
							_queue.push_back(out_ptr);
							out_pos = _queue.size() - 1;
							++_real_size;
						}
						else
						{
							out_pos = -1;
						}
						return true;
					}
				}
				if (_queue.size() < ReadyMemNum)
				{
					_queue.push_back(in_ptr);
					in_pos = _queue.size() - 1;
					out_ptr = ItemPtr();
					out_pos = -1;
					++_real_size;
					return true;
				}
				return false;
			}

			void ReadyQueue::clear()
			{
				_real_size = 0;
				_queue.clear();
			}

			void ReadyQueue::getInfo(qValue& q) const
			{
				for (unsigned i = 0; i < _queue.size(); ++i)
				{
					qValue tmp;
					if (_queue[i])
						_queue[i]->getInfo(tmp);
					q << tmp;
				}
			}

			void ReadyQueue::getStateInfo(qValue& q) const
			{
				for (unsigned i = 0; i < _queue.size(); ++i)
				{
					if (_queue[i])
					{
						qValue tmp;
						_queue[i]->getStateInfo(tmp, 1);
						q << tmp;
					}
				}
			}

			int ReadyQueue::getNpcPos() const
			{
				for(unsigned i = 0; i < _queue.size(); ++i)
				{
					if (_queue[i] && _queue[i]->type() == Npc)
						return i;
				}
				return _queue.size();
			}

			void ReadyQueue::toDead(unsigned cur_time, Json::Value& tips)
			{
				for (unsigned i = 0; i < _queue.size(); ++i)
				{
					if (_queue[i])
						_queue[i]->beDead(cur_time, tips);
				}
			}
		}

		BattleField::BattleField(CityPtr& ptr)
			: _city(ptr)
		{
			_state = Closed;	
			_tick_timer = 0;
			_next_tick_time = 0;
			_first_battle_nation = -1;
			_end_wait_times = 0;
			_battle_queues.assign(BattleQueueNum, BattleQueue());
			_wins.assign(Kingdom::nation_num + 1, -1);
			_counter = _city->_counter;
			_rep_data.assign(BattleQueueNum, nCity::ReportDataPtr());

			_atk_tower.assign(TowerMaxNum, nCity::TowerPtr());
			_def_tower.assign(TowerMaxNum, nCity::TowerPtr());
		}

		void BattleField::init()
		{
			loadDB();
			if (_state != Closed
				&& _state != Protected)
			{
				initReadyAttacker(0);
				initReadyDefender(0);
			}
			kingdomwar_sys.addUpdater(boostBind(BattleField::tick, upCast<BattleField>(shared_from_this())));
		}

		void BattleField::loadDB()
		{
			mongo::BSONObj key = BSON("ci" << _city->id());
			mongo::BSONObj obj = db_mgr.FindOne(DBN::dbKingdomWarCityBattle, key);
			if (obj.isEmpty())
				return;
			
			_state = obj["st"].Int();
			_next_tick_time = obj["ntt"].Int();
			checkNotEoo(obj["epm"])
			{
				std::vector<mongo::BSONElement> ele = obj["epm"].Array();
				for (unsigned i = 0; i < ele.size(); ++i)
					_exploit_map[ele[i]["i"].Int()] = ele[i]["e"].Int();
			}
			checkNotEoo(obj["atwr"])
			{
				std::vector<mongo::BSONElement> ele = obj["atwr"].Array();
				for (unsigned i = 0; i < ele.size(); ++i)
				{
					if (i >= TowerMaxNum)
						break;
					_atk_tower[i] = createTower(ele[i]);
				}
			}
			checkNotEoo(obj["dtwr"])
			{
				std::vector<mongo::BSONElement> ele = obj["dtwr"].Array();
				for (unsigned i = 0; i < ele.size(); ++i)
				{
					if (i >= TowerMaxNum)
						break;
					_def_tower[i] = createTower(ele[i]);
				}
			}
			if (_state == Protected)
			{
				setCloseTimer();
				return;
			}

			if (_state == Closed)
				return;
			_first_battle_nation = obj["fbn"].Int();
			{
				std::vector<mongo::BSONElement> ele = obj["bq"].Array();
				for (unsigned i = 0; i < ele.size(); ++i)
				{
					_battle_queues[i].next_battle_time = ele[i]["nbt"].Int();
					checkNotEoo(ele[i]["atk"])
					{
						_battle_queues[i].atk_ready_time = ele[i]["art"].Int();
						_battle_queues[i].atk_side = makeItem(ele[i]["atk"], Left);
					}
					checkNotEoo(ele[i]["def"])
					{
						_battle_queues[i].def_ready_time = ele[i]["drt"].Int();
						_battle_queues[i].def_side = makeItem(ele[i]["def"], Right);
					}
				}
			}
			{
				std::vector<mongo::BSONElement> ele = obj["ws"].Array();
				for (unsigned i = 0; i < Kingdom::nation_num; ++i)
					_wins[i] = ele[i].Int();
			}

			if (_state == Opened)
			{
				for (unsigned i = 0; i < BattleQueueNum; ++i)
				{
					if (_battle_queues[i].atk_side && _battle_queues[i].def_side)
						setBattleTimer(_battle_queues[i].next_battle_time, i);
				}
			}
			if (_state == StartWait)
				setOpenTimer();
			if (_state == AttackerWait)
				setAttackerWaitTimer();
			if (_state == DefenderWait)
				setDefenderWaitTimer();

			BattleNumMgr::shared().addOnFired(_city);
		}

		void BattleField::upTowerLifeTime(int id)
		{
			int side, pos;
			if (!getTowerPos(id, side, pos))
				return;
			nCity::TowerPtr& ptr = side == Left? _atk_tower[pos] : _def_tower[pos];
			PUSH_UPDATER(Creator<nCity::UpTower>::Create(side, pos, ptr));
		}

		int BattleField::alterTowerLifeTime(unsigned cur_time, playerDataPtr d, int id, int secs)
		{
			ForEach(TowerList, it, _atk_tower)
			{
				nCity::TowerPtr& ptr = *it;
				if (ptr && ptr->id() == id)
				{
					ptr->alterLifeTime(cur_time, secs);
					_sign_save();
					return res_sucess;
				}
			}
			ForEach(TowerList, it, _def_tower)
			{
				nCity::TowerPtr& ptr = *it;
				if (ptr && ptr->id() == id)
				{
					ptr->alterLifeTime(cur_time, secs);
					_sign_save();
					return res_sucess;
				}
			}
			return err_illedge;
		}

		nCity::ItemPtr BattleField::makeItem(const mongo::BSONElement& obj, int side)
		{
			int type = obj["t"].Int();
			switch(type)
			{
				case Player:
				{
					int pid = obj["p"].Int();
					int army_id = obj["a"].Int();
					return side == Left? 
						_city->getAttacker(pid, army_id) : _city->getDefender(pid, army_id);
				}
				case Npc:
				case ActiveNpc:
				case Shadow:
				case ShadowNpc:
				case ShadowAdvanceNpc:
				case ShadowDefenseNpc:
				{
					int id = obj["i"].Int();
					return side == Left? 
						_city->getAttacker(id) : _city->getDefender(id);
				}
				default:
					return nCity::ItemPtr();
			}
		}

		void BattleField::removeTower(unsigned cur_time, int id)
		{
			int side, pos;
			if (!getTowerPos(id, side, pos))
				return;
			PUSH_UPDATER(Creator<nCity::UpDelTower>::Create(side, pos))
			TowerMgr::shared().push(_city);
			nCity::TowerPtr& ptr = side == Left? _atk_tower[pos] : _def_tower[pos];
			ptr.reset();
			if (side == Left)
				toDefenderWait(cur_time);
			else
				toAttackerWait(cur_time);
		}

		int BattleField::callElecTower(unsigned cur_time, playerDataPtr d)
		{
			if (d->KingFight().getTitle() != Kingdom::GuoWang
				&& d->KingFight().getTitle() != Kingdom::ZuoChengXiang
				&& d->KingFight().getTitle() != Kingdom::YouChengXiang)
				return err_kingdomwar_title_error;
			if (NationParam::shared().callTowerTimesLimit(d->Info().Nation()))
				return err_kingdomwar_tower_times_not_enough;
			if (_state == Closed || _state == Protected || _state == StartWait)
				return err_kingdomwar_not_at_war;
			int side = d->Info().Nation() != _city->nation()?
				Left : Right;
			TowerList& tl = side == Left? _atk_tower : _def_tower;
			for (unsigned i = 0; i < tl.size(); ++i)
			{
				nCity::TowerPtr& ptr = tl[i];
				if (!ptr)
				{
					nCity::ElecTowerPtr nptr = Creator<nCity::ElecTower>::Create(cur_time, d->Info().Nation(), upCast<BattleField>(shared_from_this()));
					nptr->setDeadTimer(cur_time);
					nptr->setAttackTimer(cur_time);
					ptr = nptr;
					PUSH_UPDATER(Creator<nCity::UpTower>::Create(side, i, ptr));
					NationParam::shared().alterTowerTimes(d->Info().Nation());
					TowerMgr::shared().push(_city);
					Log(DBLOG::strLogKingdomWar, d, 14, _city->id());
					_sign_save();
					if (side == Left)
					{
						if (_state == DefenderWait)
						{
							if (!toAttackerWait(cur_time));
								changeState(Opened, cur_time);
						}
					}
					else
					{
						if (_state == AttackerWait)
							changeState(Opened, cur_time);
					}
					return res_sucess;
				}
			}
			return err_illedge;
		}

		nCity::TowerPtr BattleField::getElecAttackTower(unsigned tick_time, int side, int& pos) const
		{
			const TowerList& tl = side == Left? _atk_tower : _def_tower;	
			unsigned lt = 0;
			nCity::TowerPtr ptr;
			for (unsigned i = 0; i < tl.size(); ++i)
			{
				if (tl[i] && (lt == 0 || ptr->deadTime() < lt))
				{
					ptr = tl[i];
					lt = ptr->deadTime();
					pos = i;
				}
			}
			return ptr;
		}

		nCity::ItemPtr BattleField::getFightAttacker(playerDataPtr d)
		{
			nCity::ReadyQueue& atk_rq = d->Info().Nation() != _city->nation()? 
				_ready_attackers : _ready_defenders;
			int temp_pos;
			nCity::ItemPtr ptr = atk_rq.findFirst(d->ID(), temp_pos);
			if (ptr) return ptr;
			nCity::ItemList& atk_bp = d->Info().Nation() != _city->nation()? 
				_city->_attacker_backup : _city->_defender_backup;
			ForEachC(nCity::ItemList, it, atk_bp)
			{
				if ((*it)->id() == d->ID())
					return *it;
			}
			return nCity::ItemPtr();
		}

		void BattleField::popFightAttacker(const Json::Value& tips, nCity::ItemPtr& ptr)
		{
			nCity::ItemList& atk_bp = ptr->nation() != _city->nation()? 
				_city->_attacker_backup : _city->_defender_backup;
			ForEach(nCity::ItemList, it, atk_bp)
			{
				if ((*it) == ptr)
				{
					atk_bp.erase(it);
					return;
				}
			}
			nCity::ReadyQueue& atk_rq = ptr->nation() != _city->nation()? 
				_ready_attackers : _ready_defenders;
			int side = ptr->nation() != _city->nation()? 
				Left : Right;
			PUSH_UPDATER(Creator<nCity::UpDelReadyItem>::Create(side, tips, ptr))
			atk_rq.pop(ptr);
		}

		int BattleField::fight(unsigned time, playerDataPtr d)
		{
			if (_state != Opened)
				return err_illedge;

			int item_id = ItemConfig::shared().fightItemID();
			if (d->Items().itemNum(item_id) < 1)
				return err_item_not_enough;

			//nCity::ReadyQueue& atk_rq = d->Info().Nation() != _city->nation()? 
			//	_ready_attackers : _ready_defenders;
			nCity::ReadyQueue& def_rq = d->Info().Nation() != _city->nation()? 
				_ready_defenders : _ready_attackers;

			int temp_pos;
			nCity::ItemPtr atk_ptr = getFightAttacker(d);
			nCity::ItemPtr def_ptr = def_rq.front();
			if (!atk_ptr || !def_ptr)
				return err_illedge;

			d->Items().removeItem(item_id, 1);
			nCity::ReportDataPtr rep_data = Creator<nCity::ReportData>::Create(time, atk_ptr, def_ptr);
			rep_data->one2one();
			atk_ptr->tickBattle(rep_data, def_ptr, true);
			def_ptr->tickBattle(rep_data, atk_ptr, false);
			rep_data->done();
			atk_ptr->doneBattle(rep_data, def_ptr, true);
			def_ptr->doneBattle(rep_data, atk_ptr, false);
			addWins(rep_data->result.res, atk_ptr, def_ptr);

			ReturnParam::result = rep_data->result.res;
			ReturnParam::fight_army_id = upCast<nCity::IPlayer>(atk_ptr)->armyId();
			ReturnParam::fight_target_name = def_ptr->name();
			ReturnParam::fight_target_type = def_ptr->type();

			if (rep_data->result.res == resBattle::def_win
				|| atk_ptr->isDead())
			{
				int side = d->Info().Nation() != _city->nation()? Left : Right;
				Json::Value tips;
				if (rep_data->result.res == resBattle::def_win)
					tips.append((int)TIPS::DEFEATED);
				else
					tips.append((int)TIPS::HPEMPTY);
				tips.append(_city->id());
				popFightAttacker(tips, atk_ptr);
				//PUSH_UPDATER(Creator<nCity::UpDelReadyItem>::Create(side, tips, atk_ptr))
				//atk_rq.pop(atk_ptr);
				atk_ptr->beDead(time, tips);
				_counter->pop(atk_ptr);
			}
			if (rep_data->result.res == resBattle::atk_win
				|| def_ptr->isDead())
			{
				int side = d->Info().Nation() == _city->nation()? Left : Right;
				Json::Value tips;
				if (rep_data->result.res == resBattle::atk_win)
					tips.append((int)TIPS::DEFEATED);
				else
					tips.append((int)TIPS::HPEMPTY);
				tips.append(_city->id());
				PUSH_UPDATER(Creator<nCity::UpDelReadyItem>::Create(side, tips, def_ptr))
				def_rq.pop(def_ptr);
				def_ptr->beDead(time, tips);
				_counter->pop(def_ptr);
			}
			return res_sucess;
		}

		bool BattleField::getTowerPos(int id, int& side, int& pos)
		{
			for (pos = 0; pos < _atk_tower.size(); ++pos)
			{
				nCity::TowerPtr& ptr = _atk_tower[pos];
				if (ptr && ptr->id() == id)
				{
					side = Left;
					return true;
				}
			}
			for (pos = 0; pos < _def_tower.size(); ++pos)
			{
				nCity::TowerPtr& ptr = _def_tower[pos];
				if (ptr && ptr->id() == id)
				{
					side = Right;
					return true;
				}
			}
			return false;
		}

		void BattleField::tickElecAttack(unsigned tick_time, int id)
		{
			if (_state == Closed
				|| _state == Protected
				|| _state == StartWait)
				return;

			int side, pos;
			if (!getTowerPos(id, side, pos))
				return;
			nCity::ElecTowerPtr ptr = upCast<nCity::ElecTower>(side == Left? _atk_tower[pos] : _def_tower[pos]);
			if (!ptr)
				return;
			bool do_attack = false;
			do
			{
				nCity::ItemPtr iptr = getElecAttackPlayer(tick_time, side == Left? Right : Left);
				if (iptr)
				{
					int hp = iptr->tickElecAttack(tick_time);
					PUSH_UPDATER(Creator<nCity::UpElecAttackPlayer>::Create(side, pos, iptr, hp));
					_counter->pop(iptr);
					do_attack = true;
					break;
				}

				int tpos;
				nCity::TowerPtr tptr = getElecAttackTower(tick_time, side == Left? Right : Left, tpos);
				if (tptr)
				{
					PUSH_UPDATER(Creator<nCity::UpElecAttackTower>::Create(side, pos, tpos, (int)ElecAttackTowerDamage));
					tptr->alterLifeTime(tick_time, 0 - (int)ElecAttackTowerDamage);
					do_attack = true;
					break;
				}
			}
			while (false);

			if (!do_attack)
				return;

			if (side == Left)
				toAttackerWait(tick_time);
			else
				toDefenderWait(tick_time);
			return;
		}

		void BattleField::resetData()
		{
			if (_main_info.isEmpty())
				_updater.clear();
		}

		void BattleField::getInfo(qValue& q) const
		{
			if (_main_info.isEmpty())
				resetMainInfo();
			q = _main_info.Copy();
		}

		void BattleField::resetMainInfo() const
		{
			_main_info.toObject();
			qValue a;
			const std::vector<int>& num = _counter->num();
			for (unsigned i = 0; i < num.size(); ++i)
				a.append(num[i]);
			_main_info.addMember("a", a);
			_main_info.addMember("s", _state);
			_main_info.addMember("tt", _next_tick_time);
			qValue ra;
			_ready_attackers.getInfo(ra);
			_main_info.addMember("ra", ra);
			qValue rd;
			_ready_defenders.getInfo(rd);
			_main_info.addMember("rd", rd);
			qValue b;
			for (unsigned i = 0; i < BattleQueueNum; ++i)
			{
				qValue tmp_both;
				qValue tmp_atk;
				qValue tmp_def;
				if (_battle_queues[i].atk_side)
				{
					qValue tmp;
					_battle_queues[i].atk_side->getManInfo(tmp);
					tmp_atk.append(tmp);
					tmp_atk.append(_battle_queues[i].atk_ready_time);
				}
				if (_battle_queues[i].def_side)
				{
					qValue tmp;
					_battle_queues[i].def_side->getManInfo(tmp);
					tmp_def.append(tmp);
					tmp_def.append(_battle_queues[i].def_ready_time);
				}
				tmp_both.append(tmp_atk);
				tmp_both.append(tmp_def);
				b.append(tmp_both);
			}
			_main_info.addMember("b", b);
			qValue rep;
			for (unsigned i = 0; i < BattleQueueNum; ++i)
			{
				qValue tmp;
				if (_rep_data[i])
					_rep_data[i]->getInfo(tmp);
				rep.append(tmp);
			}
			_main_info.addMember("rep", rep);

			qValue atr;
			for (unsigned i = 0; i < _atk_tower.size(); ++i)
			{
				qValue tmp;
				if (_atk_tower[i])
					_atk_tower[i]->getInfo(tmp);
				atr.append(tmp);
			}
			_main_info.addMember("atr", atr);

			qValue dtr;
			for (unsigned i = 0; i < _def_tower.size(); ++i)
			{
				qValue tmp;
				if (_def_tower[i])
					_def_tower[i]->getInfo(tmp);
				dtr.append(tmp);
			}
			_main_info.addMember("dtr", dtr);
		}

		void BattleField::tick()
		{
			if (!_modified)
				return;
			_modified = false;

			//LogI << "size:" << _updater.size() << ", capacity:" << _updater.capacity() << LogEnd;

			_main_info.toObject();
			if (!_city->empty())
			{
				qValue mm(qJson::qj_object);
				qValue m;
				m.append(res_sucess);
				qValue qq(qJson::qj_object);
				qValue a;
				const std::vector<int>& num = _counter->num();
				for (unsigned i = 0; i < num.size(); ++i)
					a.append(num[i]);
				qq.addMember("a", a);
				qq.addMember("s", _state);
				qq.addMember("tt", _next_tick_time);
				qValue u;
				_updater.getInfo(u);
				qq.addMember("u", u);
				m.append(qq);
				mm.addMember(strMsg, m);
				detail::batchOnline(_city->getObserver(), mm, gate_client::kingdom_war_city_battle_update_resp);
			}
			_updater.clear();
		}

		void BattleField::changeState(int state, unsigned cur_time)
		{
			_state = state;
			_next_tick_time = cur_time;
			switch(_state)
			{
				case StartWait:
					if (PrimeState::shared())
						_next_tick_time = cur_time + (StartWaitInterval / StartWaitPrimeRate);
					else
						_next_tick_time = cur_time + StartWaitInterval;
					setOpenTimer();
					PUSH_UPDATER2(nCity::Up_State, _city)
					BattleNumMgr::shared().addOnFired(_city);
					break;
				case AttackerWait:
					if (PrimeState::shared())
						_next_tick_time = cur_time;
					else
						_next_tick_time = cur_time + getEndWaitInterval(_end_wait_times++);
					setAttackerWaitTimer();
					break;
				case DefenderWait:
					if (PrimeState::shared())
						_next_tick_time = cur_time;
					else
						_next_tick_time = cur_time + getEndWaitInterval(_end_wait_times++);
					setDefenderWaitTimer();
					break;
				case Protected:
					if (PrimeState::shared())
						_next_tick_time = cur_time + (ProtectedInterval / ProtectedPrimeRate);
					else
						_next_tick_time = cur_time + ProtectedInterval;
					setCloseTimer();
					PUSH_UPDATER2(nCity::Up_State, _city)
					BattleNumMgr::shared().rmOnFired(_city);
				case Closed:
					BattleNumMgr::shared().rmOnFired(_city);
				default:
					break;
			}
		}

		void BattleField::handleAddAttacker(unsigned tick_time)
		{
			_sign_save();
			if (_state == Closed)
				tickStartWait(tick_time);
			tryLoadReadyAttacker(tick_time);
			if (_state == StartWait)
				return;
			if (_state == DefenderWait) 
			{
				if (!toAttackerWait(tick_time))
					changeState(Opened, tick_time);
			}
			if (_state == Opened)
				tryMoveAttacker(tick_time);
		}

		void BattleField::handleAddDefender(unsigned tick_time)
		{
			if (_state == Closed
				|| _state == Protected)
				return;
			_sign_save();
			tryLoadReadyDefender(tick_time);
			if (_state == StartWait)
				return;
			if (_state == AttackerWait)
				changeState(Opened, tick_time);
			if (_state == Opened)
				tryMoveDefender(tick_time);
		}

		void BattleField::setBattleTimer(unsigned tick_time, int id)
		{
			++_battle_queues[id].battle_timer;
			_battle_queues[id].next_battle_time = tick_time;
			kingdomwar_sys.addTimer(tick_time, boostBind(BattleField::tickBattle, upCast<BattleField>(shared_from_this()), _battle_queues[id].battle_timer, tick_time, id));
		}

		void BattleField::setOpenTimer()
		{
			++_tick_timer;
			kingdomwar_sys.addTimer(_next_tick_time, boostBind(BattleField::tickOpen, upCast<BattleField>(shared_from_this()), _tick_timer, _next_tick_time));
		}

		void BattleField::setCloseTimer()
		{
			++_tick_timer;
			kingdomwar_sys.addTimer(_next_tick_time, boostBind(BattleField::tickCloseFromProtected, upCast<BattleField>(shared_from_this()), _tick_timer, _next_tick_time));
		}

		void BattleField::setAttackerWaitTimer()
		{
			++_tick_timer;
			kingdomwar_sys.addTimer(_next_tick_time, boostBind(BattleField::tickAttackerWait, upCast<BattleField>(shared_from_this()), _tick_timer, _next_tick_time));
		}

		void BattleField::setDefenderWaitTimer()
		{
			++_tick_timer;
			kingdomwar_sys.addTimer(_next_tick_time, boostBind(BattleField::tickDefenderWait, upCast<BattleField>(shared_from_this()), _tick_timer, _next_tick_time));
		}

		void BattleField::tickOpen(unsigned timer_id, unsigned tick_time)
		{
			if (timer_id != _tick_timer)
				return;
			_sign_save();
			startTowerTimer(tick_time);
			if (toAttackerWait(tick_time))
				return;
			changeState(Opened, tick_time);
			for (unsigned i = 0; i < BattleQueueNum; ++i)
			{
				if (!tryGetBoth(tick_time, i))
					break;
			}
		}

		void BattleField::startTowerTimer(unsigned cur_time)
		{
			ForEach(TowerList, it, _def_tower)
			{
				nCity::TowerPtr& ptr = *it;
				if (!ptr) continue;
				ptr->setDeadTimer(cur_time);
			}
		}

		bool BattleField::noTower(int side) const
		{
			const TowerList& tl = side == Left? _atk_tower : _def_tower;
			ForEachC(TowerList, it, tl)
			{
				if (*it)
					return false;
			}
			return true;
		}

		bool BattleField::toAttackerWait(unsigned tick_time)
		{
			if (_state == AttackerWait
				|| !noDefenders()
				|| !noTower(Right))
				return false;
			if (noAttackers()
				&& noTower(Left))
				return false;
			changeState(AttackerWait, tick_time);
			return true;
		}

		bool BattleField::toDefenderWait(unsigned tick_time)
		{
			if (_state == DefenderWait
				|| !noAttackers()
				|| !noTower(Left))
				return false;
			changeState(DefenderWait, tick_time);
			return true;
		}

		void BattleField::tickStartWait(unsigned tick_time)
		{
			changeState(StartWait, tick_time);
			initReadyDefender(tick_time);
		}

		void BattleField::initReadyDefender(unsigned tick_time)
		{
			while(_ready_defenders.size() < ReadyMemNum)
			{
				nCity::ItemPtr ptr = _city->getDefender();
				if (!ptr)
					break;
				_ready_defenders.pushBack(ptr);
			}
		}

		void BattleField::initReadyAttacker(unsigned tick_time)
		{
			while(_ready_attackers.size() < ReadyMemNum)
			{
				nCity::ItemPtr ptr = _city->getAttacker();
				if (!ptr)
					break;
				_ready_attackers.pushBack(ptr);
			}
		}

		bool BattleField::tryLoadReadyAttacker(unsigned tick_time)
		{
			bool ret = false;
			while(_ready_attackers.size() < ReadyMemNum)
			{
				if (!doLoadReadyAttacker(tick_time))
					break;
				ret = true;
			}
			return ret;
		}

		bool BattleField::doLoadReadyAttacker(unsigned tick_time)
		{
			nCity::ItemPtr ptr = _city->getAttacker();
			if (!ptr)
				return false;
			if (_first_battle_nation == -1)
				_first_battle_nation = ptr->nation();
			_ready_attackers.pushBack(ptr);
			PUSH_UPDATER(Creator<nCity::UpAdd>::Create((int)Left, ptr))
			return true;
		}

		bool BattleField::tryLoadReadyDefender(unsigned tick_time)
		{
			bool ret = false;
			int npc_pos = _ready_defenders.getNpcPos();
			while (npc_pos < _ready_defenders.size())
			{
				if (_city->_defender_backup.empty())
					break;
				doLoadReadyDefender(tick_time, npc_pos);
				++npc_pos;
				ret = true;
			}
			while(_ready_defenders.size() < ReadyMemNum)
			{
				if (!doLoadReadyDefender(tick_time, _ready_defenders.size()))
					break;
				ret = true;
			}
			return ret;
		}

		bool BattleField::doLoadReadyDefender(unsigned tick_time, int pos)
		{
			nCity::ItemPtr ptr = _city->getDefender();
			if (!ptr)
				return false;
			if (pos >= _ready_defenders.size() || ptr->type() == Npc)
			{
				_ready_defenders.pushBack(ptr);
				PUSH_UPDATER(Creator<nCity::UpAdd>::Create((int)Right, ptr))
			}
			else
			{
				int in_pos, out_pos;
				nCity::ItemPtr out_ptr;
				_ready_defenders.swap(ptr, in_pos, out_ptr, out_pos);
				PUSH_UPDATER(Creator<nCity::UpSwap>::Create((int)Right, in_pos, out_pos, ptr));
				if (out_pos == -1)
					_city->_npc_list.push_front(out_ptr);
			}
			return true;
		}

		bool BattleField::tryMoveAttacker(unsigned tick_time)
		{
			for (unsigned i = 0; i < BattleQueueNum; ++i)
			{
				if (!_battle_queues[i].atk_side
					&& _battle_queues[i].def_side)
				{
					return tryGetAttacker(tick_time, i);
				}
			}
			for (unsigned i = 0; i < BattleQueueNum; ++i)
			{
				if (!_battle_queues[i].atk_side
					&& !_battle_queues[i].def_side)
				{
					return tryGetBoth(tick_time, i);
				}
			}
			return false;
		}
		
		bool BattleField::tryMoveDefender(unsigned tick_time)
		{
			for (unsigned i = 0; i < BattleQueueNum; ++i)
			{
				if (_battle_queues[i].atk_side
					&& !_battle_queues[i].def_side)
				{
					return tryGetDefender(tick_time, i);
				}
			}
			for (unsigned i = 0; i < BattleQueueNum; ++i)
			{
				if (!_battle_queues[i].atk_side
					&& !_battle_queues[i].def_side)
				{
					return tryGetBoth(tick_time, i);
				}
			}
			return false;
		}

		bool BattleField::tryGetBoth(unsigned tick_time, int queue_id) 
		{
			if (_ready_attackers.empty()
				|| _ready_defenders.empty())
				return false;
				
			getPlayer(tick_time, Left, queue_id);
			getPlayer(tick_time, Right, queue_id);
			setBattleTimer(tick_time + BattleWaitInterval, queue_id);
			return true;
		}

		void BattleField::crossDefender(unsigned tick_time, int qid_from, int qid_to)
		{
			_battle_queues[qid_to].def_side = _battle_queues[qid_from].def_side;
			_battle_queues[qid_to].def_ready_time = tick_time + BattleWaitInterval;
			_battle_queues[qid_from].def_side.reset();
			PUSH_UPDATER(Creator<nCity::UpCross>::Create(qid_from, qid_to, tick_time + BattleWaitInterval))
		}

		bool BattleField::tryResetDefender(unsigned tick_time, int queue_id)
		{
			for (unsigned i = 0; i < BattleQueueNum; ++i)
			{
				if (i == queue_id)
					continue;
				if (_battle_queues[i].atk_side
					&& !_battle_queues[i].def_side)
				{
					crossDefender(tick_time, queue_id, i);
					setBattleTimer(tick_time + BattleWaitInterval, i);
					return true;
				}
			}
			return false;
		}

		nCity::ItemPtr BattleField::getElecAttackPlayerFromBattleQueue(int side)
		{
			if (side == Left)
			{
				for (unsigned i = 0; i < BattleQueueNum; ++i)
				{
					if (_battle_queues[i].atk_side
						&& !_battle_queues[i].def_side)
					{
						nCity::ItemPtr ptr = _battle_queues[i].atk_side;
						_battle_queues[i].atk_side.reset();
						return ptr;
					}
				}
				return nCity::ItemPtr();
			}
			else
			{
				for (unsigned i = 0; i < BattleQueueNum; ++i)
				{
					if (!_battle_queues[i].atk_side
						&& _battle_queues[i].def_side)
					{
						nCity::ItemPtr ptr = _battle_queues[i].def_side;
						_battle_queues[i].def_side.reset();
						return ptr;
					}
				}
				return nCity::ItemPtr();
			}
		}

		nCity::ItemPtr BattleField::getElecAttackPlayer(unsigned tick_time, int side)
		{
			if (side == Left)
			{
				if (_ready_attackers.empty())
					return getElecAttackPlayerFromBattleQueue(side);
				nCity::ItemPtr ptr = _ready_attackers.popFront();
				tryLoadReadyAttacker(tick_time);
				return ptr;
			}
			else
			{
				if (_ready_defenders.empty())
					return getElecAttackPlayerFromBattleQueue(side);
				nCity::ItemPtr ptr = _ready_defenders.popFront();
				tryLoadReadyDefender(tick_time);
				return ptr;
			}
		}

		void BattleField::getPlayer(unsigned tick_time, int side, int queue_id)
		{
			if (side == Left)
			{
				_battle_queues[queue_id].atk_side = _ready_attackers.popFront();
				_battle_queues[queue_id].atk_ready_time = tick_time + BattleWaitInterval;
				PUSH_UPDATER(Creator<nCity::UpMove>::Create(side, queue_id, _battle_queues[queue_id].atk_ready_time, _battle_queues[queue_id].atk_side))
				tryLoadReadyAttacker(tick_time);
			}
			else
			{
				_battle_queues[queue_id].def_side = _ready_defenders.popFront();
				_battle_queues[queue_id].def_ready_time = tick_time + BattleWaitInterval;
				PUSH_UPDATER(Creator<nCity::UpMove>::Create(side, queue_id, _battle_queues[queue_id].def_ready_time, _battle_queues[queue_id].def_side))
				tryLoadReadyDefender(tick_time);
			}
		}

		bool BattleField::tryGetAttacker(unsigned tick_time, int queue_id)
		{
			if (_ready_attackers.empty())
				return false;
			getPlayer(tick_time, Left, queue_id);
			setBattleTimer(tick_time + BattleWaitInterval, queue_id);
			return true;
		}

		bool BattleField::tryGetDefender(unsigned tick_time, int queue_id)
		{
			for (unsigned i = 0; i < BattleQueueNum; ++i)
			{
				if (queue_id == i)
					continue;
				if (!_battle_queues[i].atk_side
					&& _battle_queues[i].def_side)
				{
					crossDefender(tick_time, i, queue_id);
					setBattleTimer(tick_time + BattleWaitInterval, queue_id);
					return true;
				}
			}
			if (_ready_defenders.empty())
				return false;
			getPlayer(tick_time, Right, queue_id);
			setBattleTimer(tick_time + BattleWaitInterval, queue_id);
			return true;
		}

		void BattleField::addWins(int res, nCity::ItemPtr atk_ptr, nCity::ItemPtr def_ptr)
		{
			int atk_nation = atk_ptr->type() == Npc? Kingdom::nation_num : atk_ptr->nation();
			int def_nation = def_ptr->type() == Npc? Kingdom::nation_num : def_ptr->nation();
			if (_wins[atk_nation] == -1)
				_wins[atk_nation] = 0;
			if (_wins[def_nation] == -1)
				_wins[def_nation] = 0;
			if (res == resBattle::atk_win)
				++_wins[atk_nation];
			else
				++_wins[def_nation];
		}

		void BattleField::tryUpHp(int side, int idx, nCity::ItemPtr& ptr)
		{
			nCity::PlayerPtr nptr = upCast<nCity::IPlayer>(ptr);
			if (nptr)
			{
				nptr->tryUpHp();
				if ((side == Left && _battle_queues[idx].atk_side)
					|| (side == Right && _battle_queues[idx].def_side))
					PUSH_UPDATER(Creator<nCity::UpQueueItem>::Create(side, idx, ptr))
			}
		}

		void BattleField::doneBattle(unsigned timer_id, unsigned tick_time, int idx, nCity::ReportDataPtr& rep_data)
		{
			if (timer_id != _battle_queues[idx].battle_timer)
				return;
			_rep_data[idx].reset();
			_sign_save();

			nCity::ItemPtr& atk_ptr = _battle_queues[idx].atk_side;
			nCity::ItemPtr& def_ptr = _battle_queues[idx].def_side;
			atk_ptr->doneBattle(rep_data, def_ptr, true);
			def_ptr->doneBattle(rep_data, atk_ptr, false);
			addWins(rep_data->result.res, atk_ptr, def_ptr);
			nCity::ItemPtr atk_nptr = atk_ptr;
			nCity::ItemPtr def_nptr = def_ptr;
			
			if (rep_data->result.res == resBattle::def_win
				|| atk_ptr->isDead())
			{
				Json::Value tips;
				if (rep_data->result.res == resBattle::def_win)
					tips.append((int)TIPS::DEFEATED);
				else
					tips.append((int)TIPS::HPEMPTY);
				tips.append(_city->id());
				atk_ptr->beDead(tick_time, tips);
				PUSH_UPDATER(Creator<nCity::UpDel>::Create((int)Left, idx, tips, atk_ptr))
				_counter->pop(atk_ptr);
				atk_ptr.reset();
			}
			if (rep_data->result.res == resBattle::atk_win 
				|| def_ptr->isDead())
			{
				Json::Value tips;
				if (rep_data->result.res == resBattle::atk_win)
					tips.append((int)TIPS::DEFEATED);
				else
					tips.append((int)TIPS::HPEMPTY);
				tips.append(_city->id());
				def_ptr->beDead(tick_time, tips);
				PUSH_UPDATER(Creator<nCity::UpDel>::Create((int)Right, idx, tips, def_ptr))
				_counter->pop(def_ptr);
				def_ptr.reset();
			}

			_battle_queues[idx].in_battle = false;

			tryUpHp(Left, idx, atk_nptr);
			tryUpHp(Right, idx, def_nptr);

			if (!_battle_queues[idx].atk_side
				&& !_battle_queues[idx].def_side)
			{
				if (!tryGetBoth(tick_time, idx)
					&& !toDefenderWait(tick_time))
					toAttackerWait(tick_time);
				return;
			}

			if (!_battle_queues[idx].atk_side)
			{
				if (!tryResetDefender(tick_time, idx)
					&& !tryGetAttacker(tick_time, idx))
				{
					toDefenderWait(tick_time);
				}
				return;
			}

			if (!_battle_queues[idx].def_side)
			{
				if (!tryGetDefender(tick_time, idx))
					toAttackerWait(tick_time);
				return;
			}
		}

		void BattleField::tickBattle(unsigned timer_id, unsigned tick_time, int idx)
		{
			if (timer_id != _battle_queues[idx].battle_timer)
				return;

			_battle_queues[idx].in_battle = true;

			nCity::ItemPtr& atk_ptr = _battle_queues[idx].atk_side;
			nCity::ItemPtr& def_ptr = _battle_queues[idx].def_side;
			nCity::ReportDataPtr rep_data = Creator<nCity::ReportData>::Create(tick_time, atk_ptr, def_ptr);
			rep_data->one2one();
			atk_ptr->tickBattle(rep_data, def_ptr, true);
			def_ptr->tickBattle(rep_data, atk_ptr, false);
			rep_data->done();
			PUSH_UPDATER(Creator<nCity::UpReport>::Create(idx, rep_data))
			_rep_data[idx] = rep_data;
			unsigned battle_time = (unsigned)ceil(rep_data->data.getDamageList().size() * TimePerRound) + 2;
			battle_time *= kingdomwar_sys.battleRate();
			kingdomwar_sys.addTimer(tick_time + battle_time, boostBind(BattleField::doneBattle, upCast<BattleField>(shared_from_this()), timer_id, tick_time + battle_time, idx, rep_data));
			_sign_save();
		}

		int BattleField::getWinNation()
		{
			int win_nation = -1;
			int win_max = -1;
			for (unsigned i = 0; i < Kingdom::nation_num; ++i)
			{
				if (i == _city->nation())
					continue;
				if (_wins[i] > win_max)
				{
					win_max = _wins[i];
					win_nation = i;
				}
			}
			if (win_nation == -1)
				return _first_battle_nation;//_city->nation();
			for (unsigned i = 0; i < Kingdom::nation_num; ++i)
			{
				if (i == _city->nation())
					continue;
				if (i == win_nation)
					continue;
				if (_wins[i] == win_max)
					return _first_battle_nation;
			}
			return win_nation;
		}

		void BattleField::DebugInfo()
		{
			LogS << "******************************************" << LogEnd;
			LogS << "ID: " << _city->id() << ", State: " << _state << LogEnd;
			/*
			for (unsigned i = 0; i < BattleQueueNum; ++i)
			{
				std::ostringstream os;
				os << "[Queue " << i << "] ";
				if (_battle_queues[i].atk_side)
				{
					qValue tmp;
					_battle_queues[i].atk_side->getInfo(tmp);
					os << "atk: " << tmp.toIndentString();
				}
				if (_battle_queues[i].def_side)
				{
					qValue tmp;
					_battle_queues[i].def_side->getInfo(tmp);
					os << "def: " << tmp.toIndentString();
				}
				LogS << os.str() << LogEnd;
			}
			{
				std::ostringstream os;
				os << "ready attacker:";
				for (std::deque<nCity::ItemPtr>::iterator it = _ready_attackers.begin()
						; it != _ready_attackers.end(); ++it)
				{
					qValue tmp;
					(*it)->getInfo(tmp);
					os << tmp.toIndentString();
				}
				LogS << os.str() << LogEnd;
			}
			{
				std::ostringstream os;
				os << "ready defender:";
				for (std::deque<nCity::ItemPtr>::iterator it = _ready_defenders.begin()
						; it != _ready_defenders.end(); ++it)
				{
					qValue tmp;
					(*it)->getInfo(tmp);
					os << tmp.toIndentString();
				}
				LogS << os.str() << LogEnd;
			}
			{
				std::ostringstream os;
				os << "backup attacker:";
				ForEach(nCity::ItemList, it, _city->_attacker_backup)
				{
					qValue tmp;
					(*it)->getInfo(tmp);
					os << tmp.toIndentString();
				}
				LogS << os.str() << LogEnd;
			}
			{
				std::ostringstream os;
				os << "backup defender:";
				ForEach(nCity::ItemList, it, _city->_defender_backup)
				{
					qValue tmp;
					(*it)->getInfo(tmp);
					os << tmp.toIndentString();
				}
				LogS << os.str() << LogEnd;
			}
			{
				std::ostringstream os;
				os << "backup npc:";
				ForEach(nCity::ItemList, it, _city->_npc_list)
				{
					qValue tmp;
					(*it)->getInfo(tmp);
					os << tmp.toIndentString();
				}
				LogS << os.str() << LogEnd;
			}
			*/
			LogS << "******************************************" << LogEnd;
		}

		void BattleField::tickAttackerWait(unsigned timer_id, unsigned tick_time)
		{
			if (timer_id != _tick_timer)
				return;

			if (_state == AttackerWait)
			{
				for (std::deque<nCity::ItemPtr>::const_reverse_iterator it = _ready_attackers.getQueue().rbegin()
					; it != _ready_attackers.getQueue().rend(); ++it)
				{
					if (*it)
						_city->_attacker_backup.push_front(*it);
				}
				_ready_attackers.clear();
				for (unsigned i = 0; i < BattleQueueNum; ++i)
				{
					if (_battle_queues[i].atk_side)
					{
						_city->_attacker_backup.push_front(_battle_queues[i].atk_side);
						_battle_queues[i].atk_side.reset();
					}
				}
				int win_nation = getWinNation();
				resetTowerAfterBattle(tick_time, win_nation);
				Log(DBLOG::strLogKingdomWar, 4, _city->nation(), win_nation, _wins[0u] == -1? 0 : _wins[0u], _wins[1u] == -1? 0 : _wins[1u],  _wins[2u] == -1? 0 : _wins[2u], _city->id());
				tickProtected(tick_time, win_nation);
				_city->handleBattleResult(tick_time, true, win_nation);
				_sign_save();
			}
		}

		void BattleField::tickDefenderWait(unsigned timer_id, unsigned tick_time)
		{
			if (timer_id != _tick_timer)
				return;

			if (_state == DefenderWait)
			{
				//DebugInfo();
				for (std::deque<nCity::ItemPtr>::const_reverse_iterator it = _ready_defenders.getQueue().rbegin()
					; it != _ready_defenders.getQueue().rend(); ++it)
				{
					nCity::ItemPtr ptr = *it;
					if (ptr)
					{
						if (ptr->type() == Npc)
							_city->_npc_list.push_front(ptr);
						else
							_city->_defender_backup.push_front(ptr);
					}
				}
				_ready_defenders.clear();
				for (unsigned i = 0; i < BattleQueueNum; ++i)
				{
					if (_battle_queues[i].def_side)
					{
						nCity::ItemPtr& ptr = _battle_queues[i].def_side;
						if (ptr->type() == Npc)
							_city->_npc_list.push_front(ptr);
						else
							_city->_defender_backup.push_front(ptr);
						ptr.reset();
					}
				}
				resetTowerAfterBattle(tick_time, _city->nation());
				tickClose(tick_time);
				_city->handleBattleResult(tick_time, false);
				_sign_save();
			}
		}

		void BattleField::tickProtected(unsigned tick_time, int nation)
		{
			siegeInfo(true, tick_time);
			emailReward(nation);
			reset(tick_time);
			changeState(Protected, tick_time);
			_sign_save();
		}

		struct ExploitInfo
		{
			ExploitInfo(int p, unsigned e)
				: pid(p), exploit(e){}
			bool operator<(const ExploitInfo& rhs) const
			{
				return exploit > rhs.exploit;
			}
			int pid;
			unsigned exploit;
		};

		void BattleField::emailReward(int nation)
		{
			std::vector<ExploitInfo> ex;
			ForEach(ExploitMap, it, _exploit_map)
				ex.push_back(ExploitInfo(it->first, it->second));
			std::sort(ex.begin(), ex.end());
			Json::Value arg_name = Json::arrayValue;
			Json::Value arg_exploit = Json::arrayValue;
			for (unsigned i = 0; i < 3; ++i)
			{
				if (i >= ex.size())
					break;
				playerDataPtr d = player_mgr.getPlayer(ex[i].pid);
				if (!d)
					continue;
				arg_name.append(d->Name());
				arg_exploit.append(ex[i].exploit);
			}
			ForEach(std::vector<ExploitInfo>, it, ex)
			{
				playerDataPtr d = player_mgr.getPlayer(it->pid);
				if (!d) continue;
				int box_num = nCity::BoxConfig::shared().getGoldBoxNumByExploit(it->exploit);
				bool is_limit = (box_num > 0);
				int limit = d->KingDomWarBox().goldBoxLimit();
				if (limit < box_num)
					box_num = limit;
				Json::Value pl;
				pl.append(nation);
				pl.append(_city->id());
				pl.append(arg_name);
				pl.append(arg_exploit);
				if (box_num > 0)
				{
					pl.append(it->exploit);
					pl.append(box_num);
					Json::Value rw;
					Json::Value tmp;
					tmp.append(ACTION::item);
					tmp.append(nCity::BoxConfig::shared().getGoldBoxID());
					tmp.append(box_num);
					rw.append(tmp);
					EmailPtr e = email_sys.createPackage(EmailDef::KingdomWarCityReward, pl, rw);
					email_sys.sendToPlayer(it->pid, e);
					d->KingDomWarBox().alterGoldBoxNum(box_num);
				}
				else
				{
					EmailPtr e;
					if (is_limit)
					{
						pl.append(BoxLimit::shared().goldBoxTimes(d->LV()));
						e = email_sys.createSystem(EmailDef::KingdomWarCityReward2, pl);
					}
					else
					{
						pl.append(it->exploit);
						pl.append(nCity::BoxConfig::shared().minExploit());
						e = email_sys.createSystem(EmailDef::KingdomWarCityReward3, pl);
					}
					email_sys.sendToPlayer(it->pid, e);
				}
				Log(DBLOG::strLogKingdomWar, d, 16, _city->id(), it->exploit, box_num);
			}
			_exploit_map.clear();
		}

		void BattleField::siegeInfo(bool result, unsigned tick_time)
		{
			if (!_city->empty())
			{
				qValue mm(qJson::qj_object);
				qValue m;
				m.append(res_sucess);
				qValue q(qJson::qj_object);
				q.addMember("r", result);
				q.addMember("n", _city->nation());
				q.addMember("c", _city->id());
				{
					qValue w;
					for (unsigned i = 0; i <= Kingdom::nation_num; ++i)
						w.append(_wins[i]);
					q.addMember("w", w);
				}
				{
					qValue l;
					const std::vector<int>& num = _counter->num();
					for (unsigned i = 0; i <= Kingdom::nation_num; ++i)
						l.append(num[i]);
					q.addMember("l", l);
				}
				m.append(q);
				mm.addMember(strMsg, m);
				detail::batchOnline(_city->getObserver(), mm, gate_client::kingdom_war_siege_info_resp);
			}
		}

		void BattleField::tickCloseFromProtected(unsigned timer_id, unsigned tick_time)
		{
			if (timer_id != _tick_timer)
				return;
			changeState(Closed, tick_time);
			PUSH_UPDATER2(nCity::Up_State, _city)
			_city->handleEndProtected(tick_time);
			_sign_save();
		}
		
		void BattleField::tickClose(unsigned tick_time)
		{
			siegeInfo(false, tick_time);	
			//emailReward();
			changeState(Closed, tick_time);
			reset(tick_time);
			PUSH_UPDATER2(nCity::Up_State, _city)
			_sign_save();
		}

		void BattleField::clearTower(unsigned cur_time)
		{
			for (unsigned i = 0; i < _atk_tower.size(); ++i)
			{
				if (_atk_tower[i])
					_atk_tower[i]->setDead(cur_time);
			}
			for (unsigned i = 0; i < _def_tower.size(); ++i)
			{
				if (_def_tower[i])
					_def_tower[i]->setDead(cur_time);
			}
			_sign_save();
		}

		nCity::TowerPtr BattleField::moveTower(nCity::TowerPtr& ptr)
		{
			for (unsigned i = 0; i < _def_tower.size(); ++i)
			{
				if (!_def_tower[i])
				{
					_def_tower[i] = ptr;
					return ptr;
				}
			}
			return nCity::TowerPtr();
		}

		void BattleField::resetTowerAfterBattle(unsigned cur_time, int nation)
		{
			for (unsigned i = 0; i < _def_tower.size(); ++i)
			{
				nCity::TowerPtr& ptr = _def_tower[i];
				if (!ptr) continue;
				if (ptr->nation() != nation)
					ptr->setDead(cur_time);
				else
					ptr->stopDeadTimer(cur_time);
			}
			for (unsigned i = 0; i < _atk_tower.size(); ++i)
			{
				nCity::TowerPtr& ptr = _atk_tower[i];
				if (!ptr) continue;
				if (ptr->nation() == nation)
				{
					nCity::TowerPtr nptr = moveTower(ptr);
					ptr.reset();
					if (!nptr) continue;
					nptr->stopDeadTimer(cur_time);
				}
				else
					ptr->setDead(cur_time);
			}
			TowerMgr::shared().push(_city);
		}

		void BattleField::reset(unsigned cur_time)
		{
			_next_tick_time = 0;
			_first_battle_nation = -1;
			++_tick_timer;
			for (unsigned i = 0; i < BattleQueueNum; ++i)
				_battle_queues[i].battle_timer = 0;
			for (unsigned i = 0; i <= Kingdom::nation_num; ++i)
				_wins[i] = -1;
			_end_wait_times = 0;
			//_exploit_map.clear();
		}

		nCity::TowerPtr BattleField::createTower(const mongo::BSONElement& obj)
		{
			int type = obj["t"].Int();
			switch(type)
			{
				case nCity::ELECTOWER:
				{
					nCity::ElecTowerPtr ptr = Creator<nCity::ElecTower>::Create(obj, upCast<BattleField>(shared_from_this()));
					if (_state != Closed 
						&& _state != Protected)
						ptr->setDeadTimer();
					ptr->setAttackTimer();
					return ptr;
				}
				default:
					return nCity::TowerPtr();
			}
		}

		bool BattleField::_auto_save()
		{
			mongo::BSONObj key = BSON("ci" << _city->id());
			mongo::BSONObjBuilder obj;
			obj << "ci" << _city->id() << "st" << _state << "ntt" << _next_tick_time;
			if (!_exploit_map.empty())
			{
				mongo::BSONArrayBuilder b;
				ForEachC(ExploitMap, it, _exploit_map)
					b.append(BSON("i" << it->first << "e" << it->second));
				obj << "epm" << b.arr();
			}
			{
				mongo::BSONArrayBuilder b;
				ForEach(TowerList, it, _atk_tower)
				{
					if (*it)
						b.append((*it)->toBSON());
					else
						b.append(BSON("t" << (int)nCity::TOWER_MAX));
				}
				obj << "atwr" << b.arr();
			}
			{
				mongo::BSONArrayBuilder b;
				ForEach(TowerList, it, _def_tower)
				{
					if (*it)
						b.append((*it)->toBSON());
					else
						b.append(BSON("t" << (int)nCity::TOWER_MAX));
				}
				obj << "dtwr" << b.arr();
			}
			if (_state != Closed && _state != Protected)
			{
				obj << "fbn" << _first_battle_nation;
				{
					mongo::BSONArrayBuilder b;
					for (unsigned i = 0; i < BattleQueueNum; ++i)
					{
						mongo::BSONObjBuilder o;
						o << "nbt" << _battle_queues[i].next_battle_time;
						if (_battle_queues[i].atk_side)
							o << "atk" << _battle_queues[i].atk_side->toBSON() << "art" << _battle_queues[i].atk_ready_time;
						if (_battle_queues[i].def_side)
							o << "def" << _battle_queues[i].def_side->toBSON() << "drt" << _battle_queues[i].def_ready_time;
						b.append(o.obj());
					}
					obj << "bq" << b.arr();
				}
				{
					mongo::BSONArrayBuilder b;
					for (unsigned i = 0; i < Kingdom::nation_num; ++i)
						b.append(_wins[i]);
					obj << "ws" << b.arr();
				}
			}
			return db_mgr.SaveMongo(DBN::dbKingdomWarCityBattle, key, obj.obj());
		}

		void BattleField::_sign_save()
		{
			_auto_meta::_sign_save();
			_modified = true;
		}

		bool BattleField::noAttackers() const
		{
			for (unsigned i = 0; i < BattleQueueNum; ++i)
			{
				if (_battle_queues[i].atk_side)
					return false;
			}
			return _ready_attackers.empty();
		}

		bool BattleField::noDefenders() const
		{
			for (unsigned i = 0; i < BattleQueueNum; ++i)
			{
				if (_battle_queues[i].def_side)
					return false;
			}
			return _ready_defenders.empty();
		}

		bool BattleField::onFight(NpcDataPtr d)
		{
			if (d->nation() != _city->nation())
			{
				for (unsigned i = 0; i < BattleQueueNum; ++i)
				{
					if (_battle_queues[i].atk_side)
					{
						nCity::NpcPtr ptr = upCast<nCity::INpc>(_battle_queues[i].atk_side);
						if (ptr && ptr->id() == d->id())
							return true;
					}
				}
				int pos;
				return _ready_attackers.find(d->id(), pos) != nCity::ItemPtr();
			}
			else
			{
				for (unsigned i = 0; i < BattleQueueNum; ++i)
				{
					if (_battle_queues[i].def_side)
					{
						nCity::NpcPtr ptr = upCast<nCity::INpc>(_battle_queues[i].def_side);
						if (ptr && ptr->id() == d->id())
							return true;
					}
				}
				int pos;
				return _ready_defenders.find(d->id(), pos) != nCity::ItemPtr();
			}
		}
		
		int BattleField::upHpNumInBattle(playerDataPtr d, int army_id) const
		{
			for (unsigned i = 0; i < BattleQueueNum; ++i)
			{
				if (!_battle_queues[i].in_battle)
					continue;
				const nCity::ItemPtr& ptr =
					d->Info().Nation() == _city->nation()? _battle_queues[i].def_side : _battle_queues[i].atk_side;
				if (ptr)
				{
					nCity::PlayerPtr nptr = upCast<nCity::IPlayer>(ptr);
					if (nptr && nptr->pid() == d->ID() && nptr->armyId() == army_id)
					{
						nCity::ReportDataPtr rd = _rep_data[i];
						if (!rd) return -1;
						sBattlePtr ptr = 
							d->Info().Nation() == _city->nation()? rd->atk_info.ptr : rd->def_info.ptr;
						return getMaxHp(ptr) - getCurrentHp(ptr);
					}
				}
			}
			return -1;
		}

		bool BattleField::inBattle(playerDataPtr d, int army_id) const
		{
			for (unsigned i = 0; i < BattleQueueNum; ++i)
			{
				if (!_battle_queues[i].in_battle)
					continue;
				const nCity::ItemPtr& ptr =
					d->Info().Nation() == _city->nation()? _battle_queues[i].def_side : _battle_queues[i].atk_side;
				if (ptr)
				{
					nCity::PlayerPtr nptr = upCast<nCity::IPlayer>(ptr);
					if (nptr && nptr->pid() == d->ID() && nptr->armyId() == army_id)
						return true;
				}
			}
			return false;
		}

		bool BattleField::onFight(playerDataPtr& d, int army_id)
		{
			if (d->Info().Nation() != _city->nation())
			{
				for (unsigned i = 0; i < BattleQueueNum; ++i)
				{
					if (_battle_queues[i].atk_side)
					{
						nCity::PlayerPtr ptr = upCast<nCity::IPlayer>(_battle_queues[i].atk_side);
						if (ptr && ptr->pid() == d->ID() && ptr->armyId() == army_id)
							return true;
					}
				}
				int pos;
				return _ready_attackers.find(d->ID(), army_id, pos) != nCity::ItemPtr();
			}
			else
			{
				for (unsigned i = 0; i < BattleQueueNum; ++i)
				{
					if (_battle_queues[i].def_side)
					{
						nCity::PlayerPtr ptr = upCast<nCity::IPlayer>(_battle_queues[i].def_side);
						if (ptr && ptr->pid() == d->ID() && ptr->armyId() == army_id)
							return true;
					}
				}
				int pos;
				return _ready_defenders.find(d->ID(), army_id, pos) != nCity::ItemPtr();
			}
		}

		void BattleField::getItemList(qValue& q, int side)
		{
			int num = 0;
			qValue l;
			for (unsigned i = 0; i < BattleQueueNum; ++i)
			{
				if (side == Left)
				{
					if (_battle_queues[i].atk_side)
					{
						qValue tmp;
						_battle_queues[i].atk_side->getStateInfo(tmp, 1);
						l.append(tmp);
						++num;
					}
				}
				else
				{
					if (_battle_queues[i].def_side)
					{
						qValue tmp;
						_battle_queues[i].def_side->getStateInfo(tmp, 1);
						l.append(tmp);
						++num;
					}
				}
			}
			if (side == Left)
			{
				_ready_attackers.getStateInfo(l);
				num += _ready_attackers.realSize();
			}
			else
			{
				_ready_defenders.getStateInfo(l);
				num += _ready_defenders.realSize();
			}
			nCity::ItemList& list = side == Left? 
				_city->_attacker_backup : _city->_defender_backup;
			ForEachC(nCity::ItemList, it, list)
			{
				qValue tmp;
				(*it)->getStateInfo(tmp, 0);
				l.append(tmp);
			}
			num += list.size();
			if (side != 0)
			{
				ForEachC(nCity::ItemList, it, _city->_npc_list)
				{
					qValue tmp;
					(*it)->getStateInfo(tmp, 0);
					l.append(tmp);
				}
				num += _city->_npc_list.size();
			}
			q.addMember("n", num);
			q.addMember("l", l);
			q.addMember("s", side);
		}

		void BattleField::tickPrimeState(unsigned cur_time)
		{
			//if (PrimeState::shared().initTickPrimeState())
			//	return;
			if (_state == StartWait)
			{
				if (PrimeState::shared())
					_next_tick_time = cur_time + (_next_tick_time - cur_time) / StartWaitPrimeRate;
				else
					_next_tick_time = cur_time + (_next_tick_time - cur_time) * StartWaitPrimeRate;
				setOpenTimer();
				_sign_save();
			}
			if (_state == Protected)
			{
				if (PrimeState::shared())
					_next_tick_time = cur_time + (_next_tick_time - cur_time) / ProtectedPrimeRate;
				else
					_next_tick_time = cur_time + (_next_tick_time - cur_time) * ProtectedPrimeRate;
				setCloseTimer();
				PUSH_UPDATER2(nCity::Up_State, _city)
				_sign_save();
			}
			if (_state == AttackerWait)
			{
				if (PrimeState::shared())
				{
					_next_tick_time = cur_time;
					setAttackerWaitTimer();
					_sign_save();
				}
			}
			if (_state == DefenderWait)
			{
				if (PrimeState::shared())
				{
					_next_tick_time = cur_time;
					setDefenderWaitTimer();
					_sign_save();
				}
			}
			
			for (unsigned i = 0; i < _atk_tower.size(); ++i)
			{
				if (_atk_tower[i])
					_atk_tower[i]->tickPrimeState(cur_time);
			}
			for (unsigned i = 0; i < _def_tower.size(); ++i)
			{
				if (_def_tower[i])
					_def_tower[i]->tickPrimeState(cur_time);
			}
		}

		bool BattleField::match(const nCity::ItemPtr& ptr, int id, int army_id) const
		{
			if (!ptr || ptr->id() != id)
				return false;
			if (id > 0)
			{
				nCity::PlayerPtr nptr = upCast<nCity::IPlayer>(ptr);
				return (nptr && (nptr->armyId() == army_id));
			}
			return true;
		}

		nCity::ItemPtr BattleField::find(int id, int army_id) const
		{
			for (unsigned i = 0; i < _battle_queues.size(); ++i)
			{
				if (match(_battle_queues[i].atk_side, id, army_id))
					return _battle_queues[i].atk_side;
				if (match(_battle_queues[i].def_side, id, army_id))
					return _battle_queues[i].def_side;
			}
			int pos;
			if (id < 0)
			{
				nCity::ItemPtr ptr = _ready_attackers.find(id, pos);
				if (ptr) return ptr;
				ptr = _ready_defenders.find(id, pos);
				return ptr;
			}
			else
			{
				nCity::ItemPtr ptr = _ready_attackers.find(id, army_id, pos);
				if (ptr) return ptr;
				ptr = _ready_defenders.find(id, army_id, pos);
				return ptr;
			}
		}

		int BattleField::getTableInfo(qValue& q, int id, int army_id) const
		{
			ForEachC(nCity::ItemList, it, _city->_defender_backup)
			{
				if (match(*it, id, army_id))
				{
					(*it)->getTableInfo(q);
					return res_sucess;
				}
			}
			nCity::ItemPtr ptr = find(id, army_id);
			if (!ptr) return err_illedge;
			ptr->getTableInfo(q);
			return res_sucess;
		}

		void BattleField::clear(unsigned cur_time)
		{
			if (_state == Closed
				|| _state == Protected)
				return;
			changeState(Closed, cur_time);
			++_tick_timer;
			_next_tick_time = 0;
			_first_battle_nation = -1;
			for (unsigned i = 0; i <= Kingdom::nation_num; ++i)
				_wins[i] = -1;
			_ready_attackers.toDead(cur_time, JARRAY((int)TIPS::UNITY << _city->id()));
			_ready_attackers.clear();
			_ready_defenders.toDead(cur_time, JARRAY((int)TIPS::UNITY << _city->id()));
			_ready_defenders.clear();
			for (unsigned i = 0; i < BattleQueueNum; ++i)
			{
				_battle_queues[i].battle_timer = 0;
				if (_battle_queues[i].atk_side)
				{
					_battle_queues[i].atk_side->beDead(cur_time, JARRAY((int)TIPS::UNITY << _city->id()));
					_battle_queues[i].atk_side.reset();
				}
				if (_battle_queues[i].def_side)
				{
					_battle_queues[i].def_side->beDead(cur_time, JARRAY((int)TIPS::UNITY << _city->id()));
					_battle_queues[i].def_side.reset();
				}
			}
			clearTower(cur_time);
			_sign_save();
		}

		City::City(const Json::Value& info)
		{
			_id = info["id"].asInt();
			if (_id == MainCity[0] || _id == MainCity[1] || _id == MainCity[2])
				_is_main = true;
			else
				_is_main = false;

			_output.assign(Kingdom::nation_num + 1, 0);
			if (info["gold"].asInt() > 0)
			{
				_output_type = 0;
				_output[Kingdom::nation_num] = info["gold"].asInt();
			}
			if (info["silver"].asInt() > 0)
			{
				_output_type = 1;
				_output[Kingdom::nation_num] = info["silver"].asInt();
			}
			if (info["fame"].asInt() > 0)
			{
				_output_type = 2;
				_output[Kingdom::nation_num] = info["fame"].asInt();
			}
			if (info["merit"].asInt() > 0)
			{
				_output_type = 3;
				_output[Kingdom::nation_num] = info["merit"].asInt();
			}
			if (info["food"].asInt() > 0)
			{
				_output_type = 4;
				_output[Kingdom::nation_num] = info["food"].asInt();
			}

			_output_max = info["max"].asInt() * _output[Kingdom::nation_num];

			const Json::Value& npc_start = info["npc_start"];
			ForEachC(Json::Value, it, npc_start)
				_npc_start.push_back((*it).asInt());
			const Json::Value& npc_add = info["npc_add"];
			ForEachC(Json::Value, it, npc_add)
				_npc_add.push_back((*it).asInt());
			const Json::Value& npc_max= info["npc_max"];
			ForEachC(Json::Value, it, npc_max)
				_npc_max.push_back((*it).asInt());

			_buff_type = info["buff_type"].asInt();
			const Json::Value& buff_value = info["buff_value"];
			ForEachC(Json::Value, it, buff_value)
				_buff_value.push_back((*it).asInt());

			_sup_time = Common::gameTime();
			_sup_base = 0;
			_sup_rate = kingdomwar_sys.supRate();
			_belong_nation = info["belong"].asInt();

			_npc2_interval = info["npc2_interval"].asUInt();
			_npc2_num = info["npc2_num"].asUInt();
			_next_npc2_time = 0;
			_broadcast_1 = info["broadcast_1"].asInt();
			_broadcast_2 = info["broadcast_2"].asInt();
			_max_box_num = info["box_num"].asInt();
			_cur_box_num = 0;
		}

		int City::clientState() const
		{
			if (_battle_field->state() == Closed)
				return 0;
			if (_battle_field->state() == Protected)
				return 2;
			return 1;
		}

		bool City::boxState(playerDataPtr d) const
		{
			return (_cur_box_num > 0
				&& d->Info().Nation() == _nation
				&& (_get_box_players.find(d->ID()) == _get_box_players.end()));
		}

		void City::tryLoadPlayer(playerDataPtr& d, int army_id)
		{
			if (_is_main)
				return;
			nCity::PlayerPtr ptr = Creator<nCity::IPlayer>::Create(d, army_id, upCast<City>(shared_from_this()));
			if (_nation != d->Info().Nation())
				_attacker_backup.push_back(ptr);
			else
				_defender_backup.push_back(ptr);
			_counter->push(ptr);
		}

		TRYLOAD(Npc)
		TRYLOAD(Shadow)
		TRYLOAD(ShadowNpc)

		void City::init()
		{
			kingdomwar_sys.add5MinTicker(boostBind(City::tickOutput, upCast<City>(shared_from_this()), _1));
			kingdomwar_sys.add5MinTicker(boostBind(City::tickCreateNpc, upCast<City>(shared_from_this()), _1));
			if (_belong_nation != -1)
			{
				if (_next_npc2_time == 0)
					_next_npc2_time = (Common::gameTime() / _npc2_interval + 1) * _npc2_interval;
				kingdomwar_sys.addTimer(_next_npc2_time, boostBind(City::tickCreateActiveNpc, upCast<City>(shared_from_this()), _next_npc2_time));
			}

			_battle_field = Creator<BattleField>::Create(
				upCast<City>(shared_from_this()));
			_battle_field->init();
		}

		void City::getNumInfo(qValue& q) const
		{
			q << _id;
			const std::vector<int>& num = _counter->num();
			if (_nation == 0)
				q << (num[1] + num[2]) << (num[0] + num[3]);
			else if (_nation == 1)
				q << (num[0] + num[2]) << (num[1] + num[3]);
			else if (_nation == 2)
				q << (num[0] + num[1]) << (num[2] + num[3]);
			else
				q << (num[0] + num[1] + num[2]) << num[3];
		}

		void City::loadDB()
		{
			_counter = Creator<nCity::ItemCounter>::Create(
				upCast<City>(shared_from_this()));
			mongo::BSONObj key = BSON("ci" << _id);
			mongo::BSONObj obj = db_mgr.FindOne(DBN::dbKingdomWarCityBase, key);
			if (obj.isEmpty())
			{
				_state_helper = Closed;
				initNation();
				initMaxNpc(Common::gameTime());
				_sign_save();
				return;
			}

			bool reset = false;
			if (!obj["reset"].eoo() && obj["reset"].Bool())
			{
				initNation();
				initMaxNpc(Common::gameTime());
				_sign_save();
			}
			else
				initNation(obj["nt"].Int());

			{
				std::vector<mongo::BSONElement> ele = obj["o"].Array();
				for (unsigned i = 0; i < Kingdom::nation_num; ++i)
					_output[i] = ele[i].Int();
			}

			checkNotEoo(obj["sb"])
				_sup_base = obj["sb"].Int();
			checkNotEoo(obj["st"])
				_sup_time = obj["st"].Int();
			checkNotEoo(obj["ntt"])
				_next_npc2_time = obj["ntt"].Int();
			checkNotEoo(obj["cbn"])
			{
				_cur_box_num = obj["cbn"].Int();
				if (_cur_box_num > 0)
					CityMgr::shared().addBox(upCast<City>(shared_from_this()));	
			}
			checkNotEoo(obj["gbp"])
			{
				std::vector<mongo::BSONElement> ele = obj["gbp"].Array();
				for (unsigned i = 0; i < ele.size(); ++i)
					_get_box_players.insert(ele[i].Int());
			}
			{
				mongo::BSONObj key = BSON("ci" << _id);
				mongo::BSONObj obj = db_mgr.FindOne(DBN::dbKingdomWarCityBattle, key);
				if (obj.isEmpty())
					return;
				_state_helper = obj["st"].Int();
			}
		}

		bool City::_auto_save()
		{
			mongo::BSONObj key = BSON("ci" << _id);
			mongo::BSONObjBuilder obj;
			obj << "ci" << _id << "nt" << _nation
				<< "sb" << _sup_base << "st" << _sup_time
				<< "ntt" << _next_npc2_time << "cbn" << _cur_box_num
				<< "reset" << false;
			{
				mongo::BSONArrayBuilder b;
				for (unsigned i = 0; i < Kingdom::nation_num; ++i)
					b.append(_output[i]);
				obj << "o" << b.arr();
			}
			if (!_get_box_players.empty())
			{
				mongo::BSONArrayBuilder b;
				ForEachC(std::set<int>, it, _get_box_players)
					b.append(*it);
				obj << "gbp" << b.arr();
			}
			return db_mgr.SaveMongo(DBN::dbKingdomWarCityBase, key, obj.obj());
		}

		void City::attach(int id)
		{
			if (Observer::empty())
				_battle_field->resetData();
			Observer::attach(id);
		}

		void City::addExploit(int pid, int exploit)
		{
			BattleField::ExploitMap::iterator it = _battle_field->_exploit_map.find(pid);
			if (it == _battle_field->_exploit_map.end())
				_battle_field->_exploit_map.insert(make_pair(pid, exploit));
			else
				it->second += exploit;
		}

		inline bool City::inProtected(int nation) const
		{
			return _battle_field->state() == Protected
				&& _nation != nation;
		}

		int City::enter(unsigned time, playerDataPtr d, int army_id, Json::Value& tips)
		{
			if (_is_main)
			{
				d->KingDomWarPos().setPosition(army_id, PosCity, _id, time, tips);
				return res_sucess;
			}
			if (inProtected(d->Info().Nation()))
			{
				kingdomwar_sys.goBackMainCity(time, d, army_id, JARRAY((int)TIPS::CITYPROTECTED << _id));
				return res_sucess;
			}
			nCity::PlayerPtr ptr = Creator<nCity::IPlayer>::Create(d, army_id, upCast<City>(shared_from_this()));
			d->KingDomWarPos().setPosition(army_id, PosCity, _id, time, tips);
			enter(time, ptr);
			d->KingDomWarPos().tryMove(army_id);
			return res_sucess;
		}

		int City::enter(unsigned time, nCity::ItemPtr ptr)
		{
			_counter->push(ptr);
			if (_nation == ptr->nation())
			{
				_defender_backup.push_back(ptr);
				noticeAddDefender(time);
				if (!onFired())
					updateAll();
			}
			else
			{
				_attacker_backup.push_back(ptr);
				noticeAddAttacker(time);
			}
			return res_sucess;
		}

		ENTER(Npc)
		ENTER(Shadow)
		ENTER(ShadowNpc)

		ShadowNpcDataPtr City::createShadowNpc(unsigned cur_time, playerDataPtr d)
		{
			int map_id = NpcRuleMgr::shared().npcID();
			Position pos;
			pos.type = PosCity;
			pos.time = cur_time;
			pos.id = _id;
			pos.from_id = _id;
			std::vector<int> man_hp;
			return Creator<ShadowNpcData>::Create(d, map_id, pos, (int)ArmyMaxHp, man_hp, (int)ShadowNpc);
		}

		ShadowNpcDataPtr City::createShadowDefenseNpc(unsigned cur_time, playerDataPtr d)
		{
			int map_id = NpcRuleMgr::shared().npcID();
			Position pos;
			pos.type = PosCity;
			pos.time = cur_time;
			pos.id = _id;
			pos.from_id = _id;
			std::vector<int> man_hp;
			return Creator<ShadowNpcData>::Create(d, map_id, pos, (int)ArmyMaxHp, man_hp, (int)ShadowDefenseNpc);
		}

		ShadowNpcDataPtr City::createShadowAdvancedNpc(unsigned cur_time, playerDataPtr d)
		{
			int map_id = ShadowNpcRuleMgr::shared().npcID();
			Position pos;
			pos.type = PosCity;
			pos.time = cur_time;
			pos.id = _id;
			pos.from_id = _id;
			std::vector<int> man_hp;
			return Creator<ShadowNpcData>::Create(d, map_id, pos, (int)ArmyMaxHp, man_hp, (int)ShadowAdvanceNpc);
		}

		ShadowDataPtr City::createShadow(unsigned cur_time, playerDataPtr d, int army_id, int type)
		{
			Position pos;
			pos.type = PosCity;
			pos.time = cur_time;
			pos.id = _id;
			pos.from_id = _id;
			return Creator<ShadowData>::Create(d, army_id, pos, (int)ArmyMaxHp, -0.1);
		}

		int City::callElecTower(unsigned cur_time, playerDataPtr d)
		{
			return _battle_field->callElecTower(cur_time, d);
		}

		int City::getShadowIndex(int side) const
		{
			if (side == Left)
			{
				int count = 0;
				for (unsigned i = 0; i < BattleQueueNum; ++i)
				{
					if (_battle_field->_battle_queues[i].atk_side)
						++count;
				}
				return count + _battle_field->_ready_attackers.realSize() + _attacker_backup.size() + 1;
			}
			else
			{
				int count = 0;
				for (unsigned i = 0; i < BattleQueueNum; ++i)
				{
					if (_battle_field->_battle_queues[i].def_side)
						++count;
				}
				ForEachC(std::deque<nCity::ItemPtr>, it, _battle_field->_ready_defenders.getQueue())
				{
					const nCity::ItemPtr& ptr = *it;
					if (ptr)
					{
						if (ptr->type() == Npc)
							continue;
						++count;
					}
				}
				return count + _defender_backup.size() + 1;
			}
		}

		int City::callShadow(unsigned cur_time, playerDataPtr d, int type, int use_res, Json::Value& r)
		{
			if (type == SHADOW::PLAYER && d->KingDomWarFM().empty(0))
				return err_illedge;

			if (type == SHADOW::NPC
				&& d->Info().Nation() == _nation)
				return err_illedge;
			if (type == SHADOW::DEFENSE_NPC
				&& d->Info().Nation() != _nation)
				return err_illedge;

			if (use_res == 1)
			{
				if (d->KingDomWarShop().inShadowCd(type))
					return err_illedge;
				unsigned times = d->KingDomWarShop().callShadowTimes(type);
				if (times >= ShadowCost::shared().maxTimes(type, (type == SHADOW::NPC || type == SHADOW::DEFENSE_NPC)? d->LV() : d->Info().VipLv()))
					return err_kingdomwar_shadow_times_not_enough;
				const nShadow::Cost& cost = ShadowCost::shared().get(type, d, times);
				if (!cost.valid())
					return err_gold_not_enough;
				if (d->Res().getCash() < cost.gold)
					return err_gold_not_enough;
				if (d->Res().getFood() < cost.food)
					return err_food_not_enough;
				r[4u] = cost.gold;
				r[5u] = cost.food;
				d->Res().alterCash(0 - cost.gold);
				d->Res().alterFood(0 - cost.food);
				d->KingDomWarShop().alterShadowTimes(type);
				Log(DBLOG::strLogKingdomWar, d, 13, type, use_res, cost.toStr());
			}
			else
			{
				const ShadowItem& item = ItemConfig::shared().shadowItem(type);
				int cur_num = d->Items().itemNum(item.item_id);
				if (cur_num < 1)
					return err_item_not_enough;
				d->Items().removeItem(item.item_id, 1);
				Json::Value json = Json::arrayValue;
				Json::Value tmp;
				tmp.append(ACTION::item);
				tmp.append(item.item_id);
				tmp.append(1);
				json.append(tmp);
				Log(DBLOG::strLogKingdomWar, d, 13, type, use_res, json.toIndentString());
			}
			int shadow_index = getShadowIndex(d->Info().Nation() != _nation? Left : Right);
			r[1u] = type;
			r[2u] = use_res;
			r[3u] = shadow_index;
			if (type == SHADOW::NPC)
			{
				ShadowNpcDataPtr ptr = createShadowNpc(cur_time, d);
				ptr->_sign_save();
				TaskMgr::update(d, gg::Task::KingdomWarShadowNpc, 1);
				return enter(cur_time, ptr);
			}
			else if (type == SHADOW::PLAYER)
			{
				ShadowDataPtr ptr = createShadow(cur_time, d, 0, SHADOW::PLAYER);
				ptr->_sign_save();
				TaskMgr::update(d, gg::Task::KingdomWarShadowPlayer, 1);
				return enter(cur_time, ptr);
			}
			else if (type == SHADOW::ADVANCED_NPC)
			{
				ShadowNpcDataPtr ptr = createShadowAdvancedNpc(cur_time, d);
				ptr->_sign_save();
				TaskMgr::update(d, gg::Task::KingdomWarShadowAdvancedNpc, 1);
				return enter(cur_time, ptr);
			}
			else
			{
				ShadowNpcDataPtr ptr = createShadowDefenseNpc(cur_time, d);
				ptr->_sign_save();
				TaskMgr::update(d, gg::Task::KingdomWarShadowNpc, 1);
				return enter(cur_time, ptr);
			}
		}

		bool City::onFight(playerDataPtr d, int army_id)
		{
			if (_is_main)
				return false;
			return _battle_field->onFight(d, army_id);
		}

		bool City::onFight(NpcDataPtr d)
		{
			if (_is_main)
				return false;
			return _battle_field->onFight(d);
		}

		PathPtr City::getPath(int to_id) const
		{
			ForEachC(std::vector<PathPtr>, it, _paths)
			{
				if ((*it)->access(_id, to_id))
					return *it;
			}
			return PathPtr();
		}

		bool City::eraseItem(playerDataPtr d, int army_id)
		{
			nCity::ItemList& item_list =
				(d->Info().Nation() != _nation)? _attacker_backup : _defender_backup;
			ForEach(nCity::ItemList, it, item_list)
			{
				nCity::PlayerPtr ptr = upCast<nCity::IPlayer>(*it);
				if (!ptr) continue;
				if (ptr->pid() == d->ID() && ptr->armyId() == army_id)
				{
					_counter->pop(ptr);
					item_list.erase(it);
					return true;
				}
			}
			return false;
		}

		int City::leave(unsigned time, playerDataPtr d, int army_id, int to_city_id)
		{
			PathPtr ptr = getPath(to_city_id);
			if (!ptr)
				return err_illedge;
			if (!_is_main && !eraseItem(d, army_id))
				return err_illedge;
			return ptr->enter(time, d, army_id, to_city_id);
		}

		int City::transfer(unsigned time, playerDataPtr d, int army_id, int to_city_id)
		{
			if (to_city_id == _id)
				return err_illedge;
			if (onFired())
				return err_kingdomwar_at_war;
			CityPtr ptr = CityMgr::shared().getCity(to_city_id);
			if (ptr->_is_main || ptr->nation() != d->Info().Nation())
				return err_illedge;
			if (!_is_main && !eraseItem(d, army_id))
				return err_illedge;
			return ptr->enter(time, d, army_id, JARRAY((int)TIPS::TRANSFER << _id));
		}

		void City::noticeAddAttacker(unsigned tick_time)
		{
			_battle_field->handleAddAttacker(tick_time);
		}

		void City::noticeAddDefender(unsigned tick_time)
		{
			_battle_field->handleAddDefender(tick_time);
		}

		nCity::ItemPtr City::getAttacker()
		{
			if (_attacker_backup.empty())
				return nCity::ItemPtr();
			nCity::ItemPtr ptr = _attacker_backup.front();
			_attacker_backup.pop_front();
			return ptr;
		}

		nCity::ItemPtr City::getAttacker(int pid, int army_id)
		{
			ForEach(nCity::ItemList, it, _attacker_backup)
			{
				nCity::PlayerPtr ptr = upCast<nCity::IPlayer>(*it);
				if (ptr && ptr->pid() == pid && ptr->armyId() == army_id)
				{
					_attacker_backup.erase(it);
					return ptr;
				}
			}
			return nCity::ItemPtr();
		}

		nCity::ItemPtr City::getAttacker(int npc_id)
		{
			ForEach(nCity::ItemList, it, _attacker_backup)
			{
				nCity::ItemPtr ptr = *it;
				if (ptr->id() == npc_id)
				{
					_attacker_backup.erase(it);
					return ptr;
				}
			}
			return nCity::ItemPtr();
		}

		nCity::ItemPtr City::getDefender()
		{
			if (_defender_backup.empty()
				&& _npc_list.empty())
				return nCity::ItemPtr();
			if (!_defender_backup.empty())
			{
				nCity::ItemPtr ptr = _defender_backup.front();
				_defender_backup.pop_front();
				return ptr;
			}
			nCity::ItemPtr ptr = _npc_list.front();
			_npc_list.pop_front();
			return ptr;
		}

		nCity::ItemPtr City::getDefender(int pid, int army_id)
		{
			ForEach(nCity::ItemList, it, _defender_backup)
			{
				nCity::PlayerPtr ptr = upCast<nCity::IPlayer>(*it);
				if (ptr && ptr->pid() == pid && ptr->armyId() == army_id)
				{
					_defender_backup.erase(it);
					return ptr;
				}
			}
			return nCity::ItemPtr();
		}

		nCity::ItemPtr City::getDefender(int npc_id)
		{
			ForEach(nCity::ItemList, it, _defender_backup)
			{
				nCity::ItemPtr ptr = *it;
				if (ptr->id() == npc_id)
				{
					_defender_backup.erase(it);
					return ptr;
				}
			}
			ForEach(nCity::ItemList, it, _npc_list)
			{
				nCity::ItemPtr ptr = *it;
				if (ptr->id() == npc_id)
				{
					_npc_list.erase(it);
					return ptr;
				}
			}
			return nCity::ItemPtr();
		}
		void City::initNation(int nation)
		{
			if (nation == -1)
			{
				if (_id == MainCity[Kingdom::wei])
					_nation = Kingdom::wei;
				else if (_id == MainCity[Kingdom::shu])
					_nation = Kingdom::shu;
				else if (_id == MainCity[Kingdom::wu])
					_nation = Kingdom::wu;
				else
					_nation = Kingdom::nation_num;
			}
			else
			{
				_nation = nation;
			}
			CityCounter::shared().alter(_nation);
		}

		void City::alterNation(int nation)
		{
			int tmp = _nation;
			_nation = nation;
			CityCounter::shared().alter(_nation, tmp);
			PUSH_UPDATER2(nCity::Up_Nation, upCast<City>(shared_from_this()))
			if (_nation != Kingdom::nation_num)
			{
				qValue b;
				b << 0 << _nation << _id << tmp;
				for (unsigned i = 0; i < Kingdom::nation_num; ++i)
					b << CityCounter::shared().num(i);
				kingdomwar_sys.DoBroadcast(-2, b);

				if (_broadcast_1 == 1)
				{
					qValue bc;
					bc << 9 << _nation << tmp;
					kingdomwar_sys.DoBroadcast(-1, bc);
				}	
				if (_broadcast_2 == 1
					&& _belong_nation != -1
					&& _belong_nation != _nation)
				{
					qValue bc;
					bc << 10 << _nation << _id;
					kingdomwar_sys.DoBroadcast(_belong_nation, bc);
				}
				_cur_box_num = _max_box_num;
				CityMgr::shared().addBox(upCast<City>(shared_from_this()));	
				kingdomwar_sys.DoBroadcast(_nation, QARRAY(11 << _id));
				kingdomwar_sys.updateBoxInfo();
			}

			kingdomwar_sys.updateNationTask(_nation, Task::OccupySpecified, JARRAY(_id << 1));
			kingdomwar_sys.updateNationTask(tmp, Task::OccupySpecified, JARRAY(_id << 0));
			kingdomwar_sys.updateNationTask(_nation, Task::OccupyNum1, Json::Value(1));
			kingdomwar_sys.updateNationTask(_nation, Task::OccupyNum2, Json::Value(1));
			kingdomwar_sys.updateNationTask(tmp, Task::OccupyNum1, Json::Value(0));
			kingdomwar_sys.updateNationTask(tmp, Task::OccupyNum2, Json::Value(0));
		}

		int City::getSilverBox(playerDataPtr d, Json::Value& r)
		{
			if (d->KingDomWarBox().silverBoxLimit() < 1)
				return err_kingdomwar_silver_box_day_limit;
			if (d->Info().Nation() != _nation)
				return err_illedge;
			if (_cur_box_num < 1)
				return err_kingdomwar_silver_box_not_enough;
			if (_get_box_players.find(d->ID()) != _get_box_players.end())
				return err_kingdomwar_silver_box_received;
			ActionRandomList rw = nCity::BoxConfig::shared().getSilverBox();
			int res = actionDo(d, rw);
			if (res == res_sucess)
			{
				r = actionRes();
				d->KingDomWarBox().alterSilverBoxNum(1);
				--_cur_box_num;
				_get_box_players.insert(d->ID());
				if (_cur_box_num == 0)
				{
					CityMgr::shared().rmBox(upCast<City>(shared_from_this()));	
					kingdomwar_sys.updateBoxInfo();
				}
				Log(DBLOG::strLogKingdomWar, d, 17, _id, "", "", "", "", "", "", r.toIndentString());
				_sign_save();
			}
			else
			{
				Json::Value error_code = actionError();
				res = error_code[0u][1u].asInt();
			}
			return res;
		}

		void City::handleBattleResult(unsigned tick_time, bool result, int nation)
		{
			if (result)
			{
				alterNation(nation);
				ForEach(nCity::ItemList, it, _attacker_backup)
				{
					nCity::ItemPtr& ptr = *it;
					if (ptr->nation() == _nation)
					{
						_defender_backup.push_back(ptr);
						ptr->enter(tick_time);
					}
					else
					{
						_counter->pop(ptr);
						ptr->beDead(tick_time, JARRAY((int)TIPS::SIEGEFAILED << _id));
					}
				}
				_attacker_backup.clear();
				initNpc(tick_time);
				_sign_save();
			}
		}

		void City::tickOutput(unsigned cur_time)
		{
			if (_nation == Kingdom::nation_num)
				return;
			if (State::shared().get() == Closed &&
				(cur_time % (15 * MINUTE) != 0))
				return;
			_output[_nation] += _output[Kingdom::nation_num];
			_sign_save();
		}

		void City::initNpc(unsigned cur_time)
		{
			for (unsigned i = 0; i < _npc_start[_nation]; ++i)
			{
				int map_id = NpcRuleMgr::shared().npcID();
				nCity::NpcPtr ptr = createNpc(cur_time, Npc, map_id);
				if (!ptr)
				{
					LogE << "create npc error: map id " << map_id << LogEnd;
					continue;
				}
				_npc_list.push_back(ptr);
				_counter->push(ptr);
			}
		}

		void City::initMaxNpc(unsigned cur_time)
		{
			if (_is_main)
				return;
			for (unsigned i = 0; i < _npc_max[_nation]; ++i)
			{
				int map_id = NpcRuleMgr::shared().npcID();
				nCity::NpcPtr ptr = createNpc(cur_time, Npc, map_id);
				if (!ptr)
				{
					LogE << "create npc error: map id " << map_id << LogEnd;
					continue;
				}
				_npc_list.push_back(ptr);
				_counter->push(ptr);
			}
		}

		nCity::NpcPtr City::createNpc(unsigned cur_time, int type, int map_id)
		{
			Position pos;
			pos.type = PosCity;
			pos.time = cur_time;
			pos.id = _id;
			pos.from_id = _id;
			std::vector<int> man_hp;
			NpcDataPtr ptr = Creator<NpcData>::Create(type, map_id, _nation, pos, (int)ArmyMaxHp, man_hp);
			if (!ptr->checkValidAndSave())
				return nCity::NpcPtr();
			return Creator<nCity::INpc>::Create(ptr, upCast<City>(shared_from_this()));
		}

		void City::tickCreateNpc(unsigned cur_time)
		{
			if (_is_main)
				return;
			if (_battle_field->inBattle()
				|| KingdomWar::State::shared().get() == Closed)
				return;
			if (_npc_list.size() >= _npc_max[_nation])
				return;
			int add_num = _npc_add[_nation];
			if (_npc_list.size() + add_num > _npc_max[_nation])
				add_num = _npc_max[_nation] - _npc_list.size();
			for (unsigned i = 0; i < add_num; ++i)
			{
				int map_id = NpcRuleMgr::shared().npcID();
				nCity::NpcPtr npc_ptr = createNpc(cur_time, Npc, map_id);
				if (!npc_ptr)
				{
					LogE << "create npc error: map id " << map_id << LogEnd;
					continue;
				}
				_npc_list.push_back(npc_ptr);
				_counter->push(npc_ptr);
			}
		}

		void City::doTickCreateActiveNpc(unsigned cur_time, PathPtr& ptr, int to_id)
		{
			if (KingdomWar::State::shared().get() == Closed)
				return;
			int map_id = NpcRuleMgr::shared().activeNpcID();
			nCity::NpcPtr npc = createNpc(cur_time, ActiveNpc, map_id);
			if (!npc)
				return;
			ptr->enter(cur_time, npc->npcData(), to_id);
		}

		void City::tickCreateActiveNpc(unsigned cur_time)
		{
			_next_npc2_time += _npc2_interval;
			kingdomwar_sys.addTimer(_next_npc2_time, boostBind(City::tickCreateActiveNpc, upCast<City>(shared_from_this()), _next_npc2_time));
			_sign_save();

			if (State::shared().get() == Closed)
				return;
			if (_belong_nation == -1)
				return;
			if (_belong_nation != _nation)
				return;
			ForEach(std::vector<PathPtr>, it, _paths)
			{
				PathPtr ptr = *it;
				CityPtr city_ptr = ptr->getLinkedCity(_id);
				if (city_ptr->_belong_nation == _nation
					&& city_ptr->nation() != _nation
					&& ptr->access(_id, city_ptr->id()))
				{
					unsigned out_time = cur_time;
					for (unsigned i = 0; i < _npc2_num; ++i)
					{
						out_time += (i * NpcOutTime);
						kingdomwar_sys.addTimer(out_time, boostBind(City::doTickCreateActiveNpc, upCast<City>(shared_from_this()), out_time, ptr, city_ptr->id()));
					}
				}
			}
		}

		void City::getMilitaryInfo(qValue& q)
		{
			q.addMember("n", _nation);
			const std::vector<int>& num = _counter->num();
			qValue n;
			for (unsigned i = 0; i < num.size(); ++i)
				n.append(num[i]);
			q.addMember("a", n);
		}

		void City::getFighterList(qValue& q, int side)
		{
			return _battle_field->getItemList(q, side);
		}

		void City::addBuff(sBattlePtr ptr, int nation)
		{
			if (nation == Kingdom::nation_num)
				return;
			int buff = _buff_value[nation];
			if (_buff_type == 1)
			{
				ForEach(manList, it, ptr->battleMan)
				{
					(*it)->battleAttri[idx_phyHurtRate] += buff;
					(*it)->battleAttri[idx_warHurtRate] += buff;
					(*it)->battleAttri[idx_magicHurtRate] += buff;
					(*it)->battleAttri[idx_cureRate] += buff;
				}
			}
			else if (_buff_type == 2)
			{
				ForEach(manList, it, ptr->battleMan)
				{
					(*it)->battleAttri[idx_phyCutRate] += buff;
					(*it)->battleAttri[idx_warCutRate] += buff;
					(*it)->battleAttri[idx_magicCutRate] += buff;
				}
			}
		}

		void City::addBuff(playerDataPtr& d, sBattlePtr ptr)
		{
			addBuff(ptr, d->Info().Nation());
		}

		unsigned City::getSup(unsigned cur_time)
		{
			if (cur_time < _sup_time)
				return 0;
			return (cur_time - _sup_time) * SupSpeed  * _sup_rate  + _sup_base;
		}

		void City::tickPrimeState(unsigned tick_time)
		{
			if (_is_main)
				resetSupRate(tick_time);
			_battle_field->tickPrimeState(tick_time);
		}

		void City::resetSupRate(unsigned cur_time)
		{
			if (_sup_rate != kingdomwar_sys.supRate())
			{
				if (cur_time > _sup_time)
				{
					_sup_base = getSup(cur_time);
					_sup_time = cur_time;
					_sign_save();
				}
				_sup_rate = kingdomwar_sys.supRate();
			}
		}

		void City::tickUnity(unsigned cur_time)
		{
			if (_id == MainCity[0u]
				|| _id == MainCity[1u]
				|| _id == MainCity[2u])
				return;
			ForEach(nCity::ItemList, it, _npc_list)
			{
				(*it)->beDead(cur_time, JARRAY((int)TIPS::UNITY << _id));
				_counter->pop(*it);
			}
			_npc_list.clear();
			ForEach(nCity::ItemList, it, _attacker_backup)
			{
				(*it)->beDead(cur_time, JARRAY((int)TIPS::UNITY << _id));
				_counter->pop(*it);
			}
			_attacker_backup.clear();
			ForEach(nCity::ItemList, it, _defender_backup)
			{
				(*it)->beDead(cur_time, JARRAY((int)TIPS::UNITY << _id));
				_counter->pop(*it);
			}
			_defender_backup.clear();
			_battle_field->clear(cur_time);
		}

		void City::tickResetUnity(unsigned cur_time)
		{
			if (_id == MainCity[0u]
				|| _id == MainCity[1u]
				|| _id == MainCity[2u])
				return;
			
			alterNation(Kingdom::nation_num);
			initMaxNpc(cur_time);
			_sign_save();
		}

		int City::useTowerItem(unsigned cur_time, playerDataPtr d, int type, int id, Json::Value& r)
		{
			if (type < 0 || type > 1)
				return err_illedge;
			const TowerItem& item = ItemConfig::shared().towerItem(type);
			int cur_num = d->Items().itemNum(item.item_id);
			if (cur_num < 1)
				return err_illedge;
			int res = _battle_field->alterTowerLifeTime(cur_time, d, id, type == 0? item.getSecs() : -item.getSecs());
			if (res == res_sucess)
			{
				d->Items().removeItem(item.item_id, 1);
				d->Res().alterExploit(item.exploit);
				r[1u] = type;
				r[2u] = id;
				r[3u] = item.getSecs();
				r[4u] = item.exploit;
				Log(DBLOG::strLogKingdomWar, d, 15, _id, item.item_id);
			}
			return res;
		}

		void City::handleEndProtected(unsigned tick_time)
		{
			if (_cur_box_num > 0)
			{
				_cur_box_num = 0;
				_get_box_players.clear();
				CityMgr::shared().rmBox(upCast<City>(shared_from_this()));	
				kingdomwar_sys.updateBoxInfo();
				_sign_save();
			}
		}

		void City::getTowerInfo(qValue& q) const
		{
			q << _id;
			bool find = false;
			for (unsigned i = 0; i < _battle_field->_atk_tower.size(); ++i)
			{
				if (_battle_field->_atk_tower[i])
				{
					find = true;
					break;
				}
			}
			q << (find? 1 : 0);
			find = false;
			for (unsigned i = 0; i < _battle_field->_def_tower.size(); ++i)
			{
				if (_battle_field->_def_tower[i])
				{
					find = true;
					break;
				}
			}
			q << (find? 1 : 0);
		}

		void City::updateAll()
		{
			qValue mm(qJson::qj_object);
			qValue m;
			m.append(res_sucess);
			qValue q(qJson::qj_object);
			getMainInfo(q);
			m.append(q);
			mm.addMember(strMsg, m);
			detail::batchOnline(getObserver(), mm, gate_client::kingdom_war_city_battle_info_resp);
		}

		void City::getMainInfo(qValue& q)
		{
			if (_battle_field->state() != Closed
				&& _battle_field->state() != Protected)
				_battle_field->getInfo(q);
			else
			{
				qValue a;
				const std::vector<int>& num = _counter->num();
				for (unsigned i = 0; i < num.size(); ++i)
					a.append(num[i]);
				q.addMember("a", a);
				q.addMember("s", (int)Closed);
				qValue rd;
				int count = 0;
				ForEachC(nCity::ItemList, it, _defender_backup)
				{
					if (count >= ReadyMemNum)
						break;
					qValue tmp;
					(*it)->getInfo(tmp);
					rd.append(tmp);
					++count;
				}
				if (count < ReadyMemNum)
				{
					ForEachC(nCity::ItemList, it, _npc_list)
					{
						if (count >= ReadyMemNum)
							break;
						qValue tmp;
						(*it)->getInfo(tmp);
						rd.append(tmp);
						++count;
					}
				}
				q.addMember("rd", rd);
				qValue dtr;
				for (unsigned i = 0; i < _battle_field->_def_tower.size(); ++i)
				{
					qValue tmp;
					if (_battle_field->_def_tower[i])
						_battle_field->_def_tower[i]->getInfo(tmp);
					dtr.append(tmp);
				}
				q.addMember("dtr", dtr);
			}
		}

		CityMgr::CityMgr()
		{
		}

		CityPtr CityMgr::getCity(int id)
		{
			if (id < 0 || id >= _city_list.size())
				return CityPtr();
			return _city_list[id];
		}

		void CityMgr::getTowerInfo(qValue& q)
		{
			ForEach(CityList, it, _city_list)
			{
				qValue tmp;
				(*it)->getTowerInfo(tmp);
				q.append(tmp);
			}
		}

		void CityMgr::clearTower(unsigned cur_time)
		{
			ForEach(CityList, it, _city_list)
				(*it)->clearTower(cur_time);
		}

		void CityMgr::push(const CityPtr& ptr)
		{
			while(ptr->id() >= _city_list.size())
				_city_list.push_back(CityPtr());
			_city_list[ptr->id()] = ptr;
		}

		void CityMgr::tickUnity(unsigned cur_time)
		{
			ForEach(CityList, it, _city_list)
				(*it)->tickUnity(cur_time);
		}

		void CityMgr::tickResetUnity(unsigned cur_time)
		{
			ForEach(CityList, it, _city_list)
				(*it)->tickResetUnity(cur_time);
		}

		void CityMgr::resetUpInfo()
		{
			if (!_up_state_info.empty())
			{
				_up_state_info.clear();
				_main_state_info.toArray();
				_main_protected_time_info.toArray();
			}
			if (!_up_nation_info.empty())
			{
				_up_nation_info.clear();
				_main_nation_info.toArray();
			}
		}

		void CityMgr::getUpInfo(qValue& up_state, qValue& up_nation, qValue& up_box)
		{
			if (!_up_state_info.empty())
			{
				_main_state_info.toArray();
				_main_protected_time_info.toArray();
				ForEach(CityList, it, _up_state_info)
				{
					const CityPtr& ptr = *it;
					qValue tmp;
					tmp << ptr->id() << ptr->clientState() << ptr->protectedTime();
					up_state.append(tmp);
				}
				_up_state_info.clear();
			}
			if (!_up_nation_info.empty())
			{
				_main_nation_info.toArray();
				ForEach(CityList, it, _up_nation_info)
				{
					const CityPtr& ptr = *it;
					qValue tmp;
					tmp << ptr->id() << ptr->nation();
					up_nation.append(tmp);
				}
				_up_nation_info.clear();
			}
		}
		
		void CityMgr::loadDB()
		{
			ForEach(CityList, it, _city_list)
				(*it)->loadDB();
		}

		void CityMgr::init()
		{
			ForEach(CityList, it, _city_list)
				(*it)->init();
		}

		void CityMgr::stateInfo(qValue& q)
		{
			if (_main_state_info.isEmpty())
			{
				ForEachC(CityList, it, _city_list)
					_main_state_info.append((*it)->clientState());
			}
			q = _main_state_info.Copy();
		}

		void CityMgr::nationInfo(qValue& q)
		{
			if (_main_nation_info.isEmpty())
			{
				ForEachC(CityList, it, _city_list)
					_main_nation_info.append((*it)->nation());
			}
			q = _main_nation_info.Copy();
		}

		void CityMgr::protectedTimeInfo(qValue& q)
		{
			if (_main_protected_time_info.isEmpty())
			{
				ForEachC(CityList, it, _city_list)
					_main_protected_time_info.append((*it)->protectedTime());
			}
			q = _main_protected_time_info.Copy();
		}

		void CityMgr::tickPrimeState(unsigned tick_time)
		{
			ForEach(CityList, it, _city_list)
				(*it)->tickPrimeState(tick_time);
		}

		void CityMgr::addBox(CityPtr ptr)
		{
			_box_list.push_back(ptr);
		}

		void CityMgr::rmBox(CityPtr ptr)
		{
			ForEach(CityList, it, _box_list)
			{
				if ((*it) == ptr)
				{
					_box_list.erase(it);
					return;
				}
			}
		}

		void CityMgr::tickUpdate(int type, CityPtr ptr)
		{
			switch(type)
			{
				case nCity::Up_State:
					_up_state_info.push_back(ptr);
					break;
				case nCity::Up_Nation:
					_up_nation_info.push_back(ptr);
					break;
			}
		}

		CityCounter::CityCounter()
		{
			_num.assign(Kingdom::nation_num + 1, 0);
		}

		void CityCounter::alter(int nation, int old_nation)
		{
			if (old_nation != -1)
				--_num[old_nation];
			++_num[nation];
		}	

		int CityCounter::unityNation() const
		{
			for (unsigned i = 0; i < Kingdom::nation_num; ++i)
			{
				if (_num[i] == CityMgr::shared().size() - 2)
					return i;
			}
			return -1;
		}

		int CityCounter::strength(int nation) const
		{
			int s = 2;
			for (unsigned i = 0; i < Kingdom::nation_num; ++i)
			{
				if (i == nation)
					continue;
				if (_num[i] < _num[nation])
					--s;
			}
			return s;
		}

		TowerMgr::TowerMgr()
		{
			_valid = false;
		}

		void TowerMgr::tick()
		{
			if (_up_list.empty())
				return;
			_valid = false;
			if (!kingdomwar_sys.empty())
			{
				qValue m(qJson::qj_object);
				qValue q;
				ForEach(std::vector<CityPtr>, it, _up_list)
				{
					qValue tmp;
					(*it)->getTowerInfo(tmp);
					q.append(tmp);
				}
				m.addMember("t", q);
				qValue mm;
				mm.append(res_sucess);
				mm.append(m);
				qValue mmm(qJson::qj_object);
				mmm.addMember(strMsg, mm);
				detail::batchOnline(kingdomwar_sys.getObserver(), mmm, gate_client::kingdom_war_tower_info_resp);
			}
			_up_list.clear();
		}

		void TowerMgr::update(playerDataPtr d)
		{
			if (!_valid)
			{
				_main_info.toArray();
				CityMgr::shared().getTowerInfo(_main_info);
				_valid = true;
			}
			qValue q;
			q = _main_info.Copy();
			qValue m(qJson::qj_object);
			m.addMember("t", q);
			qValue mm;
			mm.append(res_sucess);
			mm.append(m);
			d->sendToClientFillMsg(gate_client::kingdom_war_tower_info_resp, mm);
		}

		BattleNumMgr::BattleNumMgr()
		{
			_valid = false;
		}

		void BattleNumMgr::tick()
		{
			if (_up_list.empty())
				return;
			_valid = false;
			if (!kingdomwar_sys.empty())
			{
				qValue q;
				ForEach(CityList, it, _up_list)
				{
					qValue tmp;
					(*it)->getNumInfo(tmp);
					q.append(tmp);
				}
				qValue m;
				m.append(res_sucess);
				m.append(q);
				qValue mm(qJson::qj_object);
				mm.addMember(strMsg, m);
				detail::batchOnline(kingdomwar_sys.getObserver(), mm, gate_client::kingdom_war_battle_num_info_resp);
			}
			_up_flag.reset();
			_up_list.clear();
		}

		void BattleNumMgr::update(playerDataPtr d)
		{
			if (!_valid)
			{
				_main_info.toArray();
				ForEachC(CityList, it, _on_fired_list)
				{
					qValue tmp;
					(*it)->getNumInfo(tmp);
					_main_info.append(tmp);
				}
				_valid = true;
			}
			qValue q;
			q = _main_info.Copy();
			qValue m;
			m.append(res_sucess);
			m.append(q);
			d->sendToClientFillMsg(gate_client::kingdom_war_battle_num_info_resp, m);
		}
	}
}


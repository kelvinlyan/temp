#include "kingdomwar_city.h"
#include "kingdomwar_system.h"
#include "map_war.h"
#include "net_helper.hpp"
#include "kingdomwar_task.h"
#include "kingdom_system.h"
#include "email_system.h"

namespace gg
{
	namespace KingdomWar
	{
		enum
		{
			// param
			QueueNum = 4,
			QueueMemNum = 4,
			ReadyMemNum = QueueNum * QueueMemNum,

			DefSpeed = 10,

			CacheSize = 63,

			BattleWaitInterval = 2,
			AttackerWaitInterval = 10,
			DefenderWaitInterval = 10,
			StartWaitInterval = 10 * MINUTE,
			ProtectedInterval = 60 * MINUTE,
			
			ElecAttackInterval = 1 * MINUTE,
			ElecTowerLifeTime = 60 * MINUTE,

			TowerMaxNum = 2,

			StartWaitPrimeRate = 10,
			ProtectedPrimeRate = 20,

			NpcOutTime = 3,
		};

		const static double TimePerRound = 0.7;

#define PUSH_UPDATER(PTR)\
	if (!_city->empty())\
	{\
		_updater.push(PTR);\
		if (_updater.size() > CacheSize)\
			tick();\
	}

#define TRYLOAD(TYPE)\
	void City::tryLoad##TYPE(TYPE##DataPtr& d)\
	{\
		using namespace nCity;\
		if (_is_main)\
			return;\
		TYPE##Ptr ptr = Creator<I##TYPE>::Create(d, upCast<City>(shared_from_this()));\
		if (ptr->type() == Npc)\
			_npc_list.push_back(ptr);\
		else if (ptr->nation() != _nation)\
			_attacker_backup.push_back(ptr);\
		else\
			_defender_backup.push_back(ptr);\
		_counter->push(ptr);\
	}

#define ENTER(TYPE)\
	int City::enter(unsigned time, TYPE##DataPtr d)\
	{\
		using namespace nCity;\
		if (_is_main)\
			return err_illedge;\
		if (inProtected(d->nation()))\
		{\
			d->setDead(time, QARRAY((int)TIPS::CITYPROTECTED));\
			return res_sucess;\
		}\
		TYPE##Ptr ptr = Creator<I##TYPE>::Create(d, upCast<City>(shared_from_this()));\
		d->setPosition(PosCity, _id, time);\
		return enter(time, ptr);\
	}

		namespace nCity
		{
			class BoxConfig
			{
				SINGLETON(BoxConfig);
				public:
					int getGoldBoxNumByExploit(int exploit) const;
					int getGoldBoxID() const { return _gold_box_id; }
					int getSilverBoxID() const { return _silver_box_id; }

				private:
					void loadFile();
					
				private:
					struct Item
					{
						Item(const Json::Value& info)
						{
							start = info["exploit_start"].asInt();
							end = info["exploit_end"].asInt();
							num = info["box_num"].asInt();
						}
						int start;
						int end;
						int num;
					};
					std::vector<Item> _items;
					int _gold_box_id;
					int _silver_box_id;
			};

			BoxConfig::BoxConfig()
			{
				loadFile();
			}

			void BoxConfig::loadFile()
			{
				Json::Value json = Common::loadJsonFile("./instance/kingdom_war/city_reward.json");
				const Json::Value& rw1 = json["reward1"];
				ForEachC(Json::Value, it, rw1)
					_items.push_back(Item(*it));
				_gold_box_id = json["reward1_box_id"].asInt();
				_silver_box_id = json["reward2_box_id"].asInt();
			}

			int BoxConfig::getGoldBoxNumByExploit(int exploit) const
			{
				if (exploit <= 0)
					return 0;
				ForEachC(std::vector<Item>, it, _items)
				{
					if (it->end == -1)
						return it->num;
					if (exploit >= it->start
						&& exploit <= it->end)
						return it->num;
				}
				return 0;
			}

			struct ShadowItem
			{
				ShadowItem(const Json::Value& info)
				{
					item_id = info["item_id"].asInt();
					if (info["rate"] != Json::nullValue)
						rate = info["rate"].asDouble();
					else
						rate = 1.0;
				}
				int item_id;
				double rate;
			};

			struct TowerItem
			{
				TowerItem(const Json::Value& info)
				{
					item_id = info["item_id"].asInt();
					secs = info["secs"].asInt();
				}
				int item_id;
				int secs;
			};

			class ItemConfig
			{
				SINGLETON(ItemConfig);
				public:
					const ShadowItem& shadowItem(int type) const
					{
						return _shadow_items[type];
					}
					const TowerItem& towerAddItem() const
					{
						return _tower_items[0];
					}
					const TowerItem& towerSubItem() const
					{
						return _tower_items[1];
					}
				private:
					void loadFile();
				private:
					std::vector<ShadowItem> _shadow_items;
					std::vector<TowerItem> _tower_items;
			};

			ItemConfig::ItemConfig()
			{
				loadFile();
			}

			void ItemConfig::loadFile()
			{
				Json::Value json = Common::loadJsonFile("./instance/kingdom_war/items.json");
				_shadow_items.push_back(ShadowItem(json["shadow_item1"]));
				_shadow_items.push_back(ShadowItem(json["shadow_item2"]));
				_shadow_items.push_back(ShadowItem(json["shadow_item3"]));
				_tower_items.push_back(TowerItem(json["add_tower_time_item"]));
				_tower_items.push_back(TowerItem(json["_tower_time_item"]));
			}

			enum
			{
				Up_Swap = 0,
				Up_Add,
				Up_Move,
				Up_Del,
				Up_Report,
				Up_Cross,
				Up_Clear,
				Up_Tower,
				Up_DelTower,
				Up_ElecAttack,
			};

			class UpSwap
				: public UpBase
			{
				public:
					UpSwap(int side, int player_pos, int npc_pos, const ItemPtr& ptr)
						: _side(side), _player_pos(player_pos), _npc_pos(npc_pos), _ptr(ptr){}
					virtual void getInfo(qValue& q) const
					{
						q << (int)Up_Swap << _side << _player_pos << _npc_pos;
						qValue tmp;
						_ptr->getUpInfo(Up_Swap, tmp);
						q << tmp;
					}
				private:
					int _side;
					int _player_pos;
					int _npc_pos;
					ItemPtr _ptr;
			};

			class UpAdd
				: public UpBase
			{
				public:
					UpAdd(int side, const ItemPtr& ptr)
						: _side(side), _ptr(ptr){}
					virtual void getInfo(qValue& q) const
					{
						q << (int)Up_Add << _side;
						qValue tmp;
						_ptr->getUpInfo(Up_Add, tmp);
						q << tmp;
					}
				private:
					int _side;
					ItemPtr _ptr;
			};

			class UpMove
				: public UpBase
			{
				public:
					UpMove(int side, int qid, unsigned time)
						: _side(side), _qid(qid), _ready_time(time)
					{
					}
					virtual void getInfo(qValue& q) const
					{
						q << (int)Up_Move << _side << _qid << _ready_time;
					}
				private:
					int _side;
					int _qid;
					unsigned _ready_time;
			};

			class UpDel
				: public UpBase
			{
				public:
					UpDel(int side, int qid, qValue& tips, const ItemPtr& ptr)
						: _side(side), _qid(qid), _ptr(ptr)
					{
						_tips = tips.Copy();
					}
					virtual void getInfo(qValue& q) const
					{
						q << (int)Up_Del << _qid << _side << _tips;
						qValue tmp;
						_ptr->getUpInfo(Up_Del, tmp);
						q << tmp;
					}
				private:
					int _side;
					int _qid;
					qValue _tips;
					ItemPtr _ptr;
			};

			class UpReport
				: public UpBase
			{
				public:
					UpReport(int qid, const ReportDataPtr& ptr)
						: _qid(qid), _rep(ptr){}
					virtual void getInfo(qValue& q) const
					{
						q << (int)Up_Report << _qid;
						qValue tmp;
						_rep->getInfo(tmp);
						q << tmp;
					}
				private:
					int _qid;
					ReportDataPtr _rep;
			};
			
			class UpCross
				: public UpBase
			{
				public:
					UpCross(int qid_from, int qid_to, unsigned time)
						:_qid_from(qid_from), _qid_to(qid_to), _ready_time(time){}
					virtual void getInfo(qValue& q) const
					{
						q << (int)Up_Cross << _qid_from << _qid_to << _ready_time;
					}
				private:
					int _qid_from;
					int _qid_to;
					unsigned _ready_time;
			};

			class UpClear
				: public UpBase
			{
				public:
					virtual void getInfo(qValue& q) const
					{
						q << (int)Up_Clear;
					}
			};

			class UpTower
				: public UpBase
			{
				public:
					UpTower(int side, int pos, const TowerPtr& ptr)
						: _side(side), _pos(pos), _ptr(ptr){}
					virtual void getInfo(qValue& q) const
					{
						q << (int)Up_Tower << _side << _pos;
						_ptr->getInfo(q);
					}
				private:
					int _side;
					int _pos;
					TowerPtr _ptr;
			};

			class UpDelTower
				: public UpBase
			{
				public:
					UpDelTower(int side, int pos)
						: _side(side), _pos(pos){}
					virtual void getInfo(qValue& q) const
					{
						q << (int)Up_DelTower << _side << _pos;
					}
				private:
					int _side;
					int _pos;
			};

			class UpElecAttack
				: public UpBase
			{
				public:
					UpElecAttack(int side, int pos)
						: _side(side), _pos(pos){}
					virtual void getInfo(qValue& q) const
					{
						q << (int)Up_ElecAttack << _side << _pos;
					}
				private:
					int _side;
					int _pos;
			};

			TowerBase::TowerBase()
			{
				static int ID = 0;
				_id = ++ID;
				_state = ALIVE;
			}

			ElecTower::ElecTower(const mongo::BSONElement& obj, int side, BattleFieldPtr bf)
			{
				_timer_id = 0;
				_side = side;
				_next_attack_time = obj["nat"].Int();
				_life_time = obj["lt"].Int();
				_battle_field = bf;
			}

			ElecTower::ElecTower(unsigned cur_time, int side, BattleFieldPtr bf)
			{
				_timer_id = 0;
				_side = side;
				_next_attack_time = cur_time + ElecAttackInterval;
				_life_time = cur_time + ElecTowerLifeTime;
				_battle_field = bf;
			}

			mongo::BSONObj ElecTower::toBSON() const
			{
				return BSON("t" << (int)ELECTOWER << "nat" << _next_attack_time << "lt" << _life_time);
			}

			void ElecTower::getInfo(qValue& q) const
			{
				q << id() << (int)ELECTOWER << _life_time;
			}

			void ElecTower::init()
			{
				setDeadTimer();
				setAttackTimer();
			}

			void ElecTower::setDeadTimer()
			{
				++_timer_id;
				kingdomwar_sys.addTimer(_life_time, boostBind(ElecTower::tickDead, shared_from_this(), _timer_id, _life_time));
			}

			void ElecTower::setAttackTimer()
			{
				kingdomwar_sys.addTimer(_next_attack_time, boostBind(ElecTower::tickAttack, shared_from_this(), _next_attack_time));
			}

			void ElecTower::tickDead(unsigned timer_id, unsigned tick_time)
			{
				if (_timer_id != timer_id)
					return;
				if (state() != ALIVE)
					return;
				setState(DEAD);
				_battle_field->removeTower(tick_time, _side, id());
			}

			void ElecTower::tickAttack(unsigned tick_time)
			{
				if (state() != ALIVE)
					return;
				_next_attack_time += ElecAttackInterval;
				setAttackTimer();
				_battle_field->tickElecAttack(tick_time, _side, id());
			}

			void ElecTower::alterLifeTime(int secs)
			{
				_life_time += secs;
				unsigned cur_time = Common::gameTime();
				if (cur_time >= _life_time)
				{
					setState(DEAD);
					_battle_field->removeTower(cur_time, _side, id());
				}
				else
				{
					setDeadTimer();
					_battle_field->upElecLifeTime(_side, id());
				}
			}

			ReportData::ReportData(unsigned cur_time, ItemPtr& atk_ptr, ItemPtr& def_ptr)
				: path("")
			{
				time = cur_time;
				atk_info = atk_ptr->getBattleInfo();
				def_info = def_ptr->getBattleInfo();
			}

			void ReportData::one2one()
			{
				result = data.One2One(atk_info.ptr, def_info.ptr, typeBattle::kingdomwar);
				if (result.res == resBattle::atk_win)
					++atk_info.win_streak;
				else
					++def_info.win_streak;
				//atk_info.cur_hp = getCurrentHp(atk_info.ptr);
				//def_info.cur_hp = getCurrentHp(def_info.ptr);
			}

			void ReportData::done()
			{
				data.Done(typeBattle::kingdomwar);
			}

			void ReportData::getInfo(qValue& q)
			{
				std::vector<O2ODamageRes> damage = data.getDamageList();
				qValue atk_damage, def_damage;
				for (unsigned i = 0; i < damage.size(); ++i)
				{
					atk_damage << damage[i].atkDamage;
					def_damage << damage[i].defDamage;
				}
				q << path << (int)result.res
					<< atk_info.max_hp << atk_info.pre_hp << atk_damage << atk_info.win_streak
					<< def_info.max_hp << def_info.pre_hp << def_damage << def_info.win_streak;
			}

			IPlayer::IPlayer(playerDataPtr& d, int army_id, CityPtr& ptr)
				: ItemBase(ptr)
			{
				_pid = d->ID();
				_name = d->Name();
				_nation = d->Info().Nation();
				_army_id = army_id;
				_face = d->KingDomWarFM().face(_army_id);
				_equip = getEquipList(d->KingDomWarFM().getFM(army_id));
				_lv = d->LV();
			}

			mongo::BSONObj IPlayer::toBSON() const
			{
				return BSON("t" << (int)Player << "p" << _pid << "a" << _army_id);
			}

			void IPlayer::getInfo(qValue& q) const
			{
				q << (int)Player << _pid << _army_id << _name << _nation
					<< _face << equipQ(_equip);
			}

			void IPlayer::getUpInfo(int type, qValue& q) const
			{
				q << (int)Player << _pid << _army_id;
				if (type == nCity::Up_Add || type == nCity::Up_Swap)
					q << _name << _nation << _face << equipQ(_equip);
			}

			void IPlayer::getStateInfo(qValue& q, int state) const
			{
				q << (int)Player << _name << _lv << _nation << state;
			}

			BattleInfo IPlayer::getBattleInfo()
			{
				playerDataPtr d = player_mgr.getPlayer(_pid);
				BattleInfo info;
				info.ptr = kingdomwar_sys.getBattlePtr(d, _army_id, info.max_hp, info.pre_hp);
				info.win_streak = d->KingDomWar().winStreak(_army_id);
				return info;
			}

			void IPlayer::resetHp(sBattlePtr& ptr)
			{
				playerDataPtr d = player_mgr.getPlayer(_pid);
				manList& ml = ptr->battleMan;
				for (unsigned i = 0; i < ml.size(); ++i)
				{
					if (!ml[i])
						continue;
					d->KingDomWar().setManHp(ml[i]->manID, ml[i]->currentHP);
				}
			}

			bool IPlayer::isDead()
			{
				playerDataPtr d = player_mgr.getPlayer(_pid);	
				return d->KingDomWar().isDead(_army_id);
			}

			void IPlayer::beDead(unsigned time, qValue& tips)
			{
				playerDataPtr d = player_mgr.getPlayer(_pid);	
				kingdomwar_sys.goBackMainCity(time, d, _army_id, tips);
			}

			void IPlayer::tickBattle(ReportDataPtr& rep_data, ItemPtr& target, bool atk_side)
			{
				playerDataPtr d = player_mgr.getPlayer(_pid);
				BattleInfo& b = atk_side? rep_data->atk_info : rep_data->def_info;

				// result
				int result = repResult(rep_data->result.res, atk_side);
				int star = rep_data->result.star;

				// exploit
				b.exploit = result == Win?
					kingdomwar_sys.winExploit(star) : kingdomwar_sys.loseExploit(star);

				// silver
				b.silver = kingdomwar_sys.battleSilver(d, result);
				int silver = b.silver;
				KingdomPtr kingdom_ptr = kingdom_sys.getData(d->Info().Nation());
				if (kingdom_ptr)
					silver += silver * (double)kingdom_ptr->getAddNum(Kingdom::CBoss) / 10000.0;

				// report declare
				qValue rw;
				if (b.exploit > 0)
				{
					qValue tmp;
					tmp.append(ACTION::exploit_coin);
					tmp.append(b.exploit);
					rw.append(tmp);
				}
				if (b.silver > 0)
				{
					qValue tmp;
					tmp.append(ACTION::silver);
					tmp.append(silver);
					rw.append(tmp);
				}
				rep_data->data.addReportdeclare(atk_side? "rwa" : "rwb", rw);

				// report path
				b.rep_id = d->KingDomWar().getReportID();
				std::string rpath = "kingdomwar/" + Common::toString(d->ID()) + "/" + b.rep_id;
				rep_data->data.addCopyField(rpath);
				if (rep_data->path == "")
					rep_data->path = rpath;
			}

			void IPlayer::doneBattle(ReportDataPtr& rep_data, ItemPtr& target, bool atk_side)
			{
				playerDataPtr d = player_mgr.getPlayer(_pid);
				BattleInfo& b = atk_side? rep_data->atk_info : rep_data->def_info;

				// man hp
				resetHp(b.ptr);

				// result
				int result = repResult(rep_data->result.res, atk_side);
				int star = rep_data->result.star;

				// exploit
				d->Res().alterExploit(b.exploit);

				// army hp
				int hp_cost = result == Win?
					kingdomwar_sys.winHpCost(star) : kingdomwar_sys.loseHpCost(star);
				hp_cost = d->KingDomWar().alterArmyHp(_army_id, 0 - hp_cost);

				// silver
				d->Res().alterSilver(b.silver);

				// rep
				int pos = PosCity;
				int tips = repTips(result, d, _army_id);
				qValue rep;
				rep << (int)REP::BATTLE << rep_data->time << _city->id() << _army_id << _face << target->name() 
					<< target->nation() << target->type() << pos << result << b.exploit << tips 
					<< hp_cost << b.silver << b.rep_id;
				d->KingDomWar().addReport(rep, result, pos, _army_id);

				//
				if (result == Lose || isDead())
				{
					if (result == Lose)
						kingdomwar_sys.goBackMainCity(rep_data->time, d, _army_id, QARRAY((int)TIPS::DEFEATED));
					else
						kingdomwar_sys.goBackMainCity(rep_data->time, d, _army_id, QARRAY((int)TIPS::HPEMPTY));
				}
			}

			void IPlayer::enter(unsigned time)
			{
				playerDataPtr d = player_mgr.getPlayer(_pid);
				if (!d)	return;

				d->KingDomWarPos().sign_update(_army_id);
			}

			void IPlayer::tickElecAttack(unsigned time)
			{
				playerDataPtr d = player_mgr.getPlayer(_pid);
				if (!d)	return;

				int silver = kingdomwar_sys.battleSilver(d, result);
				silver = d->Res().alterSilver(silver);

				int exploit = kingdomwar_sys.elecAttackExploit();
				d->Res().alterExploit(exploit);

				int hp = kingdomwar_sys.elecAttackHp();
				hp = d->KingDomWar().alterArmyHp(_army_id, hp);

				int side = d->Info().Nation() == _city->nation()? Left : Right;
				
				qValue rep;
				rep << (int)REP::ELECATTACK << time << _city->id() << _army_id << _face
					<< side << exploit << hp << silver;
				d->KingDomWar().addReport(rep);

				beDead(time, QARRAY((int)TIPS::ELECATTACK));
			}

			INpc::INpc(NpcDataPtr npc_data, CityPtr& ptr)
				: ItemBase(ptr), _data(npc_data)
			{
			}

			mongo::BSONObj INpc::toBSON() const
			{
				return BSON("t" << _data->type() << "i" << _data->id());
			}

			inline int INpc::face() const
			{
				return _data->npcData()->npcList.front().npcID;
			}

			inline int INpc::lv() const
			{
				return _data->npcData()->mapLevel;
			}

			void INpc::getInfo(qValue& q) const
			{
				q << _data->type() << _data->id() << face() << nation();
			}

			void INpc::getUpInfo(int type, qValue& q) const
			{
				q << _data->type() << _data->id();
				if (type == nCity::Up_Add || type == nCity::Up_Swap)
					q << face() << nation();
			}

			void INpc::getStateInfo(qValue& q, int state) const
			{
				q << _data->type() << face() << lv() << nation() << state;
			}

			void INpc::beDead(unsigned time, qValue& tips)
			{
				_data->setDead(time, tips);
			}

			void INpc::tickBattle(ReportDataPtr& rep_data, ItemPtr& target, bool atk_side)
			{
				qValue rw;
				rep_data->data.addReportdeclare(atk_side? "rwa" : "rwb", rw);
			}

			void INpc::doneBattle(ReportDataPtr& rep_data, ItemPtr& target, bool atk_side)
			{
				// result
				int result = repResult(rep_data->result.res, atk_side);
				int star = rep_data->result.star;

				// hp
				int hp_cost = result == Win?
					kingdomwar_sys.winHpCost(star) : kingdomwar_sys.loseHpCost(star);
				hp_cost = _data->alterHp(0 - hp_cost);

				// man_hp
				_data->resetManHp(atk_side? rep_data->atk_info.ptr : rep_data->def_info.ptr);

				if (result == Lose || isDead())
				{
					if (result == Lose)
						beDead(rep_data->time, QARRAY((int)TIPS::DEFEATED));
					else
						beDead(rep_data->time, QARRAY((int)TIPS::HPEMPTY));
				}
			}

			BattleInfo INpc::getBattleInfo()
			{
				BattleInfo info;
				info.ptr = _data->getBattlePtr(info.max_hp, info.pre_hp);
				info.win_streak = 0;
				return info;
			}

			IShadow::IShadow(ShadowDataPtr data, CityPtr& ptr)
				: ItemBase(ptr), _data(data)
			{
			}

			mongo::BSONObj IShadow::toBSON() const
			{
				return BSON("t" << (int)Shadow << "i" << _data->id());
			}

			const BattleEquipList& IShadow::equipList() const
			{
				static BattleEquipList eq;
				for (unsigned i = 0; i < _data->data()->battleMan.size(); ++i)
				{
					const mBattlePtr& ptr = _data->data()->battleMan[i];
					return ptr->equipList;
				}
				return eq;
			}

			void IShadow::getInfo(qValue& q) const
			{
				q << (int)Shadow << _data->id() << name() << nation() << _face << equipQ(equipList());
			}

			void IShadow::getUpInfo(int type, qValue& q) const
			{
				q << (int)Shadow << _data->id();
				if (type == nCity::Up_Add || type == nCity::Up_Swap)
					q << name() << nation() << _face << equipQ(equipList());
			}

			inline int IShadow::lv() const
			{
				return _data->data()->playerLevel;
			}

			void IShadow::getStateInfo(qValue& q, int state) const
			{
				q <<  (int)Shadow << name() << lv() << nation() << state;
			}

			void IShadow::beDead(unsigned time, qValue& tips)
			{
				_data->setDead(time, tips);
			}

			void IShadow::tickBattle(ReportDataPtr& rep_data, ItemPtr& target, bool atk_side)
			{
				playerDataPtr d = player_mgr.getPlayer(ownID());
				BattleInfo& b = atk_side? rep_data->atk_info : rep_data->def_info;

				// result
				int result = repResult(rep_data->result.res, atk_side);
				int star = rep_data->result.star;

				// exploit
				b.exploit = result == Win?
					kingdomwar_sys.winExploit(star) : kingdomwar_sys.loseExploit(star);

				// silver
				b.silver = 100;

				// report declare
				qValue rw;
				if (b.exploit > 0)
				{
					qValue tmp;
					tmp.append(ACTION::exploit_coin);
					tmp.append(b.exploit);
					rw.append(tmp);
				}
				if (b.silver > 0)
				{
					qValue tmp;
					tmp.append(ACTION::silver);
					tmp.append(b.silver);
					rw.append(tmp);
				}
				rep_data->data.addReportdeclare(atk_side? "rwa" : "rwb", rw);

				// report path
				b.rep_id = d->KingDomWar().getReportID();
				std::string rpath = "kingdomwar/" + Common::toString(d->ID()) + "/" + b.rep_id;
				rep_data->data.addCopyField(rpath);
				if (rep_data->path == "")
					rep_data->path = rpath;
			}

			void IShadow::doneBattle(ReportDataPtr& rep_data, ItemPtr& target, bool atk_side)
			{
				playerDataPtr d = player_mgr.getPlayer(ownID());
				BattleInfo& b = atk_side? rep_data->atk_info : rep_data->def_info;

				// result
				int result = repResult(rep_data->result.res, atk_side);
				int star = rep_data->result.star;

				// exploit
				d->Res().alterExploit(b.exploit);

				// silver
				d->Res().alterSilver(b.silver);

				// hp
				int hp_cost = result == Win?
					kingdomwar_sys.winHpCost(star) : kingdomwar_sys.loseHpCost(star);
				hp_cost = _data->alterHp(0 - hp_cost);
				
				// rep
				int pos = PosCity;
				int tips = -1;//repTips(result, d, _army_id);
				qValue rep;
				rep << (int)REP::BATTLE << rep_data->time << _city->id() << -1 << _face << target->name() 
					<< target->nation() << target->type() << pos << result << b.exploit << tips 
					<< hp_cost << b.silver << b.rep_id;
				d->KingDomWar().addShadowReport(rep);

				//
				if (result == Lose || isDead())
				{
					if (result == Lose)
						beDead(rep_data->time, QARRAY((int)TIPS::DEFEATED << _city->id()));
					else
						beDead(rep_data->time, QARRAY((int)TIPS::HPEMPTY << _city->id()));
				}
			}

			void IShadow::tickElecAttack(unsigned time)
			{
				playerDataPtr d = player_mgr.getPlayer(ownID());
				if (!d)	return;

				int silver = kingdomwar_sys.battleSilver(d, Lose);
				silver = d->Res().alterSilver(silver);

				int exploit = kingdomwar_sys.elecAttackExploit();
				d->Res().alterExploit(exploit);

				int hp = kingdomwar_sys.elecAttackHp();
				hp = d->KingDomWar().alterArmyHp(_army_id, hp);

				int side = d->Info().Nation() == _city->nation()? Left : Right;

				qValue rep;
				rep << (int)REP::ELECATTACK << time << _city->id() << -1 << _face
					<< side << exploit << hp << silver;
				d->KingDomWar().addReport(rep);

				beDead(time, QARRAY((int)TIPS::ELECATTACK << _city->id()));
			}

			BattleInfo IShadow::getBattleInfo()
			{
				BattleInfo info;
				info.ptr = _data->getBattlePtr(info.max_hp, info.pre_hp);
				info.win_streak = 0;
				return info;
			}

			IShadowNpc::IShadowNpc(ShadowNpcDataPtr data, CityPtr& ptr)
				: ItemBase(ptr), _data(data)
			{
			}

			mongo::BSONObj IShadowNpc::toBSON() const
			{
				return BSON("t" << _data->type() << "i" << _data->id());
			}

			inline int IShadowNpc::face() const
			{
				return _data->npcData()->npcList.front().npcID;
			}

			inline int IShadowNpc::lv() const
			{
				return _data->npcData()->mapLevel;
			}

			void IShadowNpc::getInfo(qValue& q) const
			{
				q << _data->type() << _data->id() << face() << nation() << name();
			}

			void IShadowNpc::getUpInfo(int type, qValue& q) const
			{
				q << _data->type() << _data->id();
				if (type == nCity::Up_Add || type == nCity::Up_Swap)
					q << face() << nation() << name();
			}

			void IShadowNpc::getStateInfo(qValue& q, int state) const
			{
				q << _data->type() << name() << lv() << nation() << state;
			}

			void IShadowNpc::beDead(unsigned time, qValue& tips)
			{
				_data->setDead(time, tips);
			}

			void IShadowNpc::tickBattle(ReportDataPtr& rep_data, ItemPtr& target, bool atk_side)
			{
				playerDataPtr d = player_mgr.getPlayer(ownID());
				BattleInfo& b = atk_side? rep_data->atk_info : rep_data->def_info;

				// result
				int result = repResult(rep_data->result.res, atk_side);
				int star = rep_data->result.star;

				// exploit
				b.exploit = result == Win?
					kingdomwar_sys.winExploit(star) : kingdomwar_sys.loseExploit(star);

				// silver
				b.silver = 100;

				// report declare
				qValue rw;
				if (b.exploit > 0)
				{
					qValue tmp;
					tmp.append(ACTION::exploit_coin);
					tmp.append(b.exploit);
					rw.append(tmp);
				}
				if (b.silver > 0)
				{
					qValue tmp;
					tmp.append(ACTION::silver);
					tmp.append(b.silver);
					rw.append(tmp);
				}
				rep_data->data.addReportdeclare(atk_side? "rwa" : "rwb", rw);

				// report path
				b.rep_id = d->KingDomWar().getReportID();
				std::string rpath = "kingdomwar/" + Common::toString(d->ID()) + "/" + b.rep_id;
				rep_data->data.addCopyField(rpath);
				if (rep_data->path == "")
					rep_data->path = rpath;
			}

			void IShadowNpc::doneBattle(ReportDataPtr& rep_data, ItemPtr& target, bool atk_side)
			{
				playerDataPtr d = player_mgr.getPlayer(ownID());
				BattleInfo& b = atk_side? rep_data->atk_info : rep_data->def_info;

				// result
				int result = repResult(rep_data->result.res, atk_side);
				int star = rep_data->result.star;

				// exploit
				d->Res().alterExploit(b.exploit);

				// silver
				d->Res().alterSilver(b.silver);

				// hp
				int hp_cost = result == Win?
					kingdomwar_sys.winHpCost(star) : kingdomwar_sys.loseHpCost(star);
				hp_cost = _data->alterHp(0 - hp_cost);
				
				// rep
				int pos = PosCity;
				int tips = -1;//repTips(result, d, _army_id);
				qValue rep;
				rep << rep_data->time << _city->id() << -1 << face() << target->name() 
					<< target->nation() << target->type() << pos << result << b.exploit << tips 
					<< hp_cost << b.silver << b.rep_id;
				d->KingDomWar().addShadowReport(rep);

				//
				if (result == Lose || isDead())
				{
					if (result == Lose)
						beDead(rep_data->time, QARRAY((int)TIPS::DEFEATED << _city->id()));
					else
						beDead(rep_data->time, QARRAY((int)TIPS::HPEMPTY << _city->id()));
				}
			}

			void IShadowNpc::tickElecAttack(unsigned time)
			{
				playerDataPtr d = player_mgr.getPlayer(ownID());
				if (!d)	return;

				int silver = kingdomwar_sys.battleSilver(d, Lose);
				silver = d->Res().alterSilver(silver);

				int exploit = kingdomwar_sys.elecAttackExploit();
				d->Res().alterExploit(exploit);

				int hp = kingdomwar_sys.elecAttackHp();
				hp = d->KingDomWar().alterArmyHp(_army_id, hp);

				int side = d->Info().Nation() == _city->nation()? Left : Right;

				qValue rep;
				rep << (int)REP::ELECATTACK << time << _city->id() << -1 << _face
					<< side << exploit << hp << silver;
				d->KingDomWar().addReport(rep);

				beDead(time, QARRAY((int)TIPS::ELECATTACK << _city->id()));
			}

			BattleInfo IShadowNpc::getBattleInfo()
			{
				BattleInfo info;
				info.ptr = _data->getBattlePtr(info.max_hp, info.pre_hp);
				info.win_streak = 0;
				return info;
			}

			ItemCounter::ItemCounter()
			{
				_num.assign(Kingdom::nation_num + 1, 0);
			}

			void ItemCounter::push(ItemPtr ptr)
			{
				int idx = ptr->type() == Npc?
					Kingdom::nation_num : ptr->nation();
				++_num[idx];
				if (ptr->type() == Player)
				{
					PlayerPtr pptr = upCast<IPlayer>(ptr);
					pushPlayer(_player_map, pptr);
				}
			}

			void ItemCounter::pop(ItemPtr ptr)
			{
				int idx = ptr->type() == Npc?
					Kingdom::nation_num : ptr->nation();
				--_num[idx];
				if (ptr->type() == Player)
				{
					PlayerPtr pptr = upCast<IPlayer>(ptr);
					popPlayer(_player_map, pptr);
				}
			}

			void ItemCounter::clear()
			{

			}

			bool ItemCounter::pushPlayer(PlayerMap& cmap, PlayerPtr& ptr)
			{
				PlayerMap::iterator it = cmap.find(ptr->pid());
				if (it == cmap.end())
				{
					cmap[ptr->pid()] = PlayerList(1, ptr); 
					return true;
				}
				PlayerList& vec = it->second;
				ForEach(PlayerList, itp, vec)
				{
					if ((*itp) == ptr)
						return false;
				}
				vec.push_back(ptr);
				return true;
			}

			bool ItemCounter::popPlayer(PlayerMap& cmap, PlayerPtr& ptr)
			{
				PlayerMap::iterator it = cmap.find(ptr->pid());
				if (it == cmap.end())
					return false;
				PlayerList& vec = it->second;
				ForEach(PlayerList, itp, vec)
				{
					if ((*itp) == ptr)
					{
						vec.erase(itp);
						if (vec.empty())
							cmap.erase(it);
						return true;
					}
				}
				return false;
			}

			void ItemCounter::updateName(playerDataPtr& d)
			{
				PlayerMap::iterator it = _player_map.find(d->ID());
				if (it == _player_map.end())
				{
					LogE << "kingdom war update name error: " << d->ID() << LogEnd;
					return;
				}
				PlayerList& vec = it->second;
				ForEach(PlayerList, itp, vec)
					(*itp)->alterName(d->Name());
			}
		}

		BattleField::BattleField(CityPtr& ptr)
			: _city(ptr)
		{
			_state = Closed;	
			_tick_timer = 0;
			_next_tick_time = 0;
			_first_battle_nation = -1;
			_battle_queues.assign(QueueNum, BattleQueue());
			_wins.assign(Kingdom::nation_num + 1, -1);
			_counter = _city->_counter;
			_rep_data.assign(QueueNum, nCity::ReportDataPtr());

			_atk_tower.assign(TowerMaxNum, nCity::TowerPtr());
			_def_tower.assign(TowerMaxNum, nCity::TowerPtr());
		}

		void BattleField::init()
		{
			loadDB();
			if (_state != Closed)
			{
				initReadyAttacker(0);
				initReadyDefender(0);
			}
			kingdomwar_sys.addUpdater(boostBind(BattleField::tick, upCast<BattleField>(shared_from_this())));
		}

		void BattleField::loadDB()
		{
			mongo::BSONObj key = BSON("ci" << _city->id());
			mongo::BSONObj obj = db_mgr.FindOne(DBN::dbKingdomWarCityBattle, key);
			if (obj.isEmpty())
				return;
			
			_state = obj["st"].Int();
			if (_state == Closed)
				return;
			_next_tick_time = obj["ntt"].Int();
			_first_battle_nation = obj["fbn"].Int();
			{
				std::vector<mongo::BSONElement> ele = obj["bq"].Array();
				for (unsigned i = 0; i < ele.size(); ++i)
				{
					_battle_queues[i].next_battle_time = ele[i]["nbt"].Int();
					checkNotEoo(ele[i]["atk"])
					{
						_battle_queues[i].atk_ready_time = ele[i]["art"].Int();
						_battle_queues[i].atk_side = makeItem(ele[i]["atk"], Left);
					}
					checkNotEoo(ele[i]["def"])
					{
						_battle_queues[i].def_ready_time = ele[i]["drt"].Int();
						_battle_queues[i].def_side = makeItem(ele[i]["def"], Right);
					}
				}
			}
			{
				std::vector<mongo::BSONElement> ele = obj["ws"].Array();
				for (unsigned i = 0; i < Kingdom::nation_num; ++i)
					_wins[i] = ele[i].Int();
			}
			checkNotEoo(obj["atr"])
			{
				std::vector<mongo::BSONElement> ele = obj["atr"].Array();
				for (unsigned i = 0; i < ele.size(); ++i)
				{
					if (i >= TowerMaxNum)
						break;
					_atk_tower[i] = createTower(ele[i], Left);
					if (_atk_tower[i])
						_atk_tower_type[_atk_tower[i]->type()].push_back(_atk_tower[i]);
				}
			}
			checkNotEoo(obj["dtr"])
			{
				std::vector<mongo::BSONElement> ele = obj["dtr"].Array();
				for (unsigned i = 0; i < ele.size(); ++i)
				{
					if (i >= TowerMaxNum)
						break;
					_def_tower[i] = createTower(ele[i], Right);
					if (_def_tower[i])
						_def_tower_type[_def_tower[i]->type()].push_back(_def_tower[i]);
				}
			}
			checkNotEoo(obj["epm"])
			{
				std::vector<mongo::BSONElement> ele = obj["epm"].Array();
				for (unsigned i = 0; i < ele.size(); ++i)
					_exploit_map[ele[i]["i"].Int()] = ele[i]["e"].Int();
			}

			if (_state == Opened)
			{
				for (unsigned i = 0; i < QueueNum; ++i)
				{
					if (_battle_queues[i].atk_side && _battle_queues[i].def_side)
						setBattleTimer(_battle_queues[i].next_battle_time, i);
				}
			}
			if (_state == StartWait)
				setOpenTimer();
			if (_state == AttackerWait)
				setAttackerWaitTimer();
			if (_state == DefenderWait)
				setDefenderWaitTimer();
			if (_state == Protected)
				setCloseTimer();
		}

		void BattleField::upElecLifeTime(int side, int id)
		{
			
		}

		nCity::ItemPtr BattleField::makeItem(const mongo::BSONElement& obj, int side)
		{
			int type = obj["t"].Int();
			switch(type)
			{
				case Player:
				{
					int pid = obj["p"].Int();
					int army_id = obj["a"].Int();
					return side == Left? 
						_city->getAttacker(pid, army_id) : _city->getDefender(pid, army_id);
				}
				case Npc:
				case ActiveNpc:
				case Shadow:
				case ShadowNpc:
				{
					int id = obj["i"].Int();
					return side == Left? 
						_city->getAttacker(id) : _city->getDefender(id);
				}
				default:
					return nCity::ItemPtr();
			}
		}

		void BattleField::removeTowerFromType(int side, int type, int id)
		{
			TowerList& tl = side == Left?
				_atk_tower_type[type] : _def_tower_type[type];
			ForEach(TowerList, it, tl)
			{
				if ((*it)->id() == id)
				{
					tl.erase(it);
					return;
				}
			}
		}

		void BattleField::removeTower(unsigned cur_time, int side, int id)
		{
			TowerList& tl = side == Left? _atk_tower : _def_tower;
			for (unsigned i = 0; i < tl.size(); ++i)
			{
				nCity::TowerPtr& ptr = tl[i];
				if (ptr && ptr->id() == id)
				{
					removeTowerFromType(side, ptr->type(), id);
					PUSH_UPDATER(Creator<nCity::UpDelTower>::Create(side, i))
					ptr.reset();
					return;
				}
			}
		}

		int BattleField::callElecTower(unsigned cur_time, playerDataPtr d)
		{
			if (_state == Closed || _state == Protected)
				return err_illedge;
			int side = d->Info().Nation() != _city->nation()?
				Left : Right;
			TowerList& tl = side == Left? _atk_tower : _def_tower;
			for (unsigned i = 0; i < tl.size(); ++i)
			{
				nCity::TowerPtr& ptr = tl[i];
				if (!ptr)
				{
					nCity::ElecTowerPtr nptr = Creator<nCity::ElecTower>::Create(cur_time, side, upCast<BattleField>(shared_from_this()));
					nptr->init();
					ptr = nptr;
					PUSH_UPDATER(Creator<nCity::UpTower>::Create(side, i, ptr));
					if (side == Left)
						_atk_tower_type[ptr->type()].push_back(ptr);
					else
						_def_tower_type[ptr->type()].push_back(ptr);
					return res_sucess;
				}
			}
			return err_illedge;
		}

		void BattleField::tickElecAttack(unsigned tick_time, int side, int id)
		{
			std::deque<nCity::ItemPtr>& il = side == Left?
				_ready_defenders : _ready_attackers;
			if (il.empty())
				return;
			TowerList& tl = side == Left? 
				_atk_tower : _def_tower;

			for (unsigned i = 0; i < tl.size(); ++i)
			{
				if (tl[i] && tl[i]->id() == id)
				{
					nCity::ElecTowerPtr ptr = upCast<nCity::ElecTower>(tl[i]);
					if (!ptr)
						return;
					nCity::ItemPtr iptr = il.front();
					il.pop_front();
					iptr->tickElecAttack(tick_time);
					PUSH_UPDATER(Creator<nCity::UpElecAttack>::Create(side, i));
					return;
				}
			}
		}

		void BattleField::resetData()
		{
			if (_main_info.isEmpty())
				_updater.clear();
		}

		void BattleField::getInfo(qValue& q) const
		{
			if (_main_info.isEmpty())
				resetMainInfo();
			q = _main_info.Copy();
		}

		void BattleField::resetMainInfo() const
		{
			_main_info.toObject();
			qValue a;
			const std::vector<int>& num = _counter->num();
			for (unsigned i = 0; i < num.size(); ++i)
				a.append(num[i]);
			_main_info.addMember("a", a);
			_main_info.addMember("s", _state);
			_main_info.addMember("tt", _next_tick_time);
			qValue ra;
			for (unsigned i = 0; i < _atk_pos_offset; ++i)
			{
				qValue tmp;
				ra.append(tmp);
			}
			for (unsigned i = 0; i < _ready_attackers.size(); ++i)
			{
				qValue tmp;
				_ready_attackers[i]->getInfo(tmp);
				ra.append(tmp);
			}
			_main_info.addMember("ra", ra);
			qValue rd;
			for (unsigned i = 0; i < _def_pos_offset; ++i)
			{
				qValue tmp;
				rd.append(tmp);
			}
			for (unsigned i = 0; i < _ready_defenders.size(); ++i)
			{
				qValue tmp;
				_ready_defenders[i]->getInfo(tmp);
				rd.append(tmp);
			}
			_main_info.addMember("rd", rd);
			qValue b;
			for (unsigned i = 0; i < QueueNum; ++i)
			{
				qValue tmp_both;
				qValue tmp_atk;
				qValue tmp_def;
				if (_battle_queues[i].atk_side)
				{
					qValue tmp;
					_battle_queues[i].atk_side->getInfo(tmp);
					tmp_atk.append(tmp);
					tmp_atk.append(_battle_queues[i].atk_ready_time);
				}
				if (_battle_queues[i].def_side)
				{
					qValue tmp;
					_battle_queues[i].def_side->getInfo(tmp);
					tmp_atk.append(tmp);
					tmp_atk.append(_battle_queues[i].def_ready_time);
				}
				tmp_both.append(tmp_atk);
				tmp_both.append(tmp_def);
				b.append(tmp_both);
			}
			_main_info.addMember("b", b);
			qValue rep;
			for (unsigned i = 0; i < QueueNum; ++i)
			{
				qValue tmp;
				if (_rep_data[i])
					_rep_data[i]->getInfo(tmp);
				rep.append(tmp);
			}
			_main_info.addMember("rep", rep);

			qValue atr;
			for (unsigned i = 0; i < _atk_tower.size(); ++i)
			{
				qValue tmp;
				if (_atk_tower[i])
					_atk_tower[i]->getInfo(tmp);
				atr.append(tmp);
			}
			_main_info.addMember("atr", atr);

			qValue dtr;
			for (unsigned i = 0; i < _def_tower.size(); ++i)
			{
				qValue tmp;
				if (_def_tower[i])
					_def_tower[i]->getInfo(tmp);
				dtr.append(tmp);
			}
			_main_info.addMember("dtr", dtr);
		}

		void BattleField::tick()
		{
			if (!_modified)
				return;
			_modified = false;

			//LogI << "size:" << _updater.size() << ", capacity:" << _updater.capacity() << LogEnd;

			_main_info.toObject();
			if (!_city->empty())
			{
				qValue mm(qJson::qj_object);
				qValue m;
				m.append(res_sucess);
				qValue qq(qJson::qj_object);
				qValue a;
				const std::vector<int>& num = _counter->num();
				for (unsigned i = 0; i < num.size(); ++i)
					a.append(num[i]);
				qq.addMember("a", a);
				qq.addMember("s", _state);
				qq.addMember("tt", _next_tick_time);
				qValue u;
				_updater.getInfo(u);
				qq.addMember("u", u);
				m.append(qq);
				mm.addMember(strMsg, m);
				detail::batchOnline(_city->getObserver(), mm, gate_client::kingdom_war_city_battle_update_resp);
			}
			_updater.clear();
		}

		void BattleField::changeState(int state, unsigned cur_time)
		{
			_state = state;
			_next_tick_time = cur_time;
			switch(_state)
			{
				case StartWait:
					if (State::shared().isPrimeTime())
						_next_tick_time = cur_time + (StartWaitInterval / 10);
					else
						_next_tick_time = cur_time + StartWaitInterval;
					setOpenTimer();
					break;
				case AttackerWait:
					_next_tick_time = cur_time + AttackerWaitInterval;
					setAttackerWaitTimer();
					break;
				case DefenderWait:
					_next_tick_time = cur_time + DefenderWaitInterval;
					setDefenderWaitTimer();
					break;
				case Protected:
					if (State::shared().isPrimeTime())
						_next_tick_time = cur_time + (ProtectedInterval / 20);
					else
						_next_tick_time = cur_time + ProtectedInterval;
					setCloseTimer();
				default:
					break;
			}
		}

		void BattleField::handleAddAttacker(unsigned tick_time)
		{
			_sign_save();
			if (_state == Closed)
				tickStartWait(tick_time);
			tryLoadReadyAttacker(tick_time);
			if (_state == StartWait)
				return;
			if (_state == DefenderWait) 
			{
				if (noDefenders())
					changeState(AttackerWait, tick_time);
				else
					changeState(Opened, tick_time);
			}
			if (_state == Opened)
				tryMoveAttacker(tick_time);
		}

		void BattleField::handleAddDefender(unsigned tick_time)
		{
			if (_state == Closed
				|| _state == Protected)
				return;
			_sign_save();
			tryLoadReadyDefender(tick_time);
			if (_state == StartWait)
				return;
			if (_state == AttackerWait)
				changeState(Opened, tick_time);
			if (_state == Opened)
				tryMoveDefender(tick_time);
		}

		void BattleField::setBattleTimer(unsigned tick_time, int id)
		{
			++_battle_queues[id].battle_timer;
			_battle_queues[id].next_battle_time = tick_time;
			kingdomwar_sys.addTimer(tick_time, boostBind(BattleField::tickBattle, upCast<BattleField>(shared_from_this()), _battle_queues[id].battle_timer, tick_time, id));
		}

		void BattleField::setOpenTimer()
		{
			++_tick_timer;
			kingdomwar_sys.addTimer(_next_tick_time, boostBind(BattleField::tickOpen, upCast<BattleField>(shared_from_this()), _tick_timer, _next_tick_time));
		}

		void BattleField::setCloseTimer()
		{
			++_tick_timer;
			kingdomwar_sys.addTimer(_next_tick_time, boostBind(BattleField::tickCloseFromProtected, upCast<BattleField>(shared_from_this()), _tick_timer, _next_tick_time));
		}

		void BattleField::setAttackerWaitTimer()
		{
			++_tick_timer;
			kingdomwar_sys.addTimer(_next_tick_time, boostBind(BattleField::tickAttackerWait, upCast<BattleField>(shared_from_this()), _tick_timer, _next_tick_time));
		}

		void BattleField::setDefenderWaitTimer()
		{
			++_tick_timer;
			kingdomwar_sys.addTimer(_next_tick_time, boostBind(BattleField::tickDefenderWait, upCast<BattleField>(shared_from_this()), _tick_timer, _next_tick_time));
		}

		void BattleField::tickOpen(unsigned timer_id, unsigned tick_time)
		{
			if (timer_id != _tick_timer)
				return;
			_sign_save();
			if (toAttackerWait(tick_time))
				return;
			changeState(Opened, tick_time);
			for (unsigned i = 0; i < QueueNum; ++i)
			{
				if (!tryGetBoth(tick_time, i))
					break;
			}
		}

		bool BattleField::toAttackerWait(unsigned tick_time)
		{
			if (!noDefenders())
				return false;
			changeState(AttackerWait, tick_time);
			return true;
		}

		bool BattleField::toDefenderWait(unsigned tick_time)
		{
			if (!noAttackers())
				return false;
			changeState(DefenderWait, tick_time);
			return true;
		}

		void BattleField::tickStartWait(unsigned tick_time)
		{
			changeState(StartWait, tick_time);
			initReadyDefender(tick_time);
		}

		void BattleField::initReadyDefender(unsigned tick_time)
		{
			while(_ready_defenders.size() < ReadyMemNum)
			{
				nCity::ItemPtr ptr = _city->getDefender();
				if (!ptr)
					break;
				_ready_defenders.push_back(ptr);
			}
		}

		void BattleField::initReadyAttacker(unsigned tick_time)
		{
			while(_ready_attackers.size() < ReadyMemNum)
			{
				nCity::ItemPtr ptr = _city->getAttacker();
				if (!ptr)
					break;
				_ready_attackers.push_back(ptr);
			}
		}

		bool BattleField::tryLoadReadyAttacker(unsigned tick_time)
		{
			bool ret = false;
			while(_ready_attackers.size() + _atk_pos_offset < ReadyMemNum)
			{
				if (!doLoadReadyAttacker(tick_time))
					break;
				ret = true;
			}
			return ret;
		}

		bool BattleField::doLoadReadyAttacker(unsigned tick_time)
		{
			nCity::ItemPtr ptr = _city->getAttacker();
			if (!ptr)
				return false;
			_ready_attackers.push_back(ptr);
			PUSH_UPDATER(Creator<nCity::UpAdd>::Create((int)Left, ptr))
			return true;
		}

		int BattleField::getNpcPosIdx() const
		{
			for(unsigned i = 0; i < _ready_defenders.size(); ++i)
			{
				if (_ready_defenders[i]->type() == Npc)
					return i;
			}
			return _ready_defenders.size();
		}

		bool BattleField::tryLoadReadyDefender(unsigned tick_time)
		{
			bool ret = false;
			int npc_pos = getNpcPosIdx();
			while (npc_pos < _ready_defenders.size())
			{
				if (_city->_defender_backup.empty())
					break;
				doLoadReadyDefender(tick_time, npc_pos);
				++npc_pos;
				ret = true;
			}
			while(_ready_defenders.size() + _def_pos_offset < ReadyMemNum)
			{
				if (!doLoadReadyDefender(tick_time, _ready_defenders.size()))
					break;
				ret = true;
			}
			return ret;
		}

		bool BattleField::doLoadReadyDefender(unsigned tick_time, int pos)
		{
			nCity::ItemPtr ptr = _city->getDefender();
			if (!ptr)
				return false;
			if (pos >= _ready_defenders.size() || ptr->type() == Npc)
			{
				_ready_defenders.push_back(ptr);
				PUSH_UPDATER(Creator<nCity::UpAdd>::Create((int)Right, ptr))
			}
			else
			{
				int npc_pos = 0;
				nCity::ItemPtr npc_ptr = _ready_defenders[pos];
				_ready_defenders[pos] = ptr;
				if (_ready_defenders.size() + _def_pos_offset < ReadyMemNum)
				{
					_ready_defenders.push_back(npc_ptr);
					npc_pos = _ready_defenders.size() + _def_pos_offset;
				}
				else
				{
					_city->_npc_list.push_back(npc_ptr);
				}
				PUSH_UPDATER(Creator<nCity::UpSwap>::Create((int)Right, pos + 1 + _def_pos_offset, npc_pos, ptr));
			}
			return true;
		}

		bool BattleField::tryMoveAttacker(unsigned tick_time)
		{
			for (unsigned i = 0; i < QueueNum; ++i)
			{
				if (!_battle_queues[i].atk_side
					&& _battle_queues[i].def_side)
				{
					return tryGetAttacker(tick_time, i);
				}
			}
			for (unsigned i = 0; i < QueueNum; ++i)
			{
				if (!_battle_queues[i].atk_side
					&& !_battle_queues[i].def_side)
				{
					return tryGetBoth(tick_time, i);
				}
			}
			return false;
		}
		
		bool BattleField::tryMoveDefender(unsigned tick_time)
		{
			for (unsigned i = 0; i < QueueNum; ++i)
			{
				if (_battle_queues[i].atk_side
					&& !_battle_queues[i].def_side)
				{
					return tryGetDefender(tick_time, i);
				}
			}
			for (unsigned i = 0; i < QueueNum; ++i)
			{
				if (!_battle_queues[i].atk_side
					&& !_battle_queues[i].def_side)
				{
					return tryGetBoth(tick_time, i);
				}
			}
			return false;
		}

		bool BattleField::tryGetBoth(unsigned tick_time, int queue_id) 
		{
			if (_ready_attackers.empty()
				|| _ready_defenders.empty())
				return false;
				
			getPlayer(tick_time, Left, queue_id);
			getPlayer(tick_time, Right, queue_id);
			setBattleTimer(tick_time + BattleWaitInterval, queue_id);
			return true;
		}

		void BattleField::crossDefender(unsigned tick_time, int qid_from, int qid_to)
		{
			_battle_queues[qid_to].def_side = _battle_queues[qid_from].def_side;
			_battle_queues[qid_to].def_ready_time = tick_time + BattleWaitInterval;
			_battle_queues[qid_from].def_side.reset();
			PUSH_UPDATER(Creator<nCity::UpCross>::Create(qid_from, qid_to, tick_time + BattleWaitInterval))
		}

		bool BattleField::tryResetDefender(unsigned tick_time, int queue_id)
		{
			for (unsigned i = 0; i < QueueNum; ++i)
			{
				if (i == queue_id)
					continue;
				if (_battle_queues[i].atk_side
					&& !_battle_queues[i].def_side)
				{
					crossDefender(tick_time, queue_id, i);
					setBattleTimer(tick_time + BattleWaitInterval, i);
					return true;
				}
			}
			return false;
		}

		void BattleField::getPlayer(unsigned tick_time, int side, int queue_id)
		{
			PUSH_UPDATER(Creator<nCity::UpMove>::Create(side, queue_id, tick_time + BattleWaitInterval))
			if (side == Left)
			{
				_battle_queues[queue_id].atk_side = _ready_attackers.front();
				_ready_attackers.pop_front();
				_battle_queues[queue_id].atk_ready_time = tick_time + BattleWaitInterval;
				if (_ready_attackers.empty())
					_atk_pos_offset = 0;
				else
				{
					++_atk_pos_offset;
					_atk_pos_offset %= QueueMemNum;
				}
				tryLoadReadyAttacker(tick_time);
			}
			else
			{
				_battle_queues[queue_id].def_side = _ready_defenders.front();
				_ready_defenders.pop_front();
				_battle_queues[queue_id].def_ready_time = tick_time + BattleWaitInterval;
				if (_ready_defenders.empty())
					_def_pos_offset = 0;
				else
				{
					++_def_pos_offset;
					_def_pos_offset %= QueueMemNum;
				}
				tryLoadReadyDefender(tick_time);
			}
		}

		bool BattleField::tryGetAttacker(unsigned tick_time, int queue_id)
		{
			if (_ready_attackers.empty())
				return false;
			getPlayer(tick_time, Left, queue_id);
			setBattleTimer(tick_time + BattleWaitInterval, queue_id);
			return true;
		}

		bool BattleField::tryGetDefender(unsigned tick_time, int queue_id)
		{
			for (unsigned i = 0; i < QueueNum; ++i)
			{
				if (queue_id == i)
					continue;
				if (!_battle_queues[i].atk_side
					&& _battle_queues[i].def_side)
				{
					crossDefender(tick_time, i, queue_id);
					setBattleTimer(tick_time + BattleWaitInterval, queue_id);
					return true;
				}
			}
			if (_ready_defenders.empty())
				return false;
			getPlayer(tick_time, Right, queue_id);
			setBattleTimer(tick_time + BattleWaitInterval, queue_id);
			return true;
		}

		void BattleField::addWins(int res, nCity::ItemPtr atk_ptr, nCity::ItemPtr def_ptr)
		{
			int atk_nation = atk_ptr->type() == Npc? Kingdom::nation_num : atk_ptr->nation();
			int def_nation = def_ptr->type() == Npc? Kingdom::nation_num : def_ptr->nation();
			if (_first_battle_nation == -1)
				_first_battle_nation = atk_nation;
			if (_wins[atk_nation] == -1)
				_wins[atk_nation] = 0;
			if (_wins[def_nation] == -1)
				_wins[def_nation] = 0;
			if (res == resBattle::atk_win)
				++_wins[atk_nation];
			else
				++_wins[def_nation];
		}

		void BattleField::doneBattle(unsigned timer_id, unsigned tick_time, int idx, nCity::ReportDataPtr& rep_data)
		{
			if (timer_id != _battle_queues[idx].battle_timer)
				return;
			_rep_data[idx].reset();
			_sign_save();

			nCity::ItemPtr& atk_ptr = _battle_queues[idx].atk_side;
			nCity::ItemPtr& def_ptr = _battle_queues[idx].def_side;
			atk_ptr->doneBattle(rep_data, def_ptr, true);
			def_ptr->doneBattle(rep_data, atk_ptr, false);
			addWins(rep_data->result.res, atk_ptr, def_ptr);
			
			if (rep_data->result.res == resBattle::def_win
				|| atk_ptr->isDead())
			{
				if (rep_data->result.res == resBattle::def_win)
					PUSH_UPDATER(Creator<nCity::UpDel>::Create((int)Left, idx, QARRAY((int)TIPS::DEFEATED), atk_ptr))
				else
					PUSH_UPDATER(Creator<nCity::UpDel>::Create((int)Left, idx, QARRAY((int)TIPS::HPEMPTY), atk_ptr))
				_counter->pop(atk_ptr);
				atk_ptr.reset();
			}
			if (rep_data->result.res == resBattle::atk_win 
				|| def_ptr->isDead())
			{
				if (rep_data->result.res == resBattle::atk_win)
					PUSH_UPDATER(Creator<nCity::UpDel>::Create((int)Right, idx, QARRAY((int)TIPS::DEFEATED), def_ptr))
				else
					PUSH_UPDATER(Creator<nCity::UpDel>::Create((int)Right, idx, QARRAY((int)TIPS::HPEMPTY), def_ptr))
				_counter->pop(def_ptr);
				def_ptr.reset();
			}

			if (!_battle_queues[idx].atk_side
				&& !_battle_queues[idx].def_side)
			{
				if (!tryGetBoth(tick_time, idx)
					&& !toDefenderWait(tick_time))
					toAttackerWait(tick_time);
				return;
			}

			if (!_battle_queues[idx].atk_side)
			{
				if (!tryResetDefender(tick_time, idx)
					&& !tryGetAttacker(tick_time, idx))
				{
					toDefenderWait(tick_time);
				}
				return;
			}

			if (!_battle_queues[idx].def_side)
			{
				if (!tryGetDefender(tick_time, idx))
					toAttackerWait(tick_time);
				return;
			}
		}

		void BattleField::tickBattle(unsigned timer_id, unsigned tick_time, int idx)
		{
			if (timer_id != _battle_queues[idx].battle_timer)
				return;

			nCity::ItemPtr& atk_ptr = _battle_queues[idx].atk_side;
			nCity::ItemPtr& def_ptr = _battle_queues[idx].def_side;
			nCity::ReportDataPtr rep_data = Creator<nCity::ReportData>::Create(tick_time, atk_ptr, def_ptr);
			rep_data->one2one();
			atk_ptr->tickBattle(rep_data, def_ptr, true);
			def_ptr->tickBattle(rep_data, atk_ptr, false);
			rep_data->done();
			PUSH_UPDATER(Creator<nCity::UpReport>::Create(idx, rep_data))
			_rep_data[idx] = rep_data;
			unsigned battle_time = (unsigned)ceil(rep_data->data.getDamageList().size() * TimePerRound) + 1;
			kingdomwar_sys.addTimer(tick_time + battle_time, boostBind(BattleField::doneBattle, upCast<BattleField>(shared_from_this()), timer_id, tick_time + battle_time, idx, rep_data));
			_sign_save();
		}

		int BattleField::getWinNation()
		{
			int win_nation = -1;
			int win_max = -1;
			for (unsigned i = 0; i < Kingdom::nation_num; ++i)
			{
				if (i == _city->nation())
					continue;
				if (_wins[i] > win_max)
				{
					win_max = _wins[i];
					win_nation = i;
				}
			}
			if (win_nation == -1)
				return _city->nation();
			for (unsigned i = 0; i < Kingdom::nation_num; ++i)
			{
				if (i == _city->nation())
					continue;
				if (i == win_nation)
					continue;
				if (_wins[i] == win_max)
					return _first_battle_nation;
			}
			return win_nation;
		}

		void BattleField::tickAttackerWait(unsigned timer_id, unsigned tick_time)
		{
			if (timer_id != _tick_timer)
				return;

			if (_state == AttackerWait)
			{
				for (std::deque<nCity::ItemPtr>::reverse_iterator it = _ready_attackers.rbegin()
					; it != _ready_attackers.rend(); ++it)
				{
					_city->_attacker_backup.push_front(*it);
				}
				_ready_attackers.clear();
				for (unsigned i = 0; i < QueueNum; ++i)
				{
					if (_battle_queues[i].atk_side)
					{
						_city->_attacker_backup.push_front(_battle_queues[i].atk_side);
						_battle_queues[i].atk_side.reset();
					}
				}
				int win_nation = getWinNation();
				Log(DBLOG::strLogKingdomWar, 4, _city->nation(), win_nation, _wins[0u] == -1? 0 : _wins[0u], _wins[1u] == -1? 0 : _wins[1u],  _wins[2u] == -1? 0 : _wins[2u], _city->id());
				tickProtected(tick_time);
				_city->handleBattleResult(tick_time, true, win_nation);
				_sign_save();
			}
		}

		void BattleField::tickDefenderWait(unsigned timer_id, unsigned tick_time)
		{
			if (timer_id != _tick_timer)
				return;

			if (_state == DefenderWait)
			{
				for (std::deque<nCity::ItemPtr>::reverse_iterator it = _ready_defenders.rbegin()
					; it != _ready_defenders.rend(); ++it)
				{
					nCity::ItemPtr ptr = *it;
					if (ptr->type() == Npc)
						_city->_npc_list.push_front(ptr);
					else
						_city->_defender_backup.push_front(ptr);
				}
				_ready_defenders.clear();
				for (unsigned i = 0; i < QueueNum; ++i)
				{
					if (_battle_queues[i].def_side)
					{
						nCity::ItemPtr& ptr = _battle_queues[i].def_side;
						if (ptr->type() == Npc)
							_city->_npc_list.push_front(ptr);
						else
							_city->_defender_backup.push_front(ptr);
						ptr.reset();
					}
				}
				tickClose(tick_time);
				_city->handleBattleResult(tick_time, false);
				_sign_save();
			}
		}

		void BattleField::tickProtected(unsigned tick_time)
		{
			siegeInfo(true, tick_time);
			emailReward();
			reset();
			changeState(Protected, tick_time);
			_sign_save();
		}

		void BattleField::emailReward()
		{
			ForEach(ExploitMap, it, _exploit_map)
			{
				int pid = it->first;
				unsigned exploit = it->second;
				int box_num = nCity::BoxConfig::shared().getGoldBoxNumByExploit(exploit);
				Json::Value pl;
				pl.append(_city->id());
				pl.append(exploit);
				pl.append(box_num);
				Json::Value rw;
				Json::Value tmp;
				tmp.append(ACTION::item);
				tmp.append(nCity::BoxConfig::shared().getGoldBoxID());
				tmp.append(box_num);
				EmailPtr e = email_sys.createPackage(EmailDef::KingdomWarCityReward, pl, rw);
				email_sys.sendToPlayer(pid, e);
			}
			_exploit_map.clear();
		}

		void BattleField::siegeInfo(bool result, unsigned tick_time)
		{
			if (!_city->empty())
			{
				qValue mm(qJson::qj_object);
				qValue m;
				m.append(res_sucess);
				qValue q(qJson::qj_object);
				q.addMember("r", result);
				q.addMember("n", _city->nation());
				q.addMember("c", _city->id());
				{
					qValue w;
					for (unsigned i = 0; i <= Kingdom::nation_num; ++i)
						w.append(_wins[i]);
					q.addMember("w", w);
				}
				{
					qValue l;
					const std::vector<int>& num = _counter->num();
					for (unsigned i = 0; i <= Kingdom::nation_num; ++i)
						l.append(num[i]);
					q.addMember("l", l);
				}
				m.append(q);
				mm.addMember(strMsg, m);
				detail::batchOnline(_city->getObserver(), mm, gate_client::kingdom_war_siege_info_resp);
			}
		}

		void BattleField::tickCloseFromProtected(unsigned timer_id, unsigned tick_time)
		{
			if (timer_id != _tick_timer)
				return;
			changeState(Closed, tick_time);
			_sign_save();
		}
		
		void BattleField::tickClose(unsigned tick_time)
		{
			siegeInfo(false, tick_time);	
			changeState(Closed, tick_time);
			reset();
			_sign_save();
		}

		void BattleField::reset()
		{
			_next_tick_time = 0;
			_first_battle_nation = -1;
			++_tick_timer;
			_atk_pos_offset = 0;
			_def_pos_offset = 0;
			for (unsigned i = 0; i < QueueNum; ++i)
				_battle_queues[i].battle_timer = 0;
			for (unsigned i = 0; i <= Kingdom::nation_num; ++i)
				_wins[i] = -1;
			for (unsigned i = 0; i < _atk_tower.size(); ++i)
			{
				if (_atk_tower[i])
				{
					_atk_tower[i]->setState(nCity::DEAD);
					_atk_tower[i].reset();
				}
			}
			for (unsigned i = 0; i < _def_tower.size(); ++i)
			{
				if (_def_tower[i])
				{
					_def_tower[i]->setState(nCity::DEAD);
					_def_tower[i].reset();
				}
			}
			for (unsigned i = 0; i < nCity::TOWER_MAX; ++i)
			{
				_atk_tower_type[i].clear();
				_def_tower_type[i].clear();
			}
			_exploit_map.clear();
		}

		nCity::TowerPtr BattleField::createTower(const mongo::BSONElement& obj, int side)
		{
			int type = obj["t"].Int();
			switch(type)
			{
				case nCity::ELECTOWER:
				{
					nCity::ElecTowerPtr ptr = Creator<nCity::ElecTower>::Create(obj, side, upCast<BattleField>(shared_from_this()));
					ptr->init();
					return ptr;
				}
				default:
					return nCity::TowerPtr();
			}
		}

		bool BattleField::_auto_save()
		{
			mongo::BSONObj key = BSON("ci" << _city->id());
			mongo::BSONObjBuilder obj;
			obj << "ci" << _city->id() << "st" << _state << "ntt" << _next_tick_time;
			if (_state != Closed && _state != Protected)
			{
				obj << "fbn" << _first_battle_nation;
				{
					mongo::BSONArrayBuilder b;
					for (unsigned i = 0; i < QueueNum; ++i)
					{
						mongo::BSONObjBuilder o;
						o << "nbt" << _battle_queues[i].next_battle_time;
						if (_battle_queues[i].atk_side)
							o << "atk" << _battle_queues[i].atk_side->toBSON() << "art" << _battle_queues[i].atk_ready_time;
						if (_battle_queues[i].def_side)
							o << "def" << _battle_queues[i].def_side->toBSON() << "drt" << _battle_queues[i].def_ready_time;
						b.append(o.obj());
					}
					obj << "bq" << b.arr();
				}
				{
					mongo::BSONArrayBuilder b;
					for (unsigned i = 0; i < Kingdom::nation_num; ++i)
						b.append(_wins[i]);
					obj << "ws" << b.arr();
				}
				if (!_atk_tower.empty())
				{
					mongo::BSONArrayBuilder b;
					ForEach(TowerList, it, _atk_tower)
					{
						if (*it)
							b.append((*it)->toBSON());
						else
							b.append(BSON("t" << (int)nCity::TOWER_MAX));
					}
					obj << "atr" << b.arr();
				}
				if (!_def_tower.empty())
				{
					mongo::BSONArrayBuilder b;
					ForEach(TowerList, it, _def_tower)
					{
						if (*it)
							b.append((*it)->toBSON());
						else
							b.append(BSON("t" << (int)nCity::TOWER_MAX));
					}
					obj << "dtr" << b.arr();
				}
				if (!_exploit_map.empty())
				{
					mongo::BSONArrayBuilder b;
					ForEachC(ExploitMap, it, _exploit_map)
						b.append(BSON("i" << it->first << "e" << it->second));
					obj << "epm" << b.arr();
				}
			}
			return db_mgr.SaveMongo(DBN::dbKingdomWarCityBattle, key, obj.obj());
		}

		void BattleField::_sign_save()
		{
			_auto_meta::_sign_save();
			_modified = true;
		}

		bool BattleField::noAttackers() const
		{
			for (unsigned i = 0; i < QueueNum; ++i)
			{
				if (_battle_queues[i].atk_side)
					return false;
			}
			return _ready_attackers.empty();
		}

		bool BattleField::noDefenders() const
		{
			for (unsigned i = 0; i < QueueNum; ++i)
			{
				if (_battle_queues[i].def_side)
					return false;
			}
			return _ready_defenders.empty();
		}

		bool BattleField::onFight(NpcDataPtr d)
		{
			if (d->nation() != _city->nation())
			{
				for (unsigned i = 0; i < QueueNum; ++i)
				{
					if (_battle_queues[i].atk_side)
					{
						nCity::NpcPtr ptr = upCast<nCity::INpc>(_battle_queues[i].atk_side);
						if (ptr && ptr->id() == d->id())
							return true;
					}
				}
				for (unsigned i = 0; i < _ready_attackers.size(); ++i)
				{
					nCity::NpcPtr ptr = upCast<nCity::INpc>(_ready_attackers[i]);
					if (ptr && ptr->id() == d->id())
						return true;
				}
			}
			else
			{
				for (unsigned i = 0; i < QueueNum; ++i)
				{
					if (_battle_queues[i].def_side)
					{
						nCity::NpcPtr ptr = upCast<nCity::INpc>(_battle_queues[i].def_side);
						if (ptr && ptr->id() == d->id())
							return true;
					}
				}
				for (unsigned i = 0; i < _ready_defenders.size(); ++i)
				{
					nCity::NpcPtr ptr = upCast<nCity::INpc>(_ready_defenders[i]);
					if (ptr && ptr->id() == d->id())
						return true;
				}
			}
			return false;
		}

		bool BattleField::onFight(playerDataPtr& d, int army_id)
		{
			if (d->Info().Nation() != _city->nation())
			{
				for (unsigned i = 0; i < QueueNum; ++i)
				{
					if (_battle_queues[i].atk_side)
					{
						nCity::PlayerPtr ptr = upCast<nCity::IPlayer>(_battle_queues[i].atk_side);
						if (ptr && ptr->pid() == d->ID() && ptr->armyId() == army_id)
							return true;
					}
				}
				for (unsigned i = 0; i < _ready_attackers.size(); ++i)
				{
					nCity::PlayerPtr ptr = upCast<nCity::IPlayer>(_ready_attackers[i]);
					if (ptr && ptr->pid() == d->ID() && ptr->armyId() == army_id)
						return true;
				}
			}
			else
			{
				for (unsigned i = 0; i < QueueNum; ++i)
				{
					if (_battle_queues[i].def_side)
					{
						nCity::PlayerPtr ptr = upCast<nCity::IPlayer>(_battle_queues[i].def_side);
						if (ptr && ptr->pid() == d->ID() && ptr->armyId() == army_id)
							return true;
					}
				}
				for (unsigned i = 0; i < _ready_defenders.size(); ++i)
				{
					nCity::PlayerPtr ptr = upCast<nCity::IPlayer>(_ready_defenders[i]);
					if (ptr && ptr->pid() == d->ID() && ptr->armyId() == army_id)
						return true;
				}
			}
			return false;
		}

		void BattleField::getItemList(qValue& q, int side)
		{
			int num = 0;
			qValue l;
			for (unsigned i = 0; i < QueueNum; ++i)
			{
				if (side == Left)
				{
					if (_battle_queues[i].atk_side)
					{
						qValue tmp;
						_battle_queues[i].atk_side->getStateInfo(tmp, 1);
						l.append(tmp);
						++num;
					}
				}
				else
				{
					if (_battle_queues[i].def_side)
					{
						qValue tmp;
						_battle_queues[i].def_side->getStateInfo(tmp, 1);
						l.append(tmp);
						++num;
					}
				}
			}
			if (side == Left)
			{
				for (unsigned i = 0; i < _ready_attackers.size(); ++i)
				{
					qValue tmp;
					_ready_attackers[i]->getStateInfo(tmp, 1);
					l.append(tmp);
				}
				num += _ready_attackers.size();
			}
			else
			{
				for (unsigned i = 0; i < _ready_defenders.size(); ++i)
				{
					qValue tmp;
					_ready_defenders[i]->getStateInfo(tmp, 1);
					l.append(tmp);
				}
				num += _ready_defenders.size();
			}
			nCity::ItemList& list = side == Left? 
				_city->_attacker_backup : _city->_defender_backup;
			ForEachC(nCity::ItemList, it, list)
			{
				qValue tmp;
				(*it)->getStateInfo(tmp, 0);
				l.append(tmp);
			}
			num += list.size();
			if (side != 0)
			{
				ForEachC(nCity::ItemList, it, _city->_npc_list)
				{
					qValue tmp;
					(*it)->getStateInfo(tmp, 0);
					l.append(tmp);
				}
				num += _city->_npc_list.size();
			}
			q.addMember("n", num);
			q.addMember("l", l);
			q.addMember("s", side);
		}

		void BattleField::resetTickTime(unsigned cur_time)
		{
			if (_state == StartWait)
			{
				if (State::shared().isPrimeTime())
					_next_tick_time = cur_time + (_next_tick_time - cur_time) / StartWaitPrimeRate;
				else
					_next_tick_time = cur_time + (_next_tick_time - cur_time) * StartWaitPrimeRate;
				setOpenTimer();
				_sign_save();
			}
			if (_state == Protected)
			{
				if (State::shared().isPrimeTime())
					_next_tick_time = cur_time + (_next_tick_time - cur_time) / ProtectedPrimeRate;
				else
					_next_tick_time = cur_time + (_next_tick_time - cur_time) * ProtectedPrimeRate;
				setCloseTimer();
				_sign_save();
			}
		}

		void BattleField::clear(unsigned cur_time)
		{
			if (_state == Closed
				|| _state == Protected)
				return;
			changeState(Closed, cur_time);
			++_tick_timer;
			_next_tick_time = 0;
			_first_battle_nation = -1;
			_atk_pos_offset = 0;
			_def_pos_offset = 0;
			for (unsigned i = 0; i <= Kingdom::nation_num; ++i)
				_wins[i] = -1;
			ForEach(std::deque<nCity::ItemPtr>, it, _ready_attackers)
				(*it)->beDead(cur_time, QARRAY((int)TIPS::UNITY));
			ForEach(std::deque<nCity::ItemPtr>, it, _ready_defenders)
				(*it)->beDead(cur_time, QARRAY((int)TIPS::UNITY));
			_ready_attackers.clear();
			_ready_defenders.clear();
			for (unsigned i = 0; i < QueueNum; ++i)
			{
				_battle_queues[i].battle_timer = 0;
				if (_battle_queues[i].atk_side)
				{
					_battle_queues[i].atk_side->beDead(cur_time, QARRAY((int)TIPS::UNITY));
					_battle_queues[i].atk_side.reset();
				}
				if (_battle_queues[i].def_side)
				{
					_battle_queues[i].def_side->beDead(cur_time, QARRAY((int)TIPS::UNITY));
					_battle_queues[i].def_side.reset();
				}
			}
			_sign_save();
		}

		City::City(const Json::Value& info)
		{
			_id = info["id"].asInt();
			if (_id == MainCity[0] || _id == MainCity[1] || _id == MainCity[2])
				_is_main = true;
			else
				_is_main = false;

			_output.assign(Kingdom::nation_num + 1, 0);
			if (info["gold"].asInt() > 0)
			{
				_output_type = 0;
				_output[Kingdom::nation_num] = info["gold"].asInt();
			}
			if (info["silver"].asInt() > 0)
			{
				_output_type = 1;
				_output[Kingdom::nation_num] = info["silver"].asInt();
			}
			if (info["fame"].asInt() > 0)
			{
				_output_type = 2;
				_output[Kingdom::nation_num] = info["fame"].asInt();
			}
			if (info["merit"].asInt() > 0)
			{
				_output_type = 3;
				_output[Kingdom::nation_num] = info["merit"].asInt();
			}

			_output_max = info["max"].asInt() * _output[Kingdom::nation_num];

			const Json::Value& npc_start = info["npc_start"];
			ForEachC(Json::Value, it, npc_start)
				_npc_start.push_back((*it).asInt());
			const Json::Value& npc_add = info["npc_add"];
			ForEachC(Json::Value, it, npc_add)
				_npc_add.push_back((*it).asInt());
			const Json::Value& npc_max= info["npc_max"];
			ForEachC(Json::Value, it, npc_max)
				_npc_max.push_back((*it).asInt());

			_buff_type = info["buff_type"].asInt();
			const Json::Value& buff_value = info["buff_value"];
			ForEachC(Json::Value, it, buff_value)
				_buff_value.push_back((*it).asInt());

			_counter = Creator<nCity::ItemCounter>::Create();
			_sup_time = Common::gameTime();
			_sup_base = 0;
			_sup_rate = kingdomwar_sys.supRate();
			_belong_nation = info["belong"].asInt();

			_npc2_interval = info["npc2_interval"].asUInt();
			_npc2_num = info["npc2_num"].asUInt();
			_next_npc2_time = 0;
			_broadcast_1 = info["broadcast_1"].asInt();
			_broadcast_2 = info["broadcast_2"].asInt();
			_max_box_num = info["box_num"].asInt();
			_cur_box_num = 0;
		}

		int City::state()
		{
			if (_battle_field->state() == Closed)
				return 0;
			if (_battle_field->state() == Protected)
				return 2;
			return 1;
		}

		void City::tryLoadPlayer(playerDataPtr& d, int army_id)
		{
			if (_is_main)
				return;
			nCity::PlayerPtr ptr = Creator<nCity::IPlayer>::Create(d, army_id, upCast<City>(shared_from_this()));
			if (_nation != d->Info().Nation())
				_attacker_backup.push_back(ptr);
			else
				_defender_backup.push_back(ptr);
			_counter->push(ptr);
		}

		TRYLOAD(Npc)
		TRYLOAD(Shadow)
		TRYLOAD(ShadowNpc)

		void City::init()
		{
			kingdomwar_sys.add5MinTicker(boostBind(City::tickOutput, upCast<City>(shared_from_this()), _1));
			kingdomwar_sys.add5MinTicker(boostBind(City::tickCreateNpc, upCast<City>(shared_from_this()), _1));
			if (_belong_nation != -1)
			{
				if (_next_npc2_time == 0)
					_next_npc2_time = (Common::gameTime() / _npc2_interval + 1) * _npc2_interval;
				kingdomwar_sys.addTimer(_next_npc2_time, boostBind(City::tickCreateActiveNpc, upCast<City>(shared_from_this()), _next_npc2_time));
			}

			_battle_field = Creator<BattleField>::Create(
				upCast<City>(shared_from_this()));
			_battle_field->init();
		}

		void City::loadDB()
		{
			mongo::BSONObj key = BSON("ci" << _id);
			mongo::BSONObj obj = db_mgr.FindOne(DBN::dbKingdomWarCityBase, key);
			if (obj.isEmpty())
			{
				initNation();
				initMaxNpc(Common::gameTime());
				_sign_save();
				return;
			}

			initNation(obj["nt"].Int());
			{
				std::vector<mongo::BSONElement> ele = obj["o"].Array();
				for (unsigned i = 0; i < Kingdom::nation_num; ++i)
					_output[i] = ele[i].Int();
			}

			checkNotEoo(obj["sb"])
				_sup_base = obj["sb"].Int();
			checkNotEoo(obj["st"])
				_sup_time = obj["st"].Int();
			checkNotEoo(obj["ntt"])
				_next_npc2_time = obj["ntt"].Int();
			checkNotEoo(obj["cbn"])
				_cur_box_num = obj["cbn"].Int();
			checkNotEoo(obj["gbp"])
			{
				std::vector<mongo::BSONElement> ele = obj["gbp"].Array();
				for (unsigned i = 0; i < ele.size(); ++i)
					_get_box_players.insert(ele[i].Int());
			}
		}

		bool City::_auto_save()
		{
			mongo::BSONObj key = BSON("ci" << _id);
			mongo::BSONObjBuilder obj;
			obj << "ci" << _id << "nt" << _nation
				<< "sb" << _sup_base << "st" << _sup_time
				<< "ntt" << _next_npc2_time << "cbn" << _cur_box_num;
			{
				mongo::BSONArrayBuilder b;
				for (unsigned i = 0; i < Kingdom::nation_num; ++i)
					b.append(_output[i]);
				obj << "o" << b.arr();
			}
			if (!_get_box_players.empty())
			{
				mongo::BSONArrayBuilder b;
				ForEachC(std::set<int>, it, _get_box_players)
					b.append(*it);
				obj << "gbp" << b.arr();
			}
			return db_mgr.SaveMongo(DBN::dbKingdomWarCityBase, key, obj.obj());
		}

		void City::attach(int id)
		{
			if (Observer::empty())
				_battle_field->resetData();
			Observer::attach(id);
		}

		inline bool City::inProtected(int nation) const
		{
			return _battle_field->state() == Protected
				&& _nation != nation;
		}

		int City::enter(unsigned time, playerDataPtr d, int army_id, qValue& tips)
		{
			if (_is_main)
			{
				d->KingDomWarPos().setPosition(army_id, PosCity, _id, time, tips);
				return res_sucess;
			}
			if (inProtected(d->Info().Nation()))
			{
				kingdomwar_sys.goBackMainCity(time, d, army_id, QARRAY((int)TIPS::CITYPROTECTED << _id));
				return res_sucess;
			}
			nCity::PlayerPtr ptr = Creator<nCity::IPlayer>::Create(d, army_id, upCast<City>(shared_from_this()));
			d->KingDomWarPos().setPosition(army_id, PosCity, _id, time, tips);
			enter(time, ptr);
			d->KingDomWarPos().tryMove(army_id);
			return res_sucess;
		}

		int City::enter(unsigned time, nCity::ItemPtr ptr)
		{
			_counter->push(ptr);
			if (_nation == ptr->nation())
			{
				_defender_backup.push_back(ptr);
				noticeAddDefender(time);
			}
			else
			{
				_attacker_backup.push_back(ptr);
				noticeAddAttacker(time);
			}
			return res_sucess;
		}

		ENTER(Npc)
		ENTER(Shadow)
		ENTER(ShadowNpc)

		ShadowNpcDataPtr City::createShadowNpc(unsigned cur_time, playerDataPtr d)
		{
			int map_id = kingdomwar_sys.randomNpcID(Npc);
			Position pos;
			pos.type = PosCity;
			pos.time = cur_time;
			pos.id = _id;
			pos.from_id = _id;
			std::vector<int> man_hp;
			return Creator<ShadowNpcData>::Create(d, map_id, pos, (int)ArmyMaxHp, man_hp);
		}

		ShadowDataPtr City::createShadow(unsigned cur_time, playerDataPtr d, int army_id, int type)
		{
			Position pos;
			pos.type = PosCity;
			pos.time = cur_time;
			pos.id = _id;
			pos.from_id = _id;
			return Creator<ShadowData>::Create(d, army_id, pos, (int)ArmyMaxHp);
		}

		int City::callElecTower(unsigned cur_time, playerDataPtr d)
		{
			return _battle_field->callElecTower(cur_time, d);
		}

		int City::callShadow(unsigned cur_time, playerDataPtr d, int type, int army_id)
		{
			if (type == 0)
			{
				ShadowNpcDataPtr ptr = createShadowNpc(cur_time, d);
				ptr->_sign_save();
				return enter(cur_time, ptr);
			}
			else
			{
				ShadowDataPtr ptr = createShadow(cur_time, d, army_id, type);
				ptr->_sign_save();
				return enter(cur_time, ptr);
			}
		}

		bool City::onFight(playerDataPtr d, int army_id)
		{
			if (_is_main)
				return false;
			return _battle_field->onFight(d, army_id);
		}

		bool City::onFight(NpcDataPtr d)
		{
			if (_is_main)
				return false;
			return _battle_field->onFight(d);
		}

		PathPtr City::getPath(int to_id) const
		{
			ForEachC(std::vector<PathPtr>, it, _paths)
			{
				if ((*it)->access(_id, to_id))
					return *it;
			}
			return PathPtr();
		}

		bool City::eraseItem(playerDataPtr d, int army_id)
		{
			nCity::ItemList& item_list =
				(d->Info().Nation() != _nation)? _attacker_backup : _defender_backup;
			ForEach(nCity::ItemList, it, item_list)
			{
				nCity::PlayerPtr ptr = upCast<nCity::IPlayer>(*it);
				if (!ptr) continue;
				if (ptr->pid() == d->ID() && ptr->armyId() == army_id)
				{
					_counter->pop(ptr);
					item_list.erase(it);
					return true;
				}
			}
			return false;
		}

		int City::leave(unsigned time, playerDataPtr d, int army_id, int to_city_id)
		{
			PathPtr ptr = getPath(to_city_id);
			if (!ptr)
				return err_illedge;
			if (!_is_main && !eraseItem(d, army_id))
				return err_illedge;
			return ptr->enter(time, d, army_id, to_city_id);
		}

		//void City::handleBattleStart(unsigned tick_time)
		//{	
		//	_
		//}

		void City::noticeAddAttacker(unsigned tick_time)
		{
			_battle_field->handleAddAttacker(tick_time);
		}

		void City::noticeAddDefender(unsigned tick_time)
		{
			_battle_field->handleAddDefender(tick_time);
		}

		nCity::ItemPtr City::getAttacker()
		{
			if (_attacker_backup.empty())
				return nCity::ItemPtr();
			nCity::ItemPtr ptr = _attacker_backup.front();
			_attacker_backup.pop_front();
			return ptr;
		}

		nCity::ItemPtr City::getAttacker(int pid, int army_id)
		{
			ForEach(nCity::ItemList, it, _attacker_backup)
			{
				nCity::PlayerPtr ptr = upCast<nCity::IPlayer>(*it);
				if (ptr && ptr->pid() == pid && ptr->armyId() == army_id)
				{
					_attacker_backup.erase(it);
					return ptr;
				}
			}
			return nCity::ItemPtr();
		}

		nCity::ItemPtr City::getAttacker(int npc_id)
		{
			ForEach(nCity::ItemList, it, _attacker_backup)
			{
				nCity::NpcPtr ptr = upCast<nCity::INpc>(*it);
				if (ptr && ptr->id() == npc_id)
				{
					_attacker_backup.erase(it);
					return ptr;
				}
			}
			return nCity::ItemPtr();
		}

		nCity::ItemPtr City::getDefender()
		{
			if (_defender_backup.empty()
				&& _npc_list.empty())
				return nCity::ItemPtr();
			if (!_defender_backup.empty())
			{
				nCity::ItemPtr ptr = _defender_backup.front();
				_defender_backup.pop_front();
				return ptr;
			}
			nCity::ItemPtr ptr = _npc_list.front();
			_npc_list.pop_front();
			return ptr;
		}

		nCity::ItemPtr City::getDefender(int pid, int army_id)
		{
			ForEach(nCity::ItemList, it, _defender_backup)
			{
				nCity::PlayerPtr ptr = upCast<nCity::IPlayer>(*it);
				if (ptr && ptr->pid() == pid && ptr->armyId() == army_id)
				{
					_defender_backup.erase(it);
					return ptr;
				}
			}
			return nCity::ItemPtr();
		}

		nCity::ItemPtr City::getDefender(int npc_id)
		{
			ForEach(nCity::ItemList, it, _defender_backup)
			{
				nCity::NpcPtr ptr = upCast<nCity::INpc>(*it);
				if (ptr && ptr->id() == npc_id)
				{
					_defender_backup.erase(it);
					return ptr;
				}
			}
			ForEach(nCity::ItemList, it, _npc_list)
			{
				nCity::NpcPtr ptr = upCast<nCity::INpc>(*it);
				if (ptr->id() == npc_id)
				{
					_npc_list.erase(it);
					return ptr;
				}
			}
			return nCity::ItemPtr();
		}
		void City::initNation(int nation)
		{
			if (nation == -1)
			{
				if (_id == MainCity[Kingdom::wei])
					_nation = Kingdom::wei;
				else if (_id == MainCity[Kingdom::shu])
					_nation = Kingdom::shu;
				else if (_id == MainCity[Kingdom::wu])
					_nation = Kingdom::wu;
				else
					_nation = Kingdom::nation_num;
			}
			else
			{
				_nation = nation;
			}
			CityCounter::shared().alter(_nation);
		}

		void City::alterNation(int nation)
		{
			int tmp = _nation;
			_nation = nation;
			CityCounter::shared().alter(_nation, tmp);
			
			if (_nation != Kingdom::nation_num)
			{
				qValue b;
				b << 0 << _nation << _id << tmp;
				for (unsigned i = 0; i < Kingdom::nation_num; ++i)
					b << CityCounter::shared().num(i);
				kingdomwar_sys.DoBroadcast(-2, b);

				if (_broadcast_1 == 1)
				{
					qValue bc;
					bc << 9 << _nation << tmp;
					kingdomwar_sys.DoBroadcast(-1, bc);
				}	
				if (_broadcast_2 == 1
					&& _belong_nation != -1
					&& _belong_nation != _nation)
				{
					qValue bc;
					bc << 10 << _nation << _id;
					kingdomwar_sys.DoBroadcast(_belong_nation, bc);
				}
				_cur_box_num = _max_box_num;
			}

			kingdomwar_sys.updateNationTask(_nation, Task::OccupySpecified, JARRAY(_id << 1));
			kingdomwar_sys.updateNationTask(tmp, Task::OccupySpecified, JARRAY(_id << 0));
			kingdomwar_sys.updateNationTask(_nation, Task::OccupyNum1, Json::Value(1));
			kingdomwar_sys.updateNationTask(_nation, Task::OccupyNum2, Json::Value(1));
			kingdomwar_sys.updateNationTask(tmp, Task::OccupyNum1, Json::Value(0));
			kingdomwar_sys.updateNationTask(tmp, Task::OccupyNum2, Json::Value(0));
		}

		void City::handleBattleResult(unsigned tick_time, bool result, int nation)
		{
			if (result)
			{
				alterNation(nation);
				ForEach(nCity::ItemList, it, _attacker_backup)
				{
					nCity::ItemPtr& ptr = *it;
					if (ptr->nation() == _nation)
					{
						_defender_backup.push_back(ptr);
						ptr->enter(tick_time);
					}
					else
					{
						_counter->pop(ptr);
						ptr->beDead(tick_time, QARRAY((int)TIPS::SIEGEFAILED));
					}
				}
				_attacker_backup.clear();
				initNpc(tick_time);
				_sign_save();
			}
		}

		void City::tickOutput(unsigned cur_time)
		{
			if (_nation == Kingdom::nation_num)
				return;
			if (State::shared().get() == Closed &&
				(cur_time % (15 * MINUTE) != 0))
				return;
			_output[_nation] += _output[Kingdom::nation_num];
			_sign_save();
		}

		void City::initNpc(unsigned cur_time)
		{
			for (unsigned i = 0; i < _npc_start[_nation]; ++i)
			{
				int map_id = kingdomwar_sys.randomNpcID(Npc);
				nCity::NpcPtr ptr = createNpc(cur_time, Npc, map_id);
				if (!ptr)
				{
					LogE << "create npc error: map id " << map_id << LogEnd;
					continue;
				}
				_npc_list.push_back(ptr);
				_counter->push(ptr);
			}
		}

		void City::initMaxNpc(unsigned cur_time)
		{
			if (_is_main)
				return;
			for (unsigned i = 0; i < _npc_max[_nation]; ++i)
			{
				int map_id = kingdomwar_sys.randomNpcID(Npc);
				nCity::NpcPtr ptr = createNpc(cur_time, Npc, map_id);
				if (!ptr)
				{
					LogE << "create npc error: map id " << map_id << LogEnd;
					continue;
				}
				_npc_list.push_back(ptr);
				_counter->push(ptr);
			}
		}

		nCity::NpcPtr City::createNpc(unsigned cur_time, int type, int map_id)
		{
			Position pos;
			pos.type = PosCity;
			pos.time = cur_time;
			pos.id = _id;
			pos.from_id = _id;
			std::vector<int> man_hp;
			NpcDataPtr ptr = Creator<NpcData>::Create(type, map_id, _nation, pos, (int)ArmyMaxHp, man_hp);
			if (!ptr->checkValidAndSave())
				return nCity::NpcPtr();
			return Creator<nCity::INpc>::Create(ptr, upCast<City>(shared_from_this()));
		}

		void City::tickCreateNpc(unsigned cur_time)
		{
			if (_is_main)
				return;
			if (_battle_field->state() != Closed
				|| KingdomWar::State::shared().unityFlag())
				return;
			if (_npc_list.size() >= _npc_max[_nation])
				return;
			int add_num = _npc_add[_nation];
			if (_npc_list.size() + add_num > _npc_max[_nation])
				add_num = _npc_max[_nation] - _npc_list.size();
			for (unsigned i = 0; i < add_num; ++i)
			{
				int map_id = kingdomwar_sys.randomNpcID(Npc);
				nCity::NpcPtr npc_ptr = createNpc(cur_time, Npc, map_id);
				if (!npc_ptr)
				{
					LogE << "create npc error: map id " << map_id << LogEnd;
					continue;
				}
				_npc_list.push_back(npc_ptr);
				_counter->push(npc_ptr);
			}
		}

		void City::doTickCreateActiveNpc(unsigned cur_time, PathPtr& ptr, int to_id)
		{
			if (KingdomWar::State::shared().get() == Closed)
				return;
			int map_id = kingdomwar_sys.randomNpcID(ActiveNpc);
			nCity::NpcPtr npc = createNpc(cur_time, ActiveNpc, map_id);
			if (!npc)
				return;
			ptr->enter(cur_time, npc->npcData(), to_id);
		}

		void City::tickCreateActiveNpc(unsigned cur_time)
		{
			_next_npc2_time += _npc2_interval;
			kingdomwar_sys.addTimer(_next_npc2_time, boostBind(City::tickCreateActiveNpc, upCast<City>(shared_from_this()), _next_npc2_time));
			_sign_save();

			if (State::shared().get() == Closed)
				return;
			if (_belong_nation == -1)
				return;
			if (_belong_nation != _nation)
				return;
			ForEach(std::vector<PathPtr>, it, _paths)
			{
				PathPtr ptr = *it;
				CityPtr city_ptr = ptr->getLinkedCity(_id);
				if (city_ptr->belongNation() == _nation
					&& city_ptr->nation() != _nation
					&& ptr->access(_id, city_ptr->id()))
				{
					unsigned out_time = cur_time;
					for (unsigned i = 0; i < _npc2_num; ++i)
					{
						out_time += (i * NpcOutTime);
						kingdomwar_sys.addTimer(out_time, boostBind(City::doTickCreateActiveNpc, upCast<City>(shared_from_this()), out_time, ptr, city_ptr->id()));
					}
				}
			}
		}

		void City::getMilitaryInfo(qValue& q)
		{
			q.addMember("n", _nation);
			const std::vector<int>& num = _counter->num();
			qValue n;
			for (unsigned i = 0; i < num.size(); ++i)
				n.append(num[i]);
			q.addMember("a", n);
		}

		void City::getFighterList(qValue& q, int side)
		{
			return _battle_field->getItemList(q, side);
		}

		void City::addBuff(sBattlePtr ptr, int nation)
		{
			if (nation == Kingdom::nation_num)
				return;
			int buff = _buff_value[nation];
			if (_buff_type == 1)
			{
				ForEach(manList, it, ptr->battleMan)
				{
					(*it)->battleAttri[idx_phyHurtRate] += buff;
					(*it)->battleAttri[idx_warHurtRate] += buff;
					(*it)->battleAttri[idx_magicHurtRate] += buff;
					(*it)->battleAttri[idx_cureRate] += buff;
				}
			}
			else if (_buff_type == 2)
			{
				ForEach(manList, it, ptr->battleMan)
				{
					(*it)->battleAttri[idx_phyCutRate] += buff;
					(*it)->battleAttri[idx_warCutRate] += buff;
					(*it)->battleAttri[idx_magicCutRate] += buff;
				}
			}
		}

		void City::addBuff(playerDataPtr& d, sBattlePtr ptr)
		{
			addBuff(ptr, d->Info().Nation());
		}

		unsigned City::getSup(unsigned cur_time)
		{
			if (cur_time < _sup_time)
				return 0;
			return (cur_time - _sup_time) * _sup_rate / 6 + _sup_base;
		}

		void City::reset(unsigned cur_time)
		{
			if (_sup_rate != kingdomwar_sys.supRate())
			{
				if (cur_time > _sup_time)
				{
					_sup_base = getSup(cur_time);
					_sup_time = cur_time;
					_sign_save();
				}
				_sup_rate = kingdomwar_sys.supRate();
				_battle_field->resetTickTime(cur_time);
			}
		}

		void City::clear(unsigned cur_time)
		{
			if (_id == MainCity[0u]
				|| _id == MainCity[1u]
				|| _id == MainCity[2u])
				return;
			ForEach(nCity::ItemList, it, _npc_list)
			{
				(*it)->beDead(cur_time, QARRAY((int)TIPS::UNITY));
				_counter->pop(*it);
			}
			_npc_list.clear();
			ForEach(nCity::ItemList, it, _attacker_backup)
			{
				(*it)->beDead(cur_time, QARRAY((int)TIPS::UNITY));
				_counter->pop(*it);
			}
			_attacker_backup.clear();
			ForEach(nCity::ItemList, it, _defender_backup)
			{
				(*it)->beDead(cur_time, QARRAY((int)TIPS::UNITY));
				_counter->pop(*it);
			}
			_defender_backup.clear();
			_battle_field->clear(cur_time);
		}

		void City::resetUnity(unsigned cur_time)
		{
			if (_id == MainCity[0u]
				|| _id == MainCity[1u]
				|| _id == MainCity[2u])
				return;
			
			alterNation(Kingdom::nation_num);
			initMaxNpc(cur_time);
			_sign_save();
		}

		int City::useTowerItem(unsigned cur_time, int id)
		{
			return res_sucess;
		}

		void City::getMainInfo(qValue& q)
		{
			if (_battle_field->state() != Closed)
				_battle_field->getInfo(q);
			else
			{
				qValue a;
				const std::vector<int>& num = _counter->num();
				for (unsigned i = 0; i < num.size(); ++i)
					a.append(num[i]);
				q.addMember("a", a);
				q.addMember("s", (int)Closed);
				qValue rd;
				int count = 0;
				ForEachC(nCity::ItemList, it, _defender_backup)
				{
					if (count >= ReadyMemNum)
						break;
					qValue tmp;
					(*it)->getInfo(tmp);
					rd.append(tmp);
					++count;
				}
				if (count < ReadyMemNum)
				{
					ForEachC(nCity::ItemList, it, _npc_list)
					{
						if (count >= ReadyMemNum)
							break;
						qValue tmp;
						(*it)->getInfo(tmp);
						rd.append(tmp);
						++count;
					}
				}
				q.addMember("rd", rd);
			}
		}

		CityList::CityList()
		{
		}

		CityPtr CityList::getCity(int id)
		{
			if (id < 0 || id >= _citys.size())
				return CityPtr();
			return _citys[id];
		}

		void CityList::push(const CityPtr& ptr)
		{
			while(ptr->id() >= _citys.size())
				_citys.push_back(CityPtr());
			_citys[ptr->id()] = ptr;
		}

		void CityList::clear(unsigned cur_time)
		{
			ForEach(Citys, it, _citys)
				(*it)->clear(cur_time);
		}

		void CityList::reset(unsigned cur_time)
		{
			ForEach(Citys, it, _citys)
				(*it)->resetUnity(cur_time);
		}
		
		void CityList::update(bool is_first)
		{
			if (is_first)
			{
				LogI << "city size: " << _citys.size() << LogEnd;
				_main_state_info.toArray();
				_main_nation_info.toArray();
				for (unsigned i = 0; i < _citys.size(); ++i)
				{
					_states.push_back(_citys[i]->state());
					_nations.push_back(_citys[i]->nation());
					_main_state_info.append(_states[i]);
					_main_nation_info.append(_nations[i]);
				}
			}
			else
			{
				_update_state_info.toArray();
				_update_nation_info.toArray();
				for (unsigned i = 0; i < _citys.size(); ++i)
				{
					if (_states[i] != _citys[i]->state())
					{
						_states[i] = _citys[i]->state();
						qValue tmp;
						tmp.toArray();
						tmp.append(_citys[i]->id());
						tmp.append(_states[i]);
						_update_state_info.append(tmp);
					}
					if (_nations[i] != _citys[i]->nation())
					{
						_nations[i] = _citys[i]->nation();
						qValue tmp;
						tmp.toArray();
						tmp.append(_citys[i]->id());
						tmp.append(_nations[i]);
						_update_nation_info.append(tmp);
					}
				}
				if (!_update_state_info.isEmpty())
				{
					_main_state_info.toArray();
					for (unsigned i = 0; i < _citys.size(); ++i)
						_main_state_info.append(_states[i]);
				}
				if (!_update_nation_info.isEmpty())
				{
					_main_nation_info.toArray();
					for (unsigned i = 0; i < _citys.size(); ++i)
						_main_nation_info.append(_nations[i]);
				}
			}
		}
		
		void CityList::loadDB()
		{
			ForEach(Citys, it, _citys)
				(*it)->loadDB();
		}

		void CityList::init()
		{
			ForEach(Citys, it, _citys)
				(*it)->init();
		}

		CityCounter::CityCounter()
		{
			_num.assign(Kingdom::nation_num + 1, 0);
		}

		void CityCounter::alter(int nation, int old_nation)
		{
			if (old_nation != -1)
				--_num[old_nation];
			++_num[nation];
		}	

		int CityCounter::unityNation() const
		{
			for (unsigned i = 0; i < Kingdom::nation_num; ++i)
			{
				if (_num[i] == kingdomwar_sys.citySize() - 2)
					return i;
			}
			return -1;
		}

		int CityCounter::strength(int nation) const
		{
			int s = 2;
			for (unsigned i = 0; i < Kingdom::nation_num; ++i)
			{
				if (i == nation)
					continue;
				if (_num[i] < _num[nation])
					--s;
			}
			return s;
		}

		unsigned CityCounter::allNum() const
		{
			return kingdomwar_sys.citySize();
		}
	}
}


#include "player_patrol.h"
#include "dbDriver.h"
#include <iterator>
#include "task_mgr.h"

#define DICE_DAY 37

namespace gg
{
	const std::string strPos = "pos"; //��ǰѲ��λ��
	const std::string strState = "state"; //��ǰ״̬
	const std::string strType = "type";//��ǰ�¼�����
	//const std::string strSEventIdx = "sid"; //�����¼�idx
	const std::string strEBoxIdx = "eid"; //�յ㱦���±�
	const std::string strFirst = "first";//����
	const std::string strSecond = "second";//����
	const std::string strIds = "ids";//����
	//const std::string strREventType = "rtype"; //����¼�����
	//const std::string strCardId = "card"; //��Ůid
	//const std::string strLevel = "lv"; //��Ů�ȼ�
	//const std::string strOffId = "oid";//���ӻָ���ʶ
	const std::string strDiceNum = "dnum";//��һ�����ӵ���
	const std::string strTotal = "total";//�����ӵ��ܴ���
	const std::string strVersion = "version";

	//static int CardId = -1;
	//static int Level = -1;

	//tick_dice[0]==>[10���֮ǰ���ߣ�10������11��֮ǰ����]
	static int tick_dice[][2] = {{28,27},{26,25},{24,23},{22,21},{20,19},{18,17},{16,15},{14,13},{12,11},{10,9},{8,7},{6,5},{4,3},{2,1} };
	//rtick_dice[0]==>[10���֮ǰ���ߣ�10������11��֮ǰ����]
	static int rtick_dice[][2] = { {0,1},{2,3},{4,5},{6,7},{8,9},{10,11},{12,13},{14,15},{16,17},{18,19},{20,21},{22,23},{24,25},{26,27}};
	//static int off_id[][2] = { {0,1},{2,3},{ 4,5 },{ 6,7 },{ 8,9 },{ 10,11 },{ 12,13 },{ 14,15 },{ 16,17 },{ 18,19 },{ 20,21 },{ 22,23 },{ 24,25 },{ 26,27 },{ 28,-1 } };

	static bool isGtHour(int hour, const tm& ctime)
	{
		if (ctime.tm_hour > hour)
		{
			return true;
		}
		if (ctime.tm_hour == hour && (ctime.tm_min > 0 || ctime.tm_sec > 0))
		{
			return true;
		}
		return false;
	}

	//�������Ӳ���------------------delete------------------------------
	//static int _getOffLineDice(const unsigned& off_time, const unsigned& now_time, bool isGM = false)
	//{
	//	if (off_time >= now_time)
	//	{
	//		return 0;
	//	}
	//	int dice = 0;
	//	int day = (now_time - off_time) / DAY;
	//	if (day - 1 > 0)
	//	{
	//		dice += (day - 1)*DICE_DAY;
	//		//����������Ŀ��������30����������Ĳ��������Ѿ�����30�����Դ����ﷵ�أ���������ļ��㣬Ҳ����ȷ�ġ�
	//		return dice;
	//	}
	//	//��ȥ��������������ʣ�µ�������ʱ�䵽���ߵ���24:00�Ĳ��������ߵ���10:00������ʱ��Ĳ��������м��ʱ����ܻ��ص�����
	//	tm off_tm = Common::toTm(off_time);
	//	tm now_tm = Common::toTm(now_time);
	//	if (off_tm.tm_hour < 10)
	//	{
	//		off_tm.tm_hour = 10;
	//		off_tm.tm_min = 0;
	//		off_tm.tm_sec = 0;
	//	}
	//	if (now_tm.tm_hour < 10)
	//	{
	//		now_tm.tm_hour = 10;
	//		now_tm.tm_min = 0;
	//		now_tm.tm_sec = 0;
	//	}
	//	int i, j, k, l;
	//	i = off_tm.tm_hour - 10;
	//	j = off_tm.tm_min > 29 ? 1 : 0;
	//	k = now_tm.tm_hour - 10;
	//	l = now_tm.tm_min > 29 ? 1 : 0;
	//	if (off_tm.tm_mday == now_tm.tm_mday)
	//	{
	//		//ͬһ�죬����i<=k
	//		dice = tick_dice[i][j] - tick_dice[k][l];
	//	}
	//	else
	//	{
	//		dice = tick_dice[i][j] + rtick_dice[k][l];
	//	}
	//	if (!isGM)
	//	{
	//		//�������������ʱ��㡣
	//		if (off_tm.tm_mday == now_tm.tm_mday)
	//		{
	//			//ͬһ��
	//			if (off_tm.tm_hour < 10 && isGtHour(10, now_tm))
	//			{
	//				dice += 5;
	//			}
	//			if (off_tm.tm_hour < 21 && isGtHour(21, now_tm))
	//			{
	//				dice += 5;
	//			}
	//		}
	//		else
	//		{
	//			if (off_tm.tm_hour < 10)
	//			{
	//				dice += 10;
	//			}
	//			if (off_tm.tm_hour < 21)
	//			{
	//				dice += 5;
	//			}
	//		}
	//	}
	//	return dice;
	//}


	//playerPatrol::playerPatrol(playerData* const own)
	//	:_auto_player(own),
	//	_curr_pos(1),
	//	_state(patrol::PatrolUninit),
	//	_curr_s_event_idx(0),
	//	_end_point_box_idx(-1),
	//	_offline_dice_id(-1),
	//	_last_dice_num(0),
	//	_total_throw(0)
	//{
	//	_curr_event.type = patrol::PatrolNone;
	//	_off_time = 0;
	//}

	//void playerPatrol::incTotalThrowTime() 
	//{ 
	//	++_total_throw; 
	//	TaskMgr::update(Own().getOwnDataPtr(), Task::PatrolThrowAllTimes);
	//	_sign_auto();
	//}

	//void playerPatrol::setPos(unsigned pos, bool add)
	//{
	//	if (add)
	//	{
	//		if (pos > 0)
	//		{
	//			_curr_pos = _curr_pos + pos > END_POINT ? END_POINT : _curr_pos + pos;
	//		}
	//	}
	//	else
	//	{
	//		_curr_pos = pos;
	//	}
	//	_auto_save();
	//}

	//void playerPatrol::classLoad()
	//{
	//	mongo::BSONObj key BSON(strPlayerID << Own().ID());
	//	mongo::BSONObj obj = db_mgr.FindOne(DBN::dbPlayerPatrol, key);
	//	if (!obj.isEmpty())
	//	{
	//		int CurrPos = obj[strPos].Int();
	//		int State = obj[strState].Int();
	//		int SIdx = obj[strSEventIdx].Int();
	//		int EIdx = obj[strEEventIdx].Int();
	//		int RType = obj[strREventType].Int();
	//		int CardId = obj[strCardId].Int();
	//		int Level = obj[strLevel].Int();
	//		if (!obj[strOffId].eoo())
	//		{
	//			_offline_dice_id = obj[strOffId].Int();
	//		}
	//		if (!obj[strDiceNum].eoo())
	//		{
	//			_last_dice_num = obj[strDiceNum].Int();
	//		}
	//		if (!obj[strTotal].eoo())
	//		{
	//			_total_throw = obj[strTotal].Int();
	//		}
	//		
	//		setPos(CurrPos);
	//		setStateFromInt(State);
	//		setRandomEventFromInt(RType);
	//		//���������������۸ģ����ܻ��������ط�����ϵͳ�ı���
	//		_curr_s_event_idx = SIdx;
	//		_end_point_box_idx = EIdx;
	//		_curr_event.cardId = CardId;
	//		_curr_event.level = Level;
	//	}
	//	//���е�Ԫ����
	//	/*int d1 = _getOffLineDice(Common::gameTime(), Common::gameTime() + DAY);
	//	int d2 = _getOffLineDice(Common::gameTime(), Common::gameTime() + HOUR);
	//	int d3 = _getOffLineDice(Common::gameTime(), Common::gameTime() + 40 * MINUTE);
	//	int d4 = _getOffLineDice(Common::gameTime(), Common::gameTime() + 40 * DAY);
	//	int d5 = _getOffLineDice(Common::gameTime(), Common::gameTime());
	//	int d6 = _getOffLineDice(Common::gameTime(), Common::gameTime() + 1 * SECOND);
	//	int d7 = _getOffLineDice(Common::gameTime(), Common::gameTime() + 1 * MINUTE);
	//	int d8 = _getOffLineDice(Common::gameTime(), Common::gameTime() + 2 * DAY + 5 * MINUTE);
	//	LogS << "һ��" << ":" << d1 << LogEnd;
	//	LogS << "һСʱ" << ":" << d2 << LogEnd;
	//	LogS << "��ʮ����" << ":" << d2 << LogEnd;
	//	LogS << "��ʮ��" << ":" << d4 << LogEnd;
	//	LogS << "����" << ":" << d5 << LogEnd;
	//	LogS << "һ��" << ":" << d6 << LogEnd;
	//	LogS << "һ����" << ":" << d7 << LogEnd;
	//	LogS << "���������" << ":" << d8 << LogEnd;*/


	//}

	//bool playerPatrol::_auto_save()
	//{
	//	mongo::BSONObj key = BSON(strPlayerID << Own().ID());
	//	mongo::BSONObj obj = BSON(strPlayerID << Own().ID()
	//		<< strPos << _curr_pos
	//		<< strState << (int)_state
	//		<< strSEventIdx << _curr_s_event_idx 
	//		<< strEEventIdx << _end_point_box_idx
	//		<< strREventType << (int)_curr_event.type 
	//		<< strCardId << _curr_event.cardId 
	//		<< strLevel << _curr_event.level
	//		<< strOffId << _offline_dice_id
	//		<< strDiceNum << _last_dice_num
	//		<< strTotal << _total_throw);

	//	return db_mgr.SaveMongo(DBN::dbPlayerPatrol, key, obj);
	//}

	//void playerPatrol::setRandomEventFromInt(int type)
	//{
	//	if (type == 1)
	//	{
	//		_curr_event.type = patrol::PatrolOneStar;
	//	}
	//	else if (type == 2)
	//	{
	//		_curr_event.type = patrol::PatrolTwoStar;
	//	}
	//	else if (type == 3)
	//	{
	//		_curr_event.type = patrol::PatrolThreeStar;
	//	}
	//	else if (type == 4)
	//	{
	//		_curr_event.type = patrol::PatrolLadyCoin;
	//	}
	//	else if (type == 5)
	//	{
	//		_curr_event.type = patrol::PatrolDice;
	//	}
	//	else
	//	{
	//		_curr_event.type = patrol::PatrolNone;
	//	}
	//}

	//void playerPatrol::setStateFromInt(int state)
	//{
	//	if (state == 102)
	//	{
	//		_state = patrol::PatrolPenddingDice;
	//	}
	//	else if (state == 103)
	//	{
	//		_state = patrol::PatrolPenddingEvent;
	//	}
	//	else if (state == 104)
	//	{
	//		_state = patrol::PatrolPenddingRewardRandom;
	//	}
	//	else if (state == 105)
	//	{
	//		_state = patrol::PatrolPenddingRewardSpecial;
	//	}
	//	else if (state == 106)
	//	{
	//		_state = patrol::PatrolPenddingBox;
	//	}
	//	else
	//	{
	//		_state = patrol::PatrolUninit;
	//	}
	//}

	//void playerPatrol::restart()
	//{
	//	if (_curr_pos != END_POINT)//����������յ㣬����ȡ����ɡ�
	//	{
	//		setPos(1);
	//		setState(patrol::PatrolPenddingDice);
	//		setEndPointIdx(-1);
	//	}
	//}

	//tm playerPatrol::getNextTickTime(const tm& old_time)
	//{
	//	tm next_time = old_time;
	//	if (old_time.tm_hour < 10)
	//	{
	//		next_time.tm_hour = 10;
	//		next_time.tm_min = 30;
	//		next_time.tm_sec = 0;
	//		return next_time;
	//	}
	//	if (old_time.tm_min < 30)
	//	{
	//		next_time.tm_min = 30;
	//		next_time.tm_sec = 0;
	//	}
	//	else
	//	{
	//		if (old_time.tm_hour < 23)
	//		{
	//			next_time.tm_hour = old_time.tm_hour + 1;
	//			next_time.tm_min = 0;
	//		}
	//		else if (old_time.tm_hour == 23/*&& old_time.tm_min > 29*/)
	//		{
	//			next_time.tm_hour = 0;
	//			next_time.tm_min = 0;
	//		}
	//		else
	//		{
	//			next_time.tm_hour = 10;
	//			next_time.tm_min = 30;
	//		}
	//		next_time.tm_sec = 0;
	//	}
	//	return next_time;
	//}

	//int playerPatrol::getOffLineDice(unsigned now, unsigned off, bool isGM)
	//{
	//	if (Own().LV() < PATROL_LEVEL_LIMIT)
	//	{
	//		return 0;
	//	}
	//	//int inc = _getOffLineDice(Own().Offline().OffTime(), Common::gameTime());
	//	int dice = 0;
	//	if (off >= now)
	//	{
	//		return dice;
	//	}

	//	tm off_tm = Common::toTm(off);
	//	tm now_tm = Common::toTm(now);

	//	////�������������ʱ��㡣
	//	if (!isGM)
	//	{
	//		if (off_tm.tm_mday == now_tm.tm_mday)
	//		{
	//			//ͬһ��
	//			if (off_tm.tm_hour < 10 && isGtHour(10, now_tm))
	//			{
	//				dice += 5;
	//			}
	//			if (off_tm.tm_hour < 21 && isGtHour(21, now_tm))
	//			{
	//				dice += 5;
	//			}
	//		}
	//		else
	//		{
	//			if (off_tm.tm_hour < 10)
	//			{
	//				dice += 10;
	//			}
	//			if (off_tm.tm_hour < 21)
	//			{
	//				dice += 5;
	//			}
	//			if (now_tm.tm_hour >= 21)
	//			{
	//				dice += 10;
	//			}
	//			if (now_tm.tm_hour >= 10 && now_tm.tm_hour < 21)
	//			{
	//				dice += 5;
	//			}
	//		}
	//	}
	//	///�������������ʱ��Ĵ������������Ĵ���֮ǰ��ʱ���������֣�
	//	if (off_tm.tm_hour < 10)
	//	{
	//		off_tm.tm_hour = 10;
	//		off_tm.tm_min = 0;
	//		off_tm.tm_sec = 0;
	//	}
	//	/*if (off_tm.tm_hour == 0)
	//	{
	//		off_tm.tm_hour = 24;
	//		off_tm.tm_min = 0;
	//	}*/
	//	if (now_tm.tm_hour < 10)
	//	{
	//		now_tm.tm_hour = 10;
	//		now_tm.tm_min = 0;
	//		now_tm.tm_sec = 0;
	//	}
	//	/*if (now_tm.tm_hour == 0)
	//	{
	//		now_tm.tm_hour = 24;
	//		now_tm.tm_min = 0;
	//	}*/
	//	int i, j, k, l;
	//	i = off_tm.tm_hour - 10;
	//	j = off_tm.tm_min > 29 ? 1 : 0;
	//	k = now_tm.tm_hour - 10;
	//	l = now_tm.tm_min > 29 ? 1 : 0;

	//	int day = (now - off) / DAY;
	//	//����ʱ��һ������
	//	if (day > 0)
	//	{
	//		dice = DICE_DAY;
	//		_offline_dice_id = off_id[k][l];
	//		return dice;
	//	}
	//	
	//	////
	//	if (off_tm.tm_mday == now_tm.tm_mday)
	//	{
	//		//ͬһ�죬����i<=k
	//		dice += tick_dice[i][j] - tick_dice[k][l];
	//		_offline_dice_id = off_id[k][l];
	//	}
	//	else
	//	{
	//		//����һ�죬������ͬһ��
	//		dice += tick_dice[i][j] + rtick_dice[k][l];
	//		_offline_dice_id = off_id[k][l];
	//	}
	//	
	//	return dice;
	//}

	//void playerPatrol::addTimer(unsigned login_time,  bool isLogin)
	//{
	//	if (Own().LV() >= PATROL_LEVEL_LIMIT)
	//	{
	//		delTimer();
	//		//
	//		unsigned now_time = Common::gameTime();
	//		tm now = Common::toTm(now_time);
	//		tm next_time = getNextTickTime(now);//�����һ����ʱ��ʱ��
	//		_timerId = Timer::AddEventTickTime(boostBind(playerPatrol::restoreHalfTick, _1, Own().ID()), Inter::event_patrol_dice_restore, Common::getNextTime(next_time.tm_hour, next_time.tm_min, next_time.tm_sec));
	//		if (isLogin)
	//		{
	//			int inc = getOffLineDice(login_time, Own().Offline().OffTime());
	//			LogS << "OffLine compensation is " << inc << LogEnd;
	//			int old = Own().Res().getDice();
	//			Own().Res().alterDice(inc);
	//			Log<int, int>(DBLOG::strLogDice, Own().getOwnDataPtr(), 1, inc, old, Own().Res().getDice());
	//		}
	//	}
	//}

	//void playerPatrol::delTimer()
	//{
	//	if (_timerId)
	//	{
	//		_timerId->delTimer();
	//	}
	//	_timerId = ptrTimerIdentify();
	//}

	//unsigned playerPatrol::addTickTimer()
	//{
	//	unsigned now = Common::gameTime();
	//	if (Own().LV() >= PATROL_LEVEL_LIMIT)
	//	{
	//		delTickTimer();
	//		now = Common::gameTime();
	//		_tenTimerId = Timer::AddEventTickTime(boostBind(playerPatrol::addFiveDice, _1, Own().ID()), Inter::event_patrol_dice_five, Common::getNextTime(10));
	//		_twentyOneTimerId = Timer::AddEventTickTime(boostBind(playerPatrol::addFiveDice, _1, Own().ID()), Inter::event_patrol_dice_five, Common::getNextTime(21));
	//	}
	//	return now;
	//}

	//void playerPatrol::delTickTimer()
	//{
	//	if (_twentyOneTimerId)
	//	{
	//		_twentyOneTimerId->delTimer();
	//	}
	//	if (_tenTimerId)
	//	{
	//		_tenTimerId->delTimer();
	//	}
	//	_twentyOneTimerId = ptrTimerIdentify();
	//	_tenTimerId = ptrTimerIdentify();
	//}

	//void playerPatrol::restoreHalfTick(const structTimer& timerData, const int playerID)
	//{
	//	playerDataPtr player = player_mgr.getOnlinePlayer(playerID);
	//	if (!player || player->LV() < PATROL_LEVEL_LIMIT)
	//	{
	//		return;
	//	}
	//	LogW << "HalfTick trigger..." << "dice:" <<player->Res().getDice() << LogEnd;

	//	int oldDiceNum = player->Res().getDice();
	//	player->Res().alterDice(1);
	//	Log<int, int>(DBLOG::strLogDice, player, 3, 1, oldDiceNum, player->Res().getDice());
	//	//LogS << "half restore is " << 1 << LogEnd;
	//	//���ݶ�ʱ��ʱ�������ʱ�䣬�������е�û�б���ʱ���ָ������Ӹ���(����GM���߸���ʱ�������Ĳ���)
	//	//[����]����������ܹ������ٶ�ʱ��������
	//	//int inc = _getOffLineDice(timerData.tickTime, Common::gameTime(), true);
	//	int inc = player->Patrol().getOffLineDice(Common::gameTime(), timerData.tickTime, true);
	//	LogS << "GM compensation is " << inc << LogEnd;
	//	oldDiceNum = player->Res().getDice();
	//	player->Res().alterDice(inc);
	//	Log<int, int>(DBLOG::strLogDice, player, 2, inc, oldDiceNum, player->Res().getDice());

	//	player->Patrol().addTimer(0);
	//}

	//void playerPatrol::addFiveDice(const structTimer & timerData, const int playerID)
	//{
	//	playerDataPtr player = player_mgr.getOnlinePlayer(playerID);

	//	if (!player || player->LV() < PATROL_LEVEL_LIMIT)
	//	{
	//		return;
	//	}
	//	LogW << "FiveDice... " << 5 << LogEnd;

	//	int oldDiceNum = player->Res().getDice();
	//	player->Res().alterDice(5);
	//	Log<int, int>(DBLOG::strLogDice, player, 4, 5, oldDiceNum, player->Res().getDice());

	//	player->Patrol().addTickTimer();
	//}

	//playerPatrol::~playerPatrol()
	//{
	//}

	//////////////////////////////////////////////////////////////////////////////////

	playerPatrol1::playerPatrol1(playerData* const own)
		:_auto_player(own),
		_state(patrol::PatrolUninit),
		_type(patrol::EventEnd),
		_isOk(false),
		_curr_pos(1),
		_last_dice_num(1),
		_total_throw(0),
		_endSecond(0),
		_version(1)
	{
		//std::cout << "ctor... " << std::endl;
	}

	void playerPatrol1::rebuildEvent(AQConfigPtr config, patrol::EventType type)
	{
		_ptr = Creator<patrol_aq_event>::Create(config, _second);
	}
	void playerPatrol1::rebuildEvent(AnecdoteConfigPtr config, patrol::EventType type)
	{
		_ptr = Creator<patrol_anecdote_event>::Create(config, _second);
	}
	void playerPatrol1::rebuildEvent(FingerGuessConfigPtr config, patrol::EventType type)
	{
		_ptr = Creator<patrol_finger_event>::Create(config, _first, _second);
	}
	void playerPatrol1::rebuildEvent(EnjoyFlowerConfigPtr config, patrol::EventType type)
	{
		_ptr = Creator<patrol_flower_event>::Create(config, _first, _second);
	}
	void playerPatrol1::rebuildEvent(FishConfigPtr config, patrol::EventType type)
	{
		_ptr = Creator<patrol_fish_event>::Create(config, _first, _second);
	}
	void playerPatrol1::rebuildEvent(EyeConfigPtr config, patrol::EventType type)
	{
		_ptr = Creator<patrol_eye_event>::Create(config, _second);
	}
	void playerPatrol1::rebuildEvent(SleepConfigPtr config, patrol::EventType type)
	{
		_ptr = Creator<patrol_sleep_event>::Create(config, _rndIds);
	}
	void playerPatrol1::rebuildEvent(PokerConfigPtr config, patrol::EventType type)
	{
		_ptr = Creator<patrol_poker_event>::Create(config, _first, _second);
	}
	void playerPatrol1::rebuildEvent(EndBoxConfigPtr config, patrol::EventType type)
	{
		_ptr = Creator<patrol_end_event>::Create(config, _endSecond);
		_endPtr = upCast<patrol_end_event>(_ptr);
	}

	void playerPatrol1::setPos(unsigned pos, bool add)
	{
		if (add)
		{
			if (pos > 0)
			{
				_curr_pos = _curr_pos + pos > END_POINT ? END_POINT : _curr_pos + pos;
			}
		}
		else
		{
			_curr_pos = pos;
		}
		_sign_auto();
	}

	void playerPatrol1::incTotalThrowTime()
	{
		++_total_throw;
		TaskMgr::update(Own().getOwnDataPtr(), Task::PatrolThrowAllTimes);
		_sign_auto();
	}

	EventPtr playerPatrol1::getEvent()
	{
		if (_type != patrol::EndBoxEvent)
		{
			return _ptr;
		}
		return _endPtr;
	}

	void playerPatrol1::setEvent(EventPtr ptr)
	{
		//��������
		if (ptr->Type() == patrol::EndBoxEvent)
		{
			EndEventPtr ptr_e = upCast<patrol_end_event>(ptr);
			_endPtr = ptr_e;
			_endSecond = _endPtr->getIndex();
			_auto_save();
			return;
		}
		_ptr = ptr;
		if (_ptr->Type() == patrol::FireEyeEvent)
		{
			EyeEventPtr ptr = upCast<patrol_eye_event>(_ptr);
			_second = ptr->getIndex();
		}
		else if (_ptr->Type() == patrol::SleepEvent)
		{
			SleepEventPtr ptr = upCast<patrol_sleep_event>(_ptr);
			_rndIds = ptr->getIndexs();
		}
		else if (_ptr->Type() == patrol::AnecdoteEvent)
		{
			AnecdoteEventPtr ptr = upCast<patrol_anecdote_event>(_ptr);
			_second = ptr->getIndex();
		}
		else if (_ptr->Type() == patrol::FingerGuessEvent)
		{
			FingerEventPtr ptr = upCast<patrol_finger_event>(_ptr);
			_first = ptr->getSuccIndex();
			_second = ptr->getFailIndex();

		}
		else if (_ptr->Type() == patrol::AnswerQuestionEvent)
		{
			AQEventPtr ptr = upCast<patrol_aq_event>(_ptr);
			_second = ptr->getIndex();
		}
		else if (_ptr->Type() == patrol::EnjoyFlowerEvent)
		{
			FlowerEventPtr ptr = upCast<patrol_flower_event>(_ptr);
			_first = ptr->subType();
			_second = ptr->getIndex();
		}
		else if (_ptr->Type() == patrol::PokerEvent)
		{
			PokerEventPtr ptr = upCast<patrol_poker_event>(_ptr);
			_first = ptr->subType();
			_second = ptr->getIndex();
		}
		else
		{
			FishEventPtr ptr = upCast<patrol_fish_event>(_ptr);
			_first = ptr->subType();
			_second = ptr->getIndex();
		}
		//�������ǿ�ƴ浵�����򣨵����������������ݽ����ܴ��ڲ���ȫ״̬
		_auto_save();
	}

	/*template<typename T>
	void playerPatrol1::rebuildEvent(T config, patrol::EventType type)
	{
		if (type == patrol::EventEnd)
		{
			return;
		}
		if (type == patrol::AnswerQuestionEvent)
		{
			_ptr = Creator<patrol_aq_event>::Create(config, _second);
		}
		else if (type == patrol::SleepEvent)
		{
			_ptr = Creator<patrol_sleep_event>::Create(config, _rndIds);
		}
		else if (type == patrol::FireEyeEvent)
		{
			_ptr = Creator<patrol_eye_event>::Create(config, _second);
		}
		else if (type == patrol::FishEvent)
		{
			_ptr = Creator<patrol_fish_event>::Create(config, _first, _second);
		}
		else if (type == patrol::EnjoyFlowerEvent)
		{
			_ptr = Creator<patrol_flower_event>::Create(config, _first);
		}
		else if (type == patrol::FingerGuessEvent)
		{
			_ptr = Creator<patrol_finger_event>::Create(config, _first, _second);
		}
		else if (type == patrol::AnecdoteEvent)
		{
			_ptr = Creator<patrol_anecdote_event>::Create(config, _second);
		}
		else
		{
			_ptr = Creator<patrol_end_event>::Create(config, _second);
			_endPtr = ptr;
		}
	}*/
	
	void playerPatrol1::restart()
	{
		if (_curr_pos != END_POINT)//����������յ㣬����ȡ����ɡ�
		{
			setPos(1);
			setState(patrol::PatrolPenddingDice);
			setEndBoxIndex(-1);
		}
	}

	tm playerPatrol1::getNextTickTime(const tm& old_time)
	{
		tm next_time = old_time;
		if (old_time.tm_hour < 10)
		{
			next_time.tm_hour = 10;
			next_time.tm_min = 30;
			next_time.tm_sec = 0;
			return next_time;
		}
		if (old_time.tm_min < 30)
		{
			next_time.tm_min = 30;
			next_time.tm_sec = 0;
		}
		else
		{
			if (old_time.tm_hour < 23)
			{
				next_time.tm_hour = old_time.tm_hour + 1;
				next_time.tm_min = 0;
			}
			else if (old_time.tm_hour == 23/*&& old_time.tm_min > 29*/)
			{
				next_time.tm_hour = 0;
				next_time.tm_min = 0;
			}
			else
			{
				next_time.tm_hour = 10;
				next_time.tm_min = 30;
			}
			next_time.tm_sec = 0;
		}
		return next_time;
	}

	int playerPatrol1::getOffLineDice(unsigned now, unsigned off, bool isGM)
	{
		if (Own().LV() < PATROL_LEVEL_LIMIT)
		{
			return 0;
		}
		//int inc = _getOffLineDice(Own().Offline().OffTime(), Common::gameTime());
		int dice = 0;
		if (off >= now)
		{
			return dice;
		}

		tm off_tm = Common::toTm(off);
		tm now_tm = Common::toTm(now);

		////�������������ʱ��㡣
		if (!isGM)
		{
			if (off_tm.tm_mday == now_tm.tm_mday)
			{
				//ͬһ��
				if (off_tm.tm_hour < 10 && isGtHour(10, now_tm))
				{
					dice += 5;
				}
				if (off_tm.tm_hour < 21 && isGtHour(21, now_tm))
				{
					dice += 5;
				}
			}
			else
			{
				if (off_tm.tm_hour < 10)
				{
					dice += 10;
				}
				if (off_tm.tm_hour < 21)
				{
					dice += 5;
				}
				if (now_tm.tm_hour >= 21)
				{
					dice += 10;
				}
				if (now_tm.tm_hour >= 10 && now_tm.tm_hour < 21)
				{
					dice += 5;
				}
			}
		}
		///�������������ʱ��Ĵ������������Ĵ���֮ǰ��ʱ���������֣�
		if (off_tm.tm_hour < 10)
		{
			off_tm.tm_hour = 10;
			off_tm.tm_min = 0;
			off_tm.tm_sec = 0;
		}
		/*if (off_tm.tm_hour == 0)
		{
			off_tm.tm_hour = 24;
			off_tm.tm_min = 0;
		}*/
		if (now_tm.tm_hour < 10)
		{
			now_tm.tm_hour = 10;
			now_tm.tm_min = 0;
			now_tm.tm_sec = 0;
		}
		/*if (now_tm.tm_hour == 0)
		{
			now_tm.tm_hour = 24;
			now_tm.tm_min = 0;
		}*/
		int i, j, k, l;
		i = off_tm.tm_hour - 10;
		j = off_tm.tm_min > 29 ? 1 : 0;
		k = now_tm.tm_hour - 10;
		l = now_tm.tm_min > 29 ? 1 : 0;

		int day = (now - off) / DAY;
		//����ʱ��һ������
		if (day > 0)
		{
			dice = DICE_DAY;
			return dice;
		}
		
		////
		if (off_tm.tm_mday == now_tm.tm_mday)
		{
			//ͬһ�죬����i<=k
			dice += tick_dice[i][j] - tick_dice[k][l];
		}
		else
		{
			//����һ�죬������ͬһ��
			dice += tick_dice[i][j] + rtick_dice[k][l];
		}
		
		return dice;
	}

	void playerPatrol1::addTimer(unsigned login_time,  bool isLogin)
	{
		if (Own().LV() >= PATROL_LEVEL_LIMIT)
		{
			delTimer();
			//
			unsigned now_time = Common::gameTime();
			tm now = Common::toTm(now_time);
			tm next_time = getNextTickTime(now);//�����һ����ʱ��ʱ��
			_timerId = Timer::AddEventTickTime(boostBind(playerPatrol1::restoreHalfTick, _1, Own().ID()), Inter::event_patrol_dice_restore, Common::getNextTime(next_time.tm_hour, next_time.tm_min, next_time.tm_sec));
			if (isLogin)
			{
				int inc = getOffLineDice(login_time, Own().Offline().OffTime());
				//LogS << "OffLine compensation is " << inc << LogEnd;
				int old = Own().Res().getDice();
				Own().Res().alterDice(inc);
				Log<int, int>(DBLOG::strLogDice, Own().getOwnDataPtr(), 1, inc, old, Own().Res().getDice());
			}
		}
	}

	void playerPatrol1::delTimer()
	{
		if (_timerId)
		{
			_timerId->delTimer();
		}
		_timerId = ptrTimerIdentify();
	}

	unsigned playerPatrol1::addTickTimer()
	{
		unsigned now = Common::gameTime();
		if (Own().LV() >= PATROL_LEVEL_LIMIT)
		{
			delTickTimer();
			now = Common::gameTime();
			_tenTimerId = Timer::AddEventTickTime(boostBind(playerPatrol1::addFiveDice, _1, Own().ID()), Inter::event_patrol_dice_five, Common::getNextTime(10));
			_twentyOneTimerId = Timer::AddEventTickTime(boostBind(playerPatrol1::addFiveDice, _1, Own().ID()), Inter::event_patrol_dice_five, Common::getNextTime(21));
		}
		return now;
	}

	void playerPatrol1::delTickTimer()
	{
		if (_twentyOneTimerId)
		{
			_twentyOneTimerId->delTimer();
		}
		if (_tenTimerId)
		{
			_tenTimerId->delTimer();
		}
		_twentyOneTimerId = ptrTimerIdentify();
		_tenTimerId = ptrTimerIdentify();
	}

	void playerPatrol1::restoreHalfTick(const structTimer& timerData, const int playerID)
	{
		playerDataPtr player = player_mgr.getOnlinePlayer(playerID);
		if (!player || player->LV() < PATROL_LEVEL_LIMIT)
		{
			return;
		}
		//LogW << "HalfTick trigger..." << "dice:" <<player->Res().getDice() << LogEnd;

		int oldDiceNum = player->Res().getDice();
		player->Res().alterDice(1);
		Log<int, int>(DBLOG::strLogDice, player, 3, 1, oldDiceNum, player->Res().getDice());
		//LogS << "half restore is " << 1 << LogEnd;
		//���ݶ�ʱ��ʱ�������ʱ�䣬�������е�û�б���ʱ���ָ������Ӹ���(����GM���߸���ʱ�������Ĳ���)
		//[����]����������ܹ������ٶ�ʱ��������
		//int inc = _getOffLineDice(timerData.tickTime, Common::gameTime(), true);
		int inc = player->Patrol().getOffLineDice(Common::gameTime(), timerData.tickTime, true);
		//LogS << "GM compensation is " << inc << LogEnd;
		oldDiceNum = player->Res().getDice();
		player->Res().alterDice(inc);
		Log<int, int>(DBLOG::strLogDice, player, 2, inc, oldDiceNum, player->Res().getDice());

		player->Patrol().addTimer(0);
	}

	void playerPatrol1::addFiveDice(const structTimer & timerData, const int playerID)
	{
		playerDataPtr player = player_mgr.getOnlinePlayer(playerID);

		if (!player || player->LV() < PATROL_LEVEL_LIMIT)
		{
			return;
		}
		//LogW << "FiveDice... " << 5 << LogEnd;

		int oldDiceNum = player->Res().getDice();
		player->Res().alterDice(5);
		Log<int, int>(DBLOG::strLogDice, player, 4, 5, oldDiceNum, player->Res().getDice());

		player->Patrol().addTickTimer();
	}

	void playerPatrol1::classLoad()
	{
		//std::cout << "load... " << std::endl;
		mongo::BSONObj key BSON(strPlayerID << Own().ID());
		mongo::BSONObj obj = db_mgr.FindOne(DBN::dbPlayerPatrol, key);
		if (!obj.isEmpty())
		{
			if (!obj[strPos].eoo())
			{
				_curr_pos = obj[strPos].Int();
			}
			if (!obj[strEBoxIdx].eoo())
			{
				_endSecond = obj[strEBoxIdx].Int();
			}
			if (!obj[strFirst].eoo())
			{
				_first = obj[strFirst].Int();
			}
			if (!obj[strSecond].eoo())
			{
				_second = obj[strSecond].Int();
			}
			if (!obj[strVersion].eoo())
			{
				_version = obj[strVersion].Int();
			}
			if (this->_version == 2)
			{
				if (!obj[strState].eoo())
				{
					_state = (patrol::StateType)obj[strState].Int();
				}
				if (!obj[strType].eoo())
				{
					_type = (patrol::EventType)obj[strType].Int();
				}
			}
			else
			{
				_state = patrol::PatrolUninit;
				_type = patrol::EventEnd;
				_curr_pos = 1;
				this->_version = 2;//version update. This is important.
			}
			if (!obj[strDiceNum].eoo())
			{
				_last_dice_num = obj[strDiceNum].Int();
			}
			if (!obj[strTotal].eoo())
			{
				_total_throw = obj[strTotal].type() == mongo::NumberInt ? obj[strTotal].Int() : obj[strTotal].Long();
			}

			if (!obj[strIds].eoo())
			{
				std::vector<mongo::BSONElement> rndIdx = obj[strIds].Array();
				for (unsigned i = 0; i < rndIdx.size(); ++i)
				{
					mongo::BSONElement ele = rndIdx[i];
					_rndIds.push_back(ele.Int());
				}
			}
		}
	}

	bool playerPatrol1::_auto_save()
	{
		//std::cout << "save... " << std::endl;
		mongo::BSONObj key = BSON(strPlayerID << Own().ID());
		mongo::BSONArrayBuilder ids;
		for (int i = 0; i < _rndIds.size(); ++i)
		{
			ids << _rndIds[i];
		}
		mongo::BSONObj obj = BSON(strPlayerID << Own().ID()
			<< strPos << _curr_pos
			<< strState << _state
			<< strType << _type
			<< strEBoxIdx << _endSecond
			<< strFirst << _first
			<< strIds << ids.arr()
			<< strSecond << _second
			<< strDiceNum << _last_dice_num
			<< strVersion << this->_version
			<< strTotal << _total_throw);

		return db_mgr.SaveMongo(DBN::dbPlayerPatrol, key, obj);
	}

	playerPatrol1::~playerPatrol1()
	{
	}
}

#pragma once

#include "commom.h"
#include "mongoDB.h"
#include "res_code.h"
#include "auto_base.h"

namespace gg
{
	class ActivityBase
	{
		public:
			ActivityBase(int key_id, unsigned begin_time, unsigned end_time)
				: _key_id(key_id), _begin_time(begin_time), _end_time(end_time){}

			int keyID() const { return _key_id; }
			unsigned beginTime() const { return _begin_time; }
			unsigned endTime() const { return _end_time; }

			virtual mongo::BSONObj toBSON() const = 0;

			virtual void start(){}                       // 活动开启
			virtual void update(){}                      // 活动更新
			virtual void stop(bool timer_tick){}         // 活动结束(timer_tick: true 正常结束, false 后台关闭)

		private:
			int _key_id;
			unsigned _begin_time;
			unsigned _end_time;
	};
	
	template<typename T>
	class ActivityMgr
	{
		BOOSTSHAREPTR(T, ActivityPtr);
		STDMAP(int, ActivityPtr, ActivityMap);
		STDMAP(int, unsigned, TimerID);
		public:
			ActivityMgr(const std::string& db_name, const int timer_event)
				: _db_name(db_name), _timer_event(timer_event){}

			int update(ActivityPtr& ptr);
			int remove(int key_id);

			ActivityPtr current() const { return _cur_activity; }
			ActivityPtr find(int key_id) const
			{
				typename ActivityMap::const_iterator it = _activity_map.find(key_id);
				return it != _activity_map.end()? it->second : ActivityPtr();
			}

			void getIDList(Json::Value& info);

		private:
			void start(unsigned timer_id, ActivityPtr& ptr);
			void stop(unsigned timer_id, ActivityPtr& ptr);
			void saveDB(ActivityPtr& ptr);
			void removeDB(int key_id);
			void setBothTimer(ActivityPtr& ptr);
			void setStopTimer(ActivityPtr& ptr);
			void resetTimerID(int key_id);
			unsigned getTimerID(int key_id);
			bool timeConflict(const ActivityPtr& a, const ActivityPtr& b) const;

		private:
			ActivityPtr _cur_activity;
			ActivityMap _activity_map;
			TimerID _timer_id;

			const int _timer_event;
			const std::string _db_name;
	};
	
	template<typename T>
	void ActivityMgr<T>::getIDList(Json::Value& info)
	{
		int cur_id = _cur_activity? 
			_cur_activity->keyID() : -1;
		info["cur"] = cur_id;
		info["nor"] = Json::arrayValue;
		ForEachC(typename ActivityMap, it, _activity_map)
		{
			if (cur_id == it->first)
				continue;
			info["nor"].append(it->first);
		}
	}

	template<typename T>
	int ActivityMgr<T>::update(ActivityPtr& ptr)
	{
		if (ptr->beginTime() >= ptr->endTime())
			return err_illedge;
		ForEachC(typename ActivityMap, it, _activity_map)
		{
			if (ptr->keyID() == it->second->keyID())
				continue;
			if (timeConflict(ptr, it->second))
				return err_activity_time_conflict;
		}
		if (_cur_activity && _cur_activity->keyID() == ptr->keyID())
		{
			if (_cur_activity->beginTime() != ptr->beginTime())
				return err_modify_opened_activity_begin_time;
			_activity_map[ptr->keyID()] = ptr;
			_cur_activity = ptr;
			saveDB(ptr);
			ptr->update();
			setStopTimer(ptr);
		}
		else
		{
			_activity_map[ptr->keyID()] = ptr;
			saveDB(ptr);
			setBothTimer(ptr);
		}
		return res_sucess;
	}

	template<typename T>
	bool ActivityMgr<T>::timeConflict(const ActivityPtr& a, const ActivityPtr& b) const
	{
		if (a->beginTime() >= b->beginTime() && a->beginTime() <= b->endTime())
			return false;
		if (a->endTime() >= b->beginTime() && a->endTime() <= b->endTime())
			return false;
		if (a->beginTime() <= b->beginTime() && a->endTime() >= b->endTime())
			return false;
		return true;
	}

	template<typename T>
	void ActivityMgr<T>::setBothTimer(ActivityPtr& ptr)
	{
		resetTimerID(ptr->keyID());
		unsigned timer_id = getTimerID(ptr->keyID());
		unsigned cur_time = Common::gameTime();
		if (cur_time >= ptr->beginTime())
			start(timer_id, ptr);
		else
			Timer::AddEventTickTime(boostBind(ActivityMgr<T>::start, this, timer_id, ptr), _timer_event, ptr->beginTime());
		if (cur_time >= ptr->endTime())
			stop(timer_id, ptr);
		else
			Timer::AddEventTickTime(boostBind(ActivityMgr<T>::stop, this, timer_id, ptr), _timer_event, ptr->endTime());
	}

	template<typename T>
	void ActivityMgr<T>::setStopTimer(ActivityPtr& ptr)
	{
		resetTimerID(ptr->keyID());
		unsigned timer_id = getTimerID(ptr->keyID());
		if (Common::gameTime() >= ptr->endTime())
			stop(timer_id, ptr);
		else
			Timer::AddEventTickTime(boostBind(ActivityMgr<T>::stop, this, timer_id, ptr), _timer_event, ptr->endTime());
	}

	template<typename T>
	void ActivityMgr<T>::resetTimerID(int key_id)
	{
		TimerID::iterator it = _timer_id.find(key_id);
		if (it == _timer_id.end())
			_timer_id.insert(make_pair(key_id, 1));
		else
			++it->second;
	}

	template<typename T>
	unsigned ActivityMgr<T>::getTimerID(int key_id)
	{
		TimerID::iterator it = _timer_id.find(key_id);
		return it == _timer_id.end()? 0 : it->second;
	}

	template<typename T>
	int ActivityMgr<T>::remove(int key_id)
	{
		typename ActivityMap::iterator it = _activity_map.find(key_id);
		if (it == _activity_map.end())
			return err_activity_not_found;
		resetTimerID(key_id);
		_activity_map.erase(it);
		removeDB(key_id);
		if (_cur_activity && _cur_activity->keyID() == key_id)
		{
			ActivityPtr ptr = _cur_activity;
			_cur_activity.reset();
			ptr->stop(false);
		}
		return res_sucess;
	}

	template<typename T>
	void ActivityMgr<T>::start(unsigned timer_id, ActivityPtr& ptr)
	{
		TimerID::const_iterator it_timer = _timer_id.find(ptr->keyID());
		if (it_timer == _timer_id.end()
			|| timer_id != it_timer->second)
			return;
		typename ActivityMap::const_iterator it_act = _activity_map.find(ptr->keyID());
		if (it_act == _activity_map.end())
		{
			LogE << "can not find activity: " << ptr->keyID() << LogEnd;
			return;
		}
		if (_cur_activity)
		{
			LogE << "activity conflict: " << _cur_activity->keyID() << ", " << ptr->keyID() << LogEnd;
			return;
		}
		_cur_activity = ptr;
		ptr->start();
		LogI << "activity start: " << ptr->keyID() << ", time: " << ptr->beginTime() << LogEnd;
	}

	template<typename T>
	void ActivityMgr<T>::stop(unsigned timer_id, ActivityPtr& ptr)
	{
		TimerID::const_iterator it_timer = _timer_id.find(ptr->keyID());
		if (it_timer == _timer_id.end()
			|| timer_id != it_timer->second)
			return;
		typename ActivityMap::iterator it_act = _activity_map.find(ptr->keyID());
		if (it_act == _activity_map.end() || !_cur_activity)
		{
			LogE << "can not find activity: " << ptr->keyID() << LogEnd;
			return;
		}
		_cur_activity.reset();
		_activity_map.erase(it_act);
		removeDB(ptr->keyID());
		ptr->stop(true);
		LogI << "activity stop: " << ptr->keyID() << ", time: " << ptr->endTime() << LogEnd;
	}

	template<typename T>
	void ActivityMgr<T>::saveDB(ActivityPtr& ptr)
	{
		mongo::BSONObj key = BSON("key" << ptr->keyID());
		mongo::BSONObj obj = BSON("key" << ptr->keyID() << "value" << ptr->toBSON());
		db_mgr.SaveMongo(_db_name, key, obj);
	}

	template<typename T>
	void ActivityMgr<T>::removeDB(int key_id)
	{
		mongo::BSONObj key = BSON("key" << key_id);
		db_mgr.RemoveCollection(_db_name, key);
	}
}

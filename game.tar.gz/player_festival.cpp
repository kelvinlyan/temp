#include "player_festival.h"
#include "festival_system.h"
#include "playerManager.h"
#include "map_war.h"
#include "battle_helper.hpp"
#include "kingdomwar_helper.h"
#include "task_mgr.h"

namespace gg
{
	enum
	{
		TURNTABLECOST = 100,
		TURNTABLEPOINT = 100,
		EGGPOINT = 1000,
		EGGCOST = 100,
		TURNTABLEITEM = 20006,
	};

	namespace nFestival
	{
		class Config
		{
			SINGLETON(Config);
			public:
				inline int EggCost(unsigned times);
			private:
				void loadFile();
			private:
				std::vector<int> _costs;
		};

		inline int Config::EggCost(unsigned times)
		{
			if (times >= _costs.size())
				times = _costs.size() - 1;
			return _costs[times];
		}

		Config::Config()
		{
			loadFile();
		}

		void Config::loadFile()
		{
			const Json::Value json = Common::loadJsonFile("./instance/festival/egg_cost.json");
			ForEachC(Json::Value, it, json)
				_costs.push_back((*it).asInt());
		}
	}

	const static int MaterialItem[] = {20002, 20003, 20004, 20005};

	playerFestival::playerFestival(playerData* const own)
		: _auto_player(own), _key_id(-1), _points(0), _next_npc_reset_time(0), _buy_times(0)
	{
	}

	void playerFestival::classLoad()
	{
		mongo::BSONObj key = BSON(strPlayerID << Own().ID());
		mongo::BSONObj obj = db_mgr.FindOne(DBN::dbPlayerFestival, key);
		if (obj.isEmpty()) 
			return;
		checkNotEoo(obj["kid"])
			_key_id = obj["kid"].Int();
		checkNotEoo(obj["pt"])
			_points = obj["pt"].Int();
		checkNotEoo(obj["bt"])
			_buy_times = obj["bt"].Int();
		checkNotEoo(obj["nnrt"])
			_next_npc_reset_time = obj["nnrt"].Int();
		checkNotEoo(obj["kn"])
		{
			std::vector<mongo::BSONElement> ele = obj["kn"].Array();
			for (unsigned i = 0; i < ele.size(); ++i)
				_kingdomwar_npc.push_back(Npc(ele[i]["i"].Int(), ele[i]["t"].Int()));
		}
		checkNotEoo(obj["mn"])
		{
			std::vector<mongo::BSONElement> ele = obj["mn"].Array();
			for (unsigned i = 0; i < ele.size(); ++i)
				_maincity_npc.push_back(Npc(ele[i]["i"].Int(), ele[i]["t"].Int()));
		}
	}

	bool playerFestival::_auto_save()
	{
		mongo::BSONObj key = BSON(strPlayerID << Own().ID());
		mongo::BSONObjBuilder obj;
		obj << strPlayerID << Own().ID() << "kid" << _key_id 
			<< "pt" << _points << "nnrt" << _next_npc_reset_time
			<< "bt" << _buy_times;
		{
			mongo::BSONArrayBuilder b;
			ForEachC(std::vector<Npc>, it, _kingdomwar_npc)
				b.append(BSON("i" << it->id << "t" << it->type));
			obj << "kn" << b.arr();
		}
		{
			mongo::BSONArrayBuilder b;
			ForEachC(std::vector<Npc>, it, _maincity_npc)
				b.append(BSON("i" << it->id << "t" << it->type));
			obj << "mn" << b.arr();
		}
		return db_mgr.SaveMongo(DBN::dbPlayerFestival, key, obj.obj());
	}

	void playerFestival::sendBase()
	{
		update();
		qValue m;
		m.append(res_sucess);
		qValue q(qJson::qj_object);
		q.addMember("pt", _points);
		q.addMember("ec", nFestival::Config::shared().EggCost(_buy_times));
		m.append(q);
		Own().sendToClientFillMsg(gate_client::festival_player_info_resp, m);
	}

	void playerFestival::sendNpc()
	{
		update();
		updateNpc();
		qValue m;
		m.append(res_sucess);
		qValue q(qJson::qj_object);
		{
			qValue n;
			ForEachC(std::vector<Npc>, it, _kingdomwar_npc)
			{
				qValue tmp;
				tmp << it->id << it->type;
				n << tmp;
			}
			q.addMember("kn", n);
		}	
		{
			qValue n;
			ForEachC(std::vector<Npc>, it, _maincity_npc)
			{
				qValue tmp;
				tmp << it->id << it->type;
				n << tmp;
			}
			q.addMember("mn", n);
		}	
		m.append(q);
		Own().sendToClientFillMsg(gate_client::festival_npc_info_resp, m);
	}

	void playerFestival::update()
	{
		int key_id = festival_sys.current()?
			festival_sys.current()->keyID() : -1;
		if (_key_id != key_id)
		{
			_key_id = key_id;
			_points = 0;
			{
				int num = Own().Items().itemNum(TURNTABLEITEM);
				if (num > 0)
					Own().Items().removeItem(TURNTABLEITEM, num);
			}
			for (unsigned i = 0; i < sizeof(MaterialItem) / sizeof(MaterialItem[0]); ++i)
			{
				int num = Own().Items().itemNum(MaterialItem[i]);
				if (num > 0)
					Own().Items().removeItem(MaterialItem[i], num);
			}
			if (key_id != -1)
				resetNpc(Common::gameTime());
			else
			{
				_kingdomwar_npc.clear();
				_maincity_npc.clear();
				_next_npc_reset_time = 0;
			}
			_sign_save();
		}
	}

	int playerFestival::buyTurnTableTimes()
	{
		update();
		if (!festival_sys.current())
			return err_illedge;
		if (Own().Res().getCash() < TURNTABLECOST)
			return err_gold_not_enough;
		Own().Res().alterCash(0-TURNTABLECOST);
		Own().Items().addItem(TURNTABLEITEM, 1);
		_sign_save();
		sendBase();
		return res_sucess;
	}

	int playerFestival::buyThrowEggTimes()
	{
		update();
		if (!festival_sys.current())
			return err_illedge;
		int cost = nFestival::Config::shared().EggCost(_buy_times);
		if (Own().Res().getCash() < cost)
			return err_gold_not_enough;
		Own().Res().alterCash(0-cost);
		_points += EGGPOINT;
		++_buy_times;
		_sign_save();
		sendBase();
		return res_sucess;
	}

	int playerFestival::turnTable(int type, Json::Value& r)
	{
		update();
		if (!festival_sys.current())
			return err_illedge;
		unsigned times = type == 0? 1 : 10;
		if (Own().Items().itemNum(TURNTABLEITEM) < times)
			return err_illedge;
		bool up_bc = false;
		for (unsigned i = 0; i < times; ++i)
		{
			int idx;
			bool bc;
			const ActionBoxList& rw = festival_sys.current()->turnTableReward(idx, bc);
			int res = actionDoBox(Own().getOwnDataPtr(), rw, false);
			if (res == res_sucess)
			{
				Own().Items().removeItem(TURNTABLEITEM, 1);
				_points += TURNTABLEPOINT;
				const Json::Value rw_json = actionRes();
				r[strMsg][1u].append(rw_json);
				r[strMsg][2u].append(idx);
				if (bc)
				{
					up_bc = true;
					qValue r;
					r << Own().Name() << qValue(rw_json.toIndentString().c_str());
					festival_sys.current()->addRecord(r);
				}
				ForEachC(Json::Value, it, rw_json)
				{
					const Json::Value& tmp = *it;
					if (tmp[0u].asInt() == ACTION::ticket)
						TaskMgr::update(Own().getOwnDataPtr(), Task::FestivalGetGoldNum, tmp[1u].asInt());
				}
				Log(DBLOG::strLogFestival, Own().getOwnDataPtr(), 0, type, 1, "", "", "", "", "", rw_json.toIndentString());
			}
			else
			{
				r[strMsg][1u].append(Json::arrayValue);
				r[strMsg][2u].append(-1);
			}
		}
		if (up_bc)
			festival_sys.current()->sendRecord(Own().getOwnDataPtr());
		sendBase();
		_sign_save();
		return res_sucess;
	}

	int playerFestival::throwEgg(Json::Value& r)
	{
		update();
		if (!festival_sys.current())
			return err_illedge;
		if (_points < EGGPOINT)
			return err_illedge;
		int idx;
		bool bc;
		const ActionBoxList& rw = festival_sys.current()->eggReward(idx, bc);
		int res = actionDoBox(Own().getOwnDataPtr(), rw, false);
		if (res == res_sucess)
		{
			_points -= EGGPOINT;
			const Json::Value rw_json = actionRes();
			r[strMsg][1u] = rw_json;
			sendBase();
			if (bc)
			{
				qValue r;
				r << Own().Name() << qValue(rw_json.toIndentString().c_str());
				festival_sys.current()->addRecord(r);
				festival_sys.current()->sendRecord(Own().getOwnDataPtr());
			}
			ForEachC(Json::Value, it, rw_json)
			{
				const Json::Value& tmp = *it;
				if (tmp[0u].asInt() == ACTION::ticket)
					TaskMgr::update(Own().getOwnDataPtr(), Task::FestivalGetGoldNum, tmp[1u].asInt());
			}
			TaskMgr::update(Own().getOwnDataPtr(), Task::FestivalThrowEggTimes, 1);
			Log(DBLOG::strLogFestival, Own().getOwnDataPtr(), 1, (int)EGGPOINT, "", "", "", "", "", "", rw_json.toIndentString());
			_sign_save();
		}
		return res;
	}

	int playerFestival::exchangeMaterial(int idx, Json::Value& r)
	{
		update();	
		if (!festival_sys.current())
			return err_illedge;
		if (!festival_sys.current()->exchangeIndexValid(idx))
			return err_illedge;
		const nFestival::ExchangeItem& exc = festival_sys.current()->exchangeItem(idx);
		ForEachC(nFestival::MaterialList, it, exc.materials)
		{
			if (Own().Items().itemNum(it->item) < it->num)
				return err_item_not_enough;
		}
		int res = actionDoBox(Own().getOwnDataPtr(), exc.reward, false);
		if (res == res_sucess)
		{
			Json::Value cost = Json::arrayValue;
			ForEachC(nFestival::MaterialList, it, exc.materials)
			{
				Own().Items().removeItem(it->item, it->num);
				Json::Value tmp;
				tmp.append(ACTION::item);
				tmp.append(it->item);
				tmp.append(it->num);
				cost.append(tmp);
			}
			const Json::Value rw_json = actionRes();
			r[strMsg][1u] = rw_json;
			ForEachC(Json::Value, it, rw_json)
			{
				const Json::Value& tmp = *it;
				if (tmp[0u].asInt() == ACTION::ticket)
					TaskMgr::update(Own().getOwnDataPtr(), Task::FestivalGetGoldNum, tmp[1u].asInt());
			}
			TaskMgr::update(Own().getOwnDataPtr(), Task::FestivalExchangeTimes, 1);
			Log(DBLOG::strLogFestival, Own().getOwnDataPtr(), 2, idx, "", "", "", "", "", cost.toIndentString(), rw_json.toIndentString());
		}
		return res;
	}

	int playerFestival::fightNpc(int type, int id)
	{
		if (!festival_sys.current())
			return err_illedge;
		std::vector<Npc>& npc_vec = type == 0?
			_maincity_npc : _kingdomwar_npc;
		std::vector<Npc>::iterator it = npc_vec.begin();
		for (; it != npc_vec.end(); ++it)
		{
			if (it->id == id)
				break;
		}
		if (it == npc_vec.end())
			return err_illedge;
		mapDataCfgPtr ptr = map_sys.festivalNpc(Own().Info().MaxBV());
		sBattlePtr atk = BattleHelp::WarPlayer(Own().getOwnDataPtr());
		sBattlePtr def = map_sys.npcSide(ptr);
		def->playerName = festival_sys.current()->npcName(it->type);
		BattleReport reportData;
		O2ORes resultB = reportData.One2One(atk, def, typeBattle::festival_npc);
		reportData.addNotice(Own().ID());
		if (resultB.res == resBattle::atk_win)
		{
			ActionBoxList rw = festival_sys.current()->npcReward(it->type);
			actionDoBox(Own().getOwnDataPtr(), rw, false);
			Json::Value rw_json = actionRes();
			ForEach(Json::Value, it, rw_json)
			{
				const Json::Value& tmp = *it;
				if (tmp[0u].asInt() == ACTION::ticket)
					TaskMgr::update(Own().getOwnDataPtr(), Task::FestivalGetGoldNum, tmp[1u].asInt());
			}
			reportData.addReportdeclare("wb", rw_json);
		}
		reportData.Done(typeBattle::festival_npc);
		npc_vec.erase(it);
		sendNpc();
		_sign_save();
		return res_sucess;
	}

	void playerFestival::resetNpc(unsigned cur_time)
	{
		_kingdomwar_npc.clear();
		_maincity_npc.clear();
		_next_npc_reset_time = (cur_time / HOUR + 1) * HOUR;
		struct tm t = Common::toTm(cur_time); 
		if ((t.tm_hour >= 12 && t.tm_hour <= 14)
			|| (t.tm_hour >= 20 && t.tm_hour <= 22))
		{
			for (unsigned i = 0; i < 3; ++i)
			{
				int npc_type = festival_sys.current()->npcType();
				_kingdomwar_npc.push_back(Npc(i, npc_type));
				npc_type = festival_sys.current()->npcType();
				_maincity_npc.push_back(Npc(i, npc_type));
			}
		}
		_sign_save();
	}

	void playerFestival::updateNpc()
	{
		if (!festival_sys.current())
			return;
		unsigned cur_time = Common::gameTime();
		if (cur_time >= _next_npc_reset_time)
			resetNpc(cur_time);
	}

	void playerFestival::dailyTick()
	{
		if (_buy_times != 0)
		{
			_buy_times = 0;
			_sign_save();
		}
	}
}

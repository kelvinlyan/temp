//###################################
//create by Jim
//2016-01-26
//###################################


#pragma once

#include "auto_base.h"

namespace gg
{
	class playerPoke :
		public _auto_player
	{
	public:
		playerPoke(playerData* const own);
		~playerPoke(){}
		void signPoke(const int pokeID);//��ʶͼ��
		void removePoke(const int pokeID);//��ʶͼ��
		virtual void _auto_update();
		inline string getData() { return pokeData; }
	private:
		virtual void classLoad();
		virtual bool _auto_save();
		std::string pokeData;//ͼ������ 0,1���
	};
}
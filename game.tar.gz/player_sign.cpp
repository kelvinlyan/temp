#include "player_sign.h"
#include "sign_system.h"
#include "task_mgr.h"
#include "game_time.h"
#include "kingdomwar_helper.h"

namespace gg
{
	namespace nSign
	{
		struct RewardItem
		{
			RewardItem(const Json::Value& info)
			{
				days = info["day"].asInt();
				Json::Value rw = info["reward"];
				reward = actionFormatBox(rw);
			}
			int days;
			ActionBoxList reward;
		};

		class TotalReward
		{
			SINGLETON(TotalReward);
			public:
				int getDays(int d) const;
				const ActionBoxList& getReward(int d) const;
			private:
				void loadFile();
			private:
				STDVECTOR(RewardItem, Items);
				Items _items;
		};

		TotalReward::TotalReward()
		{
			loadFile();
		}

		void TotalReward::loadFile()
		{
			const Json::Value info = Common::loadJsonFile("./instance/sign/total_reward.json");
			ForEachC(Json::Value, it, info)
				_items.push_back(RewardItem(*it));
		}

		const ActionBoxList& TotalReward::getReward(int d) const
		{
			ForEachC(Items, it, _items)
			{
				if (it->days > d)
					return it->reward;
			}
			return _items.back().reward;
		}

		int TotalReward::getDays(int d) const
		{
			ForEachC(Items, it, _items)
			{
				if (it->days > d)
					return it->days;
			}
			return ((d - _items.back().days) / 10 + 1) * 10 + _items.back().days;
		}
	}

	playerSign::playerSign(playerData* const own)
		: _auto_player(own), _next_sign_time(0), _days(0), _first_reward(true), _reset_time(0), _total_days(0), _total_reward_days(0)
	{
	}

	void playerSign::classLoad()
	{
		mongo::BSONObj key = BSON(strPlayerID << Own().ID());
		mongo::BSONObj obj = db_mgr.FindOne(DBN::dbPlayerSign, key);
		
		if (obj.isEmpty()) 
			return;

		checkNotEoo(obj["nt"])
			_next_sign_time = obj["nt"].Int();
		checkNotEoo(obj["dy"])
			_days = obj["dy"].Int();
		checkNotEoo(obj["fr"])
			_first_reward = obj["fr"].Bool();
		checkNotEoo(obj["td"])
			_total_days = obj["td"].Int();
		else
			_total_days = obj["dy"].Int();
		checkNotEoo(obj["trd"])
			_total_reward_days = obj["trd"].Int();
	}

	bool playerSign::_auto_save()
	{
		mongo::BSONObj key = BSON(strPlayerID << Own().ID());
		mongo::BSONObjBuilder obj;
		obj << strPlayerID << Own().ID() << "nt" << _next_sign_time
			<< "dy" << _days << "fr" << _first_reward << "td" << _total_days
			<< "trd" << _total_reward_days;
		return db_mgr.SaveMongo(DBN::dbPlayerSign, key, obj.obj());
	}

	void playerSign::_auto_update()
	{
		update();
	}

	void playerSign::checkAndUpdate()
	{
		/*if (_first_reward)
		{
			if (_reset_time == 0)
				_reset_time = season_sys.openTime() + 28 * DAY;
				//_reset_time = Common::getLastTimeHMS(Own().Info().CreateTime(), 5) + 30 * DAY;
			if (Common::gameTime() >= _reset_time)
			{
				_first_reward = false;
				_days = 0;
				_sign_save();
			}
		}*/
	}

	void playerSign::update()
	{
		checkAndUpdate();

		Json::Value msg;
		msg[strMsg][0u] = res_sucess;
		msg[strMsg][1u]["nt"] = _next_sign_time;
		msg[strMsg][1u]["dy"] = _days;
		msg[strMsg][1u]["fr"] = _first_reward;
		msg[strMsg][1u]["td"] = _total_days;
		msg[strMsg][1u]["trd"] = _total_reward_days;
		Own().sendToClient(gate_client::sign_player_info_resp, msg);
	}

	int playerSign::getTotalReward(Json::Value& r)
	{
		int day_limit = nSign::TotalReward::shared().getDays(_total_reward_days);
		if (_total_days < day_limit)
			return err_illedge;
		const ActionBoxList& rw = nSign::TotalReward::shared().getReward(_total_reward_days);
		int res = actionDoBox(Own().getOwnDataPtr(), rw, false);
		if (res == res_sucess)
		{
			Json::Value rw_json = actionRes();
			_total_reward_days = day_limit;
			r[strMsg][1u] = rw_json;
			Log(DBLOG::strLogSign, Own().getOwnDataPtr(), 1, day_limit, "", "", "", "", "", "", rw_json.toIndentString());
			_sign_auto();
		}
		else
		{
			Json::Value error_code = actionError();
			res = error_code[0u][1u].asInt();
		}
		return res;
	}

	int playerSign::getReward(int id, Json::Value& r)
	{
		checkAndUpdate();

		unsigned cur_time = Common::gameTime();
		if (signedToday())
			return err_illedge;
		if (id != _days + 1)
			return err_sign_reward_changed;
		if (_days == 28)
		{
			LogE << "get sign reward error" << LogEnd;
			return err_illedge;
		}
		
		const ActionBoxList& box = sign_sys.getBoxList(Own().getOwnDataPtr(), _days, _first_reward);
		int res = actionDoBox(Own().getOwnDataPtr(), box, false);
		if (res == res_sucess)
		{
			++_total_days;
			_next_sign_time = Common::getNextTimeHMS(cur_time, 5);
			int sign_day = ++_days;
			r = actionRes();
			_sign_auto();
			TaskMgr::update(Own().getOwnDataPtr(), Task::SignDayNum);
			Log(DBLOG::strLogSign, Own().getOwnDataPtr(), 0, Own().Info().VipLv()
				, sign_day, "", "", "", "", "", r.toIndentString());
		}
		else
		{
			Json::Value error_code = actionError();
			res = error_code[0u][1u].asInt();
		}
		return res;
	}

	bool playerSign::signedToday() const
	{
		return Common::gameTime() < _next_sign_time;
	}

	void playerSign::dailyTick()
	{
		if (_days == 28)
		{
			_days = 0;
			_first_reward = false;
			_sign_auto();
		}
	}
	
}

//###################################
//create by YeMing
//2016-11-18
//###################################
#pragma once

#include "auto_base.h"
#include "commom.h"
#include "gamer_data.h"


namespace gg
{
	struct  vipGift
	{
		int giftId;
		int rState;
	};
	BOOSTSHAREPTR(vipGift, vipGiftPtr);
	UNORDERMAP(int, vipGiftPtr, vipGiftMap);

	class playerVipMgr:
		public _auto_player
	{
	public:
		playerVipMgr(playerData* const own);
		~playerVipMgr() {}
		void					classLoad();
		virtual void			_auto_update();
		virtual bool			_auto_save();
	public:
		void addVipGift(int id);
		int getVipGift(int id, int is_broadcast);
		Json::Value formatgift();
		int getFirstGift(Json::Value& r);
	private:
		vipGiftMap playerVipGift;
		//int first_gift_state;
	};
}

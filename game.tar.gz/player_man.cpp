#include "player_man.h"
#include "dbDriver.h"
#include "man_system.h"
#include "task_mgr.h"
#include "shop_mgr.h"
#include "man_battle_rank.h"

namespace gg
{
	static bool SortMan(playerManPtr left, playerManPtr right)
	{
		if (left->battleValue() != right->battleValue())return left->battleValue() > right->battleValue();
		if (left->LV() != right->LV())return left->LV() > right->LV();
		const int OwnStar = left->mID() % 100;
		const int OtherStar = right->mID() % 100;
		if (OwnStar != OtherStar)return OwnStar > OtherStar;
		return left->mID() < right->mID();
	}

	void ManConfig::LevelAttri(const std::map<int, unsigned>& levelList, int* attri)
	{
		for (std::map<int, unsigned>::const_iterator it = levelList.begin(); it != levelList.end(); ++it)
		{
			if (isVaildFriendType(it->first))
			{
				const LevelList& ll = Friends[it->first];
				if (ll.empty())continue;
				const FriendLevel& cl = it->second < ll.size() ? ll[it->second] : ll.back();
				for (unsigned n = 0; n < cl.AttriList.size(); ++n)
				{
					const AttriBase& base = cl.AttriList[n];
					attri[base.idx] += base.val;
				}
			}
		}
	}

	bool ManConfig::isVaildFriendType(const int type)
	{
		return Friends.find(type) != Friends.end();
	}

	static vector<unsigned> cfgExpSeq;
	const static unsigned starsSatifyState = 0xF;
	static boost::unordered_map< int, std::vector< double > > BVAttriCal;
	static boost::unordered_map< int, int > BVAttriLVCal;

	playerMan::playerMan(const cfgManPtr config, playerData* const own, const unsigned lv /* = 1 */)
		:_auto_player(own)//�����佫�Ľӿ�
	{
		//��������
		handlerCfg = config;
		stateAttri = 0;
		manID = config->manID;
		manLevel = lv;
		manExp = 0;
		memset(_own_attri, 0x0, sizeof(_own_attri));
		memset(_equip_attri, 0x0, sizeof(_equip_attri));
		battleValue_ = 0;
		noeq_battleValue_ = 0;
		friendLevel.clear();
		equipList.clear();
		equipList.resize(equipHoleSize);
		cTrain.clear();
		if (config)
		{
			for (unsigned i = 0; i < config->TrainList.size(); ++i)
			{
				const AttributeIDX idx = config->TrainList[i].idx;
				cTrain.push_back(MANDEF::trainPlayer(idx));
			}
		}
	}

	int playerMan::onEquip(const int localID, const bool recal /* = true */)
	{
		itemPtr eq = Own().Items().getLocalItem(localID, itemDef::pos_bag | itemDef::pos_man);
		if (!eq)return err_item_no_found;
		cfgItemPtr config_item = eq->getConfig();
		cfgManPtr config_man = getConfig();
		if (!config_man || !config_item)return err_illedge;
		if (!config_item->isEquip())return err_illedge;
		//if (eq->Pos() != itemDef::pos_bag)return err_illedge;
		const unsigned limit = config_item->_declare._equip.equipLimit;
		if ((limit & config_man->manType) == 0)return err_illedge;
		const unsigned pos = config_item->_declare._equip.equipPos;
		if (pos >= equipHoleSize)return err_illedge;
		playerManPtr other_man = Own().Man().findMan(eq->getHandler());
		itemPtr mine_eq = equipList[pos];
		bool error = true;
		if (other_man)//���װ����ӵ����
		{
			if (other_man->equipList[pos] != eq)return err_illedge;
			if (equipList[pos])//������λ������װ��
			{
				//���Խ�����ȥ
				do
				{
					cfgItemPtr mine_config_item = mine_eq->getConfig();
					cfgManPtr other_config_man = other_man->getConfig();
					if (!other_config_man || !mine_config_item)break;
					if (!mine_config_item->isEquip())break;
					const unsigned mine_limit = mine_config_item->_declare._equip.equipLimit;
					if ((mine_limit & other_config_man->manType) == 0)break;
					const unsigned mine_pos = mine_config_item->_declare._equip.equipPos;
					if (mine_pos != pos)break;
					other_man->equipList[pos] = mine_eq;
					mine_eq->setPos(itemDef::pos_man);
					mine_eq->setHandler(other_man->mID());
					error = false;
				} while (false);
			}
			if (error)//������ȥ
			{
				other_man->equipList[pos] = itemPtr();
			}
			other_man->recalEquipAttri(true, (~MANDEF::war_format) & (~MANDEF::expedition_format));
			other_man->_sign_auto();//������ζ�Ҫ�������
		}
		if (error && mine_eq)
		{
			mine_eq->setPos(itemDef::pos_bag);
			mine_eq->setHandler(-1);
		}
		eq->setPos(itemDef::pos_man);
		eq->setHandler(manID);
		equipList[pos] = eq;
		_sign_auto();
		if (recal)recalEquipAttri();
		return res_sucess;
	}

	int playerMan::offEquip(const unsigned pos, const bool recal /* = true */)
	{
		if (pos >= equipHoleSize)return err_illedge;
		if (equipList[pos])
		{
			equipList[pos]->setPos(itemDef::pos_bag);
			equipList[pos]->setHandler(-1);
			equipList[pos] = itemPtr();
		}
		_sign_auto();
		if (recal)recalEquipAttri();
		return res_sucess;
	}

	int playerMan::offEquipByItem(const int localID, const bool recal /* = true */)
	{
		for (unsigned i = 0; i < equipList.size(); i++)
		{
			if (equipList[i] && equipList[i]->ID() == localID)
			{
				equipList[i]->setPos(itemDef::pos_bag);
				equipList[i]->setHandler(-1);
				equipList[i] = itemPtr();
				_sign_auto();
				break;
			}
		}
		if (recal)recalEquipAttri();
		return res_sucess;
	}

	void playerMan::deal_recal_type(const bool update, const unsigned notice)
	{
		if (update)_sign_update();
		if ((notice & MANDEF::war_format) > 0)
		{
			Own().WarFM().recalFMValue();
		}
		if ((notice & MANDEF::kingdom_war_format) > 0)
		{
			Own().KingDomWarFM().recalFM(manID);
		}
		if ((notice & MANDEF::max_man_check) > 0)
		{
			man_battle_rank.updatePlayer(Own().getOwnDataPtr(), *this);
		}
		if ((notice & MANDEF::expedition_format) > 0)
		{
			Own().Expedition().recalFM();
			Own().ExpeditionFM().recalFM();
		}
	}

	void playerMan::recal_equip_attri()
	{
		memset(_equip_attri, 0x0, sizeof(_equip_attri));

		//װ������
		for (unsigned i = 0; i < equipList.size(); ++i)
		{
			itemPtr item = equipList[i];
			if (!item)continue;
			cfgItemPtr config = item->getConfig();
			const unsigned at_idx = item->getLv();
			const itemConfig::EQUIP& _equip = config->_declare._equip;
			const vector<int>& add_equip = at_idx < _equip.equipAttri->size() ? _equip.equipAttri->operator[](at_idx) : _equip.equipAttri->back();
			//װ���ĵȼ�����
			for (unsigned idx = 0; idx < characterNum; ++idx)
			{
				_equip_attri[idx] += add_equip[idx];
			}
			//װ���ĸ�������//װ����ϴ������
			cfgItemPtr gem_config = item->getGemConfig();
			double gem_rate = 0.0;
			if (gem_config)gem_rate = gem_config->_declare._gem.rate;
			for (unsigned idx = 0; idx < itemDeclare::rbNum; ++idx)
			{
				const itemDeclare::rbAttri& at = item->getReborn((itemDeclare::rbIDX)idx);
				if (at.idx < 0)continue;
				_equip_attri[at.idx] += int(at.val *(1.0 + gem_rate));
			}
		}
	}

	void playerMan::recalEquipAttri(const bool update /* = true */, const unsigned notice /* = MANDEF::format_all */)
	{
		recal_equip_attri();
		recal_battle_value();
		deal_recal_type(update, notice);
	}

	void playerMan::recal_own_attri()
	{
		memset(_own_attri, 0x0, sizeof(_own_attri));
		cfgManPtr config = getConfig();
		if (!config)return;

		//�����������
		memmove(_own_attri, config->inital, sizeof(_own_attri));

		//�������Լӳ�
		for (unsigned i = 0; i < cTrain.size(); ++i)
		{
			const MANDEF::trainPlayer& cData = cTrain[i];
			_own_attri[cData.idx] += cData.val;
		}

		//��Ӫ�ӳ�
		int buildAttri[characterNum];
		memset(buildAttri, 0x0, sizeof(buildAttri));
		Own().Builds().getBuildAttri(config->relateBuild, buildAttri);

		//�������Լӳ�
		int friend_ship[characterNum];
		memset(friend_ship, 0x0, sizeof(friend_ship));
		config->LevelAttri(friendLevel, friend_ship);

		for (unsigned i = 0; i < characterNum; ++i)
		{
			//�ɳ�����
			_own_attri[i] += (int(config->grow[i] * (manLevel == 0 ? 0 : manLevel - 1)) + config->armsAdd[i]);
			//��������
			for (unsigned n = 0; n < starsAttriNum; ++n)
			{
				if ((stateAttri & (0x0001 << n)) > 0)
				{
					_own_attri[i] += config->manAttri[n][i];
				}
			}
			//��Ӫ���� + ��������
			_own_attri[i] += (buildAttri[i] + friend_ship[i]);//��ֵ���ռӳ�
		}
	}

	void playerMan::recalOwnAttri(const bool update /* = true */, const unsigned notice /* = MANDEF::format_all */)
	{
		recal_own_attri();
		recal_battle_value();
		deal_recal_type(update, notice);
	}

	void playerMan::recalAllAttri(const bool update /* = true */, const unsigned notice /* = MANDEF::format_all */)
	{
		recal_equip_attri();
		recal_own_attri();
		recal_battle_value();
		deal_recal_type(update, notice);
	}

	void playerMan::recalExtraAttri(const bool update /* = true */, const unsigned notice /* = MANDEF::format_all */)
	{
		recal_battle_value();
		deal_recal_type(update, notice);
	}

	void playerMan::recal_battle_value()
	{
		cfgManPtr config = getConfig();
		if (!config)return;
		//ս����������ֵ
		const vector<double>& battleConfig = BVAttriCal[config->armsType];
		//��������
		const int* public_attri = Own().Man().ComonAttri();


		//==============ս����================
		const int oldValue = battleValue_;
		battleValue_ = 0;
		noeq_battleValue_ = 0;
		for (unsigned i = 0; i < characterNum; ++i)
		{
			//������ֵ * ��ֵ�߻����õ���ֵ
			battleValue_ += std::abs(int((_own_attri[i] + _equip_attri[i] + public_attri[i]) * battleConfig[i]));
			noeq_battleValue_ += std::abs(int((_own_attri[i] + public_attri[i]) * battleConfig[i]));
		}

		//�ȼ�����
		battleValue_ += (LV() * BVAttriLVCal[config->armsType]);
		noeq_battleValue_ += (LV() * BVAttriLVCal[config->armsType]);

		//���Խ��
		const static int MaxValue = 100000000;//1��
		if (battleValue_ < 0 || battleValue_ > MaxValue)battleValue_ = MaxValue;
		if (noeq_battleValue_ < 0 || noeq_battleValue_ > MaxValue)noeq_battleValue_ = MaxValue;

		if (oldValue == 0 ||
			oldValue != battleValue_)
		{
			Own().Man().SortMaxMan();
			_sign_save();//ս�����
		}
	}

	void playerMan::toInitialAttri(int* attri)
	{
		cfgManPtr config = getConfig();
		if (!config)return;
		memmove(attri, config->inital, sizeof(config->inital));
	}

	void playerMan::toPublicAttri(int* attri)
	{
		memmove(attri, Own().Man().ComonAttri(), sizeof(_own_attri));
	}

	void playerMan::toNoEquipAttri(int* attri)
	{
		const int* public_attri = Own().Man().ComonAttri();
		for (unsigned i = 0; i < characterNum; ++i)
		{
			attri[i] = public_attri[i] + _own_attri[i];
		}
	}

	void playerMan::toNoEquipAttri(const int fmID, int* attri)
	{
		int fmAttri[characterNum];
		memset(fmAttri, 0x0, sizeof(fmAttri));
		const FMCFG& config = playerWarFM::getConfig(fmID);
		Own().Research().getForAttr(config.techID, fmAttri);
		const int* public_attri = Own().Man().ComonAttri();
		for (unsigned i = 0; i < characterNum; ++i)
		{
			attri[i] = public_attri[i] + _own_attri[i] + fmAttri[i];
		}
	}

	void playerMan::toBattleAttri(const int fmID, int* attri)
	{
		int fmAttri[characterNum];
		memset(fmAttri, 0x0, sizeof(fmAttri));
		playerWarFM::FormationAttribute(Own().getOwnDataPtr(), fmID, fmAttri);
		const int* public_attri = Own().Man().ComonAttri();
		for (unsigned i = 0; i < characterNum; ++i)
		{
			attri[i] = int(public_attri[i] + _own_attri[i] + _equip_attri[i] + fmAttri[i]);
		}
	}

	bool playerMan::_on_sign_update()
	{
		Own().Man().updateMan(manID);
		return false;
	}

	qValue playerMan::jsonPackage()
	{
		qValue json(qJson::qj_object);
		json.addMember("mid", manID);
		json.addMember("lv", manLevel);
		json.addMember("exp", manExp);
		json.addMember("st", stateAttri);
		json.addMember("bv", battleValue_);
		json.addMember("nbv", noeq_battleValue_);
		qValue base_attriJson(qJson::qj_array), eq_attriJson(qJson::qj_array);
		const int* public_attri = Own().Man().ComonAttri();
		for (unsigned i = 0; i < characterNum; ++i)
		{
			base_attriJson.append(_own_attri[i] + public_attri[i]);
			eq_attriJson.append(_equip_attri[i]);
		}//�����������
		json.addMember("atb", base_attriJson);
		json.addMember("ate", eq_attriJson);
		qValue eqJson(qJson::qj_array);
		for (unsigned i = 0; i < equipList.size(); ++i)
		{
			if (equipList[i])eqJson.append(equipList[i]->ID());
			else eqJson.append(-1);
		}
		json.addMember("eq", eqJson);
		qValue fsJson(qJson::qj_array);
		for (std::map<int, unsigned>::const_iterator it = friendLevel.begin(); it != friendLevel.end(); ++it)
		{
			fsJson.append(qValue(qJson::qj_array).append(it->first).append(it->second));
		}
		json.addMember("fri", fsJson);
		qValue tpmJson(qJson::qj_array);
		for (unsigned i = 0; i < cTrain.size(); ++i)
		{
			const MANDEF::trainPlayer& cData = cTrain[i];
			qValue sg_json(qJson::qj_array);
			sg_json.append(cData.idx);
			sg_json.append(cData.val);
			sg_json.append(cData.nval);
			sg_json.append(cData.mval);
			tpmJson.append(sg_json);
		}
		json.addMember("tpm", tpmJson);
		return json;
	}

	int playerMan::starsUp()
	{
		cfgManPtr new_config = man_sys.getConfig(manID + 1);
		cfgManPtr old_config = getConfig();
		if (!old_config || !new_config)return err_illedge;
		if (manLevel < old_config->star_level)return err_man_level_too_low;
		if (new_config->manID / 100 != ID())return err_illedge;
		if ((stateAttri & starsSatifyState) != starsSatifyState)return err_man_no_satify_attri;
		const int old_id = manID;
		manID = new_config->manID;
		stateAttri = 0;
		handlerCfg = new_config;
		Own().Face().insertFace(new_config->faceID);
		recalOwnAttri(false);
		onManStarsUp(old_id, manID);
		_sign_auto();
		return res_sucess;
	}

	bool playerMan::HasNowTrain()
	{
		
		for (unsigned i = 0; i < cTrain.size(); ++i)
		{
			const MANDEF::trainPlayer& cT = cTrain[i];
			if (cT.nval > 0)return true;
		}
		return false;
	}

	bool playerMan::HasMaxTrain()
	{
		for (unsigned i = 0; i < cTrain.size(); ++i)
		{
			const MANDEF::trainPlayer& cT = cTrain[i];
			if (cT.mval > 0)return true;
		}
		return false;
	}

	bool playerMan::isMaxTrain() const
	{
		int val = 0;
		for (unsigned i = 0; i < cTrain.size(); ++i)
			val += cTrain[i].val;
		return val >= (cTrain.size() * (20 + manLevel));
	}

	int playerMan::getAttackTrain() const
	{
		if (cTrain[0].idx == idx_tl_phy
			|| cTrain[0].idx == idx_tl_war
			|| cTrain[0].idx == idx_tl_magic)
			return cTrain[0].val;
		return 0;
	}

	void playerMan::ClearNowTrain()
	{
		for (unsigned i = 0; i < cTrain.size(); ++i)
		{
			MANDEF::trainPlayer& cT = cTrain[i];
			cT.nval = 0;
		}
		_sign_auto();
	}

	void playerMan::setNowTrain(const vector<int>& trains)
	{
		const unsigned length = trains.size();
		for (unsigned i = 0; i < cTrain.size(); ++i)
		{
			MANDEF::trainPlayer& cT = cTrain[i];
			if (i < length)
			{
				cT.nval = trains[i];
			}
			else
			{
				cT.nval = 0;
			}
		}
		_sign_auto();
	}

	int playerMan::ReplaceTrain()
	{
		if (!HasNowTrain())return err_illedge;
		qValue log_json(qJson::qj_array);
		int ct_val = 0, mt_val = 0;
		for (unsigned i = 0; i < cTrain.size(); ++i)
		{
			MANDEF::trainPlayer& cData = cTrain[i];
			cData.val = cData.nval;
			qValue sg_json(qJson::qj_array);
			sg_json.append(cData.idx).append(cData.val);
			log_json.append(sg_json);
			cData.nval = 0;
			ct_val += cData.val;
			mt_val += cData.mval;
			if (i == 0 && 
				(cData.idx == idx_tl_phy
				|| cData.idx == idx_tl_war
				|| cData.idx == idx_tl_magic))
			{
				TaskMgr::update(Own().getOwnDataPtr(), Task::HurtTrainNum);
			}
		}
		if (ct_val >= mt_val)
		{
			for (unsigned i = 0; i < cTrain.size(); ++i)
			{
				MANDEF::trainPlayer& cData = cTrain[i];
				cData.mval = cData.val;
			}
		}
		if (ct_val >= cTrain.size() * (20 + manLevel))
			TaskMgr::update(Own().getOwnDataPtr(), Task::MaxTrainNum);
		recalOwnAttri(false);
		_sign_auto();
		Log(DBLOG::strLogManDo, Own().getOwnDataPtr(), 5, log_json.toIndentString());
		return res_sucess;
	}

	unsigned playerMan::getFriendLevel(const int type)
	{
		std::map<int, unsigned>::const_iterator it = friendLevel.find(type);
		if (it == friendLevel.end())return 0;
		return it->second;
	}

	void playerMan::setFriendLevel(const int type, const unsigned level)
	{
		friendLevel[type] = level;
		recalOwnAttri(false);
		_sign_auto();
	}

	int playerMan::RecoverTrain()
	{
		if (!HasMaxTrain())return err_illedge;
		qValue log_json(qJson::qj_array);
		bool the_same = true;
		for (unsigned i = 0; i < cTrain.size(); ++i)
		{
			MANDEF::trainPlayer& cData = cTrain[i];
			if (cData.val != cData.mval)
			{
				the_same = false;
				break;
			}
		}
		if (the_same)return err_illedge;
		for (unsigned i = 0; i < cTrain.size(); ++i)
		{
			MANDEF::trainPlayer& cData = cTrain[i];
			cData.val = cData.mval;
			qValue sg_json(qJson::qj_array);
			sg_json.append(cData.idx).append(cData.val);
			log_json.append(sg_json);
		}
		recalOwnAttri();
		Log(DBLOG::strLogManDo, Own().getOwnDataPtr(), 6, log_json.toIndentString());
		_sign_auto();
		return res_sucess;
	}

	void playerMan::setLV_gm(const unsigned level)
	{
		if (level >= cfgExpSeq.size())
		{
			manLevel = cfgExpSeq.size();
			manExp = 0;
		}
		else
		{
			manLevel = level;
		}
		TaskMgr::update(Own().getOwnDataPtr(), Task::MaxTrainNum);
	}

	void playerMan::setExp_gm(const unsigned exp)
	{
		manExp = exp;
	}

	void playerMan::setState_gm(const unsigned val_)
	{
		for (unsigned i = 0; i < starsAttriNum; ++i)
		{
			stateAttri |= (val_ & (0x0001 << i));
		}
	}

	void playerMan::setDone_gm()
	{
		int tmpLevel = manLevel;
		upgrade();
		if (manLevel >= cfgExpSeq.size())
		{
			manExp = 0;
		}
		if (manLevel > Own().LV())
		{
			manLevel = Own().LV();
		}
		recalOwnAttri(false);
		_sign_auto();
	}

	void playerMan::all_attribute(int* out_attri)
	{
		const int* public_attri = Own().Man().ComonAttri();
		for (unsigned i = 0; i < characterNum; ++i)
		{
			out_attri[i] = _own_attri[i] + _equip_attri[i] + public_attri[i];
		}
	}

	cfgManPtr playerMan::getConfig()
	{
		if (!handlerCfg)
		{
			handlerCfg = man_sys.getConfig(manID);
		}
		return handlerCfg;
	}

	int playerMan::activeAttri(const unsigned idx)
	{
		cfgManPtr config = getConfig();
		if (!config || !config->hold_star_attri)return err_illedge;
		if (idx >= starsAttriNum)return err_illedge;
		if (stateAttri & (0x0001 << idx))	return err_man_has_active_attri;
		//sucess
		stateAttri |= (0x0001 << idx);
		recalOwnAttri(false);
		_sign_auto();
		return res_sucess;
	}

	void playerMan::upgrade()
	{
		const unsigned player_lv = Own().LV();
		const unsigned old_level = manLevel;
		for (unsigned idx = manLevel; idx < cfgExpSeq.size(); ++idx)
		{
			if (idx > player_lv)break;
			if (manExp >= cfgExpSeq[idx])
			{
				manExp -= cfgExpSeq[idx];
				manLevel = idx + 1;
				continue;
			}
			break;
		}
		if (manLevel >= player_lv || manLevel >= cfgExpSeq.size())
		{
			manExp = 0;
		}
		if (manLevel != old_level)
			TaskMgr::update(Own().getOwnDataPtr(), Task::MaxTrainNum);
	}

	void playerMan::upgrade(unsigned& total_num)
	{
		const unsigned player_lv = Own().LV();
		const unsigned return_lv = std::max(manLevel, player_lv);
		manExp += total_num;
		const unsigned old_level = manLevel;
		for (unsigned idx = manLevel; idx < cfgExpSeq.size(); ++idx)
		{
			if (idx > player_lv)break;
			if (manExp >= cfgExpSeq[idx])
			{
				manExp -= cfgExpSeq[idx];
				manLevel = idx + 1;
				continue;
			}
			break;
		}
		if (manLevel >= player_lv || manLevel >= cfgExpSeq.size())
		{
			if (old_level >= manLevel)//�ȼ�û��
			{
				total_num = 0;
			}
			else
			{
				total_num -= manExp;
			}
			//if (manExp <= total_num)total_num -= manExp;
			const unsigned final_lv = std::min(return_lv, (unsigned)cfgExpSeq.size());
			manLevel = final_lv;
			manExp = 0;
		}
		if (manLevel != old_level)
			TaskMgr::update(Own().getOwnDataPtr(), Task::MaxTrainNum);
	}

	unsigned playerMan::numAddExp(const unsigned num)
	{
		if (manLevel >= cfgExpSeq.size())return 0;
		if (manLevel >= Own().LV())return 0;
		if (num < 1)return 0;
		unsigned tmpExp = num;
		int tmpLevel = manLevel;
		upgrade(tmpExp);
		const unsigned player_lv = Own().LV();
		if (tmpLevel != manLevel)
		{
			TaskMgr::update(Own().getOwnDataPtr(), Task::ManMaxLv);
			recalOwnAttri(false);
		}
		_sign_auto();
		return tmpExp;
	}

	bool playerMan::isMaxLevel()
	{
		return (manLevel >= cfgExpSeq.size());
	}

	int playerMan::addExp(const unsigned num)
	{
		if (manLevel >= cfgExpSeq.size())return err_man_level_max;
		if (manLevel >= Own().LV())return err_over_player_level;
		if (num < 1)return err_illedge;
		int tmpLevel = manLevel;
		unsigned tmpExp = num;
		upgrade(tmpExp);
		const unsigned player_lv = Own().LV();
		if (tmpLevel != manLevel)
		{
			TaskMgr::update(Own().getOwnDataPtr(), Task::ManMaxLv);
			Log(DBLOG::strLogManDo, Own().getOwnDataPtr(), 0, manID, tmpLevel, manLevel, num);
			recalOwnAttri(false);
		}
		_sign_auto();
		return res_sucess;
	}

	void playerMan::_auto_update()
	{
		qValue data_json(qJson::qj_array);
		data_json.append(res_update_man);
		data_json.append(jsonPackage());
		Own().sendToClientFillMsg(gate_client::player_man_update_resp, data_json);
	}

	bool playerMan::_auto_save()
	{
		mongo::BSONObj key = BSON(strPlayerID << Own().ID() << "rid" << ID());
		mongo::BSONArrayBuilder arr, arr_train, arr_friend;
		for (unsigned i = 0; i < equipList.size(); ++i)
		{
			if (equipList[i])arr << equipList[i]->ID();
			else arr << -1;
		}
		for (unsigned i = 0; i < cTrain.size(); ++i)
		{
			const MANDEF::trainPlayer& cData = cTrain[i];
			arr_train << BSON_ARRAY(cData.val << cData.nval << cData.mval);
		}
		for (std::map<int, unsigned>::const_iterator it = friendLevel.begin(); it != friendLevel.end(); ++it)
		{
			arr_friend << BSON_ARRAY(it->first << it->second);
		}
		mongo::BSONObj obj = BSON(strPlayerID << Own().ID() << "rid" << ID() <<
			"mid" << manID << "lv" << manLevel << "exp" << manExp << "st" << stateAttri
			<< "eq" << arr.arr() << "tpm" << arr_train.arr() << "fri" << arr_friend.arr()
			<< "cbv" << battleValue_ << "q" << manID % 100
		);
		return db_mgr.SaveMongo(DBN::dbPlayerMan, key, obj);
	}

	void playerManMgr::initData()
	{
		{//�����
			cfgExpSeq.clear();
			Json::Value json = Common::loadJsonFile("./instance/manconfig/exp.json");
			for (unsigned i = 0; i < json.size(); ++i)
			{
				unsigned ug_exp = json[i].asUInt();
				ug_exp = ug_exp < 1 ? 1 : ug_exp;
				cfgExpSeq.push_back(ug_exp);
			}
		};

		{//�佫ս������������
			BVAttriCal.clear();
			Json::Value json = Common::loadJsonFile("./instance/manconfig/battle_value.json");
			for (unsigned i = 0; i < json.size(); ++i)
			{
				Json::Value& sg_json = json[i];
				const int armsType = sg_json["type"].asInt();
				const int rateLV = sg_json["rate"].asInt();
				BVAttriLVCal[armsType] = rateLV;
				vector<double> tmp;
				for (unsigned idx = 0; idx < characterNum; ++idx)
				{
					tmp.push_back(sg_json["arr"][idx].asDouble());
				}
				BVAttriCal[armsType] = tmp;
			}
		};
	}

	//////////////////////////////////////////////////////////////////////////
	//mgr
	playerManMgr::playerManMgr(playerData* const own) :_auto_player(own),
		_starUpTimes(0)
	{
		//�ڴ�����
		memset(_comon_attri, 0x0, sizeof(_comon_attri));
		mapMan.clear();

		_manNumBox = 0;
		_baseUpdate = false;
		_lastBuyTableID = 0;
	}

	Json::Value playerManMgr::gmPackage()
	{
		Json::Value json = Json::arrayValue;
		for (ManMap::iterator it = mapMan.begin(); it != mapMan.end(); ++it)
		{
			playerManPtr ptr = it->second;
			if (!ptr)continue;
			Json::Value sg_json;
			sg_json.append(ptr->mID());
			sg_json.append(ptr->LV());
			sg_json.append(ptr->EXP());
			sg_json.append(ptr->activeState());
			json.append(sg_json);
		}
		return json;
	}

	void playerManMgr::updateAll()
	{
		qValue data_list(qJson::qj_array), data_men(qJson::qj_array);
		unsigned num = 0;
		for (ManMap::iterator it = mapMan.begin(); it != mapMan.end();)
		{
			playerManPtr man = it->second;
			++it;
			if (!man)continue;
			++num;
			data_men.append(man->jsonPackage());
			if (num > 49 || it == mapMan.end())
			{
				data_list.append(res_update_man);
				data_list.append(data_men);
				num = 0;
				Own().sendToClientFillMsg(gate_client::player_man_update_resp, data_list);
				data_list.toArray();
				data_men.toArray();
			}
		}
		
		Own().sendToClientFillMsg(gate_client::player_man_base_resp,
			qValue(qJson::qj_array).
			append(res_sucess).
			append(_manNumBox)
			);
	}

	void playerManMgr::_auto_update()
	{
		do
		{
			if (listUdpate.empty())break;
			qValue data_list(qJson::qj_array), data_men(qJson::qj_array);
			unsigned num = 0;
			for (updateList::iterator it = listUdpate.begin(); it != listUdpate.end();)
			{
				playerManPtr man = findMan(*it);
				++it;
				if (!man)continue;
				++num;
				data_men.append(man->jsonPackage());
				if (num > 49 || it == listUdpate.end())
				{
					data_list.append(res_update_man);
					data_list.append(data_men);
					num = 0;
					Own().sendToClientFillMsg(gate_client::player_man_update_resp, data_list);
					data_list.toArray();
					data_men.toArray();
				}
			}
			listUdpate.clear();
		} while (false);

		if (_baseUpdate)
		{
			_baseUpdate = false;
			Own().sendToClientFillMsg(gate_client::player_man_base_resp,
				qValue(qJson::qj_array).
				append(res_sucess).
				append(_manNumBox).
				append(_lastBuyTableID)
			);
		}
	}

	bool playerManMgr::_auto_save()
	{
		mongo::BSONObj key = BSON(strPlayerID << Own().ID());
		mongo::BSONObj obj = BSON(strPlayerID << Own().ID()
			<< "sut" << _starUpTimes << "nbx" << _manNumBox
			<< "ltid" << _lastBuyTableID
		);
		return db_mgr.SaveMongo(DBN::dbPlayerManInfo, key, obj);
	}

	int playerManMgr::addMan(const int manID)
	{
		return addMan(man_sys.getConfig(manID));
	}

	int playerManMgr::addMan(const cfgManPtr config)
	{
		if (!config)return err_man_no_config;
		playerManPtr old_man = findMan(config->manID);
		if (!old_man)//û���佫
		{
			playerManPtr man = Creator<playerMan>::Create(config, _Own);
			mapMan[config->manID / 100] = man;
			listMan.push_back(man);
			man->recalAllAttri(false, MANDEF::max_man_check);
			//man_battle_rank.updatePlayer(Own().getOwnDataPtr(), man);
			if (config)
			{
				Own().Face().insertFace(config->faceID);
			}
			man->_sign_auto();
			TaskMgr::update(Own().getOwnDataPtr(), Task::ManNum);
			TaskMgr::update(Own().getOwnDataPtr(), Task::ManNumOfColor);
			TaskMgr::update(Own().getOwnDataPtr(), Task::ManSpecified);
			Log(DBLOG::strLogManDo, Own().getOwnDataPtr(), 7, config->manID);
			return res_sucess;
		}
		if (old_man->mID() >= config->manID)return err_man_has_hold;//�Ѿ�ӵ���佫
		const int old_id = old_man->mID();
		old_man->manID = config->manID;
		old_man->stateAttri = 0;
		old_man->handlerCfg = config;
		old_man->recalOwnAttri(false);
		old_man->onManStarsUp(old_id, config->manID);
		old_man->_sign_auto();
		{
			//����
			TaskMgr::update(Own().getOwnDataPtr(), Task::ManNum);
			TaskMgr::update(Own().getOwnDataPtr(), Task::ManNumOfColor);
			TaskMgr::update(Own().getOwnDataPtr(), Task::ManSpecified);
		}
		Log(DBLOG::strLogManDo, Own().getOwnDataPtr(), 7, config->manID);
		return res_sucess;
	}

	int playerManMgr::getManCount()
	{
		return (int)mapMan.size();
	}

	int playerManMgr::getManCountByQuality(int iManQuality)
	{
		int iCount = 0;
		for (ManMap::iterator it = mapMan.begin(); it != mapMan.end(); ++it)
		{
			playerManPtr man = it->second;
			//LogI << man->getConfig()->manID << "==>" << man->getConfig()->manQuality << LogEnd;
			if (man->getConfig()->manQuality < iManQuality) { continue; }
			iCount++;
		}
		return iCount;
	}

	void playerManMgr::recal_comon_attri()
	{
		//�Ƽ�
		const int* techAttri = Own().Research().getWarAttri();
		//��Ů����
		const int* cardAttri = Own().Card().getAdd();
		//��������
		const int* kingdomAttri = Own().KingDom().getAttr();
		memset(_comon_attri, 0x0, sizeof(_comon_attri));
		for (unsigned i = 0; i < characterNum; ++i)
		{
			_comon_attri[i] = techAttri[i] + cardAttri[i] + kingdomAttri[i];
		}
	}

	void playerManMgr::recalComonMan(const bool update /* = true */)
	{
		recal_comon_attri();
		for (ManMap::iterator it = mapMan.begin(); it != mapMan.end(); ++it)
		{
			playerManPtr man = it->second;
			man->recalExtraAttri(update, (~MANDEF::war_format) & (~MANDEF::expedition_format));
		}
		Own().WarFM().recalFMValue(update);
		Own().ExpeditionFM().recalFM();
	}

	void playerManMgr::recalArmsMan(const int armsType, const bool update /* = true */)
	{
		for (ManMap::iterator it = mapMan.begin(); it != mapMan.end(); ++it)
		{
			playerManPtr man = it->second;
			cfgManPtr config = man->getConfig();
			if (!config || config->armsType != armsType)continue;
			man->recalOwnAttri(update, (~MANDEF::war_format) & (~MANDEF::expedition_format));
		}
		Own().WarFM().recalFMValue(update);
		Own().ExpeditionFM().recalFM();
	}

	void playerManMgr::classLoad()
	{
		{//�佫����
			mapMan.clear();
			mongo::BSONObj key = BSON(strPlayerID << Own().ID());
			objCollection collection = db_mgr.Query(DBN::dbPlayerMan, key);
			if (collection.empty())return;
			for (unsigned i = 0; i < collection.size(); ++i)
			{
				mongo::BSONObj cObj = collection[i];
				const int manID = cObj["mid"].Int();
				cfgManPtr config = man_sys.getConfig(manID);
				if (!config)continue;
				playerManPtr man = Creator<playerMan>::Create(config, _Own);
				man->manID = manID;
				man->manLevel = (unsigned)cObj["lv"].Int();
				man->manExp = (unsigned)cObj["exp"].Int();
				if (!cObj["st"].eoo()){ man->stateAttri = (unsigned)cObj["st"].Int(); }
				if (!cObj["eq"].eoo())
				{
					vector<mongo::BSONElement> elems = cObj["eq"].Array();
					for (unsigned pos = 0; pos < elems.size() && pos < man->equipList.size(); ++pos)
					{
						man->equipList[pos] = Own().Items().getLocalItem(elems[pos].Int());
						if (man->equipList[pos])
						{
							man->equipList[pos]->setPos(itemDef::pos_man);
							man->equipList[pos]->setHandler(man->mID());
						}
					}
				}
				if (!cObj["tpm"].eoo())
				{
					vector<mongo::BSONElement> elems = cObj["tpm"].Array();
					vector<MANDEF::trainPlayer>& cTrain = man->cTrain;
					for (unsigned idx = 0; idx < elems.size() && idx < cTrain.size(); ++idx)
					{
						vector<mongo::BSONElement> val_list = elems[idx].Array();
						MANDEF::trainPlayer& cData = cTrain[idx];
						const unsigned data_length = val_list.size();
						if (data_length > 0)cData.val = val_list[0].Int();
						if (data_length > 1)cData.nval = val_list[1].Int();
						if (data_length > 2)cData.mval = val_list[2].Int();
					}
				}
				if (!cObj["fri"].eoo())
				{
					vector<mongo::BSONElement> elems = cObj["fri"].Array();
					std::map<int, unsigned>& friendLevel = man->friendLevel;
					for (unsigned idx = 0; idx < elems.size(); ++idx)
					{
						vector<mongo::BSONElement> val_list = elems[idx].Array();
						const int type = val_list[0u].Int();
						if (config->isVaildFriendType(type))
						{
							friendLevel[type] = val_list[1u].Int();
						}
					}
				}
				if (!cObj["cbv"].eoo())
				{
					man->battleValue_ = cObj["cbv"].Int();
				}
				Own().Face().insertFace(config->faceID);
				mapMan[man->ID()] = man;
			}
		};

		{//����������������
			mongo::BSONObj key = BSON(strPlayerID << Own().ID());
			mongo::BSONObj obj = db_mgr.FindOne(DBN::dbPlayerManInfo, key);
			if (!obj.isEmpty())
			{
				checkNotEoo(obj["sut"])
					_starUpTimes = obj["sut"].Int();
				checkNotEoo(obj["nbx"])
					_manNumBox = obj["nbx"].Int();
				checkNotEoo(obj["ltid"])
					_lastBuyTableID = obj["ltid"].Int();
			}
		};
	}

	void playerManMgr::classFinal()
	{
		//����ͨ������
		recal_comon_attri();

		listMan.clear();
		playerDataPtr player = Own().getOwnDataPtr();
		for (ManMap::iterator it = mapMan.begin(); it != mapMan.end(); ++it)
		{
			playerManPtr man = it->second;
			man->recalAllAttri(false, MANDEF::max_man_check);
		}
		for (ManMap::iterator it = mapMan.begin(); it != mapMan.end(); ++it)
		{
			listMan.push_back(it->second);
		}
		SortMaxMan();
	}

	void playerManMgr::updateMan(const int manID)
	{
		listUdpate.insert(manID);
		_sign_update();
	}

	playerManPtr playerManMgr::findManEqual(const int manID)
	{
		playerManPtr man = findManRaw(manID / 100);
		if (man && manID == man->manID)return man;
		return playerManPtr();
	}

	playerManPtr playerManMgr::findMan(const int manID)
	{
		return findManRaw(manID / 100);
	}

	playerManPtr playerManMgr::findManRaw(const int rawID)
	{
		ManMap::iterator it = mapMan.find(rawID);
		if (it == mapMan.end())return playerManPtr();
		return it->second;
	}

	int playerManMgr::friendUpgrade(const int manID, const int friendType)
	{
		playerManPtr man = findMan(manID);
		if (!man)return err_man_no_found;
		cfgManPtr config = man->getConfig();
		if (!config->isVaildFriendType(friendType))return err_illedge;
		const unsigned level = man->getFriendLevel(friendType);
		const ManConfig::LevelList& levelConfig = config->Friends[friendType];
		if (level + 1 >= levelConfig.size())return err_man_friend_level_max;
		const ManConfig::FriendLevel& nowLevel = levelConfig[level + 1];
		//�ж�����
		for (unsigned i =0 ;i < nowLevel.ConditionList.size(); ++i)
		{
			const ManConfig::FriendLevel::Condition& cdi = nowLevel.ConditionList[i];
			playerManPtr check_man = findManRaw(cdi.rawID);
			if (!check_man || check_man->getConfig()->manQuality < cdi.needQuality)return err_man_not_match_require_quality;
		}
		//�ж���Դ
		playerDataPtr ownPlayer = Own().getOwnDataPtr();
		for (unsigned i = 0; i < nowLevel.CostList.size(); ++i)
		{
			const Resource& cost = nowLevel.CostList[i];
			const int cur_res = shops_mgr.checkCommon(cost, ownPlayer);
			if (cur_res != res_sucess)return cur_res;
		}
		//�۳���Դ
		for (unsigned i = 0; i < nowLevel.CostList.size(); ++i)
		{
			const Resource& cost = nowLevel.CostList[i];
			shops_mgr.cutCommon(cost, ownPlayer);
			if (cost.Base.typeID == ACTION::item && cost.Item.itemID == 10021)
				TaskMgr::update(Own().getOwnDataPtr(), Task::FriendItemCostNum, cost.Item.itemNum);
		}
		man->setFriendLevel(friendType, level + 1);
		TaskMgr::update(Own().getOwnDataPtr(), Task::FriendUpgradeTimes, 1);
		Log(DBLOG::strLogManDo, ownPlayer, 9, manID, friendType, level + 1);
		return res_sucess;
	}

	int playerManMgr::getManMaxLv()
	{
		int max = 0;
		for (ManMap::iterator it = mapMan.begin(); it != mapMan.end(); ++it)
		{
			playerManPtr man = it->second;
			if (man->LV() > max)
				max = man->LV();
		}
		return max;
	}

	int playerManMgr::equipExchange(const int manID_1, const int manID_2)
	{
		playerManPtr man_1 = findMan(manID_1);
		playerManPtr man_2 = findMan(manID_2);
		if (!man_1 || !man_2)return err_illedge;
		cfgManPtr man1_config = man_1->getConfig();
		cfgManPtr man2_config = man_2->getConfig();
		if (!man1_config || !man2_config)return err_illedge;
		std::vector<itemPtr>& eq1 = man_1->equipList;
		std::vector<itemPtr>& eq2 = man_2->equipList;

		bool change = false;
		for (unsigned i = 0; i < equipHoleSize; i++)
		{
			itemPtr item1 = eq1[i];
			itemPtr item2 = eq2[i];
			if (item1)
			{
				cfgItemPtr item1_config = item1->getConfig();
				const unsigned limit = item1_config->_declare._equip.equipLimit;
				if ((limit & man2_config->manType) == 0)continue;
			}
			if (item2)
			{
				cfgItemPtr item2_config = item2->getConfig();
				const unsigned limit = item2_config->_declare._equip.equipLimit;
				if ((limit & man1_config->manType) == 0)continue;
			}
			change = true;
			eq1[i] = item2;
			eq2[i] = item1;
			if (item1)
			{
				item1->setHandler(man_2->mID());
			}
			if (item2)
			{
				item2->setHandler(man_1->mID());
			}
		}
		if (change)
		{
			man_1->recalEquipAttri();
			man_2->recalEquipAttri();
			man_1->_sign_auto();
			man_2->_sign_auto();
		}
		return res_sucess;
	}

	void playerManMgr::tickStarUp()
	{
		++_starUpTimes;
		TaskMgr::update(Own().getOwnDataPtr(), Task::AdvanceAllTimes);
		_sign_save();
	}

	void playerManMgr::SortMaxMan()
	{
		std::sort(listMan.begin(), listMan.end(), SortMan);
	}

	int playerManMgr::getMaxTrainManNum() const
	{
		int num = 0;
		ForEachC(ManMap, it, mapMan)
		{
			if (it->second->isMaxTrain())
				++num;
		}
		return num;
	}
	
	int playerManMgr::getHurtTrainManNum(int val) const
	{
		int num = 0;
		ForEachC(ManMap, it, mapMan)
		{
			if (it->second->getAttackTrain() >= val)
				++num;
		}
		return num;
	}

}

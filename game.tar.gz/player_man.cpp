#include "player_man.h"
#include "dbDriver.h"
#include "man_system.h"
#include "task_mgr.h"

namespace gg
{
	static vector<unsigned> cfgExpSeq;
	const static unsigned starsSatifyState = 0xF;
	static boost::unordered_map< int, std::vector< double > > BVAttriCal;
	static boost::unordered_map< int, int > BVAttriLVCal;

	playerMan::playerMan(const cfgManPtr config, playerData* const own, const unsigned lv /* = 1 */)
		:_auto_player(own)//�����佫�Ľӿ�
	{
		handlerCfg = config;
		stateAttri = 0;
		manID = config->manID;
		manLevel = lv;
		manExp = 0;
		memset(manAttri, 0x0, sizeof(manAttri));
		memset(rateAttri, 0x0, sizeof(rateAttri));
		battleValue_ = 0;
		equipList.clear();
		equipList.resize(equipHoleSize);
		//recalAttri(false, 0);
		cTrain.clear();
		if (config)
		{
			for (unsigned i = 0; i < config->TrainList.size(); ++i)
			{
				const AttributeIDX idx = config->TrainList[i].idx;
				cTrain.push_back(MANDEF::trainPlayer(idx));
			}
		}
	}

	int playerMan::onEquip(const int localID, const bool recal /* = true */)
	{
		itemPtr eq = Own().Items().getLocalItem(localID, itemDef::pos_bag | itemDef::pos_man);
		if (!eq)return err_item_no_found;
		cfgItemPtr config_item = eq->getConfig();
		cfgManPtr config_man = getConfig();
		if (!config_man || !config_item)return err_illedge;
		if (!config_item->isEquip())return err_illedge;
		//if (eq->Pos() != itemDef::pos_bag)return err_illedge;
		const unsigned limit = config_item->_declare._equip.equipLimit;
		if ((limit & config_man->manType) == 0)return err_illedge;
		const unsigned pos = config_item->_declare._equip.equipPos;
		if (pos >= equipHoleSize)return err_illedge;
		playerManPtr other_man = Own().Man().findMan(eq->getHandler());
		itemPtr mine_eq = equipList[pos];
		bool error = true;
		if (other_man)//���װ����ӵ����
		{
			if (other_man->equipList[pos] != eq)return err_illedge;
			if (equipList[pos])//������λ������װ��
			{
				//���Խ�����ȥ
				do
				{
					cfgItemPtr mine_config_item = mine_eq->getConfig();
					cfgManPtr other_config_man = other_man->getConfig();
					if (!other_config_man || !mine_config_item)break;
					if (!mine_config_item->isEquip())break;
					const unsigned mine_limit = mine_config_item->_declare._equip.equipLimit;
					if ((mine_limit & other_config_man->manType) == 0)break;
					const unsigned mine_pos = mine_config_item->_declare._equip.equipPos;
					if (mine_pos != pos)break;
					other_man->equipList[pos] = mine_eq;
					mine_eq->setPos(itemDef::pos_man);
					mine_eq->setHandler(other_man->mID());
					error = false;
				} while (false);
			}
			if (error)//������ȥ
			{
				other_man->equipList[pos] = itemPtr();
			}
			other_man->recalAttri(true, ~ MANDEF::war_format);
			other_man->_sign_auto();//������ζ�Ҫ�������
		}
		if (error && mine_eq)
		{
			mine_eq->setPos(itemDef::pos_bag);
			mine_eq->setHandler(-1);
		}
		eq->setPos(itemDef::pos_man);
		eq->setHandler(manID);
		equipList[pos] = eq;
		_sign_auto();
		if (recal)recalAttri();
		return res_sucess;
	}

	int playerMan::offEquip(const unsigned pos, const bool recal /* = true */)
	{
		if (pos >= equipHoleSize)return err_illedge;
		if (equipList[pos])
		{
			equipList[pos]->setPos(itemDef::pos_bag);
			equipList[pos]->setHandler(-1);
			equipList[pos] = itemPtr();
		}
		_sign_auto();
		if (recal)recalAttri();
		return res_sucess;
	}

	int playerMan::offEquipByItem(const int localID, const bool recal /* = true */)
	{
		for (unsigned i = 0; i < equipList.size(); i++)
		{
			if (equipList[i] && equipList[i]->ID() == localID)
			{
				equipList[i]->setPos(itemDef::pos_bag);
				equipList[i]->setHandler(-1);
				equipList[i] = itemPtr();
				_sign_auto();
				break;
			}
		}
		if (recal)recalAttri();
		return res_sucess;
	}

	void playerMan::recalAttri(const bool update /* = true */, const unsigned notice /* = MANDEF::format_all */)
	{
		cfgManPtr config = getConfig();
		if (!config)return;
		//�����������
		memmove(manAttri, config->inital, sizeof(manAttri));
		//�ٷֱȼӳ�
		memset(rateAttri, 0x0, sizeof(rateAttri));
		//װ������
		for (unsigned i = 0; i < equipList.size(); ++i)
		{
			itemPtr item = equipList[i];
			if (!item)continue;
			cfgItemPtr config = item->getConfig();
			const unsigned at_idx = item->getLv();
			const itemConfig::EQUIP& _equip = config->_declare._equip;
			const vector<int>& add_equip = at_idx < _equip.equipAttri->size() ? _equip.equipAttri->operator[](at_idx) : _equip.equipAttri->back();
			const vector<double>& add_rate_equip = at_idx < _equip.equipAttriRate->size() ? _equip.equipAttriRate->operator[](at_idx) : _equip.equipAttriRate->back();
			//װ���ĵȼ�����
			for (unsigned idx = 0; idx < characterNum; ++idx)
			{
				manAttri[idx] += add_equip[idx];
				rateAttri[idx] += add_rate_equip[idx];
			}
			//װ���ĸ�������//װ����ϴ������
			cfgItemPtr gem_config = item->getGemConfig();
			double gem_rate = 0.0;
			if (gem_config)gem_rate = gem_config->_declare._gem.rate;
			for (unsigned idx = 0; idx < itemDeclare::rbNum; ++idx)
			{
				const itemDeclare::rbAttri& at = item->getReborn((itemDeclare::rbIDX)idx);
				if (at.idx < 0)continue;
				manAttri[at.idx] += int(at.val *( 1.0 + gem_rate));
			}
		}
		//��������
		const vector<double>& battleConfig = BVAttriCal[config->armsType];
		for (unsigned i = 0; i < cTrain.size(); ++i)
		{
			const MANDEF::trainPlayer& cData = cTrain[i];
			manAttri[cData.idx] += cData.val;
		}
		//����
		int buildAttri[characterNum];
		memset(buildAttri, 0x0, sizeof(buildAttri));
		Own().Builds().getBuildAttri(config->relateBuild, buildAttri);
		//�Ƽ�
		const int* techAttri = Own().Research().getWarAttri();
		//��Ů����
		const int* cardAttri = Own().Card().getAdd();
		//��������
		const int* kingdomAttri = Own().KingDom().getAttr();
		//==============ս����================
		battleValue_ = 0;
		//==============ս����================
		for (unsigned i = 0; i < characterNum; ++i)
		{
			//�������� ����ֵ + �ɳ�ֵ
			manAttri[i] += (int(config->grow[i] * (manLevel == 0 ? 0 : manLevel - 1)) + config->armsAdd[i]);
			for (unsigned n = 0; n < starsAttriNum; ++n)
			{
				if ((stateAttri & (0x0001 << n)) > 0)
				{
					manAttri[i] += config->manAttri[n][i];
				}
			}
			//�������� װ�� + �Ƽ� + ��������
			manAttri[i] += (techAttri[i] + buildAttri[i] + cardAttri[i] + kingdomAttri[i]);//��ֵ���ռӳ�

			//==============ս����================
			double final_rate = (1.0 + rateAttri[i]) < 0.0 ? 0.0 : (1.0 + rateAttri[i]);
			battleValue_ += std::abs(int(manAttri[i] * final_rate * battleConfig[i]));
			//==============ս����================
		}

		//�ȼ�����
		battleValue_ += (LV() * BVAttriLVCal[config->armsType]);

		//���Խ��
		const static int MaxValue = 100000000;//1��
		if (battleValue_ < 0 || battleValue_ > MaxValue)battleValue_ = MaxValue;

		if (update)_sign_update();
		if ((notice & MANDEF::war_format) > 0)
		{
			Own().WarFM().recalFMValue();
		}
		if ((notice & MANDEF::kingdom_war_format) > 0)
		{
			Own().KingDomWarFM().recalFM(manID);
		}
	}

	void playerMan::toInitialAttri(int* attri)
	{
		cfgManPtr config = getConfig();
		if (!config)return;
		memmove(attri, config->inital, sizeof(config->inital));
	}

	void playerMan::toBattleAttri(const int fmID, int* attri)
	{
		int fmAttri[characterNum];
		memset(fmAttri, 0x0, sizeof(fmAttri));
		const FMCFG& config = playerWarFM::getConfig(fmID);
		Own().Research().getForAttr(config.techID, fmAttri);
		for (unsigned i = 0; i < characterNum; ++i)
		{
			attri[i] = int((manAttri[i] + fmAttri[i]) * (1.0 + rateAttri[i]));
		}
	}

	bool playerMan::_on_sign_update()
	{
		Own().Man().updateMan(manID);
		return false;
	}

	qValue playerMan::jsonPackage()const
	{
		qValue json(qJson::qj_object);
		json.addMember("mid", manID);
		json.addMember("lv", manLevel);
		json.addMember("exp", manExp);
		json.addMember("st", stateAttri);
		json.addMember("bv", battleValue_);
		qValue attriJson(qJson::qj_array);
		for (unsigned i = 0; i < characterNum; ++i)
		{
			attriJson.append(int(manAttri[i] * (1.0 + rateAttri[i])));
		}//�����������
		json.addMember("at", attriJson);
		qValue eqJson(qJson::qj_array);
		for (unsigned i = 0; i < equipList.size(); ++i)
		{
			if (equipList[i])eqJson.append(equipList[i]->ID());
			else eqJson.append(-1);
		}
		json.addMember("eq", eqJson);

		qValue tpmJson(qJson::qj_array);
		for (unsigned i = 0; i < cTrain.size(); ++i)
		{
			const MANDEF::trainPlayer& cData = cTrain[i];
			qValue sg_json(qJson::qj_array);
			sg_json.append(cData.idx);
			sg_json.append(cData.val);
			sg_json.append(cData.nval);
			sg_json.append(cData.mval);
			tpmJson.append(sg_json);
		}
		json.addMember("tpm", tpmJson);
		return json;
	}

	int playerMan::starsUp()
	{
		cfgManPtr new_config = man_sys.getConfig(manID + 1);
		cfgManPtr old_config = getConfig();
		if (!old_config || !new_config)return err_illedge;
		if (!old_config->upStars)return err_illedge;
		if (new_config->manID / 100 != ID())return err_illedge;
		if ((stateAttri & starsSatifyState) != starsSatifyState)return err_man_no_satify_attri;
		const int old_id = manID;
		manID = new_config->manID;
		stateAttri = 0;
		handlerCfg = new_config;
		Own().Face().insertFace(new_config->faceID);
		recalAttri(false);
		onManStarsUp(old_id, manID);
		_sign_auto();
		return res_sucess;
	}

	bool playerMan::HasNowTrain()
	{
		
		for (unsigned i = 0; i < cTrain.size(); ++i)
		{
			const MANDEF::trainPlayer& cT = cTrain[i];
			if (cT.nval > 0)return true;
		}
		return false;
	}

	bool playerMan::HasMaxTrain()
	{
		for (unsigned i = 0; i < cTrain.size(); ++i)
		{
			const MANDEF::trainPlayer& cT = cTrain[i];
			if (cT.mval > 0)return true;
		}
		return false;
	}

	void playerMan::ClearNowTrain()
	{
		for (unsigned i = 0; i < cTrain.size(); ++i)
		{
			MANDEF::trainPlayer& cT = cTrain[i];
			cT.nval = 0;
		}
		_sign_auto();
	}

	void playerMan::setNowTrain(const vector<int>& trains)
	{
		const unsigned length = trains.size();
		for (unsigned i = 0; i < cTrain.size(); ++i)
		{
			MANDEF::trainPlayer& cT = cTrain[i];
			if (i < length)
			{
				cT.nval = trains[i];
			}
			else
			{
				cT.nval = 0;
			}
		}
		_sign_auto();
	}

	int playerMan::ReplaceTrain()
	{
		if (!HasNowTrain())return err_illedge;
		qValue log_json(qJson::qj_array);
		int ct_val = 0, mt_val = 0;
		for (unsigned i = 0; i < cTrain.size(); ++i)
		{
			MANDEF::trainPlayer& cData = cTrain[i];
			cData.val = cData.nval;
			qValue sg_json(qJson::qj_array);
			sg_json.append(cData.idx).append(cData.val);
			log_json.append(sg_json);
			cData.nval = 0;
			ct_val += cData.val;
			mt_val += cData.mval;
		}
		if (ct_val >= mt_val)
		{
			for (unsigned i = 0; i < cTrain.size(); ++i)
			{
				MANDEF::trainPlayer& cData = cTrain[i];
				cData.mval = cData.val;
			}
		}
		recalAttri(false);
		_sign_auto();
		Log(DBLOG::strLogManDo, Own().getOwnDataPtr(), 5, log_json.toIndentString());
		return res_sucess;
	}

	int playerMan::RecoverTrain()
	{
		if (!HasMaxTrain())return err_illedge;
		qValue log_json(qJson::qj_array);
		bool the_same = true;
		for (unsigned i = 0; i < cTrain.size(); ++i)
		{
			MANDEF::trainPlayer& cData = cTrain[i];
			if (cData.val != cData.mval)
			{
				the_same = false;
				break;
			}
		}
		if (the_same)return err_illedge;
		for (unsigned i = 0; i < cTrain.size(); ++i)
		{
			MANDEF::trainPlayer& cData = cTrain[i];
			cData.val = cData.mval;
			qValue sg_json(qJson::qj_array);
			sg_json.append(cData.idx).append(cData.val);
			log_json.append(sg_json);
		}
		recalAttri();
		Log(DBLOG::strLogManDo, Own().getOwnDataPtr(), 6, log_json.toIndentString());
		_sign_auto();
		return res_sucess;
	}

	void playerMan::setLV_gm(const unsigned level)
	{
		if (level >= cfgExpSeq.size())
		{
			manLevel = cfgExpSeq.size();
			manExp = 0;
		}
		else
		{
			manLevel = level;
		}
	}

	void playerMan::setExp_gm(const unsigned exp)
	{
		manExp = exp;
	}

	void playerMan::setState_gm(const unsigned val_)
	{
		for (unsigned i = 0; i < starsAttriNum; ++i)
		{
			stateAttri |= (val_ & (0x0001 << i));
		}
	}

	void playerMan::setDone_gm()
	{
		int tmpLevel = manLevel;
		upgrade();
		if (manLevel >= cfgExpSeq.size())
		{
			manExp = 0;
		}
		if (manLevel > Own().LV())
		{
			manLevel = Own().LV();
		}
		recalAttri(false);
		_sign_auto();
	}

	cfgManPtr playerMan::getConfig()
	{
		if (!handlerCfg)
		{
			handlerCfg = man_sys.getConfig(manID);
		}
		return handlerCfg;
	}

	int playerMan::activeAttri(const unsigned idx)
	{
		cfgManPtr config = getConfig();
		if (!config || !config->upStars)return err_illedge;
		if (idx >= starsAttriNum)return err_illedge;
		if (stateAttri & (0x0001 << idx))	return err_man_has_active_attri;
		//sucess
		stateAttri |= (0x0001 << idx);
		recalAttri(false);
		_sign_auto();
		return res_sucess;
	}

	void playerMan::upgrade()
	{
		const unsigned player_lv = Own().LV();
		const unsigned old_level = manLevel;
		for (unsigned idx = manLevel; idx < cfgExpSeq.size(); ++idx)
		{
			if (idx > player_lv)break;
			if (manExp >= cfgExpSeq[idx])
			{
				manExp -= cfgExpSeq[idx];
				manLevel = idx + 1;
				continue;
			}
			break;
		}
		if (manLevel >= player_lv || manLevel >= cfgExpSeq.size())
		{
			manExp = 0;
		}
	}

	void playerMan::upgrade(unsigned& total_num)
	{
		const unsigned player_lv = Own().LV();
		const unsigned return_lv = std::max(manLevel, player_lv);
		manExp += total_num;
		const unsigned old_level = manLevel;
		for (unsigned idx = manLevel; idx < cfgExpSeq.size(); ++idx)
		{
			if (idx > player_lv)break;
			if (manExp >= cfgExpSeq[idx])
			{
				manExp -= cfgExpSeq[idx];
				manLevel = idx + 1;
				continue;
			}
			break;
		}
		if (manLevel >= player_lv || manLevel >= cfgExpSeq.size())
		{
			if (old_level >= manLevel)//�ȼ�û��
			{
				total_num = 0;
			}
			else
			{
				total_num -= manExp;
			}
			//if (manExp <= total_num)total_num -= manExp;
			const unsigned final_lv = std::min(return_lv, (unsigned)cfgExpSeq.size());
			manLevel = final_lv;
			manExp = 0;
		}
	}

	unsigned playerMan::numAddExp(const unsigned num)
	{
		if (manLevel >= cfgExpSeq.size())return 0;
		if (manLevel >= Own().LV())return 0;
		if (num < 1)return 0;
		unsigned tmpExp = num;
		int tmpLevel = manLevel;
		upgrade(tmpExp);
		const unsigned player_lv = Own().LV();
		if (tmpLevel != manLevel)
		{
			TaskMgr::update(Own().getOwnDataPtr(), Task::ManMaxLv);
			recalAttri(false);
		}
		_sign_auto();
		return tmpExp;
	}

	bool playerMan::isMaxLevel()
	{
		return (manLevel >= cfgExpSeq.size());
	}

	int playerMan::addExp(const unsigned num)
	{
		if (manLevel >= cfgExpSeq.size())return err_man_level_max;
		if (manLevel >= Own().LV())return err_over_player_level;
		if (num < 1)return err_illedge;
		int tmpLevel = manLevel;
		unsigned tmpExp = num;
		upgrade(tmpExp);
		const unsigned player_lv = Own().LV();
		if (tmpLevel != manLevel)
		{
			TaskMgr::update(Own().getOwnDataPtr(), Task::ManMaxLv);
			Log(DBLOG::strLogManDo, Own().getOwnDataPtr(), 0, manID, tmpLevel, manLevel, num);
			recalAttri(false);
		}
		_sign_auto();
		return res_sucess;
	}

	void playerMan::_auto_update()
	{
		qValue data_json(qJson::qj_array);
		data_json.append(res_update_man);
		data_json.append(jsonPackage());
		Own().sendToClientFillMsg(gate_client::player_man_update_resp, data_json);
	}

	bool playerMan::_auto_save()
	{
		mongo::BSONObj key = BSON(strPlayerID << Own().ID() << "rid" << ID());
		mongo::BSONArrayBuilder arr, arr_train;
		for (unsigned i = 0; i < equipList.size(); ++i)
		{
			if (equipList[i])arr << equipList[i]->ID();
			else arr << -1;
		}
		for (unsigned i = 0; i < cTrain.size(); ++i)
		{
			const MANDEF::trainPlayer& cData = cTrain[i];
			arr_train << BSON_ARRAY(cData.val << cData.nval << cData.mval);
		}
		mongo::BSONObj obj = BSON(strPlayerID << Own().ID() << "rid" << ID() <<
			"mid" << manID << "lv" << manLevel << "exp" << manExp << "st" << stateAttri
			<< "eq" << arr.arr() << "tpm" << arr_train.arr());
		return db_mgr.SaveMongo(DBN::dbPlayerMan, key, obj);
	}

	void playerManMgr::initData()
	{
		{//�����
			cfgExpSeq.clear();
			Json::Value json = Common::loadJsonFile("./instance/manconfig/exp.json");
			for (unsigned i = 0; i < json.size(); ++i)
			{
				unsigned ug_exp = json[i].asUInt();
				ug_exp = ug_exp < 1 ? 1 : ug_exp;
				cfgExpSeq.push_back(ug_exp);
			}
		};

		{//�佫ս������������
			BVAttriCal.clear();
			Json::Value json = Common::loadJsonFile("./instance/manconfig/battle_value.json");
			for (unsigned i = 0; i < json.size(); ++i)
			{
				Json::Value& sg_json = json[i];
				const int armsType = sg_json["type"].asInt();
				const int rateLV = sg_json["rate"].asInt();
				BVAttriLVCal[armsType] = rateLV;
				vector<double> tmp;
				for (unsigned idx = 0; idx < characterNum; ++idx)
				{
					tmp.push_back(sg_json["arr"][idx].asDouble());
				}
				BVAttriCal[armsType] = tmp;
			}
		};
	}

	//////////////////////////////////////////////////////////////////////////
	//mgr
	playerManMgr::playerManMgr(playerData* const own) :_auto_player(own),
		CDFly(8 * HOUR), _starUpTimes(0)
	{
		mapMan.clear();
		ownUpdate = false;
	}

	Json::Value playerManMgr::gmPackage()
	{
		Json::Value json = Json::arrayValue;
		for (ManMap::iterator it = mapMan.begin(); it != mapMan.end(); ++it)
		{
			playerManPtr ptr = it->second;
			if (!ptr)continue;
			Json::Value sg_json;
			sg_json.append(ptr->mID());
			sg_json.append(ptr->LV());
			sg_json.append(ptr->EXP());
			sg_json.append(ptr->activeState());
			json.append(sg_json);
		}
		return json;
	}

	void playerManMgr::updateAll()
	{
		qValue data_list(qJson::qj_array), data_men(qJson::qj_array);
		unsigned num = 0;
		for (ManMap::iterator it = mapMan.begin(); it != mapMan.end();)
		{
			playerManPtr man = it->second;
			++it;
			if (!man)continue;
			++num;
			data_men.append(man->jsonPackage());
			if (num > 49 || it == mapMan.end())
			{
				data_list.append(res_update_man);
				data_list.append(data_men);
				num = 0;
				Own().sendToClientFillMsg(gate_client::player_man_update_resp, data_list);
				data_list.toArray();
				data_men.toArray();
			}
		}
	}

	void playerManMgr::_auto_update()
	{
		do
		{
			if (listUdpate.empty())break;
			qValue data_list(qJson::qj_array), data_men(qJson::qj_array);
			unsigned num = 0;
			for (updateList::iterator it = listUdpate.begin(); it != listUdpate.end();)
			{
				playerManPtr man = findMan(*it);
				++it;
				if (!man)continue;
				++num;
				data_men.append(man->jsonPackage());
				if (num > 49 || it == listUdpate.end())
				{
					data_list.append(res_update_man);
					data_list.append(data_men);
					num = 0;
					Own().sendToClientFillMsg(gate_client::player_man_update_resp, data_list);
					data_list.toArray();
					data_men.toArray();
				}
			}
			listUdpate.clear();
		} while (false);

		{//CD����
			if (ownUpdate)
			{
				ownUpdate = false;
				Json::Value json;
				json[strMsg][0u] = res_sucess;
				json[strMsg][1u] = CDFly.CD();
				json[strMsg][2u] = CDFly.Lock();
				Own().sendToClient(gate_client::player_man_fly_update_resp, json);
			}
		};//
	}

	void playerManMgr::updateFlyCD()
	{
		Json::Value json;
		json[strMsg][0u] = res_sucess;
		json[strMsg][1u] = CDFly.CD();
		json[strMsg][2u] = CDFly.Lock();
		Own().sendToClient(gate_client::player_man_fly_update_resp, json);
	}

	void playerManMgr::clearFlyCD()
	{
		CDFly.Clear();
		ownUpdate = true;
		_sign_auto();
	}

	void playerManMgr::addFlyCD(const unsigned cd)
	{
		CDFly.AddCD(cd);
		ownUpdate = true;
		_sign_auto();
	}

	bool playerManMgr::_auto_save()
	{
		mongo::BSONObj key = BSON(strPlayerID << Own().ID());
		mongo::BSONObj obj = BSON(strPlayerID << Own().ID() << "fcd" << CDFly.CD() << "fl" << CDFly.Lock()
			<< "sut" << _starUpTimes);
		return db_mgr.SaveMongo(DBN::dbPlayerManInfo, key, obj);
	}

	int playerManMgr::addMan(const int manID)
	{
		return addMan(man_sys.getConfig(manID));
	}

	int playerManMgr::addMan(const cfgManPtr config)
	{
		if (!config)return err_man_no_config;
		playerManPtr old_man = findMan(config->manID);
		if (!old_man)//û���佫
		{
			playerManPtr man = Creator<playerMan>::Create(config, _Own);
			mapMan[config->manID / 100] = man;
			man->recalAttri(false, false);
			if (config)
			{
				Own().Face().insertFace(config->faceID);
			}
			man->_sign_auto();
			TaskMgr::update(Own().getOwnDataPtr(), Task::ManNum);
			TaskMgr::update(Own().getOwnDataPtr(), Task::ManNumOfColor);
			TaskMgr::update(Own().getOwnDataPtr(), Task::ManSpecified);
			Log(DBLOG::strLogManDo, Own().getOwnDataPtr(), 7, config->manID);
			return res_sucess;
		}
		if (old_man->mID() >= config->manID)return err_man_has_hold;//�Ѿ�ӵ���佫
		const int old_id = old_man->mID();
		old_man->manID = config->manID;
		old_man->stateAttri = 0;
		old_man->handlerCfg = config;
		old_man->recalAttri(false);
		old_man->onManStarsUp(old_id, config->manID);
		old_man->_sign_auto();
		{
			//����
			TaskMgr::update(Own().getOwnDataPtr(), Task::ManNum);
			TaskMgr::update(Own().getOwnDataPtr(), Task::ManNumOfColor);
			TaskMgr::update(Own().getOwnDataPtr(), Task::ManSpecified);
		}
		Log(DBLOG::strLogManDo, Own().getOwnDataPtr(), 7, config->manID);
		return res_sucess;
	}

	int playerManMgr::getManCount()
	{
		return (int)mapMan.size();
	}

	int playerManMgr::getManCountByQuality(int iManQuality)
	{
		int iCount = 0;
		for (ManMap::iterator it = mapMan.begin(); it != mapMan.end(); ++it)
		{
			playerManPtr man = it->second;
			//LogI << man->getConfig()->manID << "==>" << man->getConfig()->manQuality << LogEnd;
			if (man->getConfig()->manQuality < iManQuality) { continue; }
			iCount++;
		}
		return iCount;
	}

	void playerManMgr::recalMan(const bool update /* = true */, const bool initial /* = false */)
	{
		for (ManMap::iterator it = mapMan.begin(); it != mapMan.end(); ++it)
		{
			playerManPtr man = it->second;
			if (initial)
			{
				man->recalAttri(update, 0);
			}
			else
			{
				man->recalAttri(update, ~MANDEF::war_format);
			}
		}
		Own().WarFM().recalFMValue(update, initial);
	}

	void playerManMgr::recalArmsMan(const int armsType, const bool update /* = true */, const bool initial /* = false */)
	{
		for (ManMap::iterator it = mapMan.begin(); it != mapMan.end(); ++it)
		{
			playerManPtr man = it->second;
			cfgManPtr config = man->getConfig();
			if (!config || config->armsType != armsType)continue;
			if (initial)
			{
				man->recalAttri(update, 0);
			}
			else
			{
				man->recalAttri(update, ~MANDEF::war_format);
			}
		}
		Own().WarFM().recalFMValue(update, initial);
	}

	void playerManMgr::classLoad()
	{
		{//�佫����
			mapMan.clear();
			mongo::BSONObj key = BSON(strPlayerID << Own().ID());
			objCollection collection = db_mgr.Query(DBN::dbPlayerMan, key);
			if (collection.empty())return;
			for (unsigned i = 0; i < collection.size(); ++i)
			{
				mongo::BSONObj cObj = collection[i];
				const int manID = cObj["mid"].Int();
				cfgManPtr config = man_sys.getConfig(manID);
				if (!config)continue;
				playerManPtr man = Creator<playerMan>::Create(config, _Own);
				man->manID = manID;
				man->manLevel = (unsigned)cObj["lv"].Int();
				man->manExp = (unsigned)cObj["exp"].Int();
				if (!cObj["st"].eoo()){ man->stateAttri = (unsigned)cObj["st"].Int(); }
				if (!cObj["eq"].eoo())
				{
					vector<mongo::BSONElement> elems = cObj["eq"].Array();
					for (unsigned pos = 0; pos < elems.size() && pos < man->equipList.size(); ++pos)
					{
						man->equipList[pos] = Own().Items().getLocalItem(elems[pos].Int());
						if (man->equipList[pos])
						{
							man->equipList[pos]->setPos(itemDef::pos_man);
							man->equipList[pos]->setHandler(man->mID());
						}
					}
				}
				if (!cObj["tpm"].eoo())
				{
					vector<mongo::BSONElement> elems = cObj["tpm"].Array();
					vector<MANDEF::trainPlayer>& cTrain = man->cTrain;
					for (unsigned idx = 0; idx < elems.size() && idx < cTrain.size(); ++idx)
					{
						vector<mongo::BSONElement> val_list = elems[idx].Array();
						MANDEF::trainPlayer& cData = cTrain[idx];
						const unsigned data_length = val_list.size();
						if (data_length > 0)cData.val = val_list[0].Int();
						if (data_length > 1)cData.nval = val_list[1].Int();
						if (data_length > 2)cData.mval = val_list[2].Int();
					}
				}
				Own().Face().insertFace(config->faceID);
				mapMan[man->ID()] = man;
			}
		};

		{//������CD����������
			mongo::BSONObj key = BSON(strPlayerID << Own().ID());
			mongo::BSONObj obj = db_mgr.FindOne(DBN::dbPlayerManInfo, key);
			if (!obj.isEmpty())
			{
				CDFly = obj["fcd"].Int();
				CDFly = obj["fl"].Bool();
				checkNotEoo(obj["sut"])
					_starUpTimes = obj["sut"].Int();
			}
		};
	}

	void playerManMgr::classFinal()
	{
		for (ManMap::iterator it = mapMan.begin(); it != mapMan.end(); ++it)
		{
			playerManPtr man = it->second;
			man->recalAttri(false, 0);
		}
	}

	void playerManMgr::updateMan(const int manID)
	{
		listUdpate.insert(manID);
		_sign_update();
	}

	playerManPtr playerManMgr::findMan(const int manID)
	{
		return findManRaw(manID / 100);
	}

	int playerManMgr::findManByDuty(const int manDuty)
	{
		for (ManMap::iterator itr = mapMan.begin(); itr != mapMan.end(); ++itr)
		{
			playerManPtr playerManPtr_ptr = itr->second;
			if (playerManPtr_ptr->getConfig()->manDuty != manDuty) { continue; }
			return playerManPtr_ptr->getConfig()->manID;
		}
		return 0;
	}

	playerManPtr playerManMgr::findManRaw(const int rawID)
	{
		ManMap::iterator it = mapMan.find(rawID);
		if (it == mapMan.end())return playerManPtr();
		return it->second;
	}

	int playerManMgr::getManMaxLv()
	{
		int max = 0;
		for (ManMap::iterator it = mapMan.begin(); it != mapMan.end(); ++it)
		{
			playerManPtr man = it->second;
			if (man->LV() > max)
				max = man->LV();
		}
		return max;
	}

	int playerManMgr::equipExchange(const int manID_1, const int manID_2)
	{
		playerManPtr man_1 = findMan(manID_1);
		playerManPtr man_2 = findMan(manID_2);
		if (!man_1 || !man_2)return err_illedge;
		cfgManPtr man1_config = man_1->getConfig();
		cfgManPtr man2_config = man_2->getConfig();
		if (!man1_config || !man2_config)return err_illedge;
		std::vector<itemPtr>& eq1 = man_1->equipList;
		std::vector<itemPtr>& eq2 = man_2->equipList;

		bool change = false;
		for (unsigned i = 0; i < equipHoleSize; i++)
		{
			itemPtr item1 = eq1[i];
			itemPtr item2 = eq2[i];
			if (item1)
			{
				cfgItemPtr item1_config = item1->getConfig();
				const unsigned limit = item1_config->_declare._equip.equipLimit;
				if ((limit & man2_config->manType) == 0)continue;
			}
			if (item2)
			{
				cfgItemPtr item2_config = item2->getConfig();
				const unsigned limit = item2_config->_declare._equip.equipLimit;
				if ((limit & man1_config->manType) == 0)continue;
			}
			change = true;
			eq1[i] = item2;
			eq2[i] = item1;
			if (item1)
			{
				item1->setHandler(man_2->mID());
			}
			if (item2)
			{
				item2->setHandler(man_1->mID());
			}
		}
		if (change)
		{
			man_1->recalAttri();
			man_2->recalAttri();
			man_1->_sign_auto();
			man_2->_sign_auto();
		}
		return res_sucess;
	}

	void playerManMgr::tickStarUp()
	{
		++_starUpTimes;
		TaskMgr::update(Own().getOwnDataPtr(), Task::AdvanceAllTimes);
		_sign_save();
	}

}

#include "player_activity_rank.h"
#include "dbDriver.h"
#include "activity_rank_system.h"
#include "email_system.h"

namespace gg
{
	playerActivityRank::playerActivityRank(playerData* const own) : _auto_player(own)
	{
		for (int i = 0; i < ActivityRankEnum::activity_rank_num; ++i)
		{
			_data_list[i] = Data();
		}
	}

	void playerActivityRank::update_all()
	{
		for (int i = 0; i < ActivityRankEnum::activity_rank_num; ++i)
		{
			send_type_data(i);
		}
	}

	void playerActivityRank::check_process()
	{
		Data& battle_rank_data = _data_list[ActivityRankEnum::activity_battle_rank];
		if (
			0 == battle_rank_data._create &&
			activity_rank_sys.isOpen(ActivityRankEnum::activity_battle_rank)
			)
		{
			battle_rank_data._value = Own().Info().MaxBV();
			battle_rank_data._create = activity_rank_sys.createID(ActivityRankEnum::activity_battle_rank);
			battle_rank_data._box.clear();
			battle_rank_data._is_dirty = true;
			_sign_auto();
		}
		over_box();
		for (int i = 0; i < ActivityRankEnum::activity_rank_num; ++i)
		{
			Data& data = _data_list[i];
			if (activity_rank_sys.isClose(i, data._create))
			{
				data.reset();
				_sign_auto();
			}
		}
	}

	void playerActivityRank::send_type_data(const int type)
	{
		if (type < 0 || type >= ActivityRankEnum::activity_rank_num)return;
		const Data& data = _data_list[type];
		qValue box_json(qJson::qj_array);
		for (Data::_box_filter_type::const_iterator it = data._box.begin(); it != data._box.end(); ++it)
		{
			box_json.append(*it);
		}
		qValue json(qJson::qj_array);
		json.append(res_sucess).
			append(type).
			append(data._value).
			append(box_json);
		//send
		Own().sendToClientFillMsg(gate_client::player_activity_rank_info_update_resp, json);
	}

	int playerActivityRank::get_reach_box(const int type, const int reach)
	{
		if (type < 0 || type >= ActivityRankEnum::activity_rank_num)return err_illedge;
		Data& data = _data_list[type];
		if (activity_rank_sys.isOver(type, data._create))return err_illedge;
		if (!activity_rank_sys.isRun(type))return err_illedge;
		if (data._box.find(reach) != data._box.end())return err_illedge;
		if (data._value < reach)return err_illedge;
		ActionBoxList box_list_;
		if (false == activity_rank_sys.findActionBox(box_list_, type, reach))return err_illedge;
		const int res = actionDoBox(Own().getOwnDataPtr(), box_list_, false);
		if (res != res_sucess)return err_bag_full;
		data._box.insert(reach);
		data._is_dirty = true;
		_sign_auto();
		return res;
	}

	void playerActivityRank::over_box()
	{
		for (int i = 0; i < ActivityRankEnum::activity_rank_num; ++i)
		{
			over_box_type(i);
		}
	}

	void playerActivityRank::over_box_type(const int type)
	{
		if (type < 0 || type >= ActivityRankEnum::activity_rank_num)return;
		Data& data = _data_list[type];
		if (false == data._been_clean &&
			activity_rank_sys.isOver(type, data._create))//������ͽ���,�����������
		{
			Json::Value package_box = activity_rank_sys.packageOverBox(type, data._create, data._value, data._box);
			if (package_box.size() > 0)
			{
				//�����ʼ�
				Json::Value param_json;
				param_json.append(type);
				EmailPtr email_ptr = email_sys.createPackage(EmailDef::ActivityRankReachBoxPay, param_json, package_box);
				email_sys.sendToPlayer(Own().ID(), email_ptr);
			}
			data._been_clean = true;
			data._is_dirty = true;
			_sign_auto();
		}
	}

	int playerActivityRank::get_value(const int type)
	{
		if (type < 0 || type >= ActivityRankEnum::activity_rank_num)return 0;
		return _data_list[type]._value;
	}

	void playerActivityRank::add_process(const int type, const int value)
	{
		if (value < 1)return;
		if (type == ActivityRankEnum::activity_battle_rank)
		{
			if (activity_rank_sys.isOpen(type))
			{
				const int create_id = activity_rank_sys.createID(type);
				Data& data = _data_list[type];
				over_box_type(type);
				const int old_val = data._value;
				data._value += value;//֪ͨˢ�����а�
				data._create = create_id;
				data._is_dirty = true;
				activity_rank_sys.insertRank(type, Own().getOwnDataPtr());
				_sign_auto();
			}
		}
		else if (activity_rank_sys.isRun(type))
		{
			const int create_id = activity_rank_sys.createID(type);
			Data& data = _data_list[type];
			over_box_type(type);
			const int old_val = data._value;
			data._value += value;//֪ͨˢ�����а�
			data._create = create_id;
			data._is_dirty = true;
			activity_rank_sys.insertRank(type, Own().getOwnDataPtr());
			_sign_auto();
		}
	}

	void playerActivityRank::set_process(const int type, const int value)
	{
		if (type == ActivityRankEnum::activity_battle_rank)
		{
			if (activity_rank_sys.isOpen(type))
			{
				Data& data = _data_list[type];
				const int create_id = activity_rank_sys.createID(type);
				if (value < data._value)return;
				over_box_type(type);
				const int old_val = data._value;
				data._value = value;//֪ͨˢ�����а�
				data._create = create_id;
				data._is_dirty = true;
				activity_rank_sys.insertRank(type, Own().getOwnDataPtr());
				_sign_auto();
			}
		}
		else if (activity_rank_sys.isRun(type))
		{
			Data& data = _data_list[type];
			const int create_id = activity_rank_sys.createID(type);
			if (value < data._value)return;
			over_box_type(type);
			const int old_val = data._value;
			data._value = value;//֪ͨˢ�����а�
			data._create = create_id;
			data._is_dirty = true;
			activity_rank_sys.insertRank(type, Own().getOwnDataPtr());
			_sign_auto();
		}
	}

	void playerActivityRank::classLoad()
	{
		mongo::BSONObj key = BSON(strPlayerID << Own().ID());
		objCollection objs = db_mgr.Query(DBN::dbPlayerActivityRank, key);
		for (unsigned i = 0 ; i < objs.size(); ++i)
		{
			mongo::BSONObj& obj = objs[i];
			const int type_ = obj["t"].Int();
			Data& data = _data_list[type_];
			data._create = obj["ct"].Int();
			data._value = obj["vl"].Int();
			data._been_clean = obj["bcl"].eoo() ? false : obj["bcl"].Bool();
			std::vector<mongo::BSONElement> boxes = obj["fl"].Array();
			for (unsigned n = 0; n < boxes.size(); ++n)
			{
				mongo::BSONElement& elem = boxes[n];
				data._box.insert(elem.Int());
			}
		}
	}

	void playerActivityRank::classFinal()
	{

	}

	bool playerActivityRank::_auto_save()
	{
		for (int i = 0; i < ActivityRankEnum::activity_rank_num; ++i)
		{
			Data& data = _data_list[i];
			if (data._is_dirty)
			{
				data._is_dirty = false;
				mongo::BSONObj key = BSON(strPlayerID << Own().ID() << "t" << i);
				mongo::BSONArrayBuilder arr;
				for (Data::_box_filter_type::iterator it = data._box.begin(); it != data._box.end(); ++it)
				{
					arr << *it;
				}
				mongo::BSONObj obj = BSON(strPlayerID << Own().ID() << "t" << i << "ct" <<
					data._create << "vl" << data._value << "fl" << arr.arr() << "bcl" << 
					data._been_clean
				);
				db_mgr.SaveMongo(DBN::dbPlayerActivityRank, key, obj);
			}
		}
		return true;
	}

	void playerActivityRank::_auto_update()
	{
		for (int i = 0; i < ActivityRankEnum::activity_rank_num; ++i)
		{
			Data& data = _data_list[i];
			if (data._is_dirty)
			{
				send_type_data(i);
			}
		}
	}
}
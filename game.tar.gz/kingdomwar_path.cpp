#include "kingdomwar_path.h"
#include "kingdomwar_system.h"
#include "kingdom_def.h"

namespace gg
{
	namespace KingdomWar
	{
		enum
		{
			DefSpeed = 10,
			
			// 
			Enter = 0,
			Leave,
			Defeated,
			HpEmpty,
			Transfer,
		};

		PathReportData::PathReportData(unsigned cur_time, PItemPtr& atk, PItemPtr& def)
		{
			time = cur_time;
			atk_ptr = atk->getBattlePtr();
			def_ptr = def->getBattlePtr();
		}

		void PathReportData::one2one()
		{
			result = data.One2One(atk_ptr, def_ptr, typeBattle::kingdomwar);
		}

		void PathReportData::done()
		{
			data.Done(typeBattle::kingdomwar);
		}

		PathItemPlayer::PathItemPlayer(unsigned time, int side, playerDataPtr d, int army_id, PathPtr& ptr)
			: PathItemBase(time, side, d->Info().Nation(), ptr)
		{
			_pid = d->ID();
			_army_id = army_id;
			_name = d->Name();
			_title = d->KingFight().getTitle();
			_face = d->KingDomWarFM().face(_army_id);
			d->KingDomWarPos().setPosition(army_id, PosPath, ptr->id(), time, JARRAY((int)TIPS::NONE));
		}

		void PathItemPlayer::getInfo(qValue& q) const
		{
			q.append((int)Player);
			q.append(_pid);
			q.append(_army_id);
			q.append(nation());
			q.append(startTime());
			q.append(distance());
			q.append(_title);
		}

		void PathItemPlayer::getUpInfo(qValue& q, int type) const
		{
			q.append(type);
			q.append((int)Player);
			q.append(_pid);
			q.append(_army_id);
			if (type == Enter)
			{
				q.append(nation());
				q.append(startTime());
				q.append(distance());
				q.append(_title);
			}
		}

		sBattlePtr PathItemPlayer::getBattlePtr()
		{
			playerDataPtr d = player_mgr.getPlayer(_pid);
			if (!d) return sBattlePtr();
			return kingdomwar_sys.getBattlePtr(d, _army_id);
		}

		void PathItemPlayer::doneBattle(PathReportData& rep_data, PItemPtr& target, bool atk_side)
		{
			playerDataPtr d = player_mgr.getPlayer(_pid);

			// result
			int result = repResult(rep_data.result.res, atk_side);
			int star = rep_data.result.star;

			// exploit
			int exploit = result == Win?
				kingdomwar_sys.winExploit(star) : kingdomwar_sys.loseExploit(star);
			playerKingdomWar::ExploitReason = KingdomWar::Battle;
			d->Res().alterExploit(exploit);

			// hp
			int hp_cost = result == Win?
				kingdomwar_sys.winHpCost(star) : kingdomwar_sys.loseHpCost(star);
			hp_cost = d->KingDomWar().alterArmyHp(_army_id, 0 - hp_cost);

			// man hp
			resetHp(atk_side? rep_data.atk_ptr : rep_data.def_ptr);

			// silver
			int silver = kingdomwar_sys.battleSilver(d, result);
			silver = d->Res().alterSilver(silver);

			// rep
			int pos = PosPath;
			int tips = repTips(result, d, _army_id);
			std::string rep_id = d->KingDomWar().getReportID();
			qValue rep;
			rep << (int)REP::BATTLE << rep_data.time << _path->getOtherSideId(side()) << _army_id << _face 
				<< target->name() << target->nation() << target->type() << pos << result 
				<< exploit << tips << hp_cost << silver << rep_id;
			d->KingDomWar().addReport(rep, result, pos, _army_id);
			std::string rpath = "kingdomwar/" + Common::toString(d->ID()) + "/" + rep_id;
			rep_data.data.addCopyField(rpath);
			if (rep_data.path == "")
				rep_data.path = rpath;
			
			// 
			qValue rw;
			if (exploit > 0)
			{
				qValue tmp;
				tmp.append(ACTION::exploit_coin);
				tmp.append(exploit);
				rw.append(tmp);
			}
			if (silver > 0)
			{
				qValue tmp;
				tmp.append(ACTION::silver);
				tmp.append(silver);
				rw.append(tmp);
			}
			rep_data.data.addReportdeclare(atk_side? "rwa" : "rwb", rw);
			rep_data.data.addReportdeclare(atk_side? "aty" : "dty", Player);

			if (result == Lose || isDead())
			{
				if (result == Lose)
					beDead(rep_data.time, JARRAY((int)TIPS::DEFEATED << -1));
				else
					beDead(rep_data.time, JARRAY((int)TIPS::HPEMPTY << -1));
			}
		}

		bool PathItemPlayer::isDead()
		{
			playerDataPtr d = player_mgr.getPlayer(_pid);
			if (!d) return true;
			return d->KingDomWar().isDead(_army_id);
		}

		void PathItemPlayer::resetHp(sBattlePtr& ptr)
		{
			playerDataPtr d = player_mgr.getPlayer(_pid);
			if (!d) return;
			manList& ml = ptr->battleMan;
			for (unsigned i = 0; i < ml.size(); ++i)
			{
				if (!ml[i])
					continue;
				d->KingDomWar().setManHp(ml[i]->manID, ml[i]->currentHP);
			}
		}

		void PathItemPlayer::arrive(unsigned time, int id)
		{
			playerDataPtr d = player_mgr.getPlayer(_pid);
			if (!d) return;
			CityPtr ptr = CityMgr::shared().getCity(id);
			ptr->enter(time, d, _army_id, JARRAY((int)TIPS::NONE));
		}

		void PathItemPlayer::beDead(unsigned time, Json::Value& tips)
		{
			playerDataPtr d = player_mgr.getPlayer(_pid);
			if (!d) return;
			kingdomwar_sys.goBackMainCity(time, d, _army_id, tips);
		}

		PathItemNpc::PathItemNpc(unsigned time, int side, NpcDataPtr d, PathPtr& ptr)
			: PathItemBase(time, side, d->nation(), ptr), _npc_data(d)
		{
			d->setPosition(PosPath, ptr->id(), time);
		}

		void PathItemNpc::getInfo(qValue& q) const
		{
			q.append(_npc_data->type());
			q.append(_npc_data->id());
			q.append(0);
			q.append(nation());
			q.append(startTime());
			q.append(distance());
			q.append((int)Kingdom::None);
		}

		void PathItemNpc::getUpInfo(qValue& q, int type) const
		{
			q.append(type);
			q.append(_npc_data->type());
			q.append(_npc_data->id());
			q.append(0);
			if (type == Enter)
			{
				q.append(nation());
				q.append(startTime());
				q.append(distance());
				q.append((int)Kingdom::None);
			}
		}

		sBattlePtr PathItemNpc::getBattlePtr()
		{
			return _npc_data->getBattlePtr();
		}

		void PathItemNpc::doneBattle(PathReportData& rep_data, PItemPtr& target, bool atk_side)
		{
			// result
			int result = repResult(rep_data.result.res, atk_side);
			int star = rep_data.result.star;

			// hp
			int hp_cost = result == Win?
				kingdomwar_sys.winHpCost(star) : kingdomwar_sys.loseHpCost(star);
			hp_cost = _npc_data->alterHp(0 - hp_cost);
			
			// man_hp
			_npc_data->resetManHp(atk_side? rep_data.atk_ptr : rep_data.def_ptr);

			qValue rw;
			rep_data.data.addReportdeclare(atk_side? "rwa" : "rwb", rw);
			rep_data.data.addReportdeclare(atk_side? "aty" : "dty", _npc_data->type());

			if (result == Lose || isDead())
			{
				if (result == Lose)
					beDead(rep_data.time, JARRAY((int)TIPS::DEFEATED << -1));
				else
					beDead(rep_data.time, JARRAY((int)TIPS::HPEMPTY << -1));
			}
		}

		void PathItemNpc::arrive(unsigned time, int id)
		{
			CityPtr ptr = CityMgr::shared().getCity(id);
			ptr->enter(time, _npc_data);
		}

		void PathItemNpc::beDead(unsigned time, Json::Value& tips) 
		{
			_npc_data->setDead(time, tips);
		}

		bool PathItemSorter::getMin(PLIter& iter)
		{
			if (_sort_list.empty())
				return false;
			iter = _sort_list.begin()->target;
			return true;
		}

		inline void PathItemSorter::push(const PLIter& iter)
		{
			_sort_list.insert(SortItem(iter));
		}

		void PathItemSorter::pop(const PLIter& iter)
		{
			typedef SortList::iterator SortIter;
			SortItem target(iter);
			std::pair<SortIter, SortIter> pair_iter = _sort_list.equal_range(target);
			SortIter item = pair_iter.first;
			for(; item != pair_iter.second; ++item)
			{
				if (*item == target)
				{
					_sort_list.erase(item);
					break;
				}
			}
		}

		PathItemMgr::PathItemMgr(const int& path_id)
			: _path_id(path_id), _distance(-1)
		{
			_item_list = getInitedPathItemList();
			_left_end = _item_list.begin();
			_right_end = ++_item_list.begin();
			_rate = kingdomwar_sys.speedRate();
		}

		void PathItemMgr::setPathType(int side, int path_type, int cost_time)
		{
			_type[side] = path_type;
			if (_distance == -1)
			{
				_distance = DefSpeed * cost_time;
				_speed[side] = DefSpeed;
			}
			else
			{
				_speed[side] = divide32(_distance, cost_time);
			}
		}

		PathItemList PathItemMgr::getInitedPathItemList()
		{
			PathItemList p;
			p.push_back(PItemPtr());
			p.push_back(PItemPtr());
			return p;
		}

		bool PathItemMgr::empty() const
		{
			return _item_list.size() < 3;
		}

		void PathItemMgr::getMainInfo(qValue& q) const
		{
			if (empty())
				return;
			q.append(_path_id);
			qValue lhs;
			qValue rhs;
			PLIter iter = _left_end;
			++iter;
			for (; iter != _right_end; ++iter)
			{
				qValue tmp;
				(*iter)->getInfo(tmp);
				if ((*iter)->side() == Left)
					lhs.append(tmp);
				else
					rhs.append(tmp);
			}
			q.append(lhs);
			q.append(rhs);
		}

		void PathItemMgr::getUpdateInfo(qValue& q) const
		{
			if (_updates.empty())
				return;
			q.append(_path_id);
			qValue lhs;
			qValue rhs;
			ForEachC(UpdateItems, it, _updates)
			{
				qValue tmp;
				it->getInfo(tmp);
				if (it->side() == Left)
					lhs.append(tmp);
				else
					rhs.append(tmp);
			}
			q.append(lhs);
			q.append(rhs);
			_updates.clear();
		}

		void PathItemMgr::push(const PItemPtr& item)
		{
			PLIter iter;
			if (item->side() == Left)
			{
				iter = _left_end;
				++iter;
			}
			else
				iter = _right_end;

			iter = _item_list.insert(iter, item);
			PLIter n_iter = getNext(iter);
			int trigger_time = getTriggerTime(iter, n_iter);
			setTriggerTime(iter, trigger_time);
			if (n_iter != _left_end && 
				n_iter != _right_end &&
				(*n_iter)->side() != (*iter)->side())
				setTriggerTime(n_iter, trigger_time);

			_updates.push_back(PathUpdateItem(Enter, item));
		}

		void PathItemMgr::pop(const PLIter& iter, int type)
		{
			_sorter.pop(iter);
			PLIter l_iter = iter;
			--l_iter;
			PLIter r_iter = iter;
			++r_iter;
			_updates.push_back(PathUpdateItem(type, *iter));
			_item_list.erase(iter);
			if (l_iter != _left_end && (*l_iter)->side() == Left)
				setTriggerTime(l_iter, getTriggerTime(l_iter, r_iter));
			if (r_iter != _right_end && (*r_iter)->side() == Right)
				setTriggerTime(r_iter, getTriggerTime(r_iter, l_iter));
		}

		void PathItemMgr::addTips(const PLIter& iter, int type)
		{
			_updates.push_back(PathUpdateItem(type, *iter));
		}

		void PathItemMgr::swap(PLIter& lhs, PLIter& rhs)
		{
			if ((*lhs)->triggerTime() != 0)
			{
				_sorter.pop(lhs);
				(*lhs)->setTriggerTime(0);
			}
			if ((*rhs)->triggerTime() != 0)
			{
				_sorter.pop(rhs);
				(*rhs)->setTriggerTime(0);
			}
			PItemPtr ptr = *lhs;
			*lhs = *rhs;
			*rhs = ptr;
			PLIter iter = lhs;
			--iter;
			if (iter != _left_end && (*iter)->side() == Left)
				setTriggerTime(iter, getTriggerTime(iter, lhs));
			setTriggerTime(lhs, getTriggerTime(lhs, iter));
			iter = rhs;
			++iter;
			setTriggerTime(rhs, getTriggerTime(rhs, iter));
			if (iter != _right_end && (*iter)->side() == Right)
				setTriggerTime(iter, getTriggerTime(iter, rhs));
		}

		bool PathItemMgr::getMin(PLIter& iter)
		{
			return _sorter.getMin(iter);
		}

		void PathItemMgr::run(const Handler& h)
		{
			PLIter iter = _left_end;
			++iter;
			for(; iter != _right_end; ++iter)
				h(*iter);
		}

		void PathItemMgr::clear(unsigned cur_time)
		{
			PLIter iter = _left_end;
			++iter;
			for(; iter != _right_end; ++iter)
				(*iter)->beDead(cur_time, JARRAY((int)TIPS::UNITY << -1));
			_updates.clear();
			_sorter.clear();
			_item_list = getInitedPathItemList();
			_left_end = _item_list.begin();
			_right_end = ++_item_list.begin();
		}

		void PathItemMgr::reset(unsigned cur_time)
		{
			if (_rate != kingdomwar_sys.speedRate())
			{
				_updates.clear();

				PLIter it = _left_end;
				++it;
				for (; it != _right_end; ++it)
				{
					int distance = (cur_time - (*it)->startTime()) * _speed[(*it)->side()] * _rate + (*it)->distance();
					(*it)->setDistance(distance > _distance? _distance : distance);
					(*it)->setStartTime(cur_time);
				}

				_rate = kingdomwar_sys.speedRate();

				it = _left_end;
				++it;
				for (; it != _right_end; ++it)
					setTriggerTime(it, getTriggerTime(it, getNext(it)));
			}
		}

		PLIter PathItemMgr::getNext(const PLIter& iter)
		{
			PLIter temp = iter;
			return (*temp)->side() == Left? ++temp : --temp;
		}

		int PathItemMgr::getTriggerTime(const PLIter& lhs, const PLIter& rhs)
		{
			if (rhs == _left_end || rhs == _right_end)
				return (*lhs)->startTime() + divide32(_distance - (*lhs)->distance(), _speed[(*lhs)->side()] * _rate);

			if ((*lhs)->side() == (*rhs)->side())
				return 0;

			int left_speed = _speed[(*lhs)->side()] * _rate;
			int right_speed = _speed[(*rhs)->side()] * _rate;
			unsigned max_time = (*lhs)->startTime() > (*rhs)->startTime() ? (*lhs)->startTime() : (*rhs)->startTime();
			unsigned min_time = (*lhs)->startTime() > (*rhs)->startTime() ? (*rhs)->startTime() : (*lhs)->startTime();
			int speed = (*lhs)->startTime() > (*rhs)->startTime() ? right_speed : left_speed;
			I64 L = (I64)_distance - (*lhs)->distance() - (*rhs)->distance() - (max_time - min_time) * speed;
			I64 s = (I64)left_speed + (I64)right_speed;
			return (int)divide64(L, s) + max_time;
		}

		void PathItemMgr::setTriggerTime(PLIter& iter, int trigger_time)
		{
			if ((*iter)->triggerTime() != trigger_time)
			{
				if ((*iter)->triggerTime() != 0)
					_sorter.pop(iter);
				(*iter)->setTriggerTime(trigger_time);
				if ((*iter)->triggerTime() != 0)
					_sorter.push(iter);
			}
		}

		bool PathItemMgr::find(int pid, int army_id, PLIter& target) const
		{
			PLIter iter = _left_end;
			++iter;
			for(; iter != _right_end; ++iter)
			{
				const PItemPlayer& ptr = upCast<PathItemPlayer>(*iter);
				if (ptr && ptr->pid() == pid
					&& ptr->armyId() == army_id)
				{
					target = iter;
					return true;
				}
			}
			return false;
		}

		Path::Path(int path_id, int from_id, int to_id)
			: _manager(path_id)
		{
			_id = path_id;
			if (from_id < to_id)
			{
				_linked_city[Left] = CityMgr::shared().getCity(from_id);
				_linked_city[Right] = CityMgr::shared().getCity(to_id);
			}
			else
			{
				_linked_city[Left] = CityMgr::shared().getCity(to_id);
				_linked_city[Right] = CityMgr::shared().getCity(from_id);
			}
		}

		void Path::setPathType(int from_id, int to_id, int path_type, unsigned time)
		{
			int side = from_id == _linked_city[Left]->id()? Left : Right;
			_manager.setPathType(side, path_type, time);
		}

		bool Path::access(int from_id, int to_id) const
		{
			if (from_id == to_id)
				return false;
			if (from_id != _linked_city[Left]->id() && to_id != _linked_city[Left]->id())
				return false;
			if (from_id != _linked_city[Right]->id() && to_id != _linked_city[Right]->id())
				return false;
			int side = from_id == _linked_city[Left]->id()? Left : Right;
			return _manager.access(side);
		}

		int Path::getLinkedId(int id) const
		{
			return id == _linked_city[Left]->id()?
				_linked_city[Right]->id() : _linked_city[Left]->id();
		}

		CityPtr Path::getLinkedCity(int id) const
		{
			return id == _linked_city[Left]->id()?
				_linked_city[Right] : _linked_city[Left];
		}

		int Path::getOtherSideId(int side) const
		{
			return _linked_city[side == Left? Right : Left]->id();
		}

		int Path::enter(unsigned time, playerDataPtr d, int army_id, int to_city_id)
		{
			int side = to_city_id == _linked_city[Left]->id()? Right : Left;
			int from_city_id = to_city_id == _linked_city[Left]->id()? _linked_city[Right]->id() :  _linked_city[Left]->id();
			_manager.push(Creator<PathItemPlayer>::Create(time, side, d, army_id, shared_from_this()));
			resetTimer();
			return res_sucess;
		}

		int Path::enter(unsigned time, NpcDataPtr d, int to_city_id)
		{
			int side = to_city_id == _linked_city[Left]->id()? Right : Left;
			int from_city_id = to_city_id == _linked_city[Left]->id()? _linked_city[Right]->id() :  _linked_city[Left]->id();
			_manager.push(Creator<PathItemNpc>::Create(time, side, d, shared_from_this()));
			resetTimer();
			return res_sucess;
		}

		int Path::transferLimit(playerDataPtr d, int army_id, int to_city_id)
		{
			CityPtr ptr = CityMgr::shared().getCity(to_city_id);
			if (!ptr || ptr->id() == MainCity[d->Info().Nation()] 
				|| ptr->nation() != d->Info().Nation())
				return err_illedge;
			PLIter it;
			if (!_manager.find(d->ID(), army_id, it))
				return err_illedge;
			return res_sucess;
		}

		int Path::transfer(unsigned time, playerDataPtr d, int army_id, int to_city_id)
		{
			CityPtr ptr = CityMgr::shared().getCity(to_city_id);
			if (!ptr || ptr->id() == MainCity[d->Info().Nation()] 
				|| ptr->nation() != d->Info().Nation())
				return err_illedge;
			PLIter it;
			if (!_manager.find(d->ID(), army_id, it))
				return err_illedge;
			_manager.pop(it, Transfer);
			resetTimer();
			return ptr->enter(time, d, army_id, JARRAY((int)TIPS::TRANSFER << -1));
		}

		int Path::arrive(int timer_id, PLIter it)
		{
			if (timerOverTime(timer_id))
				return res_sucess;
			CityPtr ptr = (*it)->side() == Left?
				_linked_city[Right] : _linked_city[Left];
			unsigned time = (*it)->triggerTime();
			(*it)->arrive(time, ptr->id());
			_manager.pop(it, Leave);
			resetTimer();
			return res_sucess;
		}
		
		int Path::meet(int timer_id, PLIter lhs, PLIter rhs)
		{
			if (timerOverTime(timer_id))
				return res_sucess;
			if ((*lhs)->side() == Left)
				_manager.swap(lhs, rhs);
			else
				_manager.swap(rhs, lhs);
			resetTimer();
			return res_sucess;
		}

		int Path::attack(int timer_id, PLIter atk_it, PLIter def_it)
		{
			if (timerOverTime(timer_id))
				return res_sucess;
			
			unsigned time = (*atk_it)->triggerTime();
			PathReportData rep_data(time, *atk_it, *def_it);
			rep_data.one2one();
			(*atk_it)->doneBattle(rep_data, *def_it, true);
			(*def_it)->doneBattle(rep_data, *atk_it, false);
			rep_data.done();
			if (rep_data.result.res == resBattle::def_win || (*atk_it)->isDead())
				_manager.pop(atk_it, Defeated);
			else
				_manager.addTips(atk_it, 3);

			if (rep_data.result.res == resBattle::atk_win || (*def_it)->isDead())
				_manager.pop(def_it, Defeated);
			else
				_manager.addTips(def_it, 3);
			resetTimer();
			return res_sucess;
		}

		inline bool Path::timerOverTime(int timer_id)
		{
			return timer_id != _timer_id;
		}

		void Path::resetTimer()
		{
			++_timer_id;
			PLIter iter;
			if(!_manager.getMin(iter))
				return;
			setTimer(iter);
		}

		void Path::reset(unsigned cur_time)
		{
			_manager.reset(cur_time);
			resetTimer();
		}

		void Path::setTimer(const PLIter& iter)
		{
			PLIter n_iter = _manager.getNext(iter);
			if (n_iter == _manager.leftEnd() || n_iter == _manager.rightEnd())
				kingdomwar_sys.addTimer((*iter)->triggerTime(), boostBind(Path::arrive, this, _timer_id, iter));
			else if ((*iter)->nation() == (*n_iter)->nation())
				kingdomwar_sys.addTimer((*iter)->triggerTime(), boostBind(Path::meet, this, _timer_id, iter, n_iter));
			else
				kingdomwar_sys.addTimer((*iter)->triggerTime(), boostBind(Path::attack, this, _timer_id, iter, n_iter));
		}

		void Path::clear(unsigned tick_time)
		{
			_manager.clear(tick_time);
			resetTimer();
		}

		PathList::PathList()
		{
		}

		PathPtr PathList::getPath(int id)
		{
			PathMap::iterator it = _paths.find(id);
			return it == _paths.end()? PathPtr() : it->second;
		}

		void PathList::push(const PathPtr& ptr)
		{
			_paths.insert(make_pair(ptr->id(), ptr));
		}

		void PathList::reset(unsigned cur_time)
		{
			ForEach(PathMap, it, _paths)
				it->second->reset(cur_time);
			update(true);
		}

		void PathList::clear(unsigned cur_time)
		{
			ForEach(PathMap, it, _paths)
				it->second->clear(cur_time);
			update(true);
		}

		void PathList::update(bool is_first)
		{
			_update_info.toArray();
			ForEach(PathMap, it, _paths)
			{
				qValue tmp;
				it->second->getUpdateInfo(tmp);
				if (!tmp.isEmpty())
					_update_info.append(tmp);
			}
			if (is_first || !_update_info.isEmpty())
			{
				_main_info.toArray(); 
				ForEach(PathMap, it, _paths)
				{
					qValue tmp;
					it->second->getMainInfo(tmp);
					if (!tmp.isEmpty())
						_main_info.append(tmp);
				}
			}
		}
	}
}

#include "task_checker.h"
#include "task_record.h"

namespace gg
{
	namespace Task
	{
		Record::Record(const mongo::BSONElement& obj)
		{
			_id = obj["i"].Int();
			_value = obj["v"].Int();
			_state = obj["s"].Int();
		}

		Record::Record(int id, const CheckPtr& ptr, playerDataPtr d)
			: _id(id), _check_ptr(ptr)
		{
			_state = ptr->run(d, _value, Task::Init, -1, -1);
		}

		mongo::BSONObj Record::toBSON() const
		{
			return BSON("i" << _id << "v" << _value << "s" << _state);
		}

		void Record::getInfo(Json::Value& info) const
		{
			info.append(_id);
			info.append(_value);
			info.append(_state);
		}

		int Record::type() const
		{
			if (!getCheckPtr())
				return Empty;
			return _check_ptr->type();
		}

		bool Record::check(playerDataPtr d, int arg1, int arg2)
		{
			if (!getCheckPtr())
				return false;
			int tmp = _value;
			_state = _check_ptr->run(d, _value, Task::Update, arg1, arg2);
			return tmp != _value;
		}

		bool Record::recheck(playerDataPtr d)
		{
			if (!getCheckPtr())
				return false;
			if (_state == Rewarded)
				return false;
			int tmp = _value;
			_state = _check_ptr->run(d, _value, Task::Recheck, -1, -1);
			return tmp != _value;
		}
	}
}

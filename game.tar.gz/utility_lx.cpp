#include "utility_lx.h"


namespace lx
{

	utility_lx::utility_lx()
	{
	}


	utility_lx::~utility_lx()
	{
	}

	/*
	[[aID,id,v],[aID,v]]
	*/
	Json::Value utility_lx::combineArrayBox(const Json::Value& left, const Json::Value& right)
	{
		//LogS << "combine\t" << "left:" << left.toIndentString() << "\tright:" << right.toIndentString() << LogEnd;
		//LogS << "left_length:" << left.size() << "\tright_lenght:" << right.size() << LogEnd;
		int a = left.size();
		int b = right.size();
		if (a == 0 && b == 0)
		{
			return right;
		}
		if (a == 0)
		{
			return right;
		}
		if (b == 0)
		{
			return left;
		}
		Json::Value ret = Json::arrayValue;
		int i = 0, k = 0;
		AList llist, rlist;
		for (; i < a; ++i)
		{
			for (int j = 0; j < b; ++j)
			{
				if (std::find(rlist.begin(), rlist.end(), j) != rlist.end())
				{
					continue;
				}
				int aid = left[i][0u].asInt();
				if (aid == right[j][0u].asInt())
				{
					Json::Value sub = Json::arrayValue;
					if (aid == ACTION::item
						|| aid == ACTION::kingdom_skill_exp
						|| aid == ACTION::lady)
					{
						if (left[i][1u].asInt() == right[j][1u].asInt())
						{
							sub[0u] = left[i][0u].asInt();
							sub[1u] = left[i][1u].asInt();
							sub[2u] = left[i][2u].asInt() + right[j][2u].asInt();
							ret[k++] = sub;
							llist.push_back(i);
							rlist.push_back(j);
							break;
						}
					}
					else
					{
						sub[0u] = aid;
						sub[1u] = left[i][1u].asInt() + right[j][1u].asInt();
						ret[k++] = sub;
						llist.push_back(i);
						rlist.push_back(j);
						break;
					}
				}
			}
		}
		//
		for (int i = 0; i < a; ++i)
		{
			if (std::find(llist.begin(), llist.end(), i) != llist.end())
			{
				continue;
			}
			ret[k++] = left[i];
		}
		for (int i = 0; i < b; ++i)
		{
			if (std::find(rlist.begin(), rlist.end(), i) != rlist.end())
			{
				continue;
			}
			ret[k++] = right[i];
		}
		return ret;
	}
	
	size_t utility_lx::getProbIndex(const std::vector<int>& odds, int sum)
	{
		int target = Common::randomBetween(0, sum - 1);
		for (int i = 0; i < odds.size() - 1; ++i)
		{
			if (target >= odds[i] && target < odds[i + 1])
			{
				return i;
			}
		}
		return 0;
	}

	void utility_lx::combineJsonBox(const Json::Value& from, Json::Value& to)
	{
		Json::Value boxes = Json::arrayValue;
		//��ͬ�ĺϲ���ʣ�µĶ��ǻ�����ͬ�ġ�
		std::vector<int> first_done_list;
		std::vector<int> sec_done_list;
		int c = 0;
		for (int i = 0; i < from.size(); ++i)
		{
			int first_aid = from[i]["aID"].asInt();
			for (int j = 0; j < to.size(); ++j)
			{
				if (std::find(sec_done_list.begin(), sec_done_list.end(), j) != sec_done_list.end())
				{
					continue;
				}
				int sec_aid = to[j]["aID"].asInt();
				if (first_aid == sec_aid)
				{
					if ((first_aid == ACTION::item
						|| first_aid == ACTION::kingdom_skill_exp
						|| first_aid == ACTION::lady)
						&& from[i]["id"].asInt() == to[j]["id"].asInt())
					{
						boxes[c]["aID"] = first_aid;
						boxes[c]["id"] = from[i]["id"].asInt();
						boxes[c]["v"] = from[i]["v"].asInt() + to[j]["v"].asInt();
						first_done_list.push_back(i);
						sec_done_list.push_back(j);
						++c;
						break;
					}
					else if ((first_aid == ACTION::item
						|| first_aid == ACTION::kingdom_skill_exp
						|| first_aid == ACTION::lady)
						&& from[i]["id"].asInt() != to[j]["id"].asInt())
					{
						continue;
					}
					else
					{
						boxes[c]["aID"] = first_aid;
						boxes[c]["v"] = from[i]["v"].asInt() + to[j]["v"].asInt();
						first_done_list.push_back(i);
						sec_done_list.push_back(j);
						++c;
						break;
					}
				}

			}

		}
		//������ͬ��
		for (int i = 0; i < from.size(); ++i)
		{
			if (std::find(first_done_list.begin(), first_done_list.end(), i) != first_done_list.end())
			{
				continue;
			}
			else
			{
				boxes[c] = from[i];
				++c;
			}
		}

		for (int j = 0; j < to.size(); ++j)
		{
			if (std::find(sec_done_list.begin(), sec_done_list.end(), j) != sec_done_list.end())
			{
				continue;
			}
			else
			{
				boxes[c] = to[j];
				++c;
			}
		}
		to = boxes;
	}

	std::string utility_lx::parseJsonBox(Json::Value json_box)
	{
		std::string str("[");
		for (int i = 0; i < json_box.size(); ++i)
		{
			str.append("[");
			int aid = json_box[i]["aID"].asInt();
			str.append(boost::lexical_cast<std::string>(aid));//1.==>aID
			str.append(",");
			int v = json_box[i]["v"].asInt();//2.==>v
			str.append(boost::lexical_cast<std::string>(v));
			//����ǵ��ߺ���Ů  �ͻ���id������ID��12����ŮID��14 
			if (aid == ACTION::item
				|| aid == ACTION::kingdom_skill_exp
				|| aid == ACTION::lady)
			{
				int id = json_box[i]["id"].asInt();//3.==>id
				str.append(",");
				str.append(boost::lexical_cast<std::string>(id));
			}
			str.append("]");
			if (i != json_box.size() - 1)
			{
				str.append(",");
			}
		}
		str.append("]");
		return str;
	}

	Json::Value utility_lx::parseJson(Json::Value json_box)
	{
		Json::Value box = Json::arrayValue;
		for (unsigned i = 0; i < json_box.size(); ++i)
		{
			Json::Value ele;
			int aid = json_box[i]["aID"].asInt();
			ele[0u] = aid;
			if (aid == ACTION::item
				|| aid == ACTION::kingdom_skill_exp
				|| aid == ACTION::lady)
			{
				ele[1u] = json_box[i]["id"].asInt();
				ele[2u] = json_box[i]["v"].asInt();
			}
			else
			{
				ele[1u] = json_box[i]["v"].asInt();
			}
			box[i] = ele;
		}
		return box;
	}

	std::string utility_lx::quotationAway(const std::string& text)
	{
		if (text.size() > 2 && text[0] == '\"' && text[text.size()-1] == '\"')
		{
			return text.substr(1, text.size() - 2);
		}
		return text;
	}
}

#include "player_recharge.h"
#include "dbDriver.h"

const static std::string strCash = "cash";
const static std::string strGold = "gold";

namespace gg
{

	playerRecharge::playerRecharge(playerData* const own)
		:_auto_player(own),
		_cash(0),
		_gold(0)
	{
	}

	void playerRecharge::addRecharge(int gold, int rate)
	{
		if (gold <= 0 || rate <= 0)
		{
			return;
		}
		_gold += gold;
		_cash += gold / rate;
		_sign_auto();
	}

	bool playerRecharge::_auto_save()
	{
		mongo::BSONObj key = BSON(strPlayerID << Own().ID());
		mongo::BSONObj obj = BSON(strPlayerID << Own().ID()
			<< strCash << _cash
			<< strGold << _gold);

		return db_mgr.SaveMongo(DBN::dbPlayerRechargeLog, key, obj);
	}

	void playerRecharge::classLoad()
	{
		mongo::BSONObj key BSON(strPlayerID << Own().ID());
		mongo::BSONObj obj = db_mgr.FindOne(DBN::dbPlayerRechargeLog, key);
		if (obj.isEmpty())
		{
			return;
		}
		if (!obj[strCash].eoo())
		{
			_cash = obj[strCash].Int();
		}
		if (!obj[strGold].eoo())
		{
			_gold = obj[strGold].Int();
		}
	}


	playerRecharge::~playerRecharge()
	{
	}
}

#pragma once

#include "mongoDB.h"
#include "kingdomwar_helper.h"
#include "action_system.h"
#include "battle_system.h"
#include "rank_list.h"
#include "expedition_def.h"

namespace gg
{
	struct mapDataConfig;
	namespace Expedition
	{
		enum
		{
			NPC = 0,
			PLAYER,
		};

		BOOSTSHAREPTR(mapDataConfig, NpcDataPtr);

		struct CmpStrategy
		{
			CmpStrategy(){}
			CmpStrategy(int l, int r, int d)
				: lv(l), round_num(r), damage(d){}
			CmpStrategy(const mongo::BSONElement& obj)
			{
				lv = obj["l"].Int();
				round_num = obj["r"].Int();
				damage = obj["d"].Int();
			}
			mongo::BSONObj toBSON() const
			{
				return BSON("l" << lv << "r" << round_num << "d" << damage);
			}
			int lv;
			int round_num;
			int damage;
		};

		class Strategy
			: public _auto_meta
		{
			public:
				Strategy(int mid);
				Strategy(const mongo::BSONObj& obj);

				int mID() const { return _mid; }
				void push(qValue& q, const CmpStrategy& cmp, BattleReport& rep_data, playerDataPtr& d);
				void update(playerDataPtr d);

			private:
				virtual bool _auto_save();
				bool better(const CmpStrategy& cmp) const;

			private:
				int _mid;
				std::string _first;
				std::string _best;
				CmpStrategy _cmp_best;
				STDLIST(std::string, List);
				List _recent;
				STDLIST(int, PIDS);
				PIDS _recent_pids;
				unsigned _recent_rep_id;
		};

		class RandomER
		{
			public:
				RandomER(const Json::Value& info);
				int rand(int rank) const;
			private:
				struct Rank
				{
					int interval;
					int range;
				};
				Rank _up_rank;
				Rank _down_rank;
		};

		BOOSTSHAREPTR(RandomER, RandomERPtr);

		class MapBase
		{
			public:
				MapBase(const Json::Value& info, int pos);

				int type() const { return _type; }
				int pos() const { return _pos; }
				int bgID() const { return _bg_id; }
				const ActionRandomList& getReward() const { return _reward; }
			
				virtual sBattlePtr getBattlePtr(playerDataPtr d) = 0;
				virtual void getBaseInfo(playerDataPtr d, qValue& q) const = 0;
				virtual void getFMInfo(playerDataPtr d, qValue& q) = 0;

			private:
				int _type;
				int _pos;
				int _bg_id;
				ActionRandomList _reward;
		};

		BOOSTSHAREPTR(MapBase, MapPtr);

		class INpc
			: public MapBase
		{
			public:
				INpc(const Json::Value& info, int pos);

				int mapID() const;
				virtual sBattlePtr getBattlePtr(playerDataPtr d);
				virtual void getBaseInfo(playerDataPtr d, qValue& q) const;
				virtual void getFMInfo(playerDataPtr d, qValue& q);

			private:
				NpcDataPtr _npc_data;
		};

		BOOSTSHAREPTR(INpc, NpcPtr);

		class IPlayer
			: public MapBase
		{
			public:
				IPlayer(const Json::Value& info, int pos);

				virtual sBattlePtr getBattlePtr(playerDataPtr d);
				virtual void getBaseInfo(playerDataPtr d, qValue& q) const;
				virtual void getFMInfo(playerDataPtr d, qValue& q);

				int randTargetPID(playerDataPtr d) const;

			private:
				RandomERPtr _randomer; 
				int _attack_buff;
				int _defense_buff;
		};

		BOOSTSHAREPTR(IPlayer, PtrIPlayer);

		STDVECTOR(MapPtr, MapItemList);

		class MapData
		{
			public:
				MapData(const Json::Value& info);
				void getBaseInfo(playerDataPtr d, qValue& q) const;
				MapPtr getMapData(playerDataPtr d, int pos) const;
			private:
				int index(int bv) const;
			private:
				struct OMapData
				{
					OMapData(const Json::Value& info);
					int start_bv;
					int end_bv;
					MapItemList map_item;
				};
				STDVECTOR(OMapData, OMapDataList);
				OMapDataList _map_data;
		};

		class NpcDataMgr
		{
			SINGLETON(NpcDataMgr);
			public:
				NpcDataPtr getNpcData(int id) const;
			private:
				void loadFile();
			private:
				STDMAP(int, NpcDataPtr, NpcDataMap);
				NpcDataMap _npc_data;
		};

		class MapDataMgr
		{
			SINGLETON(MapDataMgr);
			public:
				void getBaseInfo(playerDataPtr d, qValue& q) const;
				MapPtr getMapData(playerDataPtr d, int pos) const;
			private:
				void loadMapData();
			private:
				std::vector<MapData> _map_data;
		};

		enum
		{
			DailyKey = 0,
			HistoryKey,
		};

		struct RankKey
		{
			RankKey(playerDataPtr d, int type, int season = -1);

			bool operator<(const RankKey& r) const
			{
				if (record.progress != r.record.progress)
					return record.progress < r.record.progress;
				if (record.percent != r.record.percent)
					return record.percent < r.record.percent;
				if (record.time != r.record.time)
					return record.time > r.record.time;
				return pid < r.pid;
			}
			int pid;
			Record record;
		};

		class RankItem
		{
			public:
				RankItem(playerDataPtr d, int type, int season = -1);

				int pid() const { return _rank_key.pid; }
				void getInfo(qValue& q) const;
				const RankKey& key() const { return _rank_key; }
				void alterName(const std::string& name) const
				{
					_name = name;
				}
			private:
				mutable std::string _name;
				int _nation;
				RankKey _rank_key;
		};

		BOOSTSHAREPTR(RankItem, RankItemPtr);
		typedef RankList2<RankItem, RankKey> RankList;

		class DailyRank
			: _auto_meta
		{
			SINGLETON_PTR(DailyRank);
			public:

				void update(playerDataPtr d, const RankKey& old_key);
				void alterName(playerDataPtr d);
				void getInfo(playerDataPtr d, qValue& q) const;

				void tick();

				unsigned nextTickTime() const { return _next_tick_time; }
				unsigned season() const { return _season; }

			private:
				virtual bool _auto_save();
				void loadDB();
				void packageItem(const RankItem& item);
				void clearItem(const RankItem& item);
				void startTimer();

			private:
				RankList _rank_list;
				
				int _season;
				unsigned _next_tick_time;

				int _rk;
				qValue _info;
		};

		class HistoryRank
			: public _auto_meta
		{
			public:
				HistoryRank(int season);

				void update(playerDataPtr d, const RankKey& old_key);
				void alterName(playerDataPtr d);
				void getInfo(playerDataPtr d, qValue& q) const;

				void tick();
				
			private:
				virtual bool _auto_save();
				void loadDB();
				void packageItem(const RankItem& item);
				unsigned getNextTickTime();
				void startTimer();

			private:
				const int _season;
				RankList _rank_list;

				qValue _rank_info;
				std::map<int, int> _rank_map;
				unsigned _next_tick_time;
				
				// temp 
				int _rk;
		};

		class RankMgr
		{
			SINGLETON(RankMgr);
			public:
				void getHistoryInfo(playerDataPtr d, qValue& q);
				void getDailyInfo(playerDataPtr d, qValue& q);

				void updateDaily(playerDataPtr d, const RankKey& old_key);
				void updateHistory(playerDataPtr d, int season, const RankKey& old_key);
				void updateName(playerDataPtr d);

				void tick();

			private:
				BOOSTSHAREPTR(HistoryRank, HistoryRankPtr);
				std::vector<HistoryRankPtr> _history_rank;
				DailyRank _daily_rank;
		};
	}
}

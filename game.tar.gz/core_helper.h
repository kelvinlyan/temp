#pragma once


#include "global_io.h"

namespace gg
{
	namespace DangerIO
	{
		enum
		{
			logic_io,//�߼�IO
			timer_io,//��ʱ��
			file_io,//ս��д�߳�
			despatch_io,//�����߳�
			gg_count,//IO����
		};
	}
}

//logic io
#define LogicPost IOMgr.otherIO(::gg::DangerIO::logic_io).post
//timer io
#define TimerPost IOMgr.otherIO(::gg::DangerIO::timer_io).post
//report io
#define reportPost IOMgr.otherIO(::gg::DangerIO::file_io).post
//despatch io
#define despatchPost IOMgr.otherIO(::gg::DangerIO::despatch_io).post

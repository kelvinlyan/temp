#pragma once

#include "auto_do.h"
#include "battle_def.h"
#include "mongoDB.h"
#include "expedition_def.h"

namespace gg
{
	namespace Expedition
	{
		struct ManInfo
		{
			ManInfo(int h, int m)
				: hp(h), mp(m){}
			bool full() const 
			{
				return hp == -1 && mp == -1; 
			}
			int hp;
			int mp;
		};
	}

	class playerExpedition
		: public _auto_player
	{
		public:
			playerExpedition(playerData* const own);
			void classLoad();

			int challengeLimit(int pos);
			int getReward(int pos, Json::Value& r);
			int flush();
			int buy();
			int mopUp(int pos);

			const Expedition::ManInfo& getManInfo(int mid) const;
			bool dead(int mid) const;

			void upManID(int from, int to);

			int setProgress(int pos);
			void doneBattle(int resultB, sBattlePtr& ptr, sBattlePtr& target_ptr);
			sBattlePtr getBattlePtr();

			void update();
			void upManInfo();
			void upManInfo(sBattlePtr& ptr);

			const Expedition::Record& historyRecord(int season) const { return _history_record[season]; }
			const Expedition::Record& dailyRecord() const { return _daily_record; }
			void clearDailyProgress();

			const std::map<int, int>& getTargetHp() const { return _target_hp; }

			int season();
			int matchRank();
			int matchBV();
			int maxNoEqBV();
			void recalFM();
			int getTargetPID(int pos);
			int curPos() const { return _cur_pos; }

			void tickAt0500();

			const Expedition::Record& getDailyRecord() const
			{
				return _daily_record;
			}
			const Expedition::Record& getHistoryRecord(int season) const
			{
				return _history_record[season];
			}

		private:
			virtual bool _auto_save();
			virtual void _auto_update();
			void resetManInfo(sBattlePtr& ptr);
			void updateRank();
			void resetTargetHp(sBattlePtr& ptr);
			int doGetReward(int pos, Json::Value& r);
			void check();

		private:
			Expedition::Record _history_record[4];
			Expedition::Record _daily_record;

			STDMAP(int, Expedition::ManInfo, ManInfos);
			ManInfos _man_info;
			int _cur_pos;
			unsigned _remain_times;
			unsigned _buy_times;
			unsigned _challenge_times;

			int _season;
			int _max_noeq_bv;
			std::vector<int> _reward_state;

			int _match_rank;
			int _match_bv;
			std::map<int, int> _match_pid;
			std::map<int, int> _target_hp;

			bool _first_expedition;
			int _max_mop_up_pos;
	};

	class playerShadow
		: public _auto_player
	{
		public:
			playerShadow(playerData* const own);
			void classLoad();

			sBattlePtr getBattlePtr(playerDataPtr d);
			void getInfo(playerDataPtr d, qValue& q);

			void tickAt0500();
			void tickAt2200();

		private:
			void resetBattlePtr();
			sBattlePtr fromBSON(const mongo::BSONElement& obj);
			mongo::BSONObj toBSON(const sBattlePtr& ptr);
			virtual bool _auto_save();

		private:
			STDLIST(sBattlePtr, BattleList);
			BattleList _battle_list;
	};
}

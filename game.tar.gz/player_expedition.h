#pragma once

#include "auto_do.h"

namespace gg
{
	namespace Expedition
	{
		struct ManInfo
		{
			int hp;
			int mp;
		};
	}
	class playerExpedition
		: public _auto_player
	{
		public:
			int buyTimes();
			const Expedition::ManInfo& manInfo(int mid) const;

			int rand() const { return _rand; }

		private:
			STDMAP(int, Expedition::ManInfo, ManInfos);
			ManInfos _man_info;
			int _cur_pos;
			unsigned _flush_times;
			std::vector<int> _reward_state;

			int _rand;
	};

	class playerShadow
		: public _auto_player
	{
		public:
			sBattlePtr getBattlePtr();

			void dailyTick();

		private:
			virtual bool _auto_save();

		private:
			sBattlePtr _shadow_ptr;
	};
}

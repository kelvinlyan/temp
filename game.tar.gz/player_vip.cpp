#include "player_vip.h"
#include "vip_system.h"
#include "chat.h"

namespace gg
{
	playerVipMgr::playerVipMgr(playerData* const own) :_auto_player(own)//, first_gift_state(0)
	{
		
	}

	void	 playerVipMgr::classLoad()
	{
		mongo::BSONObj key = BSON(strPlayerID << Own().ID());
		mongo::BSONObj obj = db_mgr.FindOne(DBN::dbPlayerVip, key);
		if (obj.isEmpty())
		{
			return;
		}
		if (!obj["pv"].eoo())
		{
			vector<mongo::BSONElement> sets = obj["pv"].Array();
			for (unsigned i = 0; i < sets.size(); i++)
			{
				vipGiftPtr ptr = Creator<vipGift>::Create();
				ptr->giftId = sets[i]["gi"].Int();
				ptr->rState = sets[i]["rs"].Int();
				playerVipGift[ptr->giftId] = ptr;
			}
		}

	//	checkNotEoo(obj["fg"])
	//		first_gift_state = obj["fg"].Int();
	}

	void playerVipMgr::_auto_update()
	{
		Json::Value msg;
		msg[strMsg][0u] = res_sucess;
		msg[strMsg][1u] = formatgift();
		Own().sendToClient(gate_client::player_vip_show_resp, msg);
	}

	bool playerVipMgr::_auto_save()
	{
		mongo::BSONObj key = BSON(strPlayerID << Own().ID());
		mongo::BSONObjBuilder obj;
		obj << strPlayerID << Own().ID();
		mongo::BSONArrayBuilder pv;
		for (vipGiftMap::iterator it = playerVipGift.begin(); it != playerVipGift.end(); it++)
		{
			mongo::BSONObj obj = BSON("gi" << it->second->giftId << "rs" << it->second->rState);
			pv << obj;
		}
		obj << "pv" << pv.arr();// << "fg" << first_gift_state;

		return db_mgr.SaveMongo(DBN::dbPlayerVip, key, obj.obj());
	}

	void playerVipMgr::addVipGift(int id)
	{
		vipGiftPtr giftPtr = Creator<vipGift>::Create();
		giftPtr->giftId = id;
		giftPtr->rState = 0;
		playerVipGift[giftPtr->giftId] = giftPtr;
		_sign_auto();
	}

	int playerVipMgr::getVipGift(int id, int is_broadcast)
	{
		vipGiftMap::iterator it = playerVipGift.find(id);
		if (it == playerVipGift.end()) return err_illedge;
		if (it->second->rState != 0) return err_illedge;
		vipGiftDataPtr configPtr = vip_sys.getVipGif(id);
		if (!configPtr) return err_illedge;

		const int res = actionDoBox(Own().getOwnDataPtr(), configPtr->box);
		if (res_sucess == res)
		{
			it->second->rState = 1;
			_sign_auto();
			Json::Value res_json = actionRes();
			if (id == 0)
				Log(DBLOG::strLogFirstGift, Own().getOwnDataPtr(), 0, Own().Info().VipLv()
					, "", "", "", "", "", "", res_json.toIndentString());
			else
			{
				Log(DBLOG::strLogVipGift, Own().getOwnDataPtr(), -1, Own().Info().VipLv(),
					it->second->rState, "", "", "", "", "", res_json.toIndentString());
				if (is_broadcast == 1)
				{
					Json::Value bc;
					bc.append(chat_sys.ChatPackage(Own().getOwnDataPtr()));
					bc.append(id);
					bc.append(res_json);
					chat_sys.despatchAll(CHAT::server_vip_gift_broadcast, bc);
				}
			}
			return res_sucess;
		}
		else
		{
			return res;
		}
		_sign_auto();
	}

	Json::Value playerVipMgr::formatgift()
	{
		Json::Value res = Json::objectValue;

		for (vipGiftMap::iterator it = playerVipGift.begin(); it != playerVipGift.end(); it++)
		{
			res[Common::toString(it->second->giftId)] = it->second->rState;
		}
		//res["0"] = first_gift_state;
		return res;
	}

	int playerVipMgr::getFirstGift(Json::Value& r)
	{
		return res_sucess;
	}
	/*
		if (first_gift_state != 0 || Own().Info().VipExp() == 0)
			return err_illedge;
		first_gift_state = 1;
		const ACTION::BoxList& box = vip_sys.getFirstGift();
		actionDoBox(Own().getOwnDataPtr(), box);
		r = formatgift();
		_sign_auto();
		return res_sucess;
	*/
}

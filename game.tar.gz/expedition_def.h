#pragma once

namespace gg
{
	namespace Expedition
	{
		struct Record
		{
			Record(): progress(0), percent(0){}

			int progress;
			int percent;
			unsigned time;
		};
	}
}

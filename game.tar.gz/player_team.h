//###################################
//create by Jim
//2016-03-14
//###################################

#pragma once

#include "auto_do.h"

namespace gg
{
	const static int MaxTeamWarTimes = 30;
	class playerTick;
	class playerTeam : public _auto_player
	{
		friend class playerTick;
	public:
		playerTeam(playerData* const own);
		~playerTeam(){}
		virtual void classLoad();
		inline int getTeamID(){ return teamID; }
		inline unsigned getBuy(){ return buyToday; }
		inline void setTeamID(const int team_id){ teamID = team_id; _sign_update(); }
		void leaveTeam();
		inline int HitTimes(){ return challengeTimes; }
		void alterHitTimes(const int num);
		void alterBuyTimes(const unsigned num);
		void tickWin(const unsigned idx);
		bool beenWin(const unsigned idx);
		unsigned allTimes() const { return _allTimes; }
		void tickTimes();
		virtual void _auto_update();
	private:
		virtual bool _auto_save();
		int teamID;
		unsigned buyToday;
		int challengeTimes;//��ս����
		string challengeData;//��ս����
		unsigned _allTimes;
	};
}

#include "red_paper_system.h"

const static std::string strLocalID = "li";//�������ID
const static std::string strItemID = "ii";//�������ID
const static std::string strCash = "cr";//ʣ����/��ȡ���
const static std::string strNum = "nr";//ʣ����ȡ����
const static std::string strDate = "dt";//�����������
const static std::string strName = "pn";//�������
const static std::string strRobberID = "ri";//���ID/��ȡ��ID
const static std::string strChannel = "ch";//�������
const static std::string strResType = "rt";//��Դ����
const static std::string strDelete = "de";//ɾ����־
const static std::string strFaceID = "fi";//
const static std::string strNationID = "ni";//
const static std::string strReceiverID = "rc";//

namespace gg
{

	red_paper_system* const red_paper_system::_Instance = new red_paper_system();

	red_paper_system::red_paper_system()
	{
	}

	void red_paper_system::reqSendRedPaper(net::Msg& m, Json::Value& r)
	{
		playerDataPtr player = player_mgr.getPlayer(m.playerID);
		if (!player)Return(r, err_illedge);

		//�ȼ���֤
		if (player->LV() < RED_PAPER_LEVEL_LIMIT)
		{
			Return(r, err_paper_under_the_lv);
		}

		ReadJsonArray;
		int paper_id = js_msg[0].asInt();
		playerDataPtr to_player;
		//��֤���ID��Ч��//��֤˽�˺���û���Ч��//������֤
		RawRedPaperPtrList::iterator it = _raw_paper_list.find(paper_id);
		if (it == _raw_paper_list.end())
		{
			Return(r, err_paper_id_not_exist);
		}
		if (it->second->channel == red_paper::channel::Country
			&& player->Info().NationIDX() == Kingdom::nation_invaild_idx)
		{
			Return(r, err_paper_conutry_limit);
		}
		if (it->second->channel == red_paper::channel::Person &&
			_person_raw_paper_list.find(paper_id) != _person_raw_paper_list.end())
		{
			to_player = player_mgr.getPlayer(js_msg[1].asString());
			if (!player)Return(r, err_param_error);
		}
		//��ѯ������ݵõ����
		int item_num = player->Items().itemNum(paper_id);
		if (item_num < 1)
		{
			Return(r, err_paper_out_of_capacity);
		}
		//������local_id
		int local_id = player->RedPaper().getPaperCount() + 1;
		red_paper::UnitPaperPtr paper_ptr = Creator<red_paper::UnitPaper>::Create();
		paper_ptr->player_id = player->ID();
		paper_ptr->local_id = local_id;
		paper_ptr->player_name = player->Name();
		paper_ptr->face_id = player->Info().Face();
		paper_ptr->date = Common::gameTime();
		paper_ptr->nation = player->Info().NationIDX();
		if (it->second->channel == red_paper::channel::Person)
		{
			paper_ptr->receiver_id = to_player->ID();
		}
		red_paper::RedPaperPtr paper = Creator<red_paper::RedPaper>::Create();
		paper_ptr->raw_paper = paper;
		paper_ptr->raw_paper->id = it->second->id;//
		paper_ptr->raw_paper->res_type = it->second->res_type;
		paper_ptr->raw_paper->channel = it->second->channel;
		paper_ptr->raw_paper->cash = it->second->cash;
		paper_ptr->raw_paper->num = it->second->num;
		//��������ӵ�������
		{

			RedPaperSet::iterator pit = _paper_player_set.find(player->ID());
			if (pit == _paper_player_set.end())
			{
				RedPaperList list;
				list[local_id] = paper_ptr;
				_paper_player_set[player->ID()] = list;
			}
			else
			{
				_paper_player_set[player->ID()][local_id] = paper_ptr;
			}
		}
		LogS << "red paper\taction:send\t" << player->Name() << "\tItemID:" << it->second->id << "\tcash:" << paper_ptr->raw_paper->cash << "\tnum:" << paper_ptr->raw_paper->num << LogEnd;
		player->RedPaper().incPaperCount();
		//�ɹ����ͣ�����������м�ȥ��Ӧ���
		player->Items().removeItem(paper_id);
		//player->RedPaper().addSentLog(paper_ptr);
		auto_db(paper_ptr);
		//���º�����͵��������
		Json::Value latest = Json::arrayValue;
		latest[0u] = player->Name();
		latest[1u] = paper_ptr->local_id;
		latest[2u] = paper_ptr->raw_paper->channel;
		latest[3u] = paper_ptr->raw_paper->cash;
		latest[4u] = paper_ptr->raw_paper->num;
		latest[5u] = paper_ptr->face_id;
		Json::Value ret_json;
		ret_json[strMsg][0] = 0;
		ret_json[strMsg][1] = 1;
		ret_json[strMsg][2] = latest;
		switch (paper_ptr->raw_paper->channel)
		{
		case red_paper::channel::World:
			player_mgr.sendToAll(gate_client::req_paper_new_update_resp, ret_json);
			break;
		case red_paper::channel::Country:
			player_mgr.sendToKingdom(player->Info().Nation(), gate_client::req_paper_new_update_resp, ret_json);
			break;
		case red_paper::channel::Person:
			player_mgr.sendToPlayer(to_player->ID(), gate_client::req_paper_new_update_resp, ret_json);
			break;
		default:
			break;
		}
		//���Log
		Log(DBLOG::strLogRedPaperSystem, player, 0, it->second->id, 1);
		Return(r, res_sucess);
	}

	void red_paper_system::reqOpenRedPaper(net::Msg& m, Json::Value& r)
	{
		playerDataPtr player = player_mgr.getPlayer(m.playerID);
		if (!player)Return(r, err_illedge);

		//�ȼ���֤
		if (player->LV() < RED_PAPER_LEVEL_LIMIT)
		{
			Return(r, err_paper_under_the_lv);
		}

		ReadJsonArray;
		std::string robbedName = js_msg[0].asString();
		int local_id = js_msg[1].asInt();
		playerDataPtr robbed_player = player_mgr.getPlayer(robbedName);
		if (!robbed_player)Return(r, err_param_error);

		//����Ƿ���ȡͬһ���
		bool is_open = player->RedPaper().isOpenable(robbed_player->ID(), local_id);
		if (!is_open)
		{
			Return(r, err_paper_get_again_forbidden);
		}

		RedPaperSet::iterator sit = _paper_player_set.find(robbed_player->ID());
		if (sit == _paper_player_set.end())
		{
			Return(r, err_paper_id_not_exist);
		}
		RedPaperList::iterator lit = sit->second.find(local_id);//�ҵ������͵ĺ��
		if (lit == sit->second.end())
		{
			Return(r, err_paper_out_of_count);
		}
		//���Һ����
		if (lit->second->raw_paper->channel == red_paper::channel::Country
			&& (robbed_player->Info().Nation() != player->Info().Nation()
				|| player->Info().NationIDX() == Kingdom::nation_invaild_idx))
		{
			Return(r, err_paper_conutry_limit);//δ������һ��߹��Ҳ�ͬ
		}
		if (lit->second->raw_paper->num < 1)
		{
			Return(r, err_paper_out_of_count);
		}
		int res = 1;
		if (lit->second->raw_paper->num == 1)
		{
			res = lit->second->raw_paper->cash;
			//_paper_player_set[robbed_player->ID()].erase(local_id);
		}
		else
		{
			int min = 1;
			int max = lit->second->raw_paper->cash * 2 / lit->second->raw_paper->num - 1;
			res = Common::randomBetween(min, max);
		}
		LogS << "red paper\taction:open\t" << player->Name() << "\t:-:" << robbedName << "\tcash:" << res << "\tlocal_id:" << local_id << LogEnd;
		r[strMsg][0u] = 0;
		r[strMsg][1u] = res;
		--lit->second->raw_paper->num;
		lit->second->raw_paper->cash -= res;
		//���ӵ������Դ��
		switch (lit->second->raw_paper->res_type)
		{
		case ACTION::gold:
			player->Res().alterGold(res);
			break;
		case ACTION::ticket:
			player->Res().alterTicket(res);
			break;
		case ACTION::cash:
			player->Res().alterCash(res);
			break;
		default:
			break;
		}
		//���䶯���͵��������
		{
			Json::Value latest = Json::arrayValue;
			latest[0u] = robbed_player->Name();
			latest[1u] = lit->second->local_id;
			latest[2u] = lit->second->raw_paper->channel;
			latest[3u] = lit->second->raw_paper->cash;
			latest[4u] = lit->second->raw_paper->num;
			Json::Value ret_json;
			ret_json[strMsg][0u] = 0;
			ret_json[strMsg][1u] = 2;
			ret_json[strMsg][2u] = latest;
			switch (lit->second->raw_paper->channel)
			{
			case red_paper::channel::World:
				player_mgr.sendToAll(gate_client::req_paper_new_update_resp, ret_json);
				break;
			case red_paper::channel::Country:
				player_mgr.sendToKingdom(robbed_player->Info().Nation(), gate_client::req_paper_new_update_resp, ret_json);
				break;
			case red_paper::channel::Person:
				player_mgr.sendToPlayer(robbed_player->ID(), gate_client::req_paper_new_update_resp, ret_json);
				break;
			default:
				break;
			}
		}
		//������ȡ��¼
		{
			red_paper::RobberPtr robber_ptr = Creator<red_paper::Robber>::Create();
			robber_ptr->date = Common::gameTime();
			robber_ptr->nickname = player->Name();
			robber_ptr->senderID = lit->second->player_id;
			robber_ptr->local_id = lit->second->local_id;
			robber_ptr->cash = res;
			robber_ptr->face_Id = lit->second->face_id;
			robber_ptr->robberID = player->ID();
			RobberPlayerSet::iterator ro_it = _robber_player_set.find(robbed_player->ID());
			if (ro_it == _robber_player_set.end())
			{
				red_paper::RobberPlayerList robber_list;
				red_paper::RobberVec vec;
				robber_list[robber_ptr->local_id] = vec;
				_robber_player_set[robbed_player->ID()] = robber_list;
			}
			else if (ro_it->second.find(robber_ptr->local_id) == ro_it->second.end())
			{
				red_paper::RobberVec vec;
				ro_it->second[robber_ptr->local_id] = vec;
			}
			_robber_player_set[robbed_player->ID()][robber_ptr->local_id].push_back(robber_ptr);
		}
		//db
		auto_db(lit->second);
		//player->RedPaper().addRobbedLog(lit->second->local_id, robbed_player, res);
		save_robber(robbed_player->ID(), lit->second->local_id);
		//��ˮ
		Log(DBLOG::strLogRedPaperSystem, player, 1, lit->second->raw_paper->id, robbed_player->ID(), res);
	}

	void red_paper_system::reqRobRedPaper(net::Msg& m, Json::Value& r)
	{
		playerDataPtr player = player_mgr.getPlayer(m.playerID);
		if (!player)Return(r, err_illedge);

		//�ȼ���֤
		if (player->LV() < RED_PAPER_LEVEL_LIMIT)
		{
			Return(r, err_paper_under_the_lv);
		}

		ReadJsonArray;
		std::string robbedName = js_msg[0].asString();
		int local_id = js_msg[1].asInt();
		//LogS << "rob paper\t" << local_id << "\t" << robbedName << LogEnd;
		playerDataPtr robbed_player = player_mgr.getPlayer(robbedName);
		if (!robbed_player)Return(r, err_param_error);

		//����Ƿ���ȡͬһ���
		bool is_open = player->RedPaper().isOpenable(robbed_player->ID(), local_id);
		if (!is_open)
		{
			Return(r, err_paper_get_again_forbidden);
		}

		RedPaperSet::iterator sit = _paper_player_set.find(robbed_player->ID());
		if (sit == _paper_player_set.end())
		{
			Return(r, err_paper_id_not_exist);
		}
		RedPaperList::iterator lit = sit->second.find(local_id);
		if (lit == sit->second.end())
		{
			Return(r, err_paper_out_of_count);
		}
		//���Һ����
		if (lit->second->raw_paper->channel == red_paper::channel::Country
			&& (robbed_player->Info().Nation() != player->Info().Nation()
				|| player->Info().NationIDX() == Kingdom::nation_invaild_idx))
		{
			Return(r, err_paper_conutry_limit);//δ������һ��߹��Ҳ�ͬ
		}
		if (lit->second->raw_paper->num > 0)
		{
			Return(r, res_sucess);
		}
		else
		{
			//_paper_player_set[robbed_player->ID()].erase(local_id);
			Return(r, err_paper_out_of_count);
		}
	}

	void red_paper_system::reqInfoRedPaper(net::Msg& m, Json::Value& r)
	{
		playerDataPtr player = player_mgr.getPlayer(m.playerID);
		if (!player)Return(r, err_illedge);

		//�ȼ���֤
		if (player->LV() < RED_PAPER_LEVEL_LIMIT)
		{
			Return(r, err_paper_under_the_lv);
		}

		Json::Value info = Json::arrayValue;
		unsigned l = 0u;
		unsigned now = Common::gameTime();
		RedPaperSet::iterator pit = _paper_player_set.begin();
		for (;pit != _paper_player_set.end(); ++pit)
		{
			for (RedPaperList::iterator uit = pit->second.begin();
				uit != pit->second.end();
				++uit)
			{
				if ((now > uit->second->date && now - uit->second->date > DEAHLINE)
					|| player->RedPaper().isDel(uit->second->player_id, uit->second->local_id)
					|| (uit->second->raw_paper->channel == red_paper::channel::Country && player->Info().NationIDX() != uit->second->nation)
					|| (uit->second->raw_paper->channel == red_paper::channel::Person && player->ID() != uit->second->receiver_id))
				{
					continue;
				}
				Json::Value unit = Json::arrayValue;
				//unit[0u] = uit->second->raw_paper->player_id;
				unit[0u] = uit->second->player_name;
				unit[1u] = uit->second->local_id;
				unit[2u] = uit->second->raw_paper->channel;
				unit[3u] = uit->second->raw_paper->cash;
				unit[4u] = uit->second->raw_paper->num;
				unit[5u] = uit->second->face_id;
				info[l++] = unit;
			}
		}
		r[strMsg][0u] = 0;
		r[strMsg][1u] = info;
	}

	void red_paper_system::reqDelHistoryRedPaper(net::Msg& m, Json::Value& r)
	{
		playerDataPtr player = player_mgr.getPlayer(m.playerID);
		if (!player)Return(r, err_illedge);

		//�ȼ���֤
		if (player->LV() < RED_PAPER_LEVEL_LIMIT)
		{
			Return(r, err_paper_under_the_lv);
		}

		ReadJsonArray;
		int local_id = js_msg[0u].asInt();
		std::string player_name = js_msg[1u].asString();
		playerDataPtr robbed_player = player_mgr.getPlayer(player_name);
		if (_paper_player_set.find(robbed_player->ID()) != _paper_player_set.end()
			&& _paper_player_set[robbed_player->ID()].find(local_id) != _paper_player_set[robbed_player->ID()].end())
		{
			player->RedPaper().addDelLog(robbed_player->ID(), local_id);
		}
		Return(r, res_sucess);

	}

	/*
	void red_paper_system::reqInfoHistoryRedPaper(net::Msg& m, Json::Value& r)
	{
		playerDataPtr player = player_mgr.getPlayer(m.playerID);
		if (!player)Return(r, err_illedge);

		//�ȼ���֤
		if (player->LV() < RED_PAPER_LEVEL_LIMIT)
		{
			Return(r, err_paper_under_the_lv);
		}

		SentPaperListPtr sent_ptr = player->RedPaper().sendLog();
		Json::Value sent_papers = Json::arrayValue;
		unsigned idx = 0u;
		unsigned now = Common::gameTime();
		for (SentPaperList::iterator sit = sent_ptr->begin();
			sit != sent_ptr->end();
			++sit)
		{
			if (sit->second->del == 1 || (now > sit->second->date && now - sit->second->date > DEAHLINE))
			{
				continue;
			}
			Json::Value sent_paper = Json::arrayValue;
			sent_paper[0u] = sit->second->paper->player_name;
			sent_paper[1u] = sit->second->paper->local_id;
			sent_paper[2u] = sit->second->paper->raw_paper->channel;
			sent_paper[3u] = sit->second->paper->raw_paper->cash;
			sent_paper[4u] = sit->second->paper->raw_paper->num;
			sent_papers[idx++] = sent_paper;
		}

		PaperRobbedListPtr robbed_ptr = player->RedPaper().robbedLog();
		Json::Value robbed_papers = Json::arrayValue;
		idx = 0u;
		for (red_paper::PaperRobbedList::iterator it = robbed_ptr->begin();
			it != robbed_ptr->end(); ++it)
		{
			if (it->second->del == 1 || (it->second->date > now && it->second->date - now > DEAHLINE))
			{
				continue;
			}
			Json::Value robbed_paper = Json::arrayValue;
			robbed_paper[0u] = it->second->local_id;
			robbed_paper[1u] = it->second->nickname;
			robbed_paper[2u] = it->second->cash;
			robbed_papers[idx++] = robbed_paper;
		}
		r[strMsg][0u] = 0;
		r[strMsg][1u] = sent_papers;
		r[strMsg][2u] = robbed_papers;
	}
	*/

	void red_paper_system::reqRobInfo(net::Msg& m, Json::Value& r)
	{
		playerDataPtr player = player_mgr.getPlayer(m.playerID);
		if (!player)Return(r, err_illedge);

		//�ȼ���֤
		if (player->LV() < RED_PAPER_LEVEL_LIMIT)
		{
			Return(r, err_paper_under_the_lv);
		}

		ReadJsonArray;
		std::string player_name = js_msg[0u].asString();
		int local_id = js_msg[1u].asInt();
		playerDataPtr robbed_player = player_mgr.getPlayer(player_name);
		if (!robbed_player)
		{
			Return(r, err_param_error);
		}
		LogS << "red paper\taction:rob info\t" << player->Name() << "\t:-:" << robbed_player->Name() << "\tlocal_id:" << local_id << LogEnd;
		if (_paper_player_set.find(robbed_player->ID()) != _paper_player_set.end()
			&& _paper_player_set[robbed_player->ID()].find(local_id) != _paper_player_set[robbed_player->ID()].end())
		{
			Json::Value info = Json::arrayValue;
			int item_id = _paper_player_set[robbed_player->ID()][local_id]->raw_paper->id;
			if (_robber_player_set.find(robbed_player->ID()) != _robber_player_set.end()
				&& _robber_player_set[robbed_player->ID()].find(local_id) != _robber_player_set[robbed_player->ID()].end()
				&& _raw_paper_list.find(item_id) != _raw_paper_list.end())
			{
				unsigned idx = 0u;
				for (int i = 0; i < _robber_player_set[robbed_player->ID()][local_id].size(); ++i)
				{
					Json::Value unit = Json::arrayValue;
					unit[0u] = _robber_player_set[robbed_player->ID()][local_id][i]->robberID;
					unit[1u] = _robber_player_set[robbed_player->ID()][local_id][i]->nickname;
					unit[2u] = _robber_player_set[robbed_player->ID()][local_id][i]->face_Id;
					unit[3u] = _robber_player_set[robbed_player->ID()][local_id][i]->cash;
					unit[4u] = Common::toStampTime(_robber_player_set[robbed_player->ID()][local_id][i]->date);
					info[idx++] = unit;
				}
			}
			r[strMsg][0u] = 0;
			r[strMsg][1u] = _raw_paper_list[item_id]->num;
			r[strMsg][2u] = _paper_player_set[robbed_player->ID()][local_id]->raw_paper->num;
			r[strMsg][3u] = _raw_paper_list[item_id]->cash;
			r[strMsg][4u] = _paper_player_set[robbed_player->ID()][local_id]->raw_paper->cash;
			r[strMsg][5u] = info;
		}
		else
		{
			Return(r, err_paper_id_not_exist);
		}
	}

	void red_paper_system::reqAssetRedPaper(net::Msg& m, Json::Value& r)
	{
		playerDataPtr player = player_mgr.getPlayer(m.playerID);
		if (!player)Return(r, err_illedge);

		//�ȼ���֤
		if (player->LV() < RED_PAPER_LEVEL_LIMIT)
		{
			Return(r, err_paper_under_the_lv);
		}

		Json::Value ret_json = Json::arrayValue;
		unsigned idx = 0u;
		RawRedPaperPtrList::iterator it = _raw_paper_list.begin();
		for (;it != _raw_paper_list.end(); ++it)
		{
			int count = player->Items().itemNum(it->second->id);
			if (count < 1) continue;
			Json::Value unit = Json::arrayValue;
			unit[0u] = ACTION::item;
			unit[1u] = it->second->id;
			unit[2u] = it->second->channel;
			unit[3u] = it->second->cash;
			unit[4u] = it->second->num;
			unit[5u] = count;
			ret_json[idx++] = unit;
		}
		r[strMsg][0u] = 0;
		r[strMsg][1u] = ret_json;
	}

	void red_paper_system::reqPanelTotalRedPaper(net::Msg& m, Json::Value& r)
	{
		playerDataPtr player = player_mgr.getPlayer(m.playerID);
		if (!player)Return(r, err_illedge);

		//�ȼ���֤
		if (player->LV() < RED_PAPER_LEVEL_LIMIT)
		{
			Return(r, err_paper_under_the_lv);
		}

		//ӵ�к����Ϣ
		Json::Value assets = Json::arrayValue;
		unsigned idx = 0u;
		RawRedPaperPtrList::iterator it = _raw_paper_list.begin();
		for (;it != _raw_paper_list.end(); ++it)
		{
			int count = player->Items().itemNum(it->second->id);
			if (count < 1) continue;
			Json::Value unit = Json::arrayValue;
			unit[0u] = it->second->id;
			unit[1u] = it->second->channel;
			unit[2u] = it->second->cash;
			unit[3u] = it->second->num;
			unit[4u] = count;
			assets[idx++] = unit;
		}

		/*
		//��ʷ�����Ϣ
		SentPaperListPtr sent_ptr = player->RedPaper().sendLog();
		Json::Value sent_papers = Json::arrayValue;
		idx = 0u;
		unsigned now = Common::gameTime();
		for (SentPaperList::iterator sit = sent_ptr->begin();
			sit != sent_ptr->end();
			++sit)
		{
			if (sit->second->del == 1 || (now > sit->second->date && now - sit->second->date > DEAHLINE))
			{
				continue;
			}
			Json::Value sent_paper = Json::arrayValue;
			sent_paper[0u] = sit->second->paper->player_name;
			sent_paper[1u] = sit->second->paper->local_id;
			sent_paper[2u] = sit->second->paper->raw_paper->channel;
			sent_paper[3u] = sit->second->paper->raw_paper->cash;
			sent_paper[4u] = sit->second->paper->raw_paper->num;
			sent_papers[idx++] = sent_paper;
		}

		PaperRobbedListPtr robbed_ptr = player->RedPaper().robbedLog();
		Json::Value robbed_papers = Json::arrayValue;
		idx = 0;
		for (red_paper::PaperRobbedList::iterator it = robbed_ptr->begin();
			it != robbed_ptr->end(); ++it)
		{
			if (it->second->del == 1 || (it->second->date > now && it->second->date - now > DEAHLINE))
			{
				continue;
			}
			Json::Value robbed_paper = Json::arrayValue;
			robbed_paper[0u] = it->second->local_id;
			robbed_paper[1u] = it->second->nickname;
			robbed_paper[2u] = it->second->cash;
			robbed_papers[idx++] = robbed_paper;
		}
		*/

		//��Ч�����Ϣ
		Json::Value info = Json::arrayValue;
		unsigned l = 0u;
		RedPaperSet::iterator pit = _paper_player_set.begin();
		for (;pit != _paper_player_set.end(); ++pit)
		{
			for (RedPaperList::iterator uit = pit->second.begin();
				uit != pit->second.end();
				++uit)
			{
				if (player->RedPaper().isDel(uit->second->player_id, uit->second->local_id))
				{
					continue;
				}
				Json::Value unit = Json::arrayValue;
				//unit[0u] = uit->second->raw_paper->player_id;
				unit[0u] = uit->second->player_name;
				unit[1u] = uit->second->local_id;
				unit[2u] = uit->second->raw_paper->channel;
				unit[3u] = uit->second->raw_paper->cash;
				unit[4u] = uit->second->raw_paper->num;
				info[l++] = unit;
			}
		}
		r[strMsg][0u] = 0;
		r[strMsg][1u] = info;
		//r[strMsg][2u] = sent_papers;
		//r[strMsg][3u] = robbed_papers;
		r[strMsg][2u] = assets;
	}

	void red_paper_system::reqDelete(net::Msg& m, Json::Value& r)
	{
		playerDataPtr player = player_mgr.getPlayer(m.playerID);
		if (!player)Return(r, err_illedge);

		//�ȼ���֤
		if (player->LV() < RED_PAPER_LEVEL_LIMIT)
		{
			Return(r, err_paper_under_the_lv);
		}
		Json::Value info = Json::arrayValue;
		unsigned l = 0u;
		for (RedPaperSet::iterator it = _paper_player_set.begin();
			it != _paper_player_set.end();
			++it)
		{
			for (RedPaperList::iterator lit = it->second.begin();
				lit != it->second.end();
				++lit)
			{
				if (lit->second->raw_paper->num < 1
					|| !player->RedPaper().isOpenable(lit->second->player_id, lit->second->local_id))
				{
					player->RedPaper().addDelLog(lit->second->player_id, lit->second->local_id);
				}
				else if (!player->RedPaper().isDel(lit->second->player_id, lit->second->local_id))
				{
					Json::Value unit = Json::arrayValue;
					//unit[0u] = uit->second->raw_paper->player_id;
					unit[0u] = lit->second->player_name;
					unit[1u] = lit->second->local_id;
					unit[2u] = lit->second->raw_paper->channel;
					unit[3u] = lit->second->raw_paper->cash;
					unit[4u] = lit->second->raw_paper->num;
					info[l++] = unit;
				}
			}
		}
		//�����µ����������Ϣ
		r[strMsg][0u] = 0;
		r[strMsg][1u] = info;
	}

	void red_paper_system::intiData()
	{
		std::cout << "load ./red_paper/* START	" << std::endl;

		Json::Value wor_value = Common::loadJsonFile(std::string("./instance/red_paper/config_1.json"));
		for (int i = 0; i < wor_value.size(); ++i)
		{
			assert(wor_value[i].size() == 4);
			red_paper::RedPaperPtr paper = Creator<red_paper::RedPaper>::Create();
			paper->id = wor_value[i][0].asInt();
			paper->channel = red_paper::channel::World;
			paper->res_type = wor_value[i][1].asInt() == ACTION::ticket ? ACTION::ticket : (wor_value[i][1].asInt() == ACTION::gold ? ACTION::gold : ACTION::cash);
			paper->cash = wor_value[i][2].asInt();
			paper->num = wor_value[i][3].asInt();
			_raw_paper_list[paper->id] = paper;
		}

		Json::Value con_value = Common::loadJsonFile(std::string("./instance/red_paper/config_2.json"));
		for (int i = 0; i < con_value.size(); ++i)
		{
			assert(con_value[i].size() == 4);
			red_paper::RedPaperPtr paper = Creator<red_paper::RedPaper>::Create();
			paper->id = con_value[i][0].asInt();
			paper->channel = red_paper::channel::Country;
			paper->res_type = con_value[i][1].asInt() == ACTION::ticket ? ACTION::ticket : (con_value[i][1].asInt() == ACTION::gold ? ACTION::gold : ACTION::cash);
			paper->cash = con_value[i][2].asInt();
			paper->num = con_value[i][3].asInt();
			_raw_paper_list[paper->id] = paper;
		}

		Json::Value per_value = Common::loadJsonFile(std::string("./instance/red_paper/config_3.json"));
		for (int i = 0; i < per_value.size(); ++i)
		{
			assert(per_value[i].size() >= 3);
			red_paper::RedPaperPtr paper = Creator<red_paper::RedPaper>::Create();
			paper->id = per_value[i][0].asInt();
			paper->channel = red_paper::channel::Person;
			paper->res_type = per_value[i][1].asInt() == ACTION::ticket ? ACTION::ticket : (per_value[i][1].asInt() == ACTION::gold ? ACTION::gold : ACTION::cash);
			paper->cash = per_value[i][2].asInt();
			paper->num = 1;
			_raw_paper_list[paper->id] = paper;
			_person_raw_paper_list[paper->id] = paper;
		}

		std::cout << "load ./red_paper/* NED	" << std::endl;
	}

	void red_paper_system::loadData()
	{
		objCollection objs = db_mgr.Query(DBN::dbSystemSentRedPaper);
		unsigned now = Common::gameTime();
		ForEachC(objCollection, it, objs)
		{
			red_paper::UnitPaperPtr unit = Creator<red_paper::UnitPaper>::Create();
			const mongo::BSONObj& obj = (*it);
			int num = obj[strNum].Int();
			unsigned date = date = obj[strDate].Int();
			if ((now > date && now - date > DEAHLINE)
				|| num < 1)
			{
				continue;
			}
			unit->player_id = obj[strPlayerID].Int();
			unit->player_name = obj[strPlayerName].String();
			unit->local_id = obj[strLocalID].Int();
			unit->face_id = obj[strFaceID].Int();
			unit->nation = obj[strNationID].Int();
			unit->receiver_id = obj[strReceiverID].Int();
			unit->date = date;
			red_paper::RedPaperPtr paper_ptr = Creator<red_paper::RedPaper>::Create();
			paper_ptr->id = obj[strItemID].Int();
			paper_ptr->cash = obj[strCash].Int();
			paper_ptr->num = num;
			paper_ptr->channel = obj[strChannel].Int();
			paper_ptr->res_type = obj[strResType].Int();
			unit->raw_paper = paper_ptr;
			if (_paper_player_set.find(unit->player_id) == _paper_player_set.end())
			{
				RedPaperList list;
				list[unit->local_id] = unit;
				_paper_player_set[unit->player_id] = list;
			}
			else
			{
				_paper_player_set[unit->player_id][unit->local_id] = unit;
			}
		}
		//
		objCollection objs2 = db_mgr.Query(DBN::dbSystemGetRedPaper);
		ForEachC(objCollection, it, objs2)
		{
			const mongo::BSONObj& obj = (*it);
			red_paper::RobberPtr robber_ptr = Creator<red_paper::Robber>::Create();
			robber_ptr->senderID = obj[strPlayerID].Int();
			robber_ptr->local_id = obj[strLocalID].Int();
			robber_ptr->robberID = obj[strRobberID].Int();
			robber_ptr->nickname = obj[strName].String();
			robber_ptr->cash = obj[strCash].Int();
			robber_ptr->date = obj[strDate].Int();
			robber_ptr->face_Id = obj[strFaceID].Int();
			if (_robber_player_set.find(robber_ptr->senderID) == _robber_player_set.end())
			{
				red_paper::RobberPlayerList list;
				red_paper::RobberVec vec;
				vec.push_back(robber_ptr);
				list[robber_ptr->local_id] = vec;
				_robber_player_set[robber_ptr->senderID] = list;
			}
			else if (_robber_player_set[robber_ptr->senderID].find(robber_ptr->local_id) == _robber_player_set[robber_ptr->senderID].end())
			{
				red_paper::RobberVec vec;
				vec.push_back(robber_ptr);
				_robber_player_set[robber_ptr->senderID][robber_ptr->local_id] = vec;
			}
			else
			{
				_robber_player_set[robber_ptr->senderID][robber_ptr->local_id].push_back(robber_ptr);
			}
		}
	}

	bool red_paper_system::auto_db(red_paper::UnitPaperPtr ptr)
	{
		if (!ptr) return false;
		mongo::BSONObj key = BSON(strPlayerID << ptr->player_id << strLocalID << ptr->local_id);

		mongo::BSONObj obj = BSON(strPlayerID << ptr->player_id
			<< strPlayerName << ptr->player_name
			<< strLocalID << ptr->local_id
			<< strItemID << ptr->raw_paper->id
			<< strCash << ptr->raw_paper->cash
			<< strNum << ptr->raw_paper->num
			<< strDate << ptr->date
			<< strChannel << ptr->raw_paper->channel
			<< strResType << ptr->raw_paper->res_type
			<< strFaceID << ptr->face_id
			<< strNationID << ptr->nation
			<< strReceiverID << ptr->receiver_id
		);
		return db_mgr.SaveMongo(DBN::dbSystemSentRedPaper, key, obj);
	}

	bool red_paper_system::save_robber(int playerID, int local_id, int idx/* = -1*/)
	{
		RobberPlayerSet::iterator pit = _robber_player_set.find(playerID);
		if (pit == _robber_player_set.end())
		{
			return false;
		}
		red_paper::RobberPlayerList::iterator rit = pit->second.find(local_id);
		if (rit == pit->second.end())
		{
			return false;
		}

		if (idx == -1)
		{
			idx = rit->second.size() - 1;
		}
		if (idx < 0 || rit->second.size() < 1)
		{
			return false;
		}
		mongo::BSONObj key = BSON(strPlayerID << playerID
			<< strLocalID << local_id
			<< strRobberID << rit->second[idx]->robberID);

		mongo::BSONObj obj = BSON(strPlayerID << playerID
			<< strLocalID << local_id
			<< strRobberID << rit->second[idx]->robberID
			<< strName << rit->second[idx]->nickname
			<< strDate << rit->second[idx]->date
			<< strCash << rit->second[idx]->cash
			<< strFaceID << rit->second[idx]->face_Id
		);

		return db_mgr.SaveMongo(DBN::dbSystemGetRedPaper, key, obj);
	}

	red_paper_system::~red_paper_system()
	{
	}
}

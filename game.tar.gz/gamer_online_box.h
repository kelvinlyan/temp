//###################################
//create by Jim
//2016-05-05
//###################################

#pragma once

#include "auto_do.h"

namespace gg
{
	class playerOnlineBox :
		public _auto_player
	{
	public:
		playerOnlineBox(playerData* const own);
		~playerOnlineBox(){}
		void offline();//���߼�¼
		unsigned onlineDur();//����ʱ��
		inline unsigned cBoxIDX(){ return tickBox; }//��ǰ���߽���ID
		void goOn();
		void reset();
		void online();
		virtual void _auto_update();
	private:
		virtual void classLoad();
		virtual bool _auto_save();
		unsigned tickBox;//������ȡID
		unsigned countTime;//�ۼ�ʱ��
		unsigned tickTime;//��ʼʱ��
	};
}
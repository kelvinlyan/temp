#include "sign_system.h"

namespace gg
{
	void SignConf::load(const Json::Value& info)
	{
		ForEachC(Json::Value, it, info)
		{
			Json::Value rw = (*it)["reward"];
			_one_reward.push_back(actionFormatBox(rw));
			ForEach(Json::Value, itr, rw)
				(*itr)["v"] = (*itr)["v"].asInt() * 2;
			_two_reward.push_back(actionFormatBox(rw));
			_vip.push_back((*it)["vip"].asInt());
		}
	}

	const ACTION::BoxList& SignConf::getBoxList(playerDataPtr d, int day) const
	{
		if (_vip[day] != -1
			&& d->Info().VipLv() >= _vip[day])
			return _two_reward[day];
		return _one_reward[day];
	}

	sign_system* const sign_system::_Instance = new sign_system();

	void sign_system::initData()
	{
		loadFile();
	}

	void sign_system::playerInfo(net::Msg& m, Json::Value& r)
	{
		playerDataPtr d = player_mgr.getPlayer(m.playerID);
		if (!d) Return(r, err_illedge);
		d->Sign().update();
	}

	void sign_system::getReward(net::Msg& m, Json::Value& r)
	{
		playerDataPtr d = player_mgr.getPlayer(m.playerID);
		if (!d) Return(r, err_illedge);
		ReadJsonArray;
		int id = js_msg[0u].asInt();
		int res = d->Sign().getReward(id, r[strMsg][1u]);
		Return(r, res);
	}

	void sign_system::loadFile()
	{
		Json::Value json;
		json = Common::loadJsonFile("./instance/sign/reward1.json");
		_reward1.load(json);
		json = Common::loadJsonFile("./instance/sign/reward2.json");
		_reward2.load(json);
	}

	const ACTION::BoxList& sign_system::getBoxList(playerDataPtr d, int day, bool first)
	{
		return first? _reward1.getBoxList(d, day) : _reward2.getBoxList(d, day);
	}
}

#pragma once

#include "auto_base.h"
#include "mongoDB.h"
#include "kingdomwar_helper.h"

namespace gg
{
	class playerData;
	BOOSTSHAREPTR(playerData, playerDataPtr);

	namespace KingdomWar
	{
		namespace Task
		{
			enum
			{
				Empty = 0,
				BattleTimes,
				WinStreakTimes,
				GetExploit,
				UseFood,
				PTaskMax,
			};

			enum
			{
				Running = 0,
				Finished,
				Rewarded,
				NoChanged,

				PTArrayInt = 0,
				PTVecInt,
			};

			class IParam
			{
				public:
					virtual int type() const = 0;
					virtual mongo::BSONArray toBSON() const = 0;
					virtual void getInfo(qValue& q) const = 0;
			};

			BOOSTSHAREPTR(IParam, ParamPtr);

			template<unsigned N>
			class ArrayInt
				: public IParam
			{
				public:
					ArrayInt(){}
					ArrayInt(const mongo::BSONElement& obj)
					{
						std::vector<mongo::BSONElement> ele = obj.Array();
						for (unsigned i = 1; i < ele.size(); ++i)
							_values[i - 1] = ele[i].Int();
					}
					virtual int type() const { return PTArrayInt; }
					virtual mongo::BSONArray toBSON() const
					{
						mongo::BSONArrayBuilder b;
						b.append(type());
						for(unsigned i = 0; i != N; ++i)
							b.append(_values[i]);
						return b.arr();
					}
					virtual void getInfo(qValue& q) const
					{
						for(unsigned i = 0; i != N; ++i)
							q.append(_values[i]);
					}
					int& operator[](unsigned n)
					{
						return _values[n];
					}
					
					
				private:
					int _values[N];
			};

#define ARRAYINT(num, name)\
	typedef ArrayInt<num> name;\
	BOOSTSHAREPTR(name, name##Ptr)

			ARRAYINT(1, OneInt);
			ARRAYINT(2, TwoInt);
			ARRAYINT(3, ThreeInt);
			ARRAYINT(4, FourInt);

			class VecInt
				: public IParam
			{
				public:
					VecInt(){}
					VecInt(const mongo::BSONElement& obj)
					{
						std::vector<mongo::BSONElement> ele = obj.Array();
						for (unsigned i = 1; i < ele.size(); ++i)
							_values.push_back(ele[i].Int());
					}
					virtual int type() const { return PTVecInt; }
					virtual mongo::BSONArray toBSON() const
					{
						mongo::BSONArrayBuilder b;
						b.append(type());
						for(unsigned i = 0; i < _values.size(); ++i)
							b.append(_values[i]);
						return b.arr();
					}
					virtual void getInfo(qValue& q) const
					{
						for(unsigned i = 0; i < _values.size(); ++i)
							q.append(_values[i]);
					}

					std::vector<int> _values;
			};

			BOOSTSHAREPTR(VecInt, VecIntPtr);

			class ParamFactory
			{
				public:
					static ParamPtr create(const mongo::BSONElement& obj)
					{
						std::vector<mongo::BSONElement> ele = obj.Array();
						int type = ele[0u].Int();
						if (type == PTArrayInt)
						{
							int size = ele.size() - 1;
							switch (size)
							{
								case 1:
									return Creator<OneInt>::Create(obj);
								case 2:
									return Creator<TwoInt>::Create(obj);
								case 3:
									return Creator<ThreeInt>::Create(obj);
								case 4:
									return Creator<FourInt>::Create(obj);
								default:
									return ParamPtr();
							}
						}
						else if (type == PTVecInt)
							return Creator<VecInt>::Create(obj);
						else
							return ParamPtr();
					}
			};

			class ICheck
			{
				public:
					ICheck(int type): _type(type){}
					int type() const { return _type; }
					virtual int init(playerDataPtr d, ParamPtr& param) = 0;
					virtual int update(playerDataPtr d, ParamPtr& param, const Json::Value& arg) = 0;
				private:
					int _type;
			};

			BOOSTSHAREPTR(ICheck, CheckPtr);

			enum
			{
				OccupySpecified = Empty + 1,
				GetExploit2,
				OccupyNum1,
				OccupyNum2,
				NTaskMax,
			};

			class ICheck2
			{
				public:
					ICheck2(int type): _type(type){}
					int type() const { return _type; }
					virtual int update(int nation, ParamPtr& param, const Json::Value& arg) = 0;
					virtual int init(int nation, ParamPtr& param) = 0;

				private:
					int _type;
			};

			BOOSTSHAREPTR(ICheck2, CheckPtr2);

		}

		struct NationTaskConfig
		{
			NationTaskConfig(): id(-1){}
			NationTaskConfig(const Json::Value& info);
			bool valid() const { return id != -1; }
			int id;
			int weight;
			std::vector<Task::CheckPtr2> checker;
			Json::Value reward;
		};

		class NationTask
			: public _auto_meta
		{
			public:
				NationTask(int nation);

				int id() const { return _id; }
				int state() const { return _state; }
				void loadDB();

				void getInfo(playerDataPtr d, qValue& q) const;
				void update(int type, const Json::Value& arg);
				int getReward(playerDataPtr d, Json::Value& r);
				void reset(int strength, const NationTaskConfig& config);
				void clear();
				void stop(unsigned cur_time);
				int getSchedule();
				int getTarget();

			private:
				virtual bool _auto_save();
				bool getChecker();

			private:
				int _id;
				int _nation;
				int _state;
				int _strength;
				int _nation_lv;
				Task::ParamPtr _param;
				Task::CheckPtr2 _checker;
		};

		BOOSTSHAREPTR(NationTask, NationTaskPtr);

		class NationTaskMgr
		{
			SINGLETON(NationTaskMgr);
			public:
				void update(int type, int nation, const Json::Value& arg = Json::nullValue)
				{
					if (nation < 0 || nation >= _nation_tasks.size())
						return;
					_nation_tasks[nation]->update(type, arg);
				}
				void getInfo(playerDataPtr d, qValue& q) const;
				int getState(int nation) const
				{
					if (nation < 0 || nation >= _nation_tasks.size())
						return Task::Running;
					return _nation_tasks[nation]->state();
				}

				int getReward(playerDataPtr d, int id, Json::Value& r);

				void reset();
				void clear();
				void start(unsigned cur_time);
				void stop(unsigned cur_time);

				const NationTaskConfig& getConfig(int id) const;

			private:
				void loadFile();
				void loadDB();
				const NationTaskConfig& randConfig(int type) const;

			private:
				STDVECTOR(NationTaskPtr, NationTasks);
				NationTasks _nation_tasks;

				STDMAP(int, NationTaskConfig, ConfigMap);
				STDVECTOR(NationTaskConfig, RandConfig);
				ConfigMap _config_map;
				RandConfig _rand_config[4];
				unsigned _total_weight[4];
				unsigned _last_stop_time;

				static NationTaskConfig _null;
		};

		class TaskParamHelper
			: public _auto_meta
		{
			SINGLETON_PTR(TaskParamHelper);
			public:
				int param() const 
				{
					return _player_set.size(); 
				}
				void update(int pid);
				void clear();

			private:
				void loadDB();
				virtual bool _auto_save();

			private:
				std::set<int> _player_set;
		};
	}
}

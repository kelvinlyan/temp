//###################################
//create by Jim
//2016-06-01
//###################################
#pragma once

#include "auto_do.h"

namespace gg
{
	namespace MONEYACTIVITY
	{
		enum MATYPE
		{
			money_activity_begin = 0,
			money_activity_recharge = money_activity_begin,
			money_activity_consume,
			money_activity_num,
			money_activity_end = money_activity_num - 1,
		};

		struct Data 
		{
			Data(const MATYPE type) : typeAct(type)
			{
				createTime = 0;
				dealNum = 0;
				awardList.clear();
				dirty = false;
			}
			void clearData()
			{
				createTime = 0;
				dealNum = 0;
				awardList.clear();
			}
			bool dirty;
			const MATYPE typeAct;
			unsigned createTime;
			int dealNum;
			STDSET(int, wonList);
			wonList awardList;//�Ѿ���ȡ�����б�
		};
		BOOSTSHAREPTR(Data, ptrData);
	}

	class playerMoneyActivity :
		public _auto_player
	{
	public:
		playerMoneyActivity(playerData* const own);
		~playerMoneyActivity(){}
		void clearType();
		bool hasReward(const unsigned type);
		void tickNum(const unsigned type, const int num);
		int  tryAward(const unsigned type, const int checkNum);
		void signTickUpdate(const unsigned type);
	private:
		virtual void classLoad();
		virtual void classFinal();
		virtual void _auto_update();
		virtual bool _auto_save();
		MONEYACTIVITY::ptrData dataList[MONEYACTIVITY::money_activity_num];
	};
}
#include "gamer.h"
#include "chat.h"
#include "zip_file.hpp"
//#include "king_fight.h"
#include "warlords_system.h"
#include "worldboss_system.h"
#include "task_mgr.h"
#include "discount.h"
#include "common_protocol.h"
#include "game_server.h"

namespace gg
{
	Gamer* const Gamer::_Instance = new Gamer();

	//////////////////////////////////////////////////////////////////////
	//���߽���
	struct OnlineBoxData
	{
		unsigned limit;
		ActionBoxList box;
		STDMAP(int, double, MODULEMAP);
		MODULEMAP module;
	};
	static vector<OnlineBoxData> OnlineBoxList;

	////////////////////////////////////////////////////////////////////////
	//���߽���
	struct OffDayBox
	{
		int costGold;
		ActionBoxList box;
		STDMAP(int, double, MODULEMAP);
		MODULEMAP module;
	};
	static vector< OffDayBox > OffDayBoxList;


	/////////////////////////////////////////////////////////////////////////
	//7����뽱��
	static vector< ActionBoxList > LoginDayBoxList;


	/////////////////////////////////////////////////////////////////////////
	//�������
	static std::vector< std::string > FirstNameList, SecondNameList, BoyNameList, GirlNameList;

	std::string Gamer::randomName()
	{
		return FirstNameList[Common::randomUInt(0 , FirstNameList.size() -1)] +
			SecondNameList[Common::randomUInt(0, SecondNameList.size() - 1)];
	}

	std::string Gamer::randomBoyName()
	{
		return FirstNameList[Common::randomUInt(0, FirstNameList.size() - 1)] +
			BoyNameList[Common::randomUInt(0, BoyNameList.size() - 1)];
	}

	std::string Gamer::randomGirlName()
	{
		return FirstNameList[Common::randomUInt(0, FirstNameList.size() - 1)] +
			GirlNameList[Common::randomUInt(0, GirlNameList.size() - 1)];
	}

	//////////////////////////////////////////////////////////////////////////////
	//���鲹��
	static struct
	{
		ActionBoxList box;
		STDMAP(int, double, MODULEMAP);
		MODULEMAP module;
	}staticArmySupply;

	void Gamer::initData()
	{
		Common::createDirectories("./report/last_rep/");//���һ��ս��

		{
			//�������
			FirstNameList.clear();
			SecondNameList.clear();
			BoyNameList.clear();
			GirlNameList.clear();
			{
				Json::Value json = Common::loadJsonFile("./instance/gamer/first_name.json");
				for (unsigned i = 0; i < json.size(); i++)
				{
					FirstNameList.push_back(json[i].asString());
				}
			};
			{
				Json::Value json = Common::loadJsonFile("./instance/gamer/boy_name.json");
				for (unsigned i = 0; i < json.size(); i++)
				{
					BoyNameList.push_back(json[i].asString());
					SecondNameList.push_back(json[i].asString());
				}
			};
			{
				Json::Value json = Common::loadJsonFile("./instance/gamer/girl_name.json");
				for (unsigned i = 0; i < json.size(); i++)
				{
					GirlNameList.push_back(json[i].asString());
					SecondNameList.push_back(json[i].asString());
				}
			};
		};
		{//���߽���
			OnlineBoxList.clear();
			Json::Value json = Common::loadJsonFile("./instance/gamer/online_box.json");
			for (unsigned i = 0; i < json.size(); ++i)
			{
				Json::Value& sg_json = json[i];
				OnlineBoxData data;
				data.limit = sg_json["limit"].asUInt();
				data.box = actionFormatBox(sg_json["box"]);
				for (unsigned n = 0; n < sg_json["module"].size(); ++n)
				{
					data.module[sg_json["module"][n][0u].asInt()] = sg_json["module"][n][1u].asDouble();
				}
				OnlineBoxList.push_back(data);
			}
		};

		{//���߽���
			OffDayBoxList.clear();
			Json::Value json = Common::loadJsonFile("./instance/gamer/offday_box.json");
			for (unsigned i = 0; i < json.size(); ++i)
			{
				Json::Value& sg_json = json[i];
				OffDayBox data;
				data.costGold = sg_json["cost"].asInt();
				data.box = actionFormatBox(sg_json["box"]);
				for (unsigned n = 0; n < sg_json["module"].size(); ++n)
				{
					data.module[sg_json["module"][n][0u].asInt()] = sg_json["module"][n][1u].asDouble();
				}
				OffDayBoxList.push_back(data);
			}
		};
		{//���鲹��
			Json::Value json = Common::loadJsonFile("./instance/gamer/supply_box.json");
			staticArmySupply.box = actionFormatBox(json["box"]);
			for (unsigned n = 0; n < json["module"].size(); ++n)
			{
				staticArmySupply.module[json["module"][n][0u].asInt()] = json["module"][n][1u].asDouble();
			}
		};
		{//���뽱��
			LoginDayBoxList.clear();
			Json::Value json = Common::loadJsonFile("./instance/gamer/login_box.json");
			for (unsigned i = 0; i < json.size(); ++i)
			{
				Json::Value& sg_json = json[i];
				LoginDayBoxList.push_back(actionFormatBox(sg_json));
			}
		};
	}

	void Gamer::AccountLogin(net::Msg& m, Json::Value& r)
	{
		const int playerID = m.playerID;
		playerDataPtr player = player_mgr.getAccount(playerID);
		ReadJson;
		Json::Value& js_msg = js["msg"];
		const int res = js_msg["result_code"].asInt();
		const int netID = js_msg["net_id"].asInt();
		const string ipStr = js_msg["client_ip"].asString();
		if (res == res_sucess)
		{
			if (player)
			{
				playerBase& base = player->Info();
				if (js_msg.isMember("open_id"))//uid
				{
					base.setUID(js_msg["open_id"].asString());
				}
				if (js_msg.isMember("pid"))//cid
				{
					base.setCID(js_msg["pid"].asString());
				}
				if (js_msg.isMember("user_type"))//gid
				{
					base.setGID(js_msg["user_type"].asString());
				}
			}
			else
			{
				player = player_mgr.createNewAccount(
					playerID,
					js_msg.isMember("open_id") ? js_msg["open_id"].asString() : "",
					js_msg.isMember("pid") ? js_msg["pid"].asString() : "",
					js_msg.isMember("user_type") ? js_msg["user_type"].asString() : ""
				);
				if (!player)Return(r, err_create_role);
			}
		}
		//������֤��Ϣ
		m.netID = netID;
		m.protocolID = game_protocol::comomon::account_identify_resp;
		game_svr->async_send_to_gate(m);
	}

	void Gamer::Login(net::Msg& m, Json::Value& r)
	{
		ReadJsonArray;
		const int playerID = m.playerID;
		playerDataPtr player = player_mgr.getAccount(playerID);
		if (!player)Return(r, err_illedge);
		if (!player->isVaild())Return(r, err_null_player);
		onPlayerLoginReq(player);
		Return(r, res_sucess);
	}

	static bool isVaildFace(const Gender::SEX sex, const int faceID)
	{
		if (sex == Gender::Male)
		{
			if (faceID == 1526 ||
				faceID == 1946)
				return true;
		}
		else if(sex == Gender::Female)
		{
			if (faceID == 1085 ||
				faceID == 2534)
				return true;
		}
			
		return false;
	}

	void Gamer::CreateRole(net::Msg& m, Json::Value& r)
	{
		const int playerID = m.playerID;
		playerDataPtr player = player_mgr.getAccount(playerID);
		if (!player || player->isVaild())Return(r, err_illedge);
		ReadJsonArray;
		if (js_msg[3u].isNull() || js_msg[3u].asBool())Return(r, err_illedge_char);
		const string playerName = js_msg[0u].asString();
		if (playerName.empty())Return(r, err_illedge);
		const unsigned name_length = Common::SimpleCnEg(playerName);
		if (name_length < 3 || name_length > 12)Return(r, err_player_name_limit);
		const int playerSex = js_msg[1u].asInt();
		if (!(playerSex == Gender::Male || playerSex == Gender::Female))Return(r, err_illedge);
		const int faceID = js_msg[2u].asInt();
		if (!isVaildFace(Gender::SEX(playerSex), faceID))Return(r, err_illedge);
		const int res = player_mgr.createNewPlayer(player, playerName);
		if (res == res_sucess)
		{
			player->Info().setSex(Gender::SEX(playerSex));
			player->Info().setFace(faceID, true);
			player->Man().addMan(2300);
			int fomat[9] = { -1, 2300, -1, -1, -1, -1, -1, -1, -1 };
			player->WarFM().format(0, fomat);
			onPlayerLoginReq(player);
		}
		Return(r, res);
	}

	void Gamer::motifyName(net::Msg& m, Json::Value& r)
	{
		const int playerID = m.playerID;
		playerDataPtr player = player_mgr.getPlayer(playerID);
		if (!player)Return(r, err_illedge);//�Ƿ�����
		const unsigned rename_times = player->Info().renameTis();
		int cost = 5000;
		if (rename_times < 10)
		{
			cost = rename_times * 500 + (rename_times > 0 ? 1 : 0) * 500;
		}
		if (player->Res().getCash() < cost)Return(r, err_cash_not_enough);
		if (rename_times > 1 && player->Info().VipLv() < 2)Return(r, err_vip_lv_too_low);
		ReadJsonArray;
		if (js_msg[1u].isNull() || js_msg[1u].asBool())Return(r, err_illedge_char);
		const string playerName = js_msg[0u].asString();
		if (playerName.empty())Return(r, err_illedge);
		const unsigned name_length = Common::SimpleCnEg(playerName);
		if (name_length < 3 || name_length > 12)Return(r, err_player_name_limit);
		if (player_mgr.hasRegisterName(playerName))Return(r, err_role_name_conflict);
		if (player->motifyName(playerName))
		{
			player->Res().alterCash(-cost);
			player->Info().tickRename();
			Return(r, res_sucess);
		}
		Return(r, err_illedge);
	}

	void Gamer::motifyFace(net::Msg& m, Json::Value& r)
	{
		const int playerID = m.playerID;
		playerDataPtr player = player_mgr.getPlayer(playerID);
		if (!player)Return(r, err_illedge);//�Ƿ�����
		ReadJsonArray;
		const int faceID = js_msg[0u].asInt();
		if (!player->Face().openFace(faceID))Return(r, err_illedge);
		if (player->Res().getCash() < 10)Return(r, err_cash_not_enough);
		player->Info().setFace(faceID);
		player->Res().alterCash(-10);
		Return(r, res_sucess);
	}

	static zipFile reportFile(204800);//ս��������д��
	static void RecallShareReport(const int playerID, Json::Value oppInfo, const int checkOK, Json::Value reqMsg)
	{
		State::setState(gate_client::player_shared_rep_req);
		NumberCounter::Step();

		playerDataPtr player = player_mgr.getOnlinePlayer(playerID);
		if (!player)return;
		qValue json(qJson::qj_array);
		if (res_sucess != checkOK)
		{
			json.append(checkOK);
			player->sendToClientFillMsg(gate_client::player_shared_rep_resp, json);
			return;
		}
		qValue castJson(qJson::qj_array);
		castJson.append(chat_sys.ChatPackageQ(player));
		const bool isPlayer = oppInfo[3u].asBool();
		bool isOK = false;
		if (isPlayer)
		{
			const int oppID = oppInfo[0u].asInt();
			playerDataPtr oppPlayer = player_mgr.getPlayer(oppID);
			if (oppPlayer)
			{
				castJson.append(true);
				castJson.append(chat_sys.ChatPackageQ(oppPlayer));
				isOK = true;
			}
		}
		if (!isOK)
		{
			castJson.append(false);
			string oppName = oppInfo[1u].asString();
			castJson.append(oppName);
		}
		const unsigned channel = reqMsg[0u].asUInt();
		const string playerName = reqMsg[1u].asString();
		const string path_str = "./report/" + reqMsg[2u].asString();
		const int repID = chat_sys.toChatWindowsRep(path_str);
		if(repID < 0)
		{
			json.append(err_share_last_rep_busy);
			player->sendToClientFillMsg(gate_client::player_shared_rep_resp, json);
			return;
		}
		castJson.append(repID);
		//�㲥
		if (channel == CHAT::chat_all)
		{
			chat_sys.despatchAll(CHAT::server_own_rep_share, castJson);
		}
		else if (channel == CHAT::chat_kingdom)
		{
			if (!chat_sys.despatchKingdom(CHAT::server_own_rep_share, player->Info().Nation(), castJson))
			{
				json.append(err_no_join_kingdom);
				player->sendToClientFillMsg(gate_client::player_shared_rep_resp, json);
				return;
			}
		}
		else
		{
			if (!chat_sys.despatchPlayer(CHAT::server_own_rep_share, playerName, castJson, true))
			{
				json.append(err_chat_aim_not_find);
				player->sendToClientFillMsg(gate_client::player_shared_rep_resp, json);
				return;
			}
			chat_sys.despatchPlayer(CHAT::server_own_rep_share, player->ID(), castJson);
		}
		player->Res().alterShareTimes(-1);
		player->ShareLastCD = Common::gameTime() + 60;//60s
		json.append(res_sucess);
		player->sendToClientFillMsg(gate_client::player_shared_rep_resp, json);
	}

	static void CheckReport(const int playerID, Json::Value reqMsg)
	{
		const string path_str = "./report/" + reqMsg[2u].asString();
		Json::Value json = reportFile.read_json(path_str);
		Json::Value oppInfo = Json::objectValue;
		if (json.isNull())
		{
			LogicPost(boostBind(RecallShareReport, playerID, oppInfo, err_can_not_find_report, reqMsg));
			return;
		}
		Json::Value& atk_json = json["p"][0u];
		Json::Value& def_json = json["p"][1u];
		if (atk_json[0u].asInt() == playerID)
		{
			oppInfo = def_json;
		}
		else if (def_json[0u].asInt() == playerID)
		{
			oppInfo = atk_json;
		}
		else
		{
			LogicPost(boostBind(RecallShareReport, playerID, oppInfo, err_is_not_your_report, reqMsg));
			return;
		}
		LogicPost(boostBind(RecallShareReport, playerID, oppInfo, res_sucess, reqMsg));
	}
	
	void Gamer::SharePathRep(net::Msg& m, Json::Value& r)
	{
		playerDataPtr player = player_mgr.getPlayer(m.playerID);
		if (!player)Return(r, err_illedge);//�Ƿ�����
		if (player->Res().getShare() < 1)Return(r, err_share_times_is_out);
		ReadJsonArray;
		const unsigned channel = js_msg[0u].asUInt();
		const string playerName = js_msg[1u].asString();
		if (channel >= CHAT::user_channel)Return(r, err_illedge);
		unsigned now = Common::gameTime();
		if (player->ShareLastCD > now)Return(r, err_share_last_rep_cd_limit);
		if (channel == CHAT::chat_player)
		{
			if (!player_mgr.getOnlinePlayer(playerName))Return(r, err_chat_aim_not_find);
		}
		reportPost(boostBind(CheckReport, m.playerID, js_msg));
	}

	void Gamer::DailyCardUpdate(net::Msg& m, Json::Value& r)
	{
		playerDataPtr player = player_mgr.getPlayer(m.playerID);
		if (!player)Return(r, err_illedge);//�Ƿ�����
		player->DailyCard()._auto_update();
	}

	const static int salePrice[] = {250,500};
	void Gamer::DailyCardBuy(net::Msg& m, Json::Value& r)
	{
		playerDataPtr player = player_mgr.getPlayer(m.playerID);
		if (!player)Return(r, err_illedge);//�Ƿ�����
		ReadJsonArray;
		const int typeID = js_msg[0u].asInt();
		if (!DAILYCARD::isVaildCard(typeID))Return(r, err_illedge);
		if (player->Res().getGold() < salePrice[typeID])Return(r, err_gold_not_enough);
		const int res = player->DailyCard().addCard(typeID);
		if (res == res_sucess)
		{
			player->Res().alterGold(-salePrice[typeID]);
			Log(DBLOG::strLogDailyCard, player, 0, typeID, salePrice[typeID]);
			r[strMsg][1u] = typeID;
		}
		Return(r, res);
	}

	void Gamer::DailyCardAward(net::Msg& m, Json::Value& r)
	{
		playerDataPtr player = player_mgr.getPlayer(m.playerID);
		if (!player)Return(r, err_illedge);//�Ƿ�����
		ReadJsonArray;
		const int typeID = js_msg[0u].asInt();
		if (!DAILYCARD::isVaildCard(typeID))Return(r, err_illedge);
		int rwnum = 0;
		const int res = player->DailyCard().wardCard(typeID, rwnum);
		if (res == res_sucess)
		{
			r[strMsg][1u] = rwnum;
		}
		Return(r, res);
	}

	void Gamer::LoginDayBox(net::Msg& m, Json::Value& r)
	{
		playerDataPtr player = player_mgr.getPlayer(m.playerID);
		if (!player)Return(r, err_illedge);//�Ƿ�����
		ReadJsonArray;
		const unsigned reward_day = js_msg[0u].asUInt();
		if(reward_day < 1)Return(r, err_illedge);
		if (reward_day > player->Info().loginBoxDay())Return(r, err_illedge);
		const unsigned idx = reward_day - 1;
		if (!player->Info().canGetBox(idx))Return(r, err_illedge);
		if (idx >= LoginDayBoxList.size())Return(r, err_illedge);
		const int res = actionDoBox(player, LoginDayBoxList[idx]);
		if (res == res_sucess)
		{
			r[strMsg][1u] = actionRes();
			player->Info().setLoginBox(idx);
			Log(DBLOG::strLoginDayBox, player, -1, reward_day, "", "", "", "", "", "", r[strMsg][1u].toIndentString());
		}
		else
		{
			r[strMsg][1u] = actionError();
		}
		Return(r, res);
	}

	static int isSupplyTime()
	{
		const unsigned now = Common::gameTime();
		const unsigned zero_day = Common::timeZero(now);
		if (
			now >= (zero_day + 12 * HOUR) &&
			now <= (zero_day + 14 * HOUR)
			)return 0;
		if (
			now >= (zero_day + 19 * HOUR + 30 * MINUTE) &&
			now <= (zero_day + 22 * HOUR + 30 * MINUTE)
			)return 1;
		return -1;
	}

	void Gamer::SupplyGet(net::Msg& m, Json::Value& r)
	{
		playerDataPtr player = player_mgr.getPlayer(m.playerID);
		if (!player)Return(r, err_illedge);//�Ƿ�����
		const int type = isSupplyTime();
		if (type < 0)Return(r, err_is_not_in_army_supply_time);
		if (type == 0 && player->Res().getSupplyNoon())Return(r, err_been_get_army_supply);
		if (type == 1 && player->Res().getSupplyNight())Return(r, err_been_get_army_supply);
		for (OnlineBoxData::MODULEMAP::const_iterator it = staticArmySupply.module.begin(); it != staticArmySupply.module.end(); ++it)
		{
			setActionRate(it->first, ACTION::Rate(1.0, player->LV() * it->second));
		}
		const int res = actionDoBox(player, staticArmySupply.box, false);
		if (res != res_sucess)
		{
			r[strMsg][1u] = actionError();
		}
		else
		{
			r[strMsg][1u] = actionRes();
			Log(DBLOG::strLogArmySupplyBox, player, -1, "", "", "", "", "", "", "",
				r[strMsg][1u].toIndentString());
			if (0 == type)player->Res().setNoonTrue();
			else player->Res().setNightTrue();
		}
		Return(r, res);
	}


	void Gamer::OfflineReward(net::Msg& m, Json::Value& r)
	{
		playerDataPtr player = player_mgr.getPlayer(m.playerID);
		if (!player)Return(r, err_illedge);//�Ƿ�����
		ReadJsonArray;
		const int typeID = js_msg[0u].asInt();
		if (typeID < 0 || typeID > 2)Return(r, err_illedge);
		const unsigned day = player->Offline().OffDay();
		if (day < 1)Return(r, err_illedge);
		const int times = day > 30 ? 30 : day;
		const OffDayBox& box = OffDayBoxList[typeID];
		if (box.costGold * times > player->Res().getCash())Return(r, err_cash_not_enough);
		for (OffDayBox::MODULEMAP::const_iterator it = box.module.begin(); it != box.module.end(); ++it)
		{
			setActionRate(it->first, ACTION::Rate(1.0 * times, player->LV() * it->second * times));
		}
		const int res = actionDoBox(player, box.box, false);
		if (res == res_sucess)
		{
			player->Offline().resetOffDay();
			player->Res().alterCash(-box.costGold * times);
			r[strMsg][1u] = day;
			r[strMsg][2u] = typeID;
			r[strMsg][3u] = box.costGold;
			Json::Value res_json = actionRes();
			r[strMsg][4u] = res_json;
			Log(DBLOG::strOfflineWard, player, -1, day, typeID, box.costGold * times, "", "", "", "", res_json.toIndentString());
			Return(r, res_sucess);
		}
		r[strMsg][1u] = actionError();
		Return(r, res);
	}

	void Gamer::logProcess(net::Msg& m, Json::Value& r)
	{
		ReadJsonArray;
		const int process = js_msg[0u].asInt();
		playerDataPtr player = player_mgr.getAccount(m.playerID);
		if (!player)Return(r, err_illedge);
		if (player->isVaild())
		{
			Log(DBLOG::strLogProcessRecord, -1, m.playerID, player->Name(), player->LV(), player->War().lastWinMap(), process);
		}
		else
		{
			Log(DBLOG::strLogProcessRecord, -1, m.playerID, "", 0, 0, process);
		}
		Return(r, res_sucess);
	}

	void Gamer::GMPushAnnouce(net::Msg& m, Json::Value& r)
	{
		static Json::Value nullValue = Json::objectValue;
		player_mgr.sendToAll(gate_client::player_new_push_message_annouce_resp, nullValue);
		Return(r, res_sucess);
	}

	void Gamer::motifyProcess(net::Msg& m, Json::Value& r)
	{
		playerDataPtr player = player_mgr.getPlayer(m.playerID);
		if (!player)Return(r, err_illedge);
		ReadJsonArray;
		const int process = js_msg[0u].asInt();
		player->Info().setProcess(process);
		TaskMgr::update(player, Task::NewProgress, process);
		Return(r, res_sucess);
	}

	void Gamer::LinkLogin(net::Msg& m, Json::Value& r)
	{
		player_mgr.playerLogin(m.playerID);
	}

	void Gamer::LinkLogout(net::Msg& m, Json::Value& r)
	{
		player_mgr.playerLogout(m.playerID);
	}

	void Gamer::GateReset(net::Msg& m, Json::Value& r)
	{
		player_mgr.gateResetReq();
	}

	void Gamer::GamerTable(net::Msg& m, Json::Value& r)
	{
		const int playerID = m.playerID;
		playerDataPtr player = player_mgr.getPlayer(playerID);
		if (!player)Return(r, err_illedge);//�Ƿ�����
		ReadJsonArray;
		playerDataPtr aim_player;
		if (js_msg[0u].isInt())
			aim_player = player_mgr.getPlayer(js_msg[0u].asInt());
		else if (js_msg[0u].isString())
			aim_player = player_mgr.getPlayer(js_msg[0u].asString());
		if (!aim_player)Return(r, err_player_no_found);//�Ƿ�����
		Json::Value& json = r[strMsg];
		json.append(res_sucess);
		json.append(aim_player->Name());
		json.append(aim_player->LV());
		json.append(aim_player->Info().Nation());
		json.append(0/*Ĭ�����һ����Ч������ ����ԭ��ְ������*/);
		json.append(aim_player->Info().VipLv());//vip�ȼ�
		json.append(aim_player->WarFM().currentBV());//��ǰս����
		json.append(aim_player->Info().RankNo_());//ȺӢ������
		json.append(aim_player->Info().Face());//ͷ��ID
		json.append(aim_player->War().currenChanllenge());//��ͼ����
		json.append(aim_player->Info().NationOf_());//���ҹ�λ
		json.append(aim_player->isOnline());//�Ƿ�����
		json.append(aim_player->Info().LastOnline());//������ʱ��
	}

	void Gamer::OnlineBoxUpdate(net::Msg& m, Json::Value& r)
	{
		playerDataPtr player = player_mgr.getPlayer(m.playerID);
		if (!player)Return(r, err_illedge);//�Ƿ�����
		player->OnlineBox()._auto_update();
	}

	void Gamer::OnlineBoxGet(net::Msg& m, Json::Value& r)
	{
		playerDataPtr player = player_mgr.getPlayer(m.playerID);
		if (!player)Return(r, err_illedge);//�Ƿ�����
		ReadJsonArray;
		const unsigned idx = js_msg[0u].asUInt();
		const unsigned long_time = player->OnlineBox().onlineDur();
		if (player->OnlineBox().isBeenSign(idx))Return(r, err_illedge);
		if (idx >= OnlineBoxList.size())Return(r, err_illedge);
		const OnlineBoxData& data_box = OnlineBoxList[idx];
		if (long_time < data_box.limit)Return(r, err_illedge);
		for (OnlineBoxData::MODULEMAP::const_iterator it = data_box.module.begin(); it != data_box.module.end(); ++it)
		{
			setActionRate(it->first, 
				ACTION::Rate(discout_sys.getRate(Discount::online_reward_rate), 
					player->LV() * it->second * discout_sys.getRate(Discount::online_reward_rate))
			);
		}
		const int res = actionDoBox(player, data_box.box, false);
		if (res != res_sucess)
		{
			r[strMsg][1u] = actionError();
		}
		else
		{
			r[strMsg][1u] = actionRes();
			Log(DBLOG::strLogOnlineBox, player, -1, idx, "", "", "", "", "", "",
				r[strMsg][1u].toIndentString());
			player->OnlineBox().goSignBox(idx);
			player->Daily().tickTask(DAILY::online_reward);
		}
		Return(r, res);
	}

	void Gamer::TestAnnouce(net::Msg& m, Json::Value& r)
	{
		const int playerID = m.playerID;
		playerDataPtr player = player_mgr.getPlayer(playerID);
		if (!player)Return(r, err_illedge);//�Ƿ�����
		string test = "print(2333333)";
		player->sendToClient(gate_client::resp_lua_string, test);
		return;		
	}
}

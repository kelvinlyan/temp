#pragma once

#include "action_system.h"
#include "commom.h"
#include "dbDriver.h"

#define shops_mgr (*gg::WorldShop::_Instance)

namespace gg
{
	namespace SHOP
	{
		struct Data
		{
		public:
			Data(const Json::Value& info);

			int _id;
			int _type_price;//��������
			int _price_num;//��������
			int _buy_num;
			int _base_weight;
			int _add_weight;
			int _max_weight;
			unsigned _type;
			int _nation;
			ActionBoxList _box;

			int _tmp_weight;
		};

		BOOSTSHAREPTR(Data, ptrData);
		//STDVECTOR(ptrData, ListData);
		typedef std::vector< std::vector< std::vector< ptrData > > > ListData;
		STDMAP(int, ptrData, MapData);
		STDVECTOR(int, ListCost);

		class Manager
		{
		public:
			Manager(const int type);
			ptrData getShopData(const int id);
			vector<ptrData> getShopList(playerDataPtr player);
			int getFlushCost(unsigned times);
			bool flushLimit(unsigned times);
			const int Type;
		private:
			void initFile();
			MapData _shop_map;
			ListData _shop_random;
			ListCost _flush_costs;
			std::vector<unsigned> _allot;//����
			unsigned _flush_limit;//ÿ��ˢ�´�������
		};
	}

	class WorldShop
	{
	public:
		static WorldShop* const _Instance;
		void initData();
		SHOP::ptrData getShopData(const int type, const int id);
		vector<SHOP::ptrData> getShopList(const int type, playerDataPtr player);
		bool flushLimit(const int type, unsigned times);
		int getFlushCost(const int type, unsigned times);
		
		DeclareRegFunction(shopInfo);
		DeclareRegFunction(buy);
		DeclareRegFunction(flush);
		
		Resource ResolveObjectJson(Json::Value& json);
		Resource ResolveArrayJson(Json::Value& json);
		Resource PackageData(const int type, const int num);
		Resource PackageData(const int type, const int itemID, const int num);
		
		int checkRes(const int type, const int num, playerDataPtr player);
		int checkItem(const int type, const int itemID, const int num, playerDataPtr player);
		void cutRes(const int type, const int num, playerDataPtr player);
		void cutItem(const int type, const int itemID, const int num, playerDataPtr player);

		int checkCommon(const Resource& data, playerDataPtr player);
		void cutCommon(const Resource& data, playerDataPtr player);
	private:
		BOOSTSHAREPTR(SHOP::Manager, ptrManager);
		STDVECTOR(ptrManager, ListManager);
		ListManager ManagerShops;
	};
}

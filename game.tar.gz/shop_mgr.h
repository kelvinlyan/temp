#pragma once

#include "action_system.h"
#include "gamer_data.h"

namespace gg
{
	struct ShopData
	{
		public:
			ShopData(const Json::Value& info);

			int _id;
			int _price;
			int _buy_num;
			int _base_weight;
			int _add_weight;
			int _max_weight;
			int _type;
			int _nation;
			ACTION::BoxList _box;

			int _tmp_weight;
	};

	BOOSTSHAREPTR(ShopData, ShopDataPtr);
	STDVECTOR(ShopDataPtr, ShopDataList);
	STDMAP(int, ShopDataPtr, ShopDataMap);

	class ShopDataMgr
	{
		public:
			void init(const Json::Value& info);
			ShopDataPtr getShopData(int id);
			ShopDataList getShopList(playerDataPtr d);

		private:
			ShopDataMap _shop_map;
			ShopDataList _shop_rd[Kingdom::nation_num + 1][4]; 
	};
}

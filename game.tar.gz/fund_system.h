//###################################
//create by linxing
//2016-06-20
//###################################

#pragma once
#ifndef FUND_SYSTEM
#define FUND_SYSTEM

#include "dbDriver.h"
#include "action_system.h"

#define fund_sys (*gg::fund_system::_Instance)

namespace gg
{
	class fund_system
	{
	public:
		fund_system();
		~fund_system();

		void initData();

		//���ؽ���������
		//�磺"id:1,lv:30,box:[{"aID":1,"v":3000},{"aID":12,"id":10007,"v":1}]"
		/*std::string getIdLvBoxDesc(const int& id)
		{
		return _allDesc[id];
		}
		*/
		Json::Value getBoxJson(const int& id)
		{
			if (_idBoxJson.find(id) != _idBoxJson.end())
			{
				return _idBoxJson[id];
			}
			else
			{
				return Json::Value::null;
			}
		}

		//����log�Ļ��棨id��������
		std::string getBoxDesc(const int& id)
		{
			if (_idBoxDesc.find(id) != _idBoxDesc.end())
			{
				return _idBoxDesc[id];
			}
			else
			{
				return std::string("wrong");
			}
		}

		typedef struct fund_reward_struct
		{//�ȼ�����������

		 //����id
			int id;
			//������ȡ��Ҫ��ĵȼ�
			int r_lv;
			//ͨ�ý�������
			ACTION::BoxList box_list;
		} FundReward;
		STDMAP(int, FundReward, RewardList);

		inline int VipLimit() { return _vip_lv; }
		inline int GoldCost() { return _gold; }
		inline RewardList& GetRewards() { return _reward_list; }
	public:
		DeclareRegFunction(reqFundInfo);
		DeclareRegFunction(reqFundBuy);
		DeclareRegFunction(reqFundGetReward);
	public:
		static fund_system* const _Instance;

	private:
		/// ���齱��id�Ƿ���Ч
		bool isValidFundId(const int& id) const;

		int _vip_lv;
		int _gold;
		RewardList _reward_list;//keyΪ�ȼ�������id
		std::map<int, std::string> _idBoxDesc;
		std::map<int, Json::Value> _idBoxJson;
	};
}

#endif

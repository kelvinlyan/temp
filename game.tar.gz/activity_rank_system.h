//###################################
//create by Jim
//2016-11-29
//###################################

#pragma once 

#include "dbDriver.h"
#include "cc_rank_activity.h"

#define activity_rank_sys (*gg::ActivityRankSystem::_Instance)

namespace gg
{
	class ActivityRankSystem
	{
	public:
		static ActivityRankSystem* const _Instance;
		void initData();

		void timeData(const int type, Json::Value& json);
		void updateName(playerDataPtr player);
		unsigned createID(const int type);
		unsigned activityID(const int type);
		bool isOpen(const int type);//������Ƿ��ڿ���
		bool isRun(const int type);//��Ƿ����ڽ���
		bool isOver(const int type, const unsigned create_id);//��Ƿ��Ѿ�����(ҳ����ܻ�����)
		bool isClose(const int type, const unsigned create_id);//��Ƿ��Ѿ���ȫ�ر�(�����»�����Ѿ���ȫ�������)
		void insertRank(const int type, playerDataPtr player);
		bool findActionBox(ActionBoxList& box, const int type, const int reach);
		Json::Value packageOverBox(const int type, const int create_id, const int value, boost::unordered_set<int>& filter);

		DeclareRegFunction(GMUpdate);//update
		DeclareRegFunction(GMMotify);//add motify remove
		DeclareRegFunction(UpdatePlayer);//update
		DeclareRegFunction(UpdateList);//update
		DeclareRegFunction(UpdateReach);//update
		DeclareRegFunction(GetReachBox);//reach box
		DeclareRegFunction(UpdateTitle);//title base
		DeclareRegFunction(UpdateRuler);//update ruler
	private:
		RANKACTIVITY::ActivityCCRank* _activity_data[ActivityRankEnum::activity_rank_num];
		struct ReachBoxBackUp
		{
			int _type;
			unsigned _create_id;
			RANKACTIVITY::ActivityCCRank::_box_list_type _box_list;
		};
		BOOSTSHAREPTR(ReachBoxBackUp, ptrReachBoxBackUp);
		typedef std::map< unsigned, ptrReachBoxBackUp, std::less<unsigned> >BackUpMapType;
		void save_back_up_reach(const ReachBoxBackUp& data);
		void remove_back_up_reach(const int type, const unsigned id);
		BackUpMapType _back_up_reach_map[ActivityRankEnum::activity_rank_num];
	};
}
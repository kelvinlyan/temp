//###################################
//create by Jim
//2016-06-01
//###################################

#pragma once 

#include "dbDriver.h"

#define money_sys (*gg::MoneyActivity::_Instance)

namespace gg
{
	class MoneyActivity
	{
	public:
		static MoneyActivity* const _Instance;
		void initData();
		unsigned currentRewardKey(const unsigned type);
		bool checkMatchCurrent(const unsigned type, const unsigned ct);
		ACTION::BoxList currenReward(const unsigned type, const int checkNum);
		vector<Json::Value> backUpReward(const unsigned type, const unsigned ct, const std::set<int>& filter, const int total_check);
		bool hasReward(const unsigned type, const unsigned ct, const std::set<int>& filter, const int total_check);

		void tickNum(playerDataPtr player, const unsigned type, const int num);

		DeclareRegFunction(GmUpdate);//add motify remove
		DeclareRegFunction(GmMotify);//add motify remove
		DeclareRegFunction(GetTitle);//get title
		DeclareRegFunction(GetDetail);//get detail
		DeclareRegFunction(WonReward);//get reward
		DeclareRegFunction(UpdateOwn);//get reward
		DeclareRegFunction(UpdateRed);//get red
	};
}
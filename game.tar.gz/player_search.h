#pragma once

#include "auto_base.h"

namespace gg
{
	namespace Search
	{
		const static unsigned fixWWTimes = 10;
		const static unsigned fixCSTimes = 11;
		const static unsigned zeroDiv = 10;
		const static unsigned recordWWTimes = 100;
	}

	class playerSearch
		: public _auto_player
	{
	public:
		playerSearch(playerData* const own);

		//��������
		void update();
		void dailyTick();

	private:
		virtual bool _auto_save();
		virtual void _auto_update();
		virtual void classLoad();
	public:
		inline bool isFreeWW() { return Common::gameTime() > _free_search_ww; }
		inline bool isFreeCS() { return Common::gameTime() > _free_search_cs; }
		inline unsigned singleCD() { return _single_cd; }
		inline unsigned multiCD() { return _multi_cd; }
		inline bool isFirstWW() { return _first_search_ww < Search::fixWWTimes; }
		inline bool isFirstCS() { return _first_search_cs < Search::fixCSTimes; }
		inline unsigned FirstWW() { return _first_search_ww; }
		inline unsigned FirstCS() { return _first_search_cs; }
		inline unsigned WWSearch() { return _ww_search_times; }
		inline unsigned CSSearch() { return _cs_search_times; }
	public:
		inline void nextFreeWW() { _free_search_ww = Common::gameTime() + 8 * HOUR; _sign_update(); }
		inline void nextFreeCS() { _free_search_cs = Common::gameTime() + DAY; _sign_update(); }
		inline void nextSingleCD() { _single_cd = Common::gameTime() + 5 * MINUTE;_sign_update(); }
		inline void nextMultiCD() { _multi_cd = Common::gameTime() + 5 * MINUTE; _sign_update(); }
		inline void nextFirstWW() { if (_first_search_ww < Search::fixWWTimes) { ++_first_search_ww; _sign_auto(); } }
		inline void nextFirstCS() { if (_first_search_cs < Search::fixCSTimes) { ++_first_search_cs; _sign_auto(); } }
		inline void nextWWSearch() { if (_ww_search_times < Search::recordWWTimes) { ++_ww_search_times; _sign_auto(); } }
		inline void nextCSSearch() { ++_cs_search_times %= Search::zeroDiv; _sign_auto(); }
	private:
		unsigned _single_cd;//������
		unsigned _multi_cd;//������

		unsigned _ww_search_times;//������ȡ����
		unsigned _cs_search_times;//(���)�������
		unsigned _first_search_ww;//��ʼn��
		unsigned _first_search_cs;//��ʼn��
		unsigned _free_search_ww;//�������
		unsigned _free_search_cs;//������
	};
}

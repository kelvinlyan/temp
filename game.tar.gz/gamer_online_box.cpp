#include "gamer_online_box.h"
#include "dbDriver.h"

namespace gg
{
	playerOnlineBox::playerOnlineBox(playerData* const own) : _auto_player(own)
	{
		signBox = 0;
		countTime = 0;
		tickTime = Common::gameTime();
	}

	void playerOnlineBox::classLoad()
	{
		mongo::BSONObj key = BSON(strPlayerID << Own().ID());
		mongo::BSONObj obj = db_mgr.FindOne(DBN::dbPlayerOnlineBox, key);
		if (obj.isEmpty())return;
		signBox = obj["sn"].eoo() ? 0 : obj["sn"].Int();
		countTime = (unsigned)obj["ct"].Int();
		tickTime = (unsigned)obj["tt"].Int();
	}

	bool playerOnlineBox::_auto_save()
	{
		mongo::BSONObj key = BSON(strPlayerID << Own().ID());
		mongo::BSONObj obj = BSON(strPlayerID << Own().ID() << 
			"sn" << signBox << "ct" << countTime << "tt" << tickTime);
		return db_mgr.SaveMongo(DBN::dbPlayerOnlineBox, key, obj);
	}

	void playerOnlineBox::offline()
	{
		const unsigned now = Common::gameTime();
		if (now > tickTime)
		{
			countTime += (now - tickTime);
			tickTime = now;
			_sign_save();
		}
	}

	unsigned playerOnlineBox::onlineDur()
	{
		unsigned long_time = countTime;
		const unsigned now = Common::gameTime();
		if (now > tickTime)
		{
			long_time += (now - tickTime);
		}
		return long_time;
	}

	void playerOnlineBox::reset()
	{
		signBox = 0;
		countTime = 0;
		tickTime = Common::gameTime();
		_sign_auto();
	}

	void playerOnlineBox::online()
	{
		tickTime = Common::gameTime();
		_sign_auto();
	}

	bool playerOnlineBox::isBeenSign(const unsigned idx)
	{
		if (idx > 31)return true;
		return (signBox & (0x0001 << idx)) != 0x0;
	}

	void playerOnlineBox::goSignBox(const unsigned idx)
	{
		if (idx > 31)return;
		signBox |= (0x0001 << idx);
		_sign_auto();
	}

	void playerOnlineBox::_auto_update()
	{
		qValue json(qJson::qj_object);
		json.addMember("tt", tickTime);
		json.addMember("ct", countTime);
		json.addMember("sn", signBox);
		qValue data_json(qJson::qj_array);
		data_json.append(res_sucess).append(json);
		Own().sendToClientFillMsg(gate_client::player_online_box_update_resp, data_json);
	}


}
//###################################
//create by Jim
//2015-11-05
//###################################

#pragma once

#include "playerManager.h"
#include "commom.h"
#include <iostream>
#include "timmer.hpp"

namespace gg
{
//�鿴bson�ֶ��Ƿ�Ϊ��
#define checkNotEoo(bs)\
	if(! bs.eoo())


	//
	namespace DBN
	{
		//���ݿ����ֽ���������Ӣ����ĸ,���ֺ��»���.����ĸ��ͷ.��ֹ�����κ��ַ�//���������������
		//system
		const static string dbSeason = "season";
		const static string dbTimeTable = "time_table";
		const static string dbKingFight = "king_fight";
		const static string dbChapterReport = "chapter_report_base";
		const static string dbKingFightKingRecord = "king_record";
		const static string dbRescue = "rescue_db";//������Ϣ
		const static string dbKingdom = "kingdom";
		const static string dbWorldBoss = "worldBoss";	
		const static string dbTeamWar = "team_war";
		const static string dbCompensate = "compensate";
		const static string dbRollData = "roll_data";
		const static string dbHeroPartySystem = "hero_party_system";
		const static string dbMallSystem = "mall_system";
		const static string dbCommonEmails = "common_emails";
		const static string dbCustomGift = "custom_gift";//�Զ������
		const static string dbDaysActivity = "days_activity";
		const static string dbConfigBackup = "config_backup";
		const static string dbTickStander = "tick_stander";
		const static string dbMoneyActivity = "money_activity";
		const static string dbMoneyActivityBackUp = "money_activity_back_up";
		const static string dbKingdomWarCityBattle = "kingdomwar_city_battle";
		const static string dbKingdomWarCityBase = "kingdomwar_city_base"; 
		const static string dbChatForbid = "chat_forbid";
		const static string dbKingdomWarNpc = "kingdomwar_npc";
		const static string dbKingdomWarNationTask = "kingdomwar_nation_task";
		const static string dbKingdomWarGreatEvent = "kingdomwar_great_event";
		const static string dbKingdomWarShadow = "kingdomwar_shadow";


		//player
		const static string dbPlayerBase = "player";
		const static string dbPlayerTick = "player_tick";
		const static string dbPlayerMan = "player_man";
		const static string dbPlayerRes = "player_resource";
		const static string dbPlayerWar = "player_war_m";
		const static string dbPlayerWarSnap = "player_war_snap";//ս�ۿ���
		const static string dbPlayerManInfo = "player_man_info";
		const static string dbPlayerTask = "player_task";
		const static string dbPlayerWarFM = "player_warfm";
		const static string dbPlayerWarFMBase = "player_warfm_base";
		const static string dbPlayeCard = "player_card";
		const static string dbPlayeCardFM = "player_card_fm";
		const static string dbPlayeCardBase = "player_card_base";
		const static string dbPlayerItem = "player_item";
		const static string dbPlayerItemInfo = "player_item_info";
		const static string dbPlayerSearch = "player_search";
		const static string dbPlayerCardPoke = "player_card_poke";
		const static string dbPlayerCount = "player_count";
		const static string dbPlayerCarPos = "player_car_pos";
		const static string dbPlayerTrade = "player_trade";
		const static string dbPlayerTradeItem = "player_trade_item";
		const static string dbPlayerTradeBuff = "player_trade_buff";
		const static string dbPlayerTradeRich = "player_trade_rich";
		const static string dbPlayerHeroParty = "player_heroparty";
		const static string dbPlayerKingFight = "player_king_fight";
		const static string dbPlayerRescue = "player_rescue";
		const static string dbPlayerTeam = "player_team";//���ս//����ս
		const static string dbPlayerKingdom = "player_kingdom";
		const static string dbPlayerVip = "player_vip";
		const static string dbPlayerWorldBoss = "player_worldBoss";
		const static string dbPlayerTaskEventData = "player_taskEventData";
		const static string dbPlayerLastRep = "player_last_rep";
		const static string dbPlayerResearch = "player_reseach";
		const static string dbPlayerMarket = "player_market";
		const static string dbPlayerOrders = "player_orders";
		const static string dbPlayerAffair = "player_affair";
		const static string dbPlayerWarLords = "player_warlords";
		const static string dbPlayerEmail = "player_email";
		const static string dbPlayerMall = "player_mall";
		const static string dbPlayerDaily = "player_daily";
		const static string dbPlayerBuilds = "player_builds";
		const static string dbPlayerBuildTeams = "player_build_teams";
		const static string dbPlayerAdmin = "player_admin";
		const static string dbPlayerOffline = "player_offline";
		const static string dbPlayerCustom = "player_custom";//�Զ���
		const static string dbPlayerDaysActivity = "player_days_activity";
		const static string dbPlayerOnlineBox = "player_online_box";//���߽���
		const static string dbPlayerMoneyActivity = "player_money_activity";
		const static string dbPlayerSign = "player_sign";
		const static string dbPlayerDailyCard = "player_daily_card";//�¿� ������
		const static string dbPlayerFund = "player_fund";//�ȼ�����
		const static string dbPlayerKingdomWar = "player_kingdomwar";
		const static string dbPlayerKingdomWarShop = "player_kingdomwar_shop";
		const static string dbPlayerKingdomWarOutput = "player_kingdomwar_output";
		const static string dbPlayerKingdomWarFM = "player_kingdomwar_fm";
		const static string dbPlayerKingdomWarPos = "player_kingdomwar_pos";
		const static string dbPlayerKingdomWarBox = "player_kingdomwar_box";
		const static string dbPlayerKingdomWarTask = "player_kingdomwar_task";
		const static string dbPlayerPatrol = "player_patrol";//��Ů��ѡѲ��
		const static string dbPlayerOpenActivity = "player_open_activity";//��Ů��ѡѲ��
	}

	static void ensureIndex()
	{
		//��������
		
		//system
		db_mgr.EnsureIndex(DBN::dbSeason, BSON("key" << 1));
		db_mgr.EnsureIndex(DBN::dbTimeTable, BSON("key" << 1));
		db_mgr.EnsureIndex(DBN::dbKingFight, BSON("key" << 1));
		db_mgr.EnsureIndex(DBN::dbKingFightKingRecord, BSON("nt" << 1 << "bt" << 1));
		db_mgr.EnsureIndex(DBN::dbKingdom, BSON("key" << 1));
		db_mgr.EnsureIndex(DBN::dbChapterReport, BSON("ci" << 1));
		db_mgr.EnsureIndex(DBN::dbRescue, BSON("pi" << 1 << "ri" << 1));
		db_mgr.EnsureIndex(DBN::dbWorldBoss, BSON("key" << 1));
		db_mgr.EnsureIndex(DBN::dbTeamWar, BSON(strPlayerID << 1 << "idx" << 1));
		db_mgr.EnsureIndex(DBN::dbCompensate, BSON("key" << 1));
		db_mgr.EnsureIndex(DBN::dbRollData, BSON("nid" << 1));
		db_mgr.EnsureIndex(DBN::dbHeroPartySystem, BSON("key" << 1));
		db_mgr.EnsureIndex(DBN::dbMallSystem, BSON("gid" << 1));
		db_mgr.EnsureIndex(DBN::dbCustomGift, BSON("key" << 1));
		db_mgr.EnsureIndex(DBN::dbTickStander, BSON("key" << 1));
		db_mgr.EnsureIndex(DBN::dbMoneyActivity, BSON("key" << 1));
		db_mgr.EnsureIndex(DBN::dbMoneyActivityBackUp, BSON("key" << 1 << "ct" << 1));//�����
		db_mgr.EnsureIndex(DBN::dbKingdomWarCityBattle, BSON("ci" << 1));
		db_mgr.EnsureIndex(DBN::dbKingdomWarCityBase, BSON("ci" << 1));
		db_mgr.EnsureIndex(DBN::dbChatForbid, BSON(strPlayerID << 1));
		db_mgr.EnsureIndex(DBN::dbKingdomWarNpc, BSON("ni" << 1));
		db_mgr.EnsureIndex(DBN::dbKingdomWarNationTask, BSON("nt" << 1));
		db_mgr.EnsureIndex(DBN::dbKingdomWarGreatEvent, BSON("t" << 1));
		db_mgr.EnsureIndex(DBN::dbKingdomWarShadow, BSON("i" << 1));

		//player //����ʹ��������� һ����д��һ����������, û���������� ��ֹ������
		//�������д���ݵ����keyҲ���������//��ȡ��ʱ����Ե���
		db_mgr.EnsureIndex(DBN::dbPlayerBase, BSON(strPlayerID << 1 << strPlayerName << 1));
		db_mgr.EnsureIndex(DBN::dbPlayerTick, BSON(strPlayerID << 1));
		db_mgr.EnsureIndex(DBN::dbPlayerMan, BSON(strPlayerID << 1 << "rid" << 1));
		db_mgr.EnsureIndex(DBN::dbPlayerRes, BSON(strPlayerID << 1));
		db_mgr.EnsureIndex(DBN::dbPlayerWarSnap, BSON(strPlayerID << 1));
		db_mgr.EnsureIndex(DBN::dbPlayerManInfo, BSON(strPlayerID << 1));
		db_mgr.EnsureIndex(DBN::dbPlayerTask, BSON(strPlayerID << 1));
		db_mgr.EnsureIndex(DBN::dbPlayerWarFM, BSON(strPlayerID << 1 << "fid" << 1));
		db_mgr.EnsureIndex(DBN::dbPlayerWarFMBase, BSON(strPlayerID << 1));
		db_mgr.EnsureIndex(DBN::dbPlayeCard, BSON(strPlayerID << 1 << "cid" << 1));
		db_mgr.EnsureIndex(DBN::dbPlayeCardBase, BSON(strPlayerID << 1));
		db_mgr.EnsureIndex(DBN::dbPlayeCardFM, BSON(strPlayerID << 1)); 
		db_mgr.EnsureIndex(DBN::dbPlayerItem, BSON(strPlayerID << 1 << "lid" << 1));
		db_mgr.EnsureIndex(DBN::dbPlayerSearch, BSON(strPlayerID << 1));
		db_mgr.EnsureIndex(DBN::dbPlayerItemInfo, BSON(strPlayerID << 1));
		db_mgr.EnsureIndex(DBN::dbPlayerCardPoke, BSON(strPlayerID << 1));
		db_mgr.EnsureIndex(DBN::dbPlayerCount, BSON(strPlayerID << 1 << "sid" << 1));
		db_mgr.EnsureIndex(DBN::dbPlayerCarPos, BSON(strPlayerID << 1));
		db_mgr.EnsureIndex(DBN::dbPlayerTrade, BSON(strPlayerID << 1));
		db_mgr.EnsureIndex(DBN::dbPlayerTradeItem, BSON(strPlayerID << 1));
		db_mgr.EnsureIndex(DBN::dbPlayerTradeBuff, BSON(strPlayerID << 1));
		db_mgr.EnsureIndex(DBN::dbPlayerTradeRich, BSON("key" << 1));
		db_mgr.EnsureIndex(DBN::dbPlayerHeroParty, BSON(strPlayerID << 1));
		db_mgr.EnsureIndex(DBN::dbPlayerKingFight, BSON(strPlayerID << 1));
		db_mgr.EnsureIndex(DBN::dbPlayerRescue, BSON(strPlayerID << 1));
		db_mgr.EnsureIndex(DBN::dbPlayerTeam, BSON(strPlayerID << 1));
		db_mgr.EnsureIndex(DBN::dbPlayerKingdom, BSON(strPlayerID << 1));
		db_mgr.EnsureIndex(DBN::dbPlayerVip, BSON(strPlayerID << 1));
		db_mgr.EnsureIndex(DBN::dbPlayerWorldBoss, BSON(strPlayerID << 1));
		db_mgr.EnsureIndex(DBN::dbPlayerLastRep, BSON(strPlayerID << 1));
		db_mgr.EnsureIndex(DBN::dbPlayerResearch, BSON(strPlayerID << 1));
		db_mgr.EnsureIndex(DBN::dbPlayerMarket, BSON(strPlayerID << 1));
		db_mgr.EnsureIndex(DBN::dbPlayerOrders, BSON(strPlayerID << 1));
		db_mgr.EnsureIndex(DBN::dbPlayerAffair, BSON(strPlayerID << 1));
		db_mgr.EnsureIndex(DBN::dbPlayerMall, BSON(strPlayerID << 1));
		db_mgr.EnsureIndex(DBN::dbPlayerDaily, BSON(strPlayerID << 1));
		db_mgr.EnsureIndex(DBN::dbPlayerBuilds, BSON(strPlayerID << 1));
		db_mgr.EnsureIndex(DBN::dbPlayerBuildTeams, BSON(strPlayerID << 1));
		db_mgr.EnsureIndex(DBN::dbPlayerAdmin, BSON(strPlayerID << 1));
		db_mgr.EnsureIndex(DBN::dbPlayerWarLords, BSON(strPlayerID << 1));
		db_mgr.EnsureIndex(DBN::dbPlayerEmail, BSON(strPlayerID << 1));
		db_mgr.EnsureIndex(DBN::dbPlayerOffline, BSON(strPlayerID << 1));
		db_mgr.EnsureIndex(DBN::dbPlayerCustom, BSON(strPlayerID << 1));
		db_mgr.EnsureIndex(DBN::dbPlayerDaysActivity, BSON(strPlayerID << 1));
		db_mgr.EnsureIndex(DBN::dbPlayerOnlineBox, BSON(strPlayerID << 1));
		db_mgr.EnsureIndex(DBN::dbPlayerMoneyActivity, BSON(strPlayerID << 1 << "type" << 1));
		db_mgr.EnsureIndex(DBN::dbPlayerSign, BSON(strPlayerID << 1));
		db_mgr.EnsureIndex(DBN::dbPlayerDailyCard, BSON(strPlayerID << 1));
		db_mgr.EnsureIndex(DBN::dbPlayerFund, BSON(strPlayerID << 1));
		db_mgr.EnsureIndex(DBN::dbPlayerKingdomWar, BSON(strPlayerID << 1));
		db_mgr.EnsureIndex(DBN::dbPlayerKingdomWarShop, BSON(strPlayerID << 1));
		db_mgr.EnsureIndex(DBN::dbPlayerKingdomWarOutput, BSON(strPlayerID << 1));
		db_mgr.EnsureIndex(DBN::dbPlayerKingdomWarFM, BSON(strPlayerID << 1 << "a" << 1));
		db_mgr.EnsureIndex(DBN::dbPlayerKingdomWarPos, BSON(strPlayerID << 1 << "a" << 1));
		db_mgr.EnsureIndex(DBN::dbPlayerKingdomWarBox, BSON(strPlayerID << 1));
		db_mgr.EnsureIndex(DBN::dbPlayerKingdomWarTask, BSON(strPlayerID << 1));
		db_mgr.EnsureIndex(DBN::dbPlayerOpenActivity, BSON(strPlayerID << 1));
	}

	namespace DBLOG
	{
		//���ݿ����ֽ���������Ӣ����ĸ,���ֺ��»���.����ĸ��ͷ.��ֹ�����κ��ַ�//���������������
		const static string strLogPlayerName = "log_name";
		const static string strLogPlaying = "log_playing";
		const static string strLogPlayerLevel = "log_player_level";
		const static string strLogPlayerVipLevel = "log_player_vip";
		const static string strLogRecharge = "log_player_recharge";
		const static string strLogManDo = "log_man";
		const static string strLogGold = "log_gold";
		const static string strLogSilver = "log_silver";
		const static string strLogWood = "log_wood";
		const static string strLogFame = "log_fame";
		const static string strLogMerit = "log_merit";
		const static string strLogFood = "log_food";
		const static string strLogIron = "log_iron";
		const static string strLogAction = "log_action";
		const static string strLogContribution = "log_contribution";
		const static string strLogHeroPartyMoney = "log_heropartymoney";
		const static string strLogLadyCoin = "log_ladycoin";
		const static string strLogMarket = "log_market";
		const static string strLogUpgradeBuild = "log_upgradebuild";
		const static string strLogBuyBuildTeam = "log_buybuildteam";
		const static string strLogMilitaryUpgrade = "log_militaryupgrade";
		const static string strLogPlayerOfficial = "log_player_official";
		const static string strLogPlayerGem = "log_player_gem";
		const static string strLogRescue = "log_player_rescue";
		const static string strLogBusiness = "log_player_business";
		const static string strLogPlayerNation = "log_player_nation";
		const static string strLogPlayerItem = "log_player_item";
		const static string strLogWar = "log_player_war";
		const static string strLogSearch = "log_player_search";
		const static string strLogKingdom = "log_player_kingdom";
		const static string strLogKingFight = "log_player_kingfight";
		const static string strLogWarProcess = "log_war_process";
		const static string strLogPlayerOnline = "log_player_online";
		const static string strLogClientProcess = "log_client_process";
		const static string strLogPlayerCard = "log_player_card";
		const static string strLogGiftFromGM = "log_gm_gift";
		const static string strLogHeroParty = "log_hero_party";
		const static string strLogRedPaper = "log_red_paper";
		const static string strLogPoints = "log_points";
		const static string strLogWorldBoss = "log_player_worldboss";
		const static string strLogBuildHarvest = "log_build_harvest";
		const static string strLogCustomGift = "log_custom_gift";
		const static string strLogEmail = "log_email";
		const static string strLogAffair = "log_player_affair";
		const static string strLogMall = "log_mall";
		const static string strLogProcessRecord = "log_process_record";
		const static string strLogManAppoint = "log_man_appoint";
		const static string strLogWarLords = "log_warlords";
		const static string strLogOnlineBox = "log_online_box";
		const static string strLogVipGift = "log_vip_gift";
		const static string strLogItemShop = "log_item_shop";
		const static string strLogMoneyActivity = "log_money_activity";
		const static string strLogFirstGift = "log_first_gift";
		const static string strLogSign = "log_sign";
		const static string strLogDailyCard = "log_player_daily_card";
		const static string strLogTeamWar = "log_player_team_war";
		const static string strOfflineWard = "log_player_offline_award";		
		const static string strLogFund = "log_player_fund";	
		const static string strLogItemStack = "log_item_stack";
		const static string strLogDailyTask = "log_daily_task";
		const static string strLogSearchPoint = "log_search_point";
		const static string strLogExploit = "log_exploit";
		const static string strLogTask = "log_task";
		const static string strLogFormation = "log_player_formation";
		const static string strLogPlayerBattleValue = "log_player_batlle_vlaue";
		const static string strLogKingdomWar = "log_kingdom_war";
		const static string strLogTradeRank = "log_trade_rank";
		const static string strLogDice = "log_dice";//������ˮ
		const static string strLoginDayBox = "log_login_day";//7����뽱����ˮ
	}

	//����������ģ��
	namespace MetaLog
	{
		extern void Log(const string table, const int tag, string f1 = "", string f2 = "", string f3 = "", string f4 = "", string f5 = "", string f6 = "", string f7 = "", string f8 = "");
		extern void Log(const string table, playerDataPtr player, const int tag, string f1 = "", string f2 = "", string f3 = "", string f4 = "", string f5 = "", string f6 = "", string f7 = "", string f8 = "");
	}

	//f1 ~ f8 f8 �ǳ��ı�
	template<typename T1>
	static void Log(const string table, playerDataPtr player, const int tag, T1 f1)
	{
		MetaLog::Log(table, player, tag, Common::toString(f1));
	}
	template<typename T1, typename T2>
	static void Log(const string table, playerDataPtr player, const int tag, T1 f1, T2 f2)
	{
		MetaLog::Log(table, player, tag, Common::toString(f1), Common::toString(f2));
	}
	template<typename T1, typename T2, typename T3>
	static void Log(const string table, playerDataPtr player, const int tag, T1 f1, T2 f2, T3 f3)
	{
		MetaLog::Log(table, player, tag, Common::toString(f1), Common::toString(f2), Common::toString(f3));
	}
	template<typename T1, typename T2, typename T3, typename T4>
	static void Log(const string table, playerDataPtr player, const int tag, T1 f1, T2 f2, T3 f3, T4 f4)
	{
		MetaLog::Log(table, player, tag, Common::toString(f1), Common::toString(f2), Common::toString(f3), Common::toString(f4));
	}
	template<typename T1, typename T2, typename T3, typename T4, typename T5>
	static void Log(const string table, playerDataPtr player, const int tag, T1 f1, T2 f2, T3 f3, T4 f4, T5 f5)
	{
		MetaLog::Log(table, player, tag, Common::toString(f1), Common::toString(f2), Common::toString(f3), Common::toString(f4), Common::toString(f5));
	}
	template<typename T1, typename T2, typename T3, typename T4, typename T5, typename T6>
	static void Log(const string table, playerDataPtr player, const int tag, T1 f1, T2 f2, T3 f3, T4 f4, T5 f5, T6 f6)
	{
		MetaLog::Log(table, player, tag, Common::toString(f1), Common::toString(f2), Common::toString(f3), Common::toString(f4), Common::toString(f5), Common::toString(f6));
	}
	template<typename T1, typename T2, typename T3, typename T4, typename T5, typename T6, typename T7>
	static void Log(const string table, playerDataPtr player, const int tag, T1 f1, T2 f2, T3 f3, T4 f4, T5 f5, T6 f6, T7 f7)
	{
		MetaLog::Log(table, player, tag, Common::toString(f1), Common::toString(f2), Common::toString(f3), Common::toString(f4), Common::toString(f5), Common::toString(f6), Common::toString(f7));
	}
	template<typename T1, typename T2, typename T3, typename T4, typename T5, typename T6, typename T7, typename T8>
	static void Log(const string table, playerDataPtr player, const int tag, T1 f1, T2 f2, T3 f3, T4 f4, T5 f5, T6 f6, T7 f7, T8 f8)
	{
		MetaLog::Log(table, player, tag, Common::toString(f1), Common::toString(f2), Common::toString(f3), Common::toString(f4), Common::toString(f5), Common::toString(f6), Common::toString(f7), Common::toString(f8));
	}

	//systemLog
	template<typename T1>
	static void Log(const string table, const int tag, T1 f1)
	{
		MetaLog::Log(table, tag, Common::toString(f1));
	}
	template<typename T1, typename T2>
	static void Log(const string table, const int tag, T1 f1, T2 f2)
	{
		MetaLog::Log(table, tag, Common::toString(f1), Common::toString(f2));
	}
	template<typename T1, typename T2, typename T3>
	static void Log(const string table, const int tag, T1 f1, T2 f2, T3 f3)
	{
		MetaLog::Log(table, tag, Common::toString(f1), Common::toString(f2), Common::toString(f3));
	}
	template<typename T1, typename T2, typename T3, typename T4>
	static void Log(const string table, const int tag, T1 f1, T2 f2, T3 f3, T4 f4)
	{
		MetaLog::Log(table, tag, Common::toString(f1), Common::toString(f2), Common::toString(f3), Common::toString(f4));
	}
	template<typename T1, typename T2, typename T3, typename T4, typename T5>
	static void Log(const string table, const int tag, T1 f1, T2 f2, T3 f3, T4 f4, T5 f5)
	{
		MetaLog::Log(table, tag, Common::toString(f1), Common::toString(f2), Common::toString(f3), Common::toString(f4), Common::toString(f5));
	}
	template<typename T1, typename T2, typename T3, typename T4, typename T5, typename T6>
	static void Log(const string table, const int tag, T1 f1, T2 f2, T3 f3, T4 f4, T5 f5, T6 f6)
	{
		MetaLog::Log(table, tag, Common::toString(f1), Common::toString(f2), Common::toString(f3), Common::toString(f4), Common::toString(f5), Common::toString(f6));
	}
	template<typename T1, typename T2, typename T3, typename T4, typename T5, typename T6, typename T7>
	static void Log(const string table, const int tag, T1 f1, T2 f2, T3 f3, T4 f4, T5 f5, T6 f6, T7 f7)
	{
		MetaLog::Log(table, tag, Common::toString(f1), Common::toString(f2), Common::toString(f3), Common::toString(f4), Common::toString(f5), Common::toString(f6), Common::toString(f7));
	}
	template<typename T1, typename T2, typename T3, typename T4, typename T5, typename T6, typename T7, typename T8>
	static void Log(const string table, const int tag, T1 f1, T2 f2, T3 f3, T4 f4, T5 f5, T6 f6, T7 f7, T8 f8)
	{
		MetaLog::Log(table, tag, Common::toString(f1), Common::toString(f2), Common::toString(f3), Common::toString(f4), Common::toString(f5), Common::toString(f6), Common::toString(f7), Common::toString(f8));
	}

}

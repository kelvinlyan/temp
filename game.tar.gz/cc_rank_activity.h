//###################################
//create by Jim
//2016-11-29
//###################################
#pragma once

#include "action_system.h"
#include "quickjson.h"
#include "timmer.hpp"

namespace gg
{
	namespace RANKACTIVITY
	{
		struct TypeCC
		{
			typedef int _value_type;
			TypeCC(const int id,
				const string name,
				const int value)
			{
				_player_id = id;
				_player_name = name;
				_value = value;
				_create_time = Common::gameTime();
			}
			int _player_id;
			string _player_name;
			unsigned _create_time;
			int _value;
			bool operator<(const TypeCC& other)const
			{
				if (_value != other._value)return _value > other._value;
				if (_create_time != other._create_time)return _create_time < other._create_time;
				return _player_id < other._player_id;
			}
			inline bool operator>(const TypeCC& other)const { return this->operator<(other); }
		};

		class ActivityCCRank
		{
			enum
			{
				run_nothing,
				run_to_begin,
				run_to_end,
				run_to_over,
			};
		public:
			ActivityCCRank(const int type) : Type(type) {}
			const int Type;
			const static unsigned MaxSize = 50;
			typedef TypeCC _data_type;
			typedef boost::shared_ptr<_data_type> _data_type_ptr;
			typedef TypeCC::_value_type _value_type;
			struct _condition//�ϰ�����
			{
				_condition(const unsigned begin_,
					const unsigned end_,
					const _value_type value_)
				{
					_begin_idx = begin_;
					_end_idx = end_;
					_value_compare = value_;
				}
				unsigned _begin_idx;
				unsigned _end_idx;
				_value_type _value_compare;
				bool operator<(const _condition& other)const
				{
					return _begin_idx < other._begin_idx;
				}
			};
			typedef std::vector<_condition> _condition_list_type;
			typedef std::vector<_data_type_ptr> _rank_list_type;
			struct _box
			{
				_box()
				{
					_limit_value = 0;
					_box_json = Json::arrayValue;
					_box_client_json = Json::arrayValue;
					_box_action.clear();
				}
				_box(const _value_type limit_,
					Json::Value json_)
				{
					_limit_value = limit_;
					_box_json = json_;
					_box_client_json = jsonFormats2c(json_);
					_box_action = actionFormatBox(json_);
				}
				_value_type _limit_value;
				Json::Value _box_json;
				Json::Value _box_client_json;
				ActionBoxList _box_action;
			};
			typedef std::map< int, _box, std::less<int> > _box_list_type;
			struct _rank_box
			{
				_rank_box(const unsigned begin_,
					const unsigned end_,
					Json::Value json_)
				{
					_begin_idx = begin_;
					_end_idx = end_;
					_box_json = json_;
					_box_client_json = jsonFormats2c(json_);
					_box_action = actionFormatBox(json_);
				}
				unsigned _begin_idx;
				unsigned _end_idx;
				Json::Value _box_json;
				Json::Value _box_client_json;
				ActionBoxList _box_action;
			};
			typedef std::vector<_rank_box> _rank_box_list_type;
		public:
			bool find_reach_box(ActionBoxList& box, const int reach)
			{
				_box_list_type::iterator it = _reach_box_list.find(reach);
				if (it == _reach_box_list.end())return false;
				box = it->second._box_action;
				return true;
			}
			inline bool is_null_activity() { return 0 == _activity_id || 0 == _create_time; }
			inline unsigned activity_id() { return _activity_id; }
			inline unsigned create_id() { return _create_time; }
			inline const _box_list_type& reach_box_list() { return _reach_box_list; }
			inline bool is_open()
			{
				return (_run_type > run_nothing && Common::gameTime() >= _show_begin);
			}
			inline bool is_run()
			{
				return _run_type == run_to_end;
			}
			inline bool is_end()
			{
				return is_null_activity() || _run_type >= run_to_over;
			}
			virtual void update_player_name(const int playerID, const string name);
			virtual void load_db();
			virtual void insert_rank(_data_type insert_data_);
			virtual int set_new_data(Json::Value& json);

			//base time
			unsigned inline show_begin_time() const { return _show_begin; }
			unsigned inline show_end_time() const {	return _show_end; }
			unsigned inline activity_begin_time() const {	return _activity_begin; }
			unsigned inline activity_end_time() const { return _activity_end; }
			std::string inline ruler_url() const { return _tx_url; }

			//package
			Json::Value package_gm()
			{
				Json::Value json = Json::objectValue;
				json["id"] = _activity_id;//�ID
				json["tx_url"] = _tx_url;
				json["time"][0u] = 0 == _show_begin ? 0 : Common::toStampTime(_show_begin);
				json["time"][1u] = 0 == _activity_begin ? 0 : Common::toStampTime(_activity_begin);
				json["time"][2u] = 0 == _activity_end ? 0 : Common::toStampTime(_activity_end);
				json["time"][3u] = 0 == _show_end ? 0 : Common::toStampTime(_show_end);
				for (unsigned i = 0; i < _condition_list.size(); ++i)
				{
					const _condition& condition = _condition_list[i];
					Json::Value singl_json = Json::arrayValue;
					singl_json.append(condition._end_idx);
					singl_json.append(condition._value_compare);
					singl_json.append(condition._begin_idx + 1);
					json["part"].append(singl_json);
				}
				for (unsigned i = 0; i < _rank_box_list.size(); ++i)
				{
					const _rank_box& box = _rank_box_list[i];
					Json::Value singl_json = Json::arrayValue;
					singl_json.append(box._end_idx);
					singl_json.append(box._box_json);
					singl_json.append(box._begin_idx + 1);
					json["rank"].append(singl_json);
				}
				for (_box_list_type::const_iterator it = _reach_box_list.begin(); it != _reach_box_list.end(); ++it)
				{
					const _box& box = it->second;
					Json::Value single_json = Json::arrayValue;
					single_json.append(box._limit_value);
					single_json.append(box._box_json);
					json["reach"].append(single_json);
				}
				return json;
			}
			Json::Value package_reach_box()
			{
				Json::Value json = Json::arrayValue;
				for (_box_list_type::const_iterator it = _reach_box_list.begin(); it != _reach_box_list.end(); ++it)
				{
					const _box& box = it->second;
					Json::Value single_json = Json::arrayValue;
					single_json.append(box._limit_value);
					single_json.append(box._box_client_json);
					json.append(single_json);
				}
				return json;
			}
			Json::Value package_rank_list()
			{
				const static Json::Value EmptyBoxJson = Json::arrayValue;
				Json::Value json = Json::arrayValue;
				unsigned rank_index = 0;
				for (unsigned i = 0; i < _condition_list_map.size(); ++i)
				{
					const _condition& condition = *_condition_list_map[i];
					Json::Value single_json = Json::arrayValue;
					if (rank_index >= _rank_list.size())
					{
						single_json.append(-1);//
						single_json.append("");
						single_json.append(0);
						single_json.append(condition._value_compare);
						const Json::Value& send_box_json_ = i >= _rank_box_map.size() ? EmptyBoxJson : (_rank_box_map[i])->_box_client_json;
						single_json.append(send_box_json_);
						json.append(single_json);
						continue;
					}
					const _data_type_ptr& data = _rank_list[rank_index];
					if (data->_value < condition._value_compare)
					{
						single_json.append(-1);//
						single_json.append("");
						single_json.append(0);
						single_json.append(condition._value_compare);
						const Json::Value& send_box_json_ = i >= _rank_box_map.size() ? EmptyBoxJson : (_rank_box_map[i])->_box_client_json;
						single_json.append(send_box_json_);
						json.append(single_json);
						continue;
					}
					single_json.append(data->_player_id);//
					single_json.append(data->_player_name);
					single_json.append(data->_value);
					single_json.append(condition._value_compare);
					const Json::Value& send_box_json_ = i >= _rank_box_map.size() ? EmptyBoxJson : (_rank_box_map[i])->_box_client_json;
					single_json.append(send_box_json_);
					json.append(single_json);
					++rank_index;
				}
				return json;
			}
		protected:
			void run_to_begin_event(const unsigned create_id_, const unsigned match_time_);
			void run_to_end_event(const unsigned create_id_, const unsigned match_time_);
			void run_to_over_event(const unsigned create_id_, const unsigned match_time_);
			void create_timer();
			void scroll_cast_event(const unsigned tml);
			void window_cast_event(const unsigned tml);
			void create_cast();
			void _clean_rank_list();
			void _clean_online_player();
			void clean_activity();
			void over_activity();
			void save_config();
			void save_rank();
			void save_rank_player(const _data_type& player_);
			void del_rank_player(const int player_id_);
			UNORDERMAP(int, _data_type_ptr, _data_key_map);
			_data_key_map _players;
			_data_type_ptr get_player(const int player_id_)
			{
				_data_key_map::const_iterator it = _players.find(player_id_);
				if (it == _players.end())return _data_type_ptr();
				return it->second;
			}

#define DELTIMER(DATA)\
if (DATA)\
{\
	DATA->delTimer();\
	DATA = ::ptrTimerIdentify();\
}

			virtual void reset_if_old()
			{
				_tx_url = "";
				_activity_id = 0;
				_show_begin = 0;
				_show_end = 0;
				_activity_begin = 0;
				_activity_end = 0;
				_condition_list.clear();
				_condition_list.reserve(MaxSize);
				_condition_list_map.clear();
				_condition_list_map.reserve(MaxSize);
				_rank_box_list.clear();
				_rank_box_list.reserve(MaxSize);
				_rank_box_map.clear();
				_rank_box_map.reserve(MaxSize);
				_reach_box_list.clear();
				DELTIMER(_window_end_120);
				DELTIMER(_window_end_30);
				DELTIMER(_scroll_end_15);
				DELTIMER(_scroll_end_5);
			}
			virtual void reset()
			{
				reset_if_old();
				_run_type = run_nothing;
				_create_time = 0;
				_rank_list.clear();
				_rank_list.reserve(MaxSize * 2);
				_players.clear();
			}
			::ptrTimerIdentify _scroll_end_15, _scroll_end_5, _window_end_120, _window_end_30;
			unsigned _run_type;
			unsigned _activity_id;
			unsigned _create_time;
			unsigned _show_begin;
			unsigned _show_end;
			unsigned _activity_begin;
			unsigned _activity_end;
			_condition_list_type _condition_list;
			typedef std::vector<_condition*> _condition_list_map_type;
			_condition_list_map_type _condition_list_map;
			_box_list_type _reach_box_list;
			_rank_box_list_type _rank_box_list;
			typedef std::vector<_rank_box*> _rank_box_map_type;
			_rank_box_map_type _rank_box_map;
			_rank_list_type _rank_list;
			std::string _tx_url;
		};
	}
}
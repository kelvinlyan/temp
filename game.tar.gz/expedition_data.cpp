#include "expedition_data.h"
#include "map_war.h"
#include "game_time.h"
#include "heroparty_system.h"
#include "email_system.h"

namespace gg
{
	namespace Expedition
	{
		enum
		{
			RecentStrategySize = 5,
			MaxRankSize = 100,

			FirstRepID = 1,
			BestRepID,
			RecentRepIDBegin,
			RecentRepIDEnd = RecentRepIDBegin + RecentStrategySize,
		};

		Strategy::Strategy(int mid)
			: _mid(mid), _first("[]"), _best("[]"), _recent_rep_id(RecentRepIDBegin)
		{
		}

		Strategy::Strategy(const mongo::BSONObj& obj)
			: _cmp_best(obj["cb"])
		{
			_mid = obj["mid"].Int();
			_recent_rep_id = obj["cr"].Int();
			_first = obj["f"].String();
			_best = obj["b"].String();
			{
				std::vector<mongo::BSONElement> ele = obj["r"].Array();
				for (unsigned i = 0; i < ele.size(); ++i)
					_recent.push_back(ele[i].String());
			}
			{
				std::vector<mongo::BSONElement> ele = obj["rp"].Array();
				for (unsigned i = 0; i < ele.size(); ++i)
					_recent_pids.push_back(ele[i].Int());
			}
		}

		bool Strategy::better(const CmpStrategy& cmp) const
		{
			if (_cmp_best.lv != cmp.lv)
				return _cmp_best.lv < cmp.lv;
			if (_cmp_best.round_num != cmp.round_num)
				return _cmp_best.round_num < cmp.round_num;
			if (_cmp_best.damage != cmp.damage)
				return _cmp_best.damage < cmp.damage;
			return false;
		}

		void Strategy::push(qValue& q, const CmpStrategy& cmp, BattleReport& rep_data, playerDataPtr& d)
		{
			if (_first == "[]")
			{
				qValue tmp = q.Copy();
				std::string rpath = Common::toString(_mid) + "/" + Common::toString((int)FirstRepID);
				tmp << rpath;
				_first = tmp.toIndentString();
				rpath = "expedition/" + rpath;
				rep_data.addCopyField(rpath);
			}
			if (_best == "[]" || better(cmp))
			{
				qValue tmp = q.Copy();
				std::string rpath = Common::toString(_mid) + "/" + Common::toString((int)BestRepID);
				tmp << rpath;
				_best = tmp.toIndentString();
				_cmp_best = cmp;
				rpath = "expedition/" + rpath;
				rep_data.addCopyField(rpath);
			}
			std::string rpath = Common::toString(_mid) + "/" + Common::toString(_recent_rep_id);
			q << rpath;
			List::iterator itr = _recent.begin();
			ForEach(PIDS, it, _recent_pids)
			{
				if ((*it) == d->ID())
				{
					_recent_pids.erase(it);
					_recent.erase(itr);
					break;
				}
				++itr;
			}
			_recent.push_front(q.toIndentString());
			_recent_pids.push_front(d->ID());
			while(_recent.size() > RecentStrategySize)
			{
				_recent.pop_back();
				_recent_pids.pop_back();
			}
			rpath = "expedition/" + rpath;
			rep_data.addCopyField(rpath);
			++_recent_rep_id;
			if (_recent_rep_id >= RecentRepIDEnd)
				_recent_rep_id = RecentRepIDBegin;
			_sign_save();
		}

		void Strategy::update(playerDataPtr d)
		{
			std::string str;
			str += "{\"msg\":[0,{\"f\":";
			str += _first;
			str += ",\"b\":";
			str += _best;
			str += ",\"r\":[";
			ForEachC(List, it, _recent)
			{
				if (it != _recent.begin())
					str += ",";
				str += *it;
			}
			str += "]}]}";
			d->sendToClient(gate_client::expedition_strategy_info_resp, str);
		}

		bool Strategy::_auto_save()
		{
			mongo::BSONObj key = BSON("mid" << _mid);
			mongo::BSONObjBuilder obj;
			obj << "mid" << _mid
				<< "f" << _first << "b" << _best << "cb" << _cmp_best.toBSON()
				<< "cr" << _recent_rep_id;
			{
				mongo::BSONArrayBuilder b;
				ForEachC(List, it, _recent)
					b.append(*it);
				obj << "r" << b.arr();
			}
			{
				mongo::BSONArrayBuilder b;
				ForEachC(PIDS, it, _recent_pids)
					b.append(*it);
				obj << "rp" << b.arr();
			}
			return db_mgr.SaveMongo(DBN::dbExpeditionStragety, key, obj.obj());
		}

		RandomER::RandomER(const Json::Value& info)
		{
			const Json::Value& up = info["up_rank"];
			_up_rank.interval = up[0u].asInt();
			_up_rank.range = up[1u].asInt();
			const Json::Value& down = info["down_rank"];
			_down_rank.interval = down[0u].asInt();
			_down_rank.range = down[1u].asInt();
		}

		int RandomER::rand(int rank) const
		{
			int max_range = heroparty_sys.maxOldRank(); 
			std::vector<int> res;
			if (_up_rank.range != 0)
			{
				if (rank == 1)
				{
					if (max_range > 1)
						res.push_back(rank + 1);
					else
						res.push_back(rank);
				}
				else
				{
					int range_end = rank - _up_rank.interval - 1;
					int range_start = range_end - _up_rank.range;
					if (range_start < 1)
						range_start = 1;
					if (range_end < 1)
						range_end = 1;
					res.push_back(Common::randomBetween(range_start, range_end));
				}
			}
			if (_down_rank.range != 0)
			{
				if (rank == max_range)
				{
					if (max_range > 1)
						res.push_back(rank - 1);
					else
						res.push_back(rank);
				}
				else
				{
					int range_start = rank + _down_rank.interval + 1;
					int range_end = range_start + _down_rank.range;
					if (range_start > max_range)
						range_start = max_range;
					if (range_end > max_range)
						range_end = max_range;
					res.push_back(Common::randomBetween(range_start, range_end));
				}
			}
			if (res.size() == 1)
				return res[0];
			else
				return res[Common::randomBetween(0, res.size() - 1)];
		}

		MapBase::MapBase(const Json::Value& info, int pos)
			: _pos(pos)
		{
			_type = info["type"].asInt();
			_reward = actionFormat(info["reward"].asInt());
			_bg_id = info["background"].asInt();
		}

		INpc::INpc(const Json::Value& info, int pos)
			: MapBase(info, pos)
		{
			_npc_data = NpcDataMgr::shared().getNpcData(info["npc_id"].asInt());
		}

		int INpc::mapID() const
		{
			return _npc_data->mapID;
		}

		sBattlePtr INpc::getBattlePtr(playerDataPtr d)
		{
			sBattlePtr ptr = map_sys.npcSide(_npc_data);
			const std::map<int, int>& target_hp = d->Expedition().getTargetHp();
			for (unsigned i = 0; i < ptr->battleMan.size(); ++i)
			{
				const mBattlePtr& m = ptr->battleMan[i];
				std::map<int, int>::const_iterator it = target_hp.find(m->manID);
				if (it != target_hp.end())
					m->currentHP = it->second;
			}
			return ptr;
		}

		void INpc::getBaseInfo(playerDataPtr d, qValue& q) const
		{
			q.addMember("t", NPC);
			q.addMember("lvl", _npc_data->mapLevel);
			q.addMember("b", _npc_data->battleValue);
		}
		
		void INpc::getFMInfo(playerDataPtr d, qValue& q)
		{
			q.addMember("id", _npc_data->mapID);
			q.addMember("nm", _npc_data->mapName);
			q.addMember("lv", _npc_data->mapLevel);
			q.addMember("fa", _npc_data->faceID);
			int all_bv = _npc_data->battleValue;
			qValue ml;
			sBattlePtr ptr = map_sys.npcSide(_npc_data);
			const std::map<int, int>& target_hp = d->Expedition().getTargetHp();
			for (unsigned i = 0; i < ptr->battleMan.size(); ++i)
			{
				const mBattlePtr& m = ptr->battleMan[i];
				qValue tmp;
				tmp << m->manID << m->currentIdx << m->manLevel << m->battleValue
					<< m->currentHP;
				std::map<int, int>::const_iterator it = target_hp.find(m->manID);
				if (it == target_hp.end())
					tmp << m->currentHP;
				else
				{
					if (it->second < 1)
					{
						all_bv -= m->battleValue;
						continue;
					}
					tmp << it->second;
				}
				ml << tmp;
			}
			q.addMember("bv", all_bv);
			q.addMember("ml", ml);
		}

		IPlayer::IPlayer(const Json::Value& info, int pos)
			: MapBase(info, pos)
		{
			_randomer = Creator<RandomER>::Create(info);	
			_attack_buff = info["attack_rate"].asInt();
			_defense_buff = info["defense_rate"].asInt();
		}

		sBattlePtr IPlayer::getBattlePtr(playerDataPtr d)
		{
			int target_pid = d->Expedition().getTargetPID(pos());
			playerDataPtr target = player_mgr.getPlayer(target_pid);
			if (!target) return sBattlePtr();
			sBattlePtr sb = target->Shadow().getBattlePtr(d);
			ForEach(manList, it, sb->battleMan)
			{
				(*it)->battleAttri[idx_phyHurtRate] += _attack_buff;
				(*it)->battleAttri[idx_phyCutRate] += _defense_buff;
				(*it)->battleAttri[idx_warHurtRate] += _attack_buff;
				(*it)->battleAttri[idx_warCutRate] += _defense_buff;
				(*it)->battleAttri[idx_magicHurtRate] += _attack_buff;
				(*it)->battleAttri[idx_magicCutRate] += _defense_buff;
				(*it)->battleAttri[idx_cureRate] += _attack_buff;
			}
			return sb;
		}

		void IPlayer::getBaseInfo(playerDataPtr d, qValue& q) const
		{
			int target_pid = d->Expedition().getTargetPID(pos());
			playerDataPtr target = player_mgr.getPlayer(target_pid);
			if (!target) return;
			sBattlePtr ptr = target->Shadow().getBattlePtr(d);
			if (!ptr) return;
			q.addMember("t", PLAYER);
			q.addMember("n", ptr->playerName);
			q.addMember("lvl", ptr->playerLevel);
			q.addMember("b", ptr->battleValue);
			q.addMember("f", ptr->playerFace);
		}

		void IPlayer::getFMInfo(playerDataPtr d, qValue& q)
		{
			int target_pid = d->Expedition().getTargetPID(pos());
			playerDataPtr target = player_mgr.getPlayer(target_pid);
			if (!target) return;
			target->Shadow().getInfo(d, q);
		}

		int IPlayer::randTargetPID(playerDataPtr d) const
		{
			int target_rank = _randomer->rand(d->Expedition().matchRank());
			return heroparty_sys.getPidByOldRank(target_rank);
		}

		static MapPtr createMapItem(const Json::Value& info, int pos)
		{
			int type = info["type"].asInt();
			if (type == NPC)
				return Creator<INpc>::Create(info, pos);
			else if (type == PLAYER)
				return Creator<IPlayer>::Create(info, pos);
			else
			{
				LogE << "expedition map item type error: " << type << LogEnd;
				return MapPtr();
			}
		}

		MapData::OMapData::OMapData(const Json::Value& info)
		{
			start_bv = info["start_bv"].asInt();
			end_bv = info["end_bv"].asInt();
			const Json::Value& map_data = info["map_data"];
			for (unsigned i = 0; i < map_data.size(); ++i)
				map_item.push_back(createMapItem(map_data[i], i + 1));
		}

		MapData::MapData(const Json::Value& info)
		{
			ForEachC(Json::Value, it, info)
				_map_data.push_back(OMapData(*it));
		}

		int MapData::index(int bv) const
		{
			for (unsigned i = 0; i < _map_data.size(); ++i)
			{
				if (bv >= _map_data[i].start_bv && bv <= _map_data[i].end_bv)
					return i;
			}
			return _map_data.size() - 1;
		}

		MapPtr MapData::getMapData(playerDataPtr d, int pos) const
		{
			int idx = index(d->Expedition().matchBV());
			if (idx == -1)
				return MapPtr();
			if (pos < 1 || pos > _map_data[idx].map_item.size())
				return MapPtr();
			return _map_data[idx].map_item[pos-1];
		}

		void MapData::getBaseInfo(playerDataPtr d, qValue& q) const
		{
			int idx = index(d->Expedition().matchBV());
			if (idx == -1)
				return;
			ForEachC(MapItemList, it, _map_data[idx].map_item)
			{
				qValue tmp(qJson::qj_object);
				(*it)->getBaseInfo(d, tmp);
				q << tmp;
			}
		}

		NpcDataMgr::NpcDataMgr()
		{
			loadFile();
		}

		NpcDataPtr NpcDataMgr::getNpcData(int id) const
		{
			NpcDataMap::const_iterator it = _npc_data.find(id);
			return it == _npc_data.end()? NpcDataPtr() : it->second;
		}

		void NpcDataMgr::loadFile()
		{
			FileJsonSeq vec;	
			vec = Common::loadFileJsonFromDir("./instance/expedition/npc");
			ForEachC(FileJsonSeq, it, vec)
			{
				const Json::Value& info = *it;
				NpcDataPtr map_data = Creator<mapDataConfig>::Create();
				map_data->mapID = info["mapId"].asInt();
				map_data->background = info.isMember("background") ? info["background"].asInt() : 1;
				map_data->faceID = info["faceID"].asInt();
				map_data->mapName = info["mapName"].asString();
				map_data->mapLevel = info["mapLevel"].asInt();
				map_data->battleValue = info["battleValue"].asInt();
				map_data->needFood = info["needfood"].asInt();
				map_data->needAction = info["needAction"].asInt();
				map_data->chanllengeTimes = info["challengeTimes"].asInt();
				map_data->manExp = info["manExp"].asUInt();
				map_data->levelLimit = info["levelLimit"].asUInt();
				map_data->robotIDX = info["robotIDX"].asInt();
				for (unsigned nn = 0; nn < info["army"].size(); ++nn)
				{
					const Json::Value& npcJson = info["army"][nn];
					armyNPC npc;
					npc.npcID = npcJson["npcID"].asInt();
					npc.holdMorale = npcJson["holdMorale"].asBool();
					for (unsigned cn = 0; cn < characterNum; ++cn)
					{
						npc.initAttri[cn] = npcJson["initAttri"][cn].asInt();
					}
					npc.armsType = npcJson["armsType"].asInt();
					for (unsigned cn = 0; cn < armsModulesNum; ++cn)
					{
						npc.armsModule[cn] = npcJson["armsModule"][cn].asDouble();
					}
					npc.npcLevel = npcJson["npcLevel"].asInt();
					npc.npcPos = npcJson["npcPos"].asUInt() % 9;
					npc.battleValue = npcJson["battleValue"].asInt();
					npc.skill_1 = npcJson["skill_1"].asInt();
					npc.skill_2 = npcJson["skill_2"].asInt();
					for (unsigned eq_idx = 0; eq_idx < npcJson["equip"].size(); ++eq_idx)
					{
						npc.equipList.push_back(BattleEquip(npcJson["equip"][eq_idx][0u].asUInt(),
									npcJson["equip"][eq_idx][1u].asInt(),
									npcJson["equip"][eq_idx][2u].asUInt()));
					}
					map_data->npcList.push_back(npc);
				}
				sBattlePtr bptr = map_sys.npcSide(map_data);
				manList& ml = bptr->battleMan;
				for (unsigned i = 0; i < ml.size(); ++i)
					map_data->npcList[i].maxHp = ml[i]->currentHP;
				_npc_data[map_data->mapID] = map_data;

				std::string path = "./report/expedition/" + Common::toString(map_data->mapID);
				Common::createDirectories(path);
			}
		}

		MapDataMgr::MapDataMgr()
		{
			loadMapData();
		}
		
		void MapDataMgr::loadMapData()
		{
			const static char* str[] = {"1", "2", "3", "4"};
			for (unsigned i = 0; i < sizeof(str) / sizeof(char*); ++i)
			{
				std::string file = "./instance/expedition/map/map_data_";
				file += str[i];
				file += ".json";
				const Json::Value json = Common::loadJsonFile(file);
				_map_data.push_back(MapData(json));
			}
		}

		void MapDataMgr::getBaseInfo(playerDataPtr d, qValue& q) const
		{
			return _map_data[season_sys.getSeason()].getBaseInfo(d, q);
		}

		MapPtr MapDataMgr::getMapData(playerDataPtr d, int pos) const
		{
			return _map_data[season_sys.getSeason()].getMapData(d, pos);
		}

		class RankReward
		{
			SINGLETON(RankReward);
			public:
				int maxSize() const { return _reward.size(); }
				const Json::Value& Get(int rk) const
				{
					return _reward[rk - 1];
				}
			private:
				void loadFile();
			private:
				std::vector<Json::Value> _reward;
		};

		RankReward::RankReward()
		{
			loadFile();
		}

		void RankReward::loadFile()
		{
			const Json::Value info = Common::loadJsonFile("./instance/expedition/rank_reward.json");
			ForEachC(Json::Value, it, info)
				_reward.push_back(*it);
		}

		RankKey::RankKey(playerDataPtr d, int type, int season)
		{
			pid = d->ID();
			if (type == DailyKey)
				record = d->Expedition().getDailyRecord();
			else
				record = d->Expedition().getHistoryRecord(season);
		}

		RankItem::RankItem(playerDataPtr d, int type, int season)
			: RankKey(d, type, season)
		{
			_name = d->Name();
			_nation = d->Info().Nation();
		}

		void RankItem::getInfo(qValue& q) const
		{
			q << _pid << _name << _nation << _progress << _time << _percent;
		}

		DailyRank::DailyRank()
			: _next_tick_time(0)
		{
			loadDB();
			startTimer();
		}

		void DailyRank::startTimer()
		{
			Timer::AddEventTickTime(boostBind(DailyRank::tick, this), Inter::event_expedition_timer, _next_tick_time);
		}

		void DailyRank::loadDB()
		{
			objCollection objs = db_mgr.Query(DBN::dbPlayerExpedition);
			std::vector<RankKey> sorted_rank;
			ForEachC(objCollection, it, objs)
			{
				const mongo::BSONObj& obj = *it;
				int pid = obj[strPlayerID].Int();
				playerDataPtr d = player_mgr.getPlayer(pid);
				if (!d) continue;
				const Record& r = d->Expedition().getDailyRecord();
				if (r.progress > 0)
					sorted_rank.push_back(RankKey(d, DailyKey));
			}
			std::sort(sorted_rank.begin(), sorted_rank.end());
			for (int i = sorted_rank.size() - 1; i >= 0; --i)
			{
				playerDataPtr d = player_mgr.getPlayer(sorted_rank[i].pid);
				if (!d) continue;
				_rank_list.insert(Creator<RankItem>::Create(d, DailyKey));
			}

			mongo::BSONObj key = BSON("key" << "daily_rank" << "season" << -1);
			mongo::BSONObj obj = db_mgr.FindOne(DBN::dbExpedition, key);
			if (obj.isEmpty())
			{
				_next_tick_time = player_mgr.stander5();
				_season = season_sys.getSeason(_next_tick_time - 1);
			}
			else
			{
				_next_tick_time = obj["ntt"].Int();
				_season = obj["se"].Int();
			}
		}

		void DailyRank::update(playerDataPtr d, const RankKey& old_key)
		{
			_rank_list.update(Creator<RankItem>::Create(d, DailyKey), old_key);
		}

		void DailyRank::alterName(playerDataPtr d)
		{
			RankKey key(d, DailyKey);
			RankItemPtr ptr = _rank_list.getValueByKey(key);
			if (!ptr) return;
			ptr->alterName(d->Name());
		}

		void DailyRank::tick()
		{
			_rk = 0;
			_rank_list.run(boostBind(DailyRank::clearItem, this, _1));
			_rank_list.clear();

			unsigned cur_time = Common::gameTime();
			_next_tick_time = Common::getNextTimeHMS(cur_time, 5);
			_season = season_sys.getSeason(cur_time);
			startTimer();
			_sign_save();
		}

		bool DailyRank::_auto_save()
		{
			mongo::BSONObj key = BSON("key" << "daily_rank" << "season" << -1);
			mongo::BSONObj obj = BSON("key" << "daily_rank" << "season" << -1
				<< "ntt" << _next_tick_time << "se" << _season);
			return db_mgr.SaveMongo(DBN::dbExpedition, key, obj);
		}

		void DailyRank::getInfo(playerDataPtr d, qValue& q)
		{
			RankKey key(d, DailyKey);
			int rk = _rank_list.getRank(key);
			q.addMember("rk", rk == 0? -1 : rk);
			_info.toArray();
			_rank_list.run(boostBind(DailyRank::packageItem, this, _1), 0, MaxRankSize);
			q.addMember("rl", _info);
		}

		void DailyRank::packageItem(const RankItem& item)
		{
			qValue tmp;
			item.getInfo(tmp);
			_info << tmp;
		}

		void DailyRank::clearItem(const RankItem& item)
		{
			++_rk;
			playerDataPtr d = player_mgr.getPlayer(item.pid());
			if (!d) return;
			d->Expedition().clearDailyProgress();
			int max_size = RankReward::shared().maxSize();
			if (_rk > max_size)
				return;
			const Json::Value& rw = RankReward::shared().Get(_rk);
			Json::Value pl;
			pl.append(item.value());
			pl.append(_rk);
			EmailPtr e = email_sys.createPackage(EmailDef::ExpeditionRankReward, pl, rw);
			email_sys.sendToPlayer(d->ID(), e);
		}

		HistoryRank::HistoryRank(int season)
			: _season(season), _next_tick_time(0), _rank_list(MaxRankSize)
		{
			loadDB();	
			startTimer();
		}

		void HistoryRank::loadDB()
		{
			mongo::BSONObj key = BSON("key" << "history_rank" << "season" << _season);
			mongo::BSONObj obj = db_mgr.FindOne(DBN::dbExpedition, key);
			if (obj.isEmpty())
				return;
			_rank_info = qValue(obj["ri"].String().c_str());
			_next_tick_time = obj["ntt"].Int();
			{
				std::vector<mongo::BSONElement> ele = obj["rm"].Array();
				for (unsigned i = 0; i < ele.size(); ++i)
					_rank_map.insert(make_pair(ele[i]["p"].Int(), ele[i]["r"].Int()));
			}

			objCollection objs = db_mgr.Query(DBN::dbPlayerExpedition);
			std::vector<RankKey> sorted_rank;
			ForEachC(objCollection, it, objs)
			{
				const mongo::BSONObj& obj = *it;
				int pid = obj[strPlayerID].Int();
				playerDataPtr d = player_mgr.getPlayer(pid);
				if (!d) continue;
				const Record& r = d->Expedition().getHistoryRecord(_season);
				if (r.progress > 0)
					sorted_rank.push_back(RankKey(d, HistoryKey, _season));
			}
			std::sort(sorted_rank.begin(), sorted_rank.end());
			for (int i = sorted_rank.size() - 1; i >= 0; --i)
			{
				if (_rank_list.size() >= MaxRankSize)
					break;
				playerDataPtr d = player_mgr.getPlayer(sorted_rank[i].pid());
				if (!d) continue;
				_rank_list.insert(Creator<RankItem>::Create(d, HistoryKey, _season));
			}
		}

		void HistoryRank::alterName(playerDataPtr d)
		{
			RankKey key(d, HistoryKey, _season);
			RankItemPtr ptr = _rank_list.getValueByKey(key);
			if (!ptr) return;
			ptr->alterName(d->Name());
		}

		void HistoryRank::update(playerDataPtr d, const RankKey& old_key)
		{
			_rank_list.update(Creator<RankItem>::Create(d, HistoryKey, _season), old_key);
		}

		void HistoryRank::getInfo(playerDataPtr d, qValue& q)
		{
			int rk = -1;
			std::map<int, int>::const_iterator it = _rank_map.find(d->ID());
			if (it != _rank_map.end())
				rk = it->second;
			q.addMember("rk", rk);
			q.addMember("rl", _rank_info.Copy());
		}

		void HistoryRank::packageItem(const RankItem& item)
		{
			++_rk;
			playerDataPtr d = player_mgr.getPlayer(item.pid());
			if (!d) return;
			qValue tmp;
			item.getInfo(tmp);
			_rank_info << tmp;
			_rank_map.insert(make_pair(d->ID(), _rk));
		}

		unsigned HistoryRank::getNextTickTime()
		{
			unsigned cur_time = Common::gameTime();
			unsigned next_tick_time = (cur_time / HOUR  + 1) * HOUR;
			int season = season_sys.getSeason(next_tick_time - 1);
			if (season != _season)
				next_tick_time = season_sys.getNSTimeHMS(cur_time, (SEASON::Quarter)_season, 6, 0, 0);
			return next_tick_time;
		}

		void HistoryRank::startTimer()
		{
			if (_next_tick_time == 0)
				_next_tick_time = getNextTickTime();
			Timer::AddEventTickTime(boostBind(HistoryRank::tick, this), Inter::event_expedition_timer, _next_tick_time);
		}

		void HistoryRank::tick()
		{
			_rk = 0;
			_rank_info.toArray();
			_rank_map.clear();
			_rank_list.run(boostBind(HistoryRank::packageItem, this, _1), 0, MaxRankSize);

			_next_tick_time = getNextTickTime();
			Timer::AddEventTickTime(boostBind(HistoryRank::tick, this), Inter::event_expedition_timer, _next_tick_time);
			_sign_save();
		}

		bool HistoryRank::_auto_save()
		{
			mongo::BSONObj key = BSON("key" << "history_rank" << "season" << _season);
			mongo::BSONObjBuilder obj;
			obj << "key" << "history_rank" << "season" << _season << "ri" << _rank_info.toIndentString() << "ntt" << _next_tick_time;
			{
				mongo::BSONArrayBuilder b;
				for (std::map<int, int>::const_iterator it = _rank_map.begin(); it != _rank_map.end(); ++it)
					b.append(BSON("p" << it->first << "r" << it->second));
				obj << "rm" << b.arr();
			}
			return db_mgr.SaveMongo(DBN::dbExpedition, key, obj.obj());
		}

		RankMgr::RankMgr()
		{
			for (unsigned i = 0; i < 4; ++i)
			{
				HistoryRankPtr ptr = Creator<HistoryRank>::Create(i);
				_history_rank.push_back(ptr);
			}
		}

		void RankMgr::getHistoryInfo(playerDataPtr d, qValue& q)
		{
			int season = season_sys.getSeason();
			_history_rank[season]->getInfo(d, q);
		}

		void RankMgr::getDailyInfo(playerDataPtr d, qValue& q)
		{
			_daily_rank.getInfo(d, q);
		}

		void RankMgr::updateDaily(playerDataPtr d)
		{
			_daily_rank.update(d);
		}

		void RankMgr::updateHistory(playerDataPtr d, int season, const RankKey& key)
		{
			_history_rank[season]->update(d, key);
		}

		void RankMgr::tick()
		{
			_daily_rank.tick();
		}

		void RankMgr::updateName(playerDataPtr d)
		{
			_daily_rank.updateName(d);
			for (unsigned i = 0; i < 4; ++i)
				_history_rank[i]->updateName(d);
		}
	}
}

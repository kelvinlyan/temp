#include "skill.h"

namespace gg
{
	skillManager* const skillManager::_Instance = new skillManager();
	typedef boost::function<void(BUFF::Data&, Json::Value&)> EffectFunc;
	typedef boost::function<void(SKILL::declare&, Json::Value&)> DeclareFunc;
	typedef boost::function<void(AIM::structAIM&, Json::Value&)> AIMFunc;
	typedef boost::unordered_map<int, EffectFunc> EffectMap;
	typedef boost::unordered_map<int, DeclareFunc> DeclareMap;
	typedef boost::unordered_map<int, AIMFunc> AIMMap;
	static EffectMap mapEffect;
	static DeclareMap mapDeclare;
	static AIMMap mapAIM;

	//buff
	static void formatStun(BUFF::Data& data, Json::Value& declareJson)
	{
		BUFF::stunEffect& stunData = data.otherData._stun;
		stunData.immediately = declareJson.isMember("immediately") ? declareJson["immediately"].asBool() : true;
		stunData.passFirst = declareJson.isMember("passFirst") ? declareJson["passFirst"].asBool() : true;
		stunData.effectRate = declareJson.isMember("effectRate") ? declareJson["effectRate"].asInt() : 10000;
	}

	static void formatEffectAttri(BUFF::Data& data, Json::Value& declareJson)
	{
		BUFF::attriEffect& attriData = data.otherData._attri;
		memset(attriData.attri, 0x0, sizeof(attriData.attri));
		for (unsigned i = 0; i < declareJson["attri"].size() && i < characterNum; ++i)
		{
			attriData.attri[i] = declareJson["attri"][i].asInt();
		}
	}

	static void formatEffectAlter(BUFF::Data& data, Json::Value& declareJson)
	{
		BUFF::alterEffect& alterData = data.otherData._alter;
		alterData.fixValue = declareJson["fixValue"].asInt();
		alterData.rate = declareJson.isMember("rate") ? declareJson["rate"].asDouble() : 0.0;
		alterData.idxAttri = declareJson["idxAttri"].asInt();
		alterData.firstShield = declareJson.isMember("firstShield") ? declareJson["firstShield"].asBool() : true;
		alterData.isDynamic = declareJson.isMember("isDynamic") ? declareJson["isDynamic"].asBool() : true;
		alterData.isCurrent = declareJson.isMember("isCurrent") ? declareJson["isCurrent"].asBool() : true;
	}

	static void formatEffect(BUFF::Data& data, Json::Value& declareJson)
	{
		data.buffID = declareJson["buffID"].asInt() * 1000 + declareJson["effectID"].asInt();// 1000���¼�
		data.lastRound = declareJson["lastRound"].asUInt() < 1 ? 1 : declareJson["lastRound"].asUInt();
		//data.lastRound = declareJson["lastRound"].asUInt();//0Ϊ��ǰ�غ���Ч
		data.type = declareJson.isMember("type") ? (BUFF::efType)declareJson["type"].asInt() : BUFF::buff;
		data.weight = declareJson["weight"].asInt();// 1000���¼�
		data.runTick = declareJson.isMember("tick") ? declareJson["tick"].asUInt() : (BUFF::action_begin | BUFF::attack_round);
		data.cleanTick = declareJson["cleanTick"].asUInt();//����ʱ��
		//data.cleanTick = data.cleanTick != BUFF::action_begin ? BUFF::action_end : BUFF::action_begin;
		EffectMap::iterator it = mapEffect.find(data.buffID % BUFF::BUFFOFFSET);
		if (it != mapEffect.end())
		{
			it->second(data, declareJson);
		}
	}

	//��������
	static void formatEntity(SKILL::skillEntity& entity, Json::Value& partJson);

	static void formatDeclare(SKILL::declare& decl, Json::Value& declareJson)
	{
		decl._Base.runID = declareJson["runID"].asInt();
		decl._Base.runRate = declareJson.isMember("runRate") ? declareJson["runRate"].asInt() : 10000;
		decl._Base.sign = declareJson.isMember("sign") ? declareJson["sign"].asUInt() : 100;
		decl._Base.refdelare = declareJson.isMember("refdelare") ? declareJson["refdelare"].asInt() : -1;
		decl._Base.refaim = declareJson.isMember("refaim") ? declareJson["refaim"].asInt() : 0;
		decl._Base.condition = declareJson.isMember("condition") ? declareJson["condition"].asUInt() : 0;
		decl._Base.userLimit = declareJson.isMember("userLimit") ? declareJson["userLimit"].asUInt() : SKILL::limit_user_alive;
		decl._Base.dependent = declareJson.isMember("dependent") ? declareJson["dependent"].asBool() : true;
		DeclareMap::iterator it = mapDeclare.find(decl._Attack.runID);
		if (it != mapDeclare.end())
		{
			it->second(decl, declareJson);
		}
	}

	static void formatAttack(SKILL::declare& decl, Json::Value& declareJson)
	{
		decl._Attack.critical = declareJson.isMember("critical") ? declareJson["critical"].asBool() : true;
		decl._Attack.block = declareJson.isMember("block") ? declareJson["block"].asBool() : true;
		decl._Attack.dodge = declareJson.isMember("dodge") ? declareJson["dodge"].asBool() : true;
		decl._Attack.module = declareJson.isMember("module") ? declareJson["module"].asDouble() : 1.0;//����������
		decl._Attack.module = decl._Attack.module < 0.0 ? 0.0 : decl._Attack.module;
		decl._Attack.critModule = declareJson.isMember("critModule") ? declareJson["critModule"].asDouble() : 1.5;//����������
		decl._Attack.critModule = decl._Attack.critModule < 0.0 ? 0.0 : decl._Attack.critModule;
		decl._Attack.againstModule = declareJson.isMember("againstModule") ? declareJson["againstModule"].asDouble() : 0.0;//����������
		decl._Attack.againstModule = decl._Attack.againstModule < 0.0 ? 0.0 : decl._Attack.againstModule;
		decl._Attack.moraleJoin = declareJson.isMember("moraleJoin") ? declareJson["moraleJoin"].asBool() : true;
		decl._Attack.damageDecay = declareJson.isMember("damageDecay") ? declareJson["damageDecay"].asDouble() : 0.0;//����������
		decl._Attack.damageDecay = decl._Attack.damageDecay < 0.0 ? 0.0 : decl._Attack.damageDecay;
		decl._Attack.moraleNum = declareJson.isMember("moraleNum") ? declareJson["moraleNum"].asInt() : 34;//Ĭ��34
		decl._Attack.moraleNum = decl._Attack.moraleNum < 1 ? 1 : decl._Attack.moraleNum;
		decl._Attack.moraleMode = declareJson.isMember("moraleMode") ? declareJson["moraleMode"].asUInt() : 0x3;//Ĭ��0x3
		decl._Attack.usePool = declareJson.isMember("usePool") ? declareJson["usePool"].asBool() : true;
	}

	static void formatCure(SKILL::declare& decl, Json::Value& declareJson)
	{
		decl._Cure.module_1 = declareJson.isMember("module_1") ? declareJson["module_1"].asDouble() : 2.0;
		decl._Cure.module_2 = declareJson.isMember("module_2") ? declareJson["module_2"].asInt() : 40;
		decl._Cure.module_3 = declareJson.isMember("module_3") ? declareJson["module_3"].asDouble() : 0.25;
		decl._Cure.module_4 = declareJson.isMember("module_4") ? declareJson["module_4"].asDouble() : 0.0;
	}

	static void formatAbsorb(SKILL::declare& decl, Json::Value& declareJson)
	{
		decl._Absorb.clear = declareJson.isMember("clear") ? declareJson["clear"].asBool() : true;
		decl._Absorb.fix = declareJson.isMember("fix") ? declareJson["fix"].asInt() : 0;
		decl._Absorb.rate = declareJson.isMember("rate") ? declareJson["rate"].asDouble() : 1.0;
	}

// 	static void formatAbsorbMp(SKILL::declare& decl, Json::Value& declareJson)
// 	{
// 		formatAbsorb(decl, declareJson);
// 		//buff
// 		BUFF::Data& effectEntity = decl._AbsorbMp._effect;
// 		effectEntity.buffID = declareJson["buffID"].asInt() * 1000 + BUFF::last_alter_mp;
// 		effectEntity.lastRound = 1;
// 		effectEntity.type = BUFF::buff;
// 		effectEntity.weight = declareJson["weight"].asInt();
// 		effectEntity.tick = (BUFF::action_end | BUFF::attack_round | BUFF::counter_round);
// 		//buff detail
// 		effectEntity.otherData._alter.fixValue = 0;
// 		effectEntity.otherData._alter.rate = 0.0;
// 		effectEntity.otherData._alter.idxAttri = 0.0;
// 		effectEntity.otherData._alter.firstShield = true;
// 		effectEntity.otherData._alter.isDynamic = false;
// 		effectEntity.otherData._alter.isCurrent = false;
// 	}

	static void formatAlterMpF1(SKILL::declare& decl, Json::Value& declareJson)
	{
		decl._AlterMPF1.userIDX = declareJson["userIDX"].asInt();
		decl._AlterMPF1.aimIDX = declareJson["aimIDX"].asInt();
		decl._AlterMPF1.fixValue = declareJson["fixValue"].asInt();
		decl._AlterMPF1.minValue = declareJson["minValue"].asInt();
		decl._AlterMPF1.maxValue = declareJson["maxValue"].asInt();
		decl._AlterMPF1.reduce = declareJson.isMember("reduce") ? declareJson["reduce"].asBool() : true;
	}

	static void formatMorale(SKILL::declare& decl, Json::Value& declareJson)
	{
		decl._MPAlter.num = declareJson.isMember("num") ? declareJson["num"].asInt() : 0;
		decl._MPAlter.usePool = declareJson.isMember("usePool") ? declareJson["usePool"].asBool() : true;
	}

	static void formatDirect(SKILL::declare& decl, Json::Value& declareJson)
	{
		decl._TrueDamage.precentTotalHP = declareJson.isMember("precentTotalHP") ? declareJson["precentTotalHP"].asDouble() : 0.0;
		decl._TrueDamage.precentHP = declareJson.isMember("precentHP") ? declareJson["precentHP"].asDouble() : 0.0;
		decl._TrueDamage.precentAttri = declareJson.isMember("precentAttri") ? declareJson["precentAttri"].asDouble() : 0.0;
		decl._TrueDamage.idxAttri = declareJson.isMember("idxAttri") ? declareJson["idxAttri"].asInt() : 0;
		decl._TrueDamage.fixDamage = declareJson.isMember("fixDamage") ? declareJson["fixDamage"].asInt() : 0;
	}

	static void formatShield(SKILL::declare& decl, Json::Value& declareJson)
	{
		decl._Shield.precentAttri = declareJson.isMember("precentAttri") ? declareJson["precentAttri"].asDouble() : 0.0;
		decl._Shield.idxAttri = declareJson.isMember("idxAttri") ? declareJson["idxAttri"].asInt() : 0;
		decl._Shield.fixValue = declareJson.isMember("fixDamage") ? declareJson["fixDamage"].asInt() : 0;
	}

	static void formatBuff(SKILL::declare& decl, Json::Value& declareJson)
	{
		const int buffID = declareJson["fileID"].asInt();
		Json::Value jsonBuff = Common::loadJsonFile("./instance/effect/buff_" + Common::toString(buffID) + ".json");
		formatEffect(decl._Effect._effect, jsonBuff);
	}
	
	static void formatChild(SKILL::declare& decl, Json::Value& declareJson)
	{
		decl._Child.childID = declareJson["child"].asInt();
		decl._Child.child = new(::GNew(sizeof(SKILL::skillEntity))) SKILL::skillEntity();
		Json::Value child_json = Common::loadJsonFile("./instance/skill/skill_" + Common::toString(decl._Child.childID) + ".json");
		formatEntity(*(decl._Child.child), child_json);
	}

	//Ŀ��
	static void formatAIM(AIM::structAIM& aim, Json::Value& aimJson)
	{
		aim.selectID = aimJson.isMember("selectID") ? aimJson["selectID"].asInt() : AIM::single;
		const int status = aimJson.isMember("condition") ? aimJson["condition"].asInt() : AIM::aim_alive;
		aim.isOpp = aimJson.isMember("isOpp") ? aimJson["isOpp"].asBool() : false;
		aim.holdMorale = status & AIM::aim_hold_morale;
		aim.less100Morale = status & AIM::aim_morale_less100;
		aim.over100Morale = status & AIM::aim_morale_over100;
		aim.aliveAim = status & AIM::aim_alive;
		aim.deadAim = status & AIM::aim_dead;
		aim.camp = aimJson["camp"].asInt();
		AIMMap::iterator it = mapAIM.find(aim.selectID);
		if (it != mapAIM.end())
		{
			it->second(aim, aimJson);
		}
	}

	static void formatAIMBase(AIM::structAIM& aim, Json::Value& aimJson)
	{
		aim.camp = (aim.camp < 0 || aim.camp > 1) ? 1 : aim.camp;
	}

	static void formatAIMFollow(AIM::structAIM& aim, Json::Value& aimJson)
	{
		aim.camp = -1;
		aim.otherData.Follow.followIdx = aimJson["followIdx"].asUInt();
		aim.otherData.Follow.newStatus = aimJson.isMember("newStatus") ? aimJson["newStatus"].asBool() : true;
	}

	static void formatAIMRandom(AIM::structAIM& aim, Json::Value& aimJson)
	{
		aim.camp = aimJson["camp"].asInt();
		aim.camp = (aim.camp < 0 || aim.camp > 1) ? 1 : aim.camp;
		aim.otherData.Romdom.rNum = aimJson["rNum"].asUInt();
		aim.otherData.Romdom.rNum = aim.otherData.Romdom.rNum < 1 ? 1 : aim.otherData.Romdom.rNum;
	}

	//��������
	static void formatEntity(SKILL::skillEntity& entity, Json::Value& partJson)
	{
		AIM::structAIM& aim = entity.aim;
		entity.bringCounter = partJson.isMember("bringCounter") ? partJson["bringCounter"].asBool() : false;
		entity.counterLimit = partJson.isMember("counterLimit") ? partJson["counterLimit"].asUInt() : 0;
		formatAIM(aim, partJson["aim"]);
		entity.entity.clear();
		for (unsigned i = 0; i < partJson["entity"].size(); ++i)
		{
			SKILL::declare decl;
			Json::Value& declareJson = partJson["entity"][i];
			formatDeclare(decl, declareJson);
			entity.entity.push_back(decl);
		}
	}

	void skillManager::initData()
	{
		//buff
		mapEffect[BUFF::stun] = boostBind(formatStun, _1, _2);
		mapEffect[BUFF::bonus_attri] = boostBind(formatEffectAttri, _1, _2);
		mapEffect[BUFF::bonus_attri_rate] = boostBind(formatEffectAttri, _1, _2);
		mapEffect[BUFF::last_alter_hp] = boostBind(formatEffectAlter, _1, _2);
		mapEffect[BUFF::last_alter_mp] = boostBind(formatEffectAlter, _1, _2);
		//declare
		mapDeclare[SKILL::action_phy] = boostBind(formatAttack, _1, _2);
		mapDeclare[SKILL::action_war] = boostBind(formatAttack, _1, _2);
		mapDeclare[SKILL::action_rage] = boostBind(formatAttack, _1, _2);
		mapDeclare[SKILL::action_magic] = boostBind(formatAttack, _1, _2);
		mapDeclare[SKILL::action_attack_mp] = boostBind(formatMorale, _1, _2);
		mapDeclare[SKILL::action_cure_hp] = boostBind(formatCure, _1, _2);
		mapDeclare[SKILL::action_cure_mp] = boostBind(formatCure, _1, _2);
		mapDeclare[SKILL::action_absorb_hp] = boostBind(formatAbsorb, _1, _2);
		//mapDeclare[SKILL::action_absorb_mp] = boostBind(formatAbsorbMp, _1, _2);
		mapDeclare[SKILL::action_absorb_mp] = boostBind(formatAbsorb, _1, _2);
		mapDeclare[SKILL::action_set_buff] = boostBind(formatBuff, _1, _2);
		mapDeclare[SKILL::action_child_skill] = boostBind(formatChild, _1, _2);
		mapDeclare[SKILL::action_direct_damage] = boostBind(formatDirect, _1, _2);
		mapDeclare[SKILL::action_shield] = boostBind(formatShield, _1, _2);
		mapDeclare[SKILL::action_mp_set] = boostBind(formatMorale, _1, _2);
		mapDeclare[SKILL::action_alter_mp_formula_1] = boostBind(formatAlterMpF1, _1, _2);
		//aim
		mapAIM[AIM::follow] = boostBind(formatAIMFollow, _1, _2);
		mapAIM[AIM::single] = boostBind(formatAIMBase, _1, _2);
		mapAIM[AIM::line] = boostBind(formatAIMBase, _1, _2);
		mapAIM[AIM::row] = boostBind(formatAIMBase, _1, _2);
		mapAIM[AIM::cross] = boostBind(formatAIMBase, _1, _2);
		mapAIM[AIM::current] = boostBind(formatAIMBase, _1, _2);
		mapAIM[AIM::all] = boostBind(formatAIMBase, _1, _2);
		mapAIM[AIM::other] = boostBind(formatAIMBase, _1, _2);
		mapAIM[AIM::random] = boostBind(formatAIMRandom, _1, _2);


		cout << "load ./instance/skill/" << endl;
		mapSkill.clear();
		FileJsonSeq seq = Common::loadFileJsonFromDir("./instance/skill/");
		for (unsigned i = 0; i < seq.size(); ++i)
		{
			Json::Value& json = seq[i];
			SkillPtr skill =  Creator<skillDeclare>::Create();
			skill->skillID = json["skillID"].asInt();
			SKILL::skillEntity& entity = skill->skillRun;
			formatEntity(entity, json);
			mapSkill[skill->skillID] = skill;
		}
	}

	const skillDeclare* skillManager::getSkill(const int ID)
	{
		skillMap::iterator it = mapSkill.find(ID);
		if (it == mapSkill.end())return NULL;
		return it->second.get();
	}
}
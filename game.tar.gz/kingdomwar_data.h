#pragma once

#include "kingdomwar_def.h"
#include "kingdomwar_helper.h"
#include "battle_def.h"
#include "mongoDB.h"
#include "auto_base.h"
#include "rank_list.h"
#include "battle_system.h"
#include "action_system.h"

namespace gg
{
	namespace KingdomWar
	{
		enum
		{
			ServerError = 0x7FFFFFFF,
			TowerItemPrimeRate = 2,
		};

		class RankItem
		{
			public:
				RankItem(playerDataPtr d);
				RankItem(playerDataPtr d, int exploit);
				
				void getInfo(qValue& q) const;

				int id() const { return _pid; }
				int value() const { return _exploit; }

			private:
				int _pid;
				std::string _name;
				int _nation;
				int _exploit;
		};

		BOOSTSHAREPTR(RankItem, RankItemPtr);

		class RankMgr
		{
			SINGLETON(RankMgr);
			public:
				void update(playerDataPtr d, int old_value);
				void insert(playerDataPtr d, int exploit);
				void getInfo(playerDataPtr d, int begin, int end, qValue& q);
				int getRank(playerDataPtr d) const;
				void tickRank();
				void packageInfo(const RankItem& item);
				void tickRankItem(const RankItem& item);
				void tickClearItem(const RankItem& item);
				unsigned size() const { return _rank.size(); }

			private:
				typedef RankList1<RankItem> RankList;
				RankList _rank;

				// temp
				qValue _info;
				int _rk;
		};

		

		class State
			: public _auto_meta
		{
			SINGLETON_PTR(State);
			public:
				int get() const { return _state; }
				bool isOpened() const { return _state == KingdomWar::Opened; }
				bool unityFlag() const { return _unity_flag; }
				unsigned next5MinTime() const { return _next_5_min_tick_time; }
				unsigned nextTickTime() const { return _next_tick_time; }
				unsigned nextClearTime() const { return _next_clear_time; }
				unsigned nextTime05_00() const { return _next_time_05_00; }
				unsigned nextTime20_00() const { return _next_time_20_00; }
				unsigned nextTime03_00() const { return _next_time_03_00; }

				void reset5MinTime();
				void resetClearTime();
				void resetTickTimeAndState();
				void resetTime05_00();
				void resetTime20_00();
				void resetTime03_00();
				void setUnityFlag();
				void clearUnityFlag();

			private:
				void init();
				virtual bool _auto_save();

			private:
				unsigned _next_5_min_tick_time;
				unsigned _next_tick_time;
				unsigned _next_clear_time;
				int _state;
				bool _unity_flag;


				unsigned _next_time_03_00;
				unsigned _next_time_05_00;
				unsigned _next_time_20_00;
		};

		class PrimeState
			: public _auto_meta
		{
			SINGLETON_PTR(PrimeState);
			public:
				int Get() const { return _prime_state; }
				unsigned nextTickTime() const { return _next_tick_time; }
				void tick();
				operator bool() const { return _prime_state == PrimeTime; }

			private:
				void loadDB();
				void init();
				virtual bool _auto_save();

			private:
				bool _inited;
				int _prime_state;
				unsigned _next_index;
				unsigned _next_tick_time;

				int _last_prime_state;
				unsigned _last_index;
				unsigned _last_tick_time;

				struct Item
				{
					Item(unsigned t, int s)
						: tick_time(t), state(s){}
					bool operator<(const Item& rhs) const
					{
						return tick_time < rhs.tick_time;
					}
					unsigned tick_time;
					int state;
				};

				std::vector<Item> _cur_items;
				std::vector<Item> _backup_items;
		};

		class Sign
			: public _auto_meta
		{
			public:
				Sign(int nation);
				void init(const mongo::BSONObj& obj);
				void getInfo(qValue& q);
				void sendChatInfo(playerDataPtr d);
				int setSign(playerDataPtr d, int type, int id, const std::string& str);
				void clear();

			private:
				virtual bool _auto_save();

			private:
				const int _nation;
				struct Item
				{
					Item(int i, const std::string& s)
						: id(i), str(s){}
					void getInfo(qValue& q) const
					{
						q << id << str;
					}
					int id;
					std::string str;
				};
				STDVECTOR(Item, IDList);
				IDList _id_list;
		};

		BOOSTSHAREPTR(Sign, SignPtr);
		STDVECTOR(SignPtr, Signs);

		class SignList
		{
			SINGLETON(SignList);
			public:
				int setSign(playerDataPtr d, int type, int id, const std::string& str);
				void sendChatInfo(playerDataPtr d);
				void getInfo(qValue& q, int nation);
				void clear();

			private:
				void init();

			private:
				Signs _sign;
		};

		class KingdomBuff
			: public _auto_meta
		{
			SINGLETON_PTR(KingdomBuff);
			public:
				void init();
				void reset(unsigned tick_time);
				void getInfo(qValue& q);
				int getBuff(int nation);

			private:
				virtual bool _auto_save();

			private:
				int _max;
				int _min;
				int _add;
				std::vector<int> _change;

				std::vector<int> _buff;
		};

		struct NpcRule
		{
			NpcRule(const Json::Value& info);

			int _power_begin;
			int _power_end;
			int _npc_begin;
			int _npc_end;
			int _food;
			int _battle_value;
		};

		class NpcRuleMgr
		{
			SINGLETON(NpcRuleMgr);
			public:
				void tick()
				{
					_cur_index1 = -1;
					_cur_index2 = -1;
				}
				int food() const 
				{ 
					if (_cur_index1 == -1)
						resetIndex1();
					return _rule_list[_cur_index1]._food; 
				}
				int bv() const 
				{ 
					if (_cur_index1 == -1)
						resetIndex1();
					return _rule_list[_cur_index1]._battle_value; 
				}
				int npcID() const
				{
					if (_cur_index1 == -1)
						resetIndex1();
					return Common::randomBetween(
						_rule_list[_cur_index1]._npc_begin, _rule_list[_cur_index1]._npc_end);
				}
				int activeNpcID() const
				{
					if (_cur_index2 == -1)
						resetIndex2();
					return Common::randomBetween(
						_rule_list[_cur_index2]._npc_begin, _rule_list[_cur_index2]._npc_begin + 3);
				}
			private:
				void loadFile();
				void resetIndex1() const;
				void resetIndex2() const;
			private:
				std::vector<NpcRule> _rule_list;
				mutable int _cur_index1;
				mutable int _cur_index2;
				double _npc_rate;
		};

		class ShadowNpcRuleMgr
		{
			SINGLETON(ShadowNpcRuleMgr);
			public:
				void tick()
				{
					_cur_index = -1;
				}
				int food() const
				{
					if (_cur_index == -1)
						resetIndex();
					return _rule_list[_cur_index]._food;
				}
				int bv() const
				{
					if (_cur_index == -1)
						resetIndex();
					return _rule_list[_cur_index]._battle_value;
				}
				int npcID() const
				{
					if (_cur_index == -1)
						resetIndex();
					return Common::randomBetween(
						_rule_list[_cur_index]._npc_begin, _rule_list[_cur_index]._npc_end);
				}
			private:
				void loadFile();
				void resetIndex() const;
			private:
				std::vector<NpcRule> _rule_list;
				mutable int _cur_index;
		};

		struct HpDebuff
		{
			HpDebuff(int atk_debuff, int def_debuff)
				: _atk_debuff(atk_debuff), _def_debuff(def_debuff){}

			int _atk_debuff;
			int _def_debuff;
		};

		class GreatEvent
			: public _auto_meta
		{	
			public:
				GreatEvent(unsigned time, int nation, qValue& q)
					: _time(time), _nation(nation), _data(q){}
				GreatEvent(unsigned time, int nation, const std::string& str)
					: _time(time), _nation(nation), _data(str.c_str()){}

				void getInfo(qValue& q) { q = _data.Copy(); }
				unsigned time() const { return _time; }
				int nation() const { return _nation; }
				bool operator<(const GreatEvent& e) const
				{
					return _time < e._time;
				}

			private:
				virtual bool _auto_save();

			private:
				unsigned _time;
				int _nation;
				qValue _data;
		};

		BOOSTSHAREPTR(GreatEvent, GreatEventPtr);
		STDVECTOR(GreatEventPtr, GreatEventList);

		class GreatEventMgr
		{
			SINGLETON(GreatEventMgr);
			public:
				void getInfo(int idx, qValue& q)
				{
					q.addMember("n", (int)_data.size());
					if (idx > _data.size())
						return;
					qValue e;
					_data[_data.size() - idx]->getInfo(e);
					q.addMember("e", e);
				}
				void push(const GreatEventPtr& e)
				{
					if (e->time() <= _max_time)
					{
						LogE << "kingdom war great event time error:" << e->time() << "<=" << _max_time << LogEnd;
						return;
					}
					_max_time = e->time();
					_data.push_back(e); 
					e->_sign_save();
				}
				unsigned time(int idx) const
				{
					if (idx > _data.size())
						return 0;
					return _data[_data.size() - idx]->time();
				}
				int nation(int idx) const
				{
					if (idx > _data.size())
						return -1;
					return _data[_data.size() - idx]->nation();
				}
				unsigned maxTime() const { return _max_time; }
				GreatEventList newerGreatEvent(unsigned& max_time) const
				{
					GreatEventList e;
					for (GreatEventList::const_reverse_iterator it = _data.rbegin();
						it != _data.rend(); ++it)
					{
						if ((*it)->time() > max_time)
							e.push_back(*it);
						else
							break;
					}
					max_time = _max_time;
					return e;
				}

				const ActionRandomList& getReward(unsigned idx, int nation) const
				{
					if (idx > _data.size())
					{
						LogE << "kingdom war great event reward error:" << idx << ">" << _data.size() << LogEnd;
						return _lose_reward;
					}
					return nation == _data[_data.size() - idx]->nation()? _win_reward : _lose_reward;
				}

			private:
				void loadDB();
				void loadFile();

			private:
				GreatEventList _data;
				unsigned _max_time;
				ActionRandomList _win_reward;
				ActionRandomList _lose_reward;
		};

		class NpcIDCreator
			: public _auto_meta
		{
			SINGLETON_PTR(NpcIDCreator);
			public:
				int get();

			private:
				virtual bool _auto_save();
				
			private:
				int _id;
		};

		namespace nShadow
		{
			struct Cost
			{
				Cost(const Json::Value& info)
				{
					gold = info[0u].asInt();
					food = info[1u].asInt();
				}
				Cost(int g, int f)
					: gold(g), food(f){}
				bool valid() const { return gold != -1; }
				std::string toStr() const
				{
					Json::Value json = Json::arrayValue;
					if (gold > 0)
					{
						Json::Value tmp;
						tmp.append(ACTION::gold);
						tmp.append(gold);
						json.append(tmp);
					}
					if (food > 0)
					{
						Json::Value tmp;
						tmp.append(ACTION::food);
						tmp.append(food);
						json.append(tmp);
					}
					return json.toIndentString();
				}
				int gold;
				int food;
			};
		}

		class ShadowCost
		{	
			SINGLETON(ShadowCost);
			public:
				nShadow::Cost get(int type, playerDataPtr d, unsigned times) const;
				unsigned maxTimes(int type, int vip) const;
			private:
				void loadFile();
			private:
				STDVECTOR(nShadow::Cost, Costs);	
				STDVECTOR(Costs, Type2Costs);
				Type2Costs _costs;
				nShadow::Cost _error_cost;

				STDVECTOR(int, Times);
				STDVECTOR(Times, Vip2Times);
				Vip2Times _times;
		};

		class BoxLimit
		{
			SINGLETON(BoxLimit);
			public:
				int goldBoxTimes(int lv) const
				{
					if (lv > _gold_box.size())	
						lv = _gold_box.size();
					return _gold_box[lv - 1];
				}
				int silverBoxTimes(int lv) const
				{
					if (lv > _silver_box.size())	
						lv = _silver_box.size();
					return _silver_box[lv - 1];
				}
				int homeBoxTimes(int lv) const
				{
					if (lv > _home_box.size())	
						lv = _home_box.size();
					return _home_box[lv - 1];
				}
			private:
				void loadFile();
			private:
				STDVECTOR(int, Lv2Times);
				Lv2Times _gold_box;
				Lv2Times _silver_box;
				Lv2Times _home_box;
		};

		class NationParam
			: public _auto_meta
		{
			SINGLETON_PTR(NationParam);
			public:
				void reset();
				void getInfo(qValue& q, int nation) const;
				void alterTowerTimes(int nation);
				bool callTowerTimesLimit(int nation) const
				{
					return _call_tower_times[nation] >= _max_call_tower_times[nation];	
				}

			private:
				void init();
				void loadDB();
				void loadFile();
				virtual bool _auto_save();

			private:
				std::vector<unsigned> _call_tower_times;	
				std::vector<unsigned> _max_call_tower_times;
				std::vector<std::vector<unsigned> > _type_tower_times;
		};

		class ReturnParam
		{
			SINGLETON(ReturnParam);
			public:
				int shadowIndex() const { return _shadow_index; }
				void setShadowIndex(int val) { _shadow_index = val; }

				static int fight_army_id;
				static std::string fight_target_name;
				static int result;
				static int fight_target_type;

			private:
				int _shadow_index;
		};

		class ChannelMgr
		{
			SINGLETON(ChannelMgr);
			public:
				int send(playerDataPtr d, const std::string& str);
				void update(playerDataPtr d);

			private:
				void update(int nation);

			private:
				struct Message
				{
					Message(playerDataPtr d, const std::string& str);

					void getInfo(qValue& q);
				
					qValue player;
					std::string str;
				};
				STDLIST(Message, MsgList);
				std::vector<MsgList> _msg_lists;
		};

		struct ShadowItem
		{
			ShadowItem(const Json::Value& info)
			{
				item_id = info["item_id"].asInt();
				if (info["rate"] != Json::nullValue)
					rate = info["rate"].asDouble();
				else
					rate = 1.0;
			}
			int item_id;
			double rate;
		};

		struct TowerItem
		{
			TowerItem(const Json::Value& info)
			{
				item_id = info["item_id"].asInt();
				secs = info["secs"].asInt();
				exploit = info["exploit"].asInt();
			}
			int getSecs() const
			{
				return PrimeState::shared()? secs / TowerItemPrimeRate : secs;
			}
			int item_id;
			int secs;
			int exploit;
		};

		class ItemConfig
		{
			SINGLETON(ItemConfig);
			public:
				const ShadowItem& shadowItem(int type) const
				{
					return _shadow_items[type];
				}
				const TowerItem& towerItem(int type) const
				{
					return _tower_items[type];
				}
				int transferItemID() const { return _transfer_item_id; }
				int fightItemID() const { return _fight_item_id; }
			private:
				void loadFile();
			private:
				std::vector<ShadowItem> _shadow_items;
				std::vector<TowerItem> _tower_items;
				int _transfer_item_id;
				int _fight_item_id;
		};

	}

	class ExploitRankItem
	{
		public:
			ExploitRankItem(playerDataPtr d);

			void getInfo(qValue& q) const;
			
			int id() const { return _pid; }
			int value() const { return _exploit; }

		private:
			int _pid;
			std::string _name;
			int _nation;
			int _exploit;
			int _lv;
	};

	class ExploitRank
		: public _auto_meta
	{
		SINGLETON(ExploitRank);
		public:
			BOOSTSHAREPTR(ExploitRankItem, RankItem);

			void update(playerDataPtr d);
			void update(playerDataPtr d, int old_val);

			int rank(playerDataPtr d) const;

		private:
			void getInfo(qValue& q);
			void loadDB();
			void packageItem(const ExploitRankItem& e);
		
		private:
			typedef RankList1<ExploitRankItem> RankList;
			RankList _rank;

			//
			bool _modified;
			qValue _info;
			int _rk;
			std::map<int, int> _pid2rank;
	};
}

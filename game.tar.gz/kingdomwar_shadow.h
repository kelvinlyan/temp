#pragma once

#include "auto_base.h"
#include "mongoDB.h"
#include "battle_def.h"
#include "battle_system.h"
#include "kingdomwar_helper.h"
#include "kingdomwar_def.h"

namespace gg
{
	namespace KingdomWar
	{
		class ShadowData
			: public _auto_meta
		{
			public:
				ShadowData(const mongo::BSONObj& obj);
				ShadowData(playerDataPtr d, int army_id, const Position& pos, int hp);
				virtual ~ShadowData();

				int id() const { return _id; }
				int ownID() const { return _ptr->playerID; }
				int nation() const { return _ptr->playerNation; }
				const sBattlePtr& data() const { return _ptr; }

				int hp() const { return _army_hp; }
				int alterHp(int num);

				sBattlePtr getBattlePtr(int& max_hp, int& cur_hp);
				bool isDead() const;
				void setDead(unsigned cur_time, qValue& tips);

				const Position& position() const { return _pos; }
				void setPosition(int type, int id, unsigned time);

			private:
				virtual bool _auto_save();
				void removeDB();
				sBattlePtr createBattlePtr(const mongo::BSONElement& obj);
				mongo::BSONObj battlePtrBSON() const;

			private:
				bool _dead;
				int _id;
				sBattlePtr _ptr;
				int _army_hp;
				int _max_man_hp;
				Position _pos;
		};

		BOOSTSHAREPTR(ShadowData, ShadowDataPtr);
	}
}

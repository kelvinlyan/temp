//###################################
//create by Jim
//2016-02-02
//###################################

#pragma once

#include "auto_do.h"

namespace gg
{
	class playerCount;
	namespace CountData
	{
		class Data :
			public _auto_player
		{
			friend class ::gg::playerCount;
		public:
			Data(playerData* const own, const int id);
			~Data(){}

			virtual bool _auto_save();
		private:
			int getKey(const int id);
			unsigned getCount(const int id);
			void tickCount(const int id);
			void resetCount(const int id);
			const int seqID;
			std::vector<unsigned> seqCount;
		};
		BOOSTSHAREPTR(Data, CountPtr);
	}
	class playerCount :
		public _auto_player
	{
	public:
		playerCount(playerData* const own);
		~playerCount(){}

		unsigned getCount(const int id);
		void tickCount(const int id);
		void resetCount(const int id);

		//other
	private:
		virtual void classLoad();
		CountData::CountPtr getData(const int id);
		int getKey(const int id);
		UNORDERMAP(int, CountData::CountPtr, DataMap);
		DataMap mapData;
	};
}
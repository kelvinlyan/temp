#include "despatch_task.h"
#include "auto_do.h"

namespace gg
{
	std::queue<UserTask::BINDFUNCTION> UserTask::_TaskList;
	bool UserTask::_Once = false;

	void UserTask::shutDown()
	{
		do
		{
			if (_TaskList.empty())break;

			BINDFUNCTION current_fuction = _TaskList.front();
			_TaskList.pop();
			current_fuction();
		} while (true);
	}

	void UserTask::impl_run()
	{
		boost::system_time tick = boost::get_system_time();
		do
		{
			boost::system_time now_sys = boost::get_system_time();
			if ((now_sys - tick).total_milliseconds() > 300)break;//����300�������������

			if (_TaskList.empty())break;

			BINDFUNCTION current_fuction = _TaskList.front();
			_TaskList.pop();
			current_fuction();
		} while (true);

		if (!_TaskList.empty())
		{
			despatchPost(boost::bind(&UserTask::run_tick));
		}
	}

	void UserTask::run_tick()
	{
		_Once = true;
	}

	void UserTask::run()
	{
		if (_Once)
		{
			_Once = false;
			LogicPost(boost::bind(&UserTask::impl_run));
		}
		Common::sleep(1000000);//1s
		despatchPost(boost::bind(&UserTask::run));
	}

	void UserTask::initData()
	{
		despatchPost(boost::bind(&UserTask::run));
	}

	void UserTask::Add(BINDFUNCTION delay_task, const int eventID)
	{
		despatchPost(boostBind(UserTask::impl_add, delay_task, eventID));
	}

	void UserTask::impl_add(BINDFUNCTION delay_task, const int eventID)
	{
		_TaskList.push(boostBind(UserTask::task_box, delay_task, eventID));
		run_tick();
	}

	void UserTask::task_box(BINDFUNCTION delay_task, const int eventID)
	{
		State::setState(eventID);
		NumberCounter::Step();
		delay_task();
		helper_mgr._run_tick();
	}
}
﻿//###################################
//created by Lin Xing
//2016-11-23
//###################################
#pragma once

#include "commom.h"
#include "player_secondary_compensation.h"
#include "utility_lx.h"
#include "dbDriver.h"

#define secondary_compensation_sys (*gg::secondary_compensation_system::_Instance)

namespace gg
{
	
	namespace secondary_cps
	{
		typedef struct _girls
		{
			int cardID;
		}Girl;

		typedef struct _pairs
		{
			Girl girls[2];
		}Pairs;

		typedef struct _sec_cps_config
		{
			int gold;
			std::vector<Pairs> pairs;
			std::vector<int> Odds;
		}SecondaryCompensationConfig;
	}

	//	游戏内创建角色后的次日累冲活动“充值送秀女”
	class secondary_compensation_system
	{
	public:
		secondary_compensation_system();

		void initData();

		DeclareRegFunction(reqSecondaryInfo);
		DeclareRegFunction(reqSecondaryGetReward);
		DeclareRegFunction(reqSecondaryRedPoint);

		~secondary_compensation_system();
	public:
		static secondary_compensation_system* const _Instance;
	};
}


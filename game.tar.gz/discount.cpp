#include "discount.h"
#include "team_war.h"

namespace gg
{

	DiscountManager* const DiscountManager::_Instance = new DiscountManager();

	//��������
	static void DoTeamWarBox(const int type)
	{
		team_war.tickDiscoutBox(type);
	}

	typedef boost::function<void()> dealFunc;
	UNORDERMAP(int, dealFunc, DiscountDealMap);
	static DiscountDealMap staticDealMap;

	void DiscountManager::initData()
	{
		staticDealMap[Discount::team_war_drop_out_red_num] = boostBind(DoTeamWarBox, int(Discount::team_war_drop_out_red_num));
		staticDealMap[Discount::team_war_drop_out_purple_num] = boostBind(DoTeamWarBox, int(Discount::team_war_drop_out_purple_num));

		cout << "loading discount and gain ..." << endl;
		{
			BeginTime = 0;
			EndTime = 0;

			mongo::BSONObj obj = db_mgr.FindOne(DBN::dbDiscoutAndGain, BSON("t" << int(Discount::project_time)));
			if (!obj.isEmpty())
			{
				BeginTime = obj["op"].Int();
				EndTime = obj["ed"].Int();
			}
		};

		Datas.clear();
		objCollection objs = db_mgr.Query(DBN::dbDiscoutAndGain);
		for (unsigned i = 0; i < objs.size(); ++i)
		{
			mongo::BSONObj& obj = objs[i];
			Discount::ptrData ptr = Creator<Discount::Data>::Create(obj["t"].Int());
			if (ptr->Type < 0)continue;
			if(ptr->Type >= Discount::project_num)
			{
				ptr->del();
				continue;
			}
			ptr->Value = obj["v"].Int();
			Datas[ptr->Type] = ptr;
		}
	}

	double DiscountManager::getRate(const int type)
	{
		return 1.0 + getRateOnly(type);
	}

	double DiscountManager::getRateOnly(const int type)
	{
		DataMap::const_iterator it = Datas.find(type);
		if (it == Datas.end())return 0.0;
		return it->second->getRate();
	}

	int DiscountManager::getValue(const int type)
	{
		DataMap::const_iterator it = Datas.find(type);
		if (it == Datas.end())return 0;
		return it->second->getValue();
	}

	void DiscountManager::gm_discout_update(net::Msg& m, Json::Value& r)
	{
		Json::Value& time_json = r[strMsg][1u] = Json::arrayValue;
		time_json.append(Common::toStampTime(BeginTime));
		time_json.append(Common::toStampTime(EndTime));
		Json::Value& data_json = r[strMsg][2u] = Json::arrayValue;
		for (DataMap::const_iterator it = Datas.begin(); it != Datas.end(); ++it)
		{
			Discount::ptrData ptr = it->second;
			Json::Value json;
			json.append(ptr->Type);
			json.append(ptr->Value);
			data_json.append(json);
		}
		Return(r, res_sucess);
	}

	void DiscountManager::gm_discout_set(net::Msg& m, Json::Value& r)
	{
		bool set_ok = false;
		ReadJsonArray;
		Json::Value& time_json = js_msg[0u];
		BeginTime = Common::toLocalTime(time_json[0u].asUInt());
		EndTime = Common::toLocalTime(time_json[1u].asUInt());
		saveTime();
		Json::Value& data_json = js_msg[1u];
		for (unsigned i = 0; i < data_json.size(); ++i)
		{
			Json::Value& json = data_json[i];
			const int type = json[0u].asInt();
			if (type < 0 || type >= Discount::project_num)continue;
			const int val = json[1u].asInt();
			const Json::Value& other_data = js_msg[2u];

			Discount::ptrData ptr = Creator<Discount::Data>::Create(type);
			ptr->Value = val;
			Datas[ptr->Type] = ptr;
			ptr->save();
			DiscountDealMap::iterator it = staticDealMap.find(ptr->Type);
			if (it != staticDealMap.end())
			{
				it->second();
			}
			set_ok = true;
		}
		if (set_ok)
		{
			sendDataToAll();
		}
		Return(r, res_sucess);
	}

	void DiscountManager::discout_update(net::Msg& m, Json::Value& r)
	{
		const int playerID = m.playerID;
		playerDataPtr player = player_mgr.getPlayer(playerID);
		if (!player) Return(r, err_illedge);
		sendData(player);
	}

	qValue DiscountManager::packageData()
	{
		qValue time_json(qJson::qj_array);
		time_json.append(BeginTime).append(EndTime);
		qValue data_json(qJson::qj_array);
		for (DataMap::const_iterator it = Datas.begin(); it != Datas.end(); ++it)
		{
			Discount::ptrData ptr = it->second;
			qValue json(qJson::qj_array);
			json.append(ptr->Type);
			json.append(ptr->Value);
			data_json.append(json);
		}
		return qValue(qJson::qj_array).append(res_sucess).append(time_json).append(data_json);
	}

	void DiscountManager::sendData(playerDataPtr player)
	{
		qValue data = packageData();
		if (data.isEmpty())return;
		player->sendToClientFillMsg(gate_client::player_discout_update_resp, data);
	}

	void DiscountManager::sendDataToAll()
	{
		qValue data = packageData();
		if (data.isEmpty())return;
		qValue json(qJson::qj_object);
		json.addMember(strMsg, data);
		player_mgr.sendToAll(gate_client::player_discout_update_resp, json);
	}

	bool DiscountManager::isRun()const
	{
		const unsigned now = Common::gameTime();
		return (now >= BeginTime && now <= EndTime);
	}

	void DiscountManager::saveTime()
	{
		mongo::BSONObj key = BSON("t" << int(Discount::project_time));
		mongo::BSONObj val = BSON("t" << int(Discount::project_time) << "op" << BeginTime << "ed" << EndTime);
		db_mgr.SaveMongo(DBN::dbDiscoutAndGain, key, val);
	}

}
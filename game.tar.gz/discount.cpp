#include "discount.h"
#include "team_war.h"

namespace gg
{

	DiscountManager* const DiscountManager::_Instance = new DiscountManager();

	//��������
	static void DoTeamWarBox(const int type)
	{
		team_war.tickDiscoutBox(type);
	}

	typedef boost::function<void()> dealFunc;
	UNORDERMAP(int, dealFunc, DiscountDealMap);
	static DiscountDealMap staticDealMap;

	void DiscountManager::initData()
	{
		staticDealMap[Discount::team_war_drop_out_red_num] = boostBind(DoTeamWarBox, int(Discount::team_war_drop_out_red_num));
		staticDealMap[Discount::team_war_drop_out_purple_num] = boostBind(DoTeamWarBox, int(Discount::team_war_drop_out_purple_num));

		cout << "loading discount and gain ..." << endl;
		{
			mongo::BSONObj obj = db_mgr.FindOne(DBN::dbDiscoutAndGain, BSON("t" << int(Discount::project_time)));
			if (!obj.isEmpty())
			{
				db_mgr.RemoveCollection(DBN::dbDiscoutAndGain);
			}
		};

		Datas.clear();
		objCollection objs = db_mgr.Query(DBN::dbDiscoutAndGain);
		for (unsigned i = 0; i < objs.size(); ++i)
		{
			mongo::BSONObj& obj = objs[i];
			Discount::ptrData ptr = Creator<Discount::Data>::Create(obj["t"].Int());
			if (ptr->Type < 0)continue;
			if(ptr->Type >= Discount::project_num)
			{
				ptr->del();
				continue;
			}
			ptr->Begin = obj["bg"].Int();
			ptr->End = obj["ed"].Int();
			ptr->Value = obj["v"].Int();
			Datas[ptr->Type] = ptr;
		}
	}

	double DiscountManager::getRate(const int type)
	{
		return 1.0 + getRateOnly(type);
	}

	double DiscountManager::getRateOnly(const int type)
	{
		DataMap::const_iterator it = Datas.find(type);
		if (it == Datas.end())return 0.0;
		Discount::ptrData ptr = it->second;
		if (ptr->isRun())return ptr->getRate();
		return 0.0;
	}

	int DiscountManager::getValue(const int type)
	{
		DataMap::const_iterator it = Datas.find(type);
		if (it == Datas.end())return 0;
		Discount::ptrData ptr = it->second;
		if(ptr->isRun())return ptr->getValue();
		return 0;
	}

	void DiscountManager::gm_discout_update(net::Msg& m, Json::Value& r)
	{
		Json::Value& data_json = r[strMsg][1u] = Json::arrayValue;
		for (DataMap::const_iterator it = Datas.begin(); it != Datas.end(); ++it)
		{
			Discount::ptrData ptr = it->second;
			if (ptr->isRun())
			{
				Json::Value json;
				json.append(ptr->Type);
				json.append(ptr->Value);
				json.append(Common::toStampTime(ptr->Begin));
				json.append(Common::toStampTime(ptr->End));
				data_json.append(json);
			}
		}
		Return(r, res_sucess);
	}

	void DiscountManager::gm_discout_set(net::Msg& m, Json::Value& r)
	{
		ReadJsonArray;
		for (unsigned i = 0; i < js_msg.size(); ++i)
		{
			Json::Value& json = js_msg[i];
			const int type = json[0u].asInt();
			if (type < 0 || type >= Discount::project_num)continue;
			const int val = json[1u].asInt();
			const unsigned begin = json[2u].asUInt();
			const unsigned end = json[3u].asUInt();

			Discount::ptrData ptr = Creator<Discount::Data>::Create(type);
			ptr->Value = val;
			ptr->Begin = 0 == begin ? 0 : Common::toLocalTime(begin);
			ptr->End = 0 == end ? 0 : Common::toLocalTime(end);
			Datas[ptr->Type] = ptr;
			ptr->save();
			DiscountDealMap::iterator it = staticDealMap.find(ptr->Type);
			if (it != staticDealMap.end())
			{
				it->second();
			}
		}
		sendDataToAll();
		Return(r, res_sucess);
	}

	void DiscountManager::discout_update(net::Msg& m, Json::Value& r)
	{
		const int playerID = m.playerID;
		playerDataPtr player = player_mgr.getPlayer(playerID);
		if (!player) Return(r, err_illedge);
		sendData(player);
	}

	qValue DiscountManager::packageData()
	{
		qValue data_json(qJson::qj_array);
		for (DataMap::const_iterator it = Datas.begin(); it != Datas.end(); ++it)
		{
			Discount::ptrData ptr = it->second;
			qValue json(qJson::qj_array);
			json.append(ptr->Type);
			json.append(ptr->Value);
			json.append(ptr->Begin);
			json.append(ptr->End);
			data_json.append(json);
		}
		return qValue(qJson::qj_array).append(res_sucess).append(data_json);
	}

	void DiscountManager::sendData(playerDataPtr player)
	{
		qValue data = packageData();
		if (data.isEmpty())return;
		player->sendToClientFillMsg(gate_client::player_discout_update_resp, data);
	}

	void DiscountManager::sendDataToAll()
	{
		qValue data = packageData();
		if (data.isEmpty())return;
		qValue json(qJson::qj_object);
		json.addMember(strMsg, data);
		player_mgr.sendToAll(gate_client::player_discout_update_resp, json);
	}
}
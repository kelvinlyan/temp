//###################################
//create by Jim
//2016-02-25
//###################################

#pragma once

#include "playerManager.h"
#include "battle_system.h"
#include "man_system.h"

namespace gg
{
	namespace BattleHelp
	{
		static int AddManExp(playerDataPtr player, const int per_man, Json::Value& json)
		{
			json = Json::arrayValue;
			unsigned total_me = 0;
			std::vector<playerManPtr> battleMan = player->WarFM().currentFM();
			for (unsigned i = 0; i < battleMan.size(); ++i)
			{
				playerManPtr man = battleMan[i];
				if (!man)continue;
				Json::Value sgme;
				sgme.append(man->mID());
				sgme.append(man->LV());
				sgme.append(man->EXP());
				const int real_add = man->numAddExp(per_man);
				total_me += (per_man - real_add);
				sgme.append(man->LV());
				sgme.append(man->EXP());
				sgme.append(per_man);
				sgme.append(man->isMaxLevel());
				json.append(sgme);
			}
			return total_me;//��ʣ��
		}

		static sBattlePtr WarPlayer(playerDataPtr player)
		{
			sBattlePtr sb = Creator<sideBattle>::Create();
			sb->playerID = player->ID();
			sb->playerName = player->Name();
			sb->isPlayer = true;
			sb->playerLevel = player->LV();
			sb->playerNation = player->Info().Nation();
			sb->playerFace = player->Info().Face();
			sb->battleValue = player->WarFM().currentBV();
			manList& ml = sb->battleMan;
			ml.clear();
			vector<playerManPtr> ownMan = player->WarFM().currentFM();
			for (unsigned i = 0; i < ownMan.size(); i++)
			{
				playerManPtr man = ownMan[i];
				if (!man)continue;
				mBattlePtr mbattle = Creator<manBattle>::Create();
				cfgManPtr config = man_sys.getConfig(man->mID());
				if (!config)continue;
				mbattle->manID = man->mID();
				mbattle->battleValue = man->battleValue();
				mbattle->holdMorale = config->holdMorale;
				mbattle->set_skill_1(config->skill_1);
				mbattle->set_skill_2(config->skill_2);
				mbattle->armsType = config->armsType;
				mbattle->manLevel = man->LV();
				mbattle->currentIdx = i % 9;
				memcpy(mbattle->armsModule, config->armsModules, sizeof(mbattle->armsModule));
				man->toInitialAttri(mbattle->initialAttri);
				man->toBattleAttri(player->WarFM().currentID(), mbattle->battleAttri);
				mbattle->currentHP = mbattle->getTotalAttri(idx_hp);
				std::vector<itemPtr> equipList = man->getEquipList();
				for (unsigned pos = 0; pos < equipList.size(); ++pos)
				{
					itemPtr item = equipList[pos];
					if (item)
					{
						mbattle->equipList.push_back(BattleEquip(pos, item->itemID(), item->getLv()));
					}
				}
				if (0 == i)
				{
					sb->leaderMan = mbattle;
				}
				ml.push_back(mbattle);
			}
			return sb;
		}
	}
}
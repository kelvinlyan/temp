//###################################
//create by Jim
//2015-11-04
//###################################

#pragma once

#include "playerData.h"
#include <boost/unordered_map.hpp>
#include <vector>
#include "net_base.h"
#include "gate_game_protocol.h"
#include <boost/unordered_set.hpp>
#include <iostream>
#include "dbDriver.h"
#include "res_code.h"
#include "service_config.h"
#include "timmer.hpp"
#include "action_system.h"

#define player_mgr (*gg::playerManager::playerMgr)

namespace gg
{
	class playerManager
	{
		friend void playerBase::onNameMotify(const string);
	public:
		//��ʱ����׼ʱ��
		unsigned stander5();
		unsigned stander8();
		unsigned stander18();
		unsigned stander22();
	private:
		//���㶨ʱ��
		void time5ClockTick(const structTimer& timerData);
		void time8ClockTick(const structTimer& timerData);
		void time18ClockTick(const structTimer& timerData);
		void time22ClockTick(const structTimer& timerData);
		void timePerHourTick(const structTimer& timerData);
		
		void playerManagerUpdate(const structTimer& timerData);
		void playerOnlineLog(const structTimer& timerData);
		void playerOfflineBackUp(const structTimer& timerData);
	public:
		static playerManager* const playerMgr;
		typedef boost::unordered_map<int, playerDataPtr> BHIDMAP;
		typedef boost::unordered_map<string, playerDataPtr> BHNMAP;
		typedef vector<playerDataPtr> playerDataVec;
		playerManager();
		~playerManager();
		void initData();
		void gateResetReq();

		void gameOver();//��Ϸ���̼�������
	public:
		playerDataPtr getAccount(const int playerID);
		playerDataPtr getPlayer(const int playerID);
		playerDataPtr getPlayer(const string playerName);
		playerDataPtr getOnlinePlayer(const int playerID);
		playerDataPtr getOnlinePlayer(const string playerName);
		playerDataPtr getCachePlayer(const int playerID);
		playerDataPtr getCachePlayer(const string playerName);
		int createNewPlayer(playerDataPtr player, const string playerName);
		playerDataPtr createNewAccount(
			const int playerID, //���ID
			const string uidKey,//�˺�ID
			const string cidKey,//������
			const string gidKey//��ϷID
		);
		bool IsOnline(const int playerID);
		bool hasRegisterName(const string name);

		void playerLogin(const int playerID);
		void playerLogin(playerDataPtr player);
		void playerLogout(const int playerID);
		void playerLogout(playerDataPtr player);
		void sendToPlayer(net::Msg& mj);
		//json value
		void sendToPlayer(const int playerID, const short pcl, Json::Value& m);
		void sendToAll(const short pcl, Json::Value& m);
		void sendToKingdom(const Kingdom::NATION kingdom, const short pcl, Json::Value& m);
		//qvalue
		void sendToPlayer(const int playerID, const short pcl, qValue& m);
		void sendToAll(const short pcl, qValue& m);
		void sendToKingdom(const Kingdom::NATION kingdom, const short pcl, qValue& m);
		//void sendToArea(const short pcl, Json::Value& m);

		playerDataVec allOnline();
		playerDataVec nationAllOnline();
		playerDataVec nationOnline(const Kingdom::NATION nation);
	protected:	
		void rebindPlayer(const string oldName, playerDataPtr player);
		playerDataPtr loadFromDB(const int playerID);
		playerDataPtr loadFromDB(const string playerName);
		bool insertData(playerDataPtr player);
		playerDataPtr findPlayer(const int playerID);
		playerDataPtr findPlayer(const string name);

		//unsigned onlineNum;
		BHIDMAP accountIDMap;
		BHIDMAP onlineIDMap, playerMap;//����������� ȫ������
		BHNMAP onlineNAMap, nameMap;//����������� ȫ������
	};
}

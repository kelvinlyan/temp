//###################################
//create by Jim
//2016-06-15
//###################################

#pragma once

#include "auto_do.h"

namespace gg
{
	namespace DAILYCARD
	{
		enum
		{
			card_begin = 0,
			month_card = card_begin,//�¿�31��
			live_card = 1,//���ÿ�
			card_num,
			card_end = card_num - 1,
		};

		static bool isVaildCard(const int cid)
		{
			return (cid >= DAILYCARD::card_begin && cid < DAILYCARD::card_num);
		}

		struct Data
		{
			Data(const int cid = month_card, const unsigned dl = 30) : cardID(cid), 
				dayLeave(dl == 0 ? 0xFFFFFFFF : (Common::getNextTime(5) + (dl - 1) * DAY))
			{
				wardTime = 0;
			}
			bool isOver()
			{
				return (Common::gameTime() >= dayLeave);
			}
			const int cardID;//������
			const unsigned dayLeave;//ʣ���¼�
			unsigned wardTime;//���콱ʱ��
		};
		BOOSTSHAREPTR(Data, ptrData);
	}

	class playerDailyCard :
		public _auto_player
	{
	public:
		playerDailyCard(playerData* const own);
		~playerDailyCard(){}

		int addCard(const int cardID);
		int wardCard(const int cardID);
		int wardCard(const int cardID, int& rwnum);

		//check
		void clearDead();

		//other
		virtual void _auto_update();
	private:
		virtual void classLoad();
		virtual void classFinal();
		DAILYCARD::ptrData getCard(const int cardID);
		virtual bool _auto_save();
		STDMAP(int, DAILYCARD::ptrData, CardMap);
		CardMap ownCards;
	};
}
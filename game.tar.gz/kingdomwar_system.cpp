#include "map_war.h"
#include "kingdomwar_system.h"
#include "playerManager.h"
#include "man_system.h"
#include "heroparty_system.h"
#include "net_helper.hpp"
#include "chat.h"
#include "game_time.h"
#include "kingfight_system.h"
#include "kingdomwar_task.h"
#include "kingdom_system.h"

namespace gg
{
	namespace KingdomWar
	{
		bool checkArmyID(playerDataPtr d, int army_id)
		{
			if (army_id < 0 || army_id >= ArmyNum)
				return false;
			if (army_id == 1 && d->LV() < 28)
				return false;
			if (army_id == 2 && d->LV() < 52)
				return false;
			return true;
		}

		bool checkLimit(playerDataPtr d)
		{
			return d->Info().Nation() != Kingdom::null 
				&& d->LV() >= 15;
		}
	}

#define CheckArmyID()\
	if (!KingdomWar::checkArmyID(d, army_id))\
		Return(r, err_illedge)

#define CheckState()\
	if (KingdomWar::State::shared().get() == KingdomWar::Closed)\
		Return(r, err_illedge)

#define LoadPlayer\
	playerDataPtr d = player_mgr.getPlayer(m.playerID);\
	if (!d || !KingdomWar::checkLimit(d))\
		Return(r, err_illedge)

#define DOLOAD(TYPE)\
	void kingdomwar_system::doLoad##TYPE(const mongo::BSONObj& obj)\
	{\
		using namespace KingdomWar;\
		TYPE##DataPtr d = Creator<TYPE##Data>::Create(obj);\
		const Position& pos = d->position();\
		if (pos.type == PosPath)\
		{\
			PathPtr ptr = getPath(pos.id);\
			if (!ptr) return;\
			int to_city_id = ptr->getLinkedId(pos.from_id);\
			addTimer(pos.time, boostBind(kingdomwar_system::loadPath##TYPE, this, ptr, pos.time, d, to_city_id));\
		}\
		else\
		{\
			CityPtr ptr = CityMgr::shared().getCity(pos.id);\
			if (!ptr) return;\
			ptr->tryLoad##TYPE(d);\
		}\
	}

	using namespace KingdomWar;

	kingdomwar_system* const kingdomwar_system::_Instance = new kingdomwar_system();

	kingdomwar_system::kingdomwar_system()
	{
	}

	void kingdomwar_system::initMap()
	{
		CityMgr::shared().loadDB();
		loadPlayer();
		loadNpc();
		CityMgr::shared().init();
		_path_list.update(true);
	}

	void kingdomwar_system::loadRank()
	{
		RankMgr::shared();
		objCollection objs = db_mgr.Query(DBN::dbPlayerKingdomWar);
		ForEachC(objCollection, it, objs)
		{
			int pid = (*it)[strPlayerID].Int();
			int exploit = (*it)["ep"].Int();
			if (exploit > 0)
			{
				playerDataPtr d = player_mgr.getPlayer(pid);
				if (!d) continue;
				RankMgr::shared().insert(d, exploit);
			}
		}
	}

	void kingdomwar_system::initData()
	{
		LogI << "kingdom war init start.." << LogEnd;
		loadFile();
		addTimer();
		addUpdater(boostBind(kingdomwar_system::tick, this));
		initMap();
		loadRank();
		startTimer();
		KingdomBuff::shared();
		SignList::shared();
		GreatEventMgr::shared();
		NationTaskMgr::shared();
		Timer::start();
		setPrimeTimeBroadcast();
		LogI << "kingdom war init end.." << LogEnd;
	}

	void kingdomwar_system::timerTick()
	{
		update();
		startTimer();
	}

	void kingdomwar_system::tick()
	{
		TowerMgr::shared().tick();
		BattleNumMgr::shared().tick();
		
		_path_list.update();
		if (!Observer::empty())
		{
			qValue up_state;
			qValue up_nation;
			qValue up_box;
			CityMgr::shared().getUpInfo(up_state, up_nation, up_box);
			qValue path;
			_path_list.getUpdateInfo(path);
			if (up_state.isEmpty() 
				&& up_nation.isEmpty() 
				&& path.isEmpty())
				return;
			qValue q(qJson::qj_object);
			q.addMember("s", up_state);
			q.addMember("c", up_nation);
			q.addMember("p", path);
			qValue m(qJson::qj_object);
			qValue mm;
			mm.append(res_sucess);
			mm.append(q);
			m.addMember(strMsg, mm);
			detail::batchOnline(getObserver(), m, gate_client::kingdom_war_main_update_resp);
		}
		else
		{
			CityMgr::shared().resetUpInfo();
		}
	}
	
	static bool compareFunc1(const Json::Value& a, const Json::Value& b)
	{
		return a["id"].asInt() < b["id"].asInt();
	}

	void kingdomwar_system::loadFile()
	{
		FileJsonSeq vec;	
		vec = Common::loadFileJsonFromDir("./instance/kingdom_war/city");
		std::sort(vec.begin(), vec.end(), compareFunc1);
		ForEachC(FileJsonSeq, it, vec)
			CityMgr::shared().push(Creator<KingdomWar::City>::Create(*it));

		_graph = Creator<KingdomWar::Graph>::Create((unsigned)vec.size());
		_nearby_ids.assign(vec.size(), NearbyID());
		ForEachC(FileJsonSeq, it, vec)
		{
			const Json::Value& json = *it;
			int city_id = json["id"].asInt();
			const Json::Value& link_citys = json["relationship"];
			const Json::Value& path_types = json["relationship_type"];
			const Json::Value& cost_times = json["distance"];
			for (unsigned i = 0; i < link_citys.size(); ++i)
			{
				int link_city = link_citys[i].asInt();
				int left_city = city_id > link_city ? link_city : city_id;
				int right_city = city_id > link_city ? city_id : link_city;
				int path_id = left_city * 100 + right_city;
				KingdomWar::PathPtr ptr = getPath(path_id);
				if (!ptr)
				{
					ptr = Creator<KingdomWar::Path>::Create(path_id, city_id, link_city);
					_path_list.push(ptr);
					CityMgr::shared().getCity(left_city)->addPath(ptr);
					CityMgr::shared().getCity(right_city)->addPath(ptr);
				}
				ptr->setPathType(city_id, link_city, path_types[i].asInt(), cost_times[i].asInt());
				if (ptr->access(city_id, link_city))
				{
					_graph->set(city_id, link_city, cost_times[i].asInt());
					_nearby_ids[city_id].push_back(link_city);
				}
			}

		}
		/*vector<KingdomWar::Lines> lines_list;
		for (unsigned i = 0; i < vec.size(); ++i)
		{
			KingdomWar::Lines lines;
			shortestPath_DIJ(graph, lines, i);
			lines_list.push_back(lines);
		}*/
		//_shortest_path.load(lines_list);

		vec = Common::loadFileJsonFromDir("./instance/kingdom_war/npc");
		ForEach(FileJsonSeq, it, vec)
		{
			Json::Value& chapterMap = *it;

			KingdomWar::NpcDataCfgPtr mapDatePtr = Creator<KingdomWar::NpcDataConfig>::Create();

			mapDatePtr->mapID = chapterMap["mapId"].asInt();
			//mapDatePtr->frontId = chapterMap["frontId"].asInt();
			mapDatePtr->background = chapterMap.isMember("background") ? chapterMap["background"].asInt() : 1;
			mapDatePtr->faceID = chapterMap["faceID"].asInt();
			mapDatePtr->mapName = chapterMap["mapName"].asString();
			mapDatePtr->mapName2 = chapterMap["mapName2"].asString();
			mapDatePtr->mapLevel = chapterMap["mapLevel"].asInt();
			mapDatePtr->battleValue = chapterMap["battleValue"].asInt();
			mapDatePtr->needFood = chapterMap["needfood"].asInt();
			mapDatePtr->needAction = chapterMap["needAction"].asInt();
			mapDatePtr->chanllengeTimes = chapterMap["challengeTimes"].asInt();
			mapDatePtr->manExp = chapterMap["manExp"].asUInt();
			mapDatePtr->levelLimit = chapterMap["levelLimit"].asUInt();
			mapDatePtr->robotIDX = chapterMap["robotIDX"].asInt();
			const unsigned rwJsonID = chapterMap["winBox"].asUInt();
			mapDatePtr->winBox = actionFormat(rwJsonID);
			for (unsigned nn = 0; nn < chapterMap["army"].size(); ++nn)
			{
				Json::Value& npcJson = chapterMap["army"][nn];
				armyNPC npc;
				npc.npcID = npcJson["npcID"].asInt();
				npc.holdMorale = npcJson["holdMorale"].asBool();
				for (unsigned cn = 0; cn < characterNum; ++cn)
				{
					npc.initAttri[cn] = npcJson["initAttri"][cn].asInt();
				}
				npc.armsType = npcJson["armsType"].asInt();
				for (unsigned cn = 0; cn < armsModulesNum; ++cn)
				{
					npc.armsModule[cn] = npcJson["armsModule"][cn].asDouble();
				}
				npc.npcLevel = npcJson["npcLevel"].asInt();
				npc.npcPos = npcJson["npcPos"].asUInt() % 9;
				npc.battleValue = npcJson["battleValue"].asInt();
				npc.skill_1 = npcJson["skill_1"].asInt();
				npc.skill_2 = npcJson["skill_2"].asInt();
				for (unsigned eq_idx = 0; eq_idx < npcJson["equip"].size(); ++eq_idx)
				{
					npc.equipList.push_back(BattleEquip(npcJson["equip"][eq_idx][0u].asUInt(),
								npcJson["equip"][eq_idx][1u].asInt(),
								npcJson["equip"][eq_idx][2u].asUInt()));
				}
				mapDatePtr->npcList.push_back(npc);
			}
			sBattlePtr bptr = map_sys.npcSide(mapDatePtr);
			manList& ml = bptr->battleMan;
			for (unsigned i = 0; i < ml.size(); ++i)
				mapDatePtr->npcList[i].maxHp = ml[i]->currentHP;
			_npc_map[mapDatePtr->mapID] = mapDatePtr;
		}

		Json::Value json;

		json = Common::loadJsonFile("./instance/kingdom_war/rank_reward.json");
		ForEach(Json::Value, it, json)
			_rank_reward.push_back(*it);

		json = Common::loadJsonFile("./instance/kingdom_war/hp_cost.json");
		{
			Json::Value& ping = json["ping"];
			_win_hp_cost.push_back(ping[0u].asInt());
			_lose_hp_cost.push_back(ping[0u].asInt());
			_win_hp_cost_2.push_back(ping[0u].asInt());
			_lose_hp_cost_2.push_back(ping[0u].asInt());
			Json::Value& win = json["win"];
			ForEach(Json::Value, it, win)
				_win_hp_cost.push_back((*it).asInt());
			Json::Value& lose = json["lose"];
			ForEach(Json::Value, it, lose)
				_lose_hp_cost.push_back((*it).asInt());
			_elec_attack_hp = json["tower_kill"][0u].asInt();
			Json::Value& win_2 = json["win_2"];
			ForEach(Json::Value, it, win_2)
				_win_hp_cost_2.push_back((*it).asInt());
			Json::Value& lose_2 = json["lose_2"];
			ForEach(Json::Value, it, lose_2)
				_lose_hp_cost_2.push_back((*it).asInt());
		}
		json = Common::loadJsonFile("./instance/kingdom_war/exploit.json");
		{
			Json::Value& ping = json["ping"];
			_win_exploit.push_back(ping[0u].asInt());
			_lose_exploit.push_back(ping[0u].asInt());
			Json::Value& win = json["win"];
			ForEach(Json::Value, it, win)
				_win_exploit.push_back((*it).asInt());
			Json::Value& lose = json["lose"];
			ForEach(Json::Value, it, lose)
				_lose_exploit.push_back((*it).asInt());
			_elec_attack_exploit = json["tower_kill"][0u].asInt();
		}
		json = Common::loadJsonFile("./instance/kingdom_war/hp_debuff.json");
		ForEach(Json::Value, it, json)
		{
			int start = (*it)["start"].asInt();
			int end = (*it)["end"].asInt();
			int atk_debuff = (*it)["atk_debuff"].asInt();
			int def_debuff = (*it)["def_debuff"].asInt();
			for (unsigned i = start; i <= end; ++i)
			{
				if (i >= _hp_debuff.size())
					_hp_debuff.insert(_hp_debuff.end(), end + 1 - _hp_debuff.size(), KingdomWar::HpDebuff(0, 0));
				_hp_debuff[i]._atk_debuff = atk_debuff;
				_hp_debuff[i]._def_debuff = def_debuff;
			}
		}
		json = Common::loadJsonFile("./instance/kingdom_war/hp_exploit.json");
		ForEach(Json::Value, it, json)
			_hp_exploit.push_back((*it).asInt());

		json = Common::loadJsonFile("./instance/kingdom_war/silver.json");
		ForEach(Json::Value, it, json)
			_battle_silver.push_back((*it).asInt());
	}

	void kingdomwar_system::loadPlayer()
	{
		objCollection objs = db_mgr.Query(DBN::dbPlayerKingdomWarPos);
		ForEachC(objCollection, it, objs)
		{
			int type = (*it)["t"].Int();
			int id = (*it)["i"].Int();
			if (type == KingdomWar::PosCity && KingdomWar::isMainID(id))
				continue;
			int pid = (*it)[strPlayerID].Int();
			int army_id = (*it)["a"].Int();
			playerDataPtr d = player_mgr.getPlayer(pid);
			if (!d) continue;
			const KingdomWar::Position& pos = d->KingDomWarPos().position(army_id);
			if (pos.type == KingdomWar::PosPath)
			{
				KingdomWar::PathPtr ptr = getPath(pos.id);
				if (!ptr) continue;
				int to_city_id = ptr->id() / 100;
				if (to_city_id == pos.from_id)
					to_city_id = ptr->id() % 100;
				addTimer(pos.time, boostBind(kingdomwar_system::loadPathPlayer, this, ptr, pos.time, pid, army_id, to_city_id));
			}
			else
			{
				KingdomWar::CityPtr ptr = CityMgr::shared().getCity(pos.id);
				if (!ptr) continue;
				ptr->tryLoadPlayer(d, army_id);
			}
		}
	}

	void kingdomwar_system::loadNpc()
	{
		objCollection objs = db_mgr.Query(DBN::dbKingdomWarNpc);
		ForEachC(objCollection, it, objs)
		{
			const mongo::BSONObj& obj = *it;
			int id = obj[KingdomWar::strNpcID].Int();
			if (id == 0)
				continue;
			int type = obj["t"].Int();
			switch(type)
			{
				case KingdomWar::Npc:
				case KingdomWar::ActiveNpc:
					doLoadNpc(obj);
					break;
				case KingdomWar::Shadow:
					doLoadShadow(obj);
					break;
				case KingdomWar::ShadowNpc:
					doLoadShadowNpc(obj);
					break;
				default:
					LogE << "kingdom war npc type error:" << type << LogEnd;
					break;
			}
		}
	}

	sBattlePtr kingdomwar_system::getBattlePtr(playerDataPtr player, int army_id, int& max_hp, int& cur_hp)
	{
		sBattlePtr sb = Creator<sideBattle>::Create();
		sb->playerID = player->ID();
		sb->playerName = player->Name();
		sb->isPlayer = true;
		sb->playerLevel = player->LV();
		sb->playerNation = player->Info().Nation();
		sb->playerFace = player->Info().Face();
		sb->battleValue = player->KingDomWarFM().getBV(army_id);
		manList& ml = sb->battleMan;
		ml.clear();
		vector<playerManPtr> ownMan = player->KingDomWarFM().getFM(army_id);
		max_hp = 0;
		cur_hp = 0;
		for (unsigned i = 0; i < ownMan.size(); i++)
		{
			playerManPtr man = ownMan[i];
			if (!man)continue;
			mBattlePtr mbattle = Creator<manBattle>::Create();
			cfgManPtr config = man_sys.getConfig(man->mID());
			if (!config)continue;
			mbattle->manID = man->mID();
			mbattle->battleValue = man->battleValue();
			mbattle->holdMorale = config->holdMorale;
			mbattle->set_skill_1(config->skill_1);
			mbattle->set_skill_2(config->skill_2);
			mbattle->armsType = config->armsType;
			mbattle->manLevel = man->LV();
			mbattle->currentIdx = i % 9;
			memcpy(mbattle->armsModule, config->armsModules, sizeof(mbattle->armsModule));
			man->toInitialAttri(mbattle->initialAttri);
			man->toBattleAttri(player->KingDomWarFM().getFMId(army_id), mbattle->battleAttri);
			mbattle->currentHP = mbattle->getTotalAttri(idx_hp);
			max_hp += mbattle->currentHP;
			int man_hp = player->KingDomWar().manHp(man->mID());
			if (mbattle->currentHP >= man_hp)
				mbattle->currentHP = man_hp;
			else
				player->KingDomWar().setManHp(man->mID(), mbattle->currentHP);
			cur_hp += mbattle->currentHP;
			std::vector<itemPtr> equipList = man->getEquipList();
			for (unsigned pos = 0; pos < equipList.size(); ++pos)
			{
				itemPtr item = equipList[pos];
				if (item)
				{
					mbattle->equipList.push_back(BattleEquip(pos, item->itemID(), item->getLv()));
				}
			}
			if (0 == i)
			{
				sb->leaderMan = mbattle;
			}
			ml.push_back(mbattle);
		}

		/*ForEach(manList, it, sb->battleMan)
		{
			LogI << "1: " << (*it)->battleAttri[idx_phyHurtRate] << LogEnd;
			LogI << "2: " << (*it)->battleAttri[idx_phyCutRate] << LogEnd;
			LogI << "3: " << (*it)->battleAttri[idx_warHurtRate] << LogEnd;
			LogI << "4: " << (*it)->battleAttri[idx_warCutRate] << LogEnd;
			LogI << "5: " << (*it)->battleAttri[idx_magicHurtRate] << LogEnd;
			LogI << "6: " << (*it)->battleAttri[idx_magicCutRate] << LogEnd;
			LogI << "7: " << (*it)->battleAttri[idx_cureRate] << LogEnd;
		}*/

		int buff = KingdomBuff::shared().getBuff(player->Info().Nation());
		//LogI << "kingdom buff: " << buff << LogEnd;
		const KingdomWar::Position& pos = player->KingDomWarPos().position(army_id);
		if (pos.type != KingdomWar::PosPath)
		{
			KingdomWar::CityPtr ptr = CityMgr::shared().getCity(pos.id);
			ptr->addBuff(player, sb);
		}

		ForEach(manList, it, sb->battleMan)
		{
			(*it)->battleAttri[idx_phyHurtRate] += buff;
			(*it)->battleAttri[idx_phyCutRate] += buff;
			(*it)->battleAttri[idx_warHurtRate] += buff;
			(*it)->battleAttri[idx_warCutRate] += buff;
			(*it)->battleAttri[idx_magicHurtRate] += buff;
			(*it)->battleAttri[idx_magicCutRate] += buff;
			(*it)->battleAttri[idx_cureRate] += buff;
		}

		int hp = player->KingDomWar().armyHp(army_id);
		addHpDebuff(sb, hp);

		/*ForEach(manList, it, sb->battleMan)
		{
			LogI << "1: " << (*it)->battleAttri[idx_phyHurtRate] << LogEnd;
			LogI << "2: " << (*it)->battleAttri[idx_phyCutRate] << LogEnd;
			LogI << "3: " << (*it)->battleAttri[idx_warHurtRate] << LogEnd;
			LogI << "4: " << (*it)->battleAttri[idx_warCutRate] << LogEnd;
			LogI << "5: " << (*it)->battleAttri[idx_magicHurtRate] << LogEnd;
			LogI << "6: " << (*it)->battleAttri[idx_magicCutRate] << LogEnd;
			LogI << "7: " << (*it)->battleAttri[idx_cureRate] << LogEnd;
		}*/

		return sb;
	}

	KingdomWar::PathPtr kingdomwar_system::getPath(int id)
	{
		return _path_list.getPath(id);
	}

	KingdomWar::CityPtr kingdomwar_system::getMainCity(int nation)
	{
		if (nation < 0 || nation >= Kingdom::nation_num)
			return KingdomWar::CityPtr();

		return CityMgr::shared().getCity(KingdomWar::MainCity[nation]);
	}

	void kingdomwar_system::quitReq(net::Msg& m, Json::Value& r)
	{
		LoadPlayer;
		ReadJsonArray;
		int id = js_msg[0u].asInt();
		d->KingDomWar().detach(id);
		Return(r, res_sucess);
	}

	void kingdomwar_system::attach(int id)
	{
		if (Observer::empty())
			CityMgr::shared().resetUpInfo();
		Observer::attach(id);
	}

	void kingdomwar_system::mainInfoReq(net::Msg& m, Json::Value& r)
	{
		LoadPlayer;
		d->KingDomWar().attach(-1);
		mainInfo(d);
	}

	void kingdomwar_system::moveReq(net::Msg& m, Json::Value& r)
	{
		CheckState();

		LoadPlayer;
		ReadJsonArray;
		int army_id = js_msg[0u].asInt();
		int to_city_id = js_msg[1u].asInt();
		int cp = js_msg[2u].asInt();

		CheckArmyID();

		int res = d->KingDomWarPos().move(Common::gameTime(), army_id, to_city_id, true);
		if (res == res_sucess && js_msg.size() > 2)
		{
			r[strMsg][1u] = army_id;
			r[strMsg][2u] = to_city_id;
			r[strMsg][3u] = cp;
		}
		Return(r, res);
	}

	void kingdomwar_system::playerInfoReq(net::Msg& m, Json::Value& r)
	{
		LoadPlayer;
		d->KingDomWarPos().update();
	}

	void kingdomwar_system::formationReq(net::Msg& m, Json::Value& r)
	{
		LoadPlayer;
		d->KingDomWarFM().update();
	}

	void kingdomwar_system::setFormationReq(net::Msg& m, Json::Value& r)
	{
		LoadPlayer;
		ReadJsonArray;
		int army_id = js_msg[0u].asInt();
		int fm_id = js_msg[1u].asInt();
		int fm[9];
		for (unsigned i = 0; i < 9; ++i)
			fm[i] = js_msg[2u][i].asInt();

		CheckArmyID();

		int res = d->KingDomWarFM().setFormation(army_id, fm_id, fm);
		Return(r, res);
	}

	void kingdomwar_system::cityBattleInfoReq(net::Msg& m, Json::Value& r)
	{
		LoadPlayer;
		ReadJsonArray;
		int city_id = js_msg[0u].asInt();
		KingdomWar::CityPtr ptr = CityMgr::shared().getCity(city_id);
		if (!ptr)
			Return(r, err_illedge);
		d->KingDomWar().attach(city_id);
		qValue rm;
		rm.append(res_sucess);
		qValue q(qJson::qj_object);
		ptr->getMainInfo(q);
		rm.append(q);
		d->sendToClientFillMsg(gate_client::kingdom_war_city_battle_info_resp, rm);
	}

	void kingdomwar_system::retreatReq(net::Msg& m, Json::Value& r)
	{
		CheckState();
	
		LoadPlayer;
		ReadJsonArray;
		int army_id = js_msg[0u].asInt();

		CheckArmyID();

		int res = d->KingDomWarPos().retreat(army_id);
		r[strMsg][1u] = army_id;
		Return(r, res);
	}

	void kingdomwar_system::reportInfoReq(net::Msg& m, Json::Value& r)
	{
		LoadPlayer;
		d->KingDomWar().updateReport();
	}

	void kingdomwar_system::rankInfoReq(net::Msg& m, Json::Value& r)
	{
		LoadPlayer;
		ReadJsonArray;
		int begin = js_msg[0u].asInt();
		int end = js_msg[1u].asInt();
		qValue mq;
		mq.append(res_sucess);
		qValue q(qJson::qj_object);
		RankMgr::shared().getInfo(d, begin, end, q);
		mq.append(q);
		d->sendToClientFillMsg(gate_client::kingdom_war_rank_info_resp, mq);
	}

	void kingdomwar_system::buyHpItemReq(net::Msg& m, Json::Value& r)
	{	
		LoadPlayer;
		ReadJsonArray;
		int num = js_msg[0u].asInt();
		int res = d->KingDomWar().buyHpItem(num);
		Return(r, res);
	}

	void kingdomwar_system::useHpItemReq(net::Msg& m, Json::Value& r)
	{
		CheckState();

		LoadPlayer;
		ReadJsonArray;
		int army_id = js_msg[0u].asInt();
		int res = d->KingDomWar().useHpItem(army_id, 1);
		if (res == res_sucess)
			updateHpInfo(d, army_id);
		Return(r, res);
	}

	void kingdomwar_system::outputInfoReq(net::Msg& m, Json::Value& r)
	{
		LoadPlayer;
		d->KingDomWarOutput().update();
	}

	void kingdomwar_system::getOutputReq(net::Msg& m, Json::Value& r)
	{
		LoadPlayer;
		ReadJsonArray;
		int id = js_msg[0u].asInt();
		int res = d->KingDomWarOutput().getOutput(id, r[strMsg][1u]);
		Return(r, res);
	}

	void kingdomwar_system::signGatherReq(net::Msg& m, Json::Value& r)
	{
		CheckState();

		LoadPlayer;
		ReadJsonArray;
		int type = js_msg[0u].asInt();
		int id = js_msg[1u].asInt();
		std::string str = js_msg[2u].asString();
		int res = SignList::shared().setSign(d, type, id, str);
		if (res == res_sucess)
		{
			updateSign(d->Info().Nation());
			if (type != 0)
			{
				qValue bc;
				bc << 8 << chat_sys.ChatPackageQ(d) << id << str;
				DoBroadcast(d->Info().Nation(), bc);
			}
		}
		r[strMsg][1u] = type;
		Return(r, res);
	}

	void kingdomwar_system::armyInfoReq(net::Msg& m, Json::Value& r)
	{
		LoadPlayer;
		ReadJsonArray;
		int army_id = js_msg[0u].asInt();
		CheckArmyID();
		updateHpInfo(d, army_id);
	}

	void kingdomwar_system::changeFormationReq(net::Msg& m, Json::Value& r)
	{
		LoadPlayer;
		ReadJsonArray;
		int army_id = js_msg[0u].asInt();
		int fm_id = js_msg[1u].asInt();
		int fm[9];
		for (unsigned i = 0; i < 9; ++i)
			fm[i] = js_msg[2u][i].asInt();
		CheckArmyID();
		int res = d->KingDomWarFM().setFormation(army_id, fm_id, fm);
		Return(r, res);
	}

	void kingdomwar_system::militaryInfoReq(net::Msg& m, Json::Value& r)
	{
		LoadPlayer;
		ReadJsonArray;
		int id = js_msg[0u].asInt();
		KingdomWar::CityPtr ptr = CityMgr::shared().getCity(id);
		if (!ptr)
			Return(r, err_illedge);
		qValue mm;
		mm.append(res_sucess);
		qValue q(qJson::qj_object);
		ptr->getMilitaryInfo(q);
		mm.append(q);
		d->sendToClientFillMsg(gate_client::kingdom_war_military_info_resp, mm);
	}

	void kingdomwar_system::playerListReq(net::Msg& m, Json::Value& r)
	{
		LoadPlayer;
		ReadJsonArray;
		int id = js_msg[0u].asInt();
		int side = js_msg[1u].asInt();
		KingdomWar::CityPtr ptr = CityMgr::shared().getCity(id);
		if (!ptr)
			Return(r, err_illedge);

		qValue mm;
		mm.append(res_sucess);
		qValue q(qJson::qj_object);
		ptr->getFighterList(q, side);
		mm.append(q);
		d->sendToClientFillMsg(gate_client::kingdom_war_city_player_list_resp, mm);
	}

	void kingdomwar_system::upManHpCostReq(net::Msg& m, Json::Value& r)
	{
		LoadPlayer;
		ReadJsonArray;
		Json::Value& army_id_list = js_msg[0u];
		int id = js_msg[1u].asInt();
		int cp = js_msg[2u].asInt();
		int cost = 0;
		ForEach(Json::Value, it, army_id_list)
		{
			int army_id = (*it).asInt();
			CheckArmyID();
			cost += d->KingDomWarFM().getUpHpCost(army_id);
		}
		r[strMsg][1u] = army_id_list;
		r[strMsg][2u] = id;
		r[strMsg][3u] = cost;
		r[strMsg][4u] = hpExploit(d->LV(), cost);
		r[strMsg][5u] = cp;
		Return(r, res_sucess);
	}

	void kingdomwar_system::upManHpReq(net::Msg& m, Json::Value& r)
	{
		CheckState();

		LoadPlayer;
		ReadJsonArray;
		Json::Value& army_id_list = js_msg[0u];
		int id = js_msg[1u].asInt();
		int cp = js_msg[2u].asInt();
		std::vector<int> army_id_vec;
		ForEach(Json::Value, it, army_id_list)
		{
			int army_id = (*it).asInt();
			CheckArmyID();
			army_id_vec.push_back(army_id);
		}

		int cost;
		int res = d->KingDomWarFM().upManHpByFood(army_id_vec, cost);
		if (res == res_sucess)
		{
			r[strMsg][1u] = army_id_list;
			r[strMsg][2u] = id;
			r[strMsg][3u] = cost;
			r[strMsg][4u] = hpExploit(d->LV(), cost);
			r[strMsg][5u] = cp;
		}
		Return(r, res);
	}

	void kingdomwar_system::lookUpPlayerReq(net::Msg& m, Json::Value& r)
	{
		LoadPlayer;
		ReadJsonArray;
		int cid = js_msg[0u].asInt();
		int id = js_msg[1u].asInt();
		int army_id = js_msg[2u].asInt();
		KingdomWar::CityPtr ptr = CityMgr::shared().getCity(cid);
		if (!ptr) Return(r, err_illedge);
		qValue q(qJson::qj_object);
		int res = ptr->getTableInfo(q, id, army_id); 
		if (res != res_sucess)
			Return(r, res);
		qValue mm;
		mm.append(res_sucess);
		mm.append(q);
		d->sendToClientFillMsg(gate_client::kingdom_war_look_up_player_resp, mm);
	}

	void kingdomwar_system::personTaskReq(net::Msg& m, Json::Value& r)
	{
		LoadPlayer;
		d->KingDomWarTask().update();
	}

	void kingdomwar_system::personTaskRewardReq(net::Msg& m, Json::Value& r)
	{
		LoadPlayer;
		ReadJsonArray;
		int id = js_msg[0u].asInt();
		int res = d->KingDomWarTask().getPersonTaskReward(id, r[strMsg][1u]);
		Return(r, res);
	}

	void kingdomwar_system::nationTaskReq(net::Msg& m, Json::Value& r)
	{
		LoadPlayer;
		updateNationTask(d);
	}

	void kingdomwar_system::updateNationTask(playerDataPtr d)
	{
		qValue m;
		m.append(res_sucess);
		qValue q;
		NationTaskMgr::shared().getInfo(d, q);
		qValue mm(qJson::qj_object);
		mm.addMember("l", q);
		mm.addMember("t", PrimeState::shared()? PrimeState::shared().nextTickTime() : 0);
		m.append(mm);
		d->sendToClientFillMsg(gate_client::kingdom_war_nation_task_resp, m);
	}

	void kingdomwar_system::nationTaskRewardReq(net::Msg& m, Json::Value& r)
	{
		LoadPlayer;
		ReadJsonArray;
		int id = js_msg[0u].asInt();
		int res = NationTaskMgr::shared().getReward(d, id, r[strMsg][1u]);
		if (res == res_sucess)
			updateNationTask(d);
		Return(r, res);
	}

	void kingdomwar_system::greatEventReq(net::Msg& m, Json::Value& r)
	{
		LoadPlayer;
		ReadJsonArray;
		int idx = js_msg[0u].asInt();
		updateGreatEvent(d, idx);
	}

	void kingdomwar_system::greatEventRewardReq(net::Msg& m, Json::Value& r)
	{
		LoadPlayer;
		ReadJsonArray;
		int idx = js_msg[0u].asInt();
		int res = d->KingDomWarBox().getGreatEventReward(idx, r);
		if (res == res_sucess)
			updateGreatEvent(d, idx);
		Return(r, res);
	}

	void kingdomwar_system::callShadowReq(net::Msg& m, Json::Value& r)
	{
		LoadPlayer;
		ReadJsonArray;
		int id = js_msg[0u].asInt();
		int type = js_msg[1u].asInt();
		int use_res = js_msg[2u].asInt();
		if (type < 0 || type > SHADOW::TYPEMAX)
			Return(r, err_illedge);
		KingdomWar::CityPtr ptr = CityMgr::shared().getCity(id);
		if (!ptr) Return(r, err_illedge);
		for (unsigned i = 0; i < ArmyNum; ++i)
		{
			const Position& pos = d->KingDomWarPos().position(i);
			if (pos.type == PosCity && pos.id == id)
			{
				int res = ptr->callShadow(Common::gameTime(), d, type, use_res);	
				if (res == res_sucess)
				{
					r[strMsg][1u] = type;
					r[strMsg][2u] = use_res;
					r[strMsg][3u] = ReturnParam::shared().shadowIndex();
				}
				Return(r, res);
			}
		}
		Return(r, err_kingdomwar_shadow_error_city);
	}

	void kingdomwar_system::callTowerReq(net::Msg& m, Json::Value& r)
	{
		LoadPlayer;
		ReadJsonArray;
		int id = js_msg[0u].asInt();
		KingdomWar::CityPtr ptr = CityMgr::shared().getCity(id);
		if (!ptr) Return(r, err_illedge);
		for (unsigned i = 0; i < ArmyNum; ++i)
		{
			const Position& pos = d->KingDomWarPos().position(i);
			if (pos.type == PosCity && pos.id == id)
			{
				int res = ptr->callElecTower(Common::gameTime(), d);	
				if (res == res_sucess)
					updateParam(d->Info().Nation());
				Return(r, res);
			}
		}
		Return(r, err_kingdomwar_tower_error_city);
	}

	void kingdomwar_system::useTowerItemReq(net::Msg& m, Json::Value& r)
	{
		LoadPlayer;
		ReadJsonArray;
		int type = js_msg[0u].asInt();
		int cid = js_msg[1u].asInt();
		int tid = js_msg[2u].asInt();
		KingdomWar::CityPtr ptr = CityMgr::shared().getCity(cid);
		if (!ptr) Return(r, err_illedge);
		for (unsigned i = 0; i < ArmyNum; ++i)
		{
			const Position& pos = d->KingDomWarPos().position(i);
			if (pos.type == PosCity && pos.id == cid)
			{
				int secs = 0;
				int res = ptr->useTowerItem(Common::gameTime(), d, type, tid, secs);
				if (res == res_sucess)
				{
					r[strMsg][1u] = type;
					r[strMsg][2u] = tid;
					r[strMsg][3u] = secs;
				}
				Return(r, res);
			}
		}
		Return(r, err_kingdomwar_item_error_city);
	}

	void kingdomwar_system::getCityBoxReq(net::Msg& m, Json::Value& r)
	{
		LoadPlayer;
		ReadJsonArray;
		int cid = js_msg[0u].asInt();
		KingdomWar::CityPtr ptr = CityMgr::shared().getCity(cid);
		if (!ptr) Return(r, err_illedge);
		int res = ptr->getSilverBox(d, r[strMsg][1u]);
		if (res == res_sucess)
			updateBoxInfo(d);
		Return(r, res);
	}

	void kingdomwar_system::shadowInfoReq(net::Msg& m, Json::Value& r)
	{
		LoadPlayer;
		d->KingDomWarShop().updateShadowInfo();
	}

	void kingdomwar_system::cityBoxInfoReq(net::Msg& m, Json::Value& r)
	{
		LoadPlayer;
		ReadJsonArray;
		int id = js_msg[0u].asInt();
		KingdomWar::CityPtr ptr = CityMgr::shared().getCity(id);
		if (!ptr)
			Return(r, err_illedge);
		qValue mm;
		mm.append(res_sucess);
		qValue q(qJson::qj_object);
		q.addMember("n", ptr->rewardBoxNum());
		mm.append(q);
		d->sendToClientFillMsg(gate_client::kingdom_war_city_box_info_resp, mm);
	}
		
	void kingdomwar_system::updateGreatEvent(playerDataPtr d, int idx)
	{
		qValue m;
		m.append(res_sucess);
		qValue q(qJson::qj_object);
		q.addMember("c", idx);
		KingdomWar::GreatEventMgr::shared().getInfo(idx, q);
		qValue b;
		d->KingDomWarBox().numBoxInfo(b);
		q.addMember("b", b);
		m.append(q);
		d->sendToClientFillMsg(gate_client::kingdom_war_great_event_resp, m);
	}

	void kingdomwar_system::getMainInfo(qValue& q)
	{
		qValue state_info;
		qValue nation_info;
		qValue protected_time_info;
		qValue box_info;
		CityMgr::shared().stateInfo(state_info);
		CityMgr::shared().nationInfo(nation_info);
		CityMgr::shared().protectedTimeInfo(protected_time_info);
		q.addMember("s", state_info);
		q.addMember("c", nation_info);
		q.addMember("pt", protected_time_info);
		qValue path_info;
		_path_list.getMainInfo(path_info);
		q.addMember("p", path_info);
		qValue buff;
		KingdomBuff::shared().getInfo(buff);
		q.addMember("a", buff);
		q.addMember("st", KingdomWar::State::shared().get());
		q.addMember("nt", KingdomWar::State::shared().nextTickTime());
		q.addMember("sp", speedRate());
		q.addMember("sr", supRate());
		q.addMember("fr", foodRate());
		q.addMember("br", battleRate());
		q.addMember("ps", PrimeState::shared().Get());
		q.addMember("npt", PrimeState::shared().nextTickTime());
	}

	void kingdomwar_system::mainInfo(playerDataPtr d)
	{
		qValue m;
		m.append(res_sucess);
		qValue q(qJson::qj_object);
		getMainInfo(q);
		m.append(q);
		d->sendToClientFillMsg(gate_client::kingdom_war_main_info_resp, m);

		updateSign(d);
		updateParam(d);
		updateBoxInfo(d);
		TowerMgr::shared().update(d);
		BattleNumMgr::shared().update(d);
	}

	void kingdomwar_system::mainInfo()
	{
		qValue m(qJson::qj_object);
		qValue mm;
		mm.append(res_sucess);
		qValue q(qJson::qj_object);
		getMainInfo(q);
		mm.append(q);
		m.addMember(strMsg, mm);
		detail::batchOnline(getObserver(), m, gate_client::kingdom_war_main_info_resp);
	}

	void kingdomwar_system::addTimer(unsigned tick_time, const KingdomWar::Timer::TickFunc& func)
	{
		KingdomWar::Timer::add(tick_time, func);
	}

	void kingdomwar_system::goBackMainCity(unsigned time, playerDataPtr d, int army_id, Json::Value& tips)
	{
		KingdomWar::CityPtr ptr = getMainCity(d->Info().Nation());
		if (!ptr)
			return;
		ptr->enter(time, d, army_id, tips);
	}

	void kingdomwar_system::startTimer()
	{
		KingdomWar::Timer::add(Common::gameTime() + 1, boostBind(kingdomwar_system::timerTick, this));
	}

	int kingdomwar_system::getCostTime(int from_id, int to_id)
	{
		return 0;
	}

	const KingdomWar::LineInfo& kingdomwar_system::getLine(int from_id, int to_id) const
	{
		return _shortest_path.getLine(from_id, to_id);
	}

	void kingdomwar_system::updateRank(playerDataPtr d, int old_value)
	{
		RankMgr::shared().update(d, old_value);
	}

	void kingdomwar_system::update()
	{
		ForEach(FuncList, it, _updaters)
			(*it)();
	}

	void kingdomwar_system::outputTick()
	{
		ForEach(Observer::IdList, it, getObserver())
		{
			playerDataPtr d = player_mgr.getOnlinePlayer(*it);
			if (!d) continue;
			d->KingDomWarOutput().update();
		}
	}

	void kingdomwar_system::tickEvery5Min()
	{
		unsigned cur_time = KingdomWar::State::shared().next5MinTime();
		KingdomWar::State::shared().reset5MinTime();
		addTimer(KingdomWar::State::shared().next5MinTime(), boostBind(kingdomwar_system::tickEvery5Min, this));

		ForEach(TickFuncList, it, _5_min_tickers)
			(*it)(cur_time);
		if (cur_time % (15 * MINUTE) == 0)
			outputTick();
		if (cur_time % HOUR == 0)
			KingdomBuff::shared().reset(cur_time);
	}

	void kingdomwar_system::addTimer()
	{
		addTimer(KingdomWar::State::shared().next5MinTime(), boostBind(kingdomwar_system::tickEvery5Min, this));
		addTimer(KingdomWar::State::shared().nextTickTime(), boostBind(kingdomwar_system::tickState, this));
		addTimer(KingdomWar::State::shared().nextClearTime(), boostBind(kingdomwar_system::tickClearTime, this));
		addTimer(KingdomWar::State::shared().nextTime03_00(), boostBind(kingdomwar_system::tickTime0300, this));
		addTimer(KingdomWar::State::shared().nextTime05_00(), boostBind(kingdomwar_system::tickTime0500, this));
		addTimer(KingdomWar::State::shared().nextTime20_00(), boostBind(kingdomwar_system::tickTime2000, this));
	}

	void kingdomwar_system::addUpdater(const Func& func)
	{
		_updaters.push_back(func);
	}

	void kingdomwar_system::add5MinTicker(const TickFunc& func)
	{
		_5_min_tickers.push_back(func);
	}

	void kingdomwar_system::tickState()
	{
		unsigned tick_time = KingdomWar::State::shared().nextTickTime();
		KingdomWar::State::shared().resetTickTimeAndState();
		addTimer(KingdomWar::State::shared().nextTickTime(), boostBind(kingdomwar_system::tickState, this));
		if (KingdomWar::State::shared().get() == KingdomWar::Closed)
		{
			if (season_sys.getSeason(tick_time) == SEASON::Winter)
				tickUnity(tick_time);

			//KingdomBuff::shared().reset(tick_time);
			//SignList::shared().clear();
			//for (unsigned i = 0; i < Kingdom::nation_num; ++i)
			//	updateSign(i);
		}

		qValue q(qJson::qj_object);
		qValue buff;
		KingdomBuff::shared().getInfo(buff);
		q.addMember("a", buff);
		q.addMember("st", KingdomWar::State::shared().get());
		q.addMember("nt", KingdomWar::State::shared().nextTickTime());
		qValue m(qJson::qj_object);
		qValue mm;
		mm.append(res_sucess);
		mm.append(q);
		m.addMember(strMsg, mm);
		detail::batchOnline(getObserver(), m, gate_client::kingdom_war_main_update_resp);

		playerManager::playerDataVec vec = player_mgr.nationAllOnline();

		
		for (unsigned i = 0; i < vec.size(); ++i)
		{
			if (vec[i])
				vec[i]->KingDomWar().updateRedPoint();
		}
	}

	void kingdomwar_system::tickUnity(unsigned cur_time)
	{
		int nation = KingdomWar::CityCounter::shared().unityNation();
		if (nation == -1)
			return;
		qValue e(qJson::qj_object);
		e.addMember("t", cur_time);
		kingfight_sys.getData(nation)->getUnityInfo(e);
		KingdomWar::GreatEventPtr ptr = Creator<KingdomWar::GreatEvent>::Create(cur_time, nation, e);
		KingdomWar::GreatEventMgr::shared().push(ptr);
		KingdomWar::State::shared().setUnityFlag();
		CityMgr::shared().tickUnity(cur_time);
		_path_list.clear(cur_time);
		const std::string& name = kingfight_sys.getData(nation)->getKingName();
		Log(DBLOG::strLogKingdomWar, 11, cur_time, nation, name);
		noticeUnity(nation);
	}

	void kingdomwar_system::tickClearTime()
	{
		unsigned cur_time = KingdomWar::State::shared().nextClearTime();
		KingdomWar::State::shared().resetClearTime();
		addTimer(KingdomWar::State::shared().nextClearTime(), boostBind(kingdomwar_system::tickClearTime, this));

		RankMgr::shared().tickRank();
		if (KingdomWar::State::shared().unityFlag())
		{
			CityMgr::shared().tickResetUnity(cur_time);
			KingdomWar::State::shared().clearUnityFlag();
		}
	}

	const Json::Value& kingdomwar_system::getRankReward(int rank) const
	{
		return rank > _rank_reward.size()? _rank_reward.back() : _rank_reward[rank - 1];
	}
	
	void kingdomwar_system::updateSign(playerDataPtr d)
	{
		qValue m;
		m.append(res_sucess);
		qValue q(qJson::qj_object);
		qValue qq;
		SignList::shared().getInfo(qq, d->Info().Nation());
		q.addMember("c", qq);
		m.append(q);
		d->sendToClientFillMsg(gate_client::kingdom_war_sign_info_resp, m);
	}

	void kingdomwar_system::updateSign(int nation)
	{
		std::vector<int> id_list;
		ForEachC(KingdomWar::Observer::IdList, it, getObserver())
		{
			playerDataPtr d = player_mgr.getOnlinePlayer(*it);
			if (d && d->Info().Nation() == nation)
				id_list.push_back(*it);
		}
		
		qValue m(qJson::qj_object);
		qValue mm;
		mm.append(res_sucess);
		qValue q(qJson::qj_object);
		qValue qq;
		SignList::shared().getInfo(qq, nation);
		q.addMember("c", qq);
		mm.append(q);
		m.addMember(strMsg, mm);
		detail::batchOnline(id_list, m, gate_client::kingdom_war_sign_info_resp);
	}

	void kingdomwar_system::updateHpInfo(playerDataPtr d, int army_id)
	{
		qValue m;
		m.append(res_sucess);
		qValue q(qJson::qj_object);
		d->KingDomWarFM().getHpInfo(army_id, q);
		m.append(q);
		d->sendToClientFillMsg(gate_client::kingdom_war_army_info_resp, m);
	}

	KingdomWar::NpcDataCfgPtr kingdomwar_system::getNpcData(int map_id)
	{
		NpcDataCfgMap::iterator it = _npc_map.find(map_id);
		return it == _npc_map.end()? KingdomWar::NpcDataCfgPtr() : it->second;
	}

	const KingdomWar::HpDebuff& kingdomwar_system::hpDebuff(int hp) const
	{
		if (hp < 0)
			hp = 0;
		if (hp >= _hp_debuff.size())
			hp = _hp_debuff.size() - 1;
		return _hp_debuff[hp];
	}

	void kingdomwar_system::addHpDebuff(sBattlePtr sb, int hp)
	{
		const KingdomWar::HpDebuff& hd = hpDebuff(hp);
		//LogI << "hp atk debuff: " << hd._atk_debuff << LogEnd;
		//LogI << "hp def debuff: " << hd._def_debuff << LogEnd;
		ForEach(manList, it, sb->battleMan)
		{
			(*it)->battleAttri[idx_phyHurtRate] -= hd._atk_debuff;
			(*it)->battleAttri[idx_phyCutRate] -= hd._def_debuff;
			(*it)->battleAttri[idx_warHurtRate] -= hd._atk_debuff;
			(*it)->battleAttri[idx_warCutRate] -= hd._def_debuff;
			(*it)->battleAttri[idx_magicHurtRate] -= hd._atk_debuff;
			(*it)->battleAttri[idx_magicCutRate] -= hd._def_debuff;
			(*it)->battleAttri[idx_cureRate] -= hd._atk_debuff;
		}
	}

	void kingdomwar_system::DoBroadcast(int nation, qValue& m)
	{
		if (nation == -1)
			chat_sys.despatchAll(CHAT::server_kingdom_war, m);
		else if (nation == -2)
			chat_sys.despatchKingdomWar(CHAT::server_kingdom_war, m);
		else
			chat_sys.despatchKingdom(CHAT::server_kingdom_war, (Kingdom::NATION)nation, m);
	}

	void kingdomwar_system::updateName(playerDataPtr d)
	{
		if (!KingdomWar::checkLimit(d))
			return;

		for (unsigned i = 0; i < KingdomWar::ArmyNum; ++i)
		{
			const KingdomWar::Position& pos = d->KingDomWarPos().position(i);
			if (pos.type != KingdomWar::PosPath)
			{
				KingdomWar::CityPtr ptr = CityMgr::shared().getCity(pos.id);
				if (ptr)
					ptr->updateName(d);
			}
		}
	}

	void kingdomwar_system::loadPathPlayer(KingdomWar::PathPtr ptr, unsigned time, int pid, int army_id, int to_city_id)
	{
		playerDataPtr d = player_mgr.getPlayer(pid);
		if (!d) return;
		ptr->enter(time, d, army_id, to_city_id);
	}

	void kingdomwar_system::loadPathNpc(KingdomWar::PathPtr ptr, unsigned time, KingdomWar::NpcDataPtr d, int to_city_id)
	{
		if (d->type() != KingdomWar::ActiveNpc)
		{
			LogE << "only active npc allow to move" << LogEnd;
			return;
		}
		ptr->enter(time, d, to_city_id);
	}

	void kingdomwar_system::loadPathShadow(KingdomWar::PathPtr ptr, unsigned time, KingdomWar::ShadowDataPtr d, int to_city_id)
	{
		LogE << "no realize" << LogEnd;
	}

	void kingdomwar_system::loadPathShadowNpc(KingdomWar::PathPtr ptr, unsigned time, KingdomWar::ShadowNpcDataPtr d, int to_city_id)
	{
		LogE << "no realize" << LogEnd;
	}

	void kingdomwar_system::initPrimeState(unsigned tick_time)
	{
		_path_list.reset(tick_time);
	}

	void kingdomwar_system::tickPrimeTime(unsigned tick_time)
	{
		_path_list.reset(tick_time);
		CityMgr::shared().tickPrimeState(tick_time);
		mainInfo();
		playerManager::playerDataVec vec = player_mgr.nationAllOnline();
		NationTaskMgr::shared().start(tick_time);
		for (unsigned i = 0; i < vec.size(); ++i)
		{
			if (vec[i])
			{
				vec[i]->KingDomWarPos().update();
				vec[i]->KingDomWarTask().checkAndUpdate();
			}
		}
	}

	void kingdomwar_system::tickOrdinaryTime(unsigned tick_time)
	{
		_path_list.reset(tick_time);
		CityMgr::shared().tickPrimeState(tick_time);
		mainInfo();
		playerManager::playerDataVec vec = player_mgr.nationAllOnline();
		for (unsigned i = 0; i < vec.size(); ++i)
		{
			if (vec[i])
				vec[i]->KingDomWarPos().update();
		}
		NationTaskMgr::shared().stop(tick_time);
	}

	void kingdomwar_system::updateNationTask(int nation, int type, const Json::Value& arg)
	{
		if (!PrimeState::shared())
			return;
		NationTaskMgr::shared().update(type, nation, arg);
	}
	
	void kingdomwar_system::updatePersonTask(playerDataPtr d, int type, const Json::Value& arg)
	{
		if (!PrimeState::shared())
			return;
		d->KingDomWarTask().update(type, arg);
	}

	int kingdomwar_system::battleSilver(playerDataPtr d, int result) const
	{
		if (_battle_silver.empty())
			return 0;
		unsigned times = d->KingDomWar().battleTimes();
		if (times >= _battle_silver.size())
			times = _battle_silver.size() - 1;
		return result == KingdomWar::Win? _battle_silver[times] : (_battle_silver[times] * 2 / 3);
	}

	void kingdomwar_system::setPrimeTimeBroadcast()
	{
		unsigned next_tick_time;

		next_tick_time = Common::getNextTimeHMS(Common::gameTime(), 19, 55, 0);
		::Timer::AddEventPerTimeCT(boostBind(kingdomwar_system::tickBC2020, this), Inter::event_kingdomwar_timer, next_tick_time, DAY);
		next_tick_time = Common::getNextTimeHMS(Common::gameTime(), 20, 0, 0);
		::Timer::AddEventPerTimeCT(boostBind(kingdomwar_system::tickBC2025, this), Inter::event_kingdomwar_timer, next_tick_time, DAY);

		next_tick_time = Common::getNextTimeHMS(Common::gameTime(), 20, 0, 0);
		::Timer::AddEventPerTimeCT(boostBind(kingdomwar_system::tickRollBC2025To2055, this), Inter::event_kingdomwar_timer, next_tick_time, DAY);
		next_tick_time = Common::getNextTimeHMS(Common::gameTime(), 20, 5, 0);
		::Timer::AddEventPerTimeCT(boostBind(kingdomwar_system::tickRollBC2025To2055, this), Inter::event_kingdomwar_timer, next_tick_time, DAY);
		next_tick_time = Common::getNextTimeHMS(Common::gameTime(), 20, 10, 0);
		::Timer::AddEventPerTimeCT(boostBind(kingdomwar_system::tickRollBC2025To2055, this), Inter::event_kingdomwar_timer, next_tick_time, DAY);
		next_tick_time = Common::getNextTimeHMS(Common::gameTime(), 20, 15, 0);
		::Timer::AddEventPerTimeCT(boostBind(kingdomwar_system::tickRollBC2025To2055, this), Inter::event_kingdomwar_timer, next_tick_time, DAY);
		next_tick_time = Common::getNextTimeHMS(Common::gameTime(), 20, 20, 0);
		::Timer::AddEventPerTimeCT(boostBind(kingdomwar_system::tickRollBC2025To2055, this), Inter::event_kingdomwar_timer, next_tick_time, DAY);
		next_tick_time = Common::getNextTimeHMS(Common::gameTime(), 20, 25, 0);
		::Timer::AddEventPerTimeCT(boostBind(kingdomwar_system::tickRollBC2025To2055, this), Inter::event_kingdomwar_timer, next_tick_time, DAY);

		next_tick_time = Common::getNextTimeHMS(Common::gameTime(), 12, 25, 0);
		::Timer::AddEventPerTimeCT(boostBind(kingdomwar_system::tickBC2020, this), Inter::event_kingdomwar_timer, next_tick_time, DAY);
		next_tick_time = Common::getNextTimeHMS(Common::gameTime(), 12, 30, 0);
		::Timer::AddEventPerTimeCT(boostBind(kingdomwar_system::tickBC2025, this), Inter::event_kingdomwar_timer, next_tick_time, DAY);

		next_tick_time = Common::getNextTimeHMS(Common::gameTime(), 12, 30, 0);
		::Timer::AddEventPerTimeCT(boostBind(kingdomwar_system::tickRollBC2025To2055, this), Inter::event_kingdomwar_timer, next_tick_time, DAY);
		next_tick_time = Common::getNextTimeHMS(Common::gameTime(), 12, 35, 0);
		::Timer::AddEventPerTimeCT(boostBind(kingdomwar_system::tickRollBC2025To2055, this), Inter::event_kingdomwar_timer, next_tick_time, DAY);
		next_tick_time = Common::getNextTimeHMS(Common::gameTime(), 12, 40, 0);
		::Timer::AddEventPerTimeCT(boostBind(kingdomwar_system::tickRollBC2025To2055, this), Inter::event_kingdomwar_timer, next_tick_time, DAY);
		next_tick_time = Common::getNextTimeHMS(Common::gameTime(), 12, 45, 0);
		::Timer::AddEventPerTimeCT(boostBind(kingdomwar_system::tickRollBC2025To2055, this), Inter::event_kingdomwar_timer, next_tick_time, DAY);
		next_tick_time = Common::getNextTimeHMS(Common::gameTime(), 12, 50, 0);
		::Timer::AddEventPerTimeCT(boostBind(kingdomwar_system::tickRollBC2025To2055, this), Inter::event_kingdomwar_timer, next_tick_time, DAY);
		next_tick_time = Common::getNextTimeHMS(Common::gameTime(), 12, 55, 0);
		::Timer::AddEventPerTimeCT(boostBind(kingdomwar_system::tickRollBC2025To2055, this), Inter::event_kingdomwar_timer, next_tick_time, DAY);
	}

	void kingdomwar_system::tickBC2020()
	{
		DoBroadcast(-1, qValue() << 4);
	}

	void kingdomwar_system::tickBC2025()
	{
		DoBroadcast(-1, qValue() << 5);
	}

	void kingdomwar_system::tickRollBC2025To2055()
	{
		Json::Value roll_msg;
		roll_msg.append(6);
		Json::Value extra_json;
		extra_json["weight"] = 0;
		extra_json["roll"] = 3;
		chat_sys.despatchAllSP(CHAT::server_kingdom_war, roll_msg, extra_json, CHATPOS::scroll_bar_top);
	}

	void kingdomwar_system::tickTime0500()
	{
		unsigned cur_time = KingdomWar::State::shared().nextTime05_00();
		NationTaskMgr::shared().clear();
		NationParam::shared().reset();
		for (unsigned i = 0; i < Kingdom::nation_num; ++i)
			updateParam(i);

		KingdomWar::State::shared().resetTime05_00();
		addTimer(KingdomWar::State::shared().nextTime05_00(), boostBind(kingdomwar_system::tickTime0500, this));
	}

	void kingdomwar_system::tickTime2000()
	{
		unsigned cur_time = KingdomWar::State::shared().nextTime20_00();
		//NationTaskMgr::shared().reset();

		KingdomWar::State::shared().resetTime20_00();
		addTimer(KingdomWar::State::shared().nextTime20_00(), boostBind(kingdomwar_system::tickTime2000, this));
	}

	void kingdomwar_system::tickTime0300()
	{
		unsigned cur_time = KingdomWar::State::shared().nextTime03_00();

		personalTaskLog(cur_time);

		KingdomWar::State::shared().resetTime03_00();
		addTimer(KingdomWar::State::shared().nextTime03_00(), boostBind(kingdomwar_system::tickTime0300, this));
	}

	void kingdomwar_system::noticeUnity(int nation)
	{
		Json::Value m;
		m[strMsg][0u] = res_sucess;
		m[strMsg][1u]["nt"] = nation;
		const std::string& name = kingfight_sys.getData(nation)->getKingName();
		m[strMsg][1u]["na"] = name;
		playerManager::playerDataVec vec = player_mgr.nationAllOnline();
		detail::batchOnline(vec, m, gate_client::kingdom_war_notice_unity_resp);

		DoBroadcast(-1, qValue() << 7 << nation << name);
	}

	void kingdomwar_system::personalTaskLog(unsigned cur_time)
	{
		/*
		unsigned reset_time = cur_time - 7 * HOUR; // 20:00 reset task
		unsigned end_time = reset_time + 55 * MINUTE; // 20:55 end task
		unsigned total_count = 0;

		objCollection objs = db_mgr.Query(DBN::dbPlayerKingdomWarTask);
		ForEachC(objCollection, it, objs)
		{
			const mongo::BSONObj& obj = *it;
			int pid = obj[strPlayerID].Int();
			unsigned last_update_time = obj["lt"].Int();
			if (last_update_time == reset_time)
			{
				playerDataPtr d = player_mgr.getPlayer(pid);
				d->KingDomWarTask().personalTaskLog(end_time);
				++total_count;
			}
		}
		LogI << "kingdom war personal task log: " << total_count << LogEnd;*/
	}

	void kingdomwar_system::updateParam(int nation)
	{
		std::vector<int> id_list;
		ForEachC(KingdomWar::Observer::IdList, it, getObserver())
		{
			playerDataPtr d = player_mgr.getOnlinePlayer(*it);
			if (d && d->Info().Nation() == nation)
				id_list.push_back(*it);
		}
		
		qValue m(qJson::qj_object);
		qValue mm;
		mm.append(res_sucess);
		qValue q(qJson::qj_object);
		NationParam::shared().getInfo(q, nation);
		mm.append(q);
		m.addMember(strMsg, mm);
		detail::batchOnline(id_list, m, gate_client::kingdom_war_nation_param_resp);
	}

	void kingdomwar_system::updateParam(playerDataPtr d)
	{
		qValue m;
		m.append(res_sucess);
		qValue q(qJson::qj_object);
		NationParam::shared().getInfo(q, d->Info().Nation());
		m.append(q);
		d->sendToClientFillMsg(gate_client::kingdom_war_nation_param_resp, m);
	}

	void kingdomwar_system::updateBoxInfo(playerDataPtr d)
	{
		qValue m;
		m.append(res_sucess);
		qValue q(qJson::qj_object);
		qValue bx;
		const CityList& box_list = CityMgr::shared().boxList();
		ForEachC(CityList, it, box_list)
		{
			if ((*it)->boxState(d))
				bx.append((*it)->id());
		}
		q.addMember("bx", bx);
		m.append(q);
		d->sendToClientFillMsg(gate_client::kingdom_war_box_info_resp, m);
	}

	void kingdomwar_system::updateBoxInfo()
	{
		ForEach(Observer::IdList, it, getObserver())
		{
			playerDataPtr d = player_mgr.getOnlinePlayer(*it);
			if (!d) continue;
			updateBoxInfo(d);
		}
	}

	int kingdomwar_system::winHpCost(int star) const
	{
		return PrimeState::shared()?
			_win_hp_cost_2[checkStar(star)] : _win_hp_cost[checkStar(star)];
	}

	int kingdomwar_system::loseHpCost(int star) const
	{
		return PrimeState::shared()?
			_lose_hp_cost_2[checkStar(star)] : _lose_hp_cost[checkStar(star)];
	}


	/*
	int kingdomwar_system::distance(playerDataPtr d, int from, int to) const
	{
		CityPtr ptr = CityMgr::shared().getCity(to);
		if (!ptr || (d->Info().Nation() != ptr->nation() && ptr->onFired()))
			return -1;
		return _graph->line(from, to);
	}
	*/

	void kingdomwar_system::nearbyID(playerDataPtr d, const int from, std::vector<int>& nearby_ids)
	{
		const NearbyID& n = _nearby_ids[from];
		ForEachC(NearbyID, it, n)
		{
			CityPtr ptr = CityMgr::shared().getCity(*it);
			if (ptr && (d->Info().Nation() == ptr->nation() || ptr->state() != Protected))
				nearby_ids.push_back(*it);
		}
	}

	unsigned kingdomwar_system::distance(const int from, const int to)
	{
		return _graph->line(from, to);
	}

	DOLOAD(Npc)
	DOLOAD(Shadow)
	DOLOAD(ShadowNpc)
}

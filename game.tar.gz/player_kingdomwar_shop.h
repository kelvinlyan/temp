#pragma once

#include "auto_base.h"
#include "mongoDB.h"

namespace gg
{
	class playerKingdomWarShop
		: public _auto_player
	{
		public:
			playerKingdomWarShop(playerData* const own);

			virtual void classLoad();
			virtual bool _auto_save();
			virtual void _auto_update();

			void dailyTick();
			int getUsedExploit() const { return _used_exploit; }
			void alterUsedExploit(int num);

			unsigned callShadowTimes(int type) const { return _call_shadow_times[type]; }
			bool inShadowCd(int type) const;
			unsigned callShadowCd(int type) const { return _call_shadow_cd[type]; }
			void alterShadowTimes(int type);

			void updateShadowInfo();
			unsigned channelCD() const { return _channel_cd; }
			void channelSend();

		private:
			int _used_exploit;

			std::vector<unsigned> _call_shadow_times;
			std::vector<unsigned> _call_shadow_cd;
			std::vector<int> _in_shadow_cd; // 0 or 1

			unsigned _channel_cd;
	};
}

#include "gamer_resource.h"
#include "dbDriver.h"
#include "task_mgr.h"
#include "kingdom_system.h"

namespace gg
{
	bool addSilverByKingdomConstruction()
	{
		int type = State::getState() / 50;
		return type == gate_client::player_worldboss_ui_req / 50
			|| type == gate_client::kingdom_war_quit_req / 50
			|| State::getState() == Inter::event_world_boss_timer
			|| State::getState() == Inter::event_kingdomwar_timer;
	}

	playerResource::playerResource(playerData* const own) : _auto_player(own)
	{
		initial();
	}

	void playerResource::initial()
	{
		Gold = 0;
		Ticket = 50;
		Silver = 10000;
		Troops = 0;
		Food = 30000;
		Wood = 30000;
		Iron = 30000;
		Fame = 0;
		Action = 25;
		Merit = 0;
	//	Contribution = 0;
		HeroPartyMoney = 0;
		LadyCoin = 0;
		shareTimes = 10;
		SearchPoints = 0;
		RechargeNum = 0;
		Dice = 20;
	}

	void playerResource::classLoad()
	{
		mongo::BSONObj key = BSON(strPlayerID << Own().ID());
		mongo::BSONObj obj = db_mgr.FindOne(DBN::dbPlayerRes, key);
		if (obj.isEmpty())return;
		Gold = obj["gl"].Int();
		Ticket = obj["tk"].Int();
		Silver = (obj["sil"].type() == mongo::NumberInt) ? obj["sil"].Int() : obj["sil"].Long();
		Troops = (obj["trp"].type() == mongo::NumberInt) ? obj["trp"].Int() : obj["trp"].Long();
		Food = (obj["fd"].type() == mongo::NumberInt) ? obj["fd"].Int() : obj["fd"].Long();
		Wood = (obj["wd"].type() == mongo::NumberInt) ? obj["wd"].Int() : obj["wd"].Long();
		Iron = (obj["ir"].type() == mongo::NumberInt) ? obj["ir"].Int() : obj["ir"].Long();
		Merit = (obj["me"].type() == mongo::NumberInt) ? obj["me"].Int() : obj["me"].Long();
		Fame = (obj["fa"].type() == mongo::NumberInt) ? obj["fa"].Int() : obj["fa"].Long();
		Action = obj["ac"].Int();
		//if (!obj["co"].eoo())Contribution = obj["co"].Int();
		if (!obj["hpm"].eoo())HeroPartyMoney = obj["hpm"].Int();
		if (!obj["lc"].eoo())LadyCoin = obj["lc"].Int();
		if (!obj["st"].eoo())shareTimes = obj["st"].Int();
		if (!obj["rp"].eoo())RedPaper = obj["rp"].Int();
		if (!obj["pts"].eoo())Points = obj["pts"].Int();
		if (!obj["spt"].eoo())SearchPoints = obj["spt"].Int();
		if (!obj["rcn"].eoo())RechargeNum = obj["rcn"].Int();
		if (!obj["die"].eoo())Dice = obj["die"].Int();
	}

	bool playerResource::_auto_save()
	{
		mongo::BSONObj key = BSON(strPlayerID << Own().ID());
		mongo::BSONObj obj = BSON(strPlayerID << Own().ID() << "gl" <<
			Gold << "tk" << Ticket << "sil" << Silver << "trp" << Troops <<
			"fd" << Food << "wd" << Wood << "ir" << Iron << "me" <<
			Merit << "fa" << Fame << "ac" << Action << "hpm" << HeroPartyMoney << "lc" 
			<< LadyCoin << "st" << shareTimes << "rp" << RedPaper << 
			"pts" << Points << "spt" << SearchPoints << "rcn" << RechargeNum << "die" << Dice);
		return db_mgr.SaveMongo(DBN::dbPlayerRes, key, obj);
	}

	void playerResource::_auto_update()
	{
		qValue json(qJson::qj_object), list_json(qJson::qj_array), resJson(qJson::qj_object);
		resJson.addMember("gl", Gold);
		resJson.addMember("tk", Ticket);
		resJson.addMember("sil", Silver);
		resJson.addMember("trp", Troops);
		resJson.addMember("fd", Food);
		resJson.addMember("wd", Wood);
		resJson.addMember("ir", Iron);
		resJson.addMember("me", Merit);
		resJson.addMember("fa", Fame);
		resJson.addMember("ac", Action);
		resJson.addMember("co", getContribution());
		resJson.addMember("hpm", HeroPartyMoney);
		resJson.addMember("lc", LadyCoin);
		resJson.addMember("st", shareTimes);
		resJson.addMember("spt", SearchPoints);
		resJson.addMember("exc", getExploit());
		resJson.addMember("die", Dice);//
		list_json.append(res_sucess);
		list_json.append(resJson);
		list_json.append(State::getState());
		json.addMember(strMsg, list_json);
		Own().sendToClient(gate_client::player_res_update_resp, json);
	}

	LargerRes playerResource::alterSilver(const LargerRes val)
	{
		if (0 == val)return 0;
		int oldVal = Silver;
		Silver += val;
		if (val > 0 
			&& Own().Info().Nation() != Kingdom::null
			&& addSilverByKingdomConstruction())
		{
			KingdomPtr kingdom_ptr = kingdom_sys.getData(Own().Info().Nation());
			if (kingdom_ptr)
				Silver += val * (double)kingdom_ptr->getAddNum(Kingdom::CBoss) / 10000.0;
		}
// 		if (Silver < 0)
// 		{
// 			int abs_sil = std::abs(Silver);
// 			int cost_gold = (abs_sil / 100) + (abs_sil % 100 ? 1 : 0);
// 			alterCash(-cost_gold);
// 			Silver += (cost_gold * 100);
// 		}
		Silver = Silver < 0 ? 0 : Silver;
		int add = Silver - oldVal;
		_sign_auto();
		Log(DBLOG::strLogSilver, Own().getOwnDataPtr(), -1, oldVal, Silver);
		if (val > 0)
			TaskMgr::update(Own().getOwnDataPtr(), Task::GetSilverNum, add);
		else
			TaskMgr::update(Own().getOwnDataPtr(), Task::UseSilverNum, 0 - add);
		return add;
	}
	int playerResource::alterTicket(const int val, const bool isConsume /* = true */)
	{
		if (0 == val)return 0;
		int oldVal = Ticket;
		Ticket += val;
		Ticket = Ticket < 0 ? 0 : Ticket;
		if (val < 0)
		{
			TaskMgr::update(Own().getOwnDataPtr(), Task::ConsumeNum, 0 - val);
			TaskMgr::update(Own().getOwnDataPtr(), Task::ConsumeTimes, 1);
		}
		_sign_auto();
		onAlterTicket(oldVal);
		Log(DBLOG::strLogGold, Own().getOwnDataPtr(), -1, oldVal, Ticket, Gold, Gold);
		return Ticket - oldVal;
	}
	int playerResource::alterGold(const int val, const bool isConsume /* = true */)
	{
		if (0 == val)return 0;
		int oldVal = Gold;
		Gold += val;
		Gold = Gold < 0 ? 0 : Gold;
		if (val < 0)
		{
			TaskMgr::update(Own().getOwnDataPtr(), Task::ConsumeNum, 0 - val);
			TaskMgr::update(Own().getOwnDataPtr(), Task::ConsumeTimes, 1);
		}
		_sign_auto();
		onAlterGold(oldVal);
		Log(DBLOG::strLogGold, Own().getOwnDataPtr(), -1, Ticket, Ticket, oldVal, Gold);
		return Gold - oldVal;
	}
	void GoldAlterHelper(int& first, int& second, const int num)
	{
		first += num;
		if (first < 0){
			second += first;
			second = second < 0 ? 0 : second;
			first = 0;
		}
	}
	int playerResource::alterCash(const int val, const bool isConsume /* = true */)
	{
		if (0 == val)return 0;
		int oldTicket = Ticket;
		int oldGold = Gold;
		GoldAlterHelper(Ticket, Gold, val);
		if (val < 0)
		{
			TaskMgr::update(Own().getOwnDataPtr(), Task::ConsumeNum, 0 - val);
			TaskMgr::update(Own().getOwnDataPtr(), Task::ConsumeTimes, 1);
		}
		_sign_auto();
		onAlterTicket(oldTicket);
		onAlterGold(oldGold);
		Log(DBLOG::strLogGold, Own().getOwnDataPtr(), -1, oldTicket, Ticket, oldGold, Gold);
		return Ticket + Gold - oldTicket - oldGold;
	}
	LargerRes playerResource::alterTroops(const LargerRes val)
	{
		int oldVal = Troops;
		Troops += val;
		Troops = Troops < 0 ? 0 : Troops;
		_sign_auto();
		return Troops - oldVal;
	}
	LargerRes playerResource::alterFood(const LargerRes val)
	{
		if (0 == val)return 0;
		int oldVal = Food;
		Food += val;
		Food = Food < 0 ? 0 : Food;
		_sign_auto();
		Log(DBLOG::strLogFood, Own().getOwnDataPtr(), -1, oldVal, Food);
		if (val > 0)
			TaskMgr::update(Own().getOwnDataPtr(), Task::GetFoodNum, val);
		else
			TaskMgr::update(Own().getOwnDataPtr(), Task::UseFoodNum, 0 - val);
		return Food - oldVal;
	}	
	LargerRes playerResource::alterWood(const LargerRes val)
	{
		if (0 == val)return 0;
		int oldVal = Wood;
		Wood += val;
		Wood = Wood < 0 ? 0 : Wood;
		_sign_auto();
		Log(DBLOG::strLogWood, Own().getOwnDataPtr(), -1, oldVal, Wood);
		if (val > 0)
			TaskMgr::update(Own().getOwnDataPtr(), Task::GetWoodNum, val);
		else
			TaskMgr::update(Own().getOwnDataPtr(), Task::UseWoodNum, 0 - val);
		return Wood - oldVal;
	}
	LargerRes playerResource::alterIron(const LargerRes val)
	{
		if (0 == val)return 0;
		int oldVal = Iron;
		Iron += val;
		Iron = Iron < 0 ? 0 : Iron;
		_sign_auto();
		Log(DBLOG::strLogIron, Own().getOwnDataPtr(), -1, oldVal, Iron);
		if (val > 0)
			TaskMgr::update(Own().getOwnDataPtr(), Task::GetIronNum, val);
		else
			TaskMgr::update(Own().getOwnDataPtr(), Task::UseIronNum, 0 - val);
		return Iron - oldVal;
	}
	LargerRes playerResource::alterMerit(const LargerRes val)
	{
		if (0 == val)return 0;
		int oldVal = Merit;
		Merit += val;
		Merit = Merit < 0 ? 0 : Merit;
		_sign_auto();
		Log(DBLOG::strLogMerit, Own().getOwnDataPtr(), -1, oldVal, Merit);
		if (val > 0)
			TaskMgr::update(Own().getOwnDataPtr(), Task::GetMeritNum, val);
		else
			TaskMgr::update(Own().getOwnDataPtr(), Task::UseMeritNum, 0 - val);
		return Merit - oldVal;
	}
	LargerRes playerResource::alterFame(const LargerRes val)
	{
		if (0 == val)return 0;
		int oldVal = Fame;
		Fame += val;
		if (val > 0 && Own().Info().Nation() != Kingdom::null)
		{
			KingdomPtr kingdom_ptr = kingdom_sys.getData(Own().Info().Nation());
			if (kingdom_ptr)
				Fame += val * (double)kingdom_ptr->getAddNum(Kingdom::CFame) / 10000.0;
		}
		Fame = Fame < 0 ? 0 : Fame;
		int add = Fame - oldVal;
		_sign_auto();
		Log(DBLOG::strLogFame, Own().getOwnDataPtr(), -1, oldVal, Fame);
		if (val > 0)
			TaskMgr::update(Own().getOwnDataPtr(), Task::GetFameNum, add);
		else
			TaskMgr::update(Own().getOwnDataPtr(), Task::UseFameNum, 0 - add);
		return add;
	}
	int playerResource::alterAction(const int val)
	{
		if (0 == val)return 0;
		int oldVal = Action;
		Action += val;
		Action = Action < 0 ? 0 : Action;
		_sign_auto();
		Log(DBLOG::strLogAction, Own().getOwnDataPtr(), -1, oldVal, Action);
		onAlterAction(oldVal);
		return Action - oldVal;
	}

	int playerResource::getContribution()
	{
		return Own().KingDom().getCurCon();
	}
	int playerResource::alterContribution(const int val)
	{
		if (0 == val)return 0;
		int oldVal = getContribution();
		Own().KingDom().alterCon(val);
		_sign_update();
		Log(DBLOG::strLogContribution, Own().getOwnDataPtr(), -1, oldVal, getContribution());
		onAlterContribution(val);
		return getContribution() - oldVal;
	}
	int playerResource::alterHeroPartyMoney(const int val)
	{
		if (0 == val)return 0;
		int oldVal = HeroPartyMoney;
		HeroPartyMoney += val;
		HeroPartyMoney = HeroPartyMoney < 0 ? 0 : HeroPartyMoney;
		_sign_auto();
		Log(DBLOG::strLogHeroPartyMoney, Own().getOwnDataPtr(), -1, oldVal, HeroPartyMoney);
		return HeroPartyMoney - oldVal;
	}
	int playerResource::alterLadyCoin(const int val)
	{
		if (0 == val)return 0;
		int oldVal = LadyCoin;
		LadyCoin += val;
		LadyCoin = LadyCoin < 0 ? 0 : LadyCoin;
		_sign_auto();
		Log(DBLOG::strLogLadyCoin, Own().getOwnDataPtr(), -1, oldVal, LadyCoin);
		return LadyCoin - oldVal;
	}

	int playerResource::alterShareTimes(const int val)
	{
		if (0 == val)return 0;
		int oldVal = shareTimes;
		shareTimes += val;
		shareTimes = shareTimes < 0 ? 0 : shareTimes;
		_sign_auto();
		return shareTimes - oldVal;
	}

	int playerResource::alterPaper(const int val)
	{
		if (0 == val)return 0;
		int oldVal = RedPaper;
		RedPaper += val;
		RedPaper = RedPaper < 0 ? 0 : RedPaper;
		_sign_auto();
		Log(DBLOG::strLogRedPaper, Own().getOwnDataPtr(), -1, oldVal, RedPaper);
		return RedPaper - oldVal;
	}

	int playerResource::alterPoints(const int val)
	{
		if (0 == val)return 0;
		int oldVal = Points;
		Points += val;
		Points = Points < 0 ? 0 : Points;
		_sign_auto();
		Log(DBLOG::strLogPoints, Own().getOwnDataPtr(), -1, oldVal, Points);
		return Points - oldVal;
	}

	int playerResource::alterSearchPoints(const int val)
	{
		if (0 == val)return 0;
		int oldVal = SearchPoints;
		SearchPoints += val;
		SearchPoints = SearchPoints < 0 ? 0 : SearchPoints;
		_sign_auto();
		Log(DBLOG::strLogSearchPoint, Own().getOwnDataPtr(), -1, oldVal, SearchPoints);
		return SearchPoints - oldVal;
	}

	void playerResource::addRechargeNum(const int num)
	{
		if (num < 1)return;
		if (0 == RechargeNum)
		{
			Own().Vip().addVipGift(0);
		}
		RechargeNum += num;
		TaskMgr::update(Own().getOwnDataPtr(), Task::RechargeNum, num);
		_sign_save();
	}

	void playerResource::alterExploit(int num)
	{
		int oldVal = getExploit();
		Own().KingDomWar().alterExploit(num);
		_sign_update();
		Log(DBLOG::strLogExploit, Own().getOwnDataPtr(), -1, oldVal, getExploit());
		if (num > 0)
		{
			Own().Daily().tickTask(DAILY::won_exploit_coin, num);
		}
	}

	int playerResource::getExploit()
	{
		return Own().KingDomWar().getTotalExploit() - Own().KingDomWarShop().getUsedExploit();
	}

	int playerResource::alterDice(const int val)
	{
		int oldVal = Dice;
		if (Dice + val > DICE_MAX)
		{
			Dice = DICE_MAX;
		}
		else if (Dice + val < 0)
		{
			Dice = 0;
		}
		else
		{
			Dice += val;
		}

		_sign_auto();
		Log(DBLOG::strLogDice, Own().getOwnDataPtr(), -1, oldVal, Dice);
		return Dice;
	}
}

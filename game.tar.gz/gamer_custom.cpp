#include "gamer_custom.h"
#include "dbDriver.h"
#include "gm_tools.h"

namespace gg
{
	playerCustom::playerCustom(playerData* const own) : _auto_player(own)
	{
		dataMap.clear();
	}

	void playerCustom::classLoad()
	{
		mongo::BSONObj key = BSON(strPlayerID << Own().ID());
		mongo::BSONObj obj = db_mgr.FindOne(DBN::dbPlayerCustom, key);
		if (obj.isEmpty())return;
		vector<mongo::BSONElement> vec = obj["arr"].Array();
		for (unsigned i = 0; i < vec.size(); i++)
		{
			mongo::BSONElement& elem = vec[i];
			const int csID = elem["id"].Int();
			const int cTime = (unsigned)elem["ct"].Int();
			if (!gm_mgr.isAliveCustom(csID, cTime))continue;
			CUSTOMGIFT::dataPtr data_ptr = Creator<CUSTOMGIFT::DATA>::Create(csID, cTime);
			data_ptr->gTimes = elem["gts"].Int();
			data_ptr->gCD = (unsigned)elem["cd"].Int();
			dataMap[data_ptr->cID] = data_ptr;
		}
	}

	bool playerCustom::_auto_save()
	{
		mongo::BSONObj key = BSON(strPlayerID << Own().ID());
		mongo::BSONArrayBuilder arr;
		for (DATAMAP::iterator it = dataMap.begin(); it != dataMap.end(); ++it)
		{
			CUSTOMGIFT::dataPtr data_ptr = it->second;
			//if (!gm_mgr.isAliveCustom(data_ptr->cID, data_ptr->cTime))continue;
			arr << BSON("id" << data_ptr->cID << "ct" << data_ptr->cTime <<
				"gts" << data_ptr->gTimes << "cd" << data_ptr->gCD);
		}
		mongo::BSONObj obj = BSON(strPlayerID << Own().ID() << "arr" << arr.arr());
		return db_mgr.SaveMongo(DBN::dbPlayerCustom, key, obj);
	}

	int playerCustom::canGetBox(const int csID, const unsigned createTime, const int maxTimes)
	{
		CUSTOMGIFT::dataPtr data_ptr = getData(csID, createTime);
		if (data_ptr->gTimes >= maxTimes)return err_custom_gift_get_max;
		if (Common::gameTime() <= data_ptr->gCD)return err_custom_gift_cd;
		return res_sucess;
	}

	void playerCustom::tickTimes(const int csID, const unsigned createTime, const unsigned aCD, const int num /* = 1 */)
	{
		CUSTOMGIFT::dataPtr data_ptr = getData(csID, createTime);
		data_ptr->gTimes += num;
		data_ptr->gCD = Common::gameTime() + aCD;
		_sign_save();
	}

	int playerCustom::getBoxTimes(const int csID, const unsigned createTime)
	{
		CUSTOMGIFT::dataPtr data_ptr = getData(csID, createTime);
		return data_ptr->gTimes;
	}

	unsigned playerCustom::getBoxCD(const int csID, const unsigned createTime)
	{
		CUSTOMGIFT::dataPtr data_ptr = getData(csID, createTime);
		return data_ptr->gCD;
	}

	void playerCustom::resetTimes()
	{
		for (DATAMAP::iterator it = dataMap.begin(); it != dataMap.end();)
		{
			CUSTOMGIFT::dataPtr data_ptr = it->second;
			++it;
			if (!gm_mgr.isAliveCustom(data_ptr->cID, data_ptr->cTime))
			{
				dataMap.erase(data_ptr->cID);
				continue;
			}
			if (gm_mgr.customNeedReset(data_ptr->cID, data_ptr->cTime))
			{
				data_ptr->gTimes = 0;
				data_ptr->gCD = 0;
			}
		}
		_sign_auto();
	}

	CUSTOMGIFT::dataPtr playerCustom::getData(const int csID, const unsigned create_time)
	{
		DATAMAP::iterator it = dataMap.find(csID);
		CUSTOMGIFT::dataPtr data_ptr;
		if (it == dataMap.end() || it->second->cTime != create_time)
		{
			data_ptr = Creator<CUSTOMGIFT::DATA>::Create(csID, create_time);
			dataMap[csID] = data_ptr;
			_sign_save();//����
		}
		else
		{
			data_ptr = it->second;
		}
		return data_ptr;
	}


}
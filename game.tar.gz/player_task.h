#pragma once

#include "task_record.h"
#include "auto_base.h"

namespace gg
{
	
	class MTaskRecord
		: public Task::Record
	{
		public:
			MTaskRecord(const mongo::BSONElement& obj);
			MTaskRecord(int id, const Task::CheckPtr& ptr, playerDataPtr d);
		protected:
			virtual bool getCheckPtr() const;
	};

	class BTaskRecord
		: public Task::Record
	{
		public:
			BTaskRecord(const mongo::BSONElement& obj);
			BTaskRecord(int id, const Task::CheckPtr& ptr, playerDataPtr d);
		protected:
			virtual bool getCheckPtr() const;
	};

	class playerTask
		: public _auto_player
	{
		public:
			playerTask(playerData* const own);

			virtual void classLoad();
			virtual bool _auto_save();
			virtual void _auto_update();

			void update();
			void updateRedPoint(bool check = false);
			void updateMain(int type, int arg1, int arg2);
			void updateBranch(int type, int arg1, int arg2);

			void openMainTask(int id, bool start_task);
			void openBranchTask(int id, bool start_task);
			void checkUnOpenedTask();

			int getReward(int type, int id);

		private:
			bool getRedPoint();
			void checkAndUpdate();
			int getMainReward(int id);
			int getBranchReward(int id);

		private:
			Task::RecordMgr<MTaskRecord> _main_records;
			Task::RecordMgr<BTaskRecord> _branch_records;

			STDVECTOR(int, TaskIdList);
			TaskIdList _start_main_id_list;
			TaskIdList _start_branch_id_list;
			TaskIdList _end_main_id_list;
			TaskIdList _end_branch_id_list;
			TaskIdList _unopened_main_id_list;
			TaskIdList _unopened_branch_id_list;

			unsigned _version_id;
			bool _red_point;
	};
}

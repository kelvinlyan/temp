#include "gate_game_protocol.h"
#include "heroparty_system.h"
#include <boost/assert.hpp>
#include "commom.h"
#include "chat.h"
#include "ownerland_system.h"
#include "battle_helper.hpp"
#include "task_mgr.h"
#include "despatch_task.h"
#include "game_time.h"
#include "map_war.h"
#include "gamer.h"

namespace gg
{
	static unsigned HeroPartyCloseTime = 0;//������ÿ�ս���ʱ��
	static void saveSystem()
	{
		mongo::BSONObj key = BSON("key" << 1);
		mongo::BSONObj obj = BSON("key" << 1 << "ht" << HeroPartyCloseTime);
		db_mgr.SaveMongo(DBN::dbHeroPartySystem, key, obj);
	}
	static std::vector<int> FlashShopCost;
	int getFlashCost(const unsigned times)
	{
		if (times >= FlashShopCost.size())return FlashShopCost.back();
		return FlashShopCost[times];
	}

// 	static heroPartyPtr FirstPlayer;
// 	static void saveFirst()
// 	{
// 		if (FirstPlayer)
// 		{
// 			mongo::BSONObj key = BSON("key" << 2);
// 			mongo::BSONObj obj = BSON("key" << 2 << "id" << FirstPlayer->iPlayerID);
// 			db_mgr.SaveMongo(DBN::dbHeroPartySystem, key, obj);
// 		}
// 	}

	//npc����
	static mapDataConfigMap NpcsMap;
	static vector<int> NpcsID;

	heroparty_system* const heroparty_system::_Instance = new heroparty_system();

	// ȺӢ����ս�����������Ʊ�
	STDMAP(int, int, ConfigBattleVipMap);
	static ConfigBattleVipMap mapBattleVip;

	void heroparty_system::initData()
	{
		cout << "load hero party..." << endl;

		{
			mongo::BSONObj key = BSON("key" << 1);
			mongo::BSONObj obj = db_mgr.FindOne(DBN::dbHeroPartySystem, key);
			if (obj.isEmpty())
			{
				HeroPartyCloseTime = Common::getNextTime(22);
				saveSystem();
			}
			else
			{
				HeroPartyCloseTime = (unsigned)obj["ht"].Int();
			}
		};//����ʱ��

		//�������loading
		loadAllDB();

		{
			Json::Value costJson = Common::loadJsonFile("./instance/heroparty/flash_cost.json");
			FlashShopCost.clear();
			for (unsigned i = 0; i < costJson.size(); ++i)
			{
				FlashShopCost.push_back(costJson[i].asInt());
			}
			cout << "flash cost json size=" << FlashShopCost.size() << endl;
		};

		{
			FileJsonSeq boxJsonVec = Common::loadFileJsonFromDir("./instance/heroparty_boxes/");
			kHeroPartyBoxRes.clear();
			for (unsigned i = 0; i < boxJsonVec.size(); ++i)
			{
				Json::Value& json = boxJsonVec[i];
				const unsigned index = json["index"].asUInt();
				heroPartyBoxMap& use_map = kHeroPartyBoxRes[index];
				for (unsigned n = 0; n < json["reward"].size(); ++n)
				{
					Json::Value& boxJson = json["reward"][n];
					int iID = boxJson["no"].asInt();
					Json::Value& box_json = boxJson["box"];
					use_map[iID] = actionFormatBox(box_json);
				}
			}
			cout << "box.json size=" << kHeroPartyBoxRes.size() << endl;
		};

		{
			Json::Value shopJson = Common::loadJsonFile("./instance/heroparty/shop.json");
			for (unsigned i = 0; i < shopJson.size(); ++i)
			{
				Json::Value& sg_shopjson = shopJson[i];
				int iID = sg_shopjson["id"].asInt();
				int iPrice = sg_shopjson["price"].asInt();
				int iBuyNum = sg_shopjson["buynum"].asInt();
				unsigned nationID = sg_shopjson["nation"].asUInt();
				if (nationID > Kingdom::nation_invaild_idx)continue;
				unsigned iWeight = sg_shopjson["weight"].asInt();
				unsigned imWeight = sg_shopjson["mweight"].asInt();
				unsigned iwModule = sg_shopjson["wmodule"].asInt();
				const unsigned res_idx = sg_shopjson["index"].asUInt();
				if (res_idx >= 4)continue;
				Json::Value& box_json = sg_shopjson["box"];
				heroPartyShopResPtr heroPartyShopResPtr_ptr = Creator<heroPartyShopRes>::Create();
				heroPartyShopResPtr_ptr->iID = iID;
				heroPartyShopResPtr_ptr->iPrice = iPrice;
				heroPartyShopResPtr_ptr->iBuyNum = iBuyNum;
				heroPartyShopResPtr_ptr->iWeight = iWeight;
				heroPartyShopResPtr_ptr->imWeight = imWeight;
				heroPartyShopResPtr_ptr->iwModule = iwModule;
				heroPartyShopResPtr_ptr->box = actionFormatBox(box_json);
				if (kHeroPartyShop.find(iID) != kHeroPartyShop.end())continue;
				kHeroPartyShop[heroPartyShopResPtr_ptr->iID] = heroPartyShopResPtr_ptr;
				kHeroPartyShopRD[nationID][res_idx].push_back(heroPartyShopResPtr_ptr);
			}
		};

		//vip�����������
		{
			Json::Value actionVip = Common::loadJsonFile("./instance/heroparty/battlevip.json");
			for (unsigned i = 0; i < actionVip.size(); ++i)
			{
				int iVip = actionVip[i]["vip"].asInt();
				int iAction = actionVip[i]["action"].asInt();
				mapBattleVip[iVip] = iAction;
			}
			cout << "battlevip.json size=" << mapBattleVip.size() << endl;
		};

		{
			NpcsMap.clear();
			NpcsID.clear();
			Json::Value npcJson = Common::loadJsonFile("./instance/heroparty/npcs.json");
			for (unsigned i = 0; i < npcJson.size(); i++)
			{
				Json::Value& chapterMap = npcJson[i];

				mapDataCfgPtr mapDatePtr = Creator<mapDataConfig>::Create();

				mapDatePtr->mapID = chapterMap["npcID"].asInt();
				mapDatePtr->background = chapterMap.isMember("background") ? chapterMap["background"].asInt() : 1;
				mapDatePtr->faceID = chapterMap["faceID"].asInt();
				mapDatePtr->mapName = gamer.randomName();
				mapDatePtr->mapLevel = Common::randomBetween(12, 15);// ["mapLevel"].asUInt();
				mapDatePtr->battleValue = chapterMap["battleValue"].asInt();
				for (unsigned nn = 0; nn < chapterMap["army"].size(); ++nn)
				{
					Json::Value& npcJson = chapterMap["army"][nn];
					armyNPC npc;
					npc.npcID = npcJson["npcID"].asInt();
					npc.holdMorale = npcJson["holdMorale"].asBool();
					for (unsigned cn = 0; cn < characterNum; ++cn)
					{
						npc.initAttri[cn] = npcJson["initAttri"][cn].asInt();
					}
					npc.armsType = npcJson["armsType"].asInt();
					for (unsigned cn = 0; cn < armsModulesNum; ++cn)
					{
						npc.armsModule[cn] = npcJson["armsModule"][cn].asDouble();
					}
					npc.npcLevel = npcJson["npcLevel"].asInt();
					npc.npcPos = npcJson["npcPos"].asUInt() % 9;
					npc.battleValue = npcJson["battleValue"].asInt();
					npc.skill_1 = npcJson["skill_1"].asInt();
					npc.skill_2 = npcJson["skill_2"].asInt();
					for (unsigned eq_idx = 0; eq_idx < npcJson["equip"].size(); ++eq_idx)
					{
						npc.equipList.push_back(BattleEquip(npcJson["equip"][eq_idx][0u].asUInt(),
							npcJson["equip"][eq_idx][1u].asInt(),
							npcJson["equip"][eq_idx][2u].asUInt()));
					}
					mapDatePtr->npcList.push_back(npc);
				}
				NpcsMap[mapDatePtr->mapID] = mapDatePtr;
				NpcsID.push_back(mapDatePtr->mapID);
			}
		};


// 		{
// 			mongo::BSONObj key = BSON("key" << 2);
// 			mongo::BSONObj obj = db_mgr.FindOne(DBN::dbHeroPartySystem, key);
// 			if (!obj.isEmpty())
// 			{
// 				FirstPlayer = getHeroData(obj["id"].Int());
// 			}
// 		};
	}

	const static ACTION::BoxList NullBox;
	const ACTION::BoxList& heroparty_system::getHeroPartyBox(int iNo)
	{
		if (iNo < 1)return NullBox;
		const unsigned index = (Common::gameTime() - season_sys.openTime()) / (30 * DAY);
		if (index >= kHeroPartyBoxRes.size())
		{
			heroPartyBoxMap& use_map = kHeroPartyBoxRes.rbegin()->second;
			heroPartyBoxMap::iterator it = use_map.find(iNo);
			if (it == use_map.end())return use_map.rbegin()->second;
			return it->second;
		}
		heroPartyBoxMap& use_map = kHeroPartyBoxRes[index];
		heroPartyBoxMap::iterator it = use_map.find(iNo);
		if (it == use_map.end())return use_map.rbegin()->second;
		return it->second;
	}

	const static unsigned loopRulerNum[] = { 1, 3, 2, 2 };
	typedef std::map<int, heroPartyShopResPtr, less<int> > RandomMap;
	PlayerHeroPartyShopMap heroparty_system::randomShopRes(playerDataPtr player)
	{
		PlayerHeroPartyShopMap res_map;
		const unsigned nation_idx = player->Info().NationIDX();
		const unsigned player_lv = player->LV();
		for (unsigned idx = 0; idx < 4; ++idx)
		{
			const heroPartyShopSeq& rd_vec = kHeroPartyShopRD[nation_idx][idx];
			const unsigned loop_num = loopRulerNum[idx];
			int total_weight = 0;
			RandomMap tmpMap;
			for (unsigned i = 0; i < rd_vec.size(); ++i)
			{
				heroPartyShopResPtr ptr = rd_vec[i];
				ptr->tmpWeight = ptr->iWeight + player_lv * ptr->iwModule;
				if (ptr->tmpWeight < 1)continue;
				if (ptr->tmpWeight > ptr->imWeight)ptr->tmpWeight = ptr->imWeight;
				total_weight += ptr->tmpWeight;
				tmpMap[total_weight] = ptr;
			}
			for (unsigned i = 0; i < loop_num; ++i)
			{
				if (total_weight < 1)break;
				const int rd_num = Common::randomBetween(0, total_weight - 1);
				std::pair<RandomMap::iterator, bool> pib = tmpMap.insert(RandomMap::value_type(rd_num, heroPartyShopResPtr()));
				RandomMap::iterator it = pib.first;
				if (pib.second)//����ɹ�
				{
					tmpMap.erase(it++);
				}
				else//����ʧ��
				{
					++it;
				}
				heroPartyShopResPtr ptr = it->second;
				tmpMap.erase(it++);
				total_weight -= ptr->tmpWeight;
				res_map[ptr->iID] = ptr->iBuyNum;
				if ((i + 1) >= loop_num)break;
				for (RandomMap::iterator alter_it = it; alter_it != tmpMap.end();)
				{
					heroPartyShopResPtr alter_ptr = alter_it->second;
					const unsigned old_key = alter_it->first;
					tmpMap.erase(alter_it++);
					tmpMap[old_key - ptr->tmpWeight] = alter_ptr;
				}
			}
		}
		return res_map;
	}

	const heroPartyShopResPtr heroparty_system::getShopData(const int iID)
	{
		heroPartyShopMap::iterator it = kHeroPartyShop.find(iID);
		if (it == kHeroPartyShop.end())return heroPartyShopResPtr();
		return it->second;
	}

	void heroparty_system::get_hero_base(net::Msg& m, Json::Value& r)
	{
		sendHeroPartyData(m.playerID);
	}

	void heroparty_system::get_chart(net::Msg& m, Json::Value& r)
	{
		sendChart(m.playerID);
	}

	void heroparty_system::get_fight_num_cost(net::Msg& m, Json::Value& r)
	{
		playerDataPtr player = player_mgr.getPlayer(m.playerID);
		if (!player)Return(r, err_illedge);
		heroPartyPtr heroPartyPtr_ptr = getHeroData(player->ID());
		if (!heroPartyPtr_ptr)Return(r, err_illedge);

		int iCost = (heroPartyPtr_ptr->iAddFightingNum + 1) * ONE_ADD_FIGHT_COST_CRASH;
		iCost = iCost > MAX_ADD_FIGHT_COST_CRASH ? MAX_ADD_FIGHT_COST_CRASH : iCost;

		r[strMsg][1u] = iCost;
		Return(r, res_sucess);
	}

	void heroparty_system::set_fight_num(net::Msg& m, Json::Value& r)
	{
		playerDataPtr player = player_mgr.getPlayer(m.playerID);
		if (!player)Return(r, err_illedge);
		heroPartyPtr heroPartyPtr_ptr = getHeroData(player->ID());
		if (!heroPartyPtr_ptr)Return(r, err_illedge);

		unsigned int uiVip = player->Info().VipLv();
		if (mapBattleVip.find(uiVip) == mapBattleVip.end()) Return(r, err_illedge);
		int iNum = mapBattleVip[uiVip];
		if ((heroPartyPtr_ptr->iAddFightingNum + 1) > iNum)Return(r, err_vip_lv_too_low);

		int iCost = (heroPartyPtr_ptr->iAddFightingNum + 1) * ONE_ADD_FIGHT_COST_CRASH;
		iCost = iCost > MAX_ADD_FIGHT_COST_CRASH ? MAX_ADD_FIGHT_COST_CRASH : iCost;

		if (player->Res().getCash() < iCost)Return(r, err_cash_not_enough);

		player->Res().alterCash(iCost * (-1));
		heroPartyPtr_ptr->iAddFightingNum++;
		saveOneDB(heroPartyPtr_ptr);
		sendHeroPartyData(player->ID());
		r[strMsg][1u] = iCost;
		Return(r, res_sucess);
	}

	void heroparty_system::set_box(net::Msg& m, Json::Value& r)
	{
		set_box(m.playerID);
	}

	void heroparty_system::get_shop_data(net::Msg& m, Json::Value& r)
	{
		sendShop(m.playerID);
	}

	void heroparty_system::flash_shop(net::Msg& m, Json::Value& r)
	{
		playerDataPtr player = player_mgr.getPlayer(m.playerID);
		if (!player)Return(r, err_illedge);

		heroPartyPtr heroPartyPtr_ptr = getHeroData(m.playerID);
		if (!heroPartyPtr_ptr)Return(r, err_illedge);
		const int cost = getFlashCost(heroPartyPtr_ptr->iFalshShopNum);
		if (player->Res().getCash() < cost)Return(r, err_cash_not_enough);

		player->Res().alterCash(-cost);
		resetShopData(player, false);
		sendShop(player->ID());
		TaskMgr::update(player, Task::HeroPartyShopFlushTimes, 1);
		Return(r, res_sucess);
	}

	void heroparty_system::buy_shop(net::Msg& m, Json::Value& r)
	{
		playerDataPtr player = player_mgr.getPlayer(m.playerID);
		if (!player)Return(r, err_illedge);
		heroPartyPtr heroPartyPtr_ptr = getHeroData(m.playerID);
		if (!heroPartyPtr_ptr)Return(r, err_illedge);
		ReadJsonArray;
		const int goodsID = js_msg[0u].asInt();
		heroPartyShopResPtr heroPartyShopResPtr_ptr = heroparty_sys.getShopData(goodsID);
		if (!heroPartyShopResPtr_ptr || heroPartyPtr_ptr->kHisShop.find(goodsID) == heroPartyPtr_ptr->kHisShop.end())Return(r, err_illedge);
		if (heroPartyPtr_ptr->kHisShop[goodsID] <= 0)Return(r, err_illedge);
		if (player->Res().getHeroPartyMoney() < heroPartyShopResPtr_ptr->iPrice)Return(r, err_heroparty_money_not_enough);
		const int res = actionDoBox(player, heroPartyShopResPtr_ptr->box);
		Json::Value& res_json = r[strMsg][2u] = actionRes();
		if (res_sucess == res)
		{
			player->Res().alterHeroPartyMoney(heroPartyShopResPtr_ptr->iPrice * (-1));
			--(heroPartyPtr_ptr->kHisShop[goodsID]);
			saveOneDB(heroPartyPtr_ptr);
			sendShop(m.playerID);
			TaskMgr::update(player, Task::HeroPartyShopTimes, 1);
			Log(DBLOG::strLogHeroParty, player, 2, goodsID, "", "", "", "", "", "", res_json.toIndentString());
		}
		r[strMsg][1u] = actionError();
		Return(r, res_sucess);
	}

	void heroparty_system::clear_fight_cd(net::Msg& m, Json::Value& r)
	{
		playerDataPtr player = player_mgr.getPlayer(m.playerID);
		if (!player)Return(r, err_illedge);
		heroPartyPtr heroPartyPtr_ptr = getHeroData(player->ID());
		if (!heroPartyPtr_ptr)Return(r, err_illedge);
		const unsigned now = Common::gameTime();
		if (now >= heroPartyPtr_ptr->uiFightCD)Return(r, err_illedge);
		int cost = (heroPartyPtr_ptr->uiFightCD - now) / MINUTE + ((heroPartyPtr_ptr->uiFightCD - now) % MINUTE ? 1 : 0);
		if (player->Res().getCash() < cost)Return(r, err_cash_not_enough);
		player->Res().alterCash(-cost);
		heroPartyPtr_ptr->uiFightCD = 0;
		saveOneDB(heroPartyPtr_ptr);
		sendHeroPartyData(player->ID());
		Return(r, res_sucess);
	}

	void heroparty_system::fight_npc_leader(net::Msg& m, Json::Value& r)
	{
		playerDataPtr player = player_mgr.getPlayer(m.playerID);
		if (!player)Return(r, err_illedge);
		heroPartyPtr heroPartyPtr_ptr = getHeroData(player->ID());
		if (!heroPartyPtr_ptr || heroPartyPtr_ptr->beenLeader)Return(r, err_illedge);
		ReadJsonArray;
		const int npcID = js_msg[0u].asInt();
		mapDataConfigMap::iterator it = NpcsMap.find(npcID);
		if (it == NpcsMap.end())Return(r, err_illedge);
		mapDataCfgPtr config = it->second;

		//ģ��ս��
		BattleReport reportData;
		sBattlePtr atk = BattleHelp::WarPlayer(player);
		sBattlePtr def = map_sys.npcSide(config);
		O2ORes resultB = reportData.One2One(atk, def, typeBattle::hero_party);
		reportData.addNotice(player->ID());//����������
		Json::Value rep_json = config->mapName;
		reportData.addReportdeclare("bg", config->background);

		Json::Value me_json;
		BattleHelp::AddManExp(player, 0, me_json);
		reportData.addReportdeclare("me", me_json);

		Json::Value playerJson;
		playerJson.append(player->LV());
		playerJson.append(player->Info().EXP());
		playerJson.append(player->LV());
		playerJson.append(player->Info().EXP());
		playerJson.append(0);
		playerJson.append(player->Info().isMaxLevel());
		reportData.addReportdeclare("plv", playerJson);

		reportData.Done(typeBattle::hero_party);
		
		if (resultB.res == resBattle::atk_win)
		{
			heroPartyPtr_ptr->beenLeader = true;
			saveOneDB(heroPartyPtr_ptr);
			sendHeroPartyData(player->ID());
		}

		r[strMsg][2u] = heroPartyPtr_ptr->iHeroNo;
		r[strMsg][1u] = (resultB.res == resBattle::atk_win ? 1 : 0);
		Return(r, res_sucess);
	}


	void heroparty_system::first_player(net::Msg& m, Json::Value& r)
	{
		//r[strMsg][1u] = FirstPlayer ? FirstPlayer->sPlayerName : "";
		PlayerHeroParty::iterator it = kHeroPartyHeroNo.find(1);
		heroPartyPtr ptr = it == kHeroPartyHeroNo.end() ? heroPartyPtr() : it->second;
		r[strMsg][1u] = ptr ? ptr->sPlayerName : "";
		Return(r, res_sucess);
	}

	void heroparty_system::heroparty_challenge(net::Msg& m, Json::Value& r)
	{
		ReadJsonArray;
		int iTargetPlayerID = js_msg[0u].asInt();// ����ս��ID
		int iTargetChartNum = js_msg[1u].asInt();// ����ս�ߵ�ʱ����
		heroparty_challenge_impl(m.playerID, iTargetPlayerID, iTargetChartNum);
	}

	void heroparty_system::get_fight_data(net::Msg& m, Json::Value& r)
	{
		sendFightData(m.playerID, false);
	}

	void heroparty_system::get_fight_list(net::Msg& m, Json::Value& r)
	{
		ReadJsonArray;
		bool isRobot = js_msg[0u].asBool();
		sendFightList(m.playerID, isRobot);
	}

	void heroparty_system::loadAllDB()
	{
		kHeroPartyPlayerID.clear();
		kHeroPartyHeroNo.clear();

		objCollection obj = db_mgr.Query(DBN::dbPlayerHeroParty);
		for (objCollection::const_iterator itr = obj.begin(); itr != obj.end(); ++itr)
		{
			mongo::BSONObj kFind = itr->copy();
			heroPartyPtr heroPartyPtr_ptr = Creator<heroParty>::Create();
			heroPartyPtr_ptr->iPlayerID = kFind["id"].Int();
			if (!kFind["reportid"].eoo()) { heroPartyPtr_ptr->iReportID = kFind["reportid"].Int(); }
			else { heroPartyPtr_ptr->iReportID = 0; }
			heroPartyPtr_ptr->sPlayerName = kFind["name"].String();
			heroPartyPtr_ptr->iHeroNo = kFind["no"].Int();
			heroPartyPtr_ptr->uiPlayerLV = (unsigned)kFind["lv"].Int();
			heroPartyPtr_ptr->iPlayerFace = kFind["face"].Int();
			heroPartyPtr_ptr->playerNation = (Kingdom::NATION)kFind["nation"].Int();
			heroPartyPtr_ptr->iFighting = kFind["fight"].Int();
			if (!kFind["fightcd"].eoo()) { heroPartyPtr_ptr->uiFightCD = kFind["fightcd"].Int(); }
			else { heroPartyPtr_ptr->uiFightCD = 0; }
			heroPartyPtr_ptr->iFightingNum = kFind["fightnum"].Int();
			if (!kFind["addfightnum"].eoo()) { heroPartyPtr_ptr->iAddFightingNum = kFind["addfightnum"].Int(); }
			else { heroPartyPtr_ptr->iAddFightingNum = 0; }
			if (!kFind["box"].eoo()) { heroPartyPtr_ptr->boxTime = (unsigned)kFind["box"].Int(); }
			else { heroPartyPtr_ptr->boxTime = 0; }
			if (!kFind["boxno"].eoo()) { heroPartyPtr_ptr->boxHeroNo = kFind["boxno"].Int(); }
			else { heroPartyPtr_ptr->boxHeroNo = 0; }
			if (!kFind["flashshopnum"].eoo()) { heroPartyPtr_ptr->iFalshShopNum = kFind["flashshopnum"].Int(); }
			else { heroPartyPtr_ptr->iFalshShopNum = 0; }
			if (!kFind["beenleader"].eoo()) { heroPartyPtr_ptr->beenLeader = kFind["beenleader"].Bool(); }
			else { heroPartyPtr_ptr->beenLeader = false; }
			for (int j = 0; j < (!kFind["hisshop"].eoo() ? (int)kFind["hisshop"].Array().size() : 0); j++)
			{
				heroPartyPtr_ptr->kHisShop[kFind["hisshop"].Array()[j]["id"].Int()] = kFind["hisshop"].Array()[j]["num"].Int();
			}
			for (int j = 0; j < (!kFind["report"].eoo() ? (int)kFind["report"].Array().size() : 0); j++)
			{
				heroPartyReportPtr heroPartyReportPtr_ptr = Creator<heroPartyReport>::Create();
				int iID = kFind["report"].Array()[j]["ID"].Int();
				heroPartyReportPtr_ptr->iPlayerID = kFind["report"].Array()[j]["iPlayerID"].Int();
				heroPartyReportPtr_ptr->iLv = kFind["report"].Array()[j]["iLv"].Int();
				heroPartyReportPtr_ptr->iWin = kFind["report"].Array()[j]["iWin"].Int();
				heroPartyReportPtr_ptr->sPlayerName = kFind["report"].Array()[j]["sPlayerName"].String();
				heroPartyReportPtr_ptr->uiTime = (unsigned int)kFind["report"].Array()[j]["uiTime"].Int();
				heroPartyReportPtr_ptr->playerNation = (Kingdom::NATION)kFind["report"].Array()[j]["playerNation"].Int();
				heroPartyReportPtr_ptr->iChart = kFind["report"].Array()[j]["iChart"].Int();
				heroPartyReportPtr_ptr->iRevenge = kFind["report"].Array()[j]["iRevenge"].Int();
				if (!(kFind["report"].Array()[j])["fight"].eoo()) { heroPartyReportPtr_ptr->sPath = kFind["report"].Array()[j]["fight"].String(); }
				else { heroPartyReportPtr_ptr->sPath = ""; }
				heroPartyPtr_ptr->kReport[iID] = heroPartyReportPtr_ptr;
			}

			kHeroPartyPlayerID[heroPartyPtr_ptr->iPlayerID] = heroPartyPtr_ptr;
			kHeroPartyHeroNo[heroPartyPtr_ptr->iHeroNo] = heroPartyPtr_ptr;
		}

		Timer::AddEventTickTime(boostBind(heroparty_system::time22ClockTick, this, _1), Inter::event_heroparty_timer22, HeroPartyCloseTime);
		Common::createDirectories(strRpDirRoot + strRpHeroParty);
	}

	heroPartyPtr heroparty_system::getHeroData(const int playerID)
	{
		heroPartyPtr heroPartyPtr_ptr = heroPartyPtr();
		PlayerHeroParty::iterator it = kHeroPartyPlayerID.find(playerID);
		if (it != kHeroPartyPlayerID.end()) 
		{ 
			heroPartyPtr_ptr = it->second;
			if (HeroPartyCloseTime > heroPartyPtr_ptr->boxTime)
			{
				heroPartyPtr_ptr->boxHeroNo = heroPartyPtr_ptr->iHeroNo;
				playerDataPtr d = player_mgr.getPlayer(playerID);
				heroPartyPtr_ptr->boxTime = HeroPartyCloseTime;
				saveOneDB(heroPartyPtr_ptr);

				TaskMgr::update(d, Task::HeroPartyRank, heroPartyPtr_ptr->boxHeroNo);
			}
		}
		return heroPartyPtr_ptr;
	}

	void heroparty_system::saveOneDB(heroPartyPtr pkHeroParty)
	{
		mongo::BSONObj key = BSON(strPlayerID << pkHeroParty->iPlayerID);
		mongo::BSONObjBuilder obj;
		obj.append(strPlayerID, pkHeroParty->iPlayerID);
		obj.append("id", pkHeroParty->iPlayerID);
		obj.append("reportid", pkHeroParty->iReportID);
		obj.append("name", pkHeroParty->sPlayerName);
		obj.append("no", pkHeroParty->iHeroNo);
		obj.append("lv", pkHeroParty->uiPlayerLV);
		obj.append("face", pkHeroParty->iPlayerFace);
		obj.append("nation", pkHeroParty->playerNation);
		obj.append("fight", pkHeroParty->iFighting);
		obj.append("fightcd", pkHeroParty->uiFightCD);
		obj.append("fightnum", pkHeroParty->iFightingNum);
		obj.append("addfightnum", pkHeroParty->iAddFightingNum);
		obj.append("box", pkHeroParty->boxTime);
		obj.append("boxno", pkHeroParty->boxHeroNo);
		obj.append("flashshopnum", pkHeroParty->iFalshShopNum);
		obj.append("beenleader", pkHeroParty->beenLeader);

		mongo::BSONArrayBuilder resObj;
		for (PlayerHeroPartyShopMap::iterator itr = pkHeroParty->kHisShop.begin(); itr != pkHeroParty->kHisShop.end(); ++itr)
		{
			mongo::BSONObjBuilder resTmp;
			resTmp.append("id", itr->first);
			resTmp.append("num", itr->second);
			resObj.append(resTmp.obj());
		}
		obj.appendArray("hisshop", resObj.arr());

		int iCount = 0;
		mongo::BSONArrayBuilder reportObj;
		for (heroPartyReportList::reverse_iterator itr = pkHeroParty->kReport.rbegin(); itr != pkHeroParty->kReport.rend(); ++itr)
		{
			heroPartyReportPtr heroPartyReportPtr_ptr = itr->second;
			mongo::BSONObjBuilder resTmp;
			resTmp.append("ID", itr->first);
			resTmp.append("iPlayerID", heroPartyReportPtr_ptr->iPlayerID);
			resTmp.append("iLv", heroPartyReportPtr_ptr->iLv);
			resTmp.append("iWin", heroPartyReportPtr_ptr->iWin);
			resTmp.append("sPlayerName", heroPartyReportPtr_ptr->sPlayerName);
			resTmp.append("uiTime", heroPartyReportPtr_ptr->uiTime);
			resTmp.append("playerNation", heroPartyReportPtr_ptr->playerNation);
			resTmp.append("iChart", heroPartyReportPtr_ptr->iChart);
			resTmp.append("iRevenge", heroPartyReportPtr_ptr->iRevenge);
			resTmp.append("fight", heroPartyReportPtr_ptr->sPath);
			reportObj.append(resTmp.obj());
			iCount++;
			if (iCount >= MAX_HEROPARTYREPORT_NUM) { break; }
		}
		obj.appendArray("report", reportObj.arr());

		db_mgr.SaveMongo(DBN::dbPlayerHeroParty, key, obj.obj());
	}

	void heroparty_system::sendHeroPartyData(const int playerID)
	{
		playerDataPtr player = player_mgr.getOnlinePlayer(playerID);
		if (!player) { return; }

		heroPartyPtr heroPartyPtr_ptr = getHeroData(playerID);
		
		qValue list_json_me(qJson::qj_array);
		list_json_me.append(bool(heroPartyPtr_ptr));
		list_json_me.append(heroPartyPtr_ptr ? heroPartyPtr_ptr->iHeroNo : 0);
		list_json_me.append(heroPartyPtr_ptr ? (heroPartyPtr_ptr->iFightingNum - heroPartyPtr_ptr->iAddFightingNum) : 0);
		list_json_me.append(MAX_FIGHTING_NUM);
		list_json_me.append(heroPartyPtr_ptr ? heroPartyPtr_ptr->uiFightCD : 0);
		int iCost = (heroPartyPtr_ptr ? (heroPartyPtr_ptr->iAddFightingNum + 1) : 0) * ONE_ADD_FIGHT_COST_CRASH;
		iCost = iCost > MAX_ADD_FIGHT_COST_CRASH ? MAX_ADD_FIGHT_COST_CRASH : iCost;
		list_json_me.append(iCost);

		list_json_me.append(heroPartyPtr_ptr ? (heroPartyPtr_ptr->boxHeroNo > 0) : false);
		list_json_me.append(HeroPartyCloseTime + 5);
		list_json_me.append(heroPartyPtr_ptr ? heroPartyPtr_ptr->boxHeroNo : 0);
		list_json_me.append(heroPartyPtr_ptr ? heroPartyPtr_ptr->beenLeader : false);

		qValue list_json_send(qJson::qj_array);
		list_json_send.append(res_sucess);
		list_json_send.append(list_json_me);

		player->sendToClientFillMsg(gate_client::player_hero_party_resp, list_json_send);
	}

	void heroparty_system::sendChart(int iPlayerID)
	{
		playerDataPtr ptrPlayer = player_mgr.getPlayer(iPlayerID);
		if (!ptrPlayer) { return; }
		heroPartyPtr heroPartyPtr_ptr = getHeroData(iPlayerID);
		if (!heroPartyPtr_ptr)return;

		int iCount = 0;
		qValue list_json_me(qJson::qj_array);
		for (PlayerHeroParty::const_iterator itr = kHeroPartyHeroNo.begin(); itr != kHeroPartyHeroNo.end(); ++itr)
		{
			iCount++;
			qValue jsonChart(qJson::qj_array);
			heroPartyPtr_ptr = itr->second;
			jsonChart.append(heroPartyPtr_ptr->iHeroNo);
			jsonChart.append(heroPartyPtr_ptr->iPlayerFace);
			jsonChart.append(heroPartyPtr_ptr->uiPlayerLV);
			jsonChart.append(heroPartyPtr_ptr->sPlayerName);
			jsonChart.append(heroPartyPtr_ptr->playerNation);
			jsonChart.append(heroPartyPtr_ptr->iFighting);
			list_json_me.append(jsonChart);
			if (iCount >= MAX_CHART_NUM) { break; }
		}

		qValue list_json_send(qJson::qj_array);
		list_json_send.append(res_sucess);
		list_json_send.append(heroPartyPtr_ptr->iHeroNo);
		list_json_send.append(list_json_me);

		qValue json(qJson::qj_object);
		json.addMember(strMsg, list_json_send);

		ptrPlayer->sendToClient(gate_client::player_hero_party_get_chart_resp, json);
	}

	vector<heroPartyPtr> heroparty_system::sendChart(Kingdom::NATION nation, int num)
	{
		vector<heroPartyPtr> vectorHeroParty;

		int iCount = 0;
		for (PlayerHeroParty::const_iterator itr = kHeroPartyHeroNo.begin(); itr != kHeroPartyHeroNo.end(); ++itr)
		{
			if (itr->second->playerNation == nation)
			{
				vectorHeroParty.push_back(itr->second);
				iCount++;
				if (iCount >= num) { break; }
			}
		}

		return vectorHeroParty;
	}

	int heroparty_system::heropartyNationPlayerNum(Kingdom::NATION nation)
	{
		int iCount = 0;
		int num = 0;
		for (PlayerHeroParty::const_iterator itr = kHeroPartyHeroNo.begin(); itr != kHeroPartyHeroNo.end(); ++itr)
		{
			if (itr->second->playerNation == nation) num = num + 1;
			iCount++;
			if (iCount >= MAX_NATION_CHART_NUM) { break; }
		}
		return num;
	}

	void heroparty_system::sendShop(const int playerID)
	{
		playerDataPtr player = player_mgr.getOnlinePlayer(playerID);
		if (!player) { return; }
		heroPartyPtr heroPartyPtr_ptr = getHeroData(playerID);
		if (!heroPartyPtr_ptr)return;

		qValue list_json_me(qJson::qj_array);
		for (PlayerHeroPartyShopMap::const_iterator itr = heroPartyPtr_ptr->kHisShop.begin(); itr != heroPartyPtr_ptr->kHisShop.end(); ++itr)
		{
			const heroPartyShopResPtr heroPartyShopResPtr_ptr = heroparty_sys.getShopData(itr->first);
			if (!heroPartyShopResPtr_ptr) { continue; }
			qValue jsonItem(qJson::qj_array);
			jsonItem.append(itr->first);
			jsonItem.append(itr->second);
			jsonItem.append(heroPartyShopResPtr_ptr->iPrice);
			list_json_me.append(jsonItem);
		}

		qValue list_json_send(qJson::qj_array);
		list_json_send.append(res_sucess);
		list_json_send.append(getFlashCost(heroPartyPtr_ptr->iFalshShopNum));
		list_json_send.append(list_json_me);

		qValue json(qJson::qj_object);
		json.addMember(strMsg, list_json_send);

		player->sendToClient(gate_client::player_hero_party_shop_base_data_resp, json);
	}

	void heroparty_system::sendFightData(int iPlayerID, bool bLast)
	{
		// 2.msg: [ �����, ��ʼ�������� 1/����һ������ 0, [ [���ID,�ȼ�,ʤ��ʧ��,�������,ս��ʱ��,����,�������������½�,�ܷ񱨳�,ս����ַ], [���ID,�ȼ�,ʤ��ʧ��,�������,ս��ʱ��,����,�������������½�,�ܷ񱨳�,ս����ַ], ........................... ], ]
		playerDataPtr ptrPlayer = player_mgr.getPlayer(iPlayerID);
		if (!ptrPlayer) { return; }
		heroPartyPtr heroPartyPtr_ptr = getHeroData(iPlayerID);
		if (!heroPartyPtr_ptr)return;

		int iCount = 0;
		qValue list_json_me(qJson::qj_array);
		for (heroPartyReportList::reverse_iterator itr = heroPartyPtr_ptr->kReport.rbegin(); itr != heroPartyPtr_ptr->kReport.rend(); ++itr)
		{
			qValue jsonFight(qJson::qj_array);
			heroPartyReportPtr heroPartyReportPtr_ptr = itr->second;
			jsonFight.append(heroPartyReportPtr_ptr->iPlayerID);
			jsonFight.append(heroPartyReportPtr_ptr->iLv);
			jsonFight.append(heroPartyReportPtr_ptr->iWin);
			jsonFight.append(heroPartyReportPtr_ptr->sPlayerName);
			jsonFight.append(heroPartyReportPtr_ptr->uiTime);
			jsonFight.append(heroPartyReportPtr_ptr->playerNation);
			jsonFight.append(heroPartyReportPtr_ptr->iChart);
			jsonFight.append(heroPartyReportPtr_ptr->iRevenge);
			jsonFight.append(heroPartyReportPtr_ptr->sPath);
			list_json_me.append(jsonFight);
			iCount++;
			if (bLast == true) { break; }
			if (iCount >= MAX_HEROPARTYREPORT_NUM) { break; }
		}

		qValue list_json_send(qJson::qj_array);
		list_json_send.append(res_sucess);
		list_json_send.append(bLast == true ? 0 : 1);
		list_json_send.append(list_json_me);

		qValue json(qJson::qj_object);
		json.addMember(strMsg, list_json_send);

		ptrPlayer->sendToClient(gate_client::player_hero_party_fight_data_resp, json);
	}

	void heroparty_system::sendFightList(int iPlayerID, const bool isRobot /* = false */)
	{
		playerDataPtr ptrPlayer = player_mgr.getPlayer(iPlayerID);
		if (!ptrPlayer) { return; }
		heroPartyPtr heroPartyPtr_ptr = getHeroData(iPlayerID);
		if (!heroPartyPtr_ptr)return;

		int iCount = 0;
		int iHeroNo = heroPartyPtr_ptr->iHeroNo;
		while (iHeroNo > 0) { iHeroNo = iHeroNo / 10; iCount++; }//λ��

		if (iCount <= 0 || heroPartyPtr_ptr->iHeroNo <= 0)
		{
			cout << "[ERROR]" << "HEROPARTY chart is error!!!!!!!!!!!!!" << endl;
			return;
		}

		qValue list_json_me(qJson::qj_array);
		if (isRobot)
		{
			unsigned robot_idx = 0;
			random_shuffle(NpcsID.begin(), NpcsID.end());
			for (int i = 1; i <= MAX_FIGHT_LIST_NUM; i++)
			{
				if (robot_idx >= NpcsID.size())continue;
				mapDataCfgPtr npc = NpcsMap[NpcsID[robot_idx]];
				++robot_idx;
				qValue jsonPlayer(qJson::qj_array);
				jsonPlayer.append(npc->mapID);
				jsonPlayer.append(Common::randomBetween(0, 2));
				jsonPlayer.append(npc->mapName);
				jsonPlayer.append(npc->mapLevel);
				jsonPlayer.append(npc->battleValue);
				jsonPlayer.append(heroPartyPtr_ptr->iHeroNo + i);
				jsonPlayer.append(npc->faceID);
				list_json_me.append(jsonPlayer);
			}
		}
		else
		{
			if (iCount <= 2)
			{
				int i = heroPartyPtr_ptr->iHeroNo <= MAX_FIGHT_LIST_NUM ? MAX_FIGHT_LIST_NUM : heroPartyPtr_ptr->iHeroNo - 1;
				for (int iCount = MAX_FIGHT_LIST_NUM; iCount > 0; --i, --iCount)
				{
					qValue jsonPlayer(qJson::qj_array);
					if (kHeroPartyHeroNo.find(i) == kHeroPartyHeroNo.end()) { continue; }
					heroPartyPtr _ptr = kHeroPartyHeroNo[i];
					jsonPlayer.append(_ptr->iPlayerID);
					jsonPlayer.append(_ptr->playerNation);
					jsonPlayer.append(_ptr->sPlayerName);
					jsonPlayer.append(_ptr->uiPlayerLV);
					jsonPlayer.append(_ptr->iFighting);
					jsonPlayer.append(_ptr->iHeroNo);
					jsonPlayer.append(_ptr->iPlayerFace);
					list_json_me.append(jsonPlayer);
				}
			}
			else
			{
				for (int i = 1; i <= MAX_FIGHT_LIST_NUM; i++)
				{
					qValue jsonPlayer(qJson::qj_array);
					iHeroNo = heroPartyPtr_ptr->iHeroNo - i * (heroPartyPtr_ptr->iHeroNo / 100 + 1);
					if (kHeroPartyHeroNo.find(iHeroNo) == kHeroPartyHeroNo.end()) { continue; }
					heroPartyPtr _ptr = kHeroPartyHeroNo[iHeroNo];
					jsonPlayer.append(_ptr->iPlayerID);
					jsonPlayer.append(_ptr->playerNation);
					jsonPlayer.append(_ptr->sPlayerName);
					jsonPlayer.append(_ptr->uiPlayerLV);
					jsonPlayer.append(_ptr->iFighting);
					jsonPlayer.append(_ptr->iHeroNo);
					jsonPlayer.append(_ptr->iPlayerFace);
					list_json_me.append(jsonPlayer);
				}
			}
		}

		qValue list_json_send(qJson::qj_array);
		list_json_send.append(res_sucess);
		list_json_send.append(list_json_me);

		qValue json(qJson::qj_object);
		json.addMember(strMsg, list_json_send);

		ptrPlayer->sendToClient(gate_client::player_hero_party_fight_list_resp, json);
	}

	int heroparty_system::getRankNo_(int iPlayerID)
	{
		heroPartyPtr heroPartyPtr_ptr = getHeroData(iPlayerID);
		if (!heroPartyPtr_ptr)return -1;
		return heroPartyPtr_ptr->iHeroNo;
	}

	void heroparty_system::openHeroParty(int iPlayerID)
	{
		playerDataPtr ptrPlayer = player_mgr.getPlayer(iPlayerID);
		if (!ptrPlayer) { return; }

		bool bUpdate = false;
		heroPartyPtr heroPartyPtr_ptr = getHeroData(iPlayerID);
// 		const Kingdom::NATION na = ptrPlayer->Info().Nation();
// 		if (!heroPartyPtr_ptr && na > Kingdom::null && na < Kingdom::nation_num)
		if (!heroPartyPtr_ptr && ptrPlayer->LV() >= 12)
		{
			heroPartyPtr_ptr = Creator<heroParty>::Create();
			heroPartyPtr_ptr->iPlayerID = ptrPlayer->ID();
			heroPartyPtr_ptr->iReportID = 0;
			heroPartyPtr_ptr->sPlayerName = ptrPlayer->Name();
			heroPartyPtr_ptr->iHeroNo = kHeroPartyHeroNo.size() + 1;
			heroPartyPtr_ptr->uiPlayerLV = ptrPlayer->LV();
			heroPartyPtr_ptr->iPlayerFace = ptrPlayer->Info().Face();
			heroPartyPtr_ptr->playerNation = ptrPlayer->Info().Nation();
			heroPartyPtr_ptr->iFighting = ptrPlayer->WarFM().currentBV();
			heroPartyPtr_ptr->uiFightCD = 0;
			heroPartyPtr_ptr->iFightingNum = 0;
			heroPartyPtr_ptr->iAddFightingNum = 0;
			heroPartyPtr_ptr->boxTime = HeroPartyCloseTime;
			heroPartyPtr_ptr->boxHeroNo = 0;
			heroPartyPtr_ptr->iFalshShopNum = 0;
			heroPartyPtr_ptr->beenLeader = false;

			heroPartyPtr_ptr->kHisShop = randomShopRes(ptrPlayer);
			heroPartyPtr_ptr->kReport.clear();
			kHeroPartyPlayerID[heroPartyPtr_ptr->iPlayerID] = heroPartyPtr_ptr;
			kHeroPartyHeroNo[heroPartyPtr_ptr->iHeroNo] = heroPartyPtr_ptr;
			bUpdate = true;
		}
		if (heroPartyPtr_ptr)
		{
			if (heroPartyPtr_ptr->uiPlayerLV != ptrPlayer->LV())
			{
				heroPartyPtr_ptr->uiPlayerLV = ptrPlayer->LV();
				bUpdate = true;
			}
			if (heroPartyPtr_ptr->iFighting != ptrPlayer->WarFM().currentBV())
			{
				heroPartyPtr_ptr->iFighting = ptrPlayer->WarFM().currentBV();
				bUpdate = true;
			}
			if (heroPartyPtr_ptr->sPlayerName != ptrPlayer->Name())
			{
				heroPartyPtr_ptr->sPlayerName = ptrPlayer->Name();
				bUpdate = true;
			}
			if (heroPartyPtr_ptr->iPlayerFace != ptrPlayer->Info().Face())
			{
				heroPartyPtr_ptr->iPlayerFace = ptrPlayer->Info().Face();
				bUpdate = true;
			}
			if (heroPartyPtr_ptr->playerNation != ptrPlayer->Info().Nation())
			{
				heroPartyPtr_ptr->playerNation = ptrPlayer->Info().Nation();
				bUpdate = true;
			}
		}
		if (bUpdate && heroPartyPtr_ptr)
		{
			ptrPlayer->Info().motifyNo_(heroPartyPtr_ptr->iHeroNo);
			saveOneDB(heroPartyPtr_ptr);
		}

		sendHeroPartyData(iPlayerID);
	}

	void heroparty_system::time22ClockTick(const structTimer& timerData)
	{
		// ���ý�����Ϣ
		for (PlayerHeroParty::iterator itr = kHeroPartyHeroNo.begin(); itr != kHeroPartyHeroNo.end(); ++itr)
		{
			heroPartyPtr heroPartyPtr_ptr = itr->second;

			if (itr->first < 301)
			{
				if (itr->first < 6)
				{
					playerDataPtr c_player = player_mgr.getPlayer(heroPartyPtr_ptr->iPlayerID);
					if (c_player)
					{
						qValue jsonTMP(qJson::qj_array);
						jsonTMP.append(chat_sys.ChatPackageQ(c_player));
						jsonTMP.append(heroPartyPtr_ptr->iHeroNo);
						chat_sys.despatchAll(gg::CHAT::server_heroparty_chart, jsonTMP);
					}
// 					if (itr->first == 1)
// 					{
// 						FirstPlayer = heroPartyPtr_ptr;
// 					}
				}
				Log(DBLOG::strLogHeroParty, 3, heroPartyPtr_ptr->iPlayerID, heroPartyPtr_ptr->sPlayerName, 
					heroPartyPtr_ptr->uiPlayerLV, heroPartyPtr_ptr->playerNation, itr->first);
				continue;
			}
			break;
		}
		static Json::Value nullValueJson = Json::objectValue;
		chat_sys.despatchAll(gg::CHAT::server_heroparty_restart, nullValueJson);

// 		if (FirstPlayer)
// 		{
//  			qValue json(qJson::qj_array);
//  			json.append(res_sucess).append(FirstPlayer->sPlayerName);
//  			qValue msg_json(qJson::qj_object);
//  			msg_json.addMember(strMsg, json);
// 			saveFirst();
// 			player_mgr.sendToAll(gate_client::player_hero_party_first_resp, msg_json);
// 		}


		HeroPartyCloseTime += DAY;
		saveSystem();
		Timer::AddEventTickTime(boostBind(heroparty_system::time22ClockTick, this, _1), Inter::event_heroparty_timer22, HeroPartyCloseTime);
	}

	void heroparty_system::flashHero(playerDataPtr player)
	{
		if (!player)return;
		heroPartyPtr heroPartyPtr_ptr = getHeroData(player->ID());
		if (!heroPartyPtr_ptr)return;
		heroPartyPtr_ptr->iFightingNum = 0;//����ս������
		heroPartyPtr_ptr->iAddFightingNum = 0;
		heroPartyPtr_ptr->iFalshShopNum = 0;
		heroPartyPtr_ptr->kHisShop = randomShopRes(player);//����ˢ���̳�����
		saveOneDB(heroPartyPtr_ptr);
		sendHeroPartyData(player->ID());
		sendShop(player->ID());
	}

	void heroparty_system::modifyName(int iPlayerID)
	{
		playerDataPtr ptrPlayer = player_mgr.getPlayer(iPlayerID);
		if (!ptrPlayer) { return; }
		heroPartyPtr heroPartyPtr_ptr = getHeroData(iPlayerID);
		if (!heroPartyPtr_ptr)return;
		heroPartyPtr_ptr->sPlayerName = ptrPlayer->Name();
		saveOneDB(heroPartyPtr_ptr);
	}

	void heroparty_system::modifyNation(int iPlayerID)
	{
		playerDataPtr ptrPlayer = player_mgr.getPlayer(iPlayerID);
		if (!ptrPlayer) { return; }
		heroPartyPtr heroPartyPtr_ptr = getHeroData(iPlayerID);
		if (!heroPartyPtr_ptr)return;
		heroPartyPtr_ptr->playerNation = ptrPlayer->Info().Nation();
		saveOneDB(heroPartyPtr_ptr);
	}

	void heroparty_system::modifyFace(int iPlayerID)
	{
		playerDataPtr ptrPlayer = player_mgr.getPlayer(iPlayerID);
		if (!ptrPlayer) { return; }
		heroPartyPtr heroPartyPtr_ptr = getHeroData(iPlayerID);
		if (!heroPartyPtr_ptr)return;
		heroPartyPtr_ptr->iPlayerFace = ptrPlayer->Info().Face();
		saveOneDB(heroPartyPtr_ptr);
	}

	void heroparty_system::set_box(int iPlayerID)
	{
		playerDataPtr ptrPlayer = player_mgr.getPlayer(iPlayerID);
		if (!ptrPlayer) { return; }
		heroPartyPtr heroPartyPtr_ptr = getHeroData(iPlayerID);
		if (!heroPartyPtr_ptr)return;
		if (heroPartyPtr_ptr->boxHeroNo < 1)return;

		const ACTION::BoxList& heroPartyBoxResPtr_ptr = heroparty_sys.getHeroPartyBox(heroPartyPtr_ptr->boxHeroNo);
		actionDoBox(ptrPlayer, heroPartyBoxResPtr_ptr);
		Json::Value json;
		json[strMsg][0u] = res_sucess;
		json[strMsg][1u] = actionRes();
		ptrPlayer->sendToClient(gate_client::player_hero_party_set_box_resp, json);
		Log(DBLOG::strLogHeroParty, ptrPlayer, 0, heroPartyPtr_ptr->boxHeroNo, heroPartyPtr_ptr->playerNation, "", "", "", "", "", json[strMsg][1u].toIndentString());
		heroPartyPtr_ptr->boxHeroNo = 0;//��ȡ����ɹ�
		saveOneDB(heroPartyPtr_ptr);
		sendHeroPartyData(ptrPlayer->ID());
	}

	void heroparty_system::resetShopData(playerDataPtr player, const bool isNature /* = true */)
	{
		heroPartyPtr heroPartyPtr_ptr = getHeroData(player->ID());
		if (!heroPartyPtr_ptr)return;
		if (!isNature)
		{
			heroPartyPtr_ptr->iFalshShopNum++;
		}
		heroPartyPtr_ptr->kHisShop = randomShopRes(player);
		saveOneDB(heroPartyPtr_ptr);
	}

	void heroparty_system::changeChart(playerDataPtr iPlayer, playerDataPtr iTargetPlayer)
	{
		heroPartyPtr heroPartyPtr_ptr_me = getHeroData(iPlayer->ID());
		if (!heroPartyPtr_ptr_me)return;
		heroPartyPtr heroPartyPtr_ptr_Target = getHeroData(iTargetPlayer->ID());
		if (!heroPartyPtr_ptr_Target)return;

		int iOldMeLv = heroPartyPtr_ptr_me->iHeroNo;
		int iOldTargetLv = heroPartyPtr_ptr_Target->iHeroNo;

		if (iOldMeLv > iOldTargetLv)
		{
			heroPartyPtr_ptr_me->iHeroNo = iOldTargetLv;
			heroPartyPtr_ptr_Target->iHeroNo = iOldMeLv;
			iPlayer->Info().motifyNo_(heroPartyPtr_ptr_me->iHeroNo);
			iTargetPlayer->Info().motifyNo_(heroPartyPtr_ptr_Target->iHeroNo);
			kHeroPartyHeroNo[iOldMeLv] = heroPartyPtr_ptr_Target;
			kHeroPartyHeroNo[iOldTargetLv] = heroPartyPtr_ptr_me;
		}
	}

	static void staticNoAnnounce(Json::Value json, const string part_path)
	{
		const int repID = chat_sys.toChatWindowsRep("./report/" + part_path);
		json.append(repID);
		chat_sys.despatchAll(gg::CHAT::server_heroparty_fight, json);
	}

	void heroparty_system::heroparty_challenge_impl(int iPlayerID, int iTargetPlayerID, int iTargetChartNum)
	{
		playerDataPtr ptrMePlayer = player_mgr.getPlayer(iPlayerID);
		if (!ptrMePlayer) { return; }
		playerDataPtr ptrTargetPlayer = player_mgr.getPlayer(iTargetPlayerID);
		if (!ptrTargetPlayer) { return; }

		if (iPlayerID == iTargetPlayerID)
		{
			sendHeroPartyData(iPlayerID);
			sendFightList(iPlayerID);
			Json::Value json;
			json[strMsg][0u] = err_heroparty_fight_me;
			ptrMePlayer->sendToClient(gate_client::player_hero_party_challenge_resp, json);
			return;
		}

		unsigned int uiTime = Common::gameTime();
		heroPartyPtr heroPartyPtr_ptr_me = getHeroData(iPlayerID);
		if (!heroPartyPtr_ptr_me)return;
		heroPartyPtr heroPartyPtr_ptr_Target = getHeroData(iTargetPlayerID);
		if (!heroPartyPtr_ptr_Target)return;

		if (heroPartyPtr_ptr_Target->iHeroNo != iTargetChartNum)
		{
			sendHeroPartyData(iPlayerID);
			sendFightList(iPlayerID);
			Json::Value json;
			json[strMsg][0u] = err_heroparty_fight_chart_num;
			ptrMePlayer->sendToClient(gate_client::player_hero_party_challenge_resp, json);
			return;
		}

		if (heroPartyPtr_ptr_me->uiFightCD > uiTime)
		{
			sendHeroPartyData(iPlayerID);
			sendFightList(iPlayerID);
			Json::Value json;
			json[strMsg][0u] = err_heroparty_fight_time;
			ptrMePlayer->sendToClient(gate_client::player_hero_party_challenge_resp, json);
			return;
		}

		if (heroPartyPtr_ptr_me->iFightingNum >= (MAX_FIGHTING_NUM + heroPartyPtr_ptr_me->iAddFightingNum))
		{
			sendHeroPartyData(iPlayerID);
			sendFightList(iPlayerID);
			Json::Value json;
			json[strMsg][0u] = err_heroparty_max_fight_num;
			ptrMePlayer->sendToClient(gate_client::player_hero_party_challenge_resp, json);
			return;
		}

		heroPartyPtr_ptr_me->iReportID++;
		heroPartyPtr_ptr_Target->iReportID++;
		heroPartyPtr_ptr_me->iFightingNum++;
		heroPartyPtr_ptr_me->uiFightCD = uiTime;

		// ��ս
		sBattlePtr atk = BattleHelp::WarPlayer(ptrMePlayer);
		sBattlePtr def = BattleHelp::WarPlayer(ptrTargetPlayer);
		BattleReport reportData;
		O2ORes resultB = reportData.One2One(atk, def, typeBattle::hero_party);
		reportData.addNotice(iPlayerID);
		Json::Value rep_json = chat_sys.ChatPackage(ptrTargetPlayer);
		const string part_path = "last_rep/" + Common::toString(ptrMePlayer->ID());
		reportData.addCopyField(part_path);
		string rPath = strRpHeroParty + Common::toString(iPlayerID) + "_" + Common::toString(iTargetPlayerID) + "_" + Common::toString(heroPartyPtr_ptr_me->iReportID);
		reportData.addCopyField(rPath);

		// ��������˳��
		const int mineNo = heroPartyPtr_ptr_me->iHeroNo;
		const int aimNo = heroPartyPtr_ptr_Target->iHeroNo;
		if (resultB.res == resBattle::atk_win) { changeChart(ptrMePlayer, ptrTargetPlayer); }
		bool change_rank = ((resultB.res == resBattle::atk_win) && (mineNo > aimNo));
		// �Լ���ս��
		heroPartyReportPtr heroPartyReportPtr_mePtr = Creator<heroPartyReport>::Create();
		heroPartyPtr_ptr_me->kReport[heroPartyPtr_ptr_me->iReportID] = heroPartyReportPtr_mePtr;
		heroPartyReportPtr_mePtr->iPlayerID = heroPartyPtr_ptr_Target->iPlayerID;
		heroPartyReportPtr_mePtr->iLv = heroPartyPtr_ptr_Target->uiPlayerLV;
		heroPartyReportPtr_mePtr->iWin = resultB.res == resBattle::atk_win ? 1 : 0;
		heroPartyReportPtr_mePtr->sPlayerName = heroPartyPtr_ptr_Target->sPlayerName;
		heroPartyReportPtr_mePtr->uiTime = uiTime;
		heroPartyReportPtr_mePtr->playerNation = heroPartyPtr_ptr_Target->playerNation;
		heroPartyReportPtr_mePtr->iChart = resultB.res == resBattle::atk_win ? (mineNo > aimNo ? mineNo - aimNo : 0) : 0;
		heroPartyReportPtr_mePtr->iRevenge = 0;
		heroPartyReportPtr_mePtr->sPath = rPath;

		//�Լ���CD
		if (resultB.res == resBattle::def_win)
		{
			heroPartyPtr_ptr_me->uiFightCD = Common::gameTime() + MAX_FIGHT_TIME_CD;
		}


		// ���ֵ�ս��
		heroPartyReportPtr heroPartyReportPtr_targetPtr = Creator<heroPartyReport>::Create();
		heroPartyPtr_ptr_Target->kReport[heroPartyPtr_ptr_Target->iReportID] = heroPartyReportPtr_targetPtr;
		heroPartyReportPtr_targetPtr->iPlayerID = heroPartyPtr_ptr_me->iPlayerID;
		heroPartyReportPtr_targetPtr->iLv = heroPartyPtr_ptr_me->uiPlayerLV;
		heroPartyReportPtr_targetPtr->iWin = resultB.res == resBattle::def_win ? 1 : 0;
		heroPartyReportPtr_targetPtr->sPlayerName = heroPartyPtr_ptr_me->sPlayerName;
		heroPartyReportPtr_targetPtr->uiTime = uiTime;
		heroPartyReportPtr_targetPtr->playerNation = heroPartyPtr_ptr_me->playerNation;
		heroPartyReportPtr_targetPtr->iChart = resultB.res == resBattle::atk_win ? (mineNo > aimNo ? aimNo - mineNo : 0) : 0;
		heroPartyReportPtr_targetPtr->iRevenge = resultB.res == resBattle::def_win ? 0 : 1;
		heroPartyReportPtr_targetPtr->sPath = rPath;

		saveOneDB(heroPartyPtr_ptr_me);
		saveOneDB(heroPartyPtr_ptr_Target);

// 		int rw_silver = 3000;
// 		if (resultB.res != resBattle::atk_win)rw_silver = 2000;
// 		ptrMePlayer->Res().alterSilver(rw_silver);
// 		qValue box_rw(qJson::qj_array), silver_rw(qJson::qj_array);
// 		silver_rw.append(ACTION::silver).append(rw_silver);
// 		box_rw.append(silver_rw);
//		ptrMePlayer->Res().alterSilver(rw_silver);

		int rw_silver = 15;
		if (resultB.res != resBattle::atk_win)rw_silver = 10;
		qValue box_rw(qJson::qj_array), silver_rw(qJson::qj_array);
		silver_rw.append(ACTION::heroes_coin).append(rw_silver);
		box_rw.append(silver_rw);
		ptrMePlayer->Res().alterHeroPartyMoney(rw_silver);
		reportData.addReportdeclare("wb", box_rw);//��װα��
		reportData.Done(typeBattle::hero_party);

		// ����ս��
		sendFightData(iPlayerID, true);
		sendFightData(iTargetPlayerID, true);
		sendHeroPartyData(iPlayerID);

		Json::Value json;
		json[strMsg][0u] = res_sucess;
		json[strMsg][1u] = resultB.res == resBattle::atk_win ? 1 : 0;
		json[strMsg][2u] = heroPartyPtr_ptr_me->iHeroNo;
		json[strMsg][3u] = rw_silver;
		ptrMePlayer->sendToClient(gate_client::player_hero_party_challenge_resp, json);

		// �㲥 //ʤ�� //Ŀ�������� 1~100
		if (resultB.res == resBattle::atk_win && aimNo > 0 && aimNo < 101)
		{
			if (change_rank &&
				(aimNo < 6 ||
				(resultB.star == 1 && aimNo >= 6 && (ptrMePlayer->LV() >= 60 || ptrTargetPlayer->LV() >= 60)))
				)
			{
				Json::Value jsonChat;
				jsonChat.append(aimNo);
				jsonChat.append(chat_sys.ChatPackage(ptrMePlayer));
				jsonChat.append(chat_sys.ChatPackage(ptrTargetPlayer));
				UserTask::Add(boostBind(staticNoAnnounce, jsonChat, part_path), State::getState());
			}
		}
		Log(DBLOG::strLogHeroParty, ptrMePlayer, 1, ptrTargetPlayer->LV(), heroPartyPtr_ptr_me->iHeroNo, heroPartyPtr_ptr_Target->iHeroNo, resultB.res);
		{
			//�ճ�
			TaskMgr::update(ptrMePlayer, Task::HeroPartyTimes, 1);
			ptrMePlayer->Daily().tickTask(DAILY::hero_party);
		}
	}

	int heroparty_system::getKingdomWarNpcBV() const
	{
		int sum = 0;
		for (int rk = 100; rk < 110; ++rk)
		{
			PlayerHeroParty::const_iterator it = kHeroPartyHeroNo.find(rk);
			if (it == kHeroPartyHeroNo.end())
				break;
			sum += it->second->iFighting;
		}
		return sum / 10;
	}

	int heroparty_system::getKingdomWarTaskParam() const
	{
		int sum = 0;
		for (int rk = 50; rk < 60; ++rk)
		{
			PlayerHeroParty::const_iterator it = kHeroPartyHeroNo.find(rk);
			if (it == kHeroPartyHeroNo.end())
				break;
			sum += it->second->uiPlayerLV;
		}
		return sum / 10;
	}
}

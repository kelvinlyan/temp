//###################################
//create by Jim
//2016-11-07
//###################################

#pragma once

#include "dbDriver.h"

#define business_daily_rank (*gg::BusinessDailyRank::_Instance)

namespace gg
{
	namespace NSBusinessDailyRank
	{
		struct Rankey
		{
			Rankey()
			{
				playerID = -1;
				businessMoney = 0;
			}
			bool operator<(const Rankey& other)const
			{
				if (businessMoney != other.businessMoney)return businessMoney > other.businessMoney;
				return playerID < other.playerID;
			}
			bool operator>(const Rankey& other)const
			{
				return *this < other;
			}
			int playerID;
			int businessMoney;
		};

		struct RankData
		{
			Rankey Key()
			{
				Rankey key;
				key.playerID = playerID;
				key.businessMoney = businessMoney;
				return key;
			}
			RankData()
			{
				playerID = -1;
				playerName = "";
				playerNation = Kingdom::null;
				businessMoney = 0;
				rankNo = 0;
			}
			RankData(playerDataPtr player)
			{
				setNewData(player);
				rankNo = 0;
			}
			void setNewData(playerDataPtr player)
			{
				playerID = player->ID();
				playerName = player->Name();
				playerNation = player->Info().Nation();
			}
			int playerID;
			string playerName;
			int playerNation;
			int businessMoney;
			int rankNo;
		};

		BOOSTSHAREPTR(RankData, ptrRankData);

		STDMAP(Rankey, ptrRankData, RankMap);
		STDMAP(int, ptrRankData, PlayerMap);
	}

	class BusinessDailyRank
	{
	public:
		BusinessDailyRank() { isInitial = false; }
		static BusinessDailyRank* const _Instance;
		void initData();
		DeclareRegFunction(RankList);
	public:
		typedef NSBusinessDailyRank::RankMap::iterator iterator_type;
		inline NSBusinessDailyRank::RankMap::iterator rank_begin() { return Rank.begin(); }
		inline NSBusinessDailyRank::RankMap::iterator rank_end() { return Rank.end(); }
		void updateInfo(playerDataPtr player);
		void updatePlayer(playerDataPtr player, const int money);
		void clearAllData();
	private:
		NSBusinessDailyRank::ptrRankData getData(const int playerID);
		int getRank(const int playerID);

		NSBusinessDailyRank::RankMap Rank;
		NSBusinessDailyRank::PlayerMap Player;

		bool isInitial;

	private:
		void saveData(NSBusinessDailyRank::ptrRankData data);
		void delData(const int playerID);
	};
}

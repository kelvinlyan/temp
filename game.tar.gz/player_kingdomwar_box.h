#pragma once

#include "auto_base.h"

namespace gg
{
	class playerKingdomWarBox
		: public _auto_player
	{
		public:
			playerKingdomWarBox(playerData* const own);
			
			virtual void classLoad();
			virtual bool _auto_save();
			virtual void _auto_update();

			void update();

			int getReward(int id, Json::Value& r);
			unsigned numBox(unsigned time);
			void numBoxInfo(qValue& q);
			void initGreatEventBox();
			int getGreatEventReward(int idx, Json::Value& r);
			void clear();

			int rpState();
			void resetRpState();
			void resetRpStateAndUpdate();

			int greatEventRP();
			int resetGreatEventRP();
			void resetGreatEventRPAndUpdate();

			int goldBoxLimit();
			int silverBoxLimit();
			int homeBoxLimit();
			void alterGoldBoxNum(int num = 1);
			void alterSilverBoxNum(int num = 1);
			void alterHomeBoxNum(int num = 1);
			void dailyTick();

		private:
			std::vector<int> _box_state;
			int _rp_state;

			STDMAP(unsigned, unsigned, GreatEventBoxNum);
			GreatEventBoxNum _box_num;
			unsigned _max_box_time;
			int _ge_rp_state;

			int _gold_box_num;
			int _silver_box_num;
			int _home_box_num;
	};
}

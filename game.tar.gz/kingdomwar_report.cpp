#include "kingdomwar_report.h"
#include "playerManager.h"

namespace gg
{
	namespace KingdomWar
	{
		ReportMgr::ReportMgr(int max)
			: _max(max)
		{
		}

		void ReportMgr::load(const mongo::BSONElement& obj)
		{
			std::vector<mongo::BSONElement> ele = obj.Array();
			for (unsigned i = 0; i < ele.size(); ++i)
				_rep_list.push_back(ele[i].String());
			while(_rep_list.size() > _max)
				_rep_list.pop_back();
		}

		mongo::BSONArray ReportMgr::toBSON() const
		{
			mongo::BSONArrayBuilder b;
			ForEachC(ReportList, it, _rep_list)
				b.append(*it);
			return b.arr();
		}

		void ReportMgr::push(qValue& rep)
		{
			_rep_list.push_front(rep.toIndentString());
			while(_rep_list.size() > _max)
				_rep_list.pop_back();
		}

		void ReportMgr::updateAll(playerDataPtr d, short protocol)
		{
			std::string str;
			str += "{\"msg\":[0,[";
			ForEachC(ReportList, it, _rep_list)
			{
				if (it != _rep_list.begin())
					str += ",";
				str += *it;
			}
			str += "]]}";
			d->sendToClient(protocol, str);
		}
	}
}

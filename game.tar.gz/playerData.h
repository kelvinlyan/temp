//###################################
//create by Jim
//2015-11-04
//###################################

#pragma once
#include <boost/thread/mutex.hpp>
#include <boost/thread/recursive_mutex.hpp>
#include <boost/shared_ptr.hpp>
#include <boost/enable_shared_from_this.hpp>
#include "commom.h"
#include "channel.h"
#include "quickjson.h"

//@�������ͷ�ļ�
#include "gamer_data.h"
#include "gamer_tick.h"
#include "player_man.h"
#include "gamer_resource.h"
#include "player_mapwar.h"
#include "player_task.h"
#include "war_formation.h"
#include "player_card.h"
#include "player_item.h"
#include "player_search.h"
#include "gamer_face.h"
#include "pokedex.h"
#include "playerCount.h"
#include "player_trade.h"
#include "player_kingfight.h"
#include "player_kingdom.h"
#include "player_rescue.h"
#include "player_team.h"
#include "player_vip.h"
#include "player_worldboss.h"
#include "player_research.h"
#include "player_market.h"
#include "player_orders.h"
#include "player_mall.h"
#include "player_warlords.h"
#include "player_email.h"
#include "player_daily.h"
#include "player_build_team.h"
#include "player_feod.h"
#include "player_admin.h"
#include "gamer_offline.h"
#include "gamer_custom.h"
#include "player_days_activity.h"
#include "gamer_online_box.h"
#include "player_affair.h"
#include "player_sign.h"
#include "player_money.h"
#include "gamer_daily_card.h"
#include "player_fund.h"
#include "player_kingdomwar.h"
#include "player_kingdomwar_shop.h"
#include "player_kingdomwar_output.h"
#include "player_kingdomwar_fm.h"
#include "player_kingdomwar_pos.h"
#include "player_kingdomwar_box.h"
#include "player_kingdomwar_task.h"
#include "player_patrol.h"
#include "player_open_activity.h"

//@�������ͷ�ļ�

namespace gg
{
	const static string strPlayerID = "pi";

#define PlayerDataInitial(TYPENAME, NICKNAME) \
protected:\
	boost::shared_ptr<TYPENAME> _##NICKNAME;\
	boost::shared_ptr<TYPENAME> ptr_##NICKNAME(){\
		_##NICKNAME->toLoad();\
		if(!isOnline()){_##NICKNAME->classRefresh();}\
		return _##NICKNAME;\
	}\
public:\
	inline TYPENAME& NICKNAME(){return *ptr_##NICKNAME();}\

	class playerData :
		public boost::enable_shared_from_this<playerData>
	{
		friend class playerManager;
	public:
		inline playerDataPtr getOwnDataPtr(){
			return shared_from_this();
		}
		bool isVaild();
//		inline int Net(){ return netID; }
		inline bool isOnline()
		{
			return Online;
		}
		void sendToClient(const short protocol, Json::Value& msg);
		void sendToClient(const short protocol, qValue& msg);
		void sendToClientFillMsg(const short protocol, qValue& msg);
		void sendToClient(const short protocol, string& msg);
		void sendToClientFillMsg(const short protocol, string& msg);
		void Logout();
		void Login();
//		bool outLine();
		inline int ID(){ return Info().ID(); }
		inline string Name(){ return Info().Name(); }
		inline unsigned LV(){ return Info().LV(); }
		inline bool motifyName(const string name){ return Info().motifyName(name); }

		//////////////////////////////////////////////////////////////////////////
		PlayerDataInitial(playerBase, Info);
		PlayerDataInitial(playerTick, Tick);
		PlayerDataInitial(playerManMgr, Man);
		PlayerDataInitial(playerResource, Res);
		PlayerDataInitial(playerMapWarMgr, War);//
		PlayerDataInitial(playerTask, Task);//
		PlayerDataInitial(playerWarFM, WarFM);
		PlayerDataInitial(playerCardMgr, Card);
		PlayerDataInitial(playerCardTs, CardTs);
		PlayerDataInitial(playerItemMgr, Items);
		PlayerDataInitial(playerSearch, Sch);
		PlayerDataInitial(playerFace, Face);
		PlayerDataInitial(playerPoke, Poke);
		PlayerDataInitial(playerCount, Count);
		PlayerDataInitial(playerCarPos, CarPos);
		PlayerDataInitial(playerTrade, Trade);//ó��
		PlayerDataInitial(playerKingFight, KingFight);//
		PlayerDataInitial(playerKingdom, KingDom);//
		PlayerDataInitial(playerRescue, RescueData);
		PlayerDataInitial(playerTeam, Team);//
		PlayerDataInitial(playerVipMgr, Vip);//
		PlayerDataInitial(playerWorldBoss, WorldBoss);//
		PlayerDataInitial(playerWarLords, WarLords);//
		PlayerDataInitial(playerResearch, Research);
		PlayerDataInitial(playerMarket, Market);
		PlayerDataInitial(playerOrders, Orders);
		PlayerDataInitial(playerMall, Malls);
		PlayerDataInitial(playerEmail, Email);
		PlayerDataInitial(playerDaily, Daily);
		PlayerDataInitial(playerBuildTeam, BuildTeam);
		PlayerDataInitial(playerBuilds, Builds);
		PlayerDataInitial(playerAdmin, Admin);
		PlayerDataInitial(playerOffline, Offline);
		PlayerDataInitial(playerCustom, Custom);
		PlayerDataInitial(playerDaysActivity, DaysActivity);
		PlayerDataInitial(playerOnlineBox, OnlineBox);
		PlayerDataInitial(playerAffair, Affair);
		PlayerDataInitial(playerSign, Sign);
		PlayerDataInitial(playerMoneyActivity, MoneyActivity);
		PlayerDataInitial(playerDailyCard, DailyCard);
		PlayerDataInitial(playerFund, Fund);
		PlayerDataInitial(playerKingdomWar, KingDomWar);
		PlayerDataInitial(playerKingdomWarShop, KingDomWarShop);
		PlayerDataInitial(playerKingdomWarOutput, KingDomWarOutput);
		PlayerDataInitial(playerKingdomWarFM, KingDomWarFM);
		PlayerDataInitial(playerKingdomWarPos, KingDomWarPos);
		PlayerDataInitial(playerKingdomWarBox, KingDomWarBox);
		PlayerDataInitial(playerKingdomWarTask, KingDomWarTask);
		PlayerDataInitial(playerPatrol1, Patrol);
		PlayerDataInitial(playerOpenActivity, OpenActivity);



		//////////////////////////////////////////////////////////////////////////
		//memory
		unsigned Chat[CHAT::user_channel];
		unsigned TeamCD;
		unsigned BusinessCD;
		unsigned EquipShowCD;
		unsigned ShareLastCD;
		unsigned TeamAnnCD;
		boost::system_time CarMoveCD;
		//end
		//public method
		void onBVAlter();//�����ս���ı��ʱ��
	protected:
		void clearData();
		bool Dirty;
		bool Online;
		void initial(const unsigned dataState);
		void onLogin();//��ҵ�½��ʱ��
		void onOFFLine();//�������
		void onCreateRole();//��Ҵ�����ɫ��ʱ��
	public:
		playerData(const int pID, const unsigned dataState);
		playerData(const string pName, const unsigned dataState);
		~playerData();
		static playerDataPtr Create(const int playerID, const unsigned dataState = AutoPlayer::class_all_empty)
		{
			return Creator<playerData>::Create(playerID, dataState);
		}
		static playerDataPtr Create(const string playerName, const unsigned dataState = AutoPlayer::class_all_empty)
		{
			return Creator<playerData>::Create(playerName, dataState);
		}
	};
}

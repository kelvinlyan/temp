#include "player_kingdomwar_pos.h"
#include "playerManager.h"
#include "kingdomwar_system.h"
#include "kingdomwar_def.h"
#include "task_mgr.h"
#include "wstar_kingdomwar.h"

namespace gg
{
	namespace KingdomWar
	{
		class HomeReward
		{
			SINGLETON(HomeReward);
			public:
				const ActionRandomList& getReward(playerDataPtr d) const
				{
					int lv = d->LV();
					ForEachC(std::vector<Item>, it, _items)
					{
						if (lv >= it->start && lv <= it->end)
						{
							if (d->KingDomWarFM().getBV(0) * 1.2 < NpcRuleMgr::shared().bv())
								return it->rw2;
							else
								return it->rw1;
						}
					}
					if (d->KingDomWarFM().getBV(0) * 1.2 < NpcRuleMgr::shared().bv())
						return _items.front().rw2;
					else
						return _items.front().rw1;
				}
			private:
				void loadFile();
			private:
				struct Item
				{
					Item(const Json::Value& info)
					{
						start = info["lv_start"].asInt();
						end = info["lv_end"].asInt();
						rw1 = actionFormat(info["reward1"].asInt());
						rw2 = actionFormat(info["reward2"].asInt());

					}
					int start; // lv
					int end;
					ActionRandomList rw1;
					ActionRandomList rw2;
				};
				std::vector<Item> _items;
		};

		HomeReward::HomeReward()
		{
			loadFile();
		}

		void HomeReward::loadFile()
		{
			const Json::Value json = Common::loadJsonFile("./instance/kingdom_war/home_reward.json");
			ForEachC(Json::Value, it, json)
				_items.push_back(Item(*it));
		}
	}

	playerKingdomWarSGPos::playerKingdomWarSGPos(int army_id, playerData* const own)
		: _auto_player(own), _army_id(army_id)
	{
		_pos.type = KingdomWar::PosEmpty;
	}

	void playerKingdomWarSGPos::load(const mongo::BSONObj& obj)
	{
		_pos.type = obj["t"].Int();
		_pos.id = obj["i"].Int();
		_pos.time = obj["tm"].Int();
		_pos.from_id = obj["f"].Int();
		std::vector<mongo::BSONElement> ele = obj["p"].Array();
		for (unsigned i = 0; i < ele.size(); ++i)
			_line.push_back(ele[i].Int());
	}

	bool playerKingdomWarSGPos::_auto_save()
	{
		mongo::BSONObj key = BSON(strPlayerID << Own().ID() << "a" << _army_id);
		mongo::BSONObjBuilder obj;
		obj << strPlayerID << Own().ID() << "a" << _army_id << "t" << _pos.type
			<< "i" << _pos.id << "tm" << _pos.time << "f" << _pos.from_id;
		{
			mongo::BSONArrayBuilder b;
			ForEachC(IdList, it, _line)
				b.append(*it);
			obj << "p" << b.arr();
		}
		return db_mgr.SaveMongo(DBN::dbPlayerKingdomWarPos, key, obj.obj());
	}

	void playerKingdomWarSGPos::_auto_update()
	{
		qValue m;
		m.append(res_sucess);
		qValue q(qJson::qj_object);
		getInfo(q);
		m.append(q);
		Own().sendToClientFillMsg(gate_client::kingdom_war_player_update_resp, m);
	}

	void playerKingdomWarSGPos::getInfo(qValue& q)
	{
		if (_pos.type == KingdomWar::PosEmpty)
			kingdomwar_sys.goBackMainCity(0, Own().getOwnDataPtr(), _army_id, JARRAY((int)KingdomWar::TIPS::NONE));

		unsigned cur_time = Common::gameTime();
		q.addMember("i", _army_id);
		q.addMember("h", Own().KingDomWar().armyHp(_army_id, cur_time));
		q.addMember("t", cur_time);
		q.addMember("ht", Own().KingDomWar().useHpItemTimes());
		qValue p(qJson::qj_object);
		if (_pos.type == KingdomWar::PosCity)
		{
			KingdomWar::CityPtr ptr = KingdomWar::CityMgr::shared().getCity(_pos.id);
			if (ptr->nation() != Own().Info().Nation())
				p.addMember("t", 2);
			else
				p.addMember("t", _pos.type);
		}
		else
			p.addMember("t", _pos.type);
		p.addMember("i", _pos.id);
		p.addMember("tm", _pos.time);
		p.addMember("f", _pos.from_id);
		if (_tips != Json::nullValue)
		{
			p.addMember("r", qValue(_tips.toIndentString().c_str()));
			_tips = Json::nullValue;
		}
		qValue l;
		ForEachC(IdList, it, _line)
			l.append(*it);
		p.addMember("p", l);
		q.addMember("p", p);
	}

	bool playerKingdomWarSGPos::inMainCity()
	{
		return (_pos.type == KingdomWar::PosCity &&
			_pos.id == KingdomWar::MainCity[Own().Info().Nation()]);
	}

	void playerKingdomWarSGPos::setLine(const KingdomWar::Line& line)
	{
		_line.clear();
		for (unsigned i = 1; i < line.size(); ++i)
			_line.push_back(line[i]);
		_sign_auto();
	}

	int playerKingdomWarSGPos::tryMove()
	{
		if (_pos.type != KingdomWar::PosCity
			|| _line.empty())
			return res_sucess;
		_auto_update();
		return move(_pos.time, _line.front(), false);
	}

	int playerKingdomWarSGPos::transfer(unsigned time, int to_city_id)
	{
		if (Own().KingDomWarFM().empty(_army_id))
			return err_illedge;
		if (_pos.type == KingdomWar::PosCity)
		{
			if (_pos.id == KingdomWar::MainCity[Own().Info().Nation()])
			{
				if (!Own().KingDomWar().armyHpFilled(_army_id))
					return err_kingdomwar_army_hp_not_enough;
				if (Own().KingDomWarFM().getUpHpCost(_army_id) > 0)
					return err_kingdomwar_man_hp_not_enough;
			}
			KingdomWar::CityPtr ptr = KingdomWar::CityMgr::shared().getCity(_pos.id);	
			if (!ptr) return err_illedge;
			return ptr->transfer(time, Own().getOwnDataPtr(), _army_id, to_city_id);
		}
		else
		{
			KingdomWar::PathPtr ptr = kingdomwar_sys.getPath(_pos.id);
			if (!ptr) return err_illedge;
			int res = ptr->transferLimit(Own().getOwnDataPtr(), _army_id, to_city_id);
			if (res != res_sucess)
				return res;
			_line.clear();
			return ptr->transfer(time, Own().getOwnDataPtr(), _army_id, to_city_id);
		}
	}

	void playerKingdomWarSGPos::setPosition(int type, int id, unsigned time, Json::Value& tips)
	{
		if (_pos.type != KingdomWar::PosPath)
			_pos.from_id = _pos.id;

		_pos.type = type;
		_pos.id = id;
		_pos.time = time;

		int reason = tips[0u].asInt();

		if (inMainCity())
		{
			_line.clear();
			Own().KingDomWar().clearWinStreak(_army_id);
			if (reason == KingdomWar::TIPS::HPEMPTY
				|| reason == KingdomWar::TIPS::DEFEATED
				|| reason == KingdomWar::TIPS::ELECATTACK)
			{
				Own().KingDomWarFM().clearManHp(_army_id);
				if (_army_id == 0 
					&& KingdomWar::PrimeState::shared()
					&& Own().KingDomWarBox().homeBoxLimit() > 0)
				{
					const ActionRandomList& rw = KingdomWar::HomeReward::shared().getReward(Own().getOwnDataPtr());
					int res = actionDo(Own().getOwnDataPtr(), rw);
					if (res == res_sucess)
					{
						Json::Value ar = actionRes();
						if (ar.size() != 0)
						{
							tips.append(ar);
							Own().KingDomWarBox().alterHomeBoxNum(1);
						}
					}
				}
			}
			Own().KingDomWar().resetArmyHp(_army_id, time);
		}
		if (_pos.type == KingdomWar::PosCity
			&& !_line.empty())
		{
			_line.pop_front();
		}
		_tips = tips;
		_sign_auto();
	}

	int playerKingdomWarSGPos::move(unsigned time, int to_city_id, bool start)
	{
		if (_pos.type == KingdomWar::PosPath)
			return err_kingdomwar_in_path;

		KingdomWar::CityPtr ptr = KingdomWar::CityMgr::shared().getCity(_pos.id);	
		if (!ptr)
			return err_illedge;

		if (ptr->state() != KingdomWar::Closed
			&& ptr->state() != KingdomWar::Protected)
		{
			if (!start)
			{
				_line.clear();
				return err_kingdomwar_at_war;
			}
		}
	//	
	//	if (ptr->onFight(Own().getOwnDataPtr(), _army_id))
	//		return err_kingdomwar_at_war;
		
		if (start)
		{
			if (_pos.type == KingdomWar::PosCity &&
				_pos.id == KingdomWar::MainCity[Own().Info().Nation()])
			{
				if (!Own().KingDomWar().armyHpFilled(_army_id))
					return err_kingdomwar_army_hp_not_enough;
				if (Own().KingDomWarFM().getUpHpCost(_army_id) > 0)
					return err_kingdomwar_man_hp_not_enough;
			}

			std::vector<int> line;
			{
				WStarKW w;
				w.publicStart = _pos.id;
				w.publicEnd = to_city_id;
				w.publicNearly = boostBind(kingdomwar_system::nearbyID1, kingdomwar_system::_Instance, Own().getOwnDataPtr(), to_city_id, _1, _2);
				w.publicFare = boostBind(kingdomwar_system::distance, kingdomwar_system::_Instance, _1, _2);
				line = w.find();
			}
			if (line.empty())
			{
				WStarKW w;
				w.publicStart = _pos.id;
				w.publicEnd = to_city_id;
				w.publicNearly = boostBind(kingdomwar_system::nearbyID2, kingdomwar_system::_Instance, Own().getOwnDataPtr(), _1, _2);
				w.publicFare = boostBind(kingdomwar_system::distance, kingdomwar_system::_Instance, _1, _2);
				line = w.find();
				if (line.empty())
					return err_kingdomwar_path_not_access;
			}
			_line.clear();
			ForEachC(std::vector<int>, it, line)
				_line.push_back(*it);
			to_city_id = _line.front();	
		}
		
		int res = ptr->leave(time, Own().getOwnDataPtr(), _army_id, to_city_id);
		if (res != res_sucess && !start)
		{
			_line.clear();
		}
		return res;
	}

	int playerKingdomWarSGPos::retreat()
	{
		if (_pos.type == KingdomWar::PosPath)
			return err_kingdomwar_in_path;

		KingdomWar::CityPtr ptr = KingdomWar::CityMgr::shared().getCity(_pos.id);	
		if (!ptr)
			return err_illedge;
		
		if (ptr->onFight(Own().getOwnDataPtr(), _army_id))
			return err_kingdomwar_at_war;

		if (_pos.from_id == KingdomWar::MainCity[Own().Info().Nation()])
			return err_kingdomwar_path_not_access;

		_line.clear();
		_line.push_back(_pos.from_id);
		
		return ptr->leave(Common::gameTime(), Own().getOwnDataPtr(), _army_id, _pos.from_id);
	}

	playerKingdomWarPos::playerKingdomWarPos(playerData* const own)
		: _auto_player(own)
	{
		for (unsigned i = 0; i < KingdomWar::ArmyNum; ++i)
			_pos_list.push_back(Creator<playerKingdomWarSGPos>::Create(i, own));
	}

	void playerKingdomWarPos::classLoad()
	{
		mongo::BSONObj key = BSON(strPlayerID << Own().ID());
		objCollection objs = db_mgr.Query(DBN::dbPlayerKingdomWarPos, key);
		for (unsigned i = 0; i < objs.size(); ++i)
		{
			int army_id = objs[i]["a"].Int();
			_pos_list[army_id]->load(objs[i]);
		}
	}

	void playerKingdomWarPos::_auto_update()
	{
	}

	bool playerKingdomWarPos::_auto_save()
	{
		return true;
	}

	void playerKingdomWarPos::update()
	{
		qValue m;
		m.append(res_sucess);
		qValue q;
		for (unsigned i = 0; i < _pos_list.size(); ++i)
		{
			qValue tmp(qJson::qj_object);
			_pos_list[i]->getInfo(tmp);
			q.append(tmp);
		}
		m.append(q);
		Own().sendToClientFillMsg(gate_client::kingdom_war_player_info_resp, m);
	}

	void playerKingdomWarPos::setPosition(int army_id, int type, int id, unsigned time, Json::Value& tips)
	{
		_pos_list[army_id]->setPosition(type, id, time, tips);
	}

	void playerKingdomWarPos::setLine(int army_id, const KingdomWar::Line& l)
	{
		_pos_list[army_id]->setLine(l);
	}

	int playerKingdomWarPos::move(unsigned time, int army_id, int to_city_id, bool start)
	{
		if (army_id < 0 || army_id >= KingdomWar::ArmyNum)
			return err_illedge;

		return _pos_list[army_id]->move(time, to_city_id, start);
	}

	int playerKingdomWarPos::transfer(unsigned time, int army_id, int to_city_id)
	{
		if (army_id < 0 || army_id >= KingdomWar::ArmyNum)
			return err_illedge;

		return _pos_list[army_id]->transfer(time, to_city_id);
	}

	int playerKingdomWarPos::retreat(int army_id)
	{
		if (army_id < 0 || army_id >= KingdomWar::ArmyNum)
			return err_illedge;

		return _pos_list[army_id]->retreat();
	}
}

//###################################
//create by Jim
//2016-03-03
//###################################

#pragma once

namespace gg
{
	namespace Rescue
	{
		enum TYPE
		{
			rescue_null,//��Ч������
			rescue_build_1,
			rescue_build_2,
			rescue_build_3,
			rescue_build_4,
			rescue_build_5,
			rescue_build_6,
			rescue_build_7,
			rescue_build_8,
			rescue_build_9,
			rescue_build_10,
			rescue_build_11,
			rescue_build_12,
			rescue_end,//��������
		};
	}

}
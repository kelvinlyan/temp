#pragma once

#include "auto_base.h"
#include "mongoDB.h"
#include "battle_def.h"
#include "battle_system.h"
#include "kingdomwar_helper.h"
#include "map_war.h"

namespace gg
{
	namespace KingdomWar
	{
		struct NpcDataConfig
			: public mapDataConfig
		{
			std::string mapName2;
		};

		BOOSTSHAREPTR(NpcDataConfig, NpcDataCfgPtr);

		class NpcData
			: public _auto_meta
		{
			public:
				NpcData(const mongo::BSONObj& obj);
				NpcData(int type, int map_id, int nation, const Position& pos, int hp, const std::vector<int>& man_hp);
				virtual ~NpcData();

				int type() const { return _type; }
				int id() const { return _id; }
				const std::string& name() const { return _name; }
				int nation() const { return _nation; }
				int hp() const { return _hp; }
				int bv() const { return _npc_data->battleValue; }
				void fmInfo(qValue& q) const;
				const NpcDataCfgPtr& npcData() const { return _npc_data; }
				bool valid() const { return (bool)_npc_data; }
				bool checkValidAndSave();
				void setDead(unsigned cur_time, Json::Value& tips);

				int alterHp(int num);
				int manHp() const;
				void resetManHp(sBattlePtr& ptr);

				sBattlePtr getBattlePtr(int& max_hp, int& cur_hp) const;
				bool isDead() const;
				
				const Position& position() const { return _pos; }
				void setPosition(int type, int id, unsigned time);

			protected:
				virtual bool _auto_save();
				void removeDB();
			
			protected:
				int _type;
				int _id;
				std::string _name;
				int _nation;
				int _hp;
				std::vector<int> _man_hp;
				NpcDataCfgPtr _npc_data;
				Position _pos;
				bool _dead;
		};

		BOOSTSHAREPTR(NpcData, NpcDataPtr);

		class ShadowNpcData
			: public NpcData
		{
			public:
				ShadowNpcData(const mongo::BSONObj& obj);
				ShadowNpcData(playerDataPtr d, int map_id, const Position& pos, int hp, const std::vector<int>& man_hp, int type);

				int ownID() const { return _own_id; }
				void setDead(unsigned cur_time, Json::Value& tips);
				
			protected:
				virtual bool _auto_save();

			private:
				int _own_id;
		};

		BOOSTSHAREPTR(ShadowNpcData, ShadowNpcDataPtr);
	}
}

#include "gate_game_protocol.h"
#include "ownerland_system.h"
#include "commom.h"
#include <boost/assert.hpp>
#include "rescue_system.h"
#include "man_system.h"
#include "task_mgr.h"

namespace gg
{
	//��ְϵͳ���ŵȼ�
	const int MAX_OFFICIAL_OPEN_PALER_LV = 10;

	ownerland_system* const ownerland_system::_Instance = new ownerland_system();

	UNORDERSET(unsigned, AffairIDList);
	static AffairIDList _AffairList;
	const static unsigned _AffairOption = 2;//����ѡ������
	const static unsigned _AffairCostOption = _AffairOption - 1;//���¿������Ľ�ҵ�ѡ��
	static int _AffairCost = 2;//�������ѽ��
	struct AffairModule
	{
		AffairModule()
		{
			ResBase.clear();
			ResType.clear();
			ResModule.clear();
		}
		int calResNum(const int type, const unsigned level)
		{
			RESMAP::iterator it = ResModule.find(type);
			double rate = 1.0;
			if (it != ResModule.end())rate = it->second;
			return (level * rate + ResBase[type]);
		}
		vector<int> randomResType(const unsigned num)
		{
			vector<int> vec;
			vec.resize(num, ACTION::null);
			RESTYPEMAP tmpResType = ResType;
			int max_rdnum = 10000;
			for (unsigned n = 0; n < num; ++n)
			{
				const int rd_num = Common::randomBetween(1, max_rdnum);
				int total_num = 0;
				for (RESTYPEMAP::iterator it = tmpResType.begin(); it != tmpResType.end(); ++it)
				{
					total_num += it->second;
					if (total_num >= rd_num)
					{
						vec[n] = it->first;
						max_rdnum -= it->second;
						tmpResType.erase(it);
						break;
					}
				}
			}
			return vec;
		}
		int randomResType()
		{
			const int rd_num = Common::randomBetween(1, 10000);
			int total_num = 0;
			for (RESTYPEMAP::iterator it = ResType.begin(); it != ResType.end(); ++it)
			{
				total_num += it->second;
				if (total_num >= rd_num)return it->first;
			}
			return ACTION::null;
		}
		STDMAP(int, double, RESMAP);
		RESMAP ResModule;
		STDMAP(int, int, RESTYPEMAP);//�������
		RESTYPEMAP ResType;
		STDMAP(int, int, RESBASEMAP);//����ֵ
		RESBASEMAP ResBase;
	};
	BOOSTSHAREPTR(AffairModule, affairModulePtr);
	affairModulePtr FreeAffairModule, CostAffairModule;
	int ownerland_system::getAffairReward(const int type, const unsigned lv, const bool is_gold)
	{
		if (is_gold)
		{
			return CostAffairModule->calResNum(type, lv);
		}
		return FreeAffairModule->calResNum(type, lv);
	}


	UNORDERMAP(int, unsigned, ItemCDMAP);
	static ItemCDMAP mapItemCut;
	unsigned getCut(const int itemID)
	{
		ItemCDMAP::iterator it = mapItemCut.find(itemID);
		if (it == mapItemCut.end())return 0;
		return it->second;
	}

	UNORDERMAP(int, int, BINDTASKMAP);
	static BINDTASKMAP DailyBind;

	//�Զ������������Ͱ�
	UNORDERMAP(int, unsigned, AUTOBINDMAP);
	static AUTOBINDMAP AutoBuildMap;
	enum
	{
		idx_auto_dwellings = (0x0001 << 0), 
		idx_auto_cropland = (0x0001 << 1),
		idx_auto_mine = (0x0001 << 2),
		idx_auto_wood = (0x0001 << 3),

		idx_auto_num = 4,//����
	};
	static unsigned FullAutoTypeValue = 0xFFFFFFFF;

	unsigned ownerland_system::FullContainType()
	{
		return FullAutoTypeValue;
	}

	bool ownerland_system::VaildAutoBuildType(const unsigned containType, const int buildType)
	{
		AUTOBINDMAP::const_iterator it = AutoBuildMap.find(buildType);
		if (it == AutoBuildMap.end())return false;
		const unsigned idx = it->second;
		return (containType & (0x0001 << idx)) > 0;
	}

	void ownerland_system::initData()
	{
		AutoBuildMap[LAND::idx_building_type_dwellings] = 0;
		AutoBuildMap[LAND::idx_building_type_cropland] = 1;
		AutoBuildMap[LAND::idx_building_type_mine] = 2;
		AutoBuildMap[LAND::idx_building_type_wood] = 3;
		FullAutoTypeValue = 0;
		for (int i = 0; i < idx_auto_num; ++i)
		{
			FullAutoTypeValue += (0x0001 << i);
		}

		playerBuilds::initData();
		//�ճ������
		DailyBind[LAND::idx_building_res_cropland] = DAILY::market_buy_food;
		DailyBind[LAND::idx_building_res_wood] = DAILY::market_buy_wood;
		DailyBind[LAND::idx_building_res_iron] = DAILY::market_buy_iron;
		DailyBind[LAND::idx_building_res_silver] = DAILY::market_buy_silver;

		cout << "load owner land system ..." << endl;
		{//���߼�CD
			mapItemCut.clear();
			Json::Value json = Common::loadJsonFile("./instance/onwerland/item_cut_cd.json");
			for (unsigned i = 0; i < json.size(); ++i)
			{
				mapItemCut[json[i]["id"].asInt()] = json[i]["cut"].asUInt();
			}
		};

		{//�������
			cout << "load land and arms realte ..." << endl;//���ֽ�����ϵ
			FileJsonSeq soldierList = Common::loadFileJsonFromDir(soildierDataDirStr);
			std::map<int, int> relateMap;
			for (unsigned i = 0; i < soldierList.size(); ++i)
			{
				Json::Value& man = soldierList[i];
				relateMap[man["relateBuild"].asInt()] = man[armsTypeStr].asInt();
			}

			FileJsonSeq json_list = Common::loadFileJsonFromDir("./instance/onwerland/building/");
			for (unsigned i = 0; i < json_list.size(); ++i)
			{
				Json::Value& json = json_list[i];
				LANDCONFIG::landCFGPtr config = Creator<LANDCONFIG::landConfig>::Create();
				config->buildType = (LAND::BuildingType)json["buildType"].asInt();
				config->beginLevel = json["beginLevel"].asUInt();
				config->endLevel = json["endLevel"].asUInt();
				config->staticBuild = (config->beginLevel == config->endLevel);
				config->buildMaxNum = json["maxNum"].asInt();
				config->levelSpace = json["space"].asInt();
				config->relateArms = relateMap[config->buildType];
				config->autoBuild = (AutoBuildMap.find(config->buildType) != AutoBuildMap.end());
				Json::Value& open_json = json["open"];
				for (unsigned n = 0; n < open_json.size(); ++n)
				{
					LANDCONFIG::openBuild open;
					open.iFeod = open_json[n]["iFeod"].asInt();
					open.openType = open_json[n]["openType"].asInt();
					open.openVal = open_json[n]["openVal"].asInt();
					config->openLimit[open.iFeod] = open;
				}
				Json::Value& level_json = json["level"];
				for (unsigned n = 0; n < level_json.size(); ++n)
				{
					Json::Value& sg_level = level_json[n];
					LANDCONFIG::buildPtr build_ptr = Creator<LANDCONFIG::landBuild>::Create();
					build_ptr->buildType = config->buildType;//�������ڵĽ�������
					build_ptr->iBuildLv = sg_level["iBuildLv"].asUInt();
					build_ptr->iOutIntervalTime = sg_level["outTime"].asUInt();
					build_ptr->iOutValue = sg_level["outVal"].asDouble();
					build_ptr->iOutType = (LAND::BuildResource)sg_level["outType"].asInt();
					build_ptr->iBuildCD = sg_level["iBuildCD"].asUInt();
					build_ptr->iMaxout = sg_level["iMaxout"].asUInt();
					build_ptr->iOutRelateID = (LAND::HomeType)sg_level["iOutRelateID"].asInt();
					build_ptr->iCapacityRelateID = (LAND::HomeType)sg_level["iCapacityRelateID"].asInt();
					Json::Value& sg_cost = sg_level["upCost"];
					Json::Value& sg_attri = sg_level["attribute"];

					build_ptr->attriList.clear();
					for (unsigned indexAttribute = 0; indexAttribute < sg_attri.size() && indexAttribute < characterNum; ++indexAttribute)
					{
						const int val = sg_attri[indexAttribute].asInt();
						if (val > 0)
						{
							build_ptr->attriList.push_back(AttriBase(AttributeIDX(indexAttribute), val));
						}
					}
					build_ptr->upCost.clear();
					for (unsigned index = 0; index < sg_cost.size(); ++index)
					{
						const int type = sg_cost[index]["type"].asInt();
						const int val = sg_cost[index]["val"].asInt();
						if (val > 0)
						{
							build_ptr->upCost[type] = val;
						}
					}
					config->levelBuild[build_ptr->iBuildLv] = build_ptr;
				}
				BuildConfigs[config->buildType] = config;
			}
			cout << "building.json size=" << BuildConfigs.size() << endl;
		};


		Json::Value actionVip = Common::loadJsonFile("./instance/onwerland/actionvip.json");
		for (unsigned i = 0; i < actionVip.size(); ++i)
		{
			int iVip = actionVip[i]["vip"].asInt();
			int iAction = actionVip[i]["action"].asInt();
			mapActionVip[iVip] = iAction;
		}
		cout << "actionVip.json size=" << mapActionVip.size() << endl;

		Json::Value actionCash = Common::loadJsonFile("./instance/onwerland/actioncash.json");
		for (unsigned i = 0; i < actionCash.size(); ++i)
		{
			int iNo = actionCash[i]["no"].asInt();
			int iCash = actionCash[i]["cash"].asInt();
			mapActionCash[iNo] = iCash;
		}
		cout << "actionCash.json size=" << mapActionCash.size() << endl;

		{
			_AffairList.clear();
			Json::Value affairsJson = Common::loadJsonFile("./instance/onwerland/affairs.json");
			const unsigned affair_size = affairsJson["size"].asUInt();
			for (unsigned i = 0; i < affair_size; ++i)
			{
				_AffairList.insert(i + 1);//�����¼�ID
			}
			_AffairCost = affairsJson.isMember("cost") ? affairsJson["cost"].asInt() : _AffairCost;//
			FreeAffairModule = Creator<AffairModule>::Create();
			CostAffairModule = Creator<AffairModule>::Create();
			//���
			for (unsigned n = 0; n < affairsJson["freeRes"].size(); ++n)
			{
				FreeAffairModule->ResModule[affairsJson["freeRes"][n][0u].asInt()] = affairsJson["freeRes"][n][1u].asDouble();
				FreeAffairModule->ResBase[affairsJson["freeRes"][n][0u].asInt()] = affairsJson["freeRes"][n][2u].asInt();
				FreeAffairModule->ResType[affairsJson["freeRes"][n][0u].asInt()] = affairsJson["freeRes"][n][3u].asInt();
			}
			//�շ�
			for (unsigned n = 0; n < affairsJson["costRes"].size(); ++n)
			{
				CostAffairModule->ResModule[affairsJson["costRes"][n][0u].asInt()] = affairsJson["costRes"][n][1u].asDouble();
				CostAffairModule->ResBase[affairsJson["costRes"][n][0u].asInt()] = affairsJson["costRes"][n][2u].asInt();
				CostAffairModule->ResType[affairsJson["costRes"][n][0u].asInt()] = affairsJson["costRes"][n][3u].asInt();
			}
		};

		FileJsonSeq mapmilitaryJson = Common::loadFileJsonFromDir("./instance/onwerland/military/");
		for (unsigned j = 0; j < mapmilitaryJson.size(); ++j)
		{
			Json::Value& militaryJson = mapmilitaryJson[j];

			for (unsigned i = 0; i < militaryJson.size(); ++i)
			{
				int	iID = militaryJson[i]["id"].asInt();
				unsigned iLv = militaryJson[i]["lv"].asUInt();
				LAND::MilitaryTechType eType = (LAND::MilitaryTechType)militaryJson[i]["type"].asInt();
				unsigned iOpenLv = militaryJson[i]["openlv"].asUInt();
				int	iPreID = militaryJson[i]["preid"].asInt();
				unsigned iPreLv = militaryJson[i]["prelv"].asUInt();
				Json::Value warattr = militaryJson[i]["warattr"];
				Json::Value homeattr = militaryJson[i]["homeattr"];
				Json::Value lvupdata = militaryJson[i]["lvupdata"];
// 				BOOST_ASSERT((int)warattr.size() < characterNum);
// 				BOOST_ASSERT((int)homeattr.size() < LAND::idx_home_type_end);

				militaryTechKey kmilitaryTechKey;
				kmilitaryTechKey.iID = iID;
				kmilitaryTechKey.iLv = iLv;

				if (mapMilitaryTech.find(kmilitaryTechKey) != mapMilitaryTech.end()) { continue; }
				mapMilitaryTech[kmilitaryTechKey] = Creator<militaryTech>::Create();
				militaryTechPtr militaryTechPtr_ptr = mapMilitaryTech[kmilitaryTechKey];
				militaryTechPtr_ptr->iID = iID;
				militaryTechPtr_ptr->iLv = iLv;
				militaryTechPtr_ptr->eType = eType;
				militaryTechPtr_ptr->iOpenLv = iOpenLv;
				militaryTechPtr_ptr->iPreID = iPreID;
				militaryTechPtr_ptr->iPreLv = iPreLv;
				militaryTechPtr_ptr->warAttri.clear();
				for (unsigned indexAttribute = 0; indexAttribute < warattr.size() && indexAttribute < characterNum; ++indexAttribute) 
				{
					const int val = warattr[indexAttribute].asInt();
					if (val > 0)
					{
						militaryTechPtr_ptr->warAttri.push_back(AttriBase((AttributeIDX)indexAttribute, val));
					}
				}
				militaryTechPtr_ptr->homeAttri.clear();
				for (unsigned indexAttribute = 0; indexAttribute < homeattr.size() && indexAttribute < LAND::idx_home_type_num; ++indexAttribute)
				{
					const int val = homeattr[indexAttribute].asInt();
					if (val > 0)
					{
						militaryTechPtr_ptr->homeAttri.push_back(militaryAdd((LAND::HomeType)indexAttribute, val));
					}
				}
				
				for (unsigned idx = 0; idx < LAND::idx_building_res_end; ++idx)
				{
					const string key = Common::toString(idx);
					if (lvupdata.isMember(key)) { militaryTechPtr_ptr->buildUpgradeMAP[LAND::BuildResource(idx)] = lvupdata[key].asInt(); }
				}
				if (iLv == 1) { mapMilitaryTechLVOne[iID] = militaryTechPtr_ptr; }
			}
		}
		cout << "militaryJson.json size=" << mapMilitaryTech.size() << endl;

		Json::Value officialJson = Common::loadJsonFile("./instance/onwerland/official.json");
		for (unsigned i = 0; i < officialJson.size(); ++i)
		{
			officialResPtr officialResPtr_ptr = Creator<officialRes>::Create();
			officialResPtr_ptr->sName = officialJson[i]["name"].asString();
			officialResPtr_ptr->iLv = officialJson[i]["lv"].asInt();
			officialResPtr_ptr->iNeedFame = officialJson[i]["fame"].asInt();
			officialResPtr_ptr->iNeedlv = officialJson[i]["needlv"].asInt();
			officialResPtr_ptr->iNeedManNum = officialJson[i]["mannum"].asInt();
			officialResPtr_ptr->iChartid = officialJson[i]["chartid"].asInt();
			officialResPtr_ptr->iTechID = officialJson[i]["tech"].asInt();
			officialResPtr_ptr->iTechlv = officialJson[i]["techlv"].asInt();
			officialResPtr_ptr->iManStar = officialJson[i]["manstar"].asInt();
			officialResPtr_ptr->iManStarNum = officialJson[i]["manstarnum"].asInt();
			officialResPtr_ptr->eBuildType = (LAND::BuildingType)officialJson[i]["buildtype"].asInt();
			officialResPtr_ptr->iBuildTypeLv = officialJson[i]["buildtypelv"].asInt();
			officialResPtr_ptr->iBuildLv = officialJson[i]["buildlv"].asInt();
			officialResPtr_ptr->iBuildNum = officialJson[i]["buildnum"].asInt();
			officialResPtr_ptr->iSilver = officialJson[i]["silver"].asInt();
			
			Json::Value& award = officialJson[i]["award"];

			ACTION::BoxList boxList = actionFormatBox(award);
			officialResPtr_ptr->kGiveRes[0] = boxList;
			ACTION::Box addBox;
			addBox.actionID = ACTION::man;
			{//κ
				addBox.boxData._Res.val = officialJson[i]["wei"].asInt();
				ACTION::BoxList newBoxList = boxList;
				if (addBox.boxData._Res.val > 0)newBoxList.push_back(addBox);
				officialResPtr_ptr->kGiveRes[1] = newBoxList;
			};
			{//��
				addBox.boxData._Res.val = officialJson[i]["shu"].asInt();
				ACTION::BoxList newBoxList = boxList;
				if (addBox.boxData._Res.val > 0)newBoxList.push_back(addBox);
				officialResPtr_ptr->kGiveRes[2] = newBoxList;
			}
			{//��
				addBox.boxData._Res.val = officialJson[i]["wu"].asInt();
				ACTION::BoxList newBoxList = boxList;
				if (addBox.boxData._Res.val > 0)newBoxList.push_back(addBox);
				officialResPtr_ptr->kGiveRes[3] = newBoxList;
			};
			
			mapOfficial[officialResPtr_ptr->iLv] = officialResPtr_ptr;
		}
		cout << "official.json size=" << mapOfficial.size() << endl;

		marketResPtr marketResPtrMax_ptr = marketResPtr();
		Json::Value marketJson = Common::loadJsonFile("./instance/onwerland/market.json");
		for (unsigned i = 0; i < marketJson.size(); ++i)
		{
			marketResPtr marketResPtr_ptr = Creator<marketRes>::Create();
			marketResPtr_ptr->iBuyNum = marketJson[i]["num"].asInt();
			marketResPtr_ptr->iSilver = marketJson[i]["silver"].asInt();
			marketResPtr_ptr->iCropland = marketJson[i]["cropland"].asInt();
			marketResPtr_ptr->iWood = marketJson[i]["wood"].asInt();
			marketResPtr_ptr->iIron = marketJson[i]["iron"].asInt();
			mapMarket[marketResPtr_ptr->iBuyNum] = marketResPtr_ptr;
			if (!marketResPtrMax_ptr) { marketResPtrMax_ptr = marketResPtr_ptr; }
			if (marketResPtrMax_ptr->iBuyNum < marketResPtr_ptr->iBuyNum) { marketResPtrMax_ptr = marketResPtr_ptr; }
		}
		mapMarket[0] = marketResPtrMax_ptr;// �洢�����Ǹ�
		cout << "marketJson.json size=" << mapMarket.size() << endl;
	}

	LANDCONFIG::landCFGPtr ownerland_system::getBuildConfig(const int eBuildingType)
	{
		LANDCONFIG::CONFIGMAP::iterator itr = BuildConfigs.find(eBuildingType);
		if (itr == BuildConfigs.end()) { return LANDCONFIG::landCFGPtr(); }
		return itr->second;
	}

	vector<AFFAIE::affairDataPtr> ownerland_system::randomAffairs(const unsigned rd_num, const vector<unsigned>& filter_vec)
	{
		vector<AFFAIE::affairDataPtr> data_list;

		AffairIDList tmp_list = _AffairList;
		for (unsigned i = 0; i < filter_vec.size(); ++i)
		{
			tmp_list.erase(filter_vec[i]);
		}
		vector<unsigned> random_vec;
		for (AffairIDList::iterator it = tmp_list.begin(); it != tmp_list.end(); ++it)
		{
			random_vec.push_back(*it);
		}

		random_shuffle(random_vec.begin(), random_vec.end());

		for (unsigned i = 0; i < random_vec.size() && i < rd_num; ++i)
		{
			AFFAIE::affairDataPtr ptr = Creator<AFFAIE::AffairData>::Create();
			ptr->iFid = random_vec[i];
			ptr->isGold = Common::randomOk(0.5);
			if (ptr->isGold)
			{
				ptr->freeType = FreeAffairModule->randomResType();
				ptr->costType = CostAffairModule->randomResType();
			}
			else
			{
				vector<int> vecs = FreeAffairModule->randomResType(2);
				ptr->freeType = vecs[0];
				ptr->costType = vecs[1];
			}
			data_list.push_back(ptr);
		}

		return data_list;
	}

	const militaryTechPtr ownerland_system::getMilitaryTechData(const int iID, const unsigned iLv)
	{
		militaryTechKey kmilitaryTechKey;
		kmilitaryTechKey.iID = iID;
		kmilitaryTechKey.iLv = iLv;
		ConfigMilitaryTechMap::iterator itr = mapMilitaryTech.find(kmilitaryTechKey);
		if (itr == mapMilitaryTech.end()) { return militaryTechPtr(); }
		return itr->second;
	}

	const officialResPtr ownerland_system::getOfficialRes(int iLV)
	{
		ConfigOfficialMap::iterator itr = mapOfficial.find(iLV);
		if (itr == mapOfficial.end()) { return officialResPtr(); }
		return itr->second;
	}

	const marketResPtr ownerland_system::getMarketRes(int iBuyNum)
	{
		ConfigMarketResMap::iterator itr = mapMarket.find(iBuyNum);
		if (itr != mapMarket.end()) { return itr->second; }
		itr = mapMarket.find(0);
		if (itr == mapMarket.end()) { return marketResPtr(); }
		return itr->second;
	}

	int ownerland_system::checkResource(playerDataPtr player, const int type, const int val)
	{
		if (type == LAND::idx_building_res_cropland) { if (player->Res().getFood() < val) { return err_food_not_enough; } }		// 1 : ��ʳerr_food_not_enough
		else if (type == LAND::idx_building_res_silver) { if (player->Res().getSilver() < val) { return err_silver_not_enough; } }	// 2 : ����err_silver_not_enough
		else if (type == LAND::idx_building_res_iron)	{ if (player->Res().getIron() < val) { return err_iron_not_enough; } }			// 3 : ����err_iron_not_enough
		else if (type == LAND::idx_building_res_wood)	{ if (player->Res().getWood() < val) { return err_wood_not_enough; } }			// 4 : ľ��err_wood_not_enough
		else if (type == LAND::idx_building_res_soldier) { if (player->Res().getTroops() < val) { return err_troops_not_enough; } }	// 5 : ����err_troops_not_enough
		else if (type == LAND::idx_building_res_gold)	{ if (player->Res().getGold() < val) { return err_gold_not_enough; } }			// 6 : ���err_gold_not_enough
		else if (type == LAND::idx_building_res_ticket) { if (player->Res().getTicket() < val) { return err_ticket_not_enough; } }	// 7 : ���ͽ��err_ticket_not_enough
		else if (type == LAND::idx_building_res_merit) { if (player->Res().getMerit() < val) { return err_merit_not_enough; } }		// 8 : ����err_merit_not_enough
		else if (type == LAND::idx_building_res_fame)	{ if (player->Res().getFame() < val) { return err_fame_not_enough; } }			// 9 : ����err_fame_not_enough
		else if (type == LAND::idx_building_res_action) { if (player->Res().getAction() < val) { return err_action_not_enough; } }	// 10 : ����err_action_not_enough
		return res_sucess;
	}

	int ownerland_system::checkResource(playerDataPtr player, LAND::resMap kResource, const double rate /* = 1.0 */)
	{
		for (LAND::resMap::iterator itr = kResource.begin(); itr != kResource.end(); ++itr)
		{
			const int resourceType = itr->first;
			int iCost = itr->second * rate;
			if (resourceType == LAND::idx_building_res_cropland) { if (player->Res().getFood() < iCost) { return err_food_not_enough; } }		// 1 : ��ʳerr_food_not_enough
			else if (resourceType == LAND::idx_building_res_silver) { if (player->Res().getSilver() < iCost) { return err_silver_not_enough; } }	// 2 : ����err_silver_not_enough
			else if (resourceType == LAND::idx_building_res_iron)	{ if (player->Res().getIron() < iCost) { return err_iron_not_enough; } }			// 3 : ����err_iron_not_enough
			else if (resourceType == LAND::idx_building_res_wood)	{ if (player->Res().getWood() < iCost) { return err_wood_not_enough; } }			// 4 : ľ��err_wood_not_enough
			else if (resourceType == LAND::idx_building_res_soldier) { if (player->Res().getTroops() < iCost) { return err_troops_not_enough; } }	// 5 : ����err_troops_not_enough
			else if (resourceType == LAND::idx_building_res_gold)	{ if (player->Res().getGold() < iCost) { return err_gold_not_enough; } }			// 6 : ���err_gold_not_enough
			else if (resourceType == LAND::idx_building_res_ticket) { if (player->Res().getTicket() < iCost) { return err_ticket_not_enough; } }	// 7 : ���ͽ��err_ticket_not_enough
			else if (resourceType == LAND::idx_building_res_merit) { if (player->Res().getMerit() < iCost) { return err_merit_not_enough; } }		// 8 : ����err_merit_not_enough
			else if (resourceType == LAND::idx_building_res_fame)	{ if (player->Res().getFame() < iCost) { return err_fame_not_enough; } }			// 9 : ����err_fame_not_enough
			else if (resourceType == LAND::idx_building_res_action) { if (player->Res().getAction() < iCost) { return err_action_not_enough; } }	// 10 : ����err_action_not_enough
		}

		return res_sucess;
	}

	void ownerland_system::alterResource(playerDataPtr player, const int type, const int val, bool bAdd)
	{
		const int iCost = bAdd ? val : -val;
		if (type == LAND::idx_building_res_cropland) { player->Res().alterFood(iCost); }					// 1 : ��ʳ
		else if (type == LAND::idx_building_res_silver) { player->Res().alterSilver(iCost); }					// 2 : ����
		else if (type == LAND::idx_building_res_iron)	{ player->Res().alterIron(iCost); }						// 3 : ���� 
		else if (type == LAND::idx_building_res_wood)	{ player->Res().alterWood(iCost); }						// 4 : ľ��
		else if (type == LAND::idx_building_res_soldier) { player->Res().alterTroops(iCost); }					// 5 : ����
		else if (type == LAND::idx_building_res_gold)	{ player->Res().alterGold(iCost); }						// 6 : ���
		else if (type == LAND::idx_building_res_ticket) { player->Res().alterTicket(iCost); }					// 7 : ���ͽ��
		else if (type == LAND::idx_building_res_merit) { player->Res().alterMerit(iCost); }						// 8 : ����
		else if (type == LAND::idx_building_res_fame)	{ player->Res().alterFame(iCost); }						// 9 : ����
		else if (type == LAND::idx_building_res_action) { player->Res().alterAction(iCost); }					// 10 : ����
		else if (type == LAND::idx_building_res_exp && bAdd) { player->Info().addExp(iCost); }	// 11 : ����ֵ
	}

	void ownerland_system::alterResource(playerDataPtr player, LAND::resMap kResource, bool bAdd, const double rate /* = 1.0 */)
	{
		for (LAND::resMap::iterator itr = kResource.begin(); itr != kResource.end(); ++itr)
		{
			const int resourceType = itr->first;
			const int iCost = bAdd ? itr->second * rate : itr->second*(-rate);
			if (resourceType == LAND::idx_building_res_cropland) { player->Res().alterFood(iCost); }					// 1 : ��ʳ
			if (resourceType == LAND::idx_building_res_silver) { player->Res().alterSilver(iCost); }					// 2 : ����
			if (resourceType == LAND::idx_building_res_iron)	{ player->Res().alterIron(iCost); }						// 3 : ���� 
			if (resourceType == LAND::idx_building_res_wood)	{ player->Res().alterWood(iCost); }						// 4 : ľ��
			if (resourceType == LAND::idx_building_res_soldier) { player->Res().alterTroops(iCost); }					// 5 : ����
			if (resourceType == LAND::idx_building_res_gold)	{ player->Res().alterGold(iCost); }						// 6 : ���
			if (resourceType == LAND::idx_building_res_ticket) { player->Res().alterTicket(iCost); }					// 7 : ���ͽ��
			if (resourceType == LAND::idx_building_res_merit) { player->Res().alterMerit(iCost); }						// 8 : ����
			if (resourceType == LAND::idx_building_res_fame)	{ player->Res().alterFame(iCost); }						// 9 : ����
			if (resourceType == LAND::idx_building_res_action) { player->Res().alterAction(iCost); }					// 10 : ����
			if (resourceType == LAND::idx_building_res_exp && bAdd) { player->Info().addExp(iCost); }	// 11 : ����ֵ
		}
	}

	void ownerland_system::getBaseData(net::Msg& m, Json::Value& r)
	{
		ReadJsonArray;
		playerDataPtr player = player_mgr.getPlayer(m.playerID);
		if (!player)Return(r, err_illedge);

		player->Builds().updateAll();//������Ϣ
		player->Orders()._auto_update();//����
		player->BuildTeam()._auto_update();//������ж���
		player->Affair()._auto_update();
		player->Admin()._auto_update();//ί��
		player->Research().sendResearch();//�Ƽ�
		player->Market().sendMarketData();//����
//		player->Onwerland->sendLandAdminLog(true);//ί������
		Return(r, res_sucess);
	}

	void ownerland_system::getOneData(net::Msg& m, Json::Value& r)
	{
		ReadJsonArray;
		playerDataPtr player = player_mgr.getPlayer(m.playerID);
		if (!player)Return(r, err_illedge);

		const int iID = js_msg[0u].asInt();
		const int iPos = js_msg[1u].asInt();
		const int iBuildingID = js_msg[2u].asInt();

//		player->Builds().sendBuildData(iID, iPos, iBuildingID);
	}

	int ownerland_system::buildToWork(playerDataPtr player, const int iFeod, const int iType, const int iPos, const LAND::BuildKey replaceKey)
	{
		LANDCONFIG::landCFGPtr config = ownerland_sys.getBuildConfig(iType);
		if (!config)return err_illedge;
		FEOD::buildPtr build_ptr = player->Builds().getBuild(iFeod, iType, iPos);
		if (!build_ptr)return err_illedge;
		LANDCONFIG::buildPtr config_level = config->findLV(build_ptr->iBuildLv);
		if (!config_level)return err_illedge;

		double rate = 1.0;
		cfgManPtr man_config = player->Admin().getVaildAdmin(iFeod, LAND::idx_adminType_builder);
		if (man_config)rate = 1.0 - man_config->costRes / 10000.0;
		rate = rate < 0.0 ? 0.0 : rate;

		int res = checkResource(player, config_level->upCost, rate);
		if (res != res_sucess)return res;

		res = player->BuildTeam().upgradeBuilding(iFeod, iType, iPos, replaceKey);
		if (res != res_sucess)return res;

		alterResource(player, config_level->upCost, false, rate);
		qValue log_arr_json(qJson::qj_array);
		for (LAND::resMap::iterator it = config_level->upCost.begin(); it != config_level->upCost.end(); ++it)
		{
			qValue log_sg_json(qJson::qj_array);
			log_sg_json.append(it->first);
			log_sg_json.append(it->second * rate);
			log_arr_json.append(log_sg_json);
		}
		Log(DBLOG::strLogUpgradeBuild, player, 0, iFeod, iType, iPos, config_level->iBuildLv, 
			man_config ? man_config->manID : -1, rate, "", log_arr_json.toIndentString());

		//TaskMgr::update(player, Task::BuildTimes, 1);
		return res_sucess;
	}

	void ownerland_system::buildingUpgrade(net::Msg& m, Json::Value& r)
	{
		ReadJsonArray;
		playerDataPtr player = player_mgr.getPlayer(m.playerID);
		if (!player)Return(r, err_illedge);

		const int iFeod = js_msg[0u].asInt();
		const int iType = js_msg[1u].asInt();
		const int iPos = js_msg[2u].asInt();

		const int res = buildToWork(player, iFeod, iType, iPos);

		r[strMsg][1u] = iFeod;
		r[strMsg][2u] = iType;
		r[strMsg][3u] = iPos;
		Return(r, res);
	}

	void ownerland_system::buildingHarvest(net::Msg& m, Json::Value& r)
	{
		ReadJsonArray;
		playerDataPtr player = player_mgr.getPlayer(m.playerID);
		if (!player)Return(r, err_illedge);

		vector<LAND::BuildKey> buildList;

		for (unsigned i = 0; i < js_msg.size() && i < 32; ++i)
		{
			buildList.push_back(LAND::BuildKey(js_msg[i][0u].asInt(), js_msg[i][1u].asInt(), js_msg[i][2u].asInt()));
		}

		if (!player->Builds().tryHarvest(buildList))
		{
			Return(r, err_can_not_harvest);
		}
	}

	void ownerland_system::fastBuild(net::Msg& m, Json::Value& r)
	{
		ReadJsonArray;
		playerDataPtr player = player_mgr.getPlayer(m.playerID);
		if (!player)Return(r, err_illedge);

		const int iFeod = js_msg[0u].asInt();
		const int iType = js_msg[1u].asInt();
		const int iPos = js_msg[2u].asInt();

		const unsigned now = Common::gameTime();
		const unsigned cd = player->BuildTeam().getCD(iFeod, iType, iPos);
		if (now > cd || cd <= (FREE_BUILD_CD_TIME + now))Return(r, err_illedge);
		const int cash = (cd - now - FREE_BUILD_CD_TIME + 59) / 60;
		if (cash < 1)Return(r, err_illedge);
		if (player->Res().getCash() < cash) Return(r, err_cash_not_enough);
		player->BuildTeam().clearCD(iFeod, iType, iPos);
		player->Res().alterCash(-cash);

		r[strMsg][1u] = cash;
		Return(r, res_sucess);
	}

	void ownerland_system::freeRemoveBuildingCD(net::Msg& m, Json::Value& r)
	{
		ReadJsonArray;
		playerDataPtr player = player_mgr.getPlayer(m.playerID);
		if (!player)Return(r, err_illedge);

		const int iFeod = js_msg[0u].asInt();
		const int iType = js_msg[1u].asInt();
		const int iPos = js_msg[2u].asInt();

		const unsigned now = Common::gameTime();
		const unsigned cd = player->BuildTeam().getCD(iFeod, iType, iPos);
		if ((now + FREE_BUILD_CD_TIME) < cd)Return(r, err_illedge);

		player->BuildTeam().clearCD(iFeod, iType, iPos);

		Return(r, res_sucess);
	}

	void ownerland_system::getFastBuild(net::Msg& m, Json::Value& r)
	{
		ReadJsonArray;
		playerDataPtr player = player_mgr.getPlayer(m.playerID);
		if (!player)Return(r, err_illedge);

		const int iFeod = js_msg[0u].asInt();
		const int iType = js_msg[1u].asInt();
		const int iPos = js_msg[2u].asInt();

		const unsigned now = Common::gameTime();
		const unsigned cd = player->BuildTeam().getCD(iFeod, iType, iPos);
		int cash = 0;
		if (cd > (FREE_BUILD_CD_TIME + now))
		{
			cash = (cd - now - FREE_BUILD_CD_TIME + 59) / 60;
		}
		
		r[strMsg][1u] = iFeod;
		r[strMsg][2u] = iType;
		r[strMsg][3u] = iPos;
		r[strMsg][4u] = cash;
		Return(r, res_sucess);
	}

	const int CostBuildTeamBuy[] = { 0, 100, 500 };
	void ownerland_system::buyBuildTeam(net::Msg& m, Json::Value& r)
	{
		playerDataPtr player = player_mgr.getPlayer(m.playerID);
		if (!player)Return(r, err_illedge);
		ReadJsonArray;
		const int iID = js_msg[0u].asInt();
		const unsigned buildTeam_size = player->BuildTeam().buildTeamSize(iID);
		const unsigned vip_lv = player->Info().VipLv();
		if (vip_lv < 1 && buildTeam_size > 0)Return(r, err_vip_lv_too_low);
		if (vip_lv < 3 && buildTeam_size > 1)Return(r, err_vip_lv_too_low);
		int iCash = CostBuildTeamBuy[buildTeam_size];//������ �����, 100, 500���
		if (player->Res().getCash() < iCash) Return(r, err_cash_not_enough);
		const int res = player->BuildTeam().addBuildTeam(iID);
		if (res == res_sucess)
		{
			player->Res().alterCash(-iCash);
			Log(DBLOG::strLogBuyBuildTeam, player, -1, iID, iCash);
		}
		Return(r, res);
	}

	void ownerland_system::buyAction(net::Msg& m, Json::Value& r)
	{
		ReadJsonArray;
		playerDataPtr player = player_mgr.getPlayer(m.playerID);
		if (!player)Return(r, err_illedge);

		unsigned int uiVip = player->Info().VipLv();
		if (mapActionVip.find(uiVip) == mapActionVip.end()) Return(r, err_illedge);
		int iBuyActionNum = player->Orders().getBuyNum();

		int iNum = mapActionVip[uiVip];
		if ((iBuyActionNum + 1) > iNum)Return(r, err_buy_action_max);

		// ��鹺�����
		if (mapActionCash.find(iBuyActionNum + 1) == mapActionCash.end()) Return(r, err_illedge);

		int iCostCash = mapActionCash[iBuyActionNum + 1];
		if (player->Res().getCash() < iCostCash)Return(r, err_cash_not_enough);

		// ��Ǯ
		player->Res().alterCash(iCostCash*(-1));
		// ���Ӿ���
		player->Res().alterAction(MAX_VIP_BUY_ACTION_NUM);
		// ���ӽ��칺�����Ĵ���
		player->Orders().alterBuyNum(1);

		r[strMsg][0u] = res_sucess;
		r[strMsg][1u] = iCostCash;
	}

	void ownerland_system::setAffairs(net::Msg& m, Json::Value& r)
	{
		playerDataPtr player = player_mgr.getPlayer(m.playerID);
		if (!player)Return(r, err_illedge);
		if (!player->Builds().isBuildValid(LAND::idx_building_type_parliament))Return(r, err_illedge);
		ReadJsonArray;
		const unsigned opt = js_msg[0u].asUInt();

		if (opt >= _AffairOption)Return(r, err_illedge);
		AFFAIE::affairDataPtr ptr = player->Affair().getTop();
		if (!ptr)Return(r, err_illedge);

		bool cost_gold = (opt == _AffairCostOption && ptr->isGold);
		int cost = 0;
		if (cost_gold)
		{
			cost = _AffairCost;
			if (player->Res().getCash() < cost)Return(r, err_cash_not_enough);
		}
		int won_reward = 0;
		int won_type = ACTION::null;
		if (opt == 0)
		{
			won_type = ptr->freeType;
			won_reward = getAffairReward(ptr->freeType, player->LV(), false);
		}
		else
		{
			won_type = ptr->costType;
			won_reward = getAffairReward(ptr->costType, player->LV(), ptr->isGold);
		}
		if (cost_gold)
		{
			player->Res().alterCash(-cost);
		}
		const int res = player->Affair().setAffairs(opt, false);
		if (res == res_sucess)
		{
			player->Daily().tickTask(DAILY::deal_affair);

			AFFAIE::affairDataPtr show_ptr = player->Affair().getShowTop();

			{//��ǰҪ���Ŷ���������
				Json::Value c_json;
				c_json.append(ptr->iFid);
				c_json.append(ptr->isGold);
				c_json.append(ptr->choices);
				c_json.append(ptr->freeType);
				c_json.append(ptr->costType);
				c_json.append(ptr->freeVal);
				c_json.append(ptr->costVal);
				r[strMsg][1u] = c_json;
			};
			{//��һ��Ҫ��ʾ������
				Json::Value c_json;
				c_json.append(show_ptr->iFid);
				c_json.append(show_ptr->isGold);
				c_json.append(show_ptr->choices);
				c_json.append(show_ptr->freeType);
				c_json.append(show_ptr->costType);
				c_json.append(ownerland_sys.getAffairReward(show_ptr->freeType, player->LV(), false));
				c_json.append(ownerland_sys.getAffairReward(show_ptr->costType, player->LV(), show_ptr->isGold));
				r[strMsg][2u] = c_json;
			};
			r[strMsg][3u] = player->Affair().getLeaveEvent();
			alterResource(player, won_type, won_reward, true);
			Log(DBLOG::strLogAffair, player, -1, won_type, won_reward, opt, ptr->isGold, cost, ptr->iFid);
		}
		Return(r, res);
	}

	void ownerland_system::landAppoint(net::Msg& m, Json::Value& r)
	{
		playerDataPtr player = player_mgr.getPlayer(m.playerID);
		if (!player)Return(r, err_illedge);
		//if (player->Info().Nation() == Kingdom::null)Return(r, err_illedge);
		if (!player->War().isChallengeChaper(1001))Return(r, err_illedge);

		ReadJsonArray;
		const int iFeod = js_msg[0u].asInt();
		const LAND::LandAdminType type = (LAND::LandAdminType)js_msg[1u].asInt();
		const int manID = js_msg[2u].asInt();
		const unsigned containType = (js_msg[3u].asUInt() & FullAutoTypeValue);
		unsigned final_contain = containType;
		if (type == LAND::idx_adminType_builder)
		{
			if (0 >= containType)Return(r, err_illedge);
		}
		else
		{
			final_contain = FullContainType();
		}
		const int res = player->Admin().appointMan(iFeod, type, manID, final_contain);
		if (res == res_sucess)
		{
			player->Daily().tickTask(DAILY::land_admin);
		}
		Return(r, res);
	}

	void ownerland_system::landNotAppoint(net::Msg& m, Json::Value& r)
	{
		playerDataPtr player = player_mgr.getPlayer(m.playerID);
		if (!player)Return(r, err_illedge);


		ReadJsonArray;
		const int iFeod = js_msg[0u].asInt();
		const LAND::LandAdminType type = (LAND::LandAdminType)js_msg[1u].asInt();
		const int res = player->Admin().outgoingMan(iFeod, type);
		Return(r, res);
	}

	void ownerland_system::landAddAppointTime(net::Msg& m, Json::Value& r)
	{
		playerDataPtr player = player_mgr.getPlayer(m.playerID);
		if (!player)Return(r, err_illedge);

		ReadJsonArray;
		const int iFeod = js_msg[0u].asInt();
		const LAND::LandAdminType type = (LAND::LandAdminType)js_msg[1u].asInt();
		const int beenAdd = player->Admin().getAddTimes(iFeod, type);
		const int cost = (beenAdd + 1) * 10;
		if (cost > player->Res().getCash())Return(r, err_cash_not_enough);
		const int res = player->Admin().addAppoint(iFeod, type, 3600);//����1��Сʱ
		if (res == res_sucess)
		{
			player->Res().alterCash(-cost);
		}
		Return(r, res_sucess);
	}

	void ownerland_system::militaryTechUpgrade(net::Msg& m, Json::Value& r)
	{
		ReadJsonArray;
		playerDataPtr player = player_mgr.getPlayer(m.playerID);
		if (!player)Return(r, err_illedge);

		const int iID = js_msg[0u].asInt();
		unsigned iTimes = js_msg[1u].asUInt();
		const int result = player->Research().researchUpgrade(iID, iTimes);
		//if (result != res_sucess)Return(r, result);

		r[strMsg][1u] = iTimes;
		Return(r, result);
	}

	void ownerland_system::marketBuyRes(net::Msg& m, Json::Value& r)
	{
		ReadJsonArray;
		playerDataPtr player = player_mgr.getPlayer(m.playerID);
		if (!player)Return(r, err_illedge);

		const int eResource = js_msg[0u].asInt();
		int iAddRes = 0;
		float fOdds = 0;
		int iExtraRes = 0;
		int iRet = player->Market().marketBuyRes((LAND::BuildResource)eResource, iAddRes, fOdds, iExtraRes);

		//player->Onwerland->sendMarketData();

		{
			//����
			if (iRet == res_sucess)
			{
				player->Daily().tickTask(DAILY::land_market_buy);
				player->Daily().tickTask(DAILY::TYPE(DailyBind[eResource]));
				//player->Task().evTask(TaskDef::EvCon(TaskBind[eResource]));
			}
		}

		// ��Դ����ID����Դ��������������, �ӳɵ���Դ����
		r[strMsg][0u] = iRet;
		r[strMsg][1u] = eResource;
		r[strMsg][2u] = iAddRes;
		r[strMsg][3u] = fOdds;
		r[strMsg][4u] = iExtraRes;
	}

	void ownerland_system::buildTeamRescue(net::Msg& m, Json::Value& r)
	{
		playerDataPtr player = player_mgr.getPlayer(m.playerID);
		if (!player)Return(r, err_illedge);
		ReadJsonArray;
		const int iFeod = js_msg[0u].asInt();
		const unsigned iIDX = js_msg[1u].asUInt();

		BUILDTEAM::workPtr work_ptr = player->BuildTeam().getTeamWork(iFeod, iIDX);
		if (!work_ptr)Return(r, err_invalid_build_team_rescue);
		if (work_ptr->iHelp)Return(r, err_illedge);
		FEOD::buildPtr build_ptr = player->Builds().getBuild(work_ptr->iFeod, work_ptr->iBuildType, work_ptr->iBuildPos);
		if (!build_ptr)Return(r, err_illedge);

		const unsigned now = Common::gameTime();
		const unsigned cd = work_ptr->iBuildCD;
		if (now > cd || cd <= (FREE_BUILD_CD_TIME + now))Return(r, err_illedge);
		
		Json::Value json;
		json.append(build_ptr->iBuildType);
		json.append(build_ptr->iBuildPos);
		json.append(build_ptr->iBuildLv);
		const Rescue::TYPE rescue_type = Rescue::TYPE(iFeod * MAX_BUILD_TEAM_NUM + iIDX + 1);
		int res = rescue_sys.AddRescue(rescue_type, player, json);
		if (res == res_sucess)
		{
			player->BuildTeam().setHelpTrue(iFeod, iIDX);
			Log(DBLOG::strLogRescue, player, 0, rescue_type, json.toIndentString());
		}
		Return(r, res);
	}

	void ownerland_system::replaceBuild(net::Msg& m, Json::Value& r)
	{
		playerDataPtr player = player_mgr.getPlayer(m.playerID);
		if (!player)Return(r, err_illedge);
		ReadJsonArray;
		const int iFeod = js_msg[0u].asInt();
		const int irType = js_msg[1u].asInt();
		const int irPos = js_msg[2u].asInt();
		const int iType = js_msg[3u].asInt();
		const int iPos = js_msg[4u].asInt();

		LAND::BuildKey minKey = LAND::BuildKey(iFeod, irType, irPos);
		if (minKey.isNull())Return(r, err_illedge);
		
		const unsigned now = Common::gameTime();
		const unsigned cd = player->BuildTeam().getCD(iFeod, irType, irPos);
		int cash = 0;
		if (cd > (FREE_BUILD_CD_TIME + now))
		{
			cash = (cd - now - FREE_BUILD_CD_TIME + 59) / 60;
		}
		
		if (player->Res().getCash() < cash) Return(r, err_cash_not_enough);
		const int res = buildToWork(player, iFeod, iType, iPos, minKey);
		if (res == res_sucess)
		{
			player->Res().alterCash(-cash);
		}
		r[strMsg][1u] = cash;
		Return(r, res);
	}

	void ownerland_system::setBuildState(net::Msg& m, Json::Value& r)
	{
		playerDataPtr player = player_mgr.getPlayer(m.playerID);
		if (!player)Return(r, err_illedge);
		ReadJsonArray;
		const int iFeod = js_msg[0u].asInt();
		const bool state = js_msg[1u].asBool();
		
		Return(r, player->BuildTeam().setFeodState(iFeod, state));
	}

	void ownerland_system::itemFastBuild(net::Msg& m, Json::Value& r)
	{
		playerDataPtr player = player_mgr.getPlayer(m.playerID);
		if (!player)Return(r, err_illedge);
		ReadJsonArray;
		const int iFeod = js_msg[0u].asInt();
		const int iType = js_msg[1u].asInt();
		const int iPos = js_msg[2u].asInt();

		//�����ܷ�ʹ��
		const unsigned now = Common::gameTime();
		const unsigned cd = player->BuildTeam().getCD(iFeod, iType, iPos);
		if (now > (cd + FREE_BUILD_CD_TIME))Return(r, err_illedge);
		
		//�������ʱ��
		if (!js_msg[3u].isArray())Return(r, err_illedge);
		Json::Value& use_json = js_msg[3u];
		std::map<int, unsigned> useItem;
		unsigned cut_time = 0;
		for (unsigned i = 0; i < use_json.size(); ++i)
		{
			Json::Value& sg_json = use_json[i];
			const int itemID = sg_json[0u].asInt();
			const unsigned times = sg_json[1u].asUInt();
			if (times < 1 || times > 999)continue;
			const unsigned unit_cut = getCut(itemID);
			if (unit_cut < 1)continue;
			useItem[itemID] += times;
			cut_time += (unit_cut * times);
		}
		//if ((now + cut_time) >= cd)Return(r, err_illedge);
		for (std::map<int, unsigned>::iterator it = useItem.begin(); it != useItem.end(); ++it)
		{
			if (!player->Items().overItem(it->first, it->second))Return(r, err_item_not_enough);
		}
		if (player->BuildTeam().reduceBuildCD(iFeod, iType, iPos, cut_time))
		{
			for (std::map<int, unsigned>::iterator it = useItem.begin(); it != useItem.end(); ++it)
			{
				player->Items().removeItem(it->first, it->second);
			}
			TaskMgr::update(player, Task::SpeedUpTimes, 1);
			Return(r, res_sucess);
		}
		Return(r, err_illedge);
	}

	void ownerland_system::affairsUpdate(net::Msg& m, Json::Value& r)
	{
		playerDataPtr player = player_mgr.getPlayer(m.playerID);
		if (!player)Return(r, err_illedge);
		player->Affair()._auto_update();
	}

}

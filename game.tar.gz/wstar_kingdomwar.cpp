﻿#include "wstar_kingdomwar.h"
#include <cassert>
#include <cstring>
#include <algorithm>

WStarKW::~WStarKW()
{
	clear();
}

void WStarKW::clear()
{
	_openList.clear();
	_maps.clear();
}

bool WStarKW::isValidParam()
{
	return (publicNearly && publicFare &&
		publicStart != publicEnd
		);
}

inline unsigned WStarKW::calculGValue(Node *parent_node, const int current_pos)
{
	unsigned g_value = publicFare(parent_node->pos, current_pos);
	return g_value += parent_node->g;
}

inline unsigned WStarKW::calculHValue(const int current_pos, const int end_pos)
{
	return publicFare(current_pos, current_pos);
}

inline bool WStarKW::findInOpenList(const int pos, Node *&out)
{
	XMap::iterator it = _maps.find(pos);
	if (it == _maps.end())return false;
	if (IN_OPENLIST == it->second.state)
	{
		out = &(it->second);
		return true;
	}
	return false;
}

inline bool WStarKW::isInCloseList(const int pos)
{
	XMap::iterator it = _maps.find(pos);
	if (it == _maps.end())return false;
	return it->second.state == IN_CLOSELIST;
}

void WStarKW::findNearlyPos(const int current_pos, std::vector<int> &nearly_pos)
{
	nearly_pos.clear();
	std::vector<int> tmp_pos;
	publicNearly(current_pos, tmp_pos);
	for (unsigned i = 0; i < tmp_pos.size(); ++i)
	{
		if (isInCloseList(tmp_pos[i]))continue;
		nearly_pos.push_back(tmp_pos[i]);
	}
}

void WStarKW::handleInOpenNode(Node *current_node, Node *target_node)
{
	unsigned int g_value = calculGValue(current_node, target_node->pos);
	if (g_value < target_node->g)
	{
		std::pair<multiList::iterator, multiList::iterator> find_range =
			_openList.equal_range(target_node);

		for (multiList::iterator iIDX = find_range.first; 
			iIDX != find_range.second; iIDX++)
		{
			if (*target_node == *(*iIDX))
			{
				_openList.erase(iIDX);
				break;
			}
		}

		target_node->g = g_value;
		target_node->parent = current_node;
		_openList.insert(target_node);//重新排序
	}
}

void WStarKW::handleNotInOpenNode(Node *current_node, Node *target_node, const int end_pos)
{
	target_node->parent = current_node;
	target_node->h = calculHValue(target_node->pos, end_pos);
	target_node->g = calculGValue(current_node, target_node->pos);
	target_node->state = IN_OPENLIST;
	_openList.insert(target_node);
}

std::vector<int> WStarKW::find()
{
	std::vector<int> paths;
	if (!isValidParam())
	{
		return paths;
	}
	else
	{
		_maps[publicStart] = Node(publicStart);//起点节点

		//重设周围最多可以行走的物件格
		std::vector<int> nearby_nodes;
		nearby_nodes.reserve(8);

		_openList.insert(&_maps[publicStart]);//所有实体的节点都是从map中生成
		(*_openList.begin())->state = IN_OPENLIST;//设置到open列表

		while (!_openList.empty())
		{
			Node *current_node = *_openList.begin();
			_openList.erase(_openList.begin());
			current_node->state = IN_CLOSELIST;

			//寻找附近的节点
			findNearlyPos(current_node->pos, nearby_nodes);

			for (unsigned index = 0; index < nearby_nodes.size(); index++)
			{
				Node *new_node = NULL;
				const int& index_pos = nearby_nodes[index];
				if (findInOpenList(index_pos, new_node))//如果新找到的下一个路径, 已经是在open列中
				{
					handleInOpenNode(current_node, new_node);//看大小是否需要重新连接当前节点的父节点
				}
				else
				{
					//不会有闭合列表和开列表的坐标点//所以到这步骤位置, 必定是没有创建实例的地图点
					new_node = &(_maps[index_pos] = Node(index_pos));
					handleNotInOpenNode(current_node, new_node, publicEnd);

					if (index_pos == publicEnd)
					{
						while (new_node->parent)
						{
							paths.push_back(new_node->pos);
							new_node = new_node->parent;
						}
						std::reverse(paths.begin(), paths.end());
						goto __end__;
					}
				}
			}
		}
	}

__end__:
	clear();
	return paths;
}
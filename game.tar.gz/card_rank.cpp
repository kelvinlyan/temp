#include "card_rank.h"
#include "player_card.h"

namespace gg
{
	CardRank* const CardRank::_Instance = new CardRank();

	using namespace NSCardRank;
	ptrRankData CardRank::getData(const int playerID)
	{
		PlayerMap::const_iterator it = Player.find(playerID);
		if (it == Player.end())return ptrRankData();
		return it->second;
	}
	int CardRank::getRank(const int playerID)
	{
		ptrRankData ptr = getData(playerID);
		return ptr ? ptr->rankNo : -1;
	}

	void CardRank::initData()
	{
		if (isInitial)return;
		cout << "initial card rank list ..." << endl;
		Rank.clear();
		Player.clear();
		mongo::Query find_query;
		find_query.sort("id", 1).sort("exp", -1).sort("lv", -1).sort("q", -1);
		objCollection objs = db_mgr.QueryCustom(DBN::dbPlayeCardMax, find_query, 100);
		for (unsigned i = 0; i < objs.size(); ++i)
		{
			mongo::BSONObj& obj = objs[i];
			const int playerID = obj[strPlayerID].Int();
			playerDataPtr now_player = player_mgr.getPlayer(playerID);
			if (!now_player)break;
			ptrRankData ptr = Creator<RankData>::Create(now_player);
			if (ptr->isNull())continue;
			Rank[ptr->Key()] = ptr;
			Player[ptr->playerID] = ptr;
		}
		unsigned rank_begin = 0;
		for (RankMap::iterator it = Rank.begin(); it != Rank.end(); ++it)
		{
			it->second->rankNo = (++rank_begin);
		}
		cout << "card rank size:" << Rank.size() << "\t" << Player.size() << endl;
		isInitial = true;
	}

	void CardRank::CardDetail(net::Msg& m, Json::Value& r)
	{
		playerDataPtr player = player_mgr.getPlayer(m.playerID);
		if (!player)Return(r, err_illedge);//�Ƿ�����
		ReadJsonArray;
		const int id = js_msg[0u].asInt();
		ptrRankData ptr = getData(id);
		qValue json(qJson::qj_array);
		if (ptr)
		{
			json.
				append(res_sucess).
				append(ptr->cardID).
				append(ptr->cardLV).
				append(ptr->cardEXP).
				append(ptr->cardQua)
				;
			player->sendToClientFillMsg(gate_client::player_card_rank_detail_resp, json);
			return;
		}
		Return(r, err_illedge);
	}

	void CardRank::RankList(net::Msg& m, Json::Value& r)
	{
		playerDataPtr player = player_mgr.getPlayer(m.playerID);
		if (!player)Return(r, err_illedge);//�Ƿ�����
		qValue json(qJson::qj_array);
		for (RankMap::const_iterator it = Rank.begin(); it != Rank.end(); ++it)
		{
			ptrRankData ptr = it->second;
			json.append(
				qValue(qJson::qj_array).
				append(ptr->playerID).
				append(ptr->playerName).
				append(ptr->playerNation).
				append(ptr->cardLV).
				append(ptr->cardID)
			);
		}
		ptrRankData ownData = getData(m.playerID);
		player->sendToClientFillMsg(gate_client::player_card_rank_resp,
			qValue(qJson::qj_array).
			append(res_sucess).
			append(json).
			append(ownData ? ownData->rankNo : -1).
			append(ownData ? ownData->cardID : player->Card().getMax().cardID)
		);
	}

	void CardRank::updatePlayer(playerDataPtr player)
	{
		if (false == isInitial)return;
		Rankey new_key(player);
		ptrRankData ptr = getData(player->ID());
		if (ptr)//�ȸ��·ǹ�Ҫ����
		{
			ptr->playerName = player->Name();
			ptr->playerNation = player->Info().Nation();
			//���key�Ƿ���������ļ�ֵ
			Rankey old_key = ptr->Key();
			if (!(new_key > old_key))return;
			ptr->setNewData(player);
		}
		else
		{
			ptr = Creator<RankData>::Create(player);
			if (ptr->isNull())return;
		}
		RankMap::iterator insert_it = Rank.insert(RankMap::value_type(ptr->Key(), ptr)).first;
		RankMap::iterator check_it = insert_it;
		++check_it;
		if (check_it == Rank.end())
		{
			ptr->rankNo = Rank.size();
			if (ptr->rankNo > 100)
			{
				Rank.erase(insert_it);
				return;
			}
			Player[ptr->playerID] = ptr;
			return;
		}
		else
		{
			ptr->rankNo = check_it->second->rankNo;
		}
		if (ptr->rankNo > 100)
		{
			Rank.erase(insert_it);
			return;
		}
		Player[ptr->playerID] = ptr;
		int begin_rank = ptr->rankNo;
		for (; check_it != Rank.end();)
		{
			ptrRankData it_ptr = check_it->second;
			if (it_ptr->playerID == ptr->playerID)
			{
				Rank.erase(check_it);
				break;
			}
			it_ptr->rankNo = (++begin_rank);
			if (it_ptr->rankNo > 100)
			{
				Rank.erase(check_it++);
				Player.erase(it_ptr->playerID);
				continue;
			}
			++check_it;
		}
	}

}

#pragma once

#include "auto_base.h"
#include "mongoDB.h"
#include "kingdomwar_helper.h"

namespace gg
{
	class playerKingdomWarSGPos
		: public _auto_player
	{
		public:
			playerKingdomWarSGPos(int army_id, playerData* const own);

			void load(const mongo::BSONObj& obj);
			void getInfo(qValue& q);

			const KingdomWar::Position& position() const { return _pos; }
			void setPosition(int type, int id, unsigned time, qValue& tips);
			void setLine(const KingdomWar::Line& line);
			void updateHp() { _sign_update(); }
			int move(unsigned time, int to_city_id, bool start);
			int tryMove();
			int retreat();
			bool inMainCity();

		private:
			virtual bool _auto_save();
			virtual void _auto_update();

		private:
			const int _army_id;
			KingdomWar::Position _pos;
			STDLIST(int, IdList);
			IdList _line;
			qValue _tips;
	};

	BOOSTSHAREPTR(playerKingdomWarSGPos, playerKingdomWarSGPosPtr);
	STDVECTOR(playerKingdomWarSGPosPtr, PlayerKingdomWarPosList);

	class playerKingdomWarPos
		: public _auto_player
	{
		public:
			playerKingdomWarPos(playerData* const own);

			virtual void classLoad();
			void update();
			void sign_update(int army_id) { _pos_list[army_id]->_sign_update(); }

			const KingdomWar::Position& position(int army_id) const 
			{
				return _pos_list[army_id]->position(); 
			}

			void setPosition(int army_id, int type, int id, unsigned time, qValue& tips);
			void setLine(int army_id, const KingdomWar::Line& l);
			void updateHp(int army_id) { _pos_list[army_id]->updateHp(); }
			int move(unsigned time, int army_id, int to_city_id, bool start);
			int tryMove(int army_id) { return _pos_list[army_id]->tryMove(); }
			int retreat(int army_id);

		private:
			virtual bool _auto_save();
			virtual void _auto_update();

		private:
			PlayerKingdomWarPosList _pos_list;
	};
}

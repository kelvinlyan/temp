#include "player_mapwar.h"
#include "dbDriver.h"
#include "map_war.h"
#include "res_code.h"
#include "task_mgr.h"
#include "map_war_rank.h"

namespace gg
{
	playerChatperData::playerChatperData(playerData* const own, const int cID, const bool isNew /* = false */) :
		_auto_player(own),
		chaperID(cID)
	{
		dirty = false;
		eliteBox = 0;
		totalStar = 0;
		filterBox.clear();

		chaperConfig = map_sys.getChaperConfig(chaperID);
		//��ͼ��ϸ����
		lastUpdateTime = player_mgr.stander5();
		mapData.clear();
		isLoadComplete = false;
		if (isNew)isLoadComplete = true;
		mapDataCfgPtr map_config = map_sys.getMapConfig(chaperConfig->beginMapID);
		SelfMapDataPtr ptr = Creator<selfMapData>::Create();
		ptr->mapId = chaperConfig->beginMapID;
		ptr->starNum = 0;
		ptr->challengeTimes = 0;// map_config->chanllengeTimes;
		ptr->reChallengeTimes = 0;
		ptr->mState = warMap::CanCH;
		//��������
		mapData[ptr->mapId] = ptr;
	}

	void playerChatperData::_auto_update()
	{
		qValue res(qJson::qj_array);
		res.append(res_sucess).append(mapDataJson()).append(State::getState());
		Own().sendToClientFillMsg(gate_client::map_war_base_resp, res);
	}

	bool playerChatperData::_auto_save()
	{
		mongo::BSONObj key = BSON(strPlayerID << Own().ID());
		mongo::BSONObjBuilder obj;
		obj << strPlayerID << Own().ID() << "ltt" << lastUpdateTime;

		mongo::BSONArrayBuilder _arrmapData;
		for (MapDataMap::iterator it = mapData.begin(); it != mapData.end(); it++)
		{
			mongo::BSONObj map_obj = BSON("mi" << it->second->mapId << //��ͼID
				"sn" << it->second->starNum << //����
				"st" << it->second->mState << //״̬
				"ct" << it->second->challengeTimes << //������ս�Ĵ���
				"re" << it->second->reChallengeTimes //���ô���
			);
			_arrmapData << map_obj;
		}
		obj << "md" << _arrmapData.arr();

		return db_mgr.SaveMongo(DBN::dbPlayerWar + Common::toString(chaperID), key, obj.obj());
	}

	qValue playerChatperData::flashSnapJson()
	{
		qValue res(qJson::qj_object);
		qValue rewardJson(qJson::qj_object);
		const rewardItemMap& checkMap = chaperConfig->passBox;
		for (rewardItemMap::const_iterator it = checkMap.begin(); it != checkMap.end(); it++)
		{
			const rewardItemCfgPtr& riConfig = it->second;
			rewardJson.addMember(
				Common::toString(riConfig->rewardID),
				riConfig->starNum > totalStar ? warReward::Unfinished :
				(filterBox.find(riConfig->rewardID) == filterBox.end() ? warReward::Notrev : warReward::Finish)
			);
		}
		res.addMember("sn", totalStar);
		res.addMember("rw", rewardJson);
		res.addMember("ch", chaperID);
		res.addMember("elb", eliteBox);
		return res;
	}

	qValue playerChatperData::mapDataJson()
	{
		if (!isLoadComplete)
		{
			classLoad();
		}
		qValue res(qJson::qj_object);
		qValue mapJson(qJson::qj_object);
		for (MapDataMap::iterator it = mapData.begin(); it != mapData.end(); it++)
		{
			SelfMapDataPtr self_data = it->second;
			mapDataCfgPtr mapConfig = map_sys.getMapConfig(self_data->mapId);
			if (mapConfig)
			{
				qValue mdJson(qJson::qj_object);
				mdJson.addMember("sn", self_data->starNum);
				mdJson.addMember("ms", self_data->mState);
				mdJson.addMember("ct", mapConfig->chanllengeTimes - self_data->challengeTimes);
				mdJson.addMember("rt", map_sys.ReNum(Own().Info().VipLv()) - self_data->reChallengeTimes);
				mdJson.addMember("ctt", mapConfig->chanllengeTimes);
				mdJson.addMember("trr", map_sys.ReNum(Own().Info().VipLv()));
				mapJson.addMember(Common::toString(self_data->mapId), mdJson);
			}
		}
		res.addMember("mp", mapJson);
		res.addMember("ch", chaperID);
		return res;
	}

	void playerChatperData::tryOpenNewMap(const int mapID)
	{
		SelfMapDataPtr pre = getMapData(mapID);
		if (pre)return;
		mapDataCfgPtr configMap = map_sys.getMapConfig(mapID);
		if (!configMap) return;
		SelfMapDataPtr ptr = Creator<selfMapData>::Create();
		ptr->mapId = mapID;
		ptr->starNum = 0;
		ptr->challengeTimes = 0;// configMap->chanllengeTimes;
		ptr->reChallengeTimes = 0;
		ptr->mState = warMap::CanCH;
		mapData[ptr->mapId] = ptr;
		_sign_auto();
	}

	int playerChatperData::setMapStar(const int mapID, const int starNum)
	{
		SelfMapDataPtr ptr = getMapData(mapID);
		if (ptr)
		{
			if (ptr->mState == warMap::Faile) { return 0; }
			mapDataCfgPtr map_config = map_sys.getMapConfig(mapID);
			ptr->mState = warMap::Success;
			int num = starNum - ptr->starNum;
			if (num > 0)
			{
				totalStar += num;
				dirty = true;
				Own().War().recalTotalStars();
				ptr->starNum = starNum;
				TaskMgr::update(Own().getOwnDataPtr(), Task::WarStarSum, num);
				TaskMgr::update(Own().getOwnDataPtr(), Task::WarMapStar, mapID, starNum);
				_sign_auto();
			}
			return num;
		}
		return 0;
	}

	void playerChatperData::reChanllengeTimeDaily(const bool update /* = true */)
	{
		if (isLoadComplete)
		{
			for (MapDataMap::iterator it = mapData.begin(); it != mapData.end(); it++)
			{
				it->second->challengeTimes = 0;
				it->second->reChallengeTimes = 0;
			}
			lastUpdateTime = player_mgr.stander5();
			_sign_save();
			if (update)_sign_update();
		}
	}

	bool playerChatperData::reChanllengeAcc(const int mapID)
	{
		SelfMapDataPtr ptr = getMapData(mapID);
		if (!ptr || ptr->reChallengeTimes >= map_sys.ReNum(Own().Info().VipLv())) return false;
		mapDataCfgPtr mapConfig = map_sys.getMapConfig(mapID);
		if (mapConfig && ptr->challengeTimes >= mapConfig->chanllengeTimes)
		{
			ptr->reChallengeTimes++;
			ptr->challengeTimes = 0;// mapConfig->chanllengeTimes;
			_sign_auto();
			return true;
		}
		return false;
	}

	void playerChatperData::subChanllengeTime(const int mapID, const int times)
	{
		SelfMapDataPtr ptr = getMapData(mapID);
		if (!ptr)return;
		ptr->challengeTimes += times;
		//ptr->challengeTimes = ptr->challengeTimes < 0 ? 0 : ptr->challengeTimes;
		_sign_auto();
	}

	SelfMapDataPtr playerChatperData::getMapData(const int mapID)
	{
		if (!isLoadComplete)
		{
			classLoad();//loading����
		}
		MapDataMap::iterator mIt = mapData.find(mapID);
		if (mIt == mapData.end())return SelfMapDataPtr();
		return mIt->second;
	}

	bool playerChatperData::_on_sign_update()
	{
		Own().War().signChaper(chaperID);
		return false;
	}

	void playerChatperData::classLoad()
	{
		isLoadComplete = true;
		mongo::BSONObj key = BSON(strPlayerID << Own().ID());
		mongo::BSONObj obj = db_mgr.FindOne(DBN::dbPlayerWar + Common::toString(chaperID), key);
		if (obj.isEmpty()) return;
		if (!obj["ltt"].eoo())
		{
			lastUpdateTime = obj["ltt"].Int();
		}
		if (!obj["md"].eoo())
		{
			unsigned star_num = 0;
			vector<mongo::BSONElement> sets = obj["md"].Array();
			for (unsigned i = 0; i < sets.size(); i++)
			{
				SelfMapDataPtr ptr = Creator<selfMapData>::Create();
				ptr->mapId = sets[i]["mi"].Int();
				ptr->starNum = sets[i]["sn"].Int();
				star_num += ptr->starNum;
				ptr->mState = (warMap::mapState)sets[i]["st"].Int();
				ptr->challengeTimes = sets[i]["ct"].Int();
				ptr->reChallengeTimes = sets[i]["re"].eoo() ? 0 : sets[i]["re"].Int();
				mapData[ptr->mapId] = ptr;
			}
			if (star_num != totalStar)//ǿ�Ʊ���
			{
				totalStar = star_num;
				Own().War().recalTotalStars();
			}
		}
		if (Common::gameTime() > lastUpdateTime)
		{
			reChanllengeTimeDaily(false);
		}
	}

	////////////////////////////////////////////////////////////////////////////////////
	///////////////////////////////////Mgr//////////////////////////////////////////////

	playerMapWarMgr::playerMapWarMgr(playerData* const own) :_auto_player(own)
	{
		_signChaper.clear();
		//������ս
		_currentChallengeChaper = 0;
		//��ͼ����
		ChapterData.clear();

		//���ʤ��
		_lastWinMap = 0;
		_lastWinMapTime = Common::gameTime();

		//������
		_totalStarsNum = 0;

		//����Ҫ�½�һ����������
		const int minChapterId = map_sys.getMinChapterNum();
		playerChatperDataPtr chatperData = Creator<playerChatperData>::Create(_Own, minChapterId, true);
		ChapterData[minChapterId] = chatperData;
		_currentChallengeChaper = minChapterId;
	}

	bool playerMapWarMgr::_auto_save()
	{
		mongo::BSONObj key = BSON(strPlayerID << Own().ID());

		mongo::BSONArrayBuilder arr;
		for (ChapterDateMap::iterator it = ChapterData.begin(); it != ChapterData.end(); it++)
		{
			playerChatperDataPtr ptr = it->second;
			mongo::BSONArrayBuilder rewardData;
			for (std::set<int>::iterator it = ptr->filterBox.begin(); it != ptr->filterBox.end(); it++)
			{
				rewardData << *it;
			}
			arr << BSON("cid" << ptr->chaperID << "sn" << 
				ptr->getStarNum() << "rw" << rewardData.arr() <<
				"elb" << ptr->getEliteBox()
			);
		}

		mongo::BSONObj obj = BSON(strPlayerID << Own().ID()
			<< "lwm" << _lastWinMap << "lwmt" << _lastWinMapTime
			<< "tts" << _totalStarsNum
			<< "arr" << arr.arr());
		return db_mgr.SaveMongo(DBN::dbPlayerWarSnap, key, obj);
	}

	void playerMapWarMgr::_auto_update()
	{
		qValue data_json(qJson::qj_array);
		for (ChapterDateMap::iterator it = ChapterData.begin(); it != ChapterData.end(); it++)
		{
			playerChatperDataPtr ptr = it->second;
			if (ptr->dirty)
			{
				ptr->dirty = false;
				data_json.append(ptr->flashSnapJson());
			}
		}
		if (!data_json.isEmpty())
		{
			qValue json(qJson::qj_array);
			json.append(res_sucess).append(_currentChallengeChaper).append(_lastWinMap).append(data_json);
			Own().sendToClientFillMsg(gate_client::map_war_flash_snap_resp, json);
		}

		for (std::set<int>::iterator it = _signChaper.begin(); it != _signChaper.end(); it++)
		{
			playerChatperDataPtr ptr = getChatperData(*it);
			if (ptr)
			{
				ptr->_auto_update();
			}
		}
		_signChaper.clear();
	}

	void playerMapWarMgr::signChaper(const int chaperID)
	{
		_signChaper.insert(chaperID);
		_sign_update();
	}

	void playerMapWarMgr::recalTotalStars()
	{
		_totalStarsNum = 0;
		for (ChapterDateMap::iterator it = ChapterData.begin(); it != ChapterData.end(); it++)
		{
			playerChatperDataPtr ptr = it->second;
			_totalStarsNum += ptr->totalStar;
		}
		_sign_auto();
	}

	void playerMapWarMgr::classLoad()
	{
		//������ս
		_currentChallengeChaper = 0;
		//��ͼ����
		ChapterData.clear();

		const int minChapterId = map_sys.getMinChapterNum();
		const int maxChapterId = map_sys.getMaxChapterNum();

		mongo::BSONObj key = BSON(strPlayerID << Own().ID());
		mongo::BSONObj base_obj = db_mgr.FindOne(DBN::dbPlayerWarSnap, key);
		if (base_obj.isEmpty())//������������
		{
			bool sucess = false;
			for (int n = minChapterId; n <= maxChapterId; n++)
			{
				mongo::BSONObj obj = db_mgr.FindOne(DBN::dbPlayerWar + Common::toString(n), key);
				if (obj.isEmpty()) break;
				sucess = true;
				playerChatperDataPtr chatperData = Creator<playerChatperData>::Create(_Own, n, true);
				chatperData->totalStar = 0;//�½�������
				if (!obj["md"].eoo())
				{
					vector<mongo::BSONElement> sets = obj["md"].Array();
					for (unsigned i = 0; i < sets.size(); i++)
					{
						SelfMapDataPtr ptr = Creator<selfMapData>::Create();
						ptr->mapId = sets[i]["mi"].Int();
						ptr->starNum = sets[i]["sn"].Int();
						chatperData->totalStar += ptr->starNum;//����
						ptr->mState = (warMap::mapState)sets[i]["st"].Int();
						ptr->challengeTimes = 0;// sets[i]["ct"].Int();
						ptr->reChallengeTimes = sets[i]["re"].eoo() ? 0 : sets[i]["re"].Int();
						chatperData->mapData[ptr->mapId] = ptr;
						//���ʤ���ĵ�ͼ
						if (_lastWinMap < ptr->mapId && ptr->mState == warMap::Success)
						{
							_lastWinMap = ptr->mapId;
						}
					}
					//������
					_totalStarsNum += chatperData->getStarNum();
				}

				//ǿ�Ʊ���
				chatperData->_auto_save();
				ChapterData[n] = chatperData;
				if (n > _currentChallengeChaper) { _currentChallengeChaper = n; }

				//�ⲿ��ת�ɿ�������
				if (!obj["rw"].eoo())
				{
					chaperDataCfgPtr map_config = chatperData->chaperConfig;
					if (map_config)
					{
						vector<mongo::BSONElement> sets = obj["rw"].Array();
						for (unsigned i = 0; i < sets.size(); i++)
						{
							const int rState = sets[i]["rs"].Int();//״̬
							const int rStar = sets[i]["nm"].Int();//����
							if (rState == warReward::Finish)
							{
								for (rewardItemMap::iterator it = map_config->passBox.begin();
									it != map_config->passBox.end(); it++)
								{
									rewardItemCfgPtr rw_ptr = it->second;
									if (rStar == rw_ptr->starNum)
									{
										chatperData->filterBox.insert(rw_ptr->rewardID);
										break;
									}
								}
							}
						}
					}
				}
			}

			if (sucess)
			{
				_auto_save();//ǿ�Ʊ������ݿ�
			}
		}
		else //�Ѿ��������õ�����
		{
			//��������
			_lastWinMap = base_obj["lwm"].Int();
			bool need_force_save = false;
			if (base_obj["lwmt"].eoo())
			{
				need_force_save = true;
			}
			else
			{
				_lastWinMapTime = base_obj["lwmt"].Int();
			}
			_totalStarsNum = base_obj["tts"].Int();

			//��ͼ����
			vector<mongo::BSONElement> vec = base_obj["arr"].Array();
			for (unsigned i = 0; i < vec.size(); i++)
			{
				mongo::BSONElement& elem = vec[i];
				const int chaperID = elem["cid"].Int();
				if (!map_sys.getChaperConfig(chaperID))continue;
				playerChatperDataPtr chatperData = Creator<playerChatperData>::Create(_Own, chaperID);
				chatperData->totalStar = elem["sn"].Int();//������
				chatperData->eliteBox = elem["elb"].eoo() ? 0 : elem["elb"].Int();
				//����
				vector<mongo::BSONElement> sets = elem["rw"].Array();
				for (unsigned idx = 0; idx < sets.size(); idx++)
				{
					chatperData->filterBox.insert(sets[idx].Int());
				}
				ChapterData[chaperID] = chatperData;
				if (chaperID > _currentChallengeChaper) { _currentChallengeChaper = chaperID; }
			}

			if (need_force_save)
			{
				_auto_save();
			}
		}

		//����Ƿ�����һ���½�����
		mapDataCfgPtr last_map_config = map_sys.getMapConfig(_lastWinMap);
		if (last_map_config && last_map_config->isEndMap() && last_map_config->hasNextChaper())
		{
			const int nextID = last_map_config->chaperPtr->nextChaperID;
			playerChatperDataPtr pre = getChatperData(nextID);
			if (!pre)
			{
				if (nextID > _currentChallengeChaper)
				{
					_currentChallengeChaper = nextID;
				}
				playerChatperDataPtr ptr = Creator<playerChatperData>::Create(_Own, nextID, true);
				//ptr->_auto_save();
				ChapterData[nextID] = ptr;
			}
		}

		if (ChapterData.empty())//û������//��������
		{
			playerChatperDataPtr chatperData = Creator<playerChatperData>::Create(_Own, minChapterId, true);
			ChapterData[minChapterId] = chatperData;
			_currentChallengeChaper = minChapterId;
		}
	}

	playerChatperDataPtr playerMapWarMgr::getChatperData(const int chapterId)
	{
		ChapterDateMap::iterator it = ChapterData.find(chapterId);
		if (it != ChapterData.end())return it->second;
		return playerChatperDataPtr();
	}

	SelfMapDataPtr playerMapWarMgr::getMapData(const int mapId)
	{
		playerChatperDataPtr ptr = getChatperData(mapId / DivMapChaperRealte);
		if (ptr)
		{
			return ptr->getMapData(mapId);
		}
		return SelfMapDataPtr();
	}

	void playerMapWarMgr::tryOpenNewChaper(const int chaperID)
	{
		playerChatperDataPtr pre = getChatperData(chaperID);
		if (pre)return;
		playerChatperDataPtr ptr = Creator<playerChatperData>::Create(_Own, chaperID, true);
		ptr->dirty = true;
		if (chaperID > _currentChallengeChaper)
		{
			_currentChallengeChaper = chaperID;
			_sign_auto();
		}
		ptr->_sign_auto();
		ChapterData[chaperID] = ptr;
	}

	void playerMapWarMgr::alterMapStar(const int mapID, const int starNum)
	{
		if (starNum <= 0 || starNum > 5) { return; }
		//��������
		const int chaperID = mapID / DivMapChaperRealte;
		playerChatperDataPtr ptr = getChatperData(chaperID);
		if (!ptr)return;

		const int num = ptr->setMapStar(mapID, starNum);
		if (mapID > _lastWinMap)
		{
			_lastWinMap = mapID;
			_lastWinMapTime = Common::gameTime();
			map_war_rank.updatePlayer(Own().getOwnDataPtr());
			onChangeMaxMapId();
			Log(DBLOG::strLogWarProcess, Own().getOwnDataPtr(), -1, _lastWinMap, mapID);
			_sign_auto();
		}

		const mapDataCfgPtr config = map_sys.getMapConfig(mapID);
		if (!config) { return; }
		if (config->hasNextMap())
		{
			ptr->tryOpenNewMap(config->nextID);
		}
		if (config->isEndMap() && config->hasNextChaper())
		{
			tryOpenNewChaper(config->chaperPtr->nextChaperID);
		}
	}

	int playerMapWarMgr::getEliteBox(const int mapID, Json::Value& r)
	{
		if (!isChallengeMap(mapID))return err_illedge;
		mapDataCfgPtr config = map_sys.getMapConfig(mapID);
		if (!config)return err_illedge;
		const unsigned boxIDX = config->eliteBox;
		if (boxIDX > 31)return err_illedge;
		playerChatperDataPtr ptr = getChatperData(config->chaperID());
		if (!ptr)return err_illedge;
		const unsigned state = ptr->getEliteBox();
		if ((state & (0x0001 << boxIDX)) > 0)return err_illedge;//�Ѿ���ȡ��
		const int res = actionDoBox(
			Own().getOwnDataPtr(),
			config->eliteBoxAction[Own().Info().NationIDX()],
			false
			);
		if (res == res_sucess)
		{
			r = actionRes();
			ptr->eliteBox |= (0x0001 << boxIDX);
			ptr->dirty = true;
			_sign_auto();
		}
		else
		{
			r = actionError();
		}
		return res;
	}

	//��½����
	void playerMapWarMgr::sendFlashSnap()
	{
		qValue json(qJson::qj_array);
		json.append(res_sucess).append(_currentChallengeChaper).append(_lastWinMap);
		qValue data_json(qJson::qj_array);
		for (ChapterDateMap::iterator it = ChapterData.begin(); it != ChapterData.end(); it++)
		{
			playerChatperDataPtr ptr = it->second;
			data_json.append(ptr->flashSnapJson());
		}
		json.append(data_json);
		Own().sendToClientFillMsg(gate_client::map_war_flash_snap_resp, json);
	}

	void playerMapWarMgr::sendMemoryMapData()
	{
		for (ChapterDateMap::iterator it = ChapterData.begin(); it != ChapterData.end(); it++)
		{
			playerChatperDataPtr ptr = it->second;
			if (ptr->isLoadComplete)
			{
				ptr->_auto_update();
			}
		}
	}

	bool playerMapWarMgr::isChallengeChaper(const int chaperID)
	{
		return chaperID <= map_sys.calCompleteChaperByMapID(_lastWinMap);
	}

	int playerMapWarMgr::getChapterReward(const int chapterId, const int rewardId)
	{
		playerChatperDataPtr ptr = getChatperData(chapterId);
		if (!ptr) return err_charpter_id_not_found;

		if (ptr->filterBox.find(rewardId) != ptr->filterBox.end())return err_charpter_reward_state_not_recv;
		ActionBoxList acPtr = map_sys.getChapterRewardList(ptr->chaperID, rewardId);
		if (acPtr.empty())return err_charpter_reward_id_not_found;
		int res = actionDoBox(Own().getOwnDataPtr(), acPtr, false);
		if (res == res_sucess)
		{
			ptr->filterBox.insert(rewardId);
			ptr->dirty = true;
			_sign_auto();
		}
		return res;
	}

	int playerMapWarMgr::canSweep(const int mapID, const int times, const int comval)
	{
		SelfMapDataPtr mapPTr = getMapData(mapID);
		if (!mapPTr) return err_illedge;
		if (mapPTr->starNum != MAX_MAP_STAR_NUM) { return err_mapwar_sweep_more_star; }
		if (mapPTr->challengeTimes + times > comval) { return err_mapwar_not_challengtimes; }
		return res_sucess;
	}

	int	playerMapWarMgr::canChanllenge(const int mapID, const int times, const int comval)
	{
		SelfMapDataPtr mapPTr = getMapData(mapID);
		if (!mapPTr || mapPTr->mState == warMap::Faile) return err_illedge;
		if (mapPTr->challengeTimes + times > comval) { return err_mapwar_not_challengtimes; }
		return res_sucess;
	}

	void playerMapWarMgr::subChanllenge(const int mapID, const int times /* = 1 */)
	{
		playerChatperDataPtr ptr = getChatperData(mapID / DivMapChaperRealte);
		if (ptr)
		{
			ptr->subChanllengeTime(mapID, times);
		}
	}

	void playerMapWarMgr::reChanllengeTimeDaily()
	{
		for (ChapterDateMap::iterator it = ChapterData.begin(); it != ChapterData.end(); it++)
		{
			it->second->reChanllengeTimeDaily();
		}
	}

	int playerMapWarMgr::currenChanllenge()
	{
		mapDataCfgPtr config = map_sys.getMapConfig(_lastWinMap);
		if (!config || config->nextID < 1)return _lastWinMap;
		return config->nextID;
	}

	int	 playerMapWarMgr::reChanllengeAcc(const int mapID)
	{
		playerChatperDataPtr ptr = getChatperData(mapID / DivMapChaperRealte);
		if (!ptr)return err_illedge;
		if (ptr->reChanllengeAcc(mapID)) return res_sucess;
		return err_illedge;
	}

	int playerMapWarMgr::getStarSum(int chapterId)
	{
		if (chapterId == -1)
		{
			return _totalStarsNum;
		}
		else
		{
			playerChatperDataPtr ptr = getChatperData(chapterId);
			if (ptr)return ptr->getStarNum();
			return 0;
		}
	}
}

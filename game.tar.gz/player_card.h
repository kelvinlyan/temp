//###################################
//create by Jim
//2015-12-30
//###################################


#pragma once

#include "man_def.h"
#include "auto_base.h"

namespace gg
{
	struct cardConfig
	{
		int cardID;//��ƬID
		int faceID;//ͷ��ID
		unsigned orderID;//��Ƭ���
		int stars;//�Ǽ�
		int coin;//ǲɢ��ð���
		int silver;//ǲɢ�������
		unsigned beginLevel;//��ʼ�ȼ�
		STDVECTOR(int, Group);
		STDVECTOR(Group, SeqGroup);
		STDVECTOR(vector<int>, SeqAttri);
		STDVECTOR(vector<double>, SeqAttriRate);
		SeqAttri attriSeq;//ֱ�����ӵ�����, ��ȼ��仯
		SeqGroup groupSET;//����޶�
		SeqAttri	 groupAttri;//������ӵ�����
	};
	BOOSTSHAREPTR(cardConfig, cfgCardPtr);

	class playerCardMgr;
	class playerCard :
		public _auto_player
	{
		friend class playerCardMgr;
	public:
		static unsigned MaxLevel();
		playerCard(playerData* const own, const int cID);
		~playerCard(){}
		inline int rawID(){ return cardID / 1000; }
		inline int ID(){ return cardID; }
		inline unsigned LV(){ return level; }
		inline unsigned EXP(){ return exp; }
		inline bool Alive(){ return alive; }
		int addExp(const unsigned num);
		unsigned toExp();
		cfgCardPtr getConfig();
		void Delete();
		void setBind(const bool bt = true);
		inline bool Lock(){ return (bind || lock); }
		inline bool Bind(){ return bind; }
		//gm tools
		void setInfo(const unsigned lv, const unsigned ex);
	private:
		void upgrade();
		virtual void _auto_end();
		virtual bool _auto_save();
		virtual bool _on_sign_update();
		int cardID;
		unsigned level;
		unsigned exp;
		bool alive;
		bool bind;
		bool lock;
		cfgCardPtr handlerCfg;
	};
	BOOSTSHAREPTR(playerCard, playerCardPtr);

	UNORDERMAP(int, int, CARDSHOPTICK);
	class playerTick;
	class playerCardTs :
		public _auto_player
	{
		friend class playerTick;
	public:
		playerCardTs(playerData* const own);
		~playerCardTs(){}
		virtual void _auto_update();
		virtual bool _auto_save();
		inline int silverTimes(){ return sT; }
		inline int goldTimes(){ return gT; }
		inline int sLotteryTimes(){ return sL; }
		inline unsigned sLotteryCD(){ return sLCD; }
		inline unsigned gLotteryCD(){ return gLCD; }
		inline unsigned gLotteryMTimes(){ return gLMTimes; }
		inline unsigned gLotteryHMTimes(){ return gLHMTimes; }
		inline unsigned ssLotteryTimes(){ return ssLTimes; }
		inline unsigned totalLotteryTimes(){ return totalTimes; }
		void subST();
		void subGT();
		void subSL();
		void setSLCD();
		void setGLCD();
		void tickGLMT();
		void tickGLHMT();
		void tickSSLottery();
		void tickTotalTimes(int times);

		unsigned ShowCardCD;
	private:
		virtual void classLoad();
		int sT;//����ʣ��������������
		int gT;//����ʣ������������
		int sL;//����ʣ��������Ѵ���
		unsigned sLCD;//���ҳ鿨CD
		unsigned gLCD;//�����ѳ鿨CD
		unsigned gLMTimes;//���10���鿨����
		unsigned gLHMTimes;//�߼����10���鿨����
		unsigned ssLTimes;//���ҳ�ȡ
		unsigned totalTimes;//�鿨�ܴ���
	};

	class playerCardMgr :
		public _auto_player
	{
	public:
		playerCardMgr(playerData* const own);
		~playerCardMgr(){}
		static void initData();
		Json::Value gmFormatPackage();
		Json::Value gmCardsPackage();
		qValue investPackage();
		void updateAll();
		inline const int* getAdd(){return attri;}
		int resAddCard(const int cardID, const unsigned num, const unsigned level = 0);
		vector<playerCardPtr> addCard(const int cardID, const unsigned num, const unsigned level = 0);
		bool removeCard(const int cardID);
		int invest(const int fm[5]);
		void memDeleteCard(const int cardID);
		void tryRecal(const int cardID);
		void tickCard(const int cardID);
		void tryRmFM(const int cardID);
		playerCardPtr getCard(const int cardID);
		const static unsigned BagCap;
		unsigned operationTime;
		inline unsigned cardNum(const int rawCard){ return mapFCard[rawCard].size(); }
		inline unsigned Size(){ return mapCard.size(); }
		inline bool isOver(const unsigned num = 0){
			if (num < 1)return (mapCard.size() >= BagCap);
			return (num > BagCap || (mapCard.size() + num) > BagCap);
		}
		inline bool tryOver(const unsigned num = 0){
			if (num > 0)
			{
				return (mapCard.size() >= BagCap || num > BagCap || (mapCard.size() + num) > BagCap);
			}
			return false;
		}
		int fmSize() const;
		int cardMaxLv() const;
		int groupNum() const;
	private:
		virtual void classLoad();
		virtual void _auto_update();
		virtual bool _auto_save();
		int CreateNewCard(const int cardID, const unsigned num, const unsigned level);
		int CreateNewCard(const int cardID, const unsigned num, const unsigned level, vector<playerCardPtr>& vec);
		void recalAttri(const bool recalMan = true);
		playerCardPtr fomation[5];//���5�� // ��Ů ���� �ʺ� ����  ���� // �ʺ�4+ ����3+
		UNORDERMAP(int, playerCardPtr, CardMap);
		CardMap mapCard;
		UNORDERMAP(int, CardMap, CardFriendMap);
		CardFriendMap mapFCard;
		STDSET(int, INTSET);
		INTSET FMSET;
		INTSET updateList;
		bool fmUpdate;
		int attri[characterNum];//ֱ�����ӵ�����, ��ȼ��仯
//		double attriRate[characterNum];//���ӵ����Եı���, ���ŵȼ��仯
// 		static int zeroAttri[characterNum];
// 		static double zeroAttriRate[characterNum];
	};
}

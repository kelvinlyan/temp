//###################################
//create by Jim
//2016-11-07
//###################################

#pragma once

#include "dbDriver.h"

#define business_total_rank (*gg::BusinessTotalRank::_Instance)

namespace gg
{
	namespace NSBusinessTotalRank
	{
		struct Rankey
		{
			Rankey()
			{
				playerID = -1;
				completeTimes = 0;
				businessMoney = 0;
			}
			Rankey(playerDataPtr player)
			{
				playerID = player->ID();
				completeTimes = player->Trade().totalTask();
				businessMoney = player->Trade().historyTotalMoney();
			}
			bool operator<(const Rankey& other)const
			{
				if (businessMoney != other.businessMoney)return businessMoney > other.businessMoney;
				if (completeTimes != other.completeTimes)return completeTimes > other.completeTimes;
				return playerID < other.playerID;
			}
			bool operator>(const Rankey& other)const
			{
				return *this < other;
			}
			int playerID;
			unsigned completeTimes;
			long long int businessMoney;
		};

		struct RankData
		{
			Rankey Key()
			{
				Rankey key;
				key.playerID = playerID;
				key.completeTimes = completeTimes;
				key.businessMoney = businessMoney;
				return key;
			}
			RankData()
			{
				playerID = -1;
				playerName = "";
				playerNation = Kingdom::null;
				completeTimes = 0;
				businessMoney = 0;
				rankNo = 0;
			}
			RankData(playerDataPtr player)
			{
				setNewData(player);
				rankNo = 0;
			}
			void setNewData(playerDataPtr player)
			{
				playerID = player->ID();
				playerName = player->Name();
				playerNation = player->Info().Nation();
				completeTimes = player->Trade().totalTask();
				businessMoney = player->Trade().historyTotalMoney();
			}
			int playerID;
			string playerName;
			int playerNation;
			unsigned completeTimes;
			long long int businessMoney;
			int rankNo;
		};

		BOOSTSHAREPTR(RankData, ptrRankData);

		STDMAP(Rankey, ptrRankData, RankMap);
		STDMAP(int, ptrRankData, PlayerMap);
	}

	class BusinessTotalRank
	{
	public:
		BusinessTotalRank() { isInitial = false; }
		static BusinessTotalRank* const _Instance;
		void initData();
		DeclareRegFunction(RankList);
	public:
		void updatePlayer(playerDataPtr player);
	private:
		NSBusinessTotalRank::ptrRankData getData(const int playerID);
		int getRank(const int playerID);

		NSBusinessTotalRank::RankMap Rank;
		NSBusinessTotalRank::PlayerMap Player;

		bool isInitial;
	};
}

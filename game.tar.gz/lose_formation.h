//###################################
//create by Jim
//2016-01-04
//###################################

#pragma once

#include "auto_do.h"
#include "mongoDB.h"
#include "man_def.h"

namespace gg
{
	class playerLoseFM : public _auto_player
	{
	public:
		const static int BaseAttributeNum = 7;
		const static int UseHoleNum = 3;
		static void initData();
		playerLoseFM(playerData* const own);
		virtual ~playerLoseFM() {}
		virtual void classLoad();
		int upgrade_base_level(const int id, const unsigned num, Json::Value& res_json);
		int active_custom_attribute(const int id);
		int select_custom_attribute(const int id);
		int wash_custom_attribute(const int id, const bool gold_mode, Json::Value& res_json);

		virtual void _auto_update();
		inline const int* lose_attribute() { return _attribute; }
		inline unsigned total_level() { return _total_level; }
		int battle_value();
	protected:
		void onRecalFormation();
		void checkDefaultCustom(const bool recal = true);
		unsigned getBaseLV(const int id);
		virtual bool _auto_save();
		bool _is_open;
		unsigned _total_level;
		int _attribute[characterNum];
		typedef std::vector<unsigned> _base_level_type;//�����ȼ�
		_base_level_type _base_level;
		//��ѡ�ȼ�
		struct _custom_data
		{
			_custom_data(
				const int i = -1, 
				const int v = 0,
				const bool o = false
			)
			{
				_idx = i;
				_val = v;
				_open = o;
			}
			int _idx;//ID//�������Ͷ���
			int _val;
			bool _open;
		};
		typedef std::vector<_custom_data> _custom_attribute_type;//�����ȼ�
		_custom_attribute_type _custom_attribute[UseHoleNum];
		int _custom_use[UseHoleNum];
	};
}
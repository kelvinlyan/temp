#pragma once

#include "action_system.h"
#include "dbDriver.h"

#define sign_sys (*gg::sign_system::_Instance)

namespace gg
{
	class SignConf
	{
		public:
			void load(const Json::Value& info);
			const ACTION::BoxList& getBoxList(playerDataPtr d, int day) const;

		private:
			std::vector<ACTION::BoxList> _one_reward;	
			std::vector<ACTION::BoxList> _two_reward;
			std::vector<int> _vip;
	};

	class sign_system
	{
		public:
			static sign_system* const _Instance;

			void initData();
			
			DeclareRegFunction(playerInfo);     
			DeclareRegFunction(getReward);

			const ACTION::BoxList& getBoxList(playerDataPtr d, int day, bool first);

		private:
			void loadFile();

		private:
			SignConf _reward1;
			SignConf _reward2;
	};
}

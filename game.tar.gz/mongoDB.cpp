#include "mongoDB.h"
#include "commom.h"
#include <boost/lexical_cast.hpp>
#pragma warning (disable : 4244)

namespace gg
{
	db_manager* const db_manager::dbMgr = new db_manager();

	db_manager::db_manager(void)
	{
		_DB_Pointer = false;
	}
		
	db_manager::~db_manager(void)
	{
	}

	bool db_manager::InitialMongo(const string uri_str)
	{		
		std::string error_str;
		conn_str = mongo::ConnectionString::parse(uri_str, error_str);
		if (!conn_str.isValid())
		{
			LogE << "parse uri_str to connect :" << error_str << LogEnd;
			return false;
		}
		try
		{
			_DB_Pointer = conn_str.connect(error_str);
		}
		catch (std::exception& e)
		{
			LogE << "connet throw" << e.what() << LogEnd;
		}
		if (_DB_Pointer)return true;
		LogE << "connect uri_str error:" << error_str << LogEnd;
		return false;
	}

	void db_manager::EnsureIndex(const std::string &collection, const mongo::BSONObj& key)
	{
		checkConnect();
		string turn_str = convert_server_db_name(collection);
		//_DB_Pointer->createIndex(turn_str, key);
	}

	bool db_manager::SaveMongo(const std::string& db_name_str, const mongo::BSONObj& key, const mongo::BSONObj& val)
	{
		checkConnect();
		bool ret = true;
		string db_turn_str = convert_server_db_name(db_name_str);
		try{
			_DB_Pointer->update(db_turn_str, mongo::Query(key), val, true);
		}
		catch(mongo::DBException &e){
			LogE << "caught error:" << e.what() << LogEnd; 
			LogE << "error db name:" << db_name_str << " key:" << key.jsonString() << " value:" << val.jsonString() << LogEnd;
			ret = false;
		}
		return ret;
	}

	void db_manager::RemoveCollection(const std::string &collection, const mongo::BSONObj& key)
	{
		checkConnect();
		string collection_trun = convert_server_db_name(collection);
		_DB_Pointer->remove(collection_trun, mongo::Query(key));
	}

	bool db_manager::DropTable(const std::string& table_name)
	{
		checkConnect();
		string table_name_trun = convert_server_db_name(table_name); 
		return _DB_Pointer->dropCollection(table_name_trun);
	}

	//mongo ����
	//1��������-1��������
	//�Զ����ѯ����˵�� ... ���аٶ�
	objCollection db_manager::QueryCustom(const std::string& db_name_str, const mongo::Query condition_custom)
	{
		checkConnect();
		string db_trun_str = convert_server_db_name(db_name_str);
		std::auto_ptr<mongo::DBClientCursor> cursor = _DB_Pointer->query(db_trun_str, condition_custom);
		objCollection objs;
		while (cursor->more())
		{
			mongo::BSONObj res = cursor->next();
			objs.push_back(res.copy());
		}
		return objs;
	}

	objCollection db_manager::Query(const std::string& db_name_str, const mongo::BSONObj key_word /* = mongo::BSONObj() */)
	{
		checkConnect();
		string db_trun_str = convert_server_db_name(db_name_str);
		mongo::Query query = mongo::Query(key_word);
		std::auto_ptr<mongo::DBClientCursor> cursor = _DB_Pointer->query(db_trun_str, query);
		objCollection objs;
		while (cursor->more()) 
		{  
			mongo::BSONObj res = cursor->next(); 
			objs.push_back(res.copy());
		}
		return objs;
	}

	mongo::BSONObj db_manager::FindOne(const std::string& db_name_str,const mongo::BSONObj& key_word)
	{
		objCollection objs = Query(db_name_str, key_word);
		if (objs.empty())return mongo::BSONObj();
		return objs.begin()->copy();
	}

	std::string db_manager::convert_server_db_name(const std::string& db_str )
	{		
		//three kingdom ������
		const static string prefix_str = "sid" + boost::lexical_cast<std::string, int>(Common::serverID())+".tk.";
		std::string tmp =  prefix_str + db_str;
		return tmp;
	}

	void db_manager::checkConnect()
	{
		if (_DB_Pointer && _DB_Pointer->isFailed())
		{
			delete _DB_Pointer;
			string error_str;
			_DB_Pointer = conn_str.connect(error_str);
		}
	}
}

//###################################
//create by Cai
//2016-04-14
//###################################

#pragma once

#include "commom.h"
#include "auto_base.h"
#include "mongoDB.h"

namespace gg
{
	namespace EmailDef
	{
		enum // msg_type
		{
			Normal = 0,
			WarLordsBattleA,
			WarLordsBattleB,
			WarLordsBattleC,
			WarLordsBattleD,
			WelcomeEmail,
			GmEmail,
			WorldBossReward,
			RechargeCostReward, //--δ��ȡ�ĳ�ֵ/���ѽ�������
			DispartItemRescue,//�����ռ���״̬, �ֽ���ߺ�Ĳ���
			CardOutOfTime,//�¿�ʧЧ
			KingdomWarRankReward,
			RichDayEmailReward,//ÿ��ó�׵�Ʊ���н���
			DaysActivityReward,
			KingdomWarCityReward,
		};

		enum
		{
			System = 0,
			Gamer,
			Package,
			Report,
			TypeMax,
		};
			
		enum
		{
			NormalReward = 0,
			GmGift,
		};

		const static unsigned AmountLimit[TypeMax] = { 50, 50, 80, 50 };

		const static std::string Id = "id";
		const static std::string Type = "ty";
		const static std::string Time = "et";
		const static std::string Sender = "sd";
		const static std::string Msg = "m";
		const static std::string ReportT = "rp";
		const static std::string Reward = "rw";
		const static std::string Common = "cm";

		const static std::string MsgType = "mt";
		const static std::string ParamList = "pl";
		
		const static std::string RewardType = "ty";
		const static std::string ActionList = "act";
		const static std::string GmGiftList = "cnt";
	}

	class Email
	{
		public:
			friend class Creator<Email>;

			void setId(int id)
			{
				data[EmailDef::Id] = id;
			}

			void setCommon();

			int id() const 
			{
				return data[EmailDef::Id].asInt();
			}
			
			int type() const 
			{
				return data[EmailDef::Type].asInt(); 
			}

			const Json::Value& toJson() const
			{
				return data;
			}

			bool common() const
			{
				return data[EmailDef::Common] != Json::Value::null
					&& data[EmailDef::Common].asBool();
			}

			const Json::Value& getPackage() const 
			{
				return data[EmailDef::Reward];
			}

		private:
			Email(unsigned time, int type, const std::string& sender, const Json::Value& msg)
			{
				data[EmailDef::Id] = -1;
				data[EmailDef::Time] = time;
				data[EmailDef::Type] = type;
				data[EmailDef::Sender] = sender;
				data[EmailDef::Msg] = msg;
			}
			Email(unsigned time, int type, const std::string& sender, const Json::Value& msg, const Json::Value& arg)
			{
				data[EmailDef::Id] = -1;
				data[EmailDef::Time] = time;
				data[EmailDef::Type] = type;
				data[EmailDef::Sender] = sender;
				data[EmailDef::Msg] = msg;
				if (type == EmailDef::Package)
					data[EmailDef::Reward] = arg;
			}
			Email(unsigned time, int type, const std::string& sender, const Json::Value& msg, const std::string& arg)
			{
				data[EmailDef::Id] = -1;
				data[EmailDef::Time] = time;
				data[EmailDef::Type] = type;
				data[EmailDef::Sender] = sender;
				data[EmailDef::Msg] = msg;
				if (type == EmailDef::Report)
					data[EmailDef::ReportT] = arg;
			}
			Email(const mongo::BSONElement& obj)
			{
				data = Common::string2json(obj.String());
			}
			Email(const Json::Value& json)
				: data(json)
			{
			}

		private:
			Json::Value data;
	};

	BOOSTSHAREPTR(Email, EmailPtr);
	STDVECTOR(EmailPtr, EmailVec);

	class CommonEmail
	{
		public:
			enum{
				All = 0,
				Nation,
				Part,
			};

			friend class Creator<CommonEmail>;
			friend class email_system;

			bool needed(playerDataPtr d);
			bool outOfDate() const;

			int getId() const
			{
				return id;
			}

			const EmailPtr& getEmail() const
			{
				return data;
			}

		private:
			CommonEmail(EmailPtr& e);
			CommonEmail(int nation, EmailPtr& e);
			CommonEmail(const std::vector<int>& parts, EmailPtr& e);
			CommonEmail(const mongo::BSONObj& obj);

			mongo::BSONObj toBSON() const;

		private:
			int id;
			unsigned time;
			int type;
			int nation;
			std::set<int> parts;
			EmailPtr data;
	};

	BOOSTSHAREPTR(CommonEmail, CommonEmailPtr);
	STDMAP(int, CommonEmailPtr, CommonEmailMap);
}

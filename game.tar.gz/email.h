//###################################
//create by Cai
//2016-04-14
//###################################

#pragma once

#include "commom.h"
#include "auto_base.h"
#include "mongoDB.h"

namespace gg
{
	namespace EmailDef
	{
		enum // msg_type
		{
			Normal = 0,
			WarLordsBattleA,
			WarLordsBattleB,
			WarLordsBattleC,
			WarLordsBattleD,
			WelcomeEmail,
			GmEmail,
			WorldBossReward,
			RechargeCostReward, //--δ��ȡ�ĳ�ֵ/���ѽ�������
			DispartItemRescue,//�����ռ���״̬, �ֽ���ߺ�Ĳ���
			CardOutOfTime,//�¿�ʧЧ
			KingdomWarRankReward,
			RichDayEmailReward,//ÿ��ó�׵�Ʊ���н���
			DaysActivityReward,
			KingdomWarOldCityReward,
			KingdomWarCityReward,
			KingdomWarCityReward2,
			DailyInpourForgetton,//���ճ�ֵ����
			DailyInpourWeekendForgetton,//���ճ�ֵ��һ����
			SecondaryCompensationReward,//��ֵ������ȡ��Ů
			ActivityRankReachBoxPay,//δ��ȡ�����а���ɽ�������
			ActivityRankListBoxPay,//���а����н���
			KingdomWarCityReward3,
			ExpeditionRankReward,
		};

		enum
		{
			System = 0,
			Gamer,
			Package,
			Report,
			TypeMax,
		};
			
		enum
		{
			NormalReward = 0,
			GmGift,
		};

		const static unsigned AmountLimit[TypeMax] = { 50, 50, 80, 50 };

		const static std::string Id = "id";
		const static std::string Type = "ty";
		const static std::string Time = "et";
		const static std::string Sender = "sd";
		const static std::string SenderId = "pi";
		const static std::string Msg = "m";
		const static std::string ReportT = "rp";
		const static std::string Reward = "rw";
		const static std::string Common = "cm";

		const static std::string MsgType = "mt";
		const static std::string ParamList = "pl";
		
		const static std::string RewardType = "ty";
		const static std::string ActionList = "act";
		const static std::string GmGiftList = "cnt";
	}

	class Email
	{
		public:
			friend class Creator<Email>;

			void setId(int id)
			{
				data[EmailDef::Id] = id;
			}

			void setCommon(int server_id);

			int id() const 
			{
				return data[EmailDef::Id].asInt();
			}
			
			int type() const 
			{
				return data[EmailDef::Type].asInt(); 
			}

			int msgType() const
			{
				return data[EmailDef::Msg][EmailDef::MsgType].asInt();
			}

			const Json::Value& toJson() const
			{
				return data;
			}

			bool common() const
			{
				return data[EmailDef::Common] != Json::Value::null
					&& data[EmailDef::Common].asBool();
			}

			void setDeleted()
			{
				deleted = true;
			}

			bool isDeleted() const
			{
				return deleted;
			}

			const Json::Value& getPackage() const 
			{
				return data[EmailDef::Reward];
			}

		private:
			Email(unsigned time, int type, int sender_id, const std::string& sender, const Json::Value& msg)
			{
				data[EmailDef::Id] = -1;
				data[EmailDef::Time] = time;
				data[EmailDef::Type] = type;
				data[EmailDef::Sender] = sender;
				data[EmailDef::SenderId] = sender_id;
				data[EmailDef::Msg] = msg;
				deleted = false;
			}
			Email(unsigned time, int type, const std::string& sender, const Json::Value& msg)
			{
				data[EmailDef::Id] = -1;
				data[EmailDef::Time] = time;
				data[EmailDef::Type] = type;
				data[EmailDef::Sender] = sender;
				data[EmailDef::Msg] = msg;
				deleted = false;
			}
			Email(unsigned time, int type, const std::string& sender, const Json::Value& msg, const Json::Value& arg)
			{
				data[EmailDef::Id] = -1;
				data[EmailDef::Time] = time;
				data[EmailDef::Type] = type;
				data[EmailDef::Sender] = sender;
				data[EmailDef::Msg] = msg;
				if (type == EmailDef::Package)
					data[EmailDef::Reward] = arg;
				deleted = false;
			}
			Email(unsigned time, int type, const std::string& sender, const Json::Value& msg, const std::string& arg)
			{
				data[EmailDef::Id] = -1;
				data[EmailDef::Time] = time;
				data[EmailDef::Type] = type;
				data[EmailDef::Sender] = sender;
				data[EmailDef::Msg] = msg;
				if (type == EmailDef::Report)
					data[EmailDef::ReportT] = arg;
				deleted = false;
			}
			Email(const mongo::BSONElement& obj)
			{
				data = Common::string2json(obj.String());
				deleted = false;
			}
			Email(const Json::Value& json)
				: data(json)
			{
				deleted = false;
			}

		private:
			Json::Value data;
			bool deleted;
	};

	BOOSTSHAREPTR(Email, EmailPtr);
	STDVECTOR(EmailPtr, EmailVec);

	class CommonEmail
		: public _auto_meta
	{
		public:
			enum
			{
				All = 0,
				Nation,
				Part,
				Channel,
			};

			friend class Creator<CommonEmail>;
			friend class email_system;

			bool needed(playerDataPtr d);
			bool outOfDate() const;
			void setDeleted();

			int getId() const
			{
				return id;
			}

			const EmailPtr& getEmail() const
			{
				return data;
			}

		private:
			CommonEmail(int server_id, EmailPtr& e);
			CommonEmail(int server_id, int nation, EmailPtr& e);
			CommonEmail(int server_id, const std::vector<int>& parts, EmailPtr& e);
			CommonEmail(int server_id, const std::vector<std::string>& channels, unsigned over_time, EmailPtr& e);
			CommonEmail(const mongo::BSONObj& obj);
			~CommonEmail();

			virtual bool _auto_save();
			void removeDB();

		private:
			int id;
			int server_id;
			unsigned time;
			int type;
			unsigned over_time;
			std::set<std::string> channels;
			int nation;
			std::set<int> parts;
			EmailPtr data;
			bool deleted;
	};

	BOOSTSHAREPTR(CommonEmail, CommonEmailPtr);
	STDMAP(int, CommonEmailPtr, CommonEmailMap);
}

#include "player_daily.h"
#include "dbDriver.h"
#include "daily_task.h"
#include "game_time.h"

namespace gg
{
	playerDaily::playerDaily(playerData* const own) : _auto_player(own)
	{
		impl_reset();
	}

	void playerDaily::tickTask(DAILY::TYPE type, const int num /* = 1 */)
	{
		if (num < 1)return;
		DAILY::ptrCONFIG config = daily_sys.getConfig(type);
		if (!config)return;//�Ҳ����¼�
		if (config->levelLimit > Own().LV())return;//�ȼ�����
		if (config->kingdomLimit && Own().Info().Nation() == Kingdom::null)return;//û�м������
		if (config->seasonLimit > -1 && config->seasonLimit != season_sys.getSeason())return;//���ڲ���
		DAILY::Data& data = dailyTask[type];
		if (data._tick_num >= config->num)return;//�Ѿ��������Щ����
		const int old_num = data._tick_num;
		data._tick_num += num;
		if (data._tick_num >= config->num)data._tick_num = config->num;
		const int add_num = (data._tick_num - old_num) < 0 ? 0 : (data._tick_num - old_num);
		const int old_point = dailyPoints;
		if (data._tick_num > data._won_num * config->per_step)
		{
			const int add_times = (data._tick_num - data._won_num * config->per_step) / config->per_step;
			data._won_num += add_times;
			alterPoints(add_times * config->active_num);//�����ճ�����
			Log(DBLOG::strLogDailyTask, Own().getOwnDataPtr(), 0, type, add_times * config->active_num, old_point, dailyPoints);
		}
		_sign_auto();
	}

	void playerDaily::alterPoints(const int val)
	{
		dailyPoints += val;
		dailyPoints = dailyPoints < 0 ? 0 : dailyPoints;
		const int maxPoints = daily_sys.getMaxPoint(Own().LV());
		dailyPoints = dailyPoints > maxPoints ? maxPoints : dailyPoints;
		_sign_auto();
	}

	bool playerDaily::checkTaskBox(const DAILY::TYPE type)
	{
		return (taskRecord.find(type) != taskRecord.end());
	}

	void playerDaily::trueTaskBox(const DAILY::TYPE type)
	{
		taskRecord.insert(type);
		_sign_auto();
	}

	bool playerDaily::checkBox(const int idPoint)
	{
		return (boxRecord.find(idPoint) != boxRecord.end());
	}

	void playerDaily::trueBox(const int idPoint)
	{
		boxRecord.insert(idPoint);
		_sign_auto();
	}

	bool playerDaily::checkTaskCompelete(const DAILY::TYPE type)
	{
		DAILY::ptrCONFIG config = daily_sys.getConfig(type);
		if (!config)return false;//�Ҳ����¼�
		return (dailyTask[type]._tick_num >= config->num);
	}

	void playerDaily::classLoad()
	{
		mongo::BSONObj key = BSON(strPlayerID << Own().ID());
		mongo::BSONObj obj = db_mgr.FindOne(DBN::dbPlayerDaily, key);
		if (obj.isEmpty())return;
		dailyPoints = obj["dp"].Int();
		{
			vector<mongo::BSONElement> vec = obj["arr"].Array();
			for (unsigned i = 0; i < vec.size(); ++i)
			{
				mongo::BSONElement& elem = vec[i];
				DAILY::Data data;
				data._tick_num = elem["v"].Int();
				if (!elem["wv"].eoo())data._won_num = elem["wv"].Int();
				dailyTask[(DAILY::TYPE)elem["i"].Int()] = data;
			}
		};
		{
			vector<mongo::BSONElement> vec = obj["box"].Array();
			for (unsigned i = 0; i < vec.size(); ++i)
			{
				mongo::BSONElement& elem = vec[i];
				boxRecord.insert(elem.Int());
			}
		};
		if(!obj["tbox"].eoo())//��������ȡ
		{
			vector<mongo::BSONElement> vec = obj["tbox"].Array();
			for (unsigned i = 0; i < vec.size(); ++i)
			{
				mongo::BSONElement& elem = vec[i];
				taskRecord.insert(elem.Int());
			}
		};
	}

	void playerDaily::impl_reset()
	{
		dailyPoints = 0;
		dailyTask.clear();
		taskRecord.clear();
		boxRecord.clear();
		const DAILY::CONFIGMAP& ALLMAP = daily_sys.getAll();
		for (DAILY::CONFIGMAP::const_iterator it = ALLMAP.begin(); it != ALLMAP.end(); ++it)
		{
			DAILY::ptrCONFIG ptr = it->second;
			dailyTask[ptr->type] = DAILY::Data();
		}
	}

	void playerDaily::resetTask()
	{
		impl_reset();
		_sign_auto();
	}

	void playerDaily::_auto_update()
	{
		qValue json(qJson::qj_array), data_json(qJson::qj_array), box_json(qJson::qj_array), tbox_json(qJson::qj_array);
		for (DAILY::DailyTaskMap::const_iterator it = dailyTask.begin(); it != dailyTask.end(); ++it)
		{
			qValue sg_json(qJson::qj_array);
			sg_json.append(it->first);
			const DAILY::Data& data = it->second;
			sg_json.append(data._tick_num);
			sg_json.append(data._won_num);
			data_json.append(sg_json);
		}
		for (BOXMAP::const_iterator it = boxRecord.begin(); it != boxRecord.end(); ++it)
		{
			box_json.append(*it);
		}
		for (BOXMAP::const_iterator it = taskRecord.begin(); it != taskRecord.end(); ++it)
		{
			tbox_json.append(*it);
		}
		json.append(res_sucess).append(dailyPoints).append(data_json).append(box_json).append(tbox_json);
		Own().sendToClientFillMsg(gate_client::player_daily_info_update_resp, json);
	}

	bool playerDaily::_auto_save()
	{
		mongo::BSONObj key = BSON(strPlayerID << Own().ID());
		mongo::BSONArrayBuilder arr, arr_box, arr_tbox;
		for (DAILY::DailyTaskMap::const_iterator it = dailyTask.begin(); it != dailyTask.end(); ++it)
		{
			const DAILY::Data& data = it->second;
			arr << BSON("i" << it->first << "v" << data._tick_num << "wv" << data._won_num);
		}
		for (BOXMAP::const_iterator it = boxRecord.begin(); it != boxRecord.end(); ++it)
		{
			arr_box << *it;
		}
		for (BOXMAP::const_iterator it = taskRecord.begin(); it != taskRecord.end(); ++it)
		{
			arr_tbox << *it;
		}
		mongo::BSONObj obj = BSON(strPlayerID << Own().ID() <<
			"arr" << arr.arr() << "box" << arr_box.arr() <<
			"dp" << dailyPoints << "tbox" << arr_tbox.arr());
		return db_mgr.SaveMongo(DBN::dbPlayerDaily, key, obj);
	}



}
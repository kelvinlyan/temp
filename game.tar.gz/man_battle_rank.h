//###################################
//create by Jim
//2016-11-07
//###################################

#pragma once

#include "dbDriver.h"

#define man_battle_rank (*gg::ManBattleRank::_Instance)

namespace gg
{
	namespace NSManRank
	{
		struct RankData
		{
			RankData()
			{
				playerID = -1;
				playerName = "";
				manID = -1;
				battleValue = 0;
				manLV = 0;
				memset(attri, 0x0, sizeof(attri));
			}
			RankData(playerDataPtr player, playerMan& man)
			{
				setNewData(player, man);
			}
			void setNewData(playerDataPtr player, playerMan& man)
			{
				playerID = player->ID();
				playerName = player->Name();
				manID = man.mID();
				battleValue = man.battleValue();
				manLV = man.LV();
				man.all_attribute(attri);
			}
			RankData(playerDataPtr player, playerManPtr man)
			{
				setNewData(player, man);
			}
			void setNewData(playerDataPtr player, playerManPtr man)
			{
				playerID = player->ID();
				playerName = player->Name();
				manID = man->mID();
				battleValue = man->battleValue();
				manLV = man->LV();
				man->all_attribute(attri);
			}
			bool isNull()
			{
				return playerID < 0 || manID < 1 || battleValue < 1;
			}
			qValue toAttriJson()
			{
				qValue json(qJson::qj_array);
				for (unsigned i = 0; i < characterNum; ++i)
				{
					json.append(attri[i]);
				}
				return json;
			}
			inline int rawID() { return manID / 100; }
			int playerID;
			string playerName;
			int manID;
			unsigned manLV;
			int battleValue;
			int attri[characterNum];
		};

		BOOSTSHAREPTR(RankData, ptrRankData);
		STDVECTOR(ptrRankData, RankVector);
		struct FindKey
		{
			explicit FindKey(const int pid = -1,
				const int rid = -1)
			{
				playerID = pid;
				rawID = rid;
			}
			bool operator<(const FindKey& other)const
			{
				if (rawID != other.rawID)return rawID < other.rawID;
				return playerID < other.playerID;
			}
			int playerID;
			int rawID;
		};
		STDMAP(FindKey, ptrRankData, PlayerMap);
	}

	class ManBattleRank
	{
	public:
		ManBattleRank() { isInitial = false; }
		static ManBattleRank* const _Instance;
		void initData();
		DeclareRegFunction(RankList);
		DeclareRegFunction(ManDetail);
	public:
		void updateInfo(playerDataPtr player);
		void updatePlayer(playerDataPtr player, playerMan& man);
		void updatePlayer(playerDataPtr player, playerManPtr man);
	private:
		NSManRank::ptrRankData getData(const int playerID, const int manID);

		NSManRank::RankVector Rank;
		NSManRank::PlayerMap Player;

		bool isInitial;
	};
}

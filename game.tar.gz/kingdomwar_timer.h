#pragma once

#include "timmer.hpp"

namespace gg
{
	namespace KingdomWar
	{
		class Timer
		{
			public:
				typedef boost::function<void()> TickFunc;
			private:
				struct Item
				{
					Item(unsigned tick_time, const TickFunc& func)
						: _tick_time(tick_time), _tick_func(func){}

					bool operator<(const Item& rhs) const
					{
						return _tick_time > rhs._tick_time;
					}

					unsigned _tick_time;
					TickFunc _tick_func;
				};
				static void check()
				{
					unsigned cur_time = Common::gameTime();
					while(!_queue.empty() &&
							cur_time >= _queue.top()._tick_time)
					{
						Item item = _queue.top();
						_queue.pop();
						item._tick_func();
					}
				}
			public:
				static void start()
				{
					::Timer::AddEventNextTimeCT(boost::bind(&Timer::check), Inter::event_kingdomwar_timer, 0, 1);
				}
				static void add(unsigned tick_time, const TickFunc& func)
				{
					_queue.push(Item(tick_time, func));
				}

			private:
				static std::priority_queue<Item> _queue;
		};
	}
}

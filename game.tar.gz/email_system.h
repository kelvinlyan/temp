//###################################
//create by Cai
//2016-04-07
//###################################

#pragma once

#include "dbDriver.h"
#include "email.h"

#define email_sys (*gg::email_system::_Instance)

namespace gg
{	
	class email_system
	{
		public:
			static email_system* const _Instance;
			void initData();
		
			DeclareRegFunction(playerInfoReq);
			DeclareRegFunction(sendEmailReq);
			DeclareRegFunction(getPackageReq);
			DeclareRegFunction(redPointReq);

			DeclareRegFunction(gmSendEmailReq);
			
			// create email
			EmailPtr createSystem(const std::string& msg);
			EmailPtr createSystem(int msg_type, const Json::Value& param = Json::arrayValue);
			EmailPtr createGamer(const std::string& sender, const std::string& msg);
			EmailPtr createPackage(int msg_type, const Json::Value& param_list, const Json::Value& reward);
			EmailPtr createGmPackage(int msg_type, const Json::Value& param_list, const Json::Value& reward);
			EmailPtr createReport(int msg_type, const Json::Value& param_list, const std::string& report);

			// send email
			void sendToAll(EmailPtr& e);
			void sendToKingdom(int nation, EmailPtr& e);
			void sendToPart(const std::vector<int>& player_list, EmailPtr& e);
			void sendToPlayer(int player_id, EmailPtr& e);

			EmailPtr createFromBSON(const mongo::BSONElement& obj);
			EmailPtr getCommonEmail(int id);
			unsigned getCommonEmails(playerDataPtr d, int player_owner_email_id, EmailVec& vec);
			unsigned getCommonId();

		private:
			CommonEmailPtr createAll(EmailPtr& e);
			CommonEmailPtr createNation(int nation, EmailPtr& e);
			CommonEmailPtr createPart(const std::vector<int>& parts, EmailPtr& e);

			void saveDB(const CommonEmailPtr& e);

		private:
			virtual void classLoad();
			unsigned common_email_id;
			CommonEmailMap common_emails;
	};
}

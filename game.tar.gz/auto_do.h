//###################################
//create by Jim
//2015-11-04
//###################################

#pragma once

#include "commom.h"
#include "auto_base.h"

#define helper_mgr (*gg::helper::helperMgr)

namespace gg
{
	class helper
	{
	public:
		static helper* const helperMgr;
		helper();

		void _run_tick();
		void _tick_update(_meta_weak pointer);
		void _tick_save(_meta_weak pointer);
		void _tick_both(_meta_weak pointer);

		void _over_tick();//��Ϸ���̽���ʹ��
	};
}
#include "item_system.h"
#include "task_def.h"
#include "chat.h"
#include "task_mgr.h"
#include "email_system.h"

namespace gg
{
	const static unsigned equipDispartLimit = 26;//װ���ֽ�����
	const static unsigned equipExchangeLimit = 55;//װ��������ת������
	const static unsigned gemUseLimit = 60;//��ʯ�ϳ���Ƕ����
	const static unsigned equipRebornLimit = 45;//ϴ������
	const static unsigned equipBuildLimit = 26;//װ����������

	item_system* const item_system::_Instance = new item_system();

	//�̵�
	UNORDERMAP(int, int, SHOPMAP);
	static SHOPMAP silverShop, goldShop, pawnShop;
	//װ��ǿ������
	static vector< vector< int > > eqRiseUp, eqRiseUpT;
	//�������
	struct ItemGift 
	{
		LIMIT::valLimit ulimit;
		acPtrList actions;
	};
	BOOSTSHAREPTR(ItemGift, iGiftPtr);
	UNORDERMAP(int, iGiftPtr, acMap);
	static acMap mapAC;
	//װ��ϴ��
	typedef vector<unsigned> RateRB;
	RateRB rbNumRate;//ϴ����������
	RateRB rbAttriRate;//ϴ��Ʒ�ʸ���
	struct RebornData
	{
		AttributeIDX attriIDX;
		int attriLower;
		int attriUpper;
		unsigned weightNum;
	};
	typedef vector< vector< vector< RebornData > > > LimitList;
	static LimitList RebornLimit;//����ϴ��������
	const static unsigned RBEquipNum = 3;
	const static int RBCost[RBEquipNum] = {3000, 5000, 8000};
	const static int RBCusCost[itemDeclare::rbNum + 1][itemDeclare::rbNum + 1] = {
		{ 20, 20, 20, 20 },
		{ 20, 80, 300, 300 },
		{ 20, 80, 300, 300 },
		{ 20, 80, 300, 300 }
	};
	static vector< double > EXCGUpper, EXCGLower;
	//��ʯ�ֽ���
	UNORDERMAP(int, unsigned, equipDpMap);
	equipDpMap mapItemDp;
	//��ʯ�ϳ��б�
	struct gemCM
	{
		int itemID;
		unsigned num;
		int limitLV;
	};
	UNORDERMAP(int, gemCM, gemCMMap);
	static gemCMMap mapGemCM;

	static unsigned itemDpNum(const int itemID)
	{
		equipDpMap::iterator it = mapItemDp.find(itemID);
		if (it == mapItemDp.end())return 0;
		return it->second;
	}

	inline static int gemOriginID()
	{
		static int itemID = Common::loadJsonFile("./instance/gem/origin.json")["origin"].asInt();
		return itemID;
	}

	struct equipBuild
	{
		~equipBuild(){}
		int formulaID;//�䷽ID
		int buildID;//���ɵĵ���ID
		struct cost
		{
			int itemID;
			unsigned num;
		};
		vector<cost> costList;
		int silver_cost;
		int gold_cost;
	};
	BOOSTSHAREPTR(equipBuild, eqBuildPtr);
	UNORDERMAP(int, eqBuildPtr, formulaMap);
	static formulaMap formulas;
	eqBuildPtr findFormula(const int fomulaID)
	{
		formulaMap::iterator it = formulas.find(fomulaID);
		if (it == formulas.end())return eqBuildPtr();
		return it->second;
	}

	void item_system::initData()
	{
		cout << "load item system ..." << endl;
		{
			formulas.clear();
			Json::Value json = Common::loadJsonFile("./instance/equipment/formula.json");
			for (unsigned i = 0; i < json.size(); ++i)
			{
				Json::Value& json_data = json[i];
				eqBuildPtr build = Creator<equipBuild>::Create();
				build->formulaID = json_data["formulaID"].asInt();
				build->buildID = json_data["buildID"].asInt();
				build->gold_cost = json_data["gold"].asInt();
				build->silver_cost = json_data["silver"].asInt();
				for (unsigned n = 0; n < json_data["cost"].size(); ++n)
				{
					Json::Value& cost_json = json_data["cost"][n];
					equipBuild::cost c;
					c.itemID = cost_json[0u].asInt();
					c.num = cost_json[1u].asUInt();
					build->costList.push_back(c);
				}
				formulas[build->formulaID] = build;
			}
		};//�䷽

		cout << "load ./instance/items/" << endl;
		FileJsonSeq seq = Common::loadFileJsonFromDir("./instance/items/");
		for (unsigned i = 0; i < seq.size(); ++i)
		{
			cfgItemPtr config = Creator<itemConfig>::Create();
			Json::Value& json = seq[i];
			if (json.isNull() || !json.isObject())continue;
			config->itemID = json["itemID"].asInt();
			if (config->itemID < 1)continue;
			config->type = json["type"].asUInt();
			config->quality = json["quality"].asUInt();
			const unsigned state = json["state"].asUInt();
			itemConfig::DEC& dec = config->_declare;
			config->state = state;
			if (itemDef::common == state)
			{
				dec._com.stackNum = json["stackNum"].asUInt();
			}
			else if (itemDef::equipment == state)
			{
				dec._equip.equipLimit = json["equipLimit"].asInt();
				dec._equip.equipPos = json["equipPos"].asUInt();
				if (dec._equip.equipPos >= 6)continue;
				dec._equip.upgradeUse = json["upgradeUse"].asUInt();
				dec._equip.rebornIdx = json["rebornIdx"].asUInt();
				dec._equip.equipAttri = new(::GNew(sizeof(vector< vector<int> >))) vector< vector<int> >();//����ռ�
				dec._equip.equipAttriRate = new(::GNew(sizeof(vector< vector<double> >))) vector< vector<double> >();//����ռ�
				itemConfig::EQUIP::AttriList& equipAttri = *dec._equip.equipAttri;
				itemConfig::EQUIP::AttriRateList& equipAttriRate = *dec._equip.equipAttriRate;
				equipAttri.resize(json["equipAttri"].size());
				equipAttriRate.resize(json["equipAttri"].size());
				for (unsigned num = 0; num < equipAttri.size(); ++num)
				{
					vector<int>& attri_single = equipAttri[num];
					vector<double>& attri_rate_single = equipAttriRate[num];
					attri_single.resize(characterNum);
					attri_rate_single.resize(characterNum);
					for (unsigned idx = 0; idx < characterNum; ++idx)
					{
						attri_single[idx] = json["equipAttri"][num][0u][idx].asInt();
						attri_rate_single[idx] = json["equipAttri"][num][1u][idx].asDouble();
					}
				}
			}
			else if (itemDef::gem == state)
			{
				dec._com.stackNum = json["stackNum"].asUInt();
				dec._gem.level = json["gemLv"].asUInt();
				dec._gem.rate = json["gemAdd"].asDouble();
			}
			else
			{
				LogE << "no define item type ..." << config->itemID << LogEnd;
				continue;
			}
			iMap[config->itemID] = config;
		}

		//װ���ֽ�Ļ�õ�ԭʯ����
		{
			Json::Value json = Common::loadJsonFile("./instance/gem/origin_prize.json");
			mapItemDp.clear();
			for (unsigned i = 0; i < json.size(); ++i)
			{
				mapItemDp[json[i][0u].asInt()] = json[i][1u].asUInt();
			}
		};

		//���Դ򿪵ĵ���
		{
			FileJsonSeq seq = Common::loadFileJsonFromDir("./instance/gifts/");
			for (unsigned i = 0; i < seq.size(); ++i)
			{
				Json::Value& json = seq[i];
				const int itemID = json["itemID"].asInt();
				iGiftPtr ptr = Creator<ItemGift>::Create();
				Json::Value& limit_json = json["limit"];
				ptr->ulimit = toLimitData(limit_json);
				const int giftID = json["gift"].asInt();
				ptr->actions = actionFormat(giftID);
				mapAC[itemID] = ptr;
			}
		};

		//װ������
		{
			Json::Value json = Common::loadJsonFile("./instance/equipment/upgrade.json");
			eqRiseUp.clear();
			eqRiseUpT.clear();
			for (unsigned i = 0; i < json.size(); ++i)
			{
				Json::Value& nj = json[i];
				vector<int> s, st;
				st.push_back(0);
				for (unsigned n = 0; n < nj.size(); ++n)
				{
					int num = nj[n].asInt();
					s.push_back(num);
					st.push_back(num + st[n]);
				}
				eqRiseUp.push_back(s);
				eqRiseUpT.push_back(st);
			}
		};

		//װ��ϴ��
		{
			//ϴ����������
			Json::Value n_json = Common::loadJsonFile("./instance/equipment/reborn_num.json");
			rbNumRate.clear();
			for (unsigned i = 0; i < n_json.size() && i <= itemDeclare::rbNum; ++i)rbNumRate.push_back(n_json[i].asUInt());
			//ϴ��Ʒ�ʸ���
			Json::Value s_json = Common::loadJsonFile("./instance/equipment/reborn_quality.json");
			rbAttriRate.clear();
			for (unsigned i = 0; i < s_json.size(); ++i)rbAttriRate.push_back(s_json[i].asUInt());
			//ϴ����ֵ������
			Json::Value l_json = Common::loadJsonFile("./instance/equipment/reborn_limit.json");
			RebornLimit.clear();
			for (unsigned i = 0; i < l_json.size() && i < RBEquipNum; ++i)
			{
				Json::Value& json_limit = l_json[i];
				vector< vector< RebornData > > vec_reborn;
				for (unsigned n = 0; n < json_limit.size(); ++n)
				{
					Json::Value& json_vec = json_limit[n];
					vector< RebornData > sg_reborn;
					for (unsigned idx = 0; idx < json_vec.size() && idx < characterNum; ++idx)
					{
						Json::Value& sg_json = json_vec[idx];
						if (sg_json.empty())continue;//����
						RebornData data_reborn;
						data_reborn.attriIDX = (AttributeIDX)idx;
						data_reborn.attriLower = sg_json[0u].asInt();
						data_reborn.attriUpper = sg_json[1u].asInt();
						data_reborn.weightNum = sg_json[2u].asUInt();
						sg_reborn.push_back(data_reborn);
					}
					vec_reborn.push_back(sg_reborn);
				}
				RebornLimit.push_back(vec_reborn);
			}
			//ת�������任
			Json::Value exc_json = Common::loadJsonFile("./instance/equipment/reborn_exchange.json");
			EXCGUpper.resize(RebornLimit.size(), 0.0);
			EXCGLower.resize(RebornLimit.size(), 0.0);
			for (unsigned i = 0; i < RebornLimit.size(); ++i)
			{
				EXCGUpper[i] = (exc_json["upper"][i].asDouble());
				EXCGLower[i] = (exc_json["lower"][i].asDouble());
			}
		};

		//�����б�
		{//�����̵�
			Json::Value shop = Common::loadJsonFile("./instance/shop/silver.json");
			silverShop.clear();
			for (unsigned i = 0; i < shop.size();++i)
			{
				silverShop[shop[i][0u].asInt()] = shop[i][1u].asInt();
			}
		};
		{//����̵�
			Json::Value shop = Common::loadJsonFile("./instance/shop/gold.json");
			goldShop.clear();
			for (unsigned i = 0; i < shop.size(); ++i)
			{
				goldShop[shop[i][0u].asInt()] = shop[i][1u].asInt();
			}
		};
		{//����
			Json::Value shop = Common::loadJsonFile("./instance/shop/pawn.json");
			pawnShop.clear();
			for (unsigned i = 0; i < shop.size(); ++i)
			{
				pawnShop[shop[i][0u].asInt()] = shop[i][1u].asInt();
			}
		};
		{//ˮ���ϳɱ�mapGemCM
			Json::Value json = Common::loadJsonFile("./instance/gem/gem_compose.json");
			for (unsigned i = 0; i < json.size(); ++i)
			{
				Json::Value& val = json[i];
				int itemID = val["itemID"].asInt();
				gemCM gcm;
				gcm.itemID = val["sourceID"].asInt();
				gcm.num = val["sourceNum"].asUInt();
				gcm.limitLV = val["limitLV"].asInt();//�ϳɱ�ʯ����
				mapGemCM[itemID] = gcm;
			}
		};//
	}

	bool item_system::canRebornQuality(const unsigned quality)
	{
		if (quality < RebornLimit.size())
		{
			return true;
		}
		return false;
	}

	unsigned item_system::CreateRebornNum()
	{
		unsigned rd_num = Common::randomBetween(1, 10000);
		unsigned t_num = 0;
		for (unsigned i = 0; i < rbNumRate.size(); ++i)
		{
			t_num += rbNumRate[i];
			if (rd_num <= t_num)
			{
				return i;
			}
		}
		return 0;
	}
	vector<itemDeclare::rbAttri> item_system::CreateRebornValueList(const unsigned quality, const unsigned num, vector<AttributeIDX> filter)
	{
		vector<itemDeclare::rbAttri> vec;
		if (quality >= RebornLimit.size())
		{
			return vec;
		}
		for (unsigned n = 0; n < num; ++n)
		{
			unsigned rd_num = Common::randomBetween(1, 10000);
			unsigned t_num = 0;
			unsigned reborn_idx = 0;
			for (unsigned i = 0; i < rbAttriRate.size(); ++i)
			{
				t_num += rbAttriRate[i];
				if (rd_num <= t_num)
				{
					reborn_idx = i;
					break;
				}
			}
			vector< RebornData > rbVector = RebornLimit[quality][reborn_idx];
			unsigned random_upper = 10000;
			for (unsigned nidx = 0; nidx < filter.size(); ++nidx)
			{
				for (unsigned i = 0; i < rbVector.size(); ++i)
				{
					if (rbVector[i].attriIDX == filter[nidx])
					{
						random_upper -= rbVector[i].weightNum;
						rbVector.erase(rbVector.begin() + i);
						break;
					}
				}
			}

			const unsigned weight = (unsigned)Common::randomBetween(0, random_upper - 1);
			unsigned total_weight = 0;
			for (unsigned i = 0; i < rbVector.size(); ++i)
			{
				const RebornData& rbData = rbVector[i];
				total_weight += rbData.weightNum;
				if (total_weight > weight)
				{
					int attri_val = Common::randomBetween(rbData.attriLower, rbData.attriUpper);
					vec.push_back(itemDeclare::rbAttri(rbData.attriIDX, attri_val));
					filter.push_back(AttributeIDX(rbData.attriIDX));
					break;
				}
			}
		}
		return vec;
	}

	itemDeclare::rbAttri item_system::CreateRebornValue(const unsigned quality, const vector<AttributeIDX> filter)
	{
		if (quality >= RebornLimit.size())
		{
			return itemDeclare::rbAttri();
		}
		unsigned rd_num = Common::randomBetween(1, 10000);
		unsigned t_num = 0;
		unsigned reborn_idx = 0;
		for (unsigned i = 0; i < rbAttriRate.size(); ++i)
		{
			t_num += rbAttriRate[i];
			if (rd_num <= t_num)
			{
				reborn_idx = i;
				break;
			}
		}
		vector< RebornData > rbVector = RebornLimit[quality][reborn_idx];
		unsigned random_upper = 10000;
		for (unsigned n = 0; n < filter.size(); ++n)
		{
			for (unsigned i = 0; i < rbVector.size(); ++i)
			{
				if (rbVector[i].attriIDX == filter[n])
				{
					random_upper -= rbVector[i].weightNum;
					rbVector.erase(rbVector.begin() + i);
					break;
				}
			}
		}
		const unsigned weight = (unsigned)Common::randomBetween(0, random_upper - 1);
		unsigned total_weight = 0;
		for (unsigned i = 0; i < rbVector.size(); ++i)
		{
			const RebornData& rbData = rbVector[i];
			total_weight += rbData.weightNum;
			if (total_weight > weight)
			{
				int attri_val = Common::randomBetween(rbData.attriLower, rbData.attriUpper);
				return itemDeclare::rbAttri(rbData.attriIDX, attri_val);
			}
		}
		return itemDeclare::rbAttri(0, 0);
	}
	int item_system::CreateRebornValue(const unsigned quality, const unsigned attri_idx)
	{
		if (quality >= RebornLimit.size())
		{
			return 0;
		}
		if (attri_idx >= characterNum)
		{
			return 0;
		}
		unsigned rd_num = Common::randomBetween(1, 10000);
		unsigned t_num = 0;
		unsigned reborn_idx = 0;
		for (unsigned i = 0; i < rbAttriRate.size(); ++i)
		{
			t_num += rbAttriRate[i];
			if (rd_num <= t_num)
			{
				reborn_idx = i;
				break;
			}
		}
		const vector< RebornData >& rbVector = RebornLimit[quality][reborn_idx];
		for (unsigned i = 0; i < rbVector.size(); ++i)
		{
			const RebornData& rbData = rbVector[i];
			if (attri_idx == rbData.attriIDX)return Common::randomBetween(rbData.attriLower, rbData.attriUpper);
		}
		return 0;
	}

	const vector<int>& item_system::equipRiseUpCost(const unsigned idx)
	{
		return eqRiseUp[idx];
	}

	const vector<int>& item_system::equipRiseUpCostT(const unsigned idx)
	{
		return eqRiseUpT[idx];
	}

	cfgItemPtr item_system::getConfig(const int itemID)
	{
		itemConfigMap::iterator it = iMap.find(itemID);
		if (it == iMap.end())return cfgItemPtr();
		return it->second;
	}

	const int getPrice(const int key, const SHOPMAP& m)
	{
		SHOPMAP::const_iterator it = m.find(key);
		if (it == m.end())return -1;
		return it->second;
	}


	void item_system::silverShopReq(net::Msg& m, Json::Value& r)
	{
		playerDataPtr player = player_mgr.getPlayer(m.playerID);
		if (!player)Return(r, err_illedge);
		ReadJsonArray;
		int itemID = js_msg[0u].asInt();
		unsigned num = js_msg[1u].asUInt();
		if (num < 1 || num > 99)Return(r, err_illedge);
		int price = getPrice(itemID, silverShop);
		if (price < 1)Return(r, err_illedge);
		int cost = price * num;
		if (cost > player->Res().getSilver())Return(r, err_silver_not_enough);
		if (!player->Items().canAddItem(itemID, num))Return(r, err_bag_full);
		player->Res().alterSilver(-cost);
		player->Items().addItem(itemID, num);
		Log(DBLOG::strLogItemShop, player, 0, cost, itemID, num);
		Return(r, res_sucess);
	}
	void item_system::goldShopReq(net::Msg& m, Json::Value& r)
	{
		playerDataPtr player = player_mgr.getPlayer(m.playerID);
		if (!player)Return(r, err_illedge);
		ReadJsonArray;
		int itemID = js_msg[0u].asInt();
		unsigned num = js_msg[1u].asUInt();
		if (num < 1 || num > 99)Return(r, err_illedge);
		int price = getPrice(itemID, goldShop);
		if (price < 1)Return(r, err_illedge);
		int cost = price * num;
		if (cost > player->Res().getCash())Return(r, err_silver_not_enough);
		if (!player->Items().canAddItem(itemID, num))Return(r, err_bag_full);
		player->Res().alterCash(-cost);
		player->Items().addItem(itemID, num);
		Log(DBLOG::strLogItemShop, player, 1, cost, itemID, num);
		Return(r, res_sucess);
	}
	void item_system::pawnReq(net::Msg& m, Json::Value& r)
	{
		playerDataPtr player = player_mgr.getPlayer(m.playerID);
		if (!player)Return(r, err_illedge);
		ReadJsonArray;
		int localID = js_msg[0u].asInt();
		unsigned num = js_msg[1u].asUInt();
		if (num < 1)Return(r, err_illedge);
		itemPtr item = player->Items().getLocalItem(localID);
		if (!item || item->Num() < num)Return(r, err_illedge);
		cfgItemPtr config = item->getConfig();
		int price = getPrice(item->itemID(), pawnShop);
		if (price < 0)Return(r, err_illedge);
		int silver_rw = price * num;
		if (config->isEquip())
		{
			if (item->canOFFGem() != res_sucess)Return(r, err_bag_full);
			if (item->hasGem() && player->Res().getCash() < 1)Return(r, err_gold_not_enough);
			unsigned c_lv = item->getLv();
			const vector<int>& cost = equipRiseUpCostT(config->_declare._equip.upgradeUse);
			silver_rw += int((cost[c_lv] - cost[1]) * 0.8);
			if (item->hasGem())player->Res().alterCash(-1);
		}
		item->OFFGem();
		item->cutNum(num);
		player->Res().alterSilver(silver_rw);
		r[strMsg][1u] = silver_rw;
		Log(DBLOG::strLogItemShop, player, 2, silver_rw, item->itemID(), 1);
		Return(r, res_sucess);
	}
	void item_system::batchPawnReq(net::Msg& m, Json::Value& r)
	{
		playerDataPtr player = player_mgr.getPlayer(m.playerID);
		if (!player)Return(r, err_illedge);
		ReadJsonArray;
		itemVec vec;
		for (unsigned i = 0; i < js_msg.size() && i < 30; ++i)
		{
			Json::Value& json = js_msg[i];
			itemPtr item = player->Items().getLocalItem(json[0u].asInt());
			unsigned num = json[1u].asUInt();
			if (num < 1)Return(r, err_illedge);
			if (!item)Return(r, err_item_no_found);
			if (item->Num() < num)Return(r, err_illedge);
			cfgItemPtr config = item->getConfig();
			if (!config)Return(r, err_illedge);
			int price = getPrice(item->itemID(), pawnShop);
			if (price < 0)Return(r, err_illedge);
			if (item->hasGem())Return(r, err_illedge);
			vec.push_back(item);
		}
		int silver_rw = 0;
		for (unsigned i = 0; i < vec.size(); ++i)
		{
			Json::Value& json = js_msg[i];
			unsigned num = json[1u].asUInt();
			itemPtr item = vec[i];
			cfgItemPtr config = item->getConfig();
			int price = getPrice(item->itemID(), pawnShop);
			silver_rw += (price * num);
			if (config->isEquip())
			{
				unsigned c_lv = item->getLv();
				const vector<int>& cost = equipRiseUpCostT(config->_declare._equip.upgradeUse);
				silver_rw += int((cost[c_lv] - cost[1])*0.8);
			}
			item->cutNum(num);
		}
		player->Res().alterSilver(silver_rw);
		r[strMsg][1u] = silver_rw;
		Return(r, err_illedge);
	}
	void item_system::equipCDReq(net::Msg& m, Json::Value& r)
	{
		playerDataPtr player = player_mgr.getPlayer(m.playerID);
		if (!player)Return(r, err_illedge);
		player->Items().updateUpCD();
	}
	void item_system::equipCDClearReq(net::Msg& m, Json::Value& r)
	{
		playerDataPtr player = player_mgr.getPlayer(m.playerID);
		if (!player)Return(r, err_illedge);
		unsigned cd = player->Items().getUpCD();
		unsigned now = Common::gameTime();
		if (cd <= now)Return(r, err_illedge);
		int cost = (cd - now) / MINUTE + ((cd - now) % MINUTE ? 1 : 0);
		if (player->Res().getCash() < cost)Return(r, err_cash_not_enough);
		player->Res().alterCash(-cost);
		player->Items().clearUpCD();
		Return(r, res_sucess);
	}
	void item_system::equipRiseUp(net::Msg& m, Json::Value& r)
	{
		playerDataPtr player = player_mgr.getPlayer(m.playerID);
		if (!player)Return(r, err_illedge);
		ReadJsonArray;
		const int localID = js_msg[0u].asInt();
		const unsigned times = js_msg[1u].asUInt();
		if (times != 1 && times != 10)Return(r, err_illedge);
		itemPtr item = player->Items().getLocalItem(localID, itemDef::pos_bag | itemDef::pos_man);
		if (!item)Return(r, err_item_no_found);
		cfgItemPtr config = item->getConfig();
		if (!config || !config->isEquip())Return(r, err_illedge);
		bool mini_ok = false;
		const unsigned begin_level = item->getLv();
		Json::Value& res_json = r[strMsg][1u] = Json::arrayValue;
		const vector<int>& cost = equipRiseUpCost(config->_declare._equip.upgradeUse);
		unsigned sucess_times = 0;
		const int bengin_silver = player->Res().getSilver();
		for (unsigned i = 0; i < times; ++i)
		{
			Json::Value sg_res = Json::arrayValue;
			if (player->Info().VipLv() < 1 && !player->Items().UpOK())
			{
				sg_res.append(err_equip_up_cd);
				sg_res.append(0);
				res_json.append(sg_res);
				break;
			}
			const unsigned c_lv = item->getLv();
			if (c_lv >= player->LV())
			{
				sg_res.append(err_over_player_level);
				sg_res.append(0);
				res_json.append(sg_res);
				break;
			}
			if (c_lv >= cost.size())
			{
				sg_res.append(err_equip_level_max);
				sg_res.append(0);
				res_json.append(sg_res);
				break;
			}
			if (player->Res().getSilver() < cost[c_lv])
			{
				sg_res.append(err_silver_not_enough);
				sg_res.append(0);
				res_json.append(sg_res);
				break;
			}
			unsigned rp_lv = 1;
			if (player->Info().VipLv() > 2 && Common::randomOk(0.1))rp_lv = 2;
			unsigned to_lv = c_lv + rp_lv;
			if (c_lv + rp_lv > player->LV()){ to_lv = player->LV(); rp_lv = 1; }
			item->setLv(to_lv);
			player->Res().alterSilver(-cost[c_lv]);
			if (player->Info().VipLv() < 1)player->Items().addUpCD(30);//û��vip��ô����CD
			mini_ok = true;
			++sucess_times;
			sg_res.append(res_sucess);
			sg_res.append(rp_lv);
			res_json.append(sg_res);
		}
		const unsigned end_level = item->getLv();
		if (mini_ok)
		{
			//�ճ�
			player->Daily().tickTask(DAILY::equip_upgrade, sucess_times);
			TaskMgr::update(player, Task::StrengthenTimes, sucess_times);
			TaskMgr::update(player, Task::EquipMaxLv, sucess_times, end_level);
			Log(DBLOG::strLogPlayerItem, player, 0, localID, begin_level, end_level, bengin_silver, player->Res().getSilver());
		}
		Return(r, res_sucess);
	}
	void item_system::itemOpen(net::Msg& m, Json::Value& r)
	{
		playerDataPtr player = player_mgr.getPlayer(m.playerID);
		if (!player)Return(r, err_illedge);
		ReadJsonArray;
		int itemID = js_msg[0u].asInt();
		unsigned times = js_msg[1u].asUInt();
		if (times > 20)Return(r, err_illedge);
		if (!player->Items().overItem(itemID, times))Return(r, err_item_not_enough);
		acMap::iterator it = mapAC.find(itemID);
		if (it == mapAC.end())Return(r, err_illedge);
		iGiftPtr igPtr = it->second;
		if (!resLimitPass(player, igPtr->ulimit))Return(r, err_illedge);
		int res = actionDo(player, igPtr->actions, times);
		player->Items().removeItem(itemID, times);
		r[strMsg][2u] = actionRes();
		r[strMsg][1u] = actionError();
		Return(r, res);
	}
	void item_system::itemCompose(net::Msg& m, Json::Value& r)
	{

	}
	void item_system::equipDegrade(net::Msg& m, Json::Value& r)
	{
		playerDataPtr player = player_mgr.getPlayer(m.playerID);
		if (!player)Return(r, err_illedge);
		ReadJsonArray;
		int localID = js_msg[0u].asInt();
		unsigned to_lv = js_msg[1u].asUInt();
		if (to_lv < 1)Return(r, err_illedge);
		itemPtr item = player->Items().getLocalItem(localID, itemDef::pos_bag | itemDef::pos_man);
		if (!item)Return(r, err_item_no_found);
		cfgItemPtr config = item->getConfig();
		if (!config || !config->isEquip())Return(r, err_illedge);
		unsigned c_lv = item->getLv();
		if (to_lv >= c_lv)Return(r, err_illedge);
		const vector<int>& cost = equipRiseUpCostT(config->_declare._equip.upgradeUse);
		int rw = cost[c_lv ] - cost[to_lv];
		rw *= 0.8;
		item->setLv(to_lv);
		player->Res().alterSilver(rw);
		TaskMgr::update(player, Task::EquipMaxLv, 0, c_lv);
		r[strMsg][1u] = rw;
		Return(r, res_sucess);
	}
	void item_system::itemResolve(net::Msg& m, Json::Value& r)
	{

	}
	const static int lightCost[itemDef::reborn_color_num][itemDeclare::rbNum] = { { 50, 100, 200 }, { 100, 200, 500 }, { 200, 500, 1000 } };
	void item_system::equipLight(net::Msg& m, Json::Value& r)
	{
		playerDataPtr player = player_mgr.getPlayer(m.playerID);
		if (!player)Return(r, err_illedge);
		if (player->LV() < equipRebornLimit)Return(r, err_player_lv_too_low);
		ReadJsonArray;
		int localID = js_msg[0u].asInt();
		itemPtr item = player->Items().getLocalItem(localID, itemDef::pos_bag | itemDef::pos_man);
		if (!item)Return(r, err_item_no_found);
		cfgItemPtr config = item->getConfig();
		if (!config->isEquip())Return(r, err_illedge);
		const unsigned rbIdx = config->_declare._equip.rebornIdx;
		if (!canRebornQuality(rbIdx))Return(r, err_illedge);
		if (item->uncertainRB())Return(r, err_illedge);
		const unsigned rb_num = item->activeRBNum();
		if (rb_num >= itemDeclare::rbNum)Return(r, err_illedge);
		const unsigned vip_lv = player->Info().VipLv();
		if (rb_num > 1 && vip_lv < 7){ Return(r, err_vip_lv_too_low); }
		else if (rb_num > 0 && vip_lv < 2){ Return(r, err_vip_lv_too_low); }
		const int cost = lightCost[rbIdx][rb_num];
		if (player->Res().getCash() < cost)Return(r, err_cash_not_enough);
		item->activeReborn(CreateRebornValue(rbIdx, item->rebornIdxList()));
		player->Res().alterCash(-cost);
		Return(r, res_sucess);
	}
	void item_system::equipReborn(net::Msg& m, Json::Value& r)
	{
		playerDataPtr player = player_mgr.getPlayer(m.playerID);
		if (!player)Return(r, err_illedge);
		if (player->LV() < equipRebornLimit)Return(r, err_player_lv_too_low);
		ReadJsonArray;
		int localID = js_msg[0u].asInt();
		itemPtr item = player->Items().getLocalItem(localID, itemDef::pos_bag | itemDef::pos_man);
		if (!item)Return(r, err_item_no_found);
		cfgItemPtr config = item->getConfig();
		if (!config->isEquip())Return(r, err_illedge);
		const unsigned rbIdx = config->_declare._equip.rebornIdx;
		if (!canRebornQuality(rbIdx))Return(r, err_illedge);
		if (player->Res().getSilver() < RBCost[rbIdx])Return(r, err_silver_not_enough);
		if (item->uncertainRB())Return(r, err_illedge);
		unsigned rb_num = item->activeRBNum();
		if (rb_num < 1 || rb_num > itemDeclare::rbNum)Return(r, err_illedge);
		vector<itemDeclare::rbAttri> vec = item_sys.CreateRebornValueList(rbIdx, rb_num);
		for (unsigned i = 0; i < vec.size(); ++i)
		{
			item->setBKReborn((itemDeclare::rbIDX)i, vec[i]);
		}
		player->Res().alterSilver(-RBCost[rbIdx]);
		//�ճ�
		player->Daily().tickTask(DAILY::equip_reborn);
		TaskMgr::update(player, Task::WashTimes, 1);
		Return(r, res_sucess);
	}
	void item_system::equipRebornCus(net::Msg& m, Json::Value& r)
	{
		playerDataPtr player = player_mgr.getPlayer(m.playerID);
		if (!player)Return(r, err_illedge);
		if (player->LV() < equipRebornLimit)Return(r, err_player_lv_too_low);
		if (player->Info().VipLv() < 2)Return(r, err_vip_lv_too_low);
		ReadJsonArray;
		int localID = js_msg[0u].asInt();
		itemPtr item = player->Items().getLocalItem(localID, itemDef::pos_bag | itemDef::pos_man);
		if (!item)Return(r, err_item_no_found);
		cfgItemPtr config = item->getConfig();
		if (!config->isEquip())Return(r, err_illedge);
		const unsigned rbIdx = config->_declare._equip.rebornIdx;
		if (!canRebornQuality(rbIdx))Return(r, err_illedge);
		if (item->uncertainRB())Return(r, err_illedge);
		unsigned rb_num = item->activeRBNum();
		if (rb_num < 1 || rb_num > itemDeclare::rbNum)Return(r, err_illedge);
		unsigned x = 0;
		unsigned y = 0;
		Json::Value& cus_json = js_msg[1u];
		for (unsigned i = 0; i < cus_json.size() && i < rb_num; ++i)
		{
			if (cus_json[i].asInt() == 1) ++x;
			else if (cus_json[i].asInt() == 2)  { ++x; ++y; }
		}
		int cost = RBCusCost[x][y];
		if (player->Res().getCash() < cost)Return(r, err_cash_not_enough);
		vector<AttributeIDX> filter_vec;
		for (unsigned i = 0; i < rb_num; ++i)
		{
			const itemDeclare::rbAttri& attri = item->getReborn((itemDeclare::rbIDX)i);
			if (attri.idx < 0)continue;
			const int option = cus_json[i].asInt();
			if (option == 1 || option == 2)
			{
				filter_vec.push_back((AttributeIDX)attri.idx);
			}
		}
		for (unsigned i = 0; i < rb_num; ++i)
		{
			const itemDeclare::rbAttri& attri = item->getReborn((itemDeclare::rbIDX)i);
			if (attri.idx < 0)continue;
			if (cus_json[i].asInt() == 1)
			{
				item->setBKReborn((itemDeclare::rbIDX)i, itemDeclare::rbAttri(attri.idx, CreateRebornValue(rbIdx, attri.idx)));//ֻϴ����
			}
			else if (cus_json[i].asInt() == 2)
			{
				item->setBKReborn((itemDeclare::rbIDX)i, attri);//��������
			}
			else
			{
				const itemDeclare::rbAttri new_attri = CreateRebornValue(rbIdx, filter_vec);
				filter_vec.push_back((AttributeIDX)new_attri.idx);
				item->setBKReborn((itemDeclare::rbIDX)i, new_attri);
			}
		}
		player->Res().alterCash(-cost);
		//�ճ�
		player->Daily().tickTask(DAILY::equip_reborn);
		TaskMgr::update(player, Task::WashTimes, 1);
		TaskMgr::update(player, Task::HighWashTimes, 1);
		Return(r, res_sucess);
	}
	void item_system::equipRBKeep(net::Msg& m, Json::Value& r)
	{
		playerDataPtr player = player_mgr.getPlayer(m.playerID);
		if (!player)Return(r, err_illedge);
		if (player->LV() < equipRebornLimit)Return(r, err_player_lv_too_low);
		ReadJsonArray;
		int localID = js_msg[0u].asInt();
		itemPtr item = player->Items().getLocalItem(localID, itemDef::pos_bag | itemDef::pos_man);
		if (!item)Return(r, err_item_no_found);
		cfgItemPtr config = item->getConfig();
		if (!config->isEquip())Return(r, err_illedge);
		if (!item->uncertainRB())Return(r, err_illedge);
		item->clearUncertainRB();
		Return(r, res_sucess);
	}
	void item_system::equipRBReplace(net::Msg& m, Json::Value& r)
	{
		playerDataPtr player = player_mgr.getPlayer(m.playerID);
		if (!player)Return(r, err_illedge);
		if (player->LV() < equipRebornLimit)Return(r, err_player_lv_too_low);
		ReadJsonArray;
		int localID = js_msg[0u].asInt();
		itemPtr item = player->Items().getLocalItem(localID, itemDef::pos_bag | itemDef::pos_man);
		if (!item)Return(r, err_item_no_found);
		cfgItemPtr config = item->getConfig();
		if (!config->isEquip())Return(r, err_illedge);
		if (!item->uncertainRB())Return(r, err_illedge);
		qValue old_json(qJson::qj_array), new_json(qJson::qj_array);
		for (unsigned i = 0; i < itemDeclare::rbNum; ++i)
		{
			qValue sg_left_json(qJson::qj_array), sg_right_json(qJson::qj_array);
			itemDeclare::rbAttri rb_1 = item->getReborn((itemDeclare::rbIDX)i);
			itemDeclare::rbAttri rb_2 = item->getBKReborn((itemDeclare::rbIDX)i);
			sg_left_json.append(rb_1.idx).append(rb_1.val);
			sg_right_json.append(rb_2.idx).append(rb_2.val);
			old_json.append(sg_left_json);
			new_json.append(sg_right_json);
		}
		item->replaceUncertainRB();
		Log(DBLOG::strLogPlayerItem, player, 4, localID, old_json.toIndentString(), new_json.toIndentString());
		Return(r, res_sucess);
	}
	//const static double upperEXCRate[];
	void item_system::equipRBExchange(net::Msg& m, Json::Value& r)
	{
		playerDataPtr player = player_mgr.getPlayer(m.playerID);
		if (!player)Return(r, err_illedge);
		if (player->LV() < equipExchangeLimit)Return(r, err_player_lv_too_low);
		if (player->Res().getCash() < 5)Return(r, err_cash_not_enough);
		ReadJsonArray;
		int localID_1 = js_msg[0u].asInt();//Դ
		int localID_2 = js_msg[1u].asInt();//Ŀ��
		itemPtr item_1 = player->Items().getLocalItem(localID_1, itemDef::pos_bag | itemDef::pos_man);
		itemPtr item_2 = player->Items().getLocalItem(localID_2, itemDef::pos_bag | itemDef::pos_man);
		if (!item_1 || !item_2)Return(r, err_item_no_found); 
		cfgItemPtr config_1 = item_1->getConfig();
		cfgItemPtr config_2 = item_2->getConfig();
		if (!config_1->isEquip() || !config_2->isEquip())Return(r, err_illedge);
		const unsigned rbIdx_1 = config_1->_declare._equip.rebornIdx;
		const unsigned rbIdx_2 = config_2->_declare._equip.rebornIdx;
		if (!canRebornQuality(rbIdx_1) || !canRebornQuality(rbIdx_2))Return(r, err_illedge);
		const unsigned rb_num_1 = item_1->activeRBNum();
		const unsigned rb_num_2 = item_2->activeRBNum();
		if (rb_num_1 != rb_num_2)Return(r, err_illedge);
		if (rb_num_1 + rb_num_2 < 1)Return(r, err_illedge);
		double rb_1_rate = 1.0, rb_2_rate = 1.0;
		unsigned rb_rate_idx = 0;
		if (rbIdx_1 > rbIdx_2)
		{
			rb_rate_idx = rbIdx_1 - rbIdx_2;
			//rb1 ���� rb2 ����
			rb_1_rate = EXCGLower[rb_rate_idx];
			rb_2_rate = EXCGUpper[rb_rate_idx];
		}
		else
		{
			rb_rate_idx = rbIdx_2 - rbIdx_1;
			//rb2 ���� rb1 ����
			rb_2_rate = EXCGLower[rb_rate_idx];
			rb_1_rate = EXCGUpper[rb_rate_idx];
		}
		qValue left_json(qJson::qj_array), right_json(qJson::qj_array);
		for (unsigned i = 0; i < itemDeclare::rbNum; ++i)
		{
			qValue sg_left_json(qJson::qj_array), sg_right_json(qJson::qj_array);
			itemDeclare::rbAttri rb_1 = item_1->getReborn((itemDeclare::rbIDX)i);
			itemDeclare::rbAttri rb_2 = item_2->getReborn((itemDeclare::rbIDX)i);
			sg_left_json.append(rb_1.idx).append(rb_1.val);
			sg_right_json.append(rb_2.idx).append(rb_2.val);
			left_json.append(sg_left_json);
			right_json.append(sg_right_json);
			rb_1.val *= rb_1_rate;
			rb_2.val *= rb_2_rate;
			item_1->setReborn((itemDeclare::rbIDX)i, rb_2, false, true);
			item_2->setReborn((itemDeclare::rbIDX)i, rb_1, false, true);
		}
		item_1->tryRecal();
		item_2->tryRecal();
		player->Res().alterCash(-5);
		Log(DBLOG::strLogPlayerItem, player, 3, localID_1, localID_2, 
			left_json.toIndentString(), right_json.toIndentString(),
			rb_1_rate, rb_2_rate);
		{
			//����
			//player->Task().evTask(TaskDef::RebornEquipEv);
			TaskMgr::update(player, Task::TransferTimes, 1);
		}
		Return(r, res_sucess);
	}

	const static Json::Value nullArrayJson = Json::arrayValue;
	void item_system::equipDp(net::Msg& m, Json::Value& r)
	{
		playerDataPtr player = player_mgr.getPlayer(m.playerID);
		if (!player)Return(r, err_illedge);
		if (player->LV() < equipDispartLimit)Return(r, err_player_lv_too_low);
		ReadJsonArray;
		unsigned add_orgin_gem_num = 0;
		unsigned total_item_num = 0;
		std::map<int, unsigned> email_add_map;
		itemMap item_list;//Ҫ֧���κε���
		for (unsigned i = 0; i < js_msg.size(); ++i)
		{
			Json::Value& sg_json = js_msg[i];
			const int localID = sg_json[0u].asInt();
			const unsigned item_num = sg_json[1u].asUInt();
			total_item_num += item_num;
			if (total_item_num > 100)Return(r, err_illedge);
			itemPtr item = player->Items().getLocalItem(localID);
			if (!item)Return(r, err_item_no_found);
			if (item->Num() < item_num)Return(r, err_item_not_enough);
			const unsigned sgNum = itemDpNum(item->itemID());
			if (sgNum < 1)Return(r, err_illedge);//������߲����Էֽ�
			if (!item_list.insert(itemMap::value_type(item->ID(), item)).second)Return(r, err_illedge);
			for (unsigned n = 0; n < item_num; ++n)
			{
				unsigned to_add_num = sgNum;
				if (Common::randomOk(2000))to_add_num *= 2;
				add_orgin_gem_num += to_add_num;
			}
		}
		int silver_rw = 0;
		qValue log_qjson(qJson::qj_array);
		for (unsigned i = 0; i < js_msg.size(); ++i)
		{
			Json::Value& sg_json = js_msg[i];
			const int localID = sg_json[0u].asInt();
			const unsigned item_num = sg_json[1u].asUInt();
			itemPtr item = player->Items().getLocalItem(localID);
			cfgItemPtr config = item->getConfig();
			if (config->isEquip())
			{
				unsigned c_lv = item->getLv();
				const vector<int>& cost = equipRiseUpCostT(config->_declare._equip.upgradeUse);
				silver_rw += int((cost[c_lv] - cost[1])*0.8);
				if (err_bag_full == item->OFFGem())//�������ʧ���˷����ʼ�
				{
					email_add_map[item->gemID()] += 1;
				}
				TaskMgr::update(player, Task::EquipMaxLv, 0, c_lv);
			}
			item->cutNum(item_num);
			log_qjson.append(item->itemID());
		}
		player->Res().alterSilver(silver_rw);
		if (player->Items().addItem(gemOriginID(), add_orgin_gem_num).empty())//ʧ���˷����ʼ�
		{
			email_add_map[gemOriginID()] += add_orgin_gem_num;
		}
		if (email_add_map.size() > 0)
		{
			Json::Value res_json;
			for (std::map<int, unsigned>::iterator it = email_add_map.begin(); it != email_add_map.end(); ++it)
			{
				Json::Value sg_json;
				sg_json.append(ACTION::item);
				sg_json.append(it->first);
				sg_json.append(it->second);
				res_json.append(sg_json);
			}
			EmailPtr email_ptr = email_sys.createPackage(EmailDef::DispartItemRescue, nullArrayJson, res_json);
			email_sys.sendToPlayer(player->ID(), email_ptr);
		}
		Log(DBLOG::strLogPlayerGem, player, 0, gemOriginID(), add_orgin_gem_num, "", "", "", "", "", log_qjson.toIndentString());
		r[strMsg][1u] = add_orgin_gem_num;
		{
			//����
			TaskMgr::update(player, Task::ResolveTimes, total_item_num);
			TaskMgr::update(player, Task::ResolveTargetNum, total_item_num);
		}
		Return(r, res_sucess);
	}

	void item_system::equipDpGD(net::Msg& m, Json::Value& r)
	{
		playerDataPtr player = player_mgr.getPlayer(m.playerID);
		if (!player)Return(r, err_illedge);
		if (player->LV() < equipDispartLimit)Return(r, err_player_lv_too_low);
		ReadJsonArray;
		unsigned add_orgin_gem_num = 0;
		unsigned total_item_num = 0;
		std::map<int, unsigned> email_add_map;
		itemMap item_list;//Ҫ֧���κε���
		unsigned base_orgin_num = 0;
		for (unsigned i = 0; i < js_msg.size(); ++i)
		{
			Json::Value& sg_json = js_msg[i];
			const int localID = sg_json[0u].asInt();
			const unsigned item_num = sg_json[1u].asUInt();
			total_item_num += item_num;
			if (total_item_num > 100)Return(r, err_illedge);
			itemPtr item = player->Items().getLocalItem(localID);
			if (!item)Return(r, err_item_no_found);
			if (item->Num() < item_num)Return(r, err_item_not_enough);
			const unsigned sgNum = itemDpNum(item->itemID());
			if (sgNum < 1)Return(r, err_illedge);//������߲����Էֽ�
			if (!item_list.insert(itemMap::value_type(item->ID(), item)).second)Return(r, err_illedge);
			base_orgin_num += (sgNum * item_num);
			for (unsigned n = 0; n < item_num; ++n)
			{
				unsigned to_add_num = sgNum * 2;
				if (Common::randomOk(1500))to_add_num = sgNum * 5;
				add_orgin_gem_num += to_add_num;
			}
		}
		const int cost_gold = (base_orgin_num * 2);
		if (player->Res().getCash() < cost_gold)Return(r, err_gold_not_enough);
		int silver_rw = 0;
		qValue log_qjson(qJson::qj_array);
		for (unsigned i = 0; i < js_msg.size(); ++i)
		{
			Json::Value& sg_json = js_msg[i];
			const int localID = sg_json[0u].asInt();
			const unsigned item_num = sg_json[1u].asUInt();
			itemPtr item = player->Items().getLocalItem(localID);
			cfgItemPtr config = item->getConfig();
			if (config->isEquip())
			{
				unsigned c_lv = item->getLv();
				const vector<int>& cost = equipRiseUpCostT(config->_declare._equip.upgradeUse);
				silver_rw += int((cost[c_lv] - cost[1])*0.8);
				if (err_bag_full == item->OFFGem())//�������ʧ���˷����ʼ�
				{
					email_add_map[item->gemID()] += 1;
				}
				TaskMgr::update(player, Task::EquipMaxLv, 0, c_lv);
			}
			item->cutNum(item_num);
			log_qjson.append(item->itemID());
		}
		player->Res().alterCash(-cost_gold);
		player->Res().alterSilver(silver_rw);
		if (player->Items().addItem(gemOriginID(), add_orgin_gem_num).empty())//ʧ���˷����ʼ�
		{
			email_add_map[gemOriginID()] += add_orgin_gem_num;
		}
		if (email_add_map.size() > 0)
		{
			Json::Value res_json;
			for (std::map<int, unsigned>::iterator it = email_add_map.begin(); it != email_add_map.end(); ++it)
			{
				Json::Value sg_json;
				sg_json.append(ACTION::item);
				sg_json.append(it->first);
				sg_json.append(it->second);
				res_json.append(sg_json);
			}
			EmailPtr email_ptr = email_sys.createPackage(EmailDef::DispartItemRescue, nullArrayJson, res_json);
			email_sys.sendToPlayer(player->ID(), email_ptr);
		}
		Log(DBLOG::strLogPlayerGem, player, 1, gemOriginID(), add_orgin_gem_num, cost_gold, "", "", "", "", log_qjson.toIndentString());
		r[strMsg][2u] = cost_gold;
		r[strMsg][1u] = add_orgin_gem_num;
		{
			//����
			TaskMgr::update(player, Task::ResolveTimes, total_item_num);
			TaskMgr::update(player, Task::ResolveTargetNum, total_item_num);
		}
		Return(r, res_sucess);
	}

	void item_system::gemCompose(net::Msg& m, Json::Value& r)
	{
		playerDataPtr player = player_mgr.getPlayer(m.playerID);
		if (!player)Return(r, err_illedge);
		if (player->LV() < gemUseLimit)Return(r, err_player_lv_too_low);
		ReadJsonArray;
		const int itemID = js_msg[0u].asInt();
		const unsigned num = js_msg[1u].asUInt();
		if (num > 10000)Return(r, err_illedge);
		if (!player->Items().canAddItem(itemID, num))Return(r, err_bag_full);
		gemCMMap::iterator it = mapGemCM.find(itemID);
		if (it == mapGemCM.end())Return(r, err_illedge);
		const gemCM& gCM = it->second;
		if (gCM.limitLV > player->Research().getResearchData(LAND::idx_home_type_gem))Return(r, err_science_level_too_low);
		const unsigned cost_num = gCM.num * num;
		if (!player->Items().overItem(gCM.itemID, cost_num))Return(r, err_item_not_enough);//���ϲ���
		player->Items().removeItem(gCM.itemID, cost_num);
		player->Items().addItem(itemID, num);
		r[strMsg][4u] = cost_num;
		r[strMsg][3u] = gCM.itemID;
		r[strMsg][2u] = num;
		r[strMsg][1u] = itemID;
		Log(DBLOG::strLogPlayerGem, player, 2, itemID, num, gCM.itemID, cost_num);
		{
			//���� 
			//��ʯ�ȼ� = ��ʯID % 100 -1
			//player->Task().evTask(TaskDef::GemComposeEv, itemID % 100 - 1, num);
			TaskMgr::update(player, Task::GemStoneNumOfLv, itemID, num);
		}
		Return(r, res_sucess);
	}

	void item_system::gemEquip(net::Msg& m, Json::Value& r)
	{
		playerDataPtr player = player_mgr.getPlayer(m.playerID);
		if (!player)Return(r, err_illedge);
		if (player->LV() < gemUseLimit)Return(r, err_player_lv_too_low);
		if (player->Res().getCash() < 1)Return(r, err_cash_not_enough);
		ReadJsonArray;
		const int localID = js_msg[0u].asInt();
		const int itemID = js_msg[1u].asInt();
		itemPtr item = player->Items().getLocalItem(localID, itemDef::pos_bag | itemDef::pos_man);
		if (!item)Return(r, err_item_no_found);
		if (!player->Items().overItem(itemID, 1))Return(r, err_item_not_enough);
		int res = item->OnGem(itemID);
		if (res == res_sucess)
		{
			player->Res().alterCash(-1);
			player->Items().removeItem(itemID, 1);
			Log(DBLOG::strLogPlayerGem, player, 3, localID, itemID);
			{
				//����
				//��ʯ�ȼ� = ��ʯID % 100 -1
				//player->Task().evTask(TaskDef::GemOnEv, itemID % 100 - 1, 1);
			}
		}
		Return(r, res);
	}

	void item_system::gemOffEquip(net::Msg& m, Json::Value& r)
	{
		playerDataPtr player = player_mgr.getPlayer(m.playerID);
		if (!player)Return(r, err_illedge);
		ReadJsonArray;
		const int localID = js_msg[0u].asInt();
		itemPtr item = player->Items().getLocalItem(localID, itemDef::pos_bag | itemDef::pos_man);
		if (!item)Return(r, err_item_no_found);
		const int itemID = item->gemID();
		int res = item->OFFGem();
		if (res == res_sucess)
		{
			Log(DBLOG::strLogPlayerGem, player, 4, localID, itemID);
		}
		Return(r, res);
	}

	void item_system::equipBuildGold(net::Msg& m, Json::Value& r)
	{
		playerDataPtr player = player_mgr.getPlayer(m.playerID);
		if (!player)Return(r, err_illedge);
		if (player->LV() < equipBuildLimit)Return(r, err_player_lv_too_low);
		ReadJsonArray;
		const int formulaID = js_msg[0u].asInt();
		eqBuildPtr build = findFormula(formulaID);
		if (!build)Return(r, err_illedge);
		if (!player->Items().canAddItem(build->buildID, 1))Return(r, err_bag_full);
		if (player->Res().getCash() < build->gold_cost)Return(r, err_cash_not_enough);
		const vector<equipBuild::cost>& costList = build->costList;
		for (unsigned i = 0; i < costList.size(); ++i)
		{
			const equipBuild::cost& cost = costList[i];
			if (!player->Items().overItem(cost.itemID, cost.num))Return(r, err_item_not_enough);
		}
		player->Res().alterCash(-build->gold_cost);
		qValue log_json(qJson::qj_array);
		for (unsigned i = 0; i < costList.size(); ++i)
		{
			const equipBuild::cost& cost = costList[i];
			player->Items().removeItem(cost.itemID, cost.num);
			qValue sg_json(qJson::qj_array);
			sg_json.append(cost.itemID).
				append(cost.num);
			log_json.append(sg_json);
		}
		itemPtr item = player->Items().addItem(build->buildID, 1)[0];
		cfgItemPtr config = item->getConfig();
		const unsigned cr_num = item->activeRBNum();
		if (config->isEquip() &&  cr_num < 2)
		{
			const unsigned rbIdx = config->_declare._equip.rebornIdx;
			const unsigned num = Common::randomOk(0.75) ? 2 : itemDeclare::rbNum;
			for (unsigned idx = cr_num; idx < num; ++idx)
			{
				item->activeReborn(CreateRebornValue(rbIdx, item->rebornIdxList()));
			}
		}
		r[strMsg][1u] = build->buildID;
		Log(DBLOG::strLogPlayerItem, player, 1, build->buildID, build->gold_cost, 
			"","","","","", log_json.toIndentString());
		{
			//����
			//player->Task().evTask(TaskDef::FormulaNumEv);
			//�ճ�
			player->Items().tickEquipBuild();
			player->Daily().tickTask(DAILY::equip_build);
			TaskMgr::update(player, Task::ForgeTimes, 1);
			TaskMgr::update(player, Task::HighForgeTimes, 1);
			TaskMgr::update(player, Task::ForgeNumOfColor, config->quality);
		}
		Return(r, res_sucess);
	}
	
	void item_system::equipBuildSilver(net::Msg& m, Json::Value& r)
	{
		playerDataPtr player = player_mgr.getPlayer(m.playerID);
		if (!player)Return(r, err_illedge);
		if (player->LV() < equipBuildLimit)Return(r, err_player_lv_too_low);
		ReadJsonArray;
		const int formulaID = js_msg[0u].asInt();
		eqBuildPtr build = findFormula(formulaID);
		if (!build)Return(r, err_illedge);
		if (!player->Items().canAddItem(build->buildID, 1))Return(r, err_bag_full);
		if (player->Res().getSilver() < build->silver_cost)Return(r, err_silver_not_enough);
		const vector<equipBuild::cost>& costList = build->costList;
		for (unsigned i = 0; i < costList.size(); ++i)
		{
			const equipBuild::cost& cost = costList[i];
			if (!player->Items().overItem(cost.itemID, cost.num))Return(r, err_item_not_enough);
		}
		player->Res().alterSilver(-build->silver_cost);
		qValue log_json(qJson::qj_array);
		for (unsigned i = 0; i < costList.size(); ++i)
		{
			const equipBuild::cost& cost = costList[i];
			player->Items().removeItem(cost.itemID, cost.num);
			qValue sg_json(qJson::qj_array);
			sg_json.append(cost.itemID).
				append(cost.num);
			log_json.append(sg_json);
		}
		itemPtr item = player->Items().addItem(build->buildID, 1)[0];
		cfgItemPtr config = item->getConfig();
		r[strMsg][1u] = build->buildID;
		Log(DBLOG::strLogPlayerItem, player, 2, build->buildID, build->silver_cost,
			"", "", "", "", "", log_json.toIndentString());
		{
			//����
			//player->Task().evTask(TaskDef::FormulaNumEv);
			//�ճ�
			player->Items().tickEquipBuild();
			player->Daily().tickTask(DAILY::equip_build);
			TaskMgr::update(player, Task::ForgeTimes, 1);
			TaskMgr::update(player, Task::ForgeNumOfColor, config->quality);
		}
		Return(r, res_sucess);
	}

	void item_system::equipShow(net::Msg& m, Json::Value& r)
	{
		playerDataPtr player = player_mgr.getPlayer(m.playerID);
		if (!player)Return(r, err_illedge);
		ReadJsonArray;
		const int itemID = js_msg[0u].asInt();
		const unsigned channel = js_msg[1u].asUInt();
		const string playerName = js_msg[2u].asString();
		if (channel >= CHAT::user_channel)Return(r, err_illedge);
		itemPtr item = player->Items().getLocalItem(itemID, itemDef::pos_bag | itemDef::pos_man);
		if (!item)Return(r, err_item_no_found);
		if (!item->getConfig()->isEquip())Return(r, err_illedge);
		unsigned now = Common::gameTime();
		if (player->EquipShowCD > now)Return(r, err_item_show_cd_limit);
		qValue data_json(qJson::qj_array);
		data_json.append(chat_sys.ChatPackageQ(player)).
			append(item->toJson());
		if (channel == CHAT::chat_all)
		{
			chat_sys.despatchAll(CHAT::server_item_show, data_json);
		}
		else if (channel == CHAT::chat_kingdom)
		{
			if (!chat_sys.despatchKingdom(CHAT::server_item_show, player->Info().Nation(), data_json))
			{
				Return(r, err_no_join_kingdom);
			}
		}
		else
		{
			if (!chat_sys.despatchPlayer(CHAT::server_item_show, playerName, data_json))
			{
				Return(r, err_chat_aim_not_find);
			}
		}
		player->EquipShowCD = now + 60;//60s
		player->Items().updateUpCD();
		Return(r, res_sucess);
	}

}

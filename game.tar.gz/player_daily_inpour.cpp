#include "player_daily_inpour.h"
#include "email_system.h"
#include "utility_lx.h"

const static string strActId = "id";
const static string strAcc = "acc";
const static string strWeek = "week";
const static string strBoxR = "box_r";
const static string strDailyR = "daily_r";
const static string strBoxA = "box_a";
const static string strDailyA = "daily_a";
const static string strBoxList = "list_b";
const static string strDailyList = "list_d";
//const static string strMap = "map_r";
const static string strAccuList = "list_a";
//const static string strShopR = "shop_r";
//const static string strShopArr = "shop_arr";
//const static string strReflesh = "reflesh";
//const static string strDay = "day";

#define TYPE_NUM 3
#define RECORED_NUM 6

namespace gg
{

	playerDailyInpour::playerDailyInpour(playerData* const own)
		:_auto_player(own),
		_curr_acc(0),
		_is_lock(false)
	{
		/*
		_shop_arr.resize(TYPE_NUM);
		for (int i = 0; i < _shop_arr.size(); ++i)
		{
			_shop_arr[i] = INVALID_DATA;//��ʼΪ��Ч������
		}
		_shop_records.resize(RECORED_NUM);
		for (int i = 0; i < _shop_records.size(); ++i)
		{
			_shop_records[i] = 0;
		}
		*/

	}

	void playerDailyInpour::addAcc(int key, int accu)
	{
		if (accu <= 0 || _accuList.find(key) != _accuList.end())
		{ 
			return ;
		}
		_curr_acc += accu;
		_accuList[key] = accu;
		_sign_auto();
	}

	/*
	void playerDailyInpour::resetShop()
	{
		for (int i = 0; i < _shop_arr.size(); ++i)
		{
			_shop_arr[i] = INVALID_DATA;//��ʼΪ��Ч������
		}
		for (int i = 0; i < _shop_records.size(); ++i)
		{
			_shop_records[i] = 0;
		}
	}
	*/

	void playerDailyInpour::addBoxRecord(int index)
	{
		if (std::find(_box_records.begin(), _box_records.end(), index) != _box_records.end())
		{
			return;
		}
		_box_records.push_back(index);
		_sign_auto();
	}

	void playerDailyInpour::addDailyRecord(int index)
	{
		if (std::find(_daily_records.begin(), _daily_records.end(), index) != _daily_records.end())
		{
			return;
		}
		_daily_records.push_back(index);
		_sign_auto();
	}

	void playerDailyInpour::addDailyAccessRecord(int index)
	{
		if (std::find(_daily_access.begin(), _daily_access.end(), index) != _daily_access.end())
		{
			return;
		}
		_daily_access.push_back(index);
		_sign_auto();
	}

	void playerDailyInpour::addBoxAccessRecord(int index)
	{
		if (std::find(_box_access.begin(), _box_access.end(), index) != _box_access.end())
		{
			return;
		}
		_box_access.push_back(index);
		_sign_auto();
	}

	void playerDailyInpour::setActId(int id)
	{
		_act_id = id;
		_auto_save();
	}

	void playerDailyInpour::addDailyBox(int key, Json::Value box)
	{
		if (_dailyBoxList.find(key) == _dailyBoxList.end())
		{
			_dailyBoxList[key] = box;
			_sign_auto();
		}
	}

	void playerDailyInpour::delDailyBox(int key)
	{
		if (_dailyBoxList.find(key) != _dailyBoxList.end())
		{
			_dailyBoxList.erase(key);
			_sign_auto();
		}
	}

	void playerDailyInpour::addAccuBox(int key, Json::Value box)
	{
		if (_accuBoxList.find(key) == _accuBoxList.end())
		{
			_accuBoxList[key] = box;
			_sign_auto();
		}
	}

	void playerDailyInpour::delAccuBox(int key)
	{
		if (_accuBoxList.find(key) != _accuBoxList.end())
		{
			_accuBoxList.erase(key);
			_sign_auto();
		}
	}

	/*
	void playerDailyInpour::addReflesh(int acc, bool is_reset)
	{
		if (is_reset)
		{
			_reflesh_time = 0;
		}
		else
		{
			if (acc > 0)
			{
				_reflesh_time += acc;
			}
		}
		_sign_auto();

	}

	void playerDailyInpour::setShopRecords(int index)
	{
		_shop_records[index] = 1;
		_sign_auto();
	}

	void playerDailyInpour::setShopItem(int type, int index)
	{
		_shop_arr[type] = index;
	}
	*/

	
	void playerDailyInpour::reset()
	{
		_is_lock = true;
		_accuList.clear();
		Json::Value boxes = Json::arrayValue;
		for (InpourBoxList::iterator it = _dailyBoxList.begin(); it != _dailyBoxList.end(); ++it)
		{
			//boxes = lx::utility_lx::combineArrayBox(boxes, it->second);
			combineActionRes(it->second, boxes);
		}
		if (boxes.size() > 0)
		{
			EmailPtr e = email_sys.createPackage(EmailDef::DailyInpourForgetton, Json::nullValue, boxes);
			email_sys.sendToPlayer(Own().ID(), e);
		}
		_dailyBoxList.clear();
		_daily_records.clear();
		_daily_records.resize(0);
		_daily_access.clear();
		_daily_access.resize(0);
		_is_lock = false;
		_sign_auto();
		//ԭ�汾
		/*
		//����������ÿ�յ��ʳ�ֵ������
		Json::Value boxes = Json::arrayValue;
		int i = 0;
		for (InpourBoxList::iterator it = _boxList.begin(); it != _boxList.end(); ++it)
		{
			if (it->first > SKEY)
			{
				boxes = lx::utility_lx::combineArrayBox(boxes, it->second);
			}
		}
		if (boxes.size() > 0)
		{
			LogS << "box size:" << _boxList.size() << "\tbox:" << boxes.toIndentString() << LogEnd;
			EmailPtr e = email_sys.createPackage(EmailDef::DailyInpourForgetton, Json::nullValue, boxes);
			email_sys.sendToPlayer(Own().ID(), e);
		}
		//��������(ÿ��)
		_daily_records.clear();
		_daily_records.resize(0);
		_daily_access.clear();
		_daily_access.resize(0);
		_accuList.clear();
		for (InpourBoxList::iterator it = _boxList.begin(); it != _boxList.end();)
		{
			if (it->first > SKEY)
			{
				it = _boxList.erase(it);
			}
			else
			{
				++it;
			}
		}
		//�̵�ˢ��
		_reflesh_time = 0;
		//_shop_arr.clear();
		//_shop_records.clear();
		for (int i = 0; i < _shop_arr.size(); ++i)
		{
			_shop_arr[i] = INVALID_DATA;//��ʼΪ��Ч������
		}
		for (int i = 0; i < _shop_records.size(); ++i)
		{
			_shop_records[i] = 0;
		}
		//ÿ����һ���
		tm ct = Common::toTm(Common::gameTime());
		if (ct.tm_wday == 1)
		{
			Json::Value boxes = Json::arrayValue;
			int i = 0;
			for (InpourBoxList::iterator it = _boxList.begin(); it != _boxList.end(); ++it)
			{
				boxes = lx::utility_lx::combineArrayBox(boxes, it->second);
			}
			if (boxes.size() > 0)
			{
				LogS << "monday\t" << "box size:" << _boxList.size() << "\tbox:" << boxes.toIndentString() << LogEnd;
				EmailPtr e = email_sys.createPackage(EmailDef::DailyInpourForgetton, Json::nullValue, boxes);
				email_sys.sendToPlayer(Own().ID(), e);
			}
			//�������ݣ�ÿ�ܣ�
			_curr_acc = 0;
			_weekend_flag = false;
			_box_records.clear();
			_box_records.resize(0);
			_box_access.clear();
			_box_access.resize(0);
			_boxList.clear();
		}
		_sign_auto();
		*/
		
	}

	void playerDailyInpour::restart()
	{
		//�µĻ����������������
		_accuList.clear();
		_box_records.clear();
		_box_records.resize(0);
		_box_access.clear();
		_box_access.resize(0);
		_daily_records.clear();
		_daily_records.resize(0);
		_daily_access.clear();
		_daily_access.resize(0);
		Json::Value boxes = Json::arrayValue;
		for (InpourBoxList::iterator it = _dailyBoxList.begin(); it != _dailyBoxList.end(); ++it)
		{
			//boxes = lx::utility_lx::combineArrayBox(boxes, it->second);
			combineActionRes(it->second, boxes);
		}
		for (InpourBoxList::iterator it = _accuBoxList.begin(); it != _accuBoxList.end();++it)
		{
			//boxes = lx::utility_lx::combineArrayBox(boxes, it->second);
			combineActionRes(it->second, boxes);
		}
		//LogS << "email content:" << boxes.toIndentString() << LogEnd;
		if (boxes.size() > 0)
		{
			EmailPtr e = email_sys.createPackage(EmailDef::DailyInpourForgetton, Json::nullValue, boxes);
			email_sys.sendToPlayer(Own().ID(), e);
		}
		_dailyBoxList.clear();
		_accuBoxList.clear();
		_curr_acc = 0;
		_auto_save();
	}

	void playerDailyInpour::_auto_update()
	{
		Json::Value json;
		json[strMsg][0u] = res_sucess;

		json[strMsg][1u] = (_dailyBoxList.size() + _accuBoxList.size()) == 0 ? 0 : 1;
		Own().sendToClient(gate_client::daily_inpour_get_red_point_resp, json);
	}

	bool playerDailyInpour::_auto_save()
	{
		
		mongo::BSONObj key = BSON(strPlayerID << Own().ID());
		mongo::BSONArrayBuilder box_r_ids, daily_r_ids, box_a_ids, daily_a_ids, daily_list_ids, box_list_ids, accu_list_ids;
		for (int i = 0; i < _box_records.size(); ++i)
		{
			box_r_ids << _box_records[i];
		}
		for (int i = 0; i < _daily_records.size(); ++i)
		{
			daily_r_ids << _daily_records[i];
		}
		for (int i = 0; i < _daily_access.size(); ++i)
		{
			daily_a_ids << _daily_access[i];
		}
		for (int i = 0; i < _box_access.size(); ++i)
		{
			box_a_ids << _box_access[i];
		}
		for (InpourBoxList::iterator it = _accuBoxList.begin(); it != _accuBoxList.end(); ++it)
		{
			box_list_ids << it->first << lx::utility_lx::quotationAway(it->second.toIndentString());
		}
		for (InpourBoxList::iterator it = _dailyBoxList.begin(); it != _dailyBoxList.end(); ++it)
		{
			daily_list_ids << it->first << lx::utility_lx::quotationAway(it->second.toIndentString());
		}
		for (InpourAccuList::iterator it = _accuList.begin(); it != _accuList.end(); ++it)
		{
			accu_list_ids << it->first << it->second;
		}
		
		mongo::BSONObj obj = BSON(strPlayerID << Own().ID()
			<< strActId << _act_id
			<< strAcc << _curr_acc
			<< strBoxR << box_r_ids.arr()
			<< strDailyR << daily_r_ids.arr()
			<< strBoxA << box_a_ids.arr()
			<< strDailyA << daily_a_ids.arr()
			<< strDailyList << daily_list_ids.arr()
			<< strBoxList << box_list_ids.arr()
			<< strAccuList << accu_list_ids.arr()
		);

		return db_mgr.SaveMongo(DBN::dbPlayerDailyInpour, key, obj);
	}

	void playerDailyInpour::classLoad()
	{
		mongo::BSONObj key = BSON(strPlayerID << Own().ID());
		mongo::BSONObj obj = db_mgr.FindOne(DBN::dbPlayerDailyInpour, key);
		if (obj.isEmpty())
		{
			return;
		}
		_curr_acc = obj[strAcc].Int();
		_act_id = obj[strActId].Int();
		std::vector<mongo::BSONElement> box_r_ids = obj[strBoxR].Array();
		std::vector<mongo::BSONElement>	daily_r_ids = obj[strDailyR].Array();
		std::vector<mongo::BSONElement> box_a_ids = obj[strBoxA].Array();
		std::vector<mongo::BSONElement> daily_a_ids = obj[strDailyA].Array();
		std::vector<mongo::BSONElement> daily_list_ids = obj[strDailyList].Array();
		std::vector<mongo::BSONElement> box_list_ids = obj[strBoxList].Array();
		std::vector<mongo::BSONElement> accu_list_ids = obj[strAccuList].Array();
		
		for (unsigned i = 0; i < box_r_ids.size(); ++i)
		{
			mongo::BSONElement ele = box_r_ids[i];
			_box_records.push_back(ele.Int());
		}
		for (unsigned i = 0; i < daily_r_ids.size(); ++i)
		{
			mongo::BSONElement ele = daily_r_ids[i];
			_daily_records.push_back(ele.Int());
		}
		for (unsigned i = 0; i < daily_a_ids.size(); ++i)
		{
			mongo::BSONElement ele = daily_a_ids[i];
			_daily_access.push_back(ele.Int());
		}
		for (unsigned i = 0; i < box_a_ids.size(); ++i)
		{
			_box_access.push_back(box_a_ids[i].Int());
		}
		for (unsigned i = 0; i < accu_list_ids.size(); i += 2)
		{
			_accuList[accu_list_ids[i].Int()] = accu_list_ids[i + 1].Int();
		}
		for (unsigned i = 0; i < daily_list_ids.size(); i += 2)
		{
			_dailyBoxList[daily_list_ids[i].Int()] = Common::string2json(daily_list_ids[i + 1].String());
		}
		for (unsigned i = 0; i < box_list_ids.size(); i += 2)
		{
			_accuBoxList[box_list_ids[i].Int()] = Common::string2json(box_list_ids[i + 1].String());
		}


	}


	playerDailyInpour::~playerDailyInpour()
	{
	}
}

#include "player_daily_inpour.h"
#include "email_system.h"

namespace gg
{

	playerDailyInpour::playerDailyInpour(playerData* const own)
		:_auto_player(own),
		_curr_acc(0),
		_weekend_flag(false)
	{
	
	}

	void playerDailyInpour::addAcc(int key, int accu)
	{
		if (accu < 0 && _accuList.find(key) != _accuList.end())
		{
			return ;
		}
		_curr_acc += accu;
		_accuList[key] = accu;
		_sign_auto();
	}

	void playerDailyInpour::addBoxRecord(int index)
	{
		if (std::find(_box_records.begin(), _box_records.end(), index) != _box_records.end())
		{
			return;
		}
		_box_records.push_back(index);
		_sign_auto();
	}

	void playerDailyInpour::addDailyRecord(int index)
	{
		if (std::find(_daily_records.begin(), _daily_records.end(), index) != _daily_records.end())
		{
			return;
		}
		_daily_records.push_back(index);
		_sign_auto();
	}

	void playerDailyInpour::addDailyAccessRecord(int index)
	{
		if (std::find(_daily_access.begin(), _daily_access.end(), index) != _daily_access.end())
		{
			return;
		}
		_daily_access.push_back(index);
		_sign_auto();
	}

	void playerDailyInpour::addBox(int key, Json::Value box)
	{
		if (_boxList.find(key) == _boxList.end())
		{
			_boxList[key] = box;
			_sign_auto();
		}
	}

	void playerDailyInpour::delBox(int key)
	{
		if (_boxList.find(key) != _boxList.end())
		{
			_boxList.erase(key);
			_sign_auto();
		}
	}

	void playerDailyInpour::reset()
	{
		if (_curr_acc <= 0)
		{
			return;
		}
		//��������
		Json::Value boxes = Json::arrayValue;
		int i = 0;
		for (InpourBoxList::iterator it = _boxList.begin(); it != _boxList.end(); ++it)
		{
			if (it->first <= SKEY)//���������ˢ�µ�
			{
				continue;
			}
			boxes[i++] = it->second;
		}
		EmailPtr e = email_sys.createPackage(EmailDef::DailyInpourForgetton, Json::nullValue, boxes);
		email_sys.sendToPlayer(Own().ID(), e);
		//��������(ÿ��)
		//_daily_records.swap(InpourList());
		for (InpourBoxList::iterator it = _boxList.begin(); it != _boxList.end(); ++it)
		{
			if (it->first <= SKEY)
			{
				_boxList.erase(it->first);
			}
		}
		//ÿ����һ���
		tm ct = Common::toTm(Common::gameTime());
		if (ct.tm_wday == 1)
		{
			//if (_boxList.find(SKEY) != _boxList.end())
			//{
			//	EmailPtr e = email_sys.createPackage(EmailDef::DailyInpourWeekendForgetton, Json::nullValue, _boxList[SKEY]);
			//	email_sys.sendToPlayer(Own().ID(), e);
			//	_weekend_flag = false;//����
			//}
			//
			Json::Value boxes = Json::arrayValue;
			int i = 0;
			for (InpourBoxList::iterator it = _boxList.begin(); it != _boxList.end(); ++it)
			{
				boxes[i++] = it->second;
			}
			EmailPtr e = email_sys.createPackage(EmailDef::DailyInpourForgetton, Json::nullValue, boxes);
			email_sys.sendToPlayer(Own().ID(), e);
			//�������ݣ�ÿ�ܣ�
			_curr_acc = 0;
			_weekend_flag = false;
			//_box_records.swap(InpourList());
			for (InpourBoxList::iterator it = _boxList.begin(); it != _boxList.end(); ++it)
			{
				_boxList.erase(it->first);//�������ǿ���ɾ����������
			}
		}

		_sign_auto();
		
	}

	bool playerDailyInpour::_auto_save()
	{
		return false;
	}

	void playerDailyInpour::classLoad()
	{
	}


	playerDailyInpour::~playerDailyInpour()
	{
	}
}

//###################################
//create by Jim
//2015-11-11
//###################################
#pragma once

#include "action_def.h"
#include "commom.h"
#include "auto_base.h"

namespace gg
{
	namespace ACTION
	{
		//ͨ�ý����ͳ齱�Ľ���������һ����
		struct Box
		{
			Box(){
				actionID = null;
			}
			int actionID;
			Declare boxData;
		};
		typedef std::vector<Box> BoxList;

		namespace FORMAT
		{
			static void NullReg(Declare& dec, Json::Value& val)
			{

			}

			static void ResReg(Declare& dec, Json::Value& val)
			{
				dec._Res.val = val["v"].asInt();
			}

			static void ManReg(Declare& dec, Json::Value& val)
			{
				dec._Man.manID = val["v"].asInt();
				dec._Man.transfer = val.isMember("ts") ? val["ts"].asBool() : true;
				dec._Man.rate.rate = 1.0;//����佫����ת����ʱ����Ч
				dec._Man.rate.fix = 0;
			}

			static void ItemReg(Declare& dec, Json::Value& val)
			{
				dec._Item.itemID = val["id"].asInt();
				dec._Item.num = val["v"].asUInt();
			}
		}
		typedef boost::function<void(Declare&, Json::Value&)> RegFunc;
	}
	typedef boost::unordered_map<int, ACTION::Rate> ActionRateMap;//������������
	//����˵��
	extern void initLimit();
	extern LIMIT::valLimit toLimitData(Json::Value& json);
	extern bool resLimitPass(playerDataPtr player, const LIMIT::valLimit& limit);

	//�����������
	extern void setActionRate(const int actionID, const ACTION::Rate& rate);
	extern void setActionRate(const ActionRateMap& rate);

	//��ʼ��
	extern void actionInitData();

	//���Թ��õĽӿ�
	typedef ACTION::BoxList ActionBoxList;
	typedef std::vector<ActionValuePtr> ActionRandomList;
	extern void actionArrange(ActionBoxList& vec);//actionBox ����
	extern ActionBoxList actionFormatBox(const int boxID);//json ת action box
	extern ActionBoxList actionFormatBox(Json::Value& acJson);//json ת action box
	extern ActionRandomList actionFormat(const int boxID);//json ת action
	extern ActionRandomList actionFormat(Json::Value& acJson);//json ת action
	extern ActionBoxList actionErrorBox();//���������box�б�
	extern Json::Value actionError();//��������
	extern Json::Value actionRes();//actionִ��ʱ��Ľ��
	extern int actionCheckAvailable(playerDataPtr player, ActionBoxList& vec);//�����
	extern ActionBoxList preToBox(playerDataPtr player, const ActionRandomList& vec, const unsigned times = 1);//Ԥ��ת��box��ʽ
	extern int actionDo(playerDataPtr player, const ActionRandomList& vec, const unsigned times = 1, const bool jump = true);//�齱��
	extern int actionDoBox(playerDataPtr player, const ActionBoxList& vec, const bool jump = true);//ִ�г齱���
	extern int actionDoBoxNum(playerDataPtr player, const ActionBoxList& vec, const unsigned times, const bool jump = true);//ִ�г齱���
	extern Json::Value jsonFormats2c(const Json::Value& acJson);
	extern ActionBoxList actionFormatBoxc2s(const Json::Value& acJson);
	extern void combineActionRes(const Json::Value& from, Json::Value& to);
}

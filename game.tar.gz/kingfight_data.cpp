#include "kingfight_data.h"
#include "kingdom_def.h"
#include "battle_def.h"
#include "battle_helper.hpp"
#include "heroparty_system.h"
#include "game_time.h"
#include "chat.h"
#include "kingfight_system.h"
#include "despatch_task.h"

namespace gg
{
	namespace KingFight
	{
		template<typename T1, typename T2, typename T3, typename T4>
		void DoBroadcast(int nation, int type, const T1& arg1, const T2& arg2, const T3& arg3, const T4& arg4)
		{
			Json::Value msg;
			msg.append(type);
			msg.append(arg1);
			msg.append(arg2);
			msg.append(arg3);
			msg.append(arg4);
			if (nation == -1)
				chat_sys.despatchAll(CHAT::server_kingfight_state, msg);
			else
				chat_sys.despatchKingdom(CHAT::server_kingfight_state, (Kingdom::NATION)nation, msg);
		}

		// class State
		State::State(int nation)
			: _nation(nation), _state(Unsetted), _last_open_time(0), _last_close_time(0)
		{
		}

		void State::classLoad()
		{
			mongo::BSONObj key = BSON("key" << KeyState[_nation]);
			mongo::BSONObj obj = db_mgr.FindOne(DBN::dbKingFight, key);
			if (obj.isEmpty())
				return;
			
			_state = obj["st"].Int();
			_next_update_time = obj["nt"].Int();
			_next_time_node = obj["ns"].Int();
			_last_open_time = obj["ot"].Int();
			_last_close_time = obj["ct"].Int();
		}

		bool State::_auto_save()
		{
			mongo::BSONObj key = BSON("key" << KeyState[_nation]);
			mongo::BSONObjBuilder obj;
			obj << "key" << KeyState[_nation] << "st" << _state
				<< "nt" << _next_update_time << "ns" << _next_time_node
				<< "ot" << _last_open_time << "ct" << _last_close_time;
			return db_mgr.SaveMongo(DBN::dbKingFight, key, obj.obj());
		}

		void State::setState(int s)
		{
			_state = s;
			_sign_save();
		}

		void State::setNextUpdateTime(unsigned nt)
		{
			_next_update_time = nt;
			_sign_save();
		}

		void State::setNextTimeNode(int ns)
		{
			_next_time_node = ns;
			_sign_save();
		}

		void State::setLastOpenTime(unsigned lt)
		{
			_last_open_time = lt;
			_sign_save();
		}

		void State::setLastCloseTime(unsigned lt)
		{
			_last_close_time = lt;
			_sign_save();
		}

		// class Title
		Title::Title(int title)
			: _title(title), _pid(-1), _name(""), _face(-1)
		{}
		
		void Title::load(const mongo::BSONElement& obj)
		{
			_pid = obj["p"].Int();
			_name = obj["n"].String();
			_face = obj["f"].Int();
		}

		mongo::BSONObj Title::toBSON() const
		{
			return BSON("t" << _title << "p" << _pid << "n" << _name << "f" << _face);
		}

		void Title::getInfo(Json::Value& info) const
		{
			info = Json::arrayValue;
			info.append(_pid);
			info.append(_face);
			info.append(_name);
		}

		void Title::getInfo(qValue& q) const
		{
			q.append(_title);
			q.append(_name);
		}

		void Title::setPlayer(playerDataPtr d)
		{
			_pid = d->ID();
			_name = d->Name();
			_face = d->Info().Face();
		}

		// class TitleInfo
		TitleInfo::TitleInfo(const int nation)
			: _nation(nation)
		{
			for (int title = Kingdom::None; title < Kingdom::PingMin; ++title)
				_title_list.push_back(Creator<Title>::Create(title));
		}

		void TitleInfo::classLoad()
		{
			mongo::BSONObj key = BSON("key" << KeyTitle[_nation]);
			mongo::BSONObj obj = db_mgr.FindOne(DBN::dbKingFight, key);
			if (obj.isEmpty())
				return;

			std::vector<mongo::BSONElement> ele = obj["tl"].Array();
			for (unsigned i = 0; i < ele.size(); ++i)
			{
				int title = ele[i]["t"].Int();
				_title_list[title]->load(ele[i]);
			}
		}

		bool TitleInfo::_auto_save()
		{
			mongo::BSONObj key = BSON("key" << KeyTitle[_nation]);
			mongo::BSONObjBuilder obj;
			obj << "key" << KeyTitle[_nation];
			{
				mongo::BSONArrayBuilder b;
				ForEachC(TitleList, it, _title_list)
					b.append((*it)->toBSON());
				obj << "tl" << b.arr();
			}
			return db_mgr.SaveMongo(DBN::dbKingFight, key, obj.obj());
		}

		int TitleInfo::setPlayer(int title, playerDataPtr d)
		{
			if (title < Kingdom::GuoWang || title > Kingdom::SiNong)
				return err_illedge;

			ForEachC(TitleList, it, _title_list)
			{
				if ((*it)->pid() == d->ID())
					return err_illedge;
			}

			if (!_title_list[title]->empty())
				return err_illedge;

			_title_list[title]->setPlayer(d);
			d->KingFight().setTitle(title);
			_sign_save();
			DoBroadcast(_nation, 9, chat_sys.ChatPackage(d), title, "", "");
			return res_sucess;
		}

		void TitleInfo::update(playerDataPtr d)
		{
			int title = d->KingFight().getTitle();
			if (_title_list[title]->pid() == d->ID())
			{
				_title_list[title]->setPlayer(d);
				_sign_save();
			}
		}

		void TitleInfo::clear()
		{
			ForEach(TitleList, it, _title_list)
			{
				if ((*it)->empty())
					continue;
				int pid = (*it)->pid();
				playerDataPtr d = player_mgr.getPlayer(pid);
				if (d)
					d->KingFight().setTitle(Kingdom::PingMin);
				(*it)->clear();
			}
			_sign_save();
		}

		bool TitleInfo::notSetted() const
		{
			for (unsigned title = Kingdom::ZuoChengXiang; title < Kingdom::PingMin; ++title)
			{
				if (!_title_list[title]->empty())
					return false;
			}
			return true;
		}

		void TitleInfo::getInfo(qValue& q) const
		{
			for (unsigned title = Kingdom::GuoWang; title < Kingdom::PingMin; ++title)
			{
				if (_title_list[title]->empty())
					continue;
				qValue tmp;
				_title_list[title]->getInfo(tmp);
				q.append(tmp);
			}
		}

		void TitleInfo::getInfo(Json::Value& info) const
		{
			const static std::string TitleId[] = {"0", "1", "2", "3", "4"
				, "5", "6", "7", "8", "9", "10", "11", "12"};
			info = Json::objectValue;
			for (unsigned title = Kingdom::GuoWang; title < Kingdom::PingMin; ++title)
			{
				if (_title_list[title]->empty())
					continue;
				_title_list[title]->getInfo(info[TitleId[title]]);
			}
		}

		// class Report
		Report::Report(const mongo::BSONElement& obj)
		{
			_pid_a = obj["ia"].Int();
			_pid_b = obj["ib"].Int();
			_name_a = obj["na"].String();
			_name_b = obj["nb"].String();
			_rep_id = obj["ri"].String();
			_type = obj["ty"].Int();
		}

		Report::Report(playerDataPtr pa, playerDataPtr pb, int type, const std::string& rep_id)
		{
			_pid_a = pa->ID();
			_pid_b = pb->ID();
			_name_a = pa->Name();
			_name_b = pb->Name();
			_rep_id = rep_id;
			_type = type;
		}

		mongo::BSONObj Report::toBSON() const
		{
			return BSON("ia" << _pid_a << "ib" << _pid_b << "na" << _name_a << "nb" << _name_b << "ri" << _rep_id << "ty" << _type);
		}

		void Report::getInfo(Json::Value& info) const
		{
			info.append(_rep_id);
			info.append(_name_a);
			info.append(_pid_a);
			info.append(_name_b);
			info.append(_pid_b);
			info.append(_type);;
		}
		
		// class ReportInfo
		ReportInfo::ReportInfo(const int nation)
			: _nation(nation), _report_id(0)
		{}

		void ReportInfo::classLoad()
		{
			mongo::BSONObj key = BSON("key" << KeyReport[_nation]);
			mongo::BSONObj obj = db_mgr.FindOne(DBN::dbKingFight, key);
			if (obj.isEmpty())
				return;

			_report_id = obj["ri"].Int();
			std::vector<mongo::BSONElement> ele = obj["rl"].Array();
			for (unsigned i = 0; i < ele.size(); ++i)
				_report_list.push_back(Creator<Report>::Create(ele[i]));
		}

		bool ReportInfo::_auto_save()
		{
			mongo::BSONObj key = BSON("key" << KeyReport[_nation]);
			mongo::BSONObjBuilder obj;
			obj << "key" << KeyReport[_nation] << "ri" << _report_id;
			{
				mongo::BSONArrayBuilder b;
				ForEachC(ReportList, it, _report_list)
					b.append((*it)->toBSON());
				obj << "rl" << b.arr();
			}
			return db_mgr.SaveMongo(DBN::dbKingFight, key, obj.obj());
		}

		void ReportInfo::getInfo(Json::Value& info) const
		{
			info = Json::arrayValue;
			ForEachC(ReportList, it, _report_list)
			{
				Json::Value tmp;
				(*it)->getInfo(tmp);
				info.append(tmp);
			}
		}

		std::string ReportInfo::add(playerDataPtr pa, playerDataPtr pb, int type)
		{
			std::string rep_id = Common::toString(++_report_id);
			_report_list.push_front(Creator<Report>::Create(pa, pb, type, rep_id));
			_auto_save();
			return rep_id;
		}

		void ReportInfo::clear()
		{
			_report_id = 0;
			_report_list.clear();
			_auto_save();
		}
		
		// class Term
		Term::Term(const int nation)
			: _nation(nation), _end_time(0)
		{}

		void Term::load(const mongo::BSONObj& obj)
		{
			_begin_time = obj["bt"].Int();
			_end_time = obj["et"].Int();
			_pid = obj["pi"].Int();
			_name = obj["na"].String();
			_lv = obj["lv"].Int();
			_face = obj["fa"].Int();
		}

		void Term::setBeginTime(unsigned bt)
		{
			_begin_time = bt;
			_sign_save();
		}

		void Term::setEndTime(unsigned et)
		{
			_end_time = et;
			_sign_save();
		}

		void Term::setPlayer(playerDataPtr d)
		{
			_pid = d->ID();
			_name = d->Name();
			_lv = d->Info().LV();
			_face = d->Info().Face();
			_sign_save();
		}

		bool Term::_auto_save()
		{
			mongo::BSONObj key = BSON("nt" << _nation << "bt" << _begin_time);
			mongo::BSONObjBuilder obj;
			obj << "nt" << _nation << "bt" << _begin_time << "et" << _end_time
				<< "pi" << _pid << "na" << _name << "lv" << _lv << "fa" << _face;
			return db_mgr.SaveMongo(DBN::dbKingFightKingRecord, key, obj.obj());
		}

		void Term::getInfo(Json::Value& info, int term_id) const
		{
			info.append(_pid);
			info.append(_name);
			info.append(_begin_time);
			info.append(_end_time);
			info.append(term_id);
			info.append(_face);
			info.append(_lv);
		}

		bool termCompare(const boost::shared_ptr<Term>& a, const boost::shared_ptr<Term>& b)
		{
			return (*a) < (*b);
		}

		// class TermInfo
		TermInfo::TermInfo(const int nation)
			: _nation(nation)
		{}

		void TermInfo::classLoad()
		{
			mongo::BSONObj key = BSON("nt" << _nation);
			objCollection objs = db_mgr.Query(DBN::dbKingFightKingRecord, key);
			ForEachC(objCollection, it, objs)
			{
				TermPtr ptr = Creator<Term>::Create(_nation);
				ptr->load(*it);
				_term_list.push_back(ptr);
			}
			std::sort(_term_list.begin(), _term_list.end(), termCompare);
		}

		void TermInfo::add(unsigned begin_time, playerDataPtr d)
		{
			if (_term_list.empty())
			{
				TermPtr ptr = Creator<Term>::Create(_nation);
				ptr->setBeginTime(begin_time);
				ptr->setPlayer(d);
				_term_list.push_back(ptr);
			}
			else if (_term_list.back()->pid() != d->ID())
			{
				_term_list.back()->setEndTime(begin_time);
				TermPtr ptr = Creator<Term>::Create(_nation);
				ptr->setBeginTime(begin_time);
				ptr->setPlayer(d);
				_term_list.push_back(ptr);
			}
		}

		void TermInfo::getInfo(Json::Value& info, int begin, int end) const
		{
			const static std::string PosId[] = {"1", "2", "3", "4", "5", "6"};
			info["nm"] = (int)_term_list.size();
			Json::Value& ref = info["of"];
			ref = Json::objectValue;
			if (begin < 1 || begin > end)
				return;
			int pos = 0;
			for (int i = begin - 1; i < end; ++i)
			{
				if (i >= _term_list.size())
					return;
				_term_list[i]->getInfo(ref[PosId[pos++]], i+1);
			}
		}

		// class Challenger
		Challenger::Challenger()
			: _pid(-1), _score(0)
		{}

		void Challenger::load(const mongo::BSONElement& obj)
		{
			_pid = obj["p"].Int();
			_name = obj["n"].String();
			_lv = obj["l"].Int();
			_face = obj["f"].Int();
			_rep_id = obj["r"].String();
			_score = obj["s"].Int();
		}

		mongo::BSONObj Challenger::toBSON() const
		{
			return BSON("p" << _pid << "n" << _name << "l" << _lv << "f" << _face << "r" << _rep_id << "s" << _score);
		}

		void Challenger::getInfo(Json::Value& info) const
		{
			info = Json::arrayValue;
			if (_pid != -1)
			{
				info.append(_face);
				info.append(_name);
				info.append(_pid);
				info.append(_score);
				info.append(_rep_id);
			}
		}

		void Challenger::setPlayer(playerDataPtr d)
		{
			_pid = d->ID();
			_name = d->Name();
			_lv = d->LV();
			_face = d->Info().Face();
		}

		// class Challengers
		Challengers::Challengers(const int nation)
			: _nation(nation)
		{
		}

		void Challengers::classLoad()
		{
			mongo::BSONObj key = BSON("key" << KeyChallenger[_nation]);
			mongo::BSONObj obj = db_mgr.FindOne(DBN::dbKingFight, key);
			if (obj.isEmpty())
				return;

			_challenger[Left].load(obj["cl"]);
			_challenger[Right].load(obj["cr"]);
		}

		void Challengers::getInfo(Json::Value& info) const
		{
			_challenger[Left].getInfo(info["1"]);
			_challenger[Right].getInfo(info["2"]);
		}
		
		bool Challengers::_auto_save()
		{
			mongo::BSONObj key = BSON("key" << KeyChallenger[_nation]);
			mongo::BSONObjBuilder obj;
			obj << "key" << KeyChallenger[_nation] << "cl" << _challenger[Left].toBSON()
				<< "cr" << _challenger[Right].toBSON();
			return db_mgr.SaveMongo(DBN::dbKingFight, key, obj.obj());
		}

		void Challengers::setPlayer(int side, playerDataPtr d)
		{
			_challenger[side].setPlayer(d);
			_sign_save();
		}

		void Challengers::setRepId(int side, const std::string& rep_id)
		{
			_challenger[side].setRepId(rep_id);
			_sign_save();
		}

		void Challengers::addScore(int side)
		{
			_challenger[side].addScore();
			_sign_save();
		}

		void Challengers::clear()
		{
			_challenger[Left].clear();
			_challenger[Right].clear();
			_sign_save();
		}

		bool Challengers::inCrown(int pid) const
		{
			return pid == _challenger[Left].pid() 
				|| pid == _challenger[Right].pid();
		}
			
		
		// class Manager
		Manager::Handler Manager::_tick_func[MaxTimeNode];

		Manager::Manager(int n)
			: State(n), _term_list(nation())
		{
		}

		void Manager::init()
		{
			createDir();

			_challenger = Creator<Challengers>::Create(nation());
			_report_list = Creator<ReportInfo>::Create(nation());
			_title_list = Creator<TitleInfo>::Create(nation());

			State::classLoad();
			_title_list->classLoad();
			_report_list->classLoad();
			_term_list.classLoad();
			_challenger->classLoad();
			checkInited();
			setTimer();
		}

		int Manager::challenge(playerDataPtr d, int side)
		{
			if (state() != Challenged)
				return err_illedge;
			if (_challenger->inCrown(d->ID()))
				return err_illedge;
			if (d->KingFight().inBattleCd())
				return err_illedge;
			if (_challenger->get(side).empty())
				_challenger->setPlayer(side, d);
			else
			{
				playerDataPtr target = player_mgr.getPlayer(_challenger->get(side).pid());
				if (!target)
					return err_illedge;

				sBattlePtr atk = BattleHelp::WarPlayer(d);
				sBattlePtr def = BattleHelp::WarPlayer(target);

				BattleReport reportData;
				O2ORes resultB = reportData.One2One(atk, def, typeBattle::crown_fight);
				addReportDeclare(reportData, d, target);
				reportData.addNotice(d->ID());

				if (resultB.res == resBattle::atk_win)
				{
					std::string rep_id = _report_list->add(d, target, side == Left? LeftCrown : RightCrown);
					_challenger->setPlayer(side, d);
					_challenger->setRepId(side, rep_id);
					reportData.addCopyField(ReportDir[nation()] + rep_id);
					if (Common::randomOk(0.3))
						DoBroadcast(d->Info().Nation(), 0, chat_sys.ChatPackage(d), chat_sys.ChatPackage(target), "", "");
					Log(DBLOG::strLogKingFight, d, 2, target->ID());
				}		

				reportData.Done(typeBattle::crown_fight);
			}
			d->Daily().tickTask(DAILY::kingdom_fight);
			return res_sucess;
		}

		int Manager::setTitle(playerDataPtr d, const std::string& name, int title)
		{
			if (d->ID() != _title_list->get(Kingdom::GuoWang)->pid())
				return err_illedge;

			playerDataPtr target = player_mgr.getPlayer(name);
			if (!target)
				return err_king_fight_noplayer;

			int res = _title_list->setPlayer(title, target);
			if (res == res_sucess)
				Log(DBLOG::strLogKingFight, 4, 1, target->ID(), title, d->ID());
			return res;
		}

		int Manager::autoSetTitle(playerDataPtr d)
		{
			if (d->ID() != getPidByTitle(Kingdom::GuoWang))
				return err_illedge;
			
			if (!_title_list->notSetted())
				return err_illedge;
			
			std::vector<heroPartyPtr> vec = heroparty_sys.sendChart((Kingdom::NATION)nation(), 12);
			int title = Kingdom::ZuoChengXiang;
			ForEachC(std::vector<heroPartyPtr>, it, vec)
			{
				if ((*it)->iPlayerID == d->ID())
					continue;
				playerDataPtr target = player_mgr.getPlayer((*it)->iPlayerID);
				_title_list->setPlayer(title, target);
				Log(DBLOG::strLogKingFight, 4, 2, target->ID(), title, d->ID(), (*it)->iHeroNo);
				++title;
			}
			return res_sucess;
		}

		int Manager::bet(playerDataPtr d, int side, int type)
		{
			if (state() != Betting)
				return err_illedge;
			if (_challenger->inCrown(d->ID()))
				return err_illedge;
			int pid = _challenger->get(side).pid();
			std::string name = _challenger->get(side).name();
			int cost = kingfight_sys.betSilver() * type;
			int rate = type == 1? 2 : 4;
			return d->KingFight().bet(pid, name, cost, rate);
		}

		void Manager::getInfo(playerDataPtr d, Json::Value& info) const
		{
			info["ty"] = getUIType();
			info["isc"] = _challenger->inCrown(d->ID())? 1 : 0;
			info["et"] = nextUpdateTime();
			info["num"] = getFinalNum() + 1;
			info["od"] = kingfight_sys.betSilver();
			_report_list->getInfo(info["rep"]);
			_challenger->getInfo(info["cr"]);
			d->KingFight().getInfo(info);
		}

		void Manager::getTitleInfo(Json::Value& info) const
		{
			_title_list->getInfo(info);
		}

		void Manager::getTitleInfo(qValue& info) const
		{
			_title_list->getInfo(info);
		}

		void Manager::getTermInfo(Json::Value& info, int begin, int end) const
		{
			_term_list.getInfo(info, begin, end);
		}

		void Manager::setHandler()
		{
			_tick_func[Time1400] = &Manager::tickAt1400;
			_tick_func[Time2130] = &Manager::tickAt2130;
			_tick_func[Time2140_50] = &Manager::tickAt2140_50;
		}

		void Manager::checkInited()
		{
			if (state() == Unsetted)
			{
				setState(Closed);
				setNextTimeNode(Time1400);
				unsigned cur_time = Common::gameTime();
				int season = season_sys.getSeason(cur_time);
				if (season == SEASON::Spring)
				{
					unsigned time_zero = Common::timeZero(cur_time);
					unsigned open_time = time_zero + 14 * HOUR;
					unsigned close_time = time_zero + 21 * HOUR + 30 * MINUTE;
					if (cur_time < close_time)
						setNextUpdateTime(open_time);
					else
						setNextUpdateTime(getNextOpenTime(cur_time));
				}
				else
					setNextUpdateTime(getNextOpenTime(cur_time));
			}
		}
		
		void Manager::setTimer()
		{
			Timer::AddEventTickTime(boostBind(Manager::tick, this, nextTimeNode(), nextUpdateTime()), Inter::event_king_fight_timer, nextUpdateTime());
			//Timer2::add(nextUpdateTime(), boostBind(Manager::tick, this, nextTimeNode(), nextUpdateTime()));
		}

		void Manager::tick(int time_node, unsigned tick_time)
		{
			_tick_func[time_node](this, tick_time);
			setTimer();
		}

		void Manager::tickAt2140_50(unsigned tick_time)
		{
			const Challenger& cl = _challenger->get(Left);
			const Challenger& cr = _challenger->get(Right);
			
			playerDataPtr pl = player_mgr.getPlayer(cl.pid());
			playerDataPtr pr = player_mgr.getPlayer(cr.pid());
			if (!pl || !pr)
			{
				// error
				return;
			}

			sBattlePtr atk, def;
			int final_num = getFinalNum(); 
			if (final_num == 0 || (final_num == 2 && Common::randomOk(0.5)))
			{
				atk = BattleHelp::WarPlayer(pl);
				def = BattleHelp::WarPlayer(pr);
			}
			else
			{
				def = BattleHelp::WarPlayer(pl);
				atk = BattleHelp::WarPlayer(pr);
			}
			
			BattleReport reportData;
			O2ORes resultB = reportData.One2One(atk, def, typeBattle::crown_fight);

			int wpid = resultB.res == resBattle::atk_win? atk->playerID : def->playerID;
			int report_type = FinalOne + final_num;
			playerDataPtr wp, lp;
			if (wpid == pl->ID())
			{
				_challenger->addScore(Left);
				wp = pl;
				lp = pr;
			}
			else
			{
				_challenger->addScore(Right);
				wp = pr;
				lp = pl;
			}
			std::string rep_id = _report_list->add(wp, lp, report_type);
			
			if (atk->playerID == pl->ID())
				addReportDeclare(reportData, pl, pr);
			else
				addReportDeclare(reportData, pr, pl);

			rep_id = ReportDir[nation()] + rep_id;
			reportData.addCopyField(rep_id);
			reportData.Done(typeBattle::crown_fight);

			Log(DBLOG::strLogKingFight, 3, atk->playerID, def->playerID, nation(), wp->ID());

			if (cl.score() == 2 || cr.score() == 2)
			{
				if (final_num == 2)
					addFinalBroadcast(6, wp, lp, rep_id);
				else
					addFinalBroadcast(7, wp, lp, rep_id);
					
				setKingInfo(tick_time, cl.score() == 2? pl : pr);

				wp->KingFight().setFinalState(2, kingfight_sys.winSilver());
				lp->KingFight().setFinalState(3, kingfight_sys.loseSilver());

				setLastCloseTime(tick_time);
				setState(Closed);
				setNextTimeNode(Time1400);
				setNextUpdateTime(getNextOpenTime(tick_time));
			}
			else
			{
				setState(Final);
				setNextTimeNode(Time2140_50);
				setNextUpdateTime(tick_time + 5 * MINUTE);
				if (final_num == 0)
					addFinalBroadcast(5, wp, lp, rep_id);
				else
					addFinalBroadcast(8, wp, lp, rep_id);
			}
		}

		void Manager::tickAt1400(unsigned tick_time)
		{
			_report_list->clear();
			_challenger->clear();

			setState(Challenged);
			setNextTimeNode(Time2130);
			setNextUpdateTime(tick_time + 7 * HOUR + 30 * MINUTE);
			setLastOpenTime(tick_time);
		}

		void Manager::tickAt2130(unsigned tick_time)
		{
			int num = getChallengerNum();
			if (num == 0)
			{
				setState(Closed);
				setNextTimeNode(Time1400);
				setNextUpdateTime(getNextOpenTime(tick_time));
				if (_term_list.empty())
					DoBroadcast(-1, 4, nation(), "", "", "");
				else
				{
					int pid = getPidByTitle(Kingdom::GuoWang);
					playerDataPtr d = player_mgr.getPlayer(pid);
					if (!d) return;
					DoBroadcast(-1, 3, nation(), chat_sys.ChatPackage(d), "", "");
				}
			}
			else if (num == 1)
			{
				setState(Closed);
				setNextTimeNode(Time1400);
				setNextUpdateTime(getNextOpenTime(tick_time));
				setLastCloseTime(tick_time);
				
				int pid = getWinner();
				playerDataPtr d = player_mgr.getPlayer(pid);
				if (!d)
				{
					// error;
					return;
				}
				setKingInfo(tick_time, d);
				DoBroadcast(-1, 2, chat_sys.ChatPackage(d), nation(), "", "");
			}
			else
			{
				setState(Betting);
				setNextTimeNode(Time2140_50);
				setNextUpdateTime(tick_time + 10 * MINUTE);
				DoBroadcast(nation(), 10, "", "", "", "");
				int pida = _challenger->get(Left).pid();
				int pidb = _challenger->get(Right).pid();
				playerDataPtr pa = player_mgr.getPlayer(pida);
				playerDataPtr pb = player_mgr.getPlayer(pidb);
				if (!pa || !pb)
					return;
				pa->KingFight().setFinalState(1, 0);
				pb->KingFight().setFinalState(1, 0);
			}
		}

		void Manager::addReportDeclare(BattleReport& reportData, playerDataPtr atkp, playerDataPtr defp)
		{
			Json::Value man_exp;
			BattleHelp::AddManExp(atkp, 0, man_exp);
			reportData.addReportdeclare("me", man_exp);
			Json::Value role_exp;
			role_exp.append(atkp->LV());
			role_exp.append(atkp->Info().EXP());
			role_exp.append(atkp->LV());
			role_exp.append(atkp->Info().EXP());
			role_exp.append(0);
			role_exp.append(atkp->Info().isMaxLevel());
			reportData.addReportdeclare("plv", role_exp);
		}

		void Manager::setKingInfo(unsigned tick_time, playerDataPtr d)
		{
			_term_list.add(tick_time, d);
			_title_list->clear();
			_title_list->setPlayer(Kingdom::GuoWang, d);
		}

		unsigned Manager::getNextOpenTime(unsigned tick_time) const
		{
			return season_sys.getNSTimeHMS(tick_time, SEASON::Spring, 14, 0, 0);
		}

		int Manager::getFinalNum() const
		{
			return _challenger->get(Left).score() + _challenger->get(Right).score();
		}

		int Manager::getChallengerNum() const
		{
			int num = 0;
			if (!_challenger->get(Left).empty())
				++num;
			if (!_challenger->get(Right).empty())
				++num;
			return num;
		}

		int Manager::getWinner() const
		{
			if (_challenger->get(Left).empty()
				&& _challenger->get(Right).empty())
				return -1;
			if (_challenger->get(Left).empty()
				|| _challenger->get(Right).score() == 2)
				return _challenger->get(Right).pid();
			if (_challenger->get(Right).empty()
				|| _challenger->get(Left).score() == 2)
				return _challenger->get(Left).pid();
			return -1;
		}

		int Manager::getPidByTitle(int title) const
		{
			if (title < Kingdom::GuoWang || title >= Kingdom::PingMin)
				return -1;
			return _title_list->get(title)->pid();
		}

		int Manager::getUIType() const
		{
			static const int type[] = {3, 1, 2, 2};
			return type[state()];
		}

		void Manager::finalBroadcast(Json::Value json, std::string path)
		{
			int rep_id = chat_sys.toChatWindowsRep(path);
			json.append(rep_id);
			chat_sys.despatchAll(CHAT::server_kingfight_state, json);
		}

		void Manager::addFinalBroadcast(int type, playerDataPtr d, playerDataPtr target, const std::string& rep_id)
		{
			Json::Value json;
			json.append(type);
			json.append(chat_sys.ChatPackage(d));
			json.append(chat_sys.ChatPackage(target));
			json.append(nation());
			UserTask::Add(boostBind(Manager::finalBroadcast, this, json, "./report/" + rep_id), gg::State::getState());
		}

		void Manager::createDir()
		{
			Common::createDirectories(strRpDirRoot + ReportDir[nation()]);
		}

		void Manager::getKingInfo(Json::Value& info) const
		{
			info["na"] = _title_list->get(Kingdom::GuoWang)->name();		
		}

		void Manager::updateName(playerDataPtr d)
		{
			if (_challenger->get(Left).pid() == d->ID())
				_challenger->setPlayer(Left, d);
			else if (_challenger->get(Right).pid() == d->ID())
				_challenger->setPlayer(Right, d);

			if (d->KingFight().getTitle() != Kingdom::PingMin)
				_title_list->update(d);
		}

		void Manager::getUnityInfo(qValue& q) const
		{
			q.addMember("n", nation());
			TitleInfo::TitlePtr ptr = _title_list->get(Kingdom::GuoWang);	
			if (!ptr->empty())
			{
				q.addMember("na", ptr->name());
				q.addMember("f", ptr->face());
			}
			qValue tl;
			getTitleInfo(tl);
			q.addMember("tl", tl);
		}

		const std::string& Manager::getKingName() const
		{
			return _title_list->get(Kingdom::GuoWang)->name();			
		}
	}
}

#include "business.h"
#include "zip_file.hpp"
#include "battle_helper.hpp"
#include "chat.h"
//#include "kingdom.h"
#include "kingdom_system.h"
#include "task_mgr.h"
#include "email_system.h"
#include "wstar.h"

namespace gg
{
	const static int StanderX = 20;//��ͼ���ӱ���
	const static int StanderY = 12;//��ͼ���ӱ���

	const static unsigned systemUseLimit = 31;

	const static int SilverKeyID = 50005;//��Կ��
	const static int GoldKeyID = 50006;//��Կ��
	const static int CarMaterialID = 50007;//�̴�����
	//50002 fangshui 50003 weishe 50004 yijia
	const static int FangShuiID = 50002;
	const static int WeiSheID = 50003;
	const static int YiJiaID = 50004;
	struct TBstruct
	{
		TBstruct()
		{
			_id_buff = TradeBuff::null;
			_duration = 0;
		}
		TBstruct(const TradeBuff::ID _id, const unsigned _d)
		{
			_id_buff = _id;
			_duration = _d;
		}
		TradeBuff::ID _id_buff;
		unsigned _duration;
	};
	static std::map<int, TBstruct> BuffDoMap;
	TBstruct getBindBuff(const int ID)
	{
		std::map<int, TBstruct>::iterator it = BuffDoMap.find(ID);
		if (it == BuffDoMap.end())return TBstruct();
		return it->second;
	}

	const static int ShunYiID = 50001;



	static unsigned CityEventNum = 3;//�����¼�����//һ������1���¼� �¼�ֻ��1��
	static unsigned MapHaiDaoEvent[2] = { 5, 10 };//��ͼ�����¼�
	static unsigned MapSilverBoxEvent[2] = { 5, 10 };//��ͼ������
	static unsigned MapGoldBoxEvent[2] = { 5, 10 };//��ͼ����


												   //���������¼��ĵ�ͼ����
	namespace MapEvnet
	{
		enum Type
		{
			null,//û���κ��¼�
			haidao,//����
			silver_box,//������
			gold_box,//����
			shark,//�����
			shark_boss,//����boss
			shark_boss_chest,//���㱦��
		};
	}

	enum
	{
		car_enter,
		car_exit
	};

	class AreaData;
	BOOSTSHAREPTR(AreaData, ptrAreaData);
	struct _info;
	BOOSTSHAREPTR(_info, _info_ptr);
	struct _info :
		public boost::enable_shared_from_this<_info>
	{
		static _info_ptr Create(playerDataPtr player);
		_info(playerDataPtr player);
		int playerID;
		string playerName;
		Kingdom::NATION playerNation;
		unsigned cpos_idx;//��ǰ���ڵ���
		unsigned cpos_x;//��ǰx
		unsigned cpos_y;//��ǰy
		unsigned aim_x;//Ŀ��x
		unsigned aim_y;//Ŀ��y
		unsigned speed;//�ٶ�
		unsigned level;//��ֻ�ȼ�
		unsigned state;
		unsigned updateCD;
		bool been_post;
		inline bool isEnter() { return state == car_enter; }
		inline bool isExit() { return state == car_exit; }
		void sendCarePlayer(playerDataPtr player);
		void sendAround(playerDataPtr player);
		void setNewPos(playerDataPtr player, const unsigned x, const unsigned y);
		ptrAreaData currentArea();
		qValue toJson()
		{
			qValue json(qJson::qj_array);
			json.append(playerID);
			json.append(playerName);
			json.append(playerNation);
			json.append(cpos_x);
			json.append(cpos_y);
			json.append(aim_x);
			json.append(aim_y);
			json.append(speed);
			json.append(level);
			return json;
		}
	};
	UNORDERMAP(int, _info_ptr, _brPlayerMap);
	static _brPlayerMap _brPlayers;//�������
	_info_ptr getBRPlayer(const int playerID)
	{
		_brPlayerMap::iterator it = _brPlayers.find(playerID);
		if (it == _brPlayers.end())return _info_ptr();
		return it->second;
	}

	namespace POS
	{
		struct Rect//����//����
		{
			Rect(
				const int lbx,
				const int lby,
				const int rtx,
				const int rty
			)
				: _left_bottom_x(lbx)
				, _left_bottom_y(lby)
				, _right_top_x(rtx)
				, _right_top_y(rty)
			{
			}
			const int _left_bottom_x;
			const int _left_bottom_y;
			const int _right_top_x;
			const int _right_top_y;
			inline bool isMatch(const int x, const int y)const
			{
				return (
					x >= _left_bottom_x &&
					x <= _right_top_x &&
					y >= _left_bottom_y &&
					y <= _right_top_y
					);
			}
		};
	}

	struct SharkData
	{
		SharkData(const unsigned tick)
			: _createTick(tick)
		{
			_hitTime = 0;
			_boxTime = 0;
			_x = 0;
			_y = 0;
			_current_hp = 0;
			_total_hp = 0;
		}
		const unsigned _createTick;
		unsigned _hitTime;//��һ�ι���ʱ��
		unsigned _boxTime;//��ȡ�������ʱ��
		int _x;
		int _y;
		int _total_hp;
		int _current_hp;
		sBattlePtr _shark;
	};
	BOOSTSHAREPTR(SharkData, ptrSharkData);
	static ptrSharkData currentShark;//��ǰ���㱦�佱����ID

	static std::vector< WSTAR::Pos > EventCoor;
	static std::vector< WSTAR::Pos > UsePos;

	//����
	class AreaData :
		public boost::enable_shared_from_this<AreaData>
	{
	public:
		BOOSTWEAKPTR(AreaData, ptrWeakArea);
		STDMAP(int, ptrWeakArea, AreaWeakMap);
	public:
		AreaData(
			const int idx,
			const int lbx,
			const int lby,
			const int rtx,
			const int rty
		) :
			_INDEX(idx),
			_Area(lbx, lby, rtx, rty)
		{
			_Events.clear();
			_Code = "";
			_PlayerIt = _Player.end();
		}
		void bindAreaRelate();
		const unsigned _INDEX;
		const POS::Rect _Area;
		void replacePlayer(_info_ptr info)
		{
			_Player[info->playerID] = info;
		}
		void removePlayer(const int playerID)
		{
			if (_PlayerIt != _Player.end())
			{
				_info_ptr info = _PlayerIt->second;
				if (info->playerID == playerID)
				{
					++_PlayerIt;
				}
			}
			_Player.erase(playerID);
		}
		inline string Code() { return _Code; }
		void removeEvent(const unsigned x, const unsigned y);
		void sendVisibleEvent(playerDataPtr player)
		{
			qValue data_json(qJson::qj_array);
			for (AreaWeakMap::iterator vit = _Visible.begin(); vit != _Visible.end(); ++vit)
			{
				const EvnetMap& checkMap = (vit->second).lock()->_Events;
				for (EvnetMap::const_iterator it = checkMap.begin(); it != checkMap.end(); ++it)
				{
					const WSTAR::Pos& pos = it->first;
					const MapEvnet::Type type = it->second;
					qValue single_json(qJson::qj_array);
					single_json.append(pos.x);
					single_json.append(pos.y);
					single_json.append(type);
					if (type == MapEvnet::shark_boss)
					{
						single_json.append(currentShark->_current_hp);
						single_json.append(currentShark->_total_hp);
					}
					data_json.append(single_json);
				}
			}
			qValue msg_json(qJson::qj_array);
			msg_json.append(res_sucess).append(data_json);
			player->sendToClientFillMsg(gate_client::player_update_trade_map_event_resp, msg_json);
		}
		bool sendSomeVisiblePlayer(playerDataPtr player, _info& player_car)//�����������
		{
			const unsigned now = Common::gameTime();
			if (now < player_car.updateCD)return false;
			qValue data_json(qJson::qj_array);
			for (AreaWeakMap::iterator vit = _Visible.begin(); vit != _Visible.end(); ++vit)
			{
				ptrAreaData ptr = (vit->second).lock();
				_brPlayerMap::const_iterator& checkIt = ptr->_PlayerIt;
				const _brPlayerMap& checkMap = ptr->_Player;
				if (checkIt == checkMap.end())checkIt = checkMap.begin();
				const int playerID = player->ID();
				unsigned num = 0;//��Ҫ�Է������·�
				for (; num < 3 && checkIt != checkMap.end(); ++checkIt)
				{
					_info_ptr info = checkIt->second;
					if (info->playerID == playerID)continue;//�Լ������� ������
					data_json.append(info->toJson());
					++num;
				}
			}
			player_car.updateCD = now + 3;
			if (data_json.isEmpty())return false;
			qValue msg_json(qJson::qj_array);//һ�����·�
			msg_json.append(res_sucess).append(data_json);
			player->sendToClientFillMsg(gate_client::player_trade_map_area_update_resp, msg_json);
			return true;
		}
		void clearEvent();
		void sendAroudNewEvent();
		void addEvent(const unsigned x, const unsigned y, const MapEvnet::Type type);
		inline bool matchArea(const unsigned x, const unsigned y)const { return _Area.isMatch(x, y); }//�Ƿ�����������
	private:
		_brPlayerMap::const_iterator _PlayerIt;
		_brPlayerMap _Player;//������������б�
		STDMAP(WSTAR::Pos, MapEvnet::Type, EvnetMap);
		EvnetMap _Events;//���������¼��б�
		string _Code;//������
		AreaWeakMap _Visible;//�ɼ�������, ����������Ҳ���ļ���
	};
	STDMAP(int, ptrAreaData, AreaMap);
	static AreaMap Areas;//��ͼ�������
	ptrAreaData getArea(const unsigned idx)
	{
		AreaMap::iterator it = Areas.find(idx);
		if (it == Areas.end())return ptrAreaData();
		return it->second;
	}

	struct MapPoint
	{
		explicit MapPoint(
			const int x = 0,
			const int y = 0,
			const MapEvnet::Type type = MapEvnet::null,
			const bool available = false
		)
		{
			_x = x;
			_y = y;
			_Type = type;
			_Available = available;
			_relateArea = NULL;
		}
		void setEvent(const MapEvnet::Type type);
		int _x;
		int _y;
		MapEvnet::Type _Type;
		bool _Available;
		AreaData* _relateArea;
	};
	static vector< vector< MapPoint > > MapData;
	MapEvnet::Type getMapEvent(const int x, const int y)
	{
		if ((unsigned)x < MapData.size())
		{
			vector< MapPoint >& yVec = MapData[x];
			if ((unsigned)y < yVec.size())
			{
				return yVec[y]._Type;
			}
		}
		return MapEvnet::null;
	}

	void removeMapEvent(const int x, const int y)
	{
		const unsigned idx = x / StanderX + (y / StanderY) * (MapData.size() / StanderX);
		ptrAreaData ptr = getArea(idx);
		if (ptr)
		{
			ptr->removeEvent(x, y);
		}
	}

	void AreaData::sendAroudNewEvent()
	{
		qValue data_json(qJson::qj_array);
		for (_brPlayerMap::const_iterator it = _Player.begin(); it != _Player.end(); ++it)
		{
			_info_ptr info = it->second;
			if (info->isEnter())
			{
				playerDataPtr player = player_mgr.getOnlinePlayer(info->playerID);
				if (player)
				{
					sendVisibleEvent(player);
				}
			}
		}
	}

	void AreaData::clearEvent()
	{
		for (EvnetMap::iterator it = _Events.begin(); it != _Events.end(); it++)
		{
			WSTAR::Pos coor = it->first;
			MapData[coor.x][coor.y]._Type = MapEvnet::null;
		}
		_Events.clear();
	}

	void AreaData::addEvent(const unsigned x, const unsigned y, const MapEvnet::Type type)
	{
		if (matchArea(x, y))
		{
			MapData[x][y]._Type = type;
			_Events[WSTAR::Pos(x, y)] = type;
		}
	}

	void AreaData::removeEvent(const unsigned x, const unsigned y)
	{
		if (_Events.erase(WSTAR::Pos(x, y)) > 0)//������¼�ɾ���ɹ���
		{
			MapData[x][y]._Type = MapEvnet::null;
			for (AreaWeakMap::iterator vit = _Visible.begin(); vit != _Visible.end(); ++vit)
			{
				const _brPlayerMap& checkMap = (vit->second).lock()->_Player;
				for (_brPlayerMap::const_iterator it = checkMap.begin(); it != checkMap.end(); ++it)
				{
					_info_ptr ptr = it->second;
					if (ptr->isEnter())
					{
						playerDataPtr player = player_mgr.getOnlinePlayer(ptr->playerID);
						if (player)
						{
							sendVisibleEvent(player);//���͵�ͼ�¼������
						}
					}
				}
			}
		}
	}

	const static unsigned RangeSize = 1;
	void AreaData::bindAreaRelate()
	{
		//range 1
		const unsigned x_length = MapData.size() / StanderX;// 0 <= ? < x_length
		const unsigned y_length = MapData[0u].size() / StanderY;// 0 <= ? < y_length
		const unsigned all_num = x_length * y_length;//���� 0 <= ? < all_n

		_Visible.clear();
		_Code = "";
		//��ȡ�Ź���

		//��ǰ����
		const unsigned spx = _INDEX % x_length;
		const unsigned spy = _INDEX / x_length;

		//��������ƫ��
		const unsigned left_bottom_x = spx < RangeSize ? 0 : spx - RangeSize;
		const unsigned left_bottom_y = spy < RangeSize ? 0 : spy - RangeSize;

		//��������ƫ��
		const unsigned right_top_x = spx + RangeSize < x_length ? spx + RangeSize : spx;
		const unsigned right_top_y = spy + RangeSize < y_length ? spy + RangeSize : spy;

		for (unsigned x = left_bottom_x; x <= right_top_x; x++)
		{
			for (unsigned y = left_bottom_y; y <= right_top_y; y++)
			{
				_Code += Common::toString(x + y * x_length);
				_Visible[x + y * x_length] = Areas[x + y * x_length];
			}
		}
	}


	//boardcast player info
	_info::_info(playerDataPtr player)
	{
		state = car_enter;
		playerID = player->ID();
		playerName = player->Name();
		playerNation = player->Info().Nation();
		playerCarPos& Car = player->CarPos();
		cpos_x = Car.currentX();//��ǰλ��
		cpos_y = Car.currentY();//��ǰλ��
		aim_x = Car.aimX();
		aim_y = Car.aimY();
		cpos_idx = cpos_x / StanderX + (cpos_y / StanderY) * (MapData.size() / StanderX);
		playerTrade& Trade = player->Trade();
		speed = Trade.getSpeed();
		level = Trade.getLevel();
		updateCD = 0;
		been_post = false;
	}

	static void PlayerAreaUpdate(const structTimer& timerData, boost::weak_ptr<_info> weak_info)
	{
		_info_ptr ptr = weak_info.lock();
		if (!ptr)return;
		ptr->been_post = false;
		if (ptr->isEnter())
		{
			playerDataPtr player = player_mgr.getOnlinePlayer(ptr->playerID);
			if (player)
			{
				ptr->sendCarePlayer(player);
				ptr->been_post = true;
				Timer::AddEventTickTime(boostBind(PlayerAreaUpdate, _1, ptr), Inter::event_trade_area_timer, ptr->updateCD);
			}
		}
	}

	_info_ptr _info::Create(playerDataPtr player)
	{
		_info_ptr info = Creator<_info>::Create(player);
		_brPlayers[player->ID()] = info;
		AreaData* current_area = MapData[info->cpos_x][info->cpos_y]._relateArea;
		current_area->replacePlayer(info);
		info->sendAround(player);
		info->been_post = true;
		Timer::AddEventTickTime(boostBind(PlayerAreaUpdate, _1, info), Inter::event_trade_area_timer, info->updateCD);
		return info;
	}

	void _info::setNewPos(playerDataPtr player, const unsigned x, const unsigned y)
	{
		AreaData* old_area = MapData[cpos_x][cpos_y]._relateArea;
		cpos_x = x;
		cpos_y = y;
		AreaData* new_area = MapData[cpos_x][cpos_y]._relateArea;
		const unsigned old_idx = cpos_idx;
		cpos_idx = cpos_x / StanderX + (cpos_y / StanderY) * (MapData.size() / StanderX);
		if (old_idx != cpos_idx)
		{
			old_area->removePlayer(playerID);
			new_area->replacePlayer(shared_from_this());
			updateCD = 0;
			sendAround(player);
		}
	}

	ptrAreaData _info::currentArea()
	{
		return getArea(cpos_idx);
	}

	void _info::sendAround(playerDataPtr player)
	{
		ptrAreaData now_area = currentArea();
		now_area->sendVisibleEvent(player);
		now_area->sendSomeVisiblePlayer(player, *this);
	}

	void _info::sendCarePlayer(playerDataPtr player)
	{
		ptrAreaData now_area = currentArea();
		now_area->sendSomeVisiblePlayer(player, *this);
	}

	void MapPoint::setEvent(const MapEvnet::Type type)
	{
		_relateArea->addEvent(_x, _y, type);
	}

	//instance
	business* const business::_Instance = new business();
	static boost::unordered_map<int, int> cityEvnMap;
	static vector<int> cityIDList;
	static zipFile tradeFile;//ó���ļ�д����
	static unsigned richTickTime = 0;

	struct AreaRange
	{
		int areaID;
		unsigned left_x;
		unsigned left_y;
		unsigned right_x;
		unsigned right_y;
	};
	UNORDERMAP(int, AreaRange, CityRangeMap);
	static CityRangeMap CitiesRange;//���з�Χ
	bool validCityRange(const int cityID, const unsigned x, const unsigned y)
	{
		CityRangeMap::iterator it = CitiesRange.find(cityID);
		if (it == CitiesRange.end())return false;
		const AreaRange& range = it->second;
		return (x >= range.left_x && x <= range.right_x && y >= range.left_y && y <= range.right_y);
	}

	//������
	struct richData
	{
		richData()
		{
			playerID = -1;
			playerName = "";
			tradeTimes = 0;
			money = 0;
			kingdom = Kingdom::null;
			createTime = Common::gameTime();
		}
		richData(playerDataPtr player, const int m)
		{
			playerID = player->ID();
			playerName = player->Name();
			kingdom = player->Info().Nation();
			tradeTimes = player->Trade().totalTask();
			money = m;
			createTime = Common::gameTime();
		}
		mongo::BSONObj toBSON()
		{
			return BSON("i" << playerID << "n" << playerName <<
				"t" << tradeTimes << "k" << kingdom << "m" << money <<
				"ct" << createTime);
		}
		int playerID;
		string playerName;
		unsigned tradeTimes;
		int money;
		Kingdom::NATION kingdom;
		unsigned createTime;
	};
	BOOSTSHAREPTR(richData, richPtr);
	static vector<richPtr> dayRich, historyRich, totalRich;
	UNORDERMAP(int, richPtr, richMap);
	static richMap dayRichMap, historyRichMap, totalRichMap;

	//������Ʒ����
	struct CityData
	{
		int cityID;
		struct Wares //��Ʒ
		{
			Wares()
			{
				price = 0;
				history.clear();
			}
			int price;//��ǰ�۸�
			int wareID;//��ƷID
			int upPrice;//�ۼ�����
			int lowPrice;//�ۼ�����
			int upPriceF;//�ۼ۸�������
			int lowPriceF;//�ۼ۸�������
			vector<int> history;//��ʷ�۸�
			qValue toHisJson()
			{
				qValue json(qJson::qj_object), data_json(qJson::qj_array);
				json.addMember("id", wareID);
				for (unsigned i = 0; i < history.size(); ++i)
				{
					data_json.append(history[i]);
				}
				json.addMember("p", data_json);
				return json;
			}
			qValue toJson()
			{
				qValue json(qJson::qj_object);
				json.addMember("id", wareID);
				json.addMember("pr", price);
				return json;
			}
		};
		qValue toJson()
		{
			qValue json(qJson::qj_object);
			json.addMember("id", cityID);
			qValue sj(qJson::qj_array), bj(qJson::qj_array);;
			for (wareMap::iterator it = PawnMap.begin(); it != PawnMap.end(); ++it)
			{
				sj.append(it->second->toJson());
			}
			json.addMember("s", sj);
			for (wareMap::iterator it = ShopMap.begin(); it != ShopMap.end(); ++it)
			{
				bj.append(it->second->toJson());
			}
			json.addMember("b", bj);
			return json;
		}
		BOOSTSHAREPTR(Wares, warePtr);
		UNORDERMAP(int, warePtr, wareMap);
		wareMap PawnMap, ShopMap;//������Ʒ�б�, ������Ʒ�б�
		warePtr saleWare(const int wareID)
		{
			wareMap::iterator it = ShopMap.find(wareID);
			if (it == ShopMap.end())return warePtr();
			return it->second;
		}
		warePtr pawnWare(const int wareID)
		{
			wareMap::iterator it = PawnMap.find(wareID);
			if (it == PawnMap.end())return warePtr();
			return it->second;
		}
	};
	BOOSTSHAREPTR(CityData, cityPtr);
	UNORDERMAP(int, cityPtr, cityMap);
	static cityMap Cities;

	//����
	struct MapBox
	{
		unsigned LevelLimit;
		acPtrList BoxReward;
	};
	bool GreaterMapBox(const MapBox& left, const MapBox& right)
	{
		return left.LevelLimit > right.LevelLimit;
	}
	static vector<MapBox> SilverBox, GoldBox;

	//����
	struct Pirate
	{
		Pirate()
		{
			LevelLimit = 0;
			npcLevel = 0;
			battleValue = 0;
			background = -1;
			npcName = "bug";
			npcList.clear();
		}
		unsigned LevelLimit;
		unsigned npcLevel;
		int battleValue;
		int background;
		string npcName;
		int npcFace;
		struct armyNPC
		{
			armyNPC()
			{
				memset(this, 0x0, sizeof(armyNPC));
			}
			int npcID;
			bool holdMorale;
			int initAttri[characterNum];
			//int addAttri[characterNum];
			int armsType;
			double armsModule[armsModulesNum];
			int npcLevel;
			unsigned npcPos;
			int battleValue;
			int skill_1;
			int skill_2;
			BattleEquipList equipList;
		};
		vector< armyNPC > npcList;		//�����б�
		acPtrList rewardList;//�����б�
	};
	static bool less_pirate(const Pirate& left, const Pirate& right)
	{
		return left.LevelLimit > right.LevelLimit;
	}
	static vector<Pirate> PirateBox;


	//ÿ�յ�Ʊ���н���
	static Json::Value RichDayBoxes = Json::arrayValue;


	//·�����㷽��
	static WStar staticWStar;
	static bool setPlaceOK(const int x, const int y)
	{
		if ((unsigned)x < MapData.size())
		{
			vector< MapPoint >& yVec = MapData[x];
			if ((unsigned)y < yVec.size())
			{
				return yVec[y]._Available;
			}
		}
		return false;
	}


	//����boss�������
	const static unsigned SharkBossRateBase = 5000;
	const static unsigned SharkBossRateGrow = 2000;

	struct SharkBoss//�����
	{
		SharkBoss()
		{
			npcLevel = 0;
			battleValue = 0;
			background = -1;
			npcName = "bug";
			npcList.clear();
		}
		unsigned npcLevel;
		int battleValue;
		int background;
		string npcName;
		int npcFace;
		struct armyNPC
		{
			armyNPC()
			{
				memset(this, 0x0, sizeof(armyNPC) - sizeof(resist));
				resist.clear();
			}
			int npcID;
			bool holdMorale;
			int initAttri[characterNum];
			//int addAttri[characterNum];
			int armsType;
			double armsModule[armsModulesNum];
			int npcLevel;
			unsigned npcPos;
			int battleValue;
			int skill_1;
			int skill_2;
			BattleEquipList equipList;
			std::set<int> resist;
		};
		vector< armyNPC > npcList;		//�����б�
		acPtrList rewardList;//�����б�
	};

	static std::vector< SharkBoss > SharkBossList;

	static void clearSharkBox(
		const structTimer& timerData,
		boost::weak_ptr<SharkData> box
	)
	{
		ptrSharkData lock_data = box.lock();
		if (lock_data == currentShark && currentShark)
		{
			MapPoint& point = MapData[lock_data->_x][lock_data->_y];
			if (MapEvnet::shark_boss == point._Type)
			{
				point.setEvent(MapEvnet::null);
				point._relateArea->sendAroudNewEvent();
			}
		}
	}

	sBattlePtr npcShark(const SharkBoss& sk)
	{
		sBattlePtr sb = Creator<sideBattle>::Create();
		sb->playerID = -1;
		sb->playerName = sk.npcName;
		sb->isPlayer = false;
		sb->playerLevel = sk.npcLevel;
		sb->battleValue = sk.battleValue;
		sb->playerFace = sk.npcFace;
		manList& ml = sb->battleMan;
		ml.clear();
		const vector< SharkBoss::armyNPC >& npcList = sk.npcList;
		for (unsigned i = 0; i < npcList.size(); i++)
		{
			const SharkBoss::armyNPC& npc = npcList[i];
			mBattlePtr man = Creator<manBattle>::Create();
			man->manID = npc.npcID;
			man->holdMorale = npc.holdMorale;
			man->set_skill_1(npc.skill_1);
			man->set_skill_2(npc.skill_2);
			man->armsType = npc.armsType;
			man->manLevel = npc.npcLevel;
			man->currentIdx = npc.npcPos;
			man->battleValue = npc.battleValue;
			memcpy(man->armsModule, npc.armsModule, sizeof(man->armsModule));
			memcpy(man->initialAttri, npc.initAttri, sizeof(man->initialAttri));
			memcpy(man->battleAttri, npc.initAttri, sizeof(man->battleAttri));
			//memcpy(man->battleAttri, npc.addAttri, sizeof(man->battleAttri));
			man->currentHP = man->getTotalAttri(idx_hp);
			man->equipList = npc.equipList;
			man->resist = npc.resist;
			ml.push_back(man);
		}
		return sb;
	}

	static unsigned SharkBossRate = SharkBossRateBase;
	static unsigned SharkBossLevel = 0;

	void business::initData()
	{
		cout << "load business ..." << endl;
		{
			RichDayBoxes = Common::loadJsonFile("./instance/business/rich_day_boxes.json");
		};
		{
			std::map<unsigned, Pirate> tmpPirateBox;
			PirateBox.clear();
			Json::Value json = Common::loadJsonFile("./instance/business/pirate.json");
			for (unsigned i = 0; i < json.size(); ++i)
			{
				Json::Value& pirateJson = json[i];
				const unsigned llimit = pirateJson["limit"].asUInt();
				Pirate pi = tmpPirateBox[llimit];
				pi.LevelLimit = llimit;
				pi.npcName = pirateJson["name"].asString();
				pi.npcFace = pirateJson["face"].asInt();
				pi.npcLevel = pirateJson["level"].asUInt();
				pi.background = pirateJson.isMember("background") ? pirateJson["background"].asInt() : 1;
				pi.battleValue = pirateJson["battleValue"].asInt();
				vector< Pirate::armyNPC >& npcl = pi.npcList;
				for (unsigned n = 0; n < pirateJson["army"].size(); ++n)
				{
					Pirate::armyNPC npc;
					Json::Value& sg_npc = pirateJson["army"][n];
					npc.npcID = sg_npc["npcID"].asInt();
					npc.holdMorale = sg_npc["holdMorale"].asBool();
					for (unsigned cn = 0; cn < characterNum; ++cn)
					{
						npc.initAttri[cn] = sg_npc["initAttri"][cn].asInt();
						//npc.addAttri[cn] = sg_npc["addAttri"][cn].asInt();
					}
					npc.armsType = sg_npc["armsType"].asInt();
					for (unsigned cn = 0; cn < armsModulesNum; ++cn)
					{
						npc.armsModule[cn] = sg_npc["armsModule"][cn].asDouble();
					}
					npc.npcLevel = sg_npc["npcLevel"].asInt();
					npc.npcPos = sg_npc["npcPos"].asUInt() % 9;
					npc.battleValue = sg_npc["battleValue"].asInt();
					npc.skill_1 = sg_npc["skill_1"].asInt();
					npc.skill_2 = sg_npc["skill_2"].asInt();
					for (unsigned eq_idx = 0; eq_idx < sg_npc["equip"].size(); ++eq_idx)
					{
						npc.equipList.push_back(BattleEquip(sg_npc["equip"][eq_idx][0u].asUInt(),
							sg_npc["equip"][eq_idx][1u].asInt(),
							sg_npc["equip"][eq_idx][2u].asUInt()));
					}
					npcl.push_back(npc);
				}
				pi.rewardList = actionFormat(pirateJson["box"].asInt());
				tmpPirateBox[pi.LevelLimit] = pi;
			}
			for (std::map<unsigned, Pirate>::iterator it = tmpPirateBox.begin(); it != tmpPirateBox.end(); ++it)
			{
				PirateBox.push_back(it->second);
			}
			std::sort(PirateBox.begin(), PirateBox.end(), less_pirate);
		};//����
		{
			SilverBox.clear();
			Json::Value json = Common::loadJsonFile("./instance/business/silver_box.json");
			for (unsigned i = 0; i < json.size(); ++i)
			{
				Json::Value& boxJson = json[i];
				MapBox box;
				box.LevelLimit = boxJson["limit"].asUInt();
				// 				Json::Value& reward = boxJson["box"];
				// 				box.BoxReward = actionFormat(reward);
				const unsigned rewardID = boxJson["box"].asUInt();
				box.BoxReward = actionFormat(rewardID);
				SilverBox.push_back(box);
			}
			std::sort(SilverBox.begin(), SilverBox.end(), GreaterMapBox);
		};//������
		{
			GoldBox.clear();
			Json::Value json = Common::loadJsonFile("./instance/business/gold_box.json");
			for (unsigned i = 0; i < json.size(); ++i)
			{
				Json::Value& boxJson = json[i];
				MapBox box;
				box.LevelLimit = boxJson["limit"].asUInt();
				// 				Json::Value& reward = boxJson["box"];
				// 				box.BoxReward = actionFormat(reward);
				const unsigned rewardID = boxJson["box"].asUInt();
				box.BoxReward = actionFormat(rewardID);
				GoldBox.push_back(box);
			}
			std::sort(GoldBox.begin(), GoldBox.end(), GreaterMapBox);
		};//����
		{
			BuffDoMap[FangShuiID] = TBstruct(TradeBuff::fangshui, 30 * MINUTE);
			BuffDoMap[WeiSheID] = TBstruct(TradeBuff::weishe, 60 * MINUTE);
			BuffDoMap[YiJiaID] = TBstruct(TradeBuff::yijia, 30 * MINUTE);
		};//buff�¼�
		//��ʼ����ص������ļ�
		{
			playerTrade::initData();
		};
		{
			Common::createDirectories("./report/business/rich/");//����Ϣ
			Common::createDirectories("./report/business/city/");//������Ϣ
		};//�����ļ���
		{
			Json::Value json = Common::loadJsonFile("./instance/business/event.json");
			CityEventNum = json["city"].asUInt();
			MapHaiDaoEvent[0] = json["haidao"][0u].asUInt();
			MapHaiDaoEvent[1] = json["haidao"][1u].asUInt();
			MapSilverBoxEvent[0] = json["silver_box"][0u].asUInt();
			MapSilverBoxEvent[1] = json["silver_box"][1u].asUInt();
			MapSilverBoxEvent[0] = json["gold_box"][0u].asUInt();
			MapSilverBoxEvent[1] = json["gold_box"][1u].asUInt();
		};//�¼���ʼ��

		{
			MapData.clear();
			Json::Value json = Common::loadJsonFile("./instance/business/map.json");
			const unsigned data_length = json[0u].size() +
				(json[0u].size() % StanderX > 0 ? (StanderX - json[0u].size() % StanderX) : 0);
			const unsigned json_data_high = json.size();
			const unsigned data_high = json.size() +
				(json.size() % StanderY > 0 ? (StanderY - json.size() % StanderY) : 0);//
			//ע��������� Ҫ������������
			//����ͼ��������ΪStander�ı���
			for (unsigned y = 0; y < data_length; ++y)//����ոպ��������� ���ò���
			{
				vector< MapPoint > vec;
				for (unsigned x = json_data_high - 1; x < json_data_high; --x)
				{
					const bool pass = (json[x][y].asInt() != 0);
					vec.push_back(
						MapPoint(0, 0, MapEvnet::null, pass)
					);
				}
				for (unsigned repair = json_data_high; repair < data_high; repair++)
				{
					vec.push_back(
						MapPoint(0, 0, MapEvnet::null, false)
					);
				}
				MapData.push_back(vec);
			}

			//Ѱ·������ʼ��
			staticWStar.publicReach = boostBind(setPlaceOK, _1, _2);//��⺯��
			staticWStar.publicCorner = true;//����б������

			//������ʼ��
			std::set<WSTAR::Pos> staticShowShark;
			staticShowShark.clear();
			json = Common::loadJsonFile("./instance/business/shark.json");
			for (unsigned i = 0; i < json.size(); ++i)
			{
				Json::Value& cityJson = json[i];
				const unsigned spx = cityJson["x"].asUInt();
				const unsigned spy = cityJson["y"].asUInt();
				MapData[spx][spy]._Type = MapEvnet::shark;//���������
				staticShowShark.insert(WSTAR::Pos(spx, spy));


				//��������ƫ��
				const unsigned left_bottom_x = spx < 2 ? 0 : spx - 2;
				const unsigned left_bottom_y = spy < 2 ? 0 : spy - 2;

				//��������ƫ��
				const unsigned right_top_x = spx + 2 < data_length ? spx + 2 : spx;
				const unsigned right_top_y = spy + 2 < data_high ? spy + 2 : spy;

				for (unsigned x = left_bottom_x; x <= right_top_x; x++)
				{
					for (unsigned y = left_bottom_y; y <= right_top_y; y++)
					{
						staticShowShark.insert(WSTAR::Pos(x, y));
					}
				}
			}

			//�¼�����//��ͼ�������
			EventCoor.clear();
			for (unsigned x = 0; x < MapData.size(); ++x)
			{
				vector< MapPoint >& vec = MapData[x];
				for (unsigned y = 0; y < vec.size(); ++y)
				{
					MapPoint& point = vec[y];
					point._x = x;
					point._y = y;
					if (point._Available &&
						staticShowShark.find(WSTAR::Pos(x, y)) == staticShowShark.end())
						EventCoor.push_back(WSTAR::Pos(x, y));
				}
			}

			//������ͼ��������
			for (unsigned x = 0; x < MapData.size(); ++x)
			{
				vector< MapPoint >& vec = MapData[x];
				for (unsigned y = 0; y < vec.size(); ++y)
				{
					MapPoint& point = vec[y];
					const unsigned idx = x / StanderX + (y / StanderY) * (MapData.size() / StanderX);
					ptrAreaData ptr = Areas[idx];
					if (!ptr)
					{
						Areas[idx] = Creator<AreaData>::Create(
							idx,//���
							(x / StanderX) * StanderX,//����x
							(y / StanderY) * StanderY,//����y
							(x / StanderX) * StanderX + (x / StanderX) * StanderX + StanderX - 1,//����x
							(y / StanderY) * StanderY + (y / StanderY) * StanderY + StanderY - 1//����y
						);
						ptr = Areas[idx];
					}
					point._relateArea = ptr.get();
				}
			}

			//���������ϵ
			for (AreaMap::iterator it = Areas.begin(); it != Areas.end(); it++)
			{
				ptrAreaData ptr = it->second;
				ptr->bindAreaRelate();//�󶨹�ϵ, ����������
			}

			//���ó�����
			UsePos.clear();
			for (unsigned bron_x = 14; bron_x <= 29; bron_x++)
			{
				for (unsigned bron_y = 18; bron_y <= 24; bron_y++)
				{
					if (availablePlace(bron_x, bron_y))
					{
						UsePos.push_back(WSTAR::Pos(bron_x, bron_y));
					}
				}
			}

		};//��ͼ��Ϣ

		{
			CitiesRange.clear();
			Json::Value json = Common::loadJsonFile("./instance/business/city_range.json");
			for (unsigned i = 0; i < json.size(); ++i)
			{
				Json::Value& cityJson = json[i];
				AreaRange range;
				range.areaID = cityJson["cityID"].asInt();
				range.left_x = cityJson["left_x"].asUInt();
				range.left_y = cityJson["left_y"].asUInt();
				range.right_x = cityJson["right_x"].asUInt();
				range.right_y = cityJson["right_y"].asUInt();
				CitiesRange[range.areaID] = range;
			}
		};//��ͼ�������귶Χ

		{
			Json::Value json = Common::loadJsonFile("./instance/business/city.json");
			for (unsigned i = 0; i < json.size(); ++i)
			{
				Json::Value& city_json = json[i];
				cityPtr city = Creator<CityData>::Create();
				city->cityID = city_json["id"].asInt();
				for (unsigned n = 0; n < city_json["buy"].size(); ++n)
				{
					Json::Value& ware_json = city_json["buy"][n];
					CityData::warePtr ware = Creator<CityData::Wares>::Create();
					ware->wareID = ware_json["wareID"].asInt();
					ware->lowPrice = ware_json["lowPrice"].asInt();
					ware->upPrice = ware_json["upPrice"].asInt();
					ware->lowPriceF = ware_json["lowPriceF"].asInt();
					ware->upPriceF = ware_json["upPriceF"].asInt();
					city->ShopMap[ware->wareID] = ware;
				}
				for (unsigned n = 0; n < city_json["sale"].size(); ++n)
				{
					Json::Value& ware_json = city_json["sale"][n];
					CityData::warePtr ware = Creator<CityData::Wares>::Create();
					ware->wareID = ware_json["wareID"].asInt();
					ware->lowPrice = ware_json["lowPrice"].asInt();
					ware->upPrice = ware_json["upPrice"].asInt();
					ware->lowPriceF = ware_json["lowPriceF"].asInt();
					ware->upPriceF = ware_json["upPriceF"].asInt();
					city->PawnMap[ware->wareID] = ware;
				}
				Cities[city->cityID] = city;
			}
			for (cityMap::const_iterator it = Cities.begin(); it != Cities.end(); ++it)
			{
				cityIDList.push_back(it->first);
			}
			for (cityMap::iterator it = Cities.begin(); it != Cities.end(); ++it)
			{
				cityPtr city = it->second;
				const string file_name = "./report/business/city/" + Common::toString(it->first);
				Json::Value json = tradeFile.read_json(file_name);
				if (json.isNull())//�ļ�Ϊ��, ��ô�������ɼ۸�
				{
					qValue write_json(qJson::qj_object), buy_json(qJson::qj_array), sale_json(qJson::qj_array);
					for (CityData::wareMap::iterator wit = city->ShopMap.begin(); wit != city->ShopMap.end(); ++wit)
					{
						CityData::warePtr ware = wit->second;
						ware->price = Common::randomBetween(ware->lowPrice, ware->upPrice);
						ware->history.push_back(ware->price);
						buy_json.append(ware->toHisJson());
					}
					for (CityData::wareMap::iterator wit = city->PawnMap.begin(); wit != city->PawnMap.end(); ++wit)
					{
						CityData::warePtr ware = wit->second;
						ware->price = Common::randomBetween(ware->lowPrice, ware->upPrice);
						ware->history.push_back(ware->price);
						sale_json.append(ware->toHisJson());
					}
					write_json.addMember("b", buy_json);
					write_json.addMember("s", sale_json);
					tradeFile.write(file_name, write_json);
					continue;
				}
				for (unsigned i = 0; i < json["b"].size(); ++i)
				{
					Json::Value& item_json = json["b"][i];
					CityData::wareMap::iterator wit = city->ShopMap.find(item_json["id"].asInt());
					if (wit == city->ShopMap.end())continue;
					CityData::warePtr ware = wit->second;
					for (unsigned n = 0; n < item_json["p"].size(); ++n)
					{
						ware->history.push_back(item_json["p"][n].asInt());
					}
					ware->price = ware->history.back();
				}
				for (unsigned i = 0; i < json["s"].size(); ++i)
				{
					Json::Value& item_json = json["s"][i];
					CityData::wareMap::iterator wit = city->PawnMap.find(item_json["id"].asInt());
					if (wit == city->PawnMap.end())continue;
					CityData::warePtr ware = wit->second;
					for (unsigned n = 0; n < item_json["p"].size(); ++n)
					{
						ware->history.push_back(item_json["p"][n].asInt());
					}
					ware->price = ware->history.back();
				}
				for (CityData::wareMap::iterator wit = city->ShopMap.begin(); wit != city->ShopMap.end(); ++wit)
				{
					CityData::warePtr ware = wit->second;
					if (ware->history.empty())
					{
						ware->price = Common::randomBetween(ware->lowPrice, ware->upPrice);
						ware->history.push_back(ware->price);
					}
				}
				for (CityData::wareMap::iterator wit = city->PawnMap.begin(); wit != city->PawnMap.end(); ++wit)
				{
					CityData::warePtr ware = wit->second;
					if (ware->history.empty())
					{
						ware->price = Common::randomBetween(ware->lowPrice, ware->upPrice);
						ware->history.push_back(ware->price);
					}
				}
			}
		};//������Ϣ

		{
			//���յ�Ʊ
			{
				dayRich.clear();
				dayRichMap.clear();
				mongo::BSONObj key = BSON("key" << 1);
				mongo::BSONObj obj = db_mgr.FindOne(DBN::dbPlayerTradeRich, key);
				if (!obj.isEmpty())
				{
					vector<mongo::BSONElement> vec = obj["r"].Array();
					for (unsigned i = 0; i < vec.size(); ++i)
					{
						mongo::BSONElement& elem = vec[i];
						richPtr rich = Creator<richData>::Create();
						rich->playerID = elem["i"].Int();
						rich->playerName = elem["n"].String();
						rich->tradeTimes = (unsigned)elem["t"].Int();
						rich->money = elem["m"].Int();
						rich->kingdom = (Kingdom::NATION)elem["k"].Int();
						rich->createTime = elem["ct"].eoo() ? Common::gameTime() : elem["ct"].Int();
						dayRich.push_back(rich);
						dayRichMap[rich->playerID] = rich;
					}
				}
			};
			//��ʷ��Ʊ
			{
				historyRich.clear();
				historyRichMap.clear();
				mongo::BSONObj key = BSON("key" << 2);
				mongo::BSONObj obj = db_mgr.FindOne(DBN::dbPlayerTradeRich, key);
				if (!obj.isEmpty())
				{
					vector<mongo::BSONElement> vec = obj["r"].Array();
					for (unsigned i = 0; i < vec.size(); ++i)
					{
						mongo::BSONElement& elem = vec[i];
						richPtr rich = Creator<richData>::Create();
						rich->playerID = elem["i"].Int();
						rich->playerName = elem["n"].String();
						rich->tradeTimes = (unsigned)elem["t"].Int();
						rich->money = elem["m"].Int();
						rich->kingdom = (Kingdom::NATION)elem["k"].Int();
						rich->createTime = elem["ct"].eoo() ? Common::gameTime() : elem["ct"].Int();
						historyRich.push_back(rich);
						historyRichMap[rich->playerID] = rich;
					}
				}
			};
			//��ʷ�ܰ�
			{
				totalRich.clear();
				totalRichMap.clear();
				mongo::BSONObj key = BSON("key" << 3);
				mongo::BSONObj obj = db_mgr.FindOne(DBN::dbPlayerTradeRich, key);
				if (!obj.isEmpty())
				{
					vector<mongo::BSONElement> vec = obj["r"].Array();
					for (unsigned i = 0; i < vec.size(); ++i)
					{
						mongo::BSONElement& elem = vec[i];
						richPtr rich = Creator<richData>::Create();
						rich->playerID = elem["i"].Int();
						rich->playerName = elem["n"].String();
						rich->tradeTimes = (unsigned)elem["t"].Int();
						rich->money = elem["m"].Int();
						rich->kingdom = (Kingdom::NATION)elem["k"].Int();
						rich->createTime = elem["ct"].eoo() ? Common::gameTime() : elem["ct"].Int();
						totalRich.push_back(rich);
						totalRichMap[rich->playerID] = rich;
					}
				}
			};
			//timer
			{
				richTickTime = Common::timeZero(Common::gameTime()) + DAY;
				mongo::BSONObj key = BSON("key" << 4);
				mongo::BSONObj obj = db_mgr.FindOne(DBN::dbPlayerTradeRich, key);
				if (!obj.isEmpty())
				{
					richTickTime = (unsigned)obj["tt"].Int();
				}
				else
				{
					saveTimerRich();
				}
			};
		};//���������ݶ�ȡ//���ݿ�

		{//�������ݳ�ʼ��
			SharkBossList.clear();
			Json::Value json = Common::loadJsonFile("./instance/business/shark_boss.json");
			for (unsigned i = 0; i < json.size(); ++i)
			{
				Json::Value& sharkJson = json[i];
				SharkBoss sk;
				sk.npcName = sharkJson["name"].asString();
				sk.npcFace = sharkJson["face"].asInt();
				sk.npcLevel = sharkJson["level"].asUInt();
				sk.background = sharkJson.isMember("background") ? sharkJson["background"].asInt() : 1;
				sk.battleValue = sharkJson["battleValue"].asInt();
				vector< SharkBoss::armyNPC >& npcl = sk.npcList;
				for (unsigned n = 0; n < sharkJson["armys"].size(); ++n)
				{
					SharkBoss::armyNPC npc;
					Json::Value& sg_npc = sharkJson["armys"][n];
					npc.npcID = sg_npc["npcID"].asInt();
					npc.holdMorale = sg_npc["holdMorale"].asBool();
					for (unsigned cn = 0; cn < characterNum; ++cn)
					{
						npc.initAttri[cn] = sg_npc["initAttri"][cn].asInt();
						//npc.addAttri[cn] = sg_npc["addAttri"][cn].asInt();
					}
					npc.armsType = sg_npc["armsType"].asInt();
					for (unsigned cn = 0; cn < armsModulesNum; ++cn)
					{
						npc.armsModule[cn] = sg_npc["armsModule"][cn].asDouble();
					}
					npc.npcLevel = sg_npc["npcLevel"].asInt();
					npc.npcPos = sg_npc["npcPos"].asUInt() % 9;
					npc.battleValue = sg_npc["battleValue"].asInt();
					npc.skill_1 = sg_npc["skill_1"].asInt();
					npc.skill_2 = sg_npc["skill_2"].asInt();
					for (unsigned eq_idx = 0; eq_idx < sg_npc["equip"].size(); ++eq_idx)
					{
						npc.equipList.push_back(BattleEquip(sg_npc["equip"][eq_idx][0u].asUInt(),
							sg_npc["equip"][eq_idx][1u].asInt(),
							sg_npc["equip"][eq_idx][2u].asUInt()));
					}
					for (unsigned idx_resist = 0; idx_resist < sg_npc["resist"].size(); ++idx_resist)
					{
						npc.resist.insert(sg_npc["resist"][idx_resist].asInt());
					}
					npcl.push_back(npc);
				}
				sk.rewardList = actionFormat(sharkJson["box"].asInt());
				SharkBossList.push_back(sk);
			}

			mongo::BSONObj key = BSON("key" << 5);
			mongo::BSONObj obj = db_mgr.FindOne(DBN::dbPlayerTradeRich, key);
			if (!obj.isEmpty())
			{
				SharkBossRate = obj["ra"].Int();
				SharkBossLevel = obj["lv"].Int();
				if (SharkBossLevel >= SharkBossList.size())
				{
					SharkBossLevel = 0;
					saveSharkBoss();
				}
			}
			else
			{
				saveSharkBoss();
			}

			key = BSON("key" << 6);
			obj = db_mgr.FindOne(DBN::dbPlayerTradeRich, key);
			if (!obj.isEmpty())
			{
				currentShark = Creator<SharkData>::Create(obj["ct"].Int());
				currentShark->_shark = npcShark(SharkBossList[SharkBossLevel]);
				manList& checkMan = currentShark->_shark->battleMan;
				vector<mongo::BSONElement> vec = obj["hp"].Array();
				for (unsigned i = 0; i < checkMan.size() && i < vec.size(); i++)
				{
					checkMan[i]->currentHP = vec[i].Int();
					currentShark->_current_hp += checkMan[i]->currentHP;
					currentShark->_total_hp += checkMan[i]->getTotalAttri(idx_hp);
				}
				currentShark->_boxTime = obj["bt"].Int();
				currentShark->_hitTime = obj["ht"].Int();
				currentShark->_x = obj["ax"].Int();
				currentShark->_y = obj["ay"].Int();
			}
		};

		//�׳���ʱ��
		{
			const unsigned now = Common::gameTime();
			const tm tm_now = Common::toTm(now);
			const unsigned tick_price = now - tm_now.tm_sec - (tm_now.tm_min % 10) * MINUTE + 10 * MINUTE;
			Timer::AddEventPerTimeCT(boostBind(business::cityPriceTick, this, _1), Inter::event_city_price_timer, tick_price, 10 * MINUTE);
			const unsigned tick_city = now - tm_now.tm_sec - tm_now.tm_min * MINUTE + (tm_now.tm_min >= 30 ? MINUTE * 30 : 0);
			Timer::AddEventPerTimeCT(boostBind(business::cityEventTick, this, _1), Inter::event_city_event_timer, tick_city, 30 * MINUTE);
			const unsigned tick_event = now - tm_now.tm_sec - tm_now.tm_min * MINUTE + 1;
			Timer::AddEventTickTime(boostBind(business::mapEventTick, this, _1), Inter::event_map_event_timer, tick_event);
			const unsigned tick_day_rich = now - tm_now.tm_sec - tm_now.tm_min * MINUTE - 1;
			Timer::AddEventTickTime(boostBind(business::dayRichTick, this, _1), Inter::event_day_rich_hour_tick, tick_day_rich);//�����¼�
			Timer::AddEventTickTime(boostBind(business::richTick, this, _1), Inter::event_rich_event_timer, richTickTime);//�����¼�
		};//��ʱ���趨����
	}

	void business::cityPriceTick(const structTimer& timerData)
	{
		for (cityMap::iterator it = Cities.begin(); it != Cities.end(); ++it)
		{
			cityPtr city = it->second;
			const string file_name = "./report/business/city/" + Common::toString(it->first);
			qValue write_json(qJson::qj_object), buy_json(qJson::qj_array), sale_json(qJson::qj_array);
			for (CityData::wareMap::iterator wit = city->ShopMap.begin(); wit != city->ShopMap.end(); ++wit)
			{
				CityData::warePtr ware = wit->second;
				int alter_price = Common::randomBetween(ware->lowPriceF, ware->upPriceF);
				if (Common::randomOk(0.5))alter_price = -alter_price;
				int final_price = ware->price + alter_price;
				if (final_price <= ware->upPrice && final_price >= ware->lowPrice)
				{
					ware->price = final_price;
				}
				else
				{
					final_price = ware->price - alter_price;
					if (final_price <= ware->upPrice && final_price >= ware->lowPrice)
					{
						ware->price = final_price;
					}
					else
					{
						ware->price = Common::randomBetween(ware->lowPrice, ware->upPrice);
					}
				}
				ware->history.push_back(ware->price);
				if (ware->history.size() > 100)ware->history.erase(ware->history.begin());
				buy_json.append(ware->toHisJson());
			}
			for (CityData::wareMap::iterator wit = city->PawnMap.begin(); wit != city->PawnMap.end(); ++wit)
			{
				CityData::warePtr ware = wit->second;
				int alter_price = Common::randomBetween(ware->lowPriceF, ware->upPriceF);
				if (Common::randomOk(0.5))alter_price = -alter_price;
				int final_price = ware->price + alter_price;
				if (final_price <= ware->upPrice && final_price >= ware->lowPrice)
				{
					ware->price = final_price;
				}
				else
				{
					final_price = ware->price - alter_price;
					if (final_price <= ware->upPrice && final_price >= ware->lowPrice)
					{
						ware->price = final_price;
					}
					else
					{
						ware->price = Common::randomBetween(ware->lowPrice, ware->upPrice);
					}
				}
				ware->history.push_back(ware->price);
				if (ware->history.size() > 100)ware->history.erase(ware->history.begin());
				sale_json.append(ware->toHisJson());
			}
			write_json.addMember("b", buy_json);
			write_json.addMember("s", sale_json);
			tradeFile.async_write(file_name, write_json);
		}
	}

	const static int cityRate[4] = { -5, -3, 3, 5 };
	void business::cityEventTick(const structTimer& timerData)
	{
		cityEvnMap.clear();
		vector<int> vec = cityIDList;
		for (unsigned i = 0; i < CityEventNum; ++i)
		{
			if (vec.empty())continue;
			unsigned idx = (unsigned)Common::randomBetween(0, vec.size() - 1);
			cityEvnMap[vec[idx]] = cityRate[Common::randomBetween(0, 3)];
			vec.erase(vec.begin() + idx);
		}
	}

	void business::mapEventTick(const structTimer& timerData)
	{
		//����ֵ������ ��Լ��8 * 5,  ��ô���� max_x - 4 >= x >= 4  max_y - 3 >= y >= 3 ��Χ��Ҫ�����õ�
		vector<MapPoint> EventList;
		std::set<WSTAR::Pos> filterList;
		random_shuffle(EventCoor.begin(), EventCoor.end());//
		const unsigned now = Common::gameTime();
		const tm tm_now = Common::toTm(now);

		const unsigned shark_tick = now - tm_now.tm_min * MINUTE - tm_now.tm_sec;
		if (currentShark && currentShark->_createTick == shark_tick)//�����ǰ���¼�ID == Ԥ�����ɵ��¼�ID, ��ô
		{
			if (currentShark->_boxTime > now)
			{
				for (int x = currentShark->_x - 3; x <= currentShark->_x + 3; x++)
				{
					for (int y = currentShark->_y - 2; y <= currentShark->_y + 2; y++)
					{
						if (setPlaceOK(x, y))
						{
							filterList.insert(WSTAR::Pos(x, y));
							continue;
						}
						filterList.clear();
						goto __NOVAILDINITDATA__;
					}
				}
				
				EventList.push_back(MapPoint(currentShark->_x, currentShark->_y, MapEvnet::shark_boss_chest));
				Timer::AddEventTickTime(
					boostBind(clearSharkBox, _1, currentShark),
					Inter::event_clear_shark_chest_timer,
					currentShark->_boxTime
				);

			__NOVAILDINITDATA__:
				;
			}
			else if(!currentShark->_shark->isDeadAll())
			{
				filterList.insert(WSTAR::Pos(currentShark->_x, currentShark->_y));
				EventList.push_back(MapPoint(currentShark->_x, currentShark->_y, MapEvnet::shark_boss));
			}
		}
		else
		{
			if (tm_now.tm_hour >= 12 && tm_now.tm_hour <= 18)//ÿ��12�㵽18��֮��
			{
				if (Common::randomOk((int)SharkBossRate))
				{
					SharkBossRate = SharkBossRateBase;//��ʼֵ
					for (unsigned i = 0; i < EventCoor.size(); ++i)
					{
						const WSTAR::Pos& coor = EventCoor[i];
						filterList.clear();
						for (int x = coor.x - 3; x <= coor.x + 3; x++)
						{
							for (int y = coor.y - 2; y <= coor.y + 2; y++)
							{
								if (!setPlaceOK(x, y))
								{
									goto __NOACCESSPOS__;
								}
								filterList.insert(WSTAR::Pos(x, y));
							}
						}

						EventList.push_back(MapPoint(coor.x, coor.y, MapEvnet::shark_boss));
						break;

					__NOACCESSPOS__:
						continue;
					}
				}
				else
				{
					SharkBossRate += SharkBossRateGrow;
				}
				saveSharkBoss();
			}
		}

		//�����¼�
		const unsigned pirate_num = Common::randomBetween(MapHaiDaoEvent[0], MapHaiDaoEvent[1]);
		const unsigned silver_box_num = Common::randomBetween(MapSilverBoxEvent[0], MapSilverBoxEvent[1]);
		const unsigned gold_box_num = Common::randomBetween(MapGoldBoxEvent[0], MapGoldBoxEvent[1]);
		unsigned begin_idx = 0;
		unsigned num = 0;
		for (unsigned i = begin_idx; i < EventCoor.size() && num < pirate_num; ++i)
		{
			const WSTAR::Pos& coor = EventCoor[i];
			if (filterList.find(coor) != filterList.end())continue;
			++num;
			EventList.push_back(MapPoint(coor.x, coor.y, MapEvnet::haidao));
		}
		begin_idx += pirate_num;
		num = 0;
		for (unsigned i = begin_idx; i < EventCoor.size() && num < silver_box_num; ++i)
		{
			const WSTAR::Pos& coor = EventCoor[i];
			if (filterList.find(coor) != filterList.end())continue;
			++num;
			EventList.push_back(MapPoint(coor.x, coor.y, MapEvnet::silver_box));
		}
		begin_idx += silver_box_num;
		num = 0;
		for (unsigned i = begin_idx; i < EventCoor.size() && num < gold_box_num; ++i)
		{
			const WSTAR::Pos& coor = EventCoor[i];
			if (filterList.find(coor) != filterList.end())continue;
			++num;
			EventList.push_back(MapPoint(coor.x, coor.y, MapEvnet::gold_box));
		}
		begin_idx += gold_box_num;
		num = 0;


		for (AreaMap::iterator it = Areas.begin(); it != Areas.end(); it++)
		{
			ptrAreaData ptr = it->second;
			ptr->clearEvent();
		}
		for (unsigned i = 0; i < EventList.size(); i++)
		{
			const MapPoint& point = EventList[i];
			MapData[point._x][point._y].setEvent(point._Type);
			if (point._Type == MapEvnet::shark_boss)
			{
				currentShark = Creator<SharkData>::Create(shark_tick);
				currentShark->_shark = npcShark(SharkBossList[SharkBossLevel]);//�����µ����㲢�ҹ㲥
				currentShark->_x = point._x;
				currentShark->_y = point._y;
				const manList& checkMan = currentShark->_shark->battleMan;
				for (unsigned i = 0; i < checkMan.size(); i++)
				{
					currentShark->_total_hp += checkMan[i]->getTotalAttri(idx_hp);
				}
				currentShark->_current_hp = currentShark->_total_hp;
				saveSharkState();//����״̬
				qValue json(qJson::qj_array);
				chat_sys.despatchAll(CHAT::server_business_shark_boss_appear, json);
			}
		}
		//������ó�׵��������һ������
		for (AreaMap::iterator it = Areas.begin(); it != Areas.end(); it++)
		{
			ptrAreaData ptr = it->second;
			ptr->sendAroudNewEvent();
		}

		const unsigned tick_event = now - tm_now.tm_sec - tm_now.tm_min * MINUTE + 1 + HOUR;
		Timer::AddEventTickTime(boostBind(business::mapEventTick, this, _1), Inter::event_map_event_timer, tick_event);
	}

	int business::cityPriceRate(const int cityID)
	{
		boost::unordered_map<int, int>::iterator it = cityEvnMap.find(cityID);
		if (it == cityEvnMap.end())return 0;
		return it->second;
	}

	bool richGreator(richPtr left, richPtr right)
	{
		if (left->money != right->money)return left->money > right->money;
		if (left->tradeTimes != right->tradeTimes)return left->tradeTimes < right->tradeTimes;
		if (left->createTime != right->createTime)return left->createTime < right->createTime;
		return left->playerID < right->playerID;
	}

	void business::updateName(playerDataPtr player)
	{
		{
			richMap::iterator it = dayRichMap.find(player->ID());
			if (it != dayRichMap.end())
			{
				richPtr rich = it->second;
				rich->playerName = player->Name();
				saveDayRich();
			}
		};
		{
			richMap::iterator it = historyRichMap.find(player->ID());
			if (it != historyRichMap.end())
			{
				richPtr rich = it->second;
				rich->playerName = player->Name();
				saveHistoryRich();
			}
		};
		{
			richMap::iterator it = totalRichMap.find(player->ID());
			if (it != totalRichMap.end())
			{
				richPtr rich = it->second;
				rich->playerName = player->Name();
				saveTotalRich();
			}
		};
		{
			_info_ptr info = getBRPlayer(player->ID());
			if (info)info->playerName = player->Name();
		};
	}

	void business::insertDayRich(playerDataPtr player, const int money)
	{
		//����
		richMap::iterator it = dayRichMap.find(player->ID());
		if (it != dayRichMap.end())
		{
			richPtr rich = it->second;
			if (rich->money < money)
			{
				rich->money = money;
				rich->tradeTimes = 0;
				rich->createTime = Common::gameTime();
				std::sort(dayRich.begin(), dayRich.end(), richGreator);
				saveDayRich();
			}//�����˲�������ļ�ֵ
			return;
		}

		//����
		richPtr rich = Creator<richData>::Create(player, money);
		rich->tradeTimes = 0;
		if (dayRich.size() < 50)
		{
			dayRich.push_back(rich);
			dayRichMap[rich->playerID] = rich;
			std::sort(dayRich.begin(), dayRich.end(), richGreator);
			saveDayRich();
			return;
		}

		//�������
		richPtr back_rich = dayRich.back();
		if (richGreator(rich, back_rich))
		{
			dayRich.pop_back();
			dayRichMap.erase(back_rich->playerID);
			dayRich.push_back(rich);
			dayRichMap[rich->playerID] = rich;
			std::sort(dayRich.begin(), dayRich.end(), richGreator);
			saveDayRich();
			return;
		}
	}

	void business::insertHisRich(playerDataPtr player, const int money)
	{
		//����
		richMap::iterator it = historyRichMap.find(player->ID());
		if (it != historyRichMap.end())
		{
			richPtr rich = it->second;
			if (rich->money < money)
			{
				rich->money = money;
				rich->tradeTimes = 0;
				rich->createTime = Common::gameTime();
				std::sort(historyRich.begin(), historyRich.end(), richGreator);
				saveHistoryRich();
			}//�����˲�������ļ�ֵ
			return;
		}

		//����
		richPtr rich = Creator<richData>::Create(player, money);
		rich->tradeTimes = 0;
		if (historyRich.size() < 50)
		{
			historyRich.push_back(rich);
			historyRichMap[rich->playerID] = rich;
			std::sort(historyRich.begin(), historyRich.end(), richGreator);
			saveHistoryRich();
			return;
		}

		//�������
		richPtr back_rich = historyRich.back();
		if (richGreator(rich, back_rich))
		{
			historyRich.pop_back();
			historyRichMap.erase(back_rich->playerID);
			historyRich.push_back(rich);
			historyRichMap[rich->playerID] = rich;
			std::sort(historyRich.begin(), historyRich.end(), richGreator);
			saveHistoryRich();
			return;
		}
	}

	void business::insertTotalRich(playerDataPtr player, const int money)
	{
		//����
		richMap::iterator it = totalRichMap.find(player->ID());
		if (it != totalRichMap.end())
		{
			richPtr rich = it->second;
			if (rich->money < money || player->Trade().totalTask() > rich->tradeTimes)
			{
				rich->money = money;
				rich->tradeTimes = player->Trade().totalTask();
				rich->createTime = Common::gameTime();
				std::sort(totalRich.begin(), totalRich.end(), richGreator);
				saveTotalRich();
			}//�����˲�������ļ�ֵ
			return;
		}

		//����
		richPtr rich = Creator<richData>::Create(player, money);
		if (dayRich.size() < 50)
		{
			totalRich.push_back(rich);
			totalRichMap[rich->playerID] = rich;
			std::sort(totalRich.begin(), totalRich.end(), richGreator);
			saveTotalRich();
			return;
		}

		//�������
		richPtr back_rich = totalRich.back();
		if (richGreator(rich, back_rich))
		{
			totalRich.pop_back();
			totalRichMap.erase(back_rich->playerID);
			totalRich.push_back(rich);
			totalRichMap[rich->playerID] = rich;
			std::sort(totalRich.begin(), totalRich.end(), richGreator);
			saveTotalRich();
			return;
		}
	}

	void business::saveDayRich()
	{
		mongo::BSONObj key = BSON("key" << 1);
		mongo::BSONArrayBuilder arr;
		for (unsigned i = 0; i < dayRich.size(); ++i)
		{
			arr << dayRich[i]->toBSON();
		}
		mongo::BSONObj obj = BSON("key" << 1 << "r" << arr.arr());
		db_mgr.SaveMongo(DBN::dbPlayerTradeRich, key, obj);
	}

	void business::saveHistoryRich()
	{
		mongo::BSONObj key = BSON("key" << 2);
		mongo::BSONArrayBuilder arr;
		for (unsigned i = 0; i < historyRich.size(); ++i)
		{
			arr << historyRich[i]->toBSON();
		}
		mongo::BSONObj obj = BSON("key" << 2 << "r" << arr.arr());
		db_mgr.SaveMongo(DBN::dbPlayerTradeRich, key, obj);
	}

	void business::saveTotalRich()
	{
		mongo::BSONObj key = BSON("key" << 3);
		mongo::BSONArrayBuilder arr;
		for (unsigned i = 0; i < totalRich.size(); ++i)
		{
			arr << totalRich[i]->toBSON();
		}
		mongo::BSONObj obj = BSON("key" << 3 << "r" << arr.arr());
		db_mgr.SaveMongo(DBN::dbPlayerTradeRich, key, obj);
	}

	void business::saveTimerRich()
	{
		mongo::BSONObj key = BSON("key" << 4);
		mongo::BSONObj obj = BSON("key" << 4 << "tt" << richTickTime);
		db_mgr.SaveMongo(DBN::dbPlayerTradeRich, key, obj);
	}

	void business::saveSharkBoss()
	{
		mongo::BSONObj key = BSON("key" << 5);
		mongo::BSONObj obj = BSON("key" << 5 << "ra" << SharkBossRate << "lv" << SharkBossLevel);
		db_mgr.SaveMongo(DBN::dbPlayerTradeRich, key, obj);
	}

	void business::saveSharkState()
	{
		if (currentShark)
		{
			mongo::BSONObj key = BSON("key" << 6);
			mongo::BSONArrayBuilder arr;
			const manList& checkMan = currentShark->_shark->battleMan;
			for (unsigned i = 0; i < checkMan.size(); i++)
			{
				arr << checkMan[i]->currentHP;
			}
			mongo::BSONObj obj = BSON(
				"key" << 6 << "ct" << currentShark->_createTick << "ht" <<
				currentShark->_hitTime << "bt" << currentShark->_boxTime << "ax" << currentShark->_x
				<< "ay" << currentShark->_y << "hp" << arr.arr()
			);
			db_mgr.SaveMongo(DBN::dbPlayerTradeRich, key, obj);
		}
	}

	void business::dayRichTick(const structTimer& timerData)
	{
		{
			qValue data_json(qJson::qj_array);//ˢ�°�
			for (unsigned i = 0; i < dayRich.size(); ++i)
			{
				richPtr rich = dayRich[i];
				qValue sg_json(qJson::qj_array);
				sg_json.append(rich->playerID).append(rich->playerName).append(rich->kingdom).append(rich->tradeTimes).append(rich->money);
				data_json.append(sg_json);
			}
			tradeFile.async_write("./report/business/rich/day", data_json);
		};//���յ�Ʊ

		const unsigned now = Common::gameTime();
		const tm tm_now = Common::toTm(now);
		const unsigned tick_day_rich = now - tm_now.tm_sec - tm_now.tm_min * MINUTE - 1 + HOUR;
		Timer::AddEventTickTime(boostBind(business::dayRichTick, this, _1), Inter::event_day_rich_hour_tick, tick_day_rich);//�����¼�
	}

	void business::richTick(const structTimer& timerData)
	{
		{
			qValue data_json(qJson::qj_array);
			for (unsigned i = 0; i < dayRich.size(); ++i)
			{
				if (RichDayBoxes.size() <= i)break;

				//�ʼ����ݣ� �װ���XXXX�������������������ó���л����ѵ�Ʊ����ΪA��������������õĽ������渽�����ţ���ע����գ�������������
				richPtr rich = dayRich[i];
				Json::Value p_json;
				p_json.append(rich->playerName);
				p_json.append(i + 1);
				Json::Value rw_json = jsonFormats2c(RichDayBoxes[i]);
				EmailPtr email_ptr = email_sys.createPackage(EmailDef::RichDayEmailReward, p_json, rw_json);
				email_sys.sendToPlayer(rich->playerID, email_ptr);
			}
			dayRich.clear();
			dayRichMap.clear();
			saveDayRich();
		};//���յ�Ʊ
		{
			qValue data_json(qJson::qj_array);
			for (unsigned i = 0; i < historyRich.size(); ++i)
			{
				richPtr rich = historyRich[i];
				Log(DBLOG::strLogTradeRank, 1, rich->playerID, rich->playerName, i + 1, rich->tradeTimes, rich->money);
				qValue sg_json(qJson::qj_array);
				sg_json.append(rich->playerID).append(rich->playerName).append(rich->kingdom).append(rich->tradeTimes).append(rich->money);
				data_json.append(sg_json);
			}
			tradeFile.async_write("./report/business/rich/history", data_json);
		};//��ʷ��Ʊ
		{
			qValue data_json(qJson::qj_array);
			for (unsigned i = 0; i < totalRich.size(); ++i)
			{
				richPtr rich = totalRich[i];
				Log(DBLOG::strLogTradeRank, 2, rich->playerID, rich->playerName, i + 1, rich->tradeTimes, rich->money);
				qValue sg_json(qJson::qj_array);
				sg_json.append(rich->playerID).append(rich->playerName).append(rich->kingdom).append(rich->tradeTimes).append(rich->money);
				data_json.append(sg_json);
			}
			tradeFile.async_write("./report/business/rich/total", data_json);
		};//��ʷ����
		//д���¸�richд���ʱ��
		richTickTime += DAY;
		saveTimerRich();
		Timer::AddEventTickTime(boostBind(business::richTick, this, _1), Inter::event_rich_event_timer, richTickTime);//�����¼�
	}

	void business::playerOFFLine(const int playerID)
	{
		_info_ptr info = getBRPlayer(playerID);
		if (info)
		{
			AreaData* current_area = MapData[info->cpos_x][info->cpos_y]._relateArea;
			current_area->removePlayer(playerID);
			_brPlayers.erase(playerID);//ɾ������
		}
	}

	bool business::inSharkArea(const int x, const int y)
	{
		if ((unsigned)x < MapData.size())
		{
			vector< MapPoint >& yVec = MapData[x];
			if ((unsigned)y < yVec.size())
			{
				return yVec[y]._Type == MapEvnet::shark;
			}
		}
		return false;
	}

	WSTAR::Pos business::getAvailablePos()
	{
		return UsePos[Common::randomBetween(0, UsePos.size() - 1)];
	}

	bool business::availablePlace(const int x, const int y)
	{
		return setPlaceOK(x, y);
	}

	void business::update_car(net::Msg& m, Json::Value& r)
	{
		playerDataPtr player = player_mgr.getPlayer(m.playerID);
		if (!player)Return(r, err_illedge);
		r[strMsg][1u] = player->CarPos().currentX();
		r[strMsg][2u] = player->CarPos().currentY();
		Return(r, res_sucess);
	}

	void business::update_base(net::Msg& m, Json::Value& r)
	{
		playerDataPtr player = player_mgr.getPlayer(m.playerID);
		if (!player)Return(r, err_illedge);
		player->Trade().updateBase();
	}
	void business::update_ware(net::Msg& m, Json::Value& r)
	{
		playerDataPtr player = player_mgr.getPlayer(m.playerID);
		if (!player)Return(r, err_illedge);
		player->Trade().updateWare();
	}
	void business::update_buff(net::Msg& m, Json::Value& r)
	{
		playerDataPtr player = player_mgr.getPlayer(m.playerID);
		if (!player)Return(r, err_illedge);
		player->Trade().updateBuff();
	}

	void business::update_move(net::Msg& m, Json::Value& r)
	{
		playerDataPtr player = player_mgr.getPlayer(m.playerID);
		if (!player)Return(r, err_illedge);
		if (player->LV() < systemUseLimit)Return(r, err_player_lv_too_low);
		if ((boost::get_system_time() - player->CarMoveCD).total_milliseconds() < 250)Return(r, err_car_move_too_fast);
		player->CarMoveCD = boost::get_system_time();
		ReadJsonArray;
		unsigned sucess_num = 0;
		//player->CarPos().stopMove();
		const int start_x = js_msg[0u][0u].asInt();
		const int start_y = js_msg[0u][1u].asInt();
		WSTAR::Pos start_pos = WSTAR::Pos(start_x, start_y);// player->CarPos().aimXY();
		if (!player->CarPos().canSetStartPos(start_pos))
		{
			r[strMsg][1u] = player->CarPos().currentX();
			r[strMsg][2u] = player->CarPos().currentY();
			r[strMsg][3u] = player->CarPos().aimX();
			r[strMsg][4u] = player->CarPos().aimY();
			Return(r, err_car_move_too_far);
		}
		std::vector<WSTAR::Pos> new_route;
		for (unsigned i = 1; i < 6 && i < js_msg.size(); i++)
		{
			const int aim_x = js_msg[i][0u].asInt();
			const int aim_y = js_msg[i][1u].asInt();
			staticWStar.publicStart = start_pos;
			staticWStar.publicEnd = WSTAR::Pos(aim_x, aim_y);
			std::vector<WSTAR::Pos> vec = staticWStar.find();
			if (vec.empty())break;
			new_route.insert(new_route.end(), vec.begin(), vec.end());
			++sucess_num;
			start_pos.x = aim_x;
			start_pos.y = aim_y;
		}
		if (sucess_num > 0)
		{
			player->CarPos().newRoute(WSTAR::Pos(start_x, start_y), new_route);
		}
		if (sucess_num < 1)Return(r, err_car_move_forbidden);
		r[strMsg][0u] = res_sucess;
		r[strMsg][1u] = player->CarPos().currentX();
		r[strMsg][2u] = player->CarPos().currentY();
		r[strMsg][3u] = player->CarPos().aimX();
		r[strMsg][4u] = player->CarPos().aimY();
		player->sendToClient(gate_client::player_car_move_update_resp, r);
		r = Json::nullValue;
		player->CarPos().sendFuturePos();
	}

	void business::end_move(net::Msg& m, Json::Value& r)
	{
		playerDataPtr player = player_mgr.getPlayer(m.playerID);
		if (!player)Return(r, err_illedge);
		if (player->LV() < systemUseLimit)Return(r, err_player_lv_too_low);
		player->CarPos().stopMove();
		r[strMsg][1u] = player->CarPos().currentX();
		r[strMsg][2u] = player->CarPos().currentY();
		Return(r, res_sucess);
	}

	const static int taskBegin[3] = { 120000, 80000, 60000 };
	const static int taskEnd[3] = { 240000, 160000, 120000 };
	void business::accept_task(net::Msg& m, Json::Value& r)
	{
		playerDataPtr player = player_mgr.getPlayer(m.playerID);
		if (!player)Return(r, err_illedge);
		if (player->LV() < systemUseLimit)Return(r, err_player_lv_too_low);
		if (player->Info().Nation() == Kingdom::null)Return(r, err_illedge);
		if (player->Trade().taskType() != TradeType::null)Return(r, err_illedge);
		if (player->Trade().taskTimes() >= 5)Return(r, err_trade_task_over_times);
		const unsigned playerLV = player->LV();
		int bg_num = 0;
		int ed_num = 0;
		if (playerLV > 80) { bg_num = taskBegin[0]; ed_num = taskEnd[0]; }
		else if (playerLV > 60) { bg_num = taskBegin[1]; ed_num = taskEnd[1]; }
		else if (playerLV > 30) { bg_num = taskBegin[2]; ed_num = taskEnd[2]; }
		else Return(r, err_illedge);
		player->Trade().acceptTask(bg_num, ed_num);
		Log(DBLOG::strLogBusiness, player, 0, bg_num, ed_num);
		Return(r, res_sucess);
	}

	void business::money_show(net::Msg& m, Json::Value& r)
	{
		playerDataPtr player = player_mgr.getPlayer(m.playerID);
		if (!player)Return(r, err_illedge);
		if (player->LV() < systemUseLimit)Return(r, err_player_lv_too_low);
		if (player->Trade().taskType() == TradeType::null)Return(r, err_illedge);
		unsigned now = Common::gameTime();
		if (player->BusinessCD > now)Return(r, err_business_show_cd_limit);
		player->BusinessCD = now + 60;//60s
		Json::Value chatJson = Json::arrayValue;
		chatJson.append(chat_sys.ChatPackage(player));
		chatJson.append(player->Trade().getMoney());
		chatJson.append(player->Trade().getComplete());
		chat_sys.despatchAll(CHAT::server_business_money, chatJson);
		Return(r, res_sucess);
	}

	void business::sence_enter(net::Msg& m, Json::Value& r)
	{
		playerDataPtr player = player_mgr.getPlayer(m.playerID);
		if (!player)Return(r, err_illedge);

		_info_ptr info = getBRPlayer(player->ID());
		if (!info)
		{
			info = _info::Create(player);
		}
		else
		{
			if (info->state != car_enter)
			{
				info->state = car_enter;
				info->sendAround(player);
				if (false == info->been_post)
				{
					info->been_post = true;
					Timer::AddEventTickTime(boostBind(PlayerAreaUpdate, _1, info), Inter::event_trade_area_timer, info->updateCD);
				}
			}
		}
		Return(r, res_sucess);
	}

	void business::sence_exit(net::Msg& m, Json::Value& r)
	{
		playerDataPtr player = player_mgr.getPlayer(m.playerID);
		if (!player)Return(r, err_illedge);

		_info_ptr info = getBRPlayer(player->ID());
		if (info)
		{
			info->state = car_exit;
		}
		Return(r, res_sucess);
	}

	static bool RefreshSharkCanPost = true;
	void business::RefreshShark(const int x, const int y)
	{
		MapPoint& point = MapData[x][y];
		point._relateArea->sendAroudNewEvent();
		business_sys.saveSharkState();
		RefreshSharkCanPost = true;
	}

	void business::needSaveSharkState()
	{
		if (!RefreshSharkCanPost)
		{
			saveSharkState();
		}
	}

	void business::hit_shark_boss(net::Msg& m, Json::Value& r)
	{
		playerDataPtr player = player_mgr.getPlayer(m.playerID);
		if (!player)Return(r, err_illedge);
		if (player->LV() < systemUseLimit)Return(r, err_player_lv_too_low);
		if (player->Info().Nation() == Kingdom::null)Return(r, err_illedge);
		if (!currentShark)Return(r, err_no_found_shark_boss);
		const unsigned now = Common::gameTime();
		if (player->Trade().sharkCD() > now)Return(r, err_shark_boss_in_cd);
		player->CarPos().stopMove();
		const int x = player->CarPos().currentX();
		const int y = player->CarPos().currentY();
		ReadJsonArray;
		const int ax = js_msg[0u].asUInt();
		const int ay = js_msg[1u].asUInt();
		const MapEvnet::Type type = getMapEvent(ax, ay);
		if (type != MapEvnet::shark_boss)Return(r, err_no_found_shark_boss);
		if (std::abs(ax - x) > 3 || std::abs((ay - y) > 2))Return(r, err_illedge);
		sBattlePtr atk = BattleHelp::WarPlayer(player);
		BattleReport reportData;
		const O2ORes res = reportData.One2One(atk, currentShark->_shark, typeBattle::trade_shark);
		reportData.addNotice(player->ID());
		const SharkBoss& sk = SharkBossList[SharkBossLevel];
		reportData.addReportdeclare("bg", sk.background);
		Json::Value me_json;
		unsigned total_me = BattleHelp::AddManExp(player, 0, me_json);
		reportData.addReportdeclare("me", me_json);
		Json::Value playerJson;
		playerJson.append(player->LV());
		playerJson.append(player->Info().EXP());
		playerJson.append(player->LV());
		playerJson.append(player->Info().EXP());
		playerJson.append(0);
		playerJson.append(player->Info().isMaxLevel());
		reportData.addReportdeclare("plv", playerJson);
		reportData.Done(typeBattle::trade_shark);
		r[strMsg][1u] = res.res;
		if (0 == currentShark->_hitTime)
		{
			//�״ι���
			currentShark->_hitTime = now;
			//�״ι����㲥
			qValue json(qJson::qj_array);
			json.append(chat_sys.ChatPackageQ(player));
			json.append(100);
			chat_sys.despatchAll(CHAT::server_business_shark_boss_first_hit, json);
			player->Res().alterTicket(100);//��100Ԫ��
		}
		if (currentShark->_shark->isDeadAll())
		{
			MapPoint& point = MapData[ax][ay];
			point.setEvent(MapEvnet::shark_boss_chest);
			currentShark->_boxTime = now + 10 * MINUTE > currentShark->_createTick + HOUR ? currentShark->_createTick + HOUR : now + 10 * MINUTE;
			Timer::AddEventTickTime(
				boostBind(clearSharkBox, _1, currentShark),
				Inter::event_clear_shark_chest_timer,
				currentShark->_boxTime
			);
			//�㲥
			qValue json(qJson::qj_array);
			chat_sys.despatchAll(CHAT::server_business_shark_boss_defeat, json);

			point._relateArea->sendAroudNewEvent();

			unsigned offset = 0;
			bool is_not_plus = false;
			const unsigned pass_time = now - currentShark->_hitTime;
			if (pass_time <= 3 * MINUTE)offset = 2;
			else if (pass_time <= 5 * MINUTE)offset = 1;
			else if (pass_time > 10 * MINUTE) { offset = -2; is_not_plus = true; }
			SharkBossLevel += offset;
			if (SharkBossLevel >= SharkBossList.size())SharkBossLevel = is_not_plus ? 0 : SharkBossList.size() - 1;
			saveSharkBoss();
			saveSharkState();//����֮�󱣴�һ��
		}
		else
		{
			const manList& checkMan = currentShark->_shark->battleMan;
			currentShark->_current_hp = 0;
			for (unsigned i = 0; i < checkMan.size(); i++)
			{
				currentShark->_current_hp += checkMan[i]->currentHP;
			}
			if (RefreshSharkCanPost)
			{
				RefreshSharkCanPost = false;
				::Timer::AddEventSeconds(boostBind(business::RefreshShark, ax, ay), Inter::event_system_common_recall, 3);
			}
		}
		player->Trade().nextSharkCD();
		Return(r, res_sucess);
	}

	void business::reward_shark_boss(net::Msg& m, Json::Value& r)
	{
		playerDataPtr player = player_mgr.getPlayer(m.playerID);
		if (!player)Return(r, err_illedge);
		if (player->LV() < systemUseLimit)Return(r, err_player_lv_too_low);
		if (player->Info().Nation() == Kingdom::null)Return(r, err_illedge);
		player->CarPos().stopMove();
		if (!currentShark)Return(r, err_shark_chest_no_found);
		if (!player->Trade().canSharkBox(currentShark->_createTick))Return(r, err_shark_chest_been_get);
		if (player->Trade().isOverSharkBox())Return(r, err_shark_chest_been_over);
		const int x = player->CarPos().currentX();
		const int y = player->CarPos().currentY();
		ReadJsonArray;
		const int ax = js_msg[0u].asUInt();
		const int ay = js_msg[1u].asUInt();
		const MapEvnet::Type type = getMapEvent(ax, ay);
		if (type != MapEvnet::shark_boss_chest)Return(r, err_shark_chest_no_found);
		if (std::abs(ax - x) > 3 || std::abs(ay - y) > 2)Return(r, err_illedge);
		actionDo(player, SharkBossList[SharkBossLevel].rewardList, 1);
		r[strMsg][1u] = actionRes();
		player->Trade().tickSharkBox(currentShark->_createTick);
		Log(DBLOG::strLogBusiness, player, 8, player->Trade().sharkBoxSize(), "", "", "", "", "", "", r[strMsg][1u].toIndentString());
		Return(r, res_sucess);
	}

	void business::route_data(net::Msg& m, Json::Value& r)
	{
		playerDataPtr player = player_mgr.getPlayer(m.playerID);
		if (!player)Return(r, err_illedge);
		if (player->LV() < systemUseLimit)Return(r, err_player_lv_too_low);
		//player->CarPos().sendRoute();
		player->CarPos().resetFuture();
		WSTAR::Pos pos = player->CarPos().currentXY();
		r[strMsg][0u] = res_sucess;
		r[strMsg][1u] = pos.x;
		r[strMsg][2u] = pos.y;
		r[strMsg][3u] = player->Trade().getSpeed();
		player->sendToClient(gate_client::player_car_route_data_resp, r);
		r = Json::nullValue;
		player->CarPos().sendFuturePos();
	}

	void business::city_event(net::Msg& m, Json::Value& r)
	{
		playerDataPtr player = player_mgr.getPlayer(m.playerID);
		if (!player)Return(r, err_illedge);
		if (player->LV() < systemUseLimit)Return(r, err_player_lv_too_low);

		Json::Value& data_json = r[strMsg][1u] = Json::arrayValue;
		for (boost::unordered_map<int, int>::iterator it = cityEvnMap.begin(); it != cityEvnMap.end(); ++it)
		{
			Json::Value sg_json;
			sg_json.append(it->first);
			sg_json.append(it->second);
			data_json.append(sg_json);
		}
		Return(r, res_sucess);
	}

	void business::cancel_task(net::Msg& m, Json::Value& r)
	{
		playerDataPtr player = player_mgr.getPlayer(m.playerID);
		if (!player)Return(r, err_illedge);
		if (player->LV() < systemUseLimit)Return(r, err_player_lv_too_low);
		ReadJsonArray;
		const unsigned idx = js_msg[0u].asUInt();
		if (player->Info().Nation() == Kingdom::null)Return(r, err_illedge);
		if (player->Trade().taskType() != TradeType::runing)Return(r, err_illedge);
		Log(DBLOG::strLogBusiness, player, 1, player->Trade().getMoney(), player->Trade().getComplete());
		player->Trade().cancelTask();
		Return(r, res_sucess);
	}

	void business::complete_task(net::Msg& m, Json::Value& r)
	{
		playerDataPtr player = player_mgr.getPlayer(m.playerID);
		if (!player)Return(r, err_illedge);
		if (player->LV() < systemUseLimit)Return(r, err_player_lv_too_low);
		if (player->Info().Nation() == Kingdom::null)Return(r, err_illedge);
		if (player->Trade().taskType() != TradeType::complete)Return(r, err_illedge);
		if (
			player->Items().isOver
			(
				player->Items().itemUsePos(CarMaterialID, 1)
			)
			)Return(r, err_bag_full);
		int cm = player->Trade().getMoney() - player->Trade().getComplete();
		cm = cm < 0 ? 0 : cm;
		const unsigned times = player->Trade().taskTimes();
		//��������Ʊ��� / 8 + 10000 + ����������� * 2 %
		const int silver = int((player->Trade().getComplete() / 4 + 10000 + cm * 0.1) * (times > 3 ? 0.3 : 1.0));
		const int contribute = 500 + (int)player->LV() * 5;
		kingdom_sys.upgradeConstruction(player->Info().Nation(), Kingdom::CLevel, contribute);
		player->Res().alterSilver(silver);
		player->Res().alterContribution(contribute);
		player->Items().addItem(CarMaterialID, 2);
		player->Trade().overTask();
		r[strMsg][1u] = silver;
		r[strMsg][2u] = contribute;
		r[strMsg][3u] = 2;
		r[strMsg][4u] = contribute;
		Log(DBLOG::strLogBusiness, player, 2, cm, silver, contribute, 2);
		{
			//����
			//player->Task().evTask(TaskDef::BusinessNumEv);
			//�ճ�
			TaskMgr::update(player, Task::BusinessTimes, 1);
			TaskMgr::update(player, Task::BusinessAllTimes);
			player->Daily().tickTask(DAILY::business_trade);
		}
		Return(r, res_sucess);
	}

	void business::complete_task_ok(net::Msg& m, Json::Value& r)
	{
		playerDataPtr player = player_mgr.getPlayer(m.playerID);
		if (!player)Return(r, err_illedge);
		if (player->Info().VipLv() < 3)Return(r, err_vip_lv_too_low);
		if (player->LV() < systemUseLimit)Return(r, err_player_lv_too_low);
		if (player->Info().Nation() == Kingdom::null)Return(r, err_illedge);
		if (player->Res().getCash() < 50)Return(r, err_cash_not_enough);
		if (player->Trade().taskType() == TradeType::null)//û������ͽ�������
		{
			const unsigned playerLV = player->LV();
			if (playerLV > 80)player->Trade().acceptTask(taskBegin[0], taskEnd[0]);
			else if (playerLV > 60)player->Trade().acceptTask(taskBegin[1], taskEnd[1]);
			else if (playerLV > 30)player->Trade().acceptTask(taskBegin[2], taskEnd[2]);
		}
		if (
			player->Items().isOver
			(
				player->Items().itemUsePos(CarMaterialID, 2)
			)
			)Return(r, err_bag_full);
		int cm = player->Trade().getMoney() - player->Trade().getComplete();
		cm = cm < 0 ? 0 : cm;
		const unsigned times = player->Trade().taskTimes();
		//��������Ʊ��� / 8 + 10000 + ����������� * 2 %
		const int silver = int((player->Trade().getComplete() / 4 + 10000 + cm * 0.1) * (times > 3 ? 0.3 : 1.0));
		const int contribute = 500 + (int)player->LV() * 5;
		kingdom_sys.upgradeConstruction(player->Info().Nation(), Kingdom::CLevel, contribute);
		player->Res().alterSilver(silver);
		player->Res().alterContribution(contribute);
		player->Items().addItem(CarMaterialID, 2);
		player->Trade().overTask();
		player->Res().alterCash(-50);
		r[strMsg][1u] = silver;
		r[strMsg][2u] = contribute;
		r[strMsg][3u] = 2;
		r[strMsg][4u] = contribute;
		Log(DBLOG::strLogBusiness, player, 3, cm, silver, contribute, 2);
		{
			//����
			//player->Task().evTask(TaskDef::BusinessNumEv);
			//�ճ�
			TaskMgr::update(player, Task::BusinessTimes, 1);
			TaskMgr::update(player, Task::BusinessAllTimes);
			player->Daily().tickTask(DAILY::business_trade);
		}
		Return(r, res_sucess);
	}

	void business::update_city(net::Msg& m, Json::Value& r)
	{
		playerDataPtr player = player_mgr.getPlayer(m.playerID);
		if (!player)Return(r, err_illedge);
		if (player->LV() < systemUseLimit)Return(r, err_player_lv_too_low);
		if (!player->CarPos().isNearlyAim())Return(r, err_car_is_moving);
		const unsigned x = player->CarPos().currentX();
		const unsigned y = player->CarPos().currentY();
		ReadJsonArray;
		const int cityID = js_msg[0u].asInt();
		if (!validCityRange(cityID, x, y))Return(r, err_illedge);
		qValue data_json(qJson::qj_array);
		data_json.append(res_sucess)
			.append(cityID)
			.append(Cities[cityID]->toJson())
			.append(cityPriceRate(cityID));
		player->sendToClientFillMsg(gate_client::player_trade_city_update_resp, data_json);
	}

	void business::buy_item(net::Msg& m, Json::Value& r)
	{
		playerDataPtr player = player_mgr.getPlayer(m.playerID);
		if (!player)Return(r, err_illedge);
		if (player->LV() < systemUseLimit)Return(r, err_player_lv_too_low);
		if (player->Info().Nation() == Kingdom::null)Return(r, err_illedge);
		if (player->Trade().taskType() != TradeType::runing)Return(r, err_illedge);
		if (!player->CarPos().isNearlyAim())Return(r, err_car_is_moving);
		const unsigned x = player->CarPos().currentX();
		const unsigned y = player->CarPos().currentY();
		ReadJsonArray;
		const int cityID = js_msg[0u].asInt();
		const int wareID = js_msg[1u].asInt();
		const unsigned wareNum = js_msg[2u].asUInt();
		const int warePrice = js_msg[3u].asInt();
		if (!validCityRange(cityID, x, y))Return(r, err_illedge);
		cityPtr city = Cities[cityID];
		CityData::warePtr ware = city->saleWare(wareID);
		if (!ware)Return(r, err_illedge);
		if (ware->price != warePrice)
		{
			r[strMsg][1u] = ware->price;
			Return(r, err_refresh_trade_city);
		}
		const int need_money = ware->price * wareNum;
		if (player->Trade().getMoney() < need_money)Return(r, err_trade_money_not_enough);
		if (player->Trade().addWare(wareID, wareNum, warePrice) == res_sucess)
		{
			player->Trade().alterMoney(-need_money);
			r[strMsg][1u] = need_money;
			Return(r, res_sucess);
		}
		Return(r, err_trade_bag_full);
	}

	int CarDurable(const int rate)
	{
		if (rate < 100)
		{
			if (rate < 90)
			{
				if (rate < 80)
				{
					if (rate < 70)
					{
						if (rate < 60)
						{
							if (rate < 50)
							{
								if (rate < 40)
								{
									if (rate < 30)
									{
										if (rate < 20)
										{
											if (rate < 10)
											{
												return -20;
											}
											return -18;
										}
										return -16;
									}
									return -14;
								}
								return -12;
							}
							return -10;
						}
						return -8;
					}
					return -6;
				}
				return -4;
			}
			return -2;
		}
		return 0;
	}
	void business::sale_item(net::Msg& m, Json::Value& r)
	{
		playerDataPtr player = player_mgr.getPlayer(m.playerID);
		if (!player)Return(r, err_illedge);
		if (player->LV() < systemUseLimit)Return(r, err_player_lv_too_low);
		if (player->Info().Nation() == Kingdom::null)Return(r, err_illedge);
		if (player->Trade().taskType() == TradeType::null)Return(r, err_illedge);
		if (!player->CarPos().isNearlyAim())Return(r, err_car_is_moving);
		const unsigned x = player->CarPos().currentX();
		const unsigned y = player->CarPos().currentY();
		ReadJsonArray;
		const int cityID = js_msg[0u].asInt();
		const int cityRate = js_msg[1u].asInt();
		const int wareID = js_msg[2u].asInt();
		const unsigned wareNum = js_msg[3u].asUInt();
		const int warePrice = js_msg[4u].asInt();
		if (!validCityRange(cityID, x, y))Return(r, err_illedge);
		const int rate = cityPriceRate(cityID);
		cityPtr city = Cities[cityID];//��ֵ��֤����һ��
		CityData::warePtr ware = city->pawnWare(wareID);
		if (!ware)Return(r, err_illedge);
		if (rate != cityRate || ware->price != warePrice)
		{
			r[strMsg][2u] = ware->price;
			r[strMsg][1u] = rate;
			Return(r, err_refresh_trade_city);
		}
		if (player->Trade().checkWare(wareID, wareNum))
		{
			player->Trade().removeWare(wareID, wareNum);
			int all_rate = 100 +
				CarDurable(player->Trade().getDurable()) +
				player->Trade().getSaleRate() +
				(
				((rate < 0 && player->Trade().checkBuff(TradeBuff::fangshui)) ? 0 : rate) +
					(player->Trade().checkBuff(TradeBuff::yijia) ? 10 : 0)
					);
			const int reward = int(
				all_rate / 100.0 * warePrice * wareNum
				);
			player->Trade().alterMoney(reward);
			r[strMsg][1u] = reward;
			Return(r, res_sucess);
		}
		Return(r, err_illedge);
	}

	void business::car_upgrade(net::Msg& m, Json::Value& r)
	{
		playerDataPtr player = player_mgr.getPlayer(m.playerID);
		if (!player)Return(r, err_illedge);
		if (player->LV() < systemUseLimit)Return(r, err_player_lv_too_low);
		if (!player->CarPos().isNearlyAim())Return(r, err_car_is_moving);
		ReadJsonArray;
		const int times = js_msg[0u].asUInt();
		if (times < 1 || times > 10)Return(r, err_illedge);
		if (player->Info().Nation() == Kingdom::null)Return(r, err_illedge);
		if (!player->Items().overItem(CarMaterialID, 1 * times))Return(r, err_item_not_enough);
		player->Items().removeItem(CarMaterialID, 1 * times);
		player->Trade().addExp(10 * times);
		r[strMsg][3u] = player->Trade().getExp();
		r[strMsg][2u] = player->Trade().getLevel();
		r[strMsg][1u] = 1000 * times;
		Log(DBLOG::strLogBusiness, player, 6, CarMaterialID, times, 10 * times);
		Return(r, res_sucess);
	}

	void business::item_use(net::Msg& m, Json::Value& r)
	{
		playerDataPtr player = player_mgr.getPlayer(m.playerID);
		if (!player)Return(r, err_illedge);
		if (player->LV() < systemUseLimit)Return(r, err_player_lv_too_low);
		if (player->Info().Nation() == Kingdom::null)Return(r, err_illedge);
		if (player->Trade().taskType() == TradeType::null)Return(r, err_illedge);
		ReadJsonArray;
		const int itemID = js_msg[0u].asInt();
		if (!player->Items().overItem(itemID, 1))Return(r, err_item_not_enough);
		const TBstruct dataBuff = getBindBuff(itemID);
		if (dataBuff._id_buff == TradeBuff::null)Return(r, err_illedge);
		if (player->Trade().checkBuff(dataBuff._id_buff))Return(r, err_trade_buff_hold);
		player->Trade().insertBuff(dataBuff._id_buff, dataBuff._duration);
		player->Items().removeItem(itemID, 1);
		Log(DBLOG::strLogBusiness, player, 4, itemID, 1);
		r[strMsg][2u] = dataBuff._duration;
		r[strMsg][1u] = dataBuff._id_buff;
		Return(r, res_sucess);
	}

	void business::open_box(net::Msg& m, Json::Value& r)
	{
		playerDataPtr player = player_mgr.getPlayer(m.playerID);
		if (!player)Return(r, err_illedge);
		if (player->LV() < systemUseLimit)Return(r, err_player_lv_too_low);
		if (player->Info().Nation() == Kingdom::null)Return(r, err_illedge);
		player->CarPos().stopMove();
		const unsigned x = player->CarPos().currentX();
		const unsigned y = player->CarPos().currentY();
		ReadJsonArray;
		const unsigned ax = js_msg[0u].asUInt();
		const unsigned ay = js_msg[1u].asUInt();
		const MapEvnet::Type type = getMapEvent(ax, ay);
		if (!(type == MapEvnet::silver_box || type == MapEvnet::gold_box))Return(r, err_trade_box_not_found);
		if ((ax > x && ax - x > 3) || (ay > y && ay - y > 3) || (ax < x && x - ax > 3) || (ay < y && y - ay > 3))Return(r, err_illedge);
		const unsigned lv = player->LV();
		if (MapEvnet::silver_box == type)
		{
			if (!player->Items().overItem(SilverKeyID, 1))Return(r, err_item_not_enough);
			for (unsigned i = 0; i < SilverBox.size(); ++i)
			{
				if (lv > SilverBox[i].LevelLimit)
				{
					const int res = actionDo(player, SilverBox[i].BoxReward, 1, false);
					if (res != res_sucess)
					{
						r[strMsg][1u] = actionError();
						Return(r, res);
					}
					break;
				}
			}
			player->Items().removeItem(SilverKeyID, 1);
			Log(DBLOG::strLogBusiness, player, 4, SilverKeyID, 1);
		}
		if (MapEvnet::gold_box == type)
		{
			if (!player->Items().overItem(GoldKeyID, 1))Return(r, err_item_not_enough);
			for (unsigned i = 0; i < GoldBox.size(); ++i)
			{
				if (lv > GoldBox[i].LevelLimit)
				{
					const int res = actionDo(player, GoldBox[i].BoxReward, 1, false);
					if (res != res_sucess)
					{
						r[strMsg][1u] = actionError();
						Return(r, res);
					}
					break;
				}
			}
			player->Items().removeItem(GoldKeyID, 1);
			Log(DBLOG::strLogBusiness, player, 4, GoldKeyID, 1);
		}
		r[strMsg][1u] = actionRes();
		removeMapEvent(ax, ay);
		Return(r, res_sucess);
	}

	sBattlePtr npcPirate(const Pirate& pir)
	{
		sBattlePtr sb = Creator<sideBattle>::Create();
		sb->playerID = -1;
		sb->playerName = pir.npcName;
		sb->isPlayer = false;
		sb->playerLevel = pir.npcLevel;
		sb->battleValue = pir.battleValue;
		sb->playerFace = pir.npcFace;
		manList& ml = sb->battleMan;
		ml.clear();
		const vector< Pirate::armyNPC >& npcList = pir.npcList;
		for (unsigned i = 0; i < npcList.size(); i++)
		{
			const Pirate::armyNPC& npc = npcList[i];
			mBattlePtr man = Creator<manBattle>::Create();
			man->manID = npc.npcID;
			man->holdMorale = npc.holdMorale;
			man->set_skill_1(npc.skill_1);
			man->set_skill_2(npc.skill_2);
			man->armsType = npc.armsType;
			man->manLevel = npc.npcLevel;
			man->currentIdx = npc.npcPos;
			man->battleValue = npc.battleValue;
			memcpy(man->armsModule, npc.armsModule, sizeof(man->armsModule));
			memcpy(man->initialAttri, npc.initAttri, sizeof(man->initialAttri));
			memcpy(man->battleAttri, npc.initAttri, sizeof(man->battleAttri));
			//memcpy(man->battleAttri, npc.addAttri, sizeof(man->battleAttri));
			man->currentHP = man->getTotalAttri(idx_hp);
			man->equipList = npc.equipList;
			ml.push_back(man);
		}
		return sb;
	}

	void business::challenge_pirate(net::Msg& m, Json::Value& r)
	{
		playerDataPtr player = player_mgr.getPlayer(m.playerID);
		if (!player)Return(r, err_illedge);
		if (player->LV() < systemUseLimit)Return(r, err_player_lv_too_low);
		if (player->Info().Nation() == Kingdom::null)Return(r, err_illedge);
		if (player->Trade().hitPirate() > 4)Return(r, err_trade_pirate_times_over);
		player->CarPos().stopMove();
		const unsigned x = player->CarPos().currentX();
		const unsigned y = player->CarPos().currentY();
		ReadJsonArray;
		const unsigned ax = js_msg[0u].asUInt();
		const unsigned ay = js_msg[1u].asUInt();
		const MapEvnet::Type type = getMapEvent(ax, ay);
		if (type != MapEvnet::haidao)Return(r, err_trade_haidao_not_found);
		if ((ax > x && ax - x > 2) || (ay > y && ay - y > 2) || (ax < x && x - ax > 2) || (ay < y && y - ay > 2))Return(r, err_illedge);
		const unsigned lv = player->LV();
		for (unsigned i = 0; i < PirateBox.size(); ++i)
		{
			const Pirate& pir = PirateBox[i];
			if (lv > pir.LevelLimit)
			{
				sBattlePtr atk = BattleHelp::WarPlayer(player);
				sBattlePtr def = npcPirate(pir);
				BattleReport reportData;
				const O2ORes res = reportData.One2One(atk, def, typeBattle::trade_pirate);
				reportData.addNotice(player->ID());
				reportData.addReportdeclare("bg", pir.background);
				if (resBattle::atk_win == res.res)
				{
					removeMapEvent(ax, ay);
				}
				Json::Value me_json;
				unsigned total_me = BattleHelp::AddManExp(player, 0, me_json);
				reportData.addReportdeclare("me", me_json);
				Json::Value res_json = Json::arrayValue;
				if (resBattle::atk_win == res.res)
				{
					player->Trade().tickPirate();
					actionDo(player, pir.rewardList, 1);
					res_json = actionRes();
				}
				reportData.addReportdeclare("wb", res_json);
				Json::Value playerJson;
				playerJson.append(player->LV());
				playerJson.append(player->Info().EXP());
				playerJson.append(player->LV());
				playerJson.append(player->Info().EXP());
				playerJson.append(0);
				playerJson.append(player->Info().isMaxLevel());
				reportData.addReportdeclare("plv", playerJson);
				reportData.Done(typeBattle::trade_pirate);
				r[strMsg][1u] = res.res;
				Return(r, res_sucess);
			}
		}
		Return(r, err_illedge);
	}

	void business::car_teleport(net::Msg& m, Json::Value& r)
	{
		playerDataPtr player = player_mgr.getPlayer(m.playerID);
		if (!player)Return(r, err_illedge);
		if (player->LV() < systemUseLimit)Return(r, err_player_lv_too_low);
		if (player->Info().Nation() == Kingdom::null)Return(r, err_illedge);
		if (!player->Items().overItem(ShunYiID, 1))Return(r, err_item_not_enough);
		ReadJsonArray;
		const unsigned x = js_msg[0u].asUInt();
		const unsigned y = js_msg[1u].asUInt();
		if (availablePlace(x, y))
		{
			player->Items().removeItem(ShunYiID, 1);
			player->CarPos().setPos(x, y);
			r[strMsg][1u] = player->CarPos().currentX();
			r[strMsg][2u] = player->CarPos().currentY();
			Log(DBLOG::strLogBusiness, player, 4, ShunYiID, 1);
			Return(r, res_sucess);
		}
		Return(r, err_illedge);
	}
	void business::car_repair(net::Msg& m, Json::Value& r)
	{
		playerDataPtr player = player_mgr.getPlayer(m.playerID);
		if (!player)Return(r, err_illedge);
		if (player->LV() < systemUseLimit)Return(r, err_player_lv_too_low);
		if (player->Info().Nation() == Kingdom::null)Return(r, err_illedge);
		const int cost_silver = player->Trade().getDurableLimit() * 100;
		if (cost_silver == 0)Return(r, err_illedge);
		if (cost_silver > player->Res().getSilver())Return(r, err_silver_not_enough);
		player->Res().alterSilver(-cost_silver);
		player->Trade().fullDurable();
		r[strMsg][1u] = cost_silver;
		Log(DBLOG::strLogBusiness, player, 7, cost_silver, player->Res().getSilver());
		Return(r, res_sucess);
	}

	void business::updateMoveCar(playerDataPtr player)
	{
		_info_ptr info = getBRPlayer(player->ID());
		if (!info) {
			info = _info::Create(player);
		}
		info->state = car_enter;
		playerCarPos& Car = player->CarPos();
		info->aim_x = Car.aimX();
		info->aim_y = Car.aimY();
		playerTrade& Trade = player->Trade();
		info->speed = Trade.getSpeed();
		info->level = Trade.getLevel();
		//�����µ�λ��
		info->setNewPos(player, Car.currentX(), Car.currentY());
	}
}

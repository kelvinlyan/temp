#include "net_helper.hpp"

namespace gg
{
	namespace detail
	{
		static boost::mutex batch_mutex;
		const static unsigned DataLength = 64 * ::net::KB;
		static void *comonData;

		void initDetail()
		{
			comonData = ::GNew(DataLength);
		}

		void batchOnline(sendList& vec, Json::Value& msgJson, const short protocol)
		{
			if (vec.empty())return;
			int size = (int)vec.size();
			string str = msgJson.toIndentString();
			net::Msg mj_begin(protocol, size, gate_client::game_set_gate_buffer_resp, str);
			boost::mutex::scoped_lock lock(batch_mutex);
			game_svr->async_send_to_gate(mj_begin);

			::net::Msg cMsg;
			cMsg.protocolID = gate_client::game_cast_buffer_group_resp;
			cMsg.strUTF8 = (char*)comonData;
			cMsg.playerID = protocol;
			for (unsigned i = 0; i < vec.size(); ++i)
			{
				const int playerID = vec[i];
				if (cMsg.packageLen >= DataLength)break;
				memmove((void*)(cMsg.strUTF8 + cMsg.packageLen - ::net::MINPACKAGE), &playerID, 4);
				cMsg.packageLen += 4;
			}
			game_svr->async_send_to_gate(cMsg);

// 			net::Msg mj_end(protocol, -1, gate_client::game_clear_gate_buffer_resp);
// 			game_svr->async_send_to_gate(mj_end);
		}

		void batchOnline(sendSet& vec, Json::Value& msgJson, const short protocol)
		{
			if (vec.empty())return;
			int size = (int)vec.size();
			string str = msgJson.toIndentString();
			net::Msg mj_begin(protocol, size, gate_client::game_set_gate_buffer_resp, str);
			boost::mutex::scoped_lock lock(batch_mutex);
			game_svr->async_send_to_gate(mj_begin);

			::net::Msg cMsg;
			cMsg.protocolID = gate_client::game_cast_buffer_group_resp;
			cMsg.strUTF8 = (char*)comonData;
			cMsg.playerID = protocol;
			for (sendSet::iterator it = vec.begin(); it != vec.end(); ++it)
			{
				const int playerID = *it;
				if (cMsg.packageLen >= DataLength)break;
				memmove((void*)(cMsg.strUTF8 + cMsg.packageLen - ::net::MINPACKAGE), &playerID, 4);
				cMsg.packageLen += 4;
			}
			game_svr->async_send_to_gate(cMsg);

// 			net::Msg mj_end(protocol, -1, gate_client::game_clear_gate_buffer_resp);
// 			game_svr->async_send_to_gate(mj_end);
		}

		void batchOnline(playerManager::playerDataVec& vec, Json::Value& msgJson, const short protocol)
		{
			if (vec.empty())return;
			int size = (int)vec.size();
			string str = msgJson.toIndentString();
			net::Msg mj_begin(protocol, size, gate_client::game_set_gate_buffer_resp, str);
			boost::mutex::scoped_lock lock(batch_mutex);
			game_svr->async_send_to_gate(mj_begin);

			::net::Msg cMsg;
			cMsg.protocolID = gate_client::game_cast_buffer_group_resp;
			cMsg.strUTF8 = (char*)comonData;
			cMsg.playerID = protocol;
			for (unsigned i = 0; i < vec.size(); ++i)
			{
				playerDataPtr player = vec[i];
				const int playerID = player->ID();
				if (cMsg.packageLen >= DataLength)break;
				memmove((void*)(cMsg.strUTF8 + cMsg.packageLen - ::net::MINPACKAGE), &playerID, 4);
				cMsg.packageLen += 4;
			}
			game_svr->async_send_to_gate(cMsg);

// 			net::Msg mj_end(protocol, -1, gate_client::game_clear_gate_buffer_resp);
// 			game_svr->async_send_to_gate(mj_end);
		}

		void batchOnline(sendList& vec, qValue& msgJson, const short protocol)
		{
			if (vec.empty())return;
			int size = (int)vec.size();
			string str = msgJson.toIndentString();
			net::Msg mj_begin(protocol, size, gate_client::game_set_gate_buffer_resp, str);
			boost::mutex::scoped_lock lock(batch_mutex);
			game_svr->async_send_to_gate(mj_begin);

			::net::Msg cMsg;
			cMsg.protocolID = gate_client::game_cast_buffer_group_resp;
			cMsg.strUTF8 = (char*)comonData;
			cMsg.playerID = protocol;
			for (unsigned i = 0; i < vec.size(); ++i)
			{
				const int playerID = vec[i];
				if (cMsg.packageLen >= DataLength)break;
				memmove((void*)(cMsg.strUTF8 + cMsg.packageLen - ::net::MINPACKAGE), &playerID, 4);
				cMsg.packageLen += 4;
			}
			game_svr->async_send_to_gate(cMsg);

// 			net::Msg mj_end(protocol, -1, gate_client::game_clear_gate_buffer_resp);
// 			game_svr->async_send_to_gate(mj_end);
		}

		void batchOnline(sendSet& vec, qValue& msgJson, const short protocol)
		{
			if (vec.empty())return;
			int size = (int)vec.size();
			string str = msgJson.toIndentString();
			net::Msg mj_begin(protocol, size, gate_client::game_set_gate_buffer_resp, str);
			boost::mutex::scoped_lock lock(batch_mutex);
			game_svr->async_send_to_gate(mj_begin);
			
			::net::Msg cMsg;
			cMsg.protocolID = gate_client::game_cast_buffer_group_resp;
			cMsg.strUTF8 = (char*)comonData;
			cMsg.playerID = protocol;
			for (sendSet::iterator it = vec.begin(); it != vec.end(); ++it)
			{
				const int playerID = *it;
				if (cMsg.packageLen >= DataLength)break;
				memmove((void*)(cMsg.strUTF8 + cMsg.packageLen - ::net::MINPACKAGE), &playerID, 4);
				cMsg.packageLen += 4;
			}
			game_svr->async_send_to_gate(cMsg);

// 			net::Msg mj_end(protocol, -1, gate_client::game_clear_gate_buffer_resp);
// 			game_svr->async_send_to_gate(mj_end);
		}

		void batchOnline(playerManager::playerDataVec& vec, qValue& msgJson, const short protocol)
		{
			if (vec.empty())return;
			int size = (int)vec.size();
			string str = msgJson.toIndentString();
			net::Msg mj_begin(protocol, size, gate_client::game_set_gate_buffer_resp, str);
			boost::mutex::scoped_lock lock(batch_mutex);
			game_svr->async_send_to_gate(mj_begin);

			::net::Msg cMsg;
			cMsg.protocolID = gate_client::game_cast_buffer_group_resp;
			cMsg.strUTF8 = (char*)comonData;
			cMsg.playerID = protocol;
			for (unsigned i = 0; i < vec.size(); ++i)
			{
				playerDataPtr player = vec[i];
				const int playerID = player->ID();
				if (cMsg.packageLen >= DataLength)break;
				memmove((void*)(cMsg.strUTF8 + cMsg.packageLen - ::net::MINPACKAGE), &playerID, 4);
				cMsg.packageLen += 4;
			}
			game_svr->async_send_to_gate(cMsg);

// 			net::Msg mj_end(protocol, -1, gate_client::game_clear_gate_buffer_resp);
// 			game_svr->async_send_to_gate(mj_end);
		}
	}

}

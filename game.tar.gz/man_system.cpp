#include "man_system.h"
#include <boost/assert.hpp>
#include "task_mgr.h"
#include "discount.h"

namespace gg
{
	const static unsigned ManTrainLimit = 50;
	const static unsigned ManUpLimit = 18;
	const static unsigned ManEquipOneKey = 20;

	UNORDERMAP(int, int, FlyExpMap);
	static FlyExpMap FlyExp;
	static vector< vector< int > > TrainCost;

	static int getFlyExp(const int itemID)
	{
		FlyExpMap::iterator it = FlyExp.find(itemID);
		if (it == FlyExp.end())return 0;
		return it->second;
	}

	void man_system::oneKeyEquip(net::Msg& m, Json::Value& r)
	{
		playerDataPtr player = player_mgr.getPlayer(m.playerID);
		if (!player)Return(r, err_illedge);
		if (player->LV() < ManEquipOneKey)Return(r, err_player_lv_too_low);

		ReadJsonArray;
		const int manID_1 = js_msg[0u].asInt();
		const int manID_2 = js_msg[1u].asInt();

		Return(r, player->Man().equipExchange(manID_1, manID_2));
	}

	void man_system::starsUp(net::Msg& m, Json::Value& r)
	{
		playerDataPtr player = player_mgr.getPlayer(m.playerID);
		if (!player)Return(r, err_illedge);
		if (player->LV() < ManUpLimit)Return(r, err_player_lv_too_low);
		ReadJsonArray;
		int manID = js_msg[0u].asInt();
		playerManPtr man = player->Man().findMan(manID);
		if (!man)Return(r, err_illedge);
		cfgManPtr config = man->getConfig();
		if (!config)Return(r, err_illedge);
		int res = man->starsUp();
		if (res == res_sucess)
		{
			player->Man().tickStarUp();
			TaskMgr::update(player, Task::AdvanceTimes, 1);
			TaskMgr::update(player, Task::ManNumOfColor);
			Log(DBLOG::strLogManDo, player, 3, manID, man->mID());
		}
		Return(r, res);
	}

	void man_system::trainMan(net::Msg& m, Json::Value& r)
	{
		playerDataPtr player = player_mgr.getPlayer(m.playerID);
		if (!player)Return(r, err_illedge);
		if (player->LV() < ManTrainLimit)Return(r, err_player_lv_too_low);
		ReadJsonArray;
		int manID = js_msg[0u].asInt();
		const unsigned opt = js_msg[1u].asUInt();
		if (opt == 0)
		{
			const int cost = player->LV() * 4;
			if (player->Res().getMerit() < cost)Return(r, err_merit_not_enough);
		}
		else
		{
			if (player->Res().getCash() < 2)Return(r, err_cash_not_enough);
		}
 		playerManPtr man = player->Man().findMan(manID);
 		if (!man)Return(r, err_illedge);
		if (man->HasNowTrain())Return(r, err_illedge);
		const vector<MANDEF::trainPlayer>& tl = man->getTrain();
		vector<int> newAttri;
		cfgManPtr config = man->getConfig();
		for (unsigned i = 0; i < tl.size(); ++i)
		{
			const int Max = man->LV() + config->TrainList[i].val;
			const int cMax = std::min(tl[i].val + 4, Max);
			newAttri.push_back(Common::randomBetween(1, cMax));
		}
		man->setNowTrain(newAttri);
		if (opt == 0)
		{
			const int cost = player->LV() * 4;
			player->Res().alterMerit(-cost);
		}
		else
		{
			player->Res().alterCash(-2);
		}
		//�ճ�
		player->Daily().tickTask(DAILY::man_train);
		TaskMgr::update(player, Task::TemperTimes, 1);
		Return(r, res_sucess);
	}

	const static int trainCostList[] = { 10, 50 };
	const static unsigned trainCostLength = sizeof(trainCostList) / sizeof(int);
	void man_system::trainManGold(net::Msg& m, Json::Value& r)
	{
		playerDataPtr player = player_mgr.getPlayer(m.playerID);
		if (!player)Return(r, err_illedge);
		if (player->LV() < ManTrainLimit)Return(r, err_player_lv_too_low);
		ReadJsonArray;
		const int manID = js_msg[0u].asInt();
		const unsigned opt = js_msg[1u].asUInt();
		if (opt >= trainCostLength)Return(r, err_illedge);
		const int cost = trainCostList[opt];
		if (player->Res().getCash() < cost)Return(r, err_cash_not_enough);
		playerManPtr man = player->Man().findMan(manID);
		if (!man)Return(r, err_illedge);
		if (man->HasNowTrain())Return(r, err_illedge);
		const vector<MANDEF::trainPlayer>& tl = man->getTrain();
		vector<int> newAttri;
		cfgManPtr config = man->getConfig();
		for (unsigned i = 0; i < tl.size(); ++i)
		{
			const int Max = man->LV() + config->TrainList[i].val;//����ϴ�������ֵ
			const int cval = tl[i].val;//��ǰ����
			const int cm_cval = cval + 5;//�Ƚ�����
			int to_val = 0;
			if (opt == 0)
			{
				if (cm_cval <= (Max / 2))//�׽�ϴ��
				{
					to_val += cval + Common::randomBetween(1, 4);
				}
				else
				{
					to_val += cval + Common::randomBetween(-8, 4);
				}
			}
			else
			{
				if (cm_cval <= int(Max * 0.8))//����ϴ��
				{
					to_val += cval + Common::randomBetween(3, 5);
				}
				else
				{
					to_val += cval + Common::randomBetween(-5, 5);
				}
			}

			to_val = to_val < 1 ? 1 : to_val;
			to_val = std::min(to_val, Max);

			newAttri.push_back(to_val);
		}
		man->setNowTrain(newAttri);
		player->Res().alterCash(-cost);
		//�ճ�
		player->Daily().tickTask(DAILY::man_train);
		TaskMgr::update(player, Task::TemperTimes, 1);
		Return(r, res_sucess);
	}

	void man_system::trainKeep(net::Msg& m, Json::Value& r)
	{
		playerDataPtr player = player_mgr.getPlayer(m.playerID);
		if (!player)Return(r, err_illedge);
		if (player->LV() < ManTrainLimit)Return(r, err_player_lv_too_low);
		ReadJsonArray;
		const int manID = js_msg[0u].asInt();
		playerManPtr man = player->Man().findMan(manID);
		if (!man)Return(r, err_man_no_found);
		man->ClearNowTrain();
		Return(r, res_sucess);
	}

	void man_system::trainReplace(net::Msg& m, Json::Value& r)
	{
		playerDataPtr player = player_mgr.getPlayer(m.playerID);
		if (!player)Return(r, err_illedge);
		if (player->LV() < ManTrainLimit)Return(r, err_player_lv_too_low);
		ReadJsonArray;
		const int manID = js_msg[0u].asInt();
		playerManPtr man = player->Man().findMan(manID);
		if (!man)Return(r, err_man_no_found);
		const int res = man->ReplaceTrain();
		Return(r, res);
	}

	void man_system::trainReconver(net::Msg& m, Json::Value& r)
	{
		playerDataPtr player = player_mgr.getPlayer(m.playerID);
		if (!player)Return(r, err_illedge);
		if (player->LV() < ManTrainLimit)Return(r, err_player_lv_too_low);
		ReadJsonArray;
		const int manID = js_msg[0u].asInt();
		playerManPtr man = player->Man().findMan(manID);
		if (!man)Return(r, err_man_no_found);
		if (man->HasNowTrain())Return(r, err_illedge);
		if (player->Res().getCash() < 20)Return(r, err_cash_not_enough);
		const int res = man->RecoverTrain();
		if (res == res_sucess)
		{
			player->Res().alterCash(-20);
		}
		Return(r, res_sucess);
	}

	void man_system::activeAttri(net::Msg& m, Json::Value& r)
	{
		playerDataPtr player = player_mgr.getPlayer(m.playerID);
		if (!player)Return(r, err_illedge);
		ReadJsonArray;
		int manID = js_msg[0u].asInt();
		unsigned idx = js_msg[1u].asUInt();
		if (idx >= starsAttriNum)Return(r, err_illedge);
		playerManPtr man = player->Man().findMan(manID);
		if (!man)Return(r, err_illedge);
		cfgManPtr config = man->getConfig();
		if (!config)Return(r, err_illedge);
		const vector< ManConfig::itemCost >& vec = config->starUpCost[idx];
		for (unsigned i = 0; i < vec.size(); ++i)
		{
			if (!player->Items().overItem(vec[i].itemID, vec[i].num))Return(r, err_item_not_enough);
		}
		r[strMsg][1u] = idx;
		int res = man->activeAttri(idx);
		if (res == res_sucess)
		{
			for (unsigned i = 0; i < vec.size(); ++i)
			{
				player->Items().removeItem(vec[i].itemID, vec[i].num);
			}
			Log(DBLOG::strLogManDo, player, 4, manID, idx);
			{
				//����
				//player->Task().evTask(TaskDef::TrainMaxnEv);
				//�ճ�
				player->Daily().tickTask(DAILY::man_active_state);
			}
		}
		Return(r, res);
	}

	void man_system::activeAttriAll(net::Msg& m, Json::Value& r)
	{
		playerDataPtr player = player_mgr.getPlayer(m.playerID);
		if (!player)Return(r, err_illedge);
		ReadJsonArray;
		int manID = js_msg[0u].asInt();
		playerManPtr man = player->Man().findMan(manID);
		if (!man)Return(r, err_illedge);
		cfgManPtr config = man->getConfig();
		if (!config)Return(r, err_illedge);
		unsigned sucess_num = 0;
		const unsigned stateAttri = man->activeState();
		Json::Value& data_json = r[strMsg][1u] = Json::arrayValue;
		for (unsigned idx = 0; idx < starsAttriNum; ++idx)
		{
			if (stateAttri & (0x0001 << idx))continue;
			const vector< ManConfig::itemCost >& vec = config->starUpCost[idx];
			bool check_ok = true;
			for (unsigned i = 0; i < vec.size(); ++i)
			{
				if (!player->Items().overItem(vec[i].itemID, vec[i].num))
				{
					check_ok = false;
					break;
				}
			}
			if (!check_ok)continue;//���߲���
			const int res = man->activeAttri(idx);
			if (res == res_sucess)
			{
				++sucess_num;
				data_json.append(idx);
				for (unsigned i = 0; i < vec.size(); ++i)
				{
					player->Items().removeItem(vec[i].itemID, vec[i].num);
				}
				Log(DBLOG::strLogManDo, player, 4, manID, idx);
			}
		}
		if (sucess_num > 0)
		{
			player->Daily().tickTask(DAILY::man_active_state, sucess_num);
		}
		const int final_res = sucess_num > 0 ? res_sucess : err_illedge;
		Return(r, final_res);
	}

	void man_system::manEquip(net::Msg& m, Json::Value& r)
	{
		ReadJsonArray;
		playerDataPtr player = player_mgr.getPlayer(m.playerID);
		if (!player)Return(r, err_illedge);
		const int manID = js_msg[0u].asInt();
		playerManPtr man = player->Man().findMan(manID);
		if (!man)Return(r, err_man_no_found);
		Json::Value& equipJson = js_msg[1u];
		if (equipJson.size() < 1 || equipJson.size() > 6)Return(r, err_illedge);
		for (unsigned i = 0; i < equipJson.size(); ++i)
		{
			const int localID = equipJson[i].asInt();
			int res = man->onEquip(localID, false);
			Json::Value resJson;
			resJson.append(res);
			resJson.append(localID);
			r[strMsg][2u].append(resJson);
		}
		r[strMsg][1u] = manID;
		man->recalAttri();
		Return(r, res_sucess);
	}

	void man_system::manOffEquip(net::Msg& m, Json::Value& r)
	{
		playerDataPtr player = player_mgr.getPlayer(m.playerID);
		if (!player)Return(r, err_illedge);
		ReadJsonArray;
		const int manID = js_msg[0u].asInt();
		playerManPtr man = player->Man().findMan(manID);
		if (!man)Return(r, err_man_no_found);
		int positionID = js_msg[1u].asInt();
		int res = man->offEquip(positionID);
		Return(r, res);
	}

	void man_system::manFriendUpgrade(net::Msg& m, Json::Value& r)
	{
		playerDataPtr player = player_mgr.getPlayer(m.playerID);
		if (!player)Return(r, err_illedge);
		ReadJsonArray;
		const int manID = js_msg[0u].asInt();
		const int friendType = js_msg[1u].asInt();
		Return(r, player->Man().friendUpgrade(manID, friendType));
	}

	DeclareRegFunction(man_system::updateAllWarFm)
	{
		playerDataPtr player = player_mgr.getPlayer(m.playerID);
		if (!player)Return(r, err_illedge);
		player->WarFM().updateAll();
	}

	DeclareRegFunction(man_system::updateSingleWarFm)
	{
		playerDataPtr player = player_mgr.getPlayer(m.playerID);
		if (!player)Return(r, err_illedge);
		ReadJsonArray;
		int fmID = js_msg[0u].asInt();
		player->WarFM().updateSingle(fmID);
	}

	DeclareRegFunction(man_system::warFormatDefalut)
	{
		playerDataPtr player = player_mgr.getPlayer(m.playerID);
		if (!player)Return(r, err_illedge);
		ReadJsonArray;
		int fID = js_msg[0u].asInt();
		Return(r, player->WarFM().defaultFM(fID));
	}

	DeclareRegFunction(man_system::warFmFormat)
	{
		playerDataPtr player = player_mgr.getPlayer(m.playerID);
		if (!player)Return(r, err_illedge);
		ReadJsonArray;
		int fID = js_msg[0u].asInt();
		int fm[9];
		for (unsigned i = 0; i < 9; ++i)
		{
			fm[i] = js_msg[1u][i].asInt();
		}
		Return(r, player->WarFM().format(fID, fm));
	}

	void man_system::manUgItem(net::Msg& m, Json::Value& r)
	{
		ReadJsonArray;
		playerDataPtr player = player_mgr.getPlayer(m.playerID);
		if (!player)Return(r, err_illedge);
		int pilotID = js_msg[0u].asInt();// �佫ID
		unsigned times = js_msg[1u].asUInt();// ����
		int itemID = js_msg[2u].asInt();//����
		if (times < 1 || times > 9999)Return(r, err_illedge);
		//if (!(times == 1 || times == 10))Return(r, err_illedge);
		playerManPtr man = player->Man().findMan(pilotID);
		if (!man)Return(r, err_no_man);
		const int try_res = man->addExp(0);
		if (try_res > 0)Return(r, try_res);
		const int sg_exp = getFlyExp(itemID) * discout_sys.getRate(Discount::exp_book_rate);
		if (sg_exp < 1)Return(r, err_illedge);
		if (!player->Items().overItem(itemID, times))Return(r, err_item_not_enough);
		unsigned total_add_exp = 0;
		unsigned ctri_times = 0;
		for (unsigned i = 0; i < times; ++i)
		{
			const bool crtok = Common::randomOk(0.2);
			total_add_exp += crtok ? sg_exp * 1.5 : sg_exp;
			if (crtok)++ctri_times;
		}
		man->addExp(total_add_exp);
		player->Items().removeItem(itemID, times);
		Log(DBLOG::strLogManDo, player, 1, pilotID, itemID, times, total_add_exp);
		TaskMgr::update(player, Task::UseExpItemTimes, times);
		r[strMsg][3u] = total_add_exp;
		r[strMsg][2u] = sg_exp * times;
		r[strMsg][1u] = ctri_times;
		Return(r, res_sucess);
	}

	void man_system::combineMan(net::Msg& m, Json::Value& r)
	{
		playerDataPtr player = player_mgr.getPlayer(m.playerID);
		if (!player)Return(r, err_illedge);
		ReadJsonArray;
		const int manID = js_msg[0u].asInt();// �佫ID
		playerManPtr man = player->Man().findManRaw(manID);
		if (man)Return(r, err_man_has_hold);
		cfgManPtr config = getConfig(manID * 100);
		if (!config)Return(r, err_illedge);
		if(!player->Items().overItem(config->soulItemID, config->combineItemNum, itemDef::pos_bag))Return(r, err_item_not_enough);
		player->Items().removeItem(config->soulItemID, config->combineItemNum, itemDef::pos_bag);
		player->Man().addMan(config);
		Log(DBLOG::strLogManDo, player, 8, manID, config->soulItemID, config->combineItemNum);
		r[strMsg][1u] = manID * 100;
		Return(r, res_sucess);
	}

	man_system* const man_system::_Instance = new man_system();

#define checkAndContinue(json)\
	if(json.isNull())\
	continue;
#define checkNotNullFomatInt(val ,json)\
	if(! json.isNull()){\
		val = json.asInt();\
				}

#define checkNotNullFomatDouble(val ,json)\
	if(! json.isNull()){\
		val = json.asDouble();\
				}

	const static string manIDStr = "manID";
	const static string manInitialStr = "initialAttri";
	const static string manGrowUpStr = "growAttri";
	const static string manAttriStr = "manAttri";
	const static string manFeeStr = "enlistFee";
	const static string manMaxLevelStr = "maxLevel";
	const static string manSkill1Str = "skill_1";
	const static string manSkill2Str = "skill_2";
	const static string armsModuleStr = "armsModule";//����ϵ��
	const static string manTypeStr = "manType"; 
	const static string manDutyStr = "manDuty";
	const static string manResistStr = "resist";//�ֿ��б�
	const static string manAddResStr = "addres";
	const static string manCostResStr = "costres";
	const static string manAppointStr = "appoint";
	const static string manStarCostStr = "starCost";
	const static string manTrainStr = "train";
	const static string manQuality = "manQuality";

	const static string soldierIDStr = "armsId";//����ID
	const static string soldierAddAttriStr = "armsAdd";//�������ӵ�����
	const static string pilotDataDirStr = "./instance/man/";

	void man_system::initData()
	{
		cout << "load  man system ..." << endl;
		ConfigMap armsHalfConfig;
		{
			cout << "load " << soildierDataDirStr << endl;
			FileJsonSeq soldierList = Common::loadFileJsonFromDir(soildierDataDirStr);
			armsHalfConfig.clear();
			for (unsigned i = 0; i < soldierList.size(); ++i)
			{
				Json::Value& man = soldierList[i];
				cfgManPtr config = Creator<ManConfig>::Create();
				config->armsType = man[armsTypeStr].asInt();
				config->relateBuild = (LAND::BuildingType)man["relateBuild"].asInt();
				for (unsigned i = 0; i < characterNum && i < man[soldierAddAttriStr].size(); ++i)
				{
					config->armsAdd[i] = man[soldierAddAttriStr][i].asInt();
				}
				armsHalfConfig[man[soldierIDStr].asInt()] = config;
			}
		};//���ֳ�ʼ��

		ConfigMap friendHalfConfig;
		{//�����ʼ��
			FileJsonSeq seq = Common::loadFileJsonFromDir("./instance/friendship/");
			for (unsigned i = 0; i < seq.size(); ++i)
			{
				Json::Value& json = seq[i];
				cfgManPtr config = Creator<ManConfig>::Create();
				config->manID = json["rawID"].asInt();
				for (unsigned idx = 0; idx < json["data"].size(); ++idx)
				{
					Json::Value& json_type = json["data"][idx];
					const int typeID = json_type["id"].asInt();
					ManConfig::LevelList TypeList;
					for (unsigned idx_level = 0; idx_level < json_type["level"].size(); ++idx_level)
					{
						typedef ManConfig::FriendLevel ThisLevel;
						ThisLevel level;
						Json::Value& json_level = json_type["level"][idx_level];
						//����
						typedef ManConfig::FriendLevel::Condition ThisConfition;
						for (unsigned idx_cdi = 0; idx_cdi < json_level["condition"].size(); ++idx_cdi)
						{
							Json::Value& json_condition = json_level["condition"][idx_cdi];
							ThisConfition cdi;
							cdi.rawID = json_condition[0u].asInt();
							cdi.needQuality = json_condition[1u].asInt();
							level.ConditionList.push_back(cdi);
						}
						//����
						typedef ManConfig::FriendLevel::Cost ThisCost;
						for (unsigned idx_cost = 0; idx_cost < json_level["cost"].size(); ++idx_cost)
						{
							Json::Value& json_cost = json_level["cost"][idx_cost];
							ThisCost cost;
							cost.typeID = json_cost[0u].asInt();
							if (cost.typeID == ACTION::item)
							{
								cost.data.Item.itemID = json_cost[1u].asInt();
								cost.data.Item.itemNum = json_cost[2u].asUInt();
							}
							else
							{
								cost.data.Res.resNum = json_cost[1u].asInt();
							}
							level.CostList.push_back(cost);
						}
						//��ֵ�ӳ�
						for (unsigned idx_attri = 0; idx_attri < json_level["attri"].size(); ++idx_attri)
						{
							Json::Value& json_attri = json_level["attri"][idx_attri];
							const int attri_sign = json_attri[0u].asInt();
							if (attri_sign < 0 || attri_sign >= characterNum)continue;
							AttriBase attri;
							attri.idx = AttributeIDX(attri_sign);
							attri.val = json_attri[1u].asInt();
							level.AttriList.push_back(attri);
						}
						TypeList.push_back(level);
					}
					config->Friends[typeID] = TypeList;
				}
				friendHalfConfig[config->manID] = config;
			}
		};

		{
			cout << "load " << pilotDataDirStr << endl;
			FileJsonSeq manList = Common::loadFileJsonFromDir(pilotDataDirStr);
			for (unsigned i = 0; i < manList.size(); ++i)
			{
				Json::Value& man = manList[i];
				cfgManPtr config = Creator<ManConfig>::Create();
				int armsID = man[soldierIDStr].asInt();
				{//�������ݴ���
					ConfigMap::iterator it = armsHalfConfig.find(armsID);
					if (it != armsHalfConfig.end()) {
						const cfgManPtr soldierCfg = it->second;
						memcpy(config->armsAdd, soldierCfg->armsAdd, sizeof(config->armsAdd));
						config->armsType = soldierCfg->armsType;
						config->relateBuild = soldierCfg->relateBuild;
					}
				};
				config->manID = man[manIDStr].asInt();
				{//�������ݴ���
					ConfigMap::iterator it = friendHalfConfig.find(config->manID / 100);
					if (it != friendHalfConfig.end()) {
						const cfgManPtr soldierCfg = it->second;
						config->Friends = soldierCfg->Friends;
					}
				};
				if (config->manID < 100)
				{
					LogW << "man id cant letter than 100 ..." << config->manID << LogEnd;
					continue;
				}//�佫ID
				config->rating = man["rating"].asInt();
				config->faceID = man["faceID"].asInt();
				config->manType = man[manTypeStr].asInt();
				config->manDuty = man[manDutyStr].asInt();
				config->addRes = man[manAddResStr].asInt();
				config->costRes = man[manCostResStr].asInt();
				config->appoint = man[manAppointStr].asUInt();
				config->manQuality = man[manQuality].asInt();
				for (unsigned n = 0; n < characterNum && n < man[manInitialStr].size(); ++n)
				{
					config->inital[n] = man[manInitialStr][n].asInt();
				}//��ʼ����//30������
				for (unsigned n = 0; n < characterNum && n < man[manGrowUpStr].size(); ++n)
				{
					config->grow[n] = man[manGrowUpStr][n].asDouble();
				}//�ɳ�����//30������
				if (man.isMember(manAttriStr) && !man[manAttriStr].isNull() && !man[manAttriStr].empty())
				{
					config->upStars = true;
					for (unsigned c = 0; c < starsAttriNum && c < man[manAttriStr].size(); ++c)
					{
						for (unsigned n = 0; n < characterNum && n < man[manAttriStr][c]["add"].size(); ++n)
						{
							config->manAttri[c][n] = man[manAttriStr][c]["add"][n].asInt();
						}//������������//30������
					}
				}
				for (unsigned n = 0; n < armsModulesNum; ++n)
				{
					config->armsModules[n] = man[armsModuleStr][n].asDouble();
				}//����ϵ��

				for (unsigned n = 0; n <= starsAttriNum; ++n)
				{
					vector< ManConfig::itemCost > vec;
					for (unsigned use = 0; use < man[manStarCostStr][n].size(); ++use)
					{
						vec.push_back(ManConfig::itemCost(man[manStarCostStr][n][use]["id"].asInt(), man[manStarCostStr][n][use]["n"].asUInt()));
					}
					config->starUpCost.push_back(vec);
				}

				config->TrainList.clear();
				config->mapTrain.clear();
				for (unsigned n = 0; n < man[manTrainStr].size(); ++n)
				{
					unsigned idx = man[manTrainStr][n][0u].asUInt();
					if (idx >= characterNum)continue;
					config->TrainList.push_back(ManConfig::TrainData((AttributeIDX)idx, man[manTrainStr][n][1u].asUInt()));
					config->mapTrain[(AttributeIDX)idx] = ManConfig::TrainData((AttributeIDX)idx, man[manTrainStr][n][1u].asUInt());
				}
				
				//����
				config->holdMorale = man["holdMorale"].asBool();
				config->skill_1 = man[manSkill1Str].asInt();
				config->skill_2 = man[manSkill2Str].asInt();

				config->soulItemID = man["soulID"].asInt();
				config->transferItemNum = man["soulNum"].asUInt();
				config->combineItemNum = man["combine"].asUInt();

				//����
				// 			if (!pilot[pilotResistStr].isNull())
				// 			{
				// 				for (unsigned i = 0; i < pilot[pilotResistStr].size(); ++i)
				// 				{
				// 					pilotG.resistList.insert(pilot[pilotResistStr][i].asInt());
				// 				}
				// 			}

				mapMan[config->manID] = config;
			}
		};//�佫��ʼ��


		{//������ӳ�
			Json::Value json = Common::loadJsonFile("./instance/manconfig/fly.json");
			FlyExp.clear();
			for (unsigned i = 0; i < json.size(); ++i)
			{
				Json::Value& sgJson = json[i];
				FlyExp[sgJson[0u].asInt()] = sgJson[1u].asInt();
			}
		};

		{//����������������
			Json::Value json = Common::loadJsonFile("./instance/manconfig/train_cost.json");
			TrainCost.clear();
			for (unsigned i = 0; i < json.size() && i < characterNum; ++i)
			{
				Json::Value& sgJson = json[i];
				vector<int> cost;
				for (unsigned n = 0; n < sgJson.size(); ++n)
				{
					cost.push_back(sgJson[n].asInt());
				}
				TrainCost.push_back(cost);
			}
		};

	}

	const cfgManPtr man_system::getConfig(const int manID)
	{
		ConfigMap::iterator it = mapMan.find(manID);
		if (it != mapMan.end())return it->second;
		return cfgManPtr();
	}
}

#pragma once

#include <boost/bind.hpp>
#include <boost/function.hpp>
#include <boost/thread/mutex.hpp>
#include <boost/unordered_map.hpp>
#include <boost/unordered_set.hpp>
#include "core_helper.h"
#include <exception>
#include "commom.h"
#include "inter_event.h"

using namespace std;
using namespace gg;

namespace gg
{
	class game;
	class playerManager;
}

struct structTimer;
namespace TIMER
{
	const static unsigned TimerErrorID = 0xFFFFFFFF;
	typedef boost::function<void(const structTimer&)> Handler;
}

class TimerIdentify
{
public:
	TimerIdentify(const int id);
	~TimerIdentify();
	void delTimer();
	const int IDTimer;//ID
private:
};
BOOSTSHAREPTR(TimerIdentify, ptrTimerIdentify);

struct structTimer
{
	structTimer(ptrTimerIdentify id, TIMER::Handler h, const unsigned tt, const int eid);
	ptrTimerIdentify timerID;//��ʱ��ID
	TIMER::Handler handler;//���÷���
	unsigned tickTime;//����ʱ��
	unsigned postTime;//�׳�ʱ��
	int eventID;
};
BOOSTSHAREPTR(structTimer, ptr_structTimer);

namespace TIMER
{
	enum CycleType
	{
		every_ntime,//ÿһ���´�ʱ��
		every_pertime,
	};

	class CycleTime
	{
	public://0ÿ��һ��ʱ��� 1ÿn��ʱ���
		CycleTime(Handler h, const int eID, const CycleType t = every_ntime, const int a = 1)
			: handler(h), eventID(eID), type(t), arg(a){}
		void run(const structTimer&);

	private:
		Handler handler;
		const CycleType type;
		const int arg;
		const int eventID;
	};
	BOOSTSHAREPTR(CycleTime, CTPtr);
}

class Timer
{
	friend class TimerIdentify;
	friend class TIMER::CycleTime;
	friend class gg::game;
	friend class gg::playerManager;
private:
	//ID������
	static std::vector<unsigned> _IDCreator;
	static unsigned _IDBegin;
	static void RecoverTimerID(const unsigned ID);
	static unsigned PopID()
	{
		if (_IDBegin == TIMER::TimerErrorID)return TIMER::TimerErrorID;
		if (_IDCreator.empty())return _IDBegin++;
		unsigned ID = _IDCreator.back();
		_IDCreator.pop_back();
		return ID;
	}
	//�ص��б�
	struct Aes
	{
		bool operator()(const ptr_structTimer left, const ptr_structTimer right)const
		{
			if (left->tickTime != right->tickTime)return left->tickTime < right->tickTime;
			return left->timerID->IDTimer < right->timerID->IDTimer;
		}
	};
	typedef std::set<ptr_structTimer, Timer::Aes> CallList;
	static CallList _callList;
	typedef boost::unordered_map<unsigned, ptr_structTimer> CallMap;
	static CallMap _callMap;
	static void AddTickImpl(ptr_structTimer tD)
	{
		_callList.insert(tD);
		_callMap[tD->timerID->IDTimer] = tD;
	}
	static void delTickImpl(const int timerID);
private:
	static void _InternalAddEvent(TIMER::Handler handler, const int eventID, const unsigned tickTime, ptrTimerIdentify timerID)//��ѭ���þ�ID, ������
	{
		if (timerID->IDTimer == TIMER::TimerErrorID)return;
		ptr_structTimer ptr = Creator<structTimer>::Create(timerID, handler, tickTime, eventID);
		TimerPost(boost::bind(&Timer::AddTickImpl, ptr));
	}
	static ptrTimerIdentify _InternalAddEvent(TIMER::Handler handler, const int eventID, const unsigned tickTime)
	{
		const unsigned ID = PopID();
		if (ID == TIMER::TimerErrorID)return ptrTimerIdentify();
		ptrTimerIdentify ptr_id = Creator<TimerIdentify>::Create(ID);
		ptr_structTimer ptr = Creator<structTimer>::Create(ptr_id, handler, tickTime, eventID);
		TimerPost(boost::bind(&Timer::AddTickImpl, ptr));
		return ptr_id;
	}
	static void TickEvent(const ptr_structTimer timerData);
	static void EventUpdate();
	static void StartTimer()
	{
		TimerPost(boost::bind(&Timer::EventUpdate));
	}
	static void ClearTimer()
	{
		_callList.clear();
		_callMap.clear();
		_IDCreator.clear();
		_IDBegin = 0;
	}
	public:
		static ptrTimerIdentify AddEventSeconds(TIMER::Handler handler, const int eventID, const unsigned seconds)
		{
			unsigned tickTime = seconds + Common::gameTime();
			return _InternalAddEvent(handler, eventID, tickTime);
		}
		static ptrTimerIdentify AddEventTickTime(TIMER::Handler handler, const int eventID, const unsigned tickTime)
		{
			return _InternalAddEvent(handler, eventID, tickTime);
		}
		// ÿ����һ��ʱ��㴥��
		static ptrTimerIdentify AddEventNextTimeCT(TIMER::Handler handler, const int eventID, const unsigned tickTime, const int offset = 0)
		{
			TIMER::CTPtr ptr(Creator<TIMER::CycleTime>::Create(handler, eventID, TIMER::every_ntime, offset));
			return _InternalAddEvent(boostBind(TIMER::CycleTime::run, ptr, _1), eventID, tickTime);
		}
		//��ÿ�δ�����ʱ���Ϊ׼+ƫ��ʱ��
		static ptrTimerIdentify AddEventPerTimeCT(TIMER::Handler handler, const int eventID, const unsigned tickTime, const int offset = 0)
		{
			TIMER::CTPtr ptr(Creator<TIMER::CycleTime>::Create(handler, eventID, TIMER::every_pertime, offset));
			return _InternalAddEvent(boostBind(TIMER::CycleTime::run, ptr, _1), eventID, tickTime);
		}
};

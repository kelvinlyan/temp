//###################################
//create by Jim
//2015-11-24
//###################################

#pragma once

#include "commom.h"

namespace gg
{
	class accumulatedCD
	{
	public:
		accumulatedCD(const unsigned ll_) :LockLimit_(ll_)
		{
			CD_ = 0;
			Lock_ = false;
		}
		accumulatedCD(const unsigned ll_, const unsigned cd, const bool l) :LockLimit_(ll_)
		{
			CD_ = cd;
			Lock_ = l;
		}
		inline unsigned CD(){ return CD_; }
		bool Lock()
		{
			_Refresh();
			return Lock_; 
		}
		bool AddCD(const unsigned cd)
		{
			_AddCD(cd);
			return !Lock_;
		}
		accumulatedCD& operator=(const int cd)
		{
			CD_ = (unsigned)cd;
			return *this;
		}
		accumulatedCD& operator=(const unsigned cd)
		{
			CD_ = cd;
			return *this;
		}
		accumulatedCD& operator=(const bool l)
		{
			Lock_ = l;
			return *this;
		}
		operator bool()
		{
			return !Lock();
		}
		void Clear()
		{
			CD_ = 0;
			Lock_ = false;
		}
	private:
		void _AddCD(const unsigned cd)
		{
			_Refresh();
			unsigned now = Common::gameTime();
			if (now > CD_)CD_ = now;
			CD_ += cd;
			if (CD_ > now && CD_ - now > LockLimit_)
			{
				Lock_ = true;
			}
		}
		void _Refresh()
		{
			if (Common::gameTime() > CD_)
			{
				Lock_ = false;
			}
		}
		unsigned CD_;
		bool Lock_;
		const unsigned LockLimit_;
	};
}
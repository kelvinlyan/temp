//###################################
//motify by Jim
//2016-09-28
//###################################
#pragma once

#include "action_system.h"
#include "broadcast_check.h"
#include "dbDriver.h"
#include "commom.h"

#define search_sys (*gg::search_system::_Instance)

namespace gg
{
	namespace Search
	{
		enum
		{
			NotSet = 0,
			WeiWang,//������ȡ
			Cash,//��ҳ�ȡ

			ShopItemCount = 8,
		};

		struct ShopData
		{	
			ShopData(Json::Value& info);

			int _id;
			int	_consume_con;
			int _buy_times;
			int	_weight;
			Kingdom::NATION _kingdom_id;
			ACTION::BoxList _box;
		};

	};
	
	BOOSTSHAREPTR(Search::ShopData, SearchShopData);
	UNORDERMAP(int, SearchShopData, SearchShopMap);
	STDVECTOR(SearchShopData, SearchShopList);

	class search_system
	{
		public:
			STDVECTOR(int, IdList);

			static search_system* const _Instance;
			void initData();
			

			DeclareRegFunction(getData);
			DeclareRegFunction(searchFor_WeiWang);
			DeclareRegFunction(searchFor_Cash);

			//Ѱ���̵����
			DeclareRegFunction(WWshopInfo);
			DeclareRegFunction(WWbuy);
			DeclareRegFunction(WWflush);

			DeclareRegFunction(CSshopInfo);
			DeclareRegFunction(CSbuy);
			DeclareRegFunction(CSflush);

			SearchShopData getWWShopData(int id);
			SearchShopData getCSShopData(int id);
			void getWWShopList(int nation, IdList& id_list);
			void getCSShopList(int nation, IdList& id_list);
			int getWWFlushCost(unsigned times);
			int getCSFlushCost(unsigned times);
			void onItemBroadcast(playerDataPtr player, const unsigned channel, int item_id);

		private:
			void loadFile();

		private:


			acPtrList _WeiWangBoxes;
			acPtrList _CashBoxes;

			//�ض��佫
			//acPtrList _SPWeiWangBoxes;//����û�бض��佫
			acPtrList _SPCashBoxes;

			//��������
			std::vector< acPtrList > _FirstWWBoxes;
			std::vector< acPtrList > _FirstCSBoxes;
			

			//�������
			SearchShopMap _ww_shop_map;

			SearchShopList _ww_shopRd[Kingdom::nation_total];
			SearchShopList _ww_shopFix[Kingdom::nation_total];
			unsigned _ww_weight[Kingdom::nation_total];
			std::vector<int> _ww_flush_costs;

			//�����̵�
			SearchShopMap _cs_shop_map;

			SearchShopList _cs_shopRd[Kingdom::nation_total];
			SearchShopList _cs_shopFix[Kingdom::nation_total];
			unsigned _cs_weight[Kingdom::nation_total];
			std::vector<int> _cs_flush_costs;
	};
}

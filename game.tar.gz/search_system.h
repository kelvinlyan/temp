//###################################
//motify by Jim
//2016-09-28
//###################################
#pragma once

#include "action_system.h"
#include "broadcast_check.h"
#include "dbDriver.h"
#include "commom.h"

#define search_sys (*gg::search_system::_Instance)

namespace gg
{
	namespace Search
	{
		enum
		{
			NotSet = 0,
			WeiWang,//������ȡ
			Cash,//��ҳ�ȡ
		};

	};
	
	class search_system
	{
		public:
			STDVECTOR(int, IdList);

			static search_system* const _Instance;
			void initData();
			

			DeclareRegFunction(getData);
			DeclareRegFunction(searchFor_WeiWang);
			DeclareRegFunction(searchFor_Cash);

		private:
			void loadFile();

		private:


			acPtrList _WeiWangBoxes;
			acPtrList _CashBoxes;

			//�ض��佫
			//acPtrList _SPWeiWangBoxes;//����û�бض��佫
			acPtrList _SPCashBoxes;

			//��������
			std::vector< acPtrList > _FirstWWBoxes;
			std::vector< acPtrList > _FirstCSBoxes;
	};
}

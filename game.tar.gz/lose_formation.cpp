#include "lose_formation.h"
#include "playerManager.h"
#include "action_system.h"
#include "shop_mgr.h"

namespace gg
{
	struct BaseConfig
	{
		int _config_id;//ID
		unsigned _config_level;//��ǰ�ȼ�
		int _limit_id;//����ID
		unsigned _limit_level;//���Ƶȼ� >=
		std::vector<Resource> _cost_data;//����
		int _attribute_idx;
		int _attribute_val;
	};
	static vector<BaseConfig> static_base_level_config[playerLoseFM::BaseAttributeNum];//7����������

	struct CustomConfig
	{
		int _config_id;
		unsigned _total_limit;//�ܵȼ�����
		int _cost_gold;//��������
		unsigned _index_hole;//λ�ÿ�
		vector<int> _attribute_idx_list;//���������б�
		int _attribute_max;//���Ե����ֵ <=
		double _attribute_per_value;//ÿ�����Ե��ṩ��ս����
		bool _is_default;//�Ƿ�ΪĬ�Ͽ����Ƽ�
		int _initial_attribute;//Ĭ������
		//��ͨϴ��//���ϴ��
		struct wash_data
		{
			wash_data()
			{
				_sucess_rate = 0;
				_total_weight = 0;
				_wash_list.clear();
			}
			int _sucess_rate;
			int _total_weight;
			struct wash_weight
			{
				wash_weight(const int ww = 0, const int wv = 0)
				{
					_wash_weight = ww;
					_wash_value = wv;
				}
				int _wash_weight;
				int _wash_value;
			};
			vector<wash_weight> _wash_list;
		};
		wash_data common_wash[10], gold_wash[10];
	};
	static vector<CustomConfig> static_custom_config[playerLoseFM::UseHoleNum];//12��ϴ������
	static int static_default_use[playerLoseFM::UseHoleNum] = {-1, -1, -1};

	void playerLoseFM::initData()
	{
		cout << "load lose formation config ..." << endl;
		//��������
		for (int i = 0; i < BaseAttributeNum; ++i)
		{
			Json::Value json = Common::loadJsonFile("./instance/lose_formation/base_attribute/"
				+ Common::toString(i) + ".json"
			);
			for (unsigned idx = 0; idx < json.size(); ++idx)
			{
				Json::Value& single_json = json[idx];
				BaseConfig config;
				config._config_id = i;
				config._config_level = idx;
				config._limit_id = single_json["limit_id"].asInt();
				config._limit_level = single_json["limit_level"].asUInt();
				const int attri = single_json["attribute_idx"].asInt();
				if (attri < 0 || attri >= characterNum)config._attribute_idx = idx_hp;
				else config._attribute_idx = attri;
				config._attribute_val = single_json["attribute_val"].asInt();
				for (unsigned cd_idx = 0; cd_idx < single_json["cost"].size(); ++cd_idx)
				{
					Json::Value& json_cost = single_json["cost"][cd_idx];
					config._cost_data.push_back(shops_mgr.ResolveObjectJson(json_cost));
				}
				static_base_level_config[i].push_back(config);
			}
		}

		//ϴ��
		{
			FileJsonSeq vec = Common::loadFileJsonFromDir("./instance/lose_formation/custom_attribute/");
			for (unsigned i = 0; i < vec.size(); ++i)
			{
				Json::Value& json = vec[i];
				CustomConfig config;
				config._config_id = json["custom_id"].asInt();
				config._index_hole = config._config_id / 100;
				if (config._index_hole < 0 || config._index_hole >= UseHoleNum)continue;
				config._total_limit = json["total_limit"].asUInt();
				config._cost_gold = json["cost_gold"].asInt();
				config._is_default = json["is_default"].asBool();
				config._initial_attribute = json["initial_attribute"].asInt();
				config._attribute_idx_list.clear();
				for (unsigned attri_idx = 0; attri_idx < json["attribute_idx"].size(); ++attri_idx)
				{
					const int attri_type = json["attribute_idx"][attri_idx].asInt();
					if (attri_type < 0 || attri_type >= characterNum)continue;
					config._attribute_idx_list.push_back(attri_type);
				}
				config._attribute_max = json["attribute_max"].asInt();
				config._attribute_per_value = json["attribute_per"].asDouble();
				for (unsigned cd_idx = 0; cd_idx < 10; ++cd_idx)
				{
					Json::Value& json_wash = json["common"][cd_idx];
					CustomConfig::wash_data& data = config.common_wash[cd_idx];
					data._sucess_rate = json_wash["sucess"].asInt();
					Json::Value& json_weight = json_wash["weight"];
					for (unsigned wgh_idx = 0; wgh_idx < json_weight.size(); ++wgh_idx)
					{
						const int weight = json_weight[wgh_idx]["weight"].asInt();
						const int value = json_weight[wgh_idx]["value"].asInt();
						data._wash_list.push_back((weight, value));
					}
				}
				for (unsigned cd_idx = 0; cd_idx < 10; ++cd_idx)
				{
					Json::Value json_wash = json["gold"][cd_idx];
					CustomConfig::wash_data& data = config.gold_wash[cd_idx];
					data._sucess_rate = json_wash["sucess"].asInt();
					Json::Value& json_weight = json_wash["weight"];
					for (unsigned wgh_idx = 0; wgh_idx < json_weight.size(); ++wgh_idx)
					{
						const int weight = json_weight[wgh_idx]["weight"].asInt();
						const int value = json_weight[wgh_idx]["value"].asInt();
						data._wash_list.push_back((weight, value));
					}
				}
				if ((int)static_custom_config[config._index_hole].size() == config._config_id)
				{
					static_custom_config[config._index_hole].push_back(config);
					if (config._is_default)static_default_use[config._index_hole] = config._config_id;
				}
			}
		};
	}

	static bool InvaildID(const int id)
	{
		const int hole = id / 100;
		if (hole < 0 || hole >= playerLoseFM::UseHoleNum)return false;
		const int config_size = (int)static_custom_config[hole].size();
		const int idx = id % 100;
		return idx < config_size;
	}

	int playerLoseFM::wash_custom_attribute(const int id, const bool gold_mode, Json::Value& res_json)
	{
		if (!InvaildID(id))return err_illedge;
		if ((gold_mode ? Own().Res().getCash() < 30 : Own().Res().getSilver() < 30000))
			return gold_mode ? err_cash_not_enough : err_silver_not_enough;
		_custom_data& data = _custom_attribute[id / 100][id % 100];
		if (false == data._open)return err_illedge;//��û�м���
		const CustomConfig& config = static_custom_config[id / 100][id % 100];
		if (data._val >= config._attribute_max)return err_illedge;
		CustomConfig::wash_data const *pointer = config.common_wash;
		if (gold_mode)pointer = config.gold_wash;
		unsigned idx = int((double)data._val / config._attribute_max) / 10;
		idx = idx >= 10 ? 9 : idx;
		const CustomConfig::wash_data& use_wash = pointer[idx];
		if (!Common::randomOk(use_wash._sucess_rate))return err_lose_formation_custom_wash_failed;
		const int weight = Common::randomBetween(1, use_wash._total_weight);
		int collect_weight = 0;
		for (unsigned i = 0; i < use_wash._wash_list.size(); ++i)
		{
			const CustomConfig::wash_data::wash_weight& wash_use_data = use_wash._wash_list[i];
			collect_weight += wash_use_data._wash_weight;
			if (collect_weight >= weight)
			{
				const int old_val = data._val;
				data._val += wash_use_data._wash_value;
				data._val = data._val > config._attribute_max ? config._attribute_max : data._val;
				res_json = wash_use_data._wash_value;
				//�����滻
				for (unsigned i = 0; i < config._attribute_idx_list.size(); ++i)
				{
					_attribute[config._attribute_idx_list[i]] -= old_val;
					_attribute[config._attribute_idx_list[i]] += data._val;
				}
				_sign_auto();
				Log(DBLOG::strLogLoseFormation, Own().getOwnDataPtr(), 2, id, old_val, data._val);
				break;
			}
		}
		if (id == _custom_use[id / 100])
		{
			onRecalFormation();
		}
		gold_mode ? Own().Res().alterCash(-30) : Own().Res().alterSilver(-30000);
		return res_sucess;
	}

	int playerLoseFM::active_custom_attribute(const int id)
	{
		if (!InvaildID(id))return err_illedge;
		_custom_data& data = _custom_attribute[id / 100][id % 100];
		if (data._open)return err_illedge;//�Ѿ�����
		const CustomConfig& config = static_custom_config[id / 100][id % 100];
		if (data._idx != id)return err_illedge;
		if (_total_level < config._total_limit)return err_lose_formation_total_level_too_low;
		if (Own().Res().getCash() < config._cost_gold)return err_cash_not_enough;
		Own().Res().alterCash(-config._cost_gold);
		data._val = config._initial_attribute;
		data._open = true;
		_sign_auto();
		Log(DBLOG::strLogLoseFormation, Own().getOwnDataPtr(), 1, id, config._cost_gold);
		return res_sucess;
	}

	int playerLoseFM::select_custom_attribute(const int id)
	{
		if (!InvaildID(id))return err_illedge;
		const _custom_data& new_data = _custom_attribute[id / 100][id % 100];
		if (false == new_data._open)return err_illedge;
		const int old_id = _custom_use[id / 100];
		if (old_id == id)return err_illedge;
		if (InvaildID(old_id))
		{
			const _custom_data& old_data = _custom_attribute[old_id / 100][old_id % 100];
			const CustomConfig& old_config = static_custom_config[old_id / 100][old_id % 100];
			for (unsigned i = 0; i < old_config._attribute_idx_list.size(); ++i)
			{
				_attribute[old_config._attribute_idx_list[i]] -= old_data._val;
			}
		}
		const CustomConfig& new_config = static_custom_config[id / 100][id % 100];
		for (unsigned i = 0; i < new_config._attribute_idx_list.size(); ++i)
		{
			_attribute[new_config._attribute_idx_list[i]] -= new_data._val;
		}
		_custom_use[id / 100] = id;
		onRecalFormation();
		_sign_auto();
		return res_sucess;
	}

	unsigned playerLoseFM::getBaseLV(const int id)
	{
		if (id < 0 || id >= (int)_base_level.size())return 0;
		return _base_level[id];
	}

	void playerLoseFM::checkDefaultCustom(const bool recal /* = true */)
	{
		for (int i = 0; i < UseHoleNum; i++)
		{
			const int check_id = static_default_use[i];
			if (!InvaildID(check_id))continue;
			const CustomConfig& config = static_custom_config[check_id / 100][check_id % 100];
			_custom_data& data = _custom_attribute[check_id / 100][check_id % 100];
			if (false == data._idx)//û�м���
			{
				data._val = config._initial_attribute;
				data._open = true;
				if (!InvaildID(_custom_use[check_id / 100]))
				{
					_custom_use[check_id / 100] = data._idx;
					if (recal)//���¼���ս����
					{
						onRecalFormation();
					}
				}
				_sign_auto();
			}
		}
	}

	int playerLoseFM::upgrade_base_level(const int id, const unsigned num, Json::Value& res_json)
	{
		if (id < 0 || id >= (int)_base_level.size() || num < 1)return err_illedge;
		int last_res = res_sucess;
		unsigned sucess_count = 0;
		const unsigned begin_lv = getBaseLV(id);
		const vector<BaseConfig>& _config_vec = static_base_level_config[id];
		const BaseConfig& begin_config = _config_vec[begin_lv];
		playerDataPtr player = Own().getOwnDataPtr();
		for (unsigned i = 0; i < num; ++i)
		{
			const unsigned check_level = begin_lv + i + 1;
			if (check_level >= _config_vec.size())
			{
				last_res = err_lose_formation_id_max;
				break;
			}
			const BaseConfig& config = _config_vec[check_level];
			if (getBaseLV(config._limit_id) < config._limit_level)
			{
				last_res = err_lose_formation_front_too_low;
				break;
			}
			for (unsigned cost_idx = 0; cost_idx < config._cost_data.size(); ++cost_idx)
			{
				const Resource& cost_val = config._cost_data[cost_idx];
				const int res_check_code = shops_mgr.checkCommon(cost_val, player);
				if (res_sucess != res_check_code)
				{
					goto res_check_break;
				}
			}
			for (unsigned cost_idx = 0; cost_idx < config._cost_data.size(); ++cost_idx)
			{
				const Resource& cost_val = config._cost_data[cost_idx];
				shops_mgr.cutCommon(cost_val, player);
			}
			++sucess_count;
			continue;
		res_check_break:
			break;
		}
		if (sucess_count > 0)
		{
			res_json = sucess_count;
			_base_level[id] = begin_lv + sucess_count;
			_total_level += sucess_count;
			//�����Ƿ����µĸ�������Ĭ�ϼ���
			checkDefaultCustom(false);
			//���¼�������
			_attribute[begin_config._attribute_idx] -= begin_config._attribute_val;
			const BaseConfig& config = _config_vec[begin_lv + sucess_count];
			_attribute[config._attribute_idx] += config._attribute_val;
			onRecalFormation();
			_sign_auto();
			Log(DBLOG::strLogLoseFormation, Own().getOwnDataPtr(), 0, begin_lv, sucess_count, begin_lv + sucess_count);
		}
		return sucess_count < 1 ? last_res : res_sucess;
	}


	//////////////////////////////////////////////////////////////////////////
	playerLoseFM::playerLoseFM(playerData* const own) : _auto_player(own)
	{
		_is_open = false;
		_total_level = 0;
		memset(_attribute, 0x0, sizeof(_attribute));
		_base_level.clear();
		_base_level.resize(BaseAttributeNum, 0);
		for (unsigned i = 0; i < UseHoleNum; ++i)
		{
			_custom_attribute[i].clear();
			_custom_attribute[i].reserve(static_custom_config[i].size());
			for (unsigned n = 0; n < static_custom_config[i].size(); ++n)
			{
				_custom_attribute[i].push_back((static_custom_config[i][n]._config_id));
			}
		}
		memset(_custom_use, -1, sizeof(_custom_use));
	}

	void playerLoseFM::classLoad()
	{
		mongo::BSONObj obj = db_mgr.FindOne(DBN::dbPlayerLoseFormation, BSON(strPlayerID << Own().ID()));
		if (obj.isEmpty())return;
		_base_level.clear();
		_base_level.resize(BaseAttributeNum, 0);
		memset(_attribute, 0x0, sizeof(_attribute));
		_total_level = 0;
		vector<mongo::BSONElement> base_arr = obj["base"].Array();
		for (unsigned i = 0; i < base_arr.size(); ++i)
		{
			mongo::BSONElement& elem = base_arr[i];
			const int id = elem["i"].Int();
			const unsigned lv = elem["l"].Int();
			if (id < 0 || id >= BaseAttributeNum)continue;
			_base_level[id] = lv;
			_total_level += lv;
			//��������
			const BaseConfig& config = static_base_level_config[id][lv];
			_attribute[config._attribute_idx] += config._attribute_val;
		}
		vector<mongo::BSONElement> cus_arr = obj["cus"].Array();
		for (unsigned i = 0; i < cus_arr.size(); ++i)
		{
			mongo::BSONElement& elem = cus_arr[i];
			const int id = elem["i"].Int();
			const unsigned val = elem["v"].Int();
			const bool op = elem["o"].Bool();
			if (!InvaildID(id))continue;
			_custom_attribute[id / 100][id % 100] = (id, val);
		}
		vector<mongo::BSONElement> use_arr = obj["use"].Array();
		for (unsigned i = 0; i < use_arr.size(); ++i)
		{
			mongo::BSONElement& elem = use_arr[i];
			const int id = elem.Int();
			if (!InvaildID(id))continue;
			_custom_use[i] = id;
			//��������
			const CustomConfig& config = static_custom_config[id / 100][id % 100];
			const _custom_data& data = _custom_attribute[id / 100][id % 100];
			for (unsigned i = 0; i < config._attribute_idx_list.size(); ++i)
			{
				_attribute[config._attribute_idx_list[i]] += data._val;
			}
		}
	}

	int playerLoseFM::battle_value()
	{
		int value = _total_level * 2;
		for (unsigned i = 0; i < 3; ++i)
		{
			const int id = _custom_use[i];
			if (!InvaildID(id))continue;
			const CustomConfig& config = static_custom_config[id / 100][id % 100];
			const _custom_data& data = _custom_attribute[id / 100][id % 100];
			value += int(data._val * config._attribute_per_value);
		}
		return value;
	}

	void playerLoseFM::_auto_update()
	{
		qValue base_json(qJson::qj_array);
		for (unsigned i = 0; i < _base_level.size(); ++i)
		{
			base_json.append(qValue(qJson::qj_array).append(i).append(_base_level[i]));
		}
		qValue custom_json(qJson::qj_array);
		for (unsigned n = 0; n < UseHoleNum; ++n)
		{
			const _custom_attribute_type& data_list = _custom_attribute[n];
			for (unsigned i = 0; i < data_list.size(); ++i)
			{
				base_json.
					append(qValue(qJson::qj_array).
					append(data_list[i]._idx).
					append(data_list[i]._val).
					append(data_list[i]._open ? 1 : 0)
					);
			}
		}
		qValue select_json(qJson::qj_array);
		for (unsigned i = 0; i < 3; ++i)
		{
			select_json << _custom_use[i];
		}
		Own().sendToClientFillMsg(gate_client::player_lose_formation_data_resp,
				qValue(qJson::qj_array).append(0).append(
					qValue(qJson::qj_object).
					addMember("b",base_json).
					addMember("c",custom_json).
					addMember("u",select_json)
				)
			);
	}

	bool playerLoseFM::_auto_save()
	{
		mongo::BSONArrayBuilder base_arr;
		for (unsigned i = 0; i < _base_level.size(); ++i)
		{
			base_arr << BSON("i" << i << "l" << _base_level[i]);
		}
		mongo::BSONArrayBuilder custom_arr;
		for (unsigned n = 0; n < UseHoleNum; ++n)
		{
			const _custom_attribute_type& data_list = _custom_attribute[n];
			for (unsigned i = 0; i < data_list.size(); ++i)
			{
				custom_arr <<
					BSON(
						"i" << data_list[i]._idx <<
						"v" << data_list[i]._val <<
						"o" << data_list[i]._open
					);
			}
		}
		mongo::BSONArrayBuilder select_arr;
		for (unsigned i = 0; i < 3; ++i)
		{
			select_arr << _custom_use[i];
		}
		return db_mgr.SaveMongo(DBN::dbPlayerLoseFormation, BSON(strPlayerID << Own().ID()), 
			BSON(
				strPlayerID << Own().ID() << "base" << base_arr.arr() 
				<< "cus" << custom_arr.arr() << "use" << select_arr.arr()
			)
			);
	}


}
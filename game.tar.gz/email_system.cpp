#include "email_system.h"

namespace gg
{
	email_system* const email_system::_Instance = new email_system();

	void email_system::initData()
	{
		classLoad();
	}
	
	void email_system::playerInfoReq(net::Msg& m, Json::Value& r)
	{
		playerDataPtr d = player_mgr.getPlayer(m.playerID);
		if (!d) Return(r, err_illedge);

		r[strMsg][1u] = d->Email().getEmailList();
		Return(r, res_sucess);
	}

	void email_system::sendEmailReq(net::Msg& m, Json::Value& r)
	{
		playerDataPtr d = player_mgr.getPlayer(m.playerID);
		if (!d) Return(r, err_illedge);
		ReadJsonArray;
		const std::string& name = js_msg[0u].asString();
		const std::string& data = js_msg[1u].asString();
		
		playerDataPtr target = player_mgr.getPlayer(name);
		if (!target) Return(r, err_email_name_not_found);

		EmailPtr e = createGamer(d->Name(), data);
		target->Email().addEmail(e);
		Return(r, res_sucess);
	}

	void email_system::getPackageReq(net::Msg& m, Json::Value& r)
	{
		playerDataPtr d = player_mgr.getPlayer(m.playerID);
		if (!d) Return(r, err_illedge);
		ReadJsonArray;
		int res = res_sucess;
		ForEach(Json::Value, it, js_msg)
		{
			int id = (*it).asInt();
			Json::Value rw;
			res = d->Email().getPackage(id, rw);
			if (res == res_sucess)
			{
				r[strMsg][1u].append(id);
				combineActionRes(rw, r[strMsg][2u]);
			}
		}
		if (r[strMsg][1u].size() == 0)
			Return(r, res)
		else
			Return(r, res_sucess)
	}

	void email_system::redPointReq(net::Msg& m, Json::Value& r)
	{
		playerDataPtr d = player_mgr.getPlayer(m.playerID);
		if (!d) Return(r, err_illedge);
		
		d->Email().updateRedPoint();
	}

	void email_system::gmSendEmailReq(net::Msg& m, Json::Value& r)
	{
		ReadJsonArray;
		Json::Value& data = js_msg[0u];
		int type = data["ty"].asInt();
		if (type < 0 || type > 2)
			Return(r, err_illedge);
		const std::string& str = data["m"].asString();
		Json::Value param;
		param.append(str);
		EmailPtr e;
		if (data["rw"] != Json::nullValue && data["rw"].size() != 0)
		{
			Json::Value& rw = data["rw"];
			ForEach(Json::Value, it, rw)
			{
				Json::Value& act = (*it)["act"];
				act = jsonFormats2c(act);
			}
			e = createGmPackage(EmailDef::GmEmail, param, rw);
		}
		else
		{
			e = createSystem(EmailDef::GmEmail, param);
		}
		if (type == 0)
		{
			std::vector<int> pids;
			const Json::Value& pid_v = data["arg"];
			ForEachC(Json::Value, it, pid_v)
				pids.push_back((*it).asInt());
			sendToPart(pids, e);
		}
		else if (type == 1)
		{
			int nation = data["arg"][0u].asInt();
			sendToKingdom(nation, e);
		}
		else
		{
			sendToAll(e);
		}

		Return(r, res_sucess);
	}

	void email_system::sendToAll(EmailPtr& e)
	{
		CommonEmailPtr c = createAll(e);
		common_emails.insert(make_pair(c->getId(), c));
		saveDB(c);
		playerManager::playerDataVec vec = player_mgr.allOnline();
		ForEach(playerManager::playerDataVec, it, vec)
			(*it)->Email().addCommonEmail();
	}

	void email_system::sendToKingdom(int nation, EmailPtr& e)
	{
		CommonEmailPtr c = createNation(nation, e);
		common_emails.insert(make_pair(c->getId(), c));
		saveDB(c);
		playerManager::playerDataVec vec = player_mgr.nationOnline((Kingdom::NATION)nation);
		ForEach(playerManager::playerDataVec, it, vec)
			(*it)->Email().addCommonEmail();
	}

	void email_system::sendToPart(const std::vector<int>& player_list, EmailPtr& e)
	{
		CommonEmailPtr c = createPart(player_list, e);
		common_emails.insert(make_pair(c->getId(), c));
		saveDB(c);
		ForEachC(std::vector<int>, it, player_list)
		{
			playerDataPtr d = player_mgr.getOnlinePlayer(*it);
			if (d)
				d->Email().addCommonEmail();
		}
	}

	void email_system::sendToPlayer(int player_id, EmailPtr& e)
	{
		playerDataPtr d = player_mgr.getPlayer(player_id);
		if (!d) return;

		d->Email().addEmail(e);
	}

	unsigned email_system::getCommonId()
	{
		return ++common_email_id;
	}

	EmailPtr email_system::createSystem(const std::string& msg)
	{
		Json::Value m;
		m[EmailDef::MsgType] = EmailDef::Normal;
		m[EmailDef::ParamList].append(msg);
		return Creator<Email>::Create(Common::gameTime(), (int)EmailDef::System, "sys", m);
	}

	EmailPtr email_system::createSystem(int msg_type, const Json::Value& param_list)
	{
		Json::Value m;
		m[EmailDef::MsgType] = msg_type;
		m[EmailDef::ParamList] = param_list;
		return Creator<Email>::Create(Common::gameTime(), (int)EmailDef::System, "sys", m);
	}

	EmailPtr email_system::createGamer(const std::string& sender, const std::string& msg)
	{
		Json::Value m;
		m[EmailDef::MsgType] = EmailDef::Normal;
		m[EmailDef::ParamList].append(msg);
		return Creator<Email>::Create(Common::gameTime(), (int)EmailDef::Gamer, sender, m);
	}

	EmailPtr email_system::createPackage(int msg_type, const Json::Value& param_list, const Json::Value& reward)
	{
		Json::Value m;
		m[EmailDef::MsgType] = msg_type;
		m[EmailDef::ParamList] = param_list;
		Json::Value rw;
		rw[EmailDef::RewardType] = EmailDef::NormalReward;
		rw[EmailDef::ActionList] = reward;
		return Creator<Email>::Create(Common::gameTime(), (int)EmailDef::Package, "sys", m, rw);
	}
	
	EmailPtr email_system::createGmPackage(int msg_type, const Json::Value& param_list, const Json::Value& reward)
	{
		Json::Value m;
		m[EmailDef::MsgType] = msg_type;
		m[EmailDef::ParamList] = param_list;
		Json::Value rw;
		rw[EmailDef::RewardType] = EmailDef::GmGift;
		rw[EmailDef::GmGiftList] = reward;
		return Creator<Email>::Create(Common::gameTime(), (int)EmailDef::Package, "sys", m, rw);
	}

	EmailPtr email_system::createReport(int msg_type, const Json::Value& param_list, const std::string& report)
	{
		Json::Value m;
		m[EmailDef::MsgType] = msg_type;
		m[EmailDef::ParamList] = param_list;
		return Creator<Email>::Create(Common::gameTime(), (int)EmailDef::Report, "sys", m, report);
	}

	EmailPtr email_system::createFromBSON(const mongo::BSONElement& obj)
	{
		return Creator<Email>::Create(obj);
	}

	CommonEmailPtr email_system::createAll(EmailPtr& e)
	{
		return Creator<CommonEmail>::Create(e);
	}

	CommonEmailPtr email_system::createNation(int nation, EmailPtr& e)
	{
		return Creator<CommonEmail>::Create(nation, e);
	}

	CommonEmailPtr email_system::createPart(const std::vector<int>& parts, EmailPtr& e)
	{
		return Creator<CommonEmail>::Create(parts, e);
	}

	unsigned email_system::getCommonEmails(playerDataPtr d, int player_common_email_id, EmailVec& vec)
	{
		if (common_email_id == player_common_email_id)
			return common_email_id;

		for (CommonEmailMap::reverse_iterator it = common_emails.rbegin();
			it != common_emails.rend(); ++it)
		{
			if (it->first <= player_common_email_id)
				break;
			if (it->second->needed(d))
				vec.push_back(it->second->getEmail());
		}

		return common_email_id;
	}

	EmailPtr email_system::getCommonEmail(int id)
	{
		CommonEmailMap::iterator it = common_emails.find(id);
		if (it == common_emails.end())
			return EmailPtr();
		return it->second->getEmail();
	}

	void email_system::classLoad()
	{
		objCollection objs = db_mgr.Query(DBN::dbCommonEmails);

		common_email_id = 100000;

		ForEachC(objCollection, it, objs)
		{
			CommonEmailPtr c = Creator<CommonEmail>::Create(*it);	
			if ((int)common_email_id < c->getId())
				common_email_id = c->getId();
			if (c->outOfDate())
				LogI << "Email Out of Date: " << c->getId() << LogEnd;
			else
				common_emails.insert(make_pair(c->getId(), c));
		}
	}

	void email_system::saveDB(const CommonEmailPtr& c)
	{
		mongo::BSONObj key = BSON(EmailDef::Id << c->getId());
		mongo::BSONObj obj = c->toBSON();
		db_mgr.SaveMongo(DBN::dbCommonEmails, key, obj);
	}
}

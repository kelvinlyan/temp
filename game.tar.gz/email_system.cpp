#include "email_system.h"

namespace gg
{
	email_system* const email_system::_Instance = new email_system();

	void email_system::initData()
	{
		classLoad();
	}
	
	void email_system::playerInfoReq(net::Msg& m, Json::Value& r)
	{
		playerDataPtr d = player_mgr.getPlayer(m.playerID);
		if (!d) Return(r, err_illedge);

		r[strMsg][1u] = d->Email().getEmailList();
		Return(r, res_sucess);
	}

	void email_system::sendEmailReq(net::Msg& m, Json::Value& r)
	{
		playerDataPtr d = player_mgr.getPlayer(m.playerID);
		if (!d) Return(r, err_illedge);
		ReadJsonArray;
		const std::string& name = js_msg[0u].asString();
		const std::string& data = js_msg[1u].asString();
		
		playerDataPtr target = player_mgr.getPlayer(name);
		if (!target) Return(r, err_email_name_not_found);

		EmailPtr e = createGamer(d->Name(), data);
		target->Email().addEmail(e);
		Return(r, res_sucess);
	}

	void email_system::getPackageReq(net::Msg& m, Json::Value& r)
	{
		playerDataPtr d = player_mgr.getPlayer(m.playerID);
		if (!d) Return(r, err_illedge);
		ReadJsonArray;
		int res = res_sucess;
		ForEach(Json::Value, it, js_msg)
		{
			int id = (*it).asInt();
			Json::Value rw;
			res = d->Email().getPackage(id, rw);
			if (res == res_sucess)
			{
				r[strMsg][1u].append(id);
				combineActionRes(rw, r[strMsg][2u]);
			}
		}
		if (r[strMsg][1u].size() == 0)
			Return(r, res)
		else
			Return(r, res_sucess)
	}

	void email_system::redPointReq(net::Msg& m, Json::Value& r)
	{
		playerDataPtr d = player_mgr.getPlayer(m.playerID);
		if (!d) Return(r, err_illedge);
		
		d->Email().updateRedPoint();
	}

	void email_system::gmEmailInfoReq(net::Msg& m, Json::Value& r)
	{
		ReadJsonArray;
		int pid = js_msg[0u].asInt();
		int begin = js_msg[1u].asInt() * 20;
		
		if (pid == -1)
		{
			Json::Value& ref = r[strMsg][1u];
			ref["n"] = (unsigned)common_emails.size();
			int pos = 0;
			int end = begin + 20;
			for (CommonEmailMap::const_reverse_iterator it = common_emails.rbegin();
				it != common_emails.rend(); ++it)
			{
				if (pos++ < begin)
					continue;
				if (begin++ > end)
					break;
				ref["l"].append(it->second->getEmail()->toJson());
			}
		}
		else
		{
			playerDataPtr d = player_mgr.getPlayer(pid);
			if (!d) Return(r, err_illedge);

			r[strMsg][1u] = d->Email().getEmailList(begin, 20);
			Return(r, res_sucess);
		}
	}

	void email_system::gmRemoveEmailReq(net::Msg& m, Json::Value& r)
	{
		ReadJsonArray;
		int pid = js_msg[0u].asInt();
		int eid = js_msg[1u].asInt();
		int res;
		if (pid == -1)
		{
			res = removeCommonEmail(eid);
		}
		else
		{
			playerDataPtr d = player_mgr.getPlayer(pid);
			if (!d) Return(r, err_illedge);
			res = d->Email().removeEmail(eid);
		}
		Return(r, res);
	}

	void email_system::gmSendEmailReq(net::Msg& m, Json::Value& r)
	{
		ReadJsonArray;
		Json::Value& data = js_msg[0u];
		int type = data["ty"].asInt();
		if (type < 0 || type > 2)
			Return(r, err_illedge);
		const std::string& str = data["m"].asString();
		Json::Value param;
		param.append(str);
		EmailPtr e;
		if (data["rw"] != Json::nullValue && data["rw"].size() != 0)
		{
			Json::Value& rw = data["rw"];
			ForEach(Json::Value, it, rw)
			{
				Json::Value& act = (*it)["act"];
				act = jsonFormats2c(act);
			}
			e = createGmPackage(EmailDef::GmEmail, param, rw);
		}
		else
		{
			e = createSystem(EmailDef::GmEmail, param);
		}
		if (type == 0)
		{
			const Json::Value& pid_v = data["arg"];
			if (pid_v.size() == 1)
			{
				int pid = pid_v[0u].asInt();
				sendToPlayer(pid, e);
			}
			else
			{
				std::vector<int> pids;
				ForEachC(Json::Value, it, pid_v)
					pids.push_back((*it).asInt());
				sendToPart(pids, e);
			}
		}
		else if (type == 1)
		{
			int nation = data["arg"][0u].asInt();
			sendToKingdom(nation, e);
		}
		else
		{
			sendToAll(e);
		}

		Return(r, res_sucess);
	}

	int email_system::removeCommonEmail(int id)
	{
		CommonEmailMap::iterator it = common_emails.find(id);
		if (it == common_emails.end())
			return err_email_id_not_found;
		it->second->setDeleted();
		common_emails.erase(it);
		return res_sucess;
	}

	void email_system::sendToAll(EmailPtr& e)
	{
		CommonEmailPtr c = createAll(e);
		common_emails.insert(make_pair(c->getId(), c));
		playerManager::playerDataVec vec = player_mgr.allOnline();
		ForEach(playerManager::playerDataVec, it, vec)
			(*it)->Email().addCommonEmail();
	}

	void email_system::sendToKingdom(int nation, EmailPtr& e)
	{
		CommonEmailPtr c = createNation(nation, e);
		common_emails.insert(make_pair(c->getId(), c));
		playerManager::playerDataVec vec = player_mgr.nationOnline((Kingdom::NATION)nation);
		ForEach(playerManager::playerDataVec, it, vec)
			(*it)->Email().addCommonEmail();
	}

	void email_system::sendToPart(const std::vector<int>& player_list, EmailPtr& e)
	{
		if (player_list.empty())
			return;
		CommonEmailPtr c = createPart(player_list, e);
		common_emails.insert(make_pair(c->getId(), c));
		ForEachC(std::vector<int>, it, player_list)
		{
			playerDataPtr d = player_mgr.getOnlinePlayer(*it);
			if (d)
				d->Email().addCommonEmail();
		}
	}

	void email_system::sendToPlayer(int player_id, EmailPtr& e)
	{
		playerDataPtr d = player_mgr.getPlayer(player_id);
		if (!d) return;

		d->Email().addEmail(e);
	}

	unsigned email_system::getCommonId()
	{
		unsigned id = ++common_email_id;
		saveCommonID();
		return id;
	}

	EmailPtr email_system::createSystem(const std::string& msg)
	{
		Json::Value m;
		m[EmailDef::MsgType] = EmailDef::Normal;
		m[EmailDef::ParamList].append(msg);
		return Creator<Email>::Create(Common::gameTime(), (int)EmailDef::System, "sys", m);
	}

	EmailPtr email_system::createSystem(int msg_type, const Json::Value& param_list)
	{
		Json::Value m;
		m[EmailDef::MsgType] = msg_type;
		m[EmailDef::ParamList] = param_list;
		return Creator<Email>::Create(Common::gameTime(), (int)EmailDef::System, "sys", m);
	}

	EmailPtr email_system::createGamer(const std::string& sender, const std::string& msg)
	{
		Json::Value m;
		m[EmailDef::MsgType] = EmailDef::Normal;
		m[EmailDef::ParamList].append(msg);
		return Creator<Email>::Create(Common::gameTime(), (int)EmailDef::Gamer, sender, m);
	}

	EmailPtr email_system::createPackage(int msg_type, const Json::Value& param_list, const Json::Value& reward)
	{
		Json::Value m;
		m[EmailDef::MsgType] = msg_type;
		m[EmailDef::ParamList] = param_list;
		Json::Value rw;
		rw[EmailDef::RewardType] = EmailDef::NormalReward;
		rw[EmailDef::ActionList] = reward;
		return Creator<Email>::Create(Common::gameTime(), (int)EmailDef::Package, "sys", m, rw);
	}
	
	EmailPtr email_system::createGmPackage(int msg_type, const Json::Value& param_list, const Json::Value& reward)
	{
		Json::Value m;
		m[EmailDef::MsgType] = msg_type;
		m[EmailDef::ParamList] = param_list;
		Json::Value rw;
		rw[EmailDef::RewardType] = EmailDef::GmGift;
		rw[EmailDef::GmGiftList] = reward;
		return Creator<Email>::Create(Common::gameTime(), (int)EmailDef::Package, "sys", m, rw);
	}

	EmailPtr email_system::createReport(int msg_type, const Json::Value& param_list, const std::string& report)
	{
		Json::Value m;
		m[EmailDef::MsgType] = msg_type;
		m[EmailDef::ParamList] = param_list;
		return Creator<Email>::Create(Common::gameTime(), (int)EmailDef::Report, "sys", m, report);
	}

	EmailPtr email_system::createFromBSON(const mongo::BSONElement& obj)
	{
		return Creator<Email>::Create(obj);
	}

	CommonEmailPtr email_system::createAll(EmailPtr& e)
	{
		CommonEmailPtr c = Creator<CommonEmail>::Create(e);
		c->_sign_save();
		return c;
	}

	CommonEmailPtr email_system::createNation(int nation, EmailPtr& e)
	{
		CommonEmailPtr c = Creator<CommonEmail>::Create(nation, e);
		c->_sign_save();
		return c;
	}

	CommonEmailPtr email_system::createPart(const std::vector<int>& parts, EmailPtr& e)
	{
		CommonEmailPtr c = Creator<CommonEmail>::Create(parts, e);
		c->_sign_save();
		return c;
	}

	unsigned email_system::getCommonEmails(playerDataPtr d, int player_common_email_id, EmailVec& vec)
	{
		if (common_email_id == player_common_email_id)
			return common_email_id;

		for (CommonEmailMap::reverse_iterator it = common_emails.rbegin();
			it != common_emails.rend(); ++it)
		{
			if (it->first <= player_common_email_id)
				break;
			if (it->second->needed(d))
				vec.push_back(it->second->getEmail());
		}

		return common_email_id;
	}

	EmailPtr email_system::getCommonEmail(int id)
	{
		CommonEmailMap::iterator it = common_emails.find(id);
		if (it == common_emails.end())
			return EmailPtr();
		return it->second->getEmail();
	}

	void email_system::classLoad()
	{
		common_email_id = 100000;
		objCollection objs = db_mgr.Query(DBN::dbCommonEmails);
		ForEachC(objCollection, it, objs)
		{
			const mongo::BSONObj& obj = *it;
			if (obj[EmailDef::Id].Int() == -1)
			{
				common_email_id = obj["cei"].Int();
				continue;
			}
			CommonEmailPtr c = Creator<CommonEmail>::Create(obj);	
			if (c->outOfDate())
				c->setDeleted();
			else
				common_emails.insert(make_pair(c->getId(), c));
		}
		
		if (common_email_id == 100000
			&& !common_emails.empty())
		{
			common_email_id = common_emails.rbegin()->second->getId();
		}
	}

	void email_system::saveCommonID()
	{
		mongo::BSONObj key = BSON(EmailDef::Id << -1);
		mongo::BSONObj obj = BSON(EmailDef::Id << -1 << "cei" << common_email_id);
		db_mgr.SaveMongo(DBN::dbCommonEmails, key, obj);
	}
}

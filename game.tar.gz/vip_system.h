//###################################
//create by YeMing
//2016-11-18
//###################################
#pragma once

#include "dbDriver.h"
#include "man_def.h"
#include "skill_def.h"
#include "battle_system.h"

#define vip_sys (*gg::vip_system::_Instance)
namespace gg
{
	struct vipGiftData
	{
		int vipLv;					//VIP�ȼ�
		ActionBoxList box;			//����
	};
	BOOSTSHAREPTR(vipGiftData, vipGiftDataPtr);
	UNORDERMAP(int, vipGiftDataPtr, vipGiftDataMap);

	class vip_system
	{
	public:
		static vip_system* const _Instance;
		void					initData();
		vipGiftDataPtr		getVipGif(int lv);
		DeclareRegFunction(showGift);
		DeclareRegFunction(getGift);
		DeclareRegFunction(addVip);
		DeclareRegFunction(getFirstGift);
	//	const ActionBoxList& getFirstGift() const { return firstGift; }
	private:
		vipGiftDataMap		vipGiftConfig;
	//	ActionBoxList firstGift;
	};
}

#include "kingdomwar_shop.h"

namespace gg
{
	kingdomwar_shop_system* const kingdomwar_shop_system::_Instance = new kingdomwar_shop_system();

	void kingdomwar_shop_system::initData()
	{
	}

	void kingdomwar_shop_system::boxRewardReq(net::Msg& m, Json::Value& r)
	{
		playerDataPtr d = player_mgr.getPlayer(m.playerID);
		if (!d || d->Info().Nation() == Kingdom::null)
			Return(r, err_illedge);
		
		d->KingDomWarBox().update();
	}

	void kingdomwar_shop_system::getBoxRewardReq(net::Msg& m, Json::Value& r)
	{
		playerDataPtr d = player_mgr.getPlayer(m.playerID);
		if (!d || d->Info().Nation() == Kingdom::null)
			Return(r, err_illedge);
		
		ReadJsonArray;
		int id = js_msg[0u].asInt();
		int res = d->KingDomWarBox().getReward(id, r[strMsg][1u]);
		Return(r, res);
	}
}

#include "kingdomwar_shop.h"

namespace gg
{
	kingdomwar_shop_system* const kingdomwar_shop_system::_Instance = new kingdomwar_shop_system();

	void kingdomwar_shop_system::initData()
	{
		loadFile();
	}

	void kingdomwar_shop_system::loadFile()
	{
		Json::Value json;
		json = Common::loadJsonFile("./instance/kingdom_war/shop.json");
		ShopDataMgr::init(json);
		
		json = Common::loadJsonFile("./instance/kingdom_war/shop_cost.json");
		ForEach(Json::Value, it, json)
			_flush_costs.push_back((*it).asInt());
	}

	int kingdomwar_shop_system::getFlushCost(unsigned times) const
	{
		if (times >= _flush_costs.size())
			times = _flush_costs.size() - 1;
		return _flush_costs[times];
	}

	void kingdomwar_shop_system::shopInfo(net::Msg& m, Json::Value& r)
	{
		playerDataPtr d = player_mgr.getPlayer(m.playerID);
		if (!d || d->Info().Nation() == Kingdom::null) 
			Return(r, err_illedge);

		d->KingDomWarShop().update();
	}

	void kingdomwar_shop_system::buy(net::Msg& m, Json::Value& r)
	{
		playerDataPtr d = player_mgr.getPlayer(m.playerID);
		if (!d || d->Info().Nation() == Kingdom::null) 
			Return(r, err_illedge);

		ReadJsonArray;
		int pos = js_msg[0u].asInt();
		int id = js_msg[1u].asInt();

		int res = d->KingDomWarShop().buy(pos, id, r[strMsg]);
		Return(r, res);
	}

	void kingdomwar_shop_system::flush(net::Msg& m, Json::Value& r)
	{
		playerDataPtr d = player_mgr.getPlayer(m.playerID);
		if (!d || d->Info().Nation() == Kingdom::null) 
			Return(r, err_illedge);

		int res = d->KingDomWarShop().flush();
		Return(r, res);
	}

	void kingdomwar_shop_system::boxRewardReq(net::Msg& m, Json::Value& r)
	{
		playerDataPtr d = player_mgr.getPlayer(m.playerID);
		if (!d || d->Info().Nation() == Kingdom::null)
			Return(r, err_illedge);
		
		d->KingDomWarBox().update();
	}

	void kingdomwar_shop_system::getBoxRewardReq(net::Msg& m, Json::Value& r)
	{
		playerDataPtr d = player_mgr.getPlayer(m.playerID);
		if (!d || d->Info().Nation() == Kingdom::null)
			Return(r, err_illedge);
		
		ReadJsonArray;
		int id = js_msg[0u].asInt();
		int res = d->KingDomWarBox().getReward(id, r[strMsg][1u]);
		Return(r, res);
	}
}

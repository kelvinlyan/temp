#include "player_red_paper.h"
#include "dbDriver.h"

const static std::string strLocalID = "li";
const static std::string strDelete = "de";
const static std::string strDate = "dt";
const static std::string strCash = "cr";
const static std::string strNum = "nr";
const static std::string strItemID = "ii";
const static std::string strChannel = "ch";
const static std::string strResType = "rt";
const static std::string strPlayerID2 = "rpi";
const static std::string strIndex = "idx";
const static std::string strTotalPaper = "tp";
const static std::string strTotalRob = "tr";
const static std::string strFaceID = "fi";//

namespace gg
{

	playerRedPaper::playerRedPaper(playerData* const own)
		:_auto_player(own),
		_total_paper(0)
	{
		_paper_robbed_list = Creator<red_paper::PaperRobbedList>::Create();
		//_sent_paper_list = Creator<SentPaperList>::Create();
	}

	void playerRedPaper::incPaperCount()
	{
		++_total_paper;
		_auto_save();
	}

	void playerRedPaper::addDelLog(int playerID, int local_id)
	{
		if (_wor_delete_map.find(playerID) == _wor_delete_map.end())
		{
			LocalIdToLogIdMap list;
			_wor_delete_map[playerID] = list;
		}
		_wor_delete_map[playerID][local_id] = 1;
		save_wor_del_db(playerID, local_id);
	}

	bool playerRedPaper::isDel(int playerID, int local_id)
	{
		if (_wor_delete_map.find(playerID) == _wor_delete_map.end())
		{
			return false;
		}
		else if (_wor_delete_map[playerID].find(local_id) == _wor_delete_map[playerID].end())
		{
			return false;
		}
		else
		{
			return true;
		}
	}

	bool playerRedPaper::isOpenable(int playerID, int local_id)
	{
		if (_player_id_map.find(playerID) != _player_id_map.end()
			&& _player_id_map[playerID].find(local_id) != _player_id_map[playerID].end())
		{
			return false;
		}
		return true;
	}
	
	/*
	void playerRedPaper::addRobbedLog(int local_id, playerDataPtr player_ptr, int cash)
	{
		if (!player_ptr) return;
		red_paper::RobberUserPtr user = Creator<red_paper::RobbedUser>::Create();
		user->userID = player_ptr->ID();
		user->nickname = player_ptr->Name();
		user->face_Id = player_ptr->Info().Face();
		user->cash = cash;
		user->local_id = local_id;
		user->date = Common::gameTime();
		user->del = 0;
		(*_paper_robbed_list)[_robbed_log_id] = user;
		save_robbed_db(user);//
		if (_player_id_map.find(player_ptr->ID()) == _player_id_map.end())
		{
			LocalIdToLogIdMap id_map;
			id_map[local_id] = _robbed_log_id;
			_player_id_map[player_ptr->ID()] = id_map;
		}
		_player_id_map[player_ptr->ID()][local_id] = _robbed_log_id;
		save_robbed_map_db(player_ptr->ID(), local_id, _robbed_log_id);//
		++_robbed_log_id;
		//save and update
		_auto_save();//
	}
	*/

	/*
	void playerRedPaper::delRobbedLog(int playerID, int local_id)
	{
		if (_player_id_map.find(playerID) != _player_id_map.end()
			&& _player_id_map[playerID].find(local_id) != _player_id_map[playerID].end())
		{
			if (_paper_robbed_list->find(_player_id_map[playerID][local_id]) != _paper_robbed_list->end())
			{
				(*_paper_robbed_list)[_player_id_map[playerID][local_id]]->del = 1;//???
				del_robbed_db((*_paper_robbed_list)[_player_id_map[playerID][local_id]]);
				del_robbed_map_db(playerID, local_id);
			}
			_player_id_map[playerID].erase(local_id);
		}
	}
	*/

	/*
	void playerRedPaper::addSentLog(red_paper::UnitPaperPtr paper_ptr)
	{
		red_paper::SenderPtr sender = Creator<red_paper::Sender>::Create();
		sender->date = Common::gameTime();
		sender->paper = paper_ptr;
		sender->del = 0;
		(*_sent_paper_list)[sender->paper->local_id] = sender;
		//save and update
		save_sent_db(sender);
	}
	*/

	/*
	void playerRedPaper::delSentLog(int local_id)
	{
		if (_sent_paper_list->find(local_id) != _sent_paper_list->end())
		{
			(*_sent_paper_list)[local_id]->del = 1;
			del_sent_db((*_sent_paper_list)[local_id]);
		}
	}

	void playerRedPaper::delAllLog()
	{
		for (red_paper::PaperRobbedList::iterator it = _paper_robbed_list->begin();
			it != _paper_robbed_list->end();
			++it)
		{
			it->second->del = 1;
		}
		for (SentPaperList::iterator it = _sent_paper_list->begin();
			it != _sent_paper_list->end();
			++it)
		{
			it->second->del = 1;
		}
	}
	*/

	/*
	bool playerRedPaper::save_sent_db(red_paper::SenderPtr sender)
	{
		if (!sender) return false;
		mongo::BSONObj key = BSON(strPlayerID << Own().ID() << strLocalID << sender->paper->local_id);

		mongo::BSONObj obj = BSON(strPlayerID << Own().ID()
			<< strLocalID << sender->paper->local_id
			<< strDelete << sender->del
			<< strDate << sender->date
			<< strCash << sender->paper->raw_paper->cash
			<< strNum << sender->paper->raw_paper->num
			<< strItemID << sender->paper->raw_paper->id
			<< strChannel << sender->paper->raw_paper->channel
			<< strResType << sender->paper->raw_paper->res_type
		);

		return db_mgr.SaveMongo(DBN::dbPlayerSenderRedPaper, key, obj);
	}

	void playerRedPaper::del_sent_db(red_paper::SenderPtr sender)
	{
		if (!sender) return;
		mongo::BSONObj key = BSON(strPlayerID << Own().ID() << strLocalID << sender->paper->local_id);

		db_mgr.RemoveCollection(DBN::dbPlayerSenderRedPaper, key);
	}
	*/

    /*
	bool playerRedPaper::save_robbed_db(red_paper::RobberUserPtr user)
	{
		if (!user) return false;
		mongo::BSONObj key = BSON(strPlayerID << Own().ID() << strPlayerID2 << user->userID << strLocalID << user->local_id);

		mongo::BSONObj obj = BSON(strPlayerID << Own().ID()
			<< strPlayerID2 << user->userID
			<< strLocalID << user->local_id
			<< strPlayerName << user->nickname
			<< strDate << user->date
			<< strDelete << user->del
			<< strCash << user->cash
			<< strFaceID << user->face_Id
		);

		return db_mgr.SaveMongo(DBN::dbPlayerRobbedUserRedPaper, key, obj);
	}

	bool playerRedPaper::save_robbed_map_db(int playerID, int local_id, int idx)
	{
		mongo::BSONObj key = BSON(strPlayerID << Own().ID() << strPlayerID2 << playerID << strLocalID << local_id);

		mongo::BSONObj obj = BSON(strPlayerID << Own().ID()
			<< strPlayerID2 << playerID
			<< strLocalID << local_id
			<< strIndex << idx
		);

		return db_mgr.SaveMongo(DBN::dbPlayerRobbedMapRedPaper, key, obj);
	}

	void playerRedPaper::del_robbed_db(red_paper::RobberUserPtr user)
	{
		if (!user) return ;
		mongo::BSONObj key = BSON(strPlayerID << Own().ID() << strPlayerID2 << user->userID << strLocalID << user->local_id);
		db_mgr.RemoveCollection(DBN::dbPlayerRobbedUserRedPaper, key);
	}

	void playerRedPaper::del_robbed_map_db(int playerID, int local_id)
	{
		mongo::BSONObj key = BSON(strPlayerID << Own().ID() << strPlayerID2 << playerID << strLocalID << local_id);
		db_mgr.RemoveCollection(DBN::dbPlayerRobbedMapRedPaper, key);
	}
	*/
	bool playerRedPaper::save_wor_del_db(int playerID, int local_id)
	{
		mongo::BSONObj key = BSON(strPlayerID << Own().ID() << strPlayerID2 << playerID << strLocalID << local_id);

		return db_mgr.SaveMongo(DBN::dbPlayerWorldDeleteRedPaper, key, key);
	}

	bool playerRedPaper::_auto_save()
	{
		mongo::BSONObj key = BSON(strPlayerID << Own().ID());

		mongo::BSONObj obj = BSON(strPlayerID << Own().ID()
			<< strTotalPaper << _total_paper
		);
		return db_mgr.SaveMongo(DBN::dbPlayerRedPaper, key, obj);
	}

	void playerRedPaper::classLoad()
	{
		unsigned now = Common::gameTime();
		//1.
		mongo::BSONObj key = BSON(strPlayerID << Own().ID());
		mongo::BSONObj obj = db_mgr.FindOne(DBN::dbPlayerRedPaper, key);
		if (!obj.isEmpty())
		{
			_total_paper = obj[strTotalPaper].Int();
			//_robbed_log_id = obj[strTotalRob].Int();
		}
		
		/*
		//2.sent log
		objCollection objs1 = db_mgr.Query(DBN::dbPlayerSenderRedPaper, key);
		ForEachC(objCollection, it, objs1)
		{
			const mongo::BSONObj& obj = (*it);
			unsigned date = obj[strDate].Int();
			if (now > date && now - date > DEAHLINE)
			{
				continue;
			}
			red_paper::SenderPtr sender = Creator<red_paper::Sender>::Create();
			sender->date = obj[strDate].Int();
			sender->del = obj[strDelete].Int();
			red_paper::UnitPaperPtr unit = Creator<red_paper::UnitPaper>::Create();
			unit->date = obj[strDate].Int();
			unit->player_id = obj[strPlayerID].Int();
			unit->local_id = obj[strLocalID].Int();
			red_paper::RedPaperPtr paper = Creator<red_paper::RedPaper>::Create();
			paper->id = obj[strItemID].Int();
			paper->channel = obj[strChannel].Int();
			paper->res_type = obj[strResType].Int();
			paper->cash = obj[strCash].Int();
			paper->num = obj[strNum].Int();
			unit->raw_paper = paper;
			sender->paper = unit;
			(*_sent_paper_list)[sender->paper->local_id] = sender;
		}
		*/
		
		//3._player_id_map
		/*objCollection objs2 = db_mgr.Query(DBN::dbPlayerRobbedMapRedPaper, key);
		ForEachC(objCollection, it, objs2)
		{
			const mongo::BSONObj& obj = (*it);
			int playerID = obj[strPlayerID2].Int();
			int local_id = obj[strLocalID].Int();
			int index = obj[strIndex].Int();
			if (_player_id_map.find(playerID) == _player_id_map.end())
			{
				LocalIdToLogIdMap list;
				_player_id_map[playerID] = list;
			}
			_player_id_map[playerID][local_id] = index;
		}*/

		//4.robbed log
		/*objCollection objs3 = db_mgr.Query(DBN::dbPlayerRobbedUserRedPaper, key);
		ForEachC(objCollection, it, objs3)
		{
			const mongo::BSONObj& obj = (*it);
			unsigned date = obj[strDate].Int();
			if (now > date && now - date > DEAHLINE)
			{
				continue;
			}
			red_paper::RobberUserPtr user = Creator<red_paper::RobbedUser>::Create();
			user->local_id = obj[strLocalID].Int();
			user->userID = obj[strPlayerID2].Int();
			user->del = obj[strDelete].Int();
			user->date = date;
			user->nickname = obj[strPlayerName];
			user->cash = obj[strCash].Int();
			user->face_Id = obj[strFaceID].Int();
			if (_player_id_map.find(user->userID) != _player_id_map.end()
				&& _player_id_map[user->userID].find(user->local_id) != _player_id_map[user->userID].end())
			{
				(*_paper_robbed_list)[_player_id_map[user->userID][user->userID]] = user;
			}
		}*/

		//5.world delete
		objCollection objs4 = db_mgr.Query(DBN::dbPlayerWorldDeleteRedPaper, key);
		ForEachC(objCollection, it, objs4)
		{
			const mongo::BSONObj& obj = (*it);
			int playerID = obj[strPlayerID2].Int();
			int local_id = obj[strLocalID].Int();
			if (_wor_delete_map.find(playerID) == _wor_delete_map.end())
			{
				LocalIdToLogIdMap list;
				_wor_delete_map[playerID] = list;
			}
			_wor_delete_map[playerID][local_id] = 1;
		}
		

	}


	playerRedPaper::~playerRedPaper()
	{
	}
}
#include "player_expedition_fm.h"
#include "man_system.h"
#include "game_time.h"

namespace gg
{
	playerExpeditionSGFM::playerExpeditionSGFM(int season, playerData* const own)
		: _auto_player(own), _cur_fm_id(-1), _season(season), _last_fm_id(-1), _bv(-1)
	{
		_cur_fm.assign(9, playerManPtr());
		_last_fm.assign(9, playerManPtr());
	}

	void playerExpeditionSGFM::resetFM()
	{
		bool save = false;
		if (_last_fm_id != _cur_fm_id)
		{
			_last_fm_id = _cur_fm_id;
			save = true;
		}
		for (unsigned i = 0; i < _cur_fm.size(); ++i)
		{
			if (_cur_fm[i] != _last_fm[i])
			{
				_last_fm[i] = _cur_fm[i];
				save = true;
			}
			if (_cur_fm[i] &&
				Own().Expedition().dead(_cur_fm[i]->mID()))
			{
				_cur_fm[i].reset();
				_bv = -1;
				//recalBV();
				save = true;
			}
		}
		if (save)
			_sign_save();
	}

	void playerExpeditionSGFM::load(const mongo::BSONObj& obj)
	{
		_cur_fm_id = obj["ci"].Int();
		_last_fm_id = obj["li"].Int();
		{
			const std::vector<mongo::BSONElement> ele = obj["cf"].Array();
			for (unsigned i = 0; i < 9; ++i)
				_cur_fm[i] = Own().Man().findMan(ele[i].Int());
		}
		{
			const std::vector<mongo::BSONElement> ele = obj["lf"].Array();
			for (unsigned i = 0; i < 9; ++i)
				_last_fm[i] = Own().Man().findMan(ele[i].Int());
		}
	}

	bool playerExpeditionSGFM::_auto_save()
	{
		mongo::BSONObj key = BSON(strPlayerID << Own().ID() << "s" << _season);
		mongo::BSONObjBuilder obj;
		obj << strPlayerID << Own().ID() << "s" << _season << "ci" << _cur_fm_id
			<< "li" << _last_fm_id;
		{
			mongo::BSONArrayBuilder b;
			ForEachC(Expedition::ManList, it, _cur_fm)
				b.append((*it)? (*it)->mID() : -1);
			obj << "cf" << b.arr();
		}
		{
			mongo::BSONArrayBuilder b;
			ForEachC(Expedition::ManList, it, _last_fm)
				b.append((*it)? (*it)->mID() : -1);
			obj << "lf" << b.arr();
		}
		return db_mgr.SaveMongo(DBN::dbPlayerExpeditionFM, key, obj.obj());
	}

	void playerExpeditionSGFM::initFM()
	{
		_cur_fm_id = Own().WarFM().currentID();
		_last_fm_id = Own().WarFM().currentID();
		std::vector<int> fm;
		std::vector<playerManPtr> war_fm = Own().WarFM().currentFM();
		for (unsigned i = 0; i < war_fm.size(); ++i)
		{
			if (war_fm[i] && war_fm[i]->LV() >= 40)
				fm.push_back(war_fm[i]->mID());
			else
				fm.push_back(-1);
		}
		setFormation(fm);
		_sign_save();
	}

	void playerExpeditionSGFM::tickAt0500()
	{
		if (_last_fm_id != -1)
		{
			_cur_fm_id = _last_fm_id;
			_cur_fm = _last_fm;
			recalBV();
			_sign_save();
		}
	}

	sBattlePtr playerExpeditionSGFM::getBattlePtr()
	{
		sBattlePtr sb = Creator<sideBattle>::Create();
		sb->playerID = Own().ID();
		sb->playerName = Own().Name();
		sb->isPlayer = true;
		sb->playerLevel = Own().LV();
		sb->playerNation = Own().Info().Nation();
		sb->playerFace = Own().Info().Face();
		sb->battleValue = bv();
		manList& ml = sb->battleMan;
		ml.clear();
		vector<Expedition::playerManPtr> ownMan = _cur_fm;
		for (unsigned i = 0; i < ownMan.size(); i++)
		{
			Expedition::playerManPtr man = ownMan[i];
			if (!man)continue;
			mBattlePtr mbattle = Creator<manBattle>::Create();
			cfgManPtr config = man_sys.getConfig(man->mID());
			if (!config)continue;
			mbattle->manID = man->mID();
			mbattle->battleValue = man->battleValue();
			mbattle->holdMorale = config->holdMorale;
			mbattle->set_skill_1(config->skill_1);
			mbattle->set_skill_2(config->skill_2);
			mbattle->armsType = config->armsType;
			mbattle->manLevel = man->LV();
			mbattle->currentIdx = i % 9;
			memcpy(mbattle->armsModule, config->armsModules, sizeof(mbattle->armsModule));
			man->toInitialAttri(mbattle->initialAttri);
			man->toNoEquipAttri(curFMID(), mbattle->battleAttri);
			mbattle->currentHP = mbattle->getTotalAttri(idx_hp);
			const Expedition::ManInfo& man_info = Own().Expedition().getManInfo(man->mID());
			if (man_info.hp != -1 && mbattle->currentHP > man_info.hp)
				mbattle->currentHP = man_info.hp;
			if (man_info.mp != -1)
				mbattle->setMorale(man_info.mp);
			if (0 == i)
			{
				sb->leaderMan = mbattle;
			}
			ml.push_back(mbattle);
		}
		return sb;
	}

	int playerExpeditionSGFM::curFMID()
	{
		if (_cur_fm_id == -1)
			initFM();
		return _cur_fm_id;
	}
	
	void playerExpeditionSGFM::getInfo(qValue& q)
	{
		q.addMember("i", curFMID());
		qValue f;
		ForEach(Expedition::ManList, it, _cur_fm)
		{
			playerManPtr& ptr = *it;	
			f.append(ptr? ptr->mID() : -1);
		}
		q.addMember("f", f);
		q.addMember("bv", bv());
	}

	int playerExpeditionSGFM::changeFormation(int fm_id)
	{
		std::vector<int> fm;
		ForEachC(Expedition::ManList, it, _cur_fm)
		{
			if (*it)
				fm.push_back((*it)->mID());
			else
				fm.push_back(-1);
		}
		bool fm_opened = false;
		const FMCFG::HOLEVEC& config = playerWarFM::getConfig(fm_id).HOLES;
		Expedition::ManList tmpList(9, playerManPtr());
		int idx = 0;
		for (unsigned i = 0; i < 9; ++i)
		{
			if (Own().LV() < config[i].LV) continue;
			if (!config[i].Use)continue;
			if (config[i].Process > 0 && !Own().War().isChallengeMap(config[i].Process))continue;
			fm_opened = true;
			for (; idx < 9; ++idx)
			{
				if (fm[idx] < 0)
					continue;
				playerManPtr man = Own().Man().findMan(fm[idx++]);
				if (man && man->LV() >= 40)
					tmpList[i] = man;
				break;
			}
		}
		if (!fm_opened)
			return err_format_hole_limit;
		_cur_fm_id = fm_id;
		_cur_fm = tmpList;
		_last_fm_id = fm_id;
		_last_fm = tmpList;
		recalBV();
		_sign_save();
		return res_sucess;
	}

	int playerExpeditionSGFM::setFormation(const std::vector<int>& fm)
	{
		if (fm.size() != 9)
			return err_illedge;
		const FMCFG::HOLEVEC& config = playerWarFM::getConfig(curFMID()).HOLES;
		boost::unordered_set<int> SAMEMAN;
		Expedition::ManList tmpList(9, playerManPtr());
		for (unsigned i = 0; i < 9; ++i)
		{
			if (fm[i] < 0)continue;
			if (!SAMEMAN.insert(fm[i] / 100).second)return err_fomat_same_man;
			if (Own().LV() < config[i].LV)return err_format_hole_limit;
			if (!config[i].Use)return err_format_hole_limit;
			if (config[i].Process > 0 && !Own().War().isChallengeMap(config[i].Process))return err_format_hole_limit;
			if (Own().Expedition().dead(fm[i]))return err_illedge;
			playerManPtr man = Own().Man().findMan(fm[i]);
			if (!man || man->LV() < 40) return err_illedge;
			tmpList[i] = man;
		}
		_cur_fm = tmpList;
		_last_fm = tmpList;
		recalBV();
		_sign_save();
		return res_sucess;
	}

	int playerExpeditionSGFM::bv()
	{
		if (_bv == -1)
			_bv = calBV();
		return _bv;
	}

	int playerExpeditionSGFM::calBV()
	{
		int power = 0;
		unsigned num = 0;
		for (unsigned i = 0; i < 9; ++i)
		{
			Expedition::playerManPtr& man = _cur_fm[i];
			if (!man) continue;
			++num;
			power += man->noeqBattleValue();
		}
		const FMCFG& config = playerWarFM::getConfig(curFMID());
		const int scLV = Own().Research().getForLV(config.techID);
		power += (scLV * 7 * num);
		//Èç¹ûÔ½½ç//ÄÇÃ´10ÒÚ
		const static int MaxValue = 1000000000;//10ÒÚ
		if (power < 0 || power > MaxValue)
			power = MaxValue;
		return power;
	}
	
	playerExpeditionFM::playerExpeditionFM(playerData* const own)
		: _auto_player(own), _cur_season(-1)
	{
		for (unsigned i = 0; i < 4; ++i)
			_fm_list.push_back(Creator<playerExpeditionSGFM>::Create(i, own));
	}

	void playerExpeditionFM::recalFM()
	{
		_fm_list[season()]->recalBV();
	}

	void playerExpeditionFM::tickAt0500()
	{
		_cur_season = -1;
		_fm_list[season()]->tickAt0500();
	}

	int playerExpeditionFM::season()
	{
		if (_cur_season == -1)
			_cur_season = season_sys.getSeason();
		return _cur_season;
	}
	
	void playerExpeditionFM::classLoad()
	{
		mongo::BSONObj key = BSON(strPlayerID << Own().ID());
		objCollection objs = db_mgr.Query(DBN::dbPlayerExpeditionFM, key);
		for (unsigned i = 0; i < objs.size(); ++i)
		{
			int season = objs[i]["s"].Int();
			_fm_list[season]->load(objs[i]);
		}
	}

	void playerExpeditionFM::_auto_update()
	{
		update();
	}

	void playerExpeditionFM::update()
	{
		qValue m;
		m.append(res_sucess);
		qValue q(qJson::qj_object);
		_fm_list[season()]->getInfo(q);
		m.append(q);
		Own().sendToClientFillMsg(gate_client::expedition_formation_resp, m);
	}

	int playerExpeditionFM::changeFormation(int fm_id)
	{
		int res = _fm_list[season()]->changeFormation(fm_id);
		if (res == res_sucess)
			_sign_update();
		return res_sucess;
	}

	int playerExpeditionFM::setFormation(const std::vector<int>& fm)
	{
		int res = _fm_list[season()]->setFormation(fm);
		if (res == res_sucess)
			_sign_update();
		return res;
	}

	sBattlePtr playerExpeditionFM::getBattlePtr()
	{
		return _fm_list[season()]->getBattlePtr();
	}

	void playerExpeditionFM::resetFM()
	{
		_fm_list[season()]->resetFM();
	}
}

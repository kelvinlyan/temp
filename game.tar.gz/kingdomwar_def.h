#pragma once

#include <string>

namespace gg
{
	namespace KingdomWar
	{
		enum
		{
			// param
			ArmyNum = 3,
			ArmyMaxHp = 100,

			// position type
			PosEmpty = -1,
			PosCity,
			PosPath,

			// state
			Closed = 0,
			Opened,
			AttackerWait,
			DefenderWait,
			StartWait,
			Protected,

			// prime state
			OrdinaryTime = 0,
			PrimeTime,

			// side
			Left = 0,
			Right,
			MaxSide,

			// item type
			Player = 0,
			Npc,
			ActiveNpc,
			Shadow,
			ShadowNpc,

			// battle result
			Win = 0,
			Lose,
		};

		// turn back reason
		namespace TIPS
		{
			enum
			{
				NONE = 0,       
				HPEMPTY,
				DEFEATED,    
				SIEGEFAILED,
				UNITY,
				ELECATTACK,
				CITYPROTECTED,
			};
		}

		// rep type
		namespace REP
		{
			enum
			{
				BATTLE = 0,
				ELECATTACK,
			};
		}

		const static std::string strNpcID = "ni";
	}
}

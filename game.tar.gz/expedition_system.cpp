#include "expedition_system.h"
#include "heroparty_system.h"

namespace gg
{
	using namespace Expedition;

	namespace Expedition
	{
		enum
		{
			LvLimit = 58,
		};
	}

#define LoadPlayer\
	playerDataPtr d = player_mgr.getPlayer(m.playerID);\
	if (!d || d->LV() < Expedition::LvLimit || heroparty_sys.getRankNo_(d->ID()) == -1)\
		Return(r, err_illedge)

	expedition_system* const expedition_system::_Instance = new expedition_system();

	void expedition_system::initData()
	{
		MapDataMgr::shared();
		RankMgr::shared();
		loadStrategy();
	}

	void expedition_system::loadStrategy()
	{
		objCollection objs = db_mgr.Query(DBN::dbExpeditionStragety);
		ForEachC(objCollection, it, objs)
		{
			StrategyPtr ptr = Creator<Expedition::Strategy>::Create(*it);
			_stragety_map.insert(make_pair(ptr->mID(), ptr));
		}
	}

	void expedition_system::playerInfo(net::Msg& m, Json::Value& r)
	{
		LoadPlayer;
		d->Expedition().update();
	}

	void expedition_system::manInfo(net::Msg& m, Json::Value& r)
	{
		LoadPlayer;
		d->Expedition().upManInfo();
	}

	static int getDamage(sBattlePtr& atk)
	{
		int damage = 0;
		for (manList::iterator it = atk->battleMan.begin(); it != atk->battleMan.end(); it++)
		{
			damage = damage + ((*it)->getTotalAttri(idx_hp) - (*it)->currentHP);
		}
		return damage;
	}

	void expedition_system::challenge(net::Msg& m, Json::Value& r)
	{
		LoadPlayer;
		ReadJsonArray;
		int res;
		int pos = js_msg[0u].asInt();
		if ((res = d->Expedition().challengeLimit(pos)) != res_sucess)
			Return(r, res);
		Expedition::MapPtr ptr = MapDataMgr::shared().getMapData(d, pos);
		if (!ptr) Return(r, err_illedge);
		sBattlePtr def = ptr->getBattlePtr(d);
		if (!def) Return(r, err_illedge);
		sBattlePtr atk = d->Expedition().getBattlePtr();
		BattleReport reportData;
		O2ORes resultB = reportData.One2One(atk, def, typeBattle::expedition);
		d->Expedition().doneBattle(resultB.res, atk, def);
		reportData.addNotice(d->ID());
		Json::Value role_exp;
		role_exp.append(d->LV());
		role_exp.append(d->Info().EXP());
		role_exp.append(d->LV());
		role_exp.append(d->Info().EXP());
		role_exp.append(0);
		role_exp.append(d->Info().isMaxLevel());
		reportData.addReportdeclare("plv", role_exp);
		reportData.addReportdeclare("bg", ptr->bgID());
		if (resultB.res == resBattle::atk_win 
			&& !def->isPlayer)
		{
			qValue rep;
			rep << resultB.star << Common::gameTime() << d->Name() << d->LV() << d->Info().Nation();
			StrategyMap::iterator it = _stragety_map.find(def->playerID);
			if (it == _stragety_map.end())
			{
				StrategyPtr ptr = Creator<Strategy>::Create(def->playerID);
				ptr->push(rep, CmpStrategy(d->LV(), reportData.getLastRound(), getDamage(atk)), reportData, d);
				_stragety_map.insert(make_pair(def->playerID, ptr));
			}
			else
			{
				it->second->push(rep, CmpStrategy(d->LV(), reportData.getLastRound(), getDamage(atk)), reportData, d);
			}
		}
		if (resultB.res == resBattle::def_win)
		{
			upFMInfo(d, ptr);
		}
		reportData.Done(typeBattle::expedition);
		Return(r, res_sucess);
	}

	void expedition_system::strategyInfo(net::Msg& m, Json::Value& r)
	{
		LoadPlayer;
		ReadJsonArray;
		int pos = js_msg[0u].asInt();
		Expedition::MapPtr ptr = MapDataMgr::shared().getMapData(d, pos);
		if (!ptr || ptr->type() != NPC)
			Return(r, err_illedge);
		NpcPtr nptr = upCast<INpc>(ptr);
		if (!nptr)
			Return(r, err_illedge);
		StrategyMap::iterator it = _stragety_map.find(nptr->mapID());
		if (it == _stragety_map.end())
			sendEmptyStrategy(d);
		else
			it->second->update(d);
	}

	void expedition_system::formationInfo(net::Msg& m, Json::Value& r)
	{
		LoadPlayer;
		d->ExpeditionFM().update();
	}

	void expedition_system::setFormation(net::Msg& m, Json::Value& r)
	{
		LoadPlayer;
		ReadJsonArray;
		const Json::Value& rfm = js_msg[0u];
		std::vector<int> fm;
		ForEachC(Json::Value, it, rfm)
			fm.push_back((*it).asInt());
		int res = d->ExpeditionFM().setFormation(fm);
		Return(r, res);
	}

	void expedition_system::changeFormation(net::Msg& m, Json::Value& r)
	{
		LoadPlayer;
		ReadJsonArray;
		int fm_id = js_msg[0u].asInt();
		int res = d->ExpeditionFM().changeFormation(fm_id);
		Return(r, res);
	}

	void expedition_system::shadowInfo(net::Msg& m, Json::Value& r)
	{
		LoadPlayer;
		//ReadJsonArray;
		//int pos = js_msg[0u].asInt();
		Expedition::MapPtr ptr = MapDataMgr::shared().getMapData(d, d->Expedition().curPos()+1);
		if (!ptr) Return(r, err_illedge);
		upFMInfo(d, ptr);
	}

	void expedition_system::upFMInfo(playerDataPtr& d, Expedition::MapPtr& ptr)
	{
		qValue mm;
		mm.append(res_sucess);
		qValue q(qJson::qj_object);
		ptr->getFMInfo(d, q);
		mm.append(q);
		d->sendToClientFillMsg(gate_client::expedition_shadow_info_resp, mm);
	}

	void expedition_system::getReward(net::Msg& m, Json::Value& r)
	{
		LoadPlayer;
		ReadJsonArray;
		int pos = js_msg[0u].asInt();
		int res = d->Expedition().getReward(pos, r[strMsg]);
		Return(r, res);
	}

	void expedition_system::flush(net::Msg& m, Json::Value& r)
	{
		LoadPlayer;
		int res = d->Expedition().flush();
		Return(r, res);
	}

	void expedition_system::mapData(net::Msg& m, Json::Value& r)
	{
		LoadPlayer;
		qValue mm;
		mm.append(res_sucess);
		qValue q;
		MapDataMgr::shared().getBaseInfo(d, q);
		mm.append(q);
		d->sendToClientFillMsg(gate_client::expedition_map_data_resp, mm);
	}

	void expedition_system::dailyRank(net::Msg& m, Json::Value& r)
	{
		LoadPlayer;
		qValue mm;
		mm.append(res_sucess);
		qValue q(qJson::qj_object);
		RankMgr::shared().getDailyInfo(d, q);
		mm.append(q);
		d->sendToClientFillMsg(gate_client::expedition_daily_rank_resp, mm);
	}

	void expedition_system::historyRank(net::Msg& m, Json::Value& r)
	{
		LoadPlayer;
		qValue mm;
		mm.append(res_sucess);
		qValue q(qJson::qj_object);
		RankMgr::shared().getHistoryInfo(d, q);
		mm.append(q);
		d->sendToClientFillMsg(gate_client::expedition_history_rank_resp, mm);
	}

	void expedition_system::buy(net::Msg& m, Json::Value& r)
	{
		LoadPlayer;
		int res = d->Expedition().buy();
		Return(r, res);
	}

	void expedition_system::mopUp(net::Msg& m, Json::Value& r)
	{
		LoadPlayer;
		ReadJsonArray;
		int pos = js_msg[0u].asInt();
		int res = d->Expedition().mopUp(pos);
		Return(r, res);
	}

	void expedition_system::GmModifyProgress(net::Msg& m, Json::Value& r)
	{
		LoadPlayer;
		ReadJsonArray;
		int pos = js_msg[0u].asInt();
		int res = d->Expedition().setProgress(pos);
		Return(r, res);
	}

	void expedition_system::sendEmptyStrategy(playerDataPtr d)
	{
		qValue m;
		m.append(res_sucess);
		m.append(qValue(qJson::qj_object));
		d->sendToClientFillMsg(gate_client::expedition_strategy_info_resp, m);
	}
}

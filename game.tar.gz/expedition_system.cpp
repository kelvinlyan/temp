#include "expedition_system.h"

namespace gg
{
	namespace Expedition
	{
		enum
		{
			RecentStrategySize = 5,
		};

		Strategy::Strategy(int mid)
			: _mid(mid), _first("[]"), _best("[]")
		{
		}

		Strategy::Strategy(const mongo::BSONObj& obj)
			: _cmp_best(obj["cb"])
		{
			_mid = obj["mid"].Int();
			_first = obj["f"].String();
			_best = obj["b"].String();
			std::vector<mongo::BSONElement> ele = obj["r"].Array();
			for (unsigned i = 0; i < ele.size(); ++i)
				_recent.push_back(ele[i].String());
		}

		bool Strategy::better(const CmpStrategy& cmp) const
		{
			if (_cmp_best.lv != cmp.lv)
				return _cmp_best.lv < cmp.lv;
			if (_cmp_best.round_num != cmp.round_num)
				return _cmp_best.round_num < cmp.round_num;
			if (_cmp_best.damage != cmp.damage)
				return _cmp_best.damage < cmp.damage;
			return false;
		}

		void Strategy::push(qValue& q, const CmpStrategy& cmp)
		{
			std::string str = q.toIndentString();
			if (_first == "[]")
				_first = str;
			if (_best == "[]" || better(cmp))
			{
				_best = str;
				_cmp_best = cmp;
			}
			_recent.push_front(str);
			while(_recent.size() > RecentStrategySize)
				_recent.pop_back();
			_sign_save();
		}

		void Strategy::update(playerDataPtr d)
		{
			std::string str;
			str += "{\"msg\":[0,{\"f\":";
			str += _first;
			str += ",\"b\":";
			str += _best;
			str += ",\"r\":[";
			ForEachC(List, it, _recent)
			{
				if (it != _recent.begin())
					str += ",";
				str += *it;
			}
			str += "]}]}";
			d->sendToClient(gate_client::expedition_strategy_info_resp, str);
		}

		bool Strategy::_auto_save()
		{
			mongo::BSONObj key = BSON("mid" << _mid);
			mongo::BSONObjBuilder obj;
			obj << "mid" << _mid
				<< "f" << _first << "b" << _best << "cb" << _cmp_best.toBSON();
			{
				mongo::BSONArrayBuilder b;
				ForEachC(List, it, _recent)
					b.append(*it);
				obj << "r" << b.arr();
			}
			return db_mgr.SaveMongo(DBN::dbExpeditionStragety, key, obj.obj());
		}

		MapDataMgr::MapItem::MapItem(const Json::Value& info)
		{
			type = info["type"].asInt();
			if (type == 0)
			{
				npc_id = info["npc_id"].asInt();
			}
			else
			{
				rank.start_rank = info["start_rank"].asInt();
				rank.end_rank = info["end_rank"].asInt();
			}
		}

		MapDataMgr::MapData::MapData(const Json::Value& info)
		{
			start_lv = info["start_lv"].asInt();
			end_lv = info["end_lv"].asInt();
			const Json::Value& map_data = info["map_data"];
			ForEachC(Json::Value, it, map_data)
				map_item.push_back(MapItem(*it));
		}

		void MapDataMgr::loadFile()
		{
			FileJsonSeq vec;	
			vec = Common::loadFileJsonFromDir("./instance/expedition/npc");
			ForEachC(FileJsonSeq, it, vec)
			{
				const Json::Value& info = *it;
				mapDataConfig map_data;
				map_data.mapID = info["mapId"].asInt();
				map_data.background = info.isMember("background") ? info["background"].asInt() : 1;
				map_data.faceID = info["faceID"].asInt();
				map_data.mapName = info["mapName"].asString();
				map_data.mapLevel = info["mapLevel"].asInt();
				map_data.battleValue = info["battleValue"].asInt();
				map_data.needFood = info["needfood"].asInt();
				map_data.needAction = info["needAction"].asInt();
				map_data.chanllengeTimes = info["challengeTimes"].asInt();
				map_data.manExp = info["manExp"].asUInt();
				map_data.levelLimit = info["levelLimit"].asUInt();
				map_data.robotIDX = info["robotIDX"].asInt();
				const unsigned rwJsonID = info["winBox"].asUInt();
				map_data.winBox = actionFormat(rwJsonID);
				for (unsigned nn = 0; nn < info["army"].size(); ++nn)
				{
					Json::Value& npcJson = info["army"][nn];
					armyNPC npc;
					npc.npcID = npcJson["npcID"].asInt();
					npc.holdMorale = npcJson["holdMorale"].asBool();
					for (unsigned cn = 0; cn < characterNum; ++cn)
					{
						npc.initAttri[cn] = npcJson["initAttri"][cn].asInt();
					}
					npc.armsType = npcJson["armsType"].asInt();
					for (unsigned cn = 0; cn < armsModulesNum; ++cn)
					{
						npc.armsModule[cn] = npcJson["armsModule"][cn].asDouble();
					}
					npc.npcLevel = npcJson["npcLevel"].asInt();
					npc.npcPos = npcJson["npcPos"].asUInt() % 9;
					npc.battleValue = npcJson["battleValue"].asInt();
					npc.skill_1 = npcJson["skill_1"].asInt();
					npc.skill_2 = npcJson["skill_2"].asInt();
					for (unsigned eq_idx = 0; eq_idx < npcJson["equip"].size(); ++eq_idx)
					{
						npc.equipList.push_back(BattleEquip(npcJson["equip"][eq_idx][0u].asUInt(),
									npcJson["equip"][eq_idx][1u].asInt(),
									npcJson["equip"][eq_idx][2u].asUInt()));
					}
					map_data.npcList.push_back(npc);
				}
				sBattlePtr bptr = map_sys.npcSide(mapDatePtr);
				manList& ml = bptr->battleMan;
				for (unsigned i = 0; i < ml.size(); ++i)
					map_data.npcList[i].maxHp = ml[i]->currentHP;
				_npc_data[map_data.mapID] = map_data;
			}

			const Json::Value json = Common::loadJsonFile("./instance/expedition/map_data.json");
			ForEachC(Json::Value, it, json)
				_map_data.push_back(MapData(*it));
		}

		sBattlePtr MapDataMgr::getBattlePtr(playerDataPtr d, int pos) const
		{
			int idx = getIdx(d->LV());
			if (idx == -1)
				return sBattlePtr();
			const MapData& data = _map_data[idx];
			if (pos < 1 || pos > _map_data.size())
				return sBattlePtr();
			const MapItem& item = data[pos-1];
			if (item.type == 0)
			{
				NpcDataMap::const_iterator it = _npc_data.find(item.npc_id);
				if (it == _npc_data.end())
					return sBattlePtr();
				else
					return map_sys.npcSide(it->second);
			}
			else
			{
				int my_rank = d->Expedition().rank();
				int seed = d->Expedition().randSeed();
				int start_rank = my_rank;
				int end_rank = my_rank;
				if (item.front_rank != 0)
					start_rank -= item.front_rank;
				if (item.back_rank != 0)
					end_rank += item.back_rank;
				

			}
		}
	}

	using namespace Expedition;

	void expedition_system::initData()
	{
		loadFile();
		loadStrategy();
	}

	void expedition_system::loadFile()
	{
		MapDataMgr::shared();
		}

	}

	void expedition_system::loadStrategy()
	{
		objCollection objs = db_mgr.Query(DBN::dbExpeditionStragety);
		ForEachC(objCollection, it, objs)
		{
			StrategyPtr ptr = Creator<Expedition::Strategy>::Create(*it);
			_stragety_map.insert(make_pair(ptr->mID(), ptr));
		}
	}

	void expedition_system::playerInfo(net::Msg& m, Json::Value& r)
	{
		
	}

	void expedition_system::challenge(net::Msg& m, Json::Value& r)
	{
		playerDataPtr d = player_mgr.getPlayer(m.playerID);
		if (!d) Return(r, err_illedge);
		ReadJsonArray;
		int pos = js_msg[0u].asInt();
		if (pos != d->Expedition().pos() + 1)
			Return(r, err_illedge);
		sBattlePtr ptr = MapDataMgr::shared().getBattlePtr(d, pos);
		if (!ptr) Return(r, err_illedge);
	}

	void expedition_system::flush(net::Msg& m, Json::Value& r)
	{
	
	}

	void expedition_system::buyTimes(net::Msg& m, Json::Value& r)
	{
	
	}

	void expedition_system::strategyInfo(net::Msg& m, Json::Value& r)
	{
		playerDataPtr d = player_mgr.getPlayer(m.playerID);
		if (!d) Return(r, err_illedge);
		ReadJsonArray;
		int pos = js_msg[0u].asInt();
		int mid = 0;
		StrategyMap::iterator it = _stragety_map.find(mid);
		if (it == _stragety_map.end())
			sendEmptyStrategy(d);
		else
			it->second->update(d);
	}

	void expedition_system::sendEmptyStrategy(playerDataPtr d)
	{
		qValue m;
		m.append(res_sucess);
		m.append(qValue(qJson::qj_object));
		d->sendToClientFillMsg(gate_client::expedition_strategy_info_resp, m);
	}
}

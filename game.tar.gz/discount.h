//###################################
//create by Jim
//2016-10-27
//###################################

#pragma once

#include "dbDriver.h"

#define discout_sys (*gg::DiscountManager::_Instance)

namespace gg
{
	namespace Discount
	{
		enum
		{
			project_time = -1,

			exp_book_rate = 0,
			equip_wash_rate,
			market_cost_rate,
			market_buy_reward_rate,
			daily_task_reward_rate,
			team_war_drop_out_red_num,
			team_war_drop_out_purple_num,
			online_reward_rate,
			action_buy_cost_rate,
			team_war_drop_out_client_show,

			project_num,
		};

		struct Data
		{
			Data(const int type)
				: Type(type)
			{
				Value = 0;
			}
			const int Type;
			int Value;
			double getRate()const
			{
				return Value / 10000.0;
			}
			int getValue()const
			{
				return Value;
			}
			void save()const
			{
				mongo::BSONObj key = BSON("t" << Type);
				mongo::BSONObj val = BSON("t" << Type << "v" << Value);
				db_mgr.SaveMongo(DBN::dbDiscoutAndGain, key, val);
			}
			void del()const
			{
				mongo::BSONObj key = BSON("t" << Type);
				db_mgr.RemoveCollection(DBN::dbDiscoutAndGain, key);
			}
		};
		BOOSTSHAREPTR(Data, ptrData);
	}

	class DiscountManager
	{
	public:
		static DiscountManager* const _Instance;
		void initData();

		DeclareRegFunction(gm_discout_update);//���ݻ�ȡ
		DeclareRegFunction(gm_discout_set);//��������

		DeclareRegFunction(discout_update);//���ݻ�ȡ

		double getRate(const int type);
		double getRateOnly(const int type);
		int getValue(const int type);

		void sendData(playerDataPtr player);
		void sendDataToAll();
	private:
		void saveTime();
		bool isRun()const;
		unsigned BeginTime;
		unsigned EndTime;
		qValue packageData();
		UNORDERMAP(int, Discount::ptrData, DataMap);
		DataMap Datas;
	};
}
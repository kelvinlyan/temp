#include "daily_inpour_system.h"

namespace gg
{
	daily_inpour_system* const daily_inpour_system::_Instance = new daily_inpour_system();

	static InpourConfigPtr inpour_config;

	daily_inpour_system::daily_inpour_system()
	{
	}

	void daily_inpour_system::ReChargePlayerRecord(playerDataPtr player, int gold)
	{
		if (!player || gold < 0)
		{
			return;
		}
		int rmb = gold / 10;
		
		int i = 0;
		//���ӻ���
		for (i = 0; i < inpour_config->cashList.size(); ++i)
		{
			if (rmb >= inpour_config->cashList[i])
			{
				player->DailyInpour().addAcc(inpour_config->cashList[i], inpour_config->cashAccuList[i]);
				//���ӿ�����ȡ�Ľ��������γ�ֵ�
				player->DailyInpour().addBox(SINGLE_KEY, inpour_config->cashAccuBoxes[i].jsonBox);
				player->DailyInpour().addDailyAccessRecord(i);//���ӿ���ȡ���±�
			}
			else
			{
				break;
			}
		}
		//
		int total_accu = player->DailyInpour().getAcc();
		for (int i = 0; i < inpour_config->accuList.size(); ++i)
		{
			if (total_accu >= inpour_config->accuList[i])
			{
				//���ӿ�����ȡ�Ľ������ۼƻ����
				player->DailyInpour().addBox(ACCU_KEY, inpour_config->accuBoxes[i].jsonBox);
			}
		}
		//�ܱ���
		if (i > 0)
		{
			bool flag = player->DailyInpour().getWeekend();
			if (flag == false)
			{
				player->DailyInpour().addBox(SKEY, inpour_config->weekendBox.jsonBox);
			}
		}
		
		
	}

	void daily_inpour_system::reqDailyInpourInfo(net::Msg& m, Json::Value& r)
	{
		playerDataPtr player = player_mgr.getPlayer(m.playerID);
		if (!player)Return(r, err_illedge);

		r[strMsg][0u] = 0;

		Json::Value accu_box_json = Json::nullValue;
		Json::Value weekend_box_json = Json::nullValue;
		Json::Value single_inpour_box_json = Json::nullValue;
		//
		accu_box_json["cumsum"] = player->DailyInpour().getAcc();
		accu_box_json["accu"] = inpour_config->accuListJson;
		accu_box_json["boxes"] = inpour_config->accuBoxesJson;
		accu_box_json["flags"] = inpour_config->zeroAccuListJson;
		InpourList box_list = player->DailyInpour().getBoxRecord();

		for (int i = 0; i < box_list.size(); ++i)
		{
			accu_box_json["flags"][box_list[i]] = 1;
		}
		//
		weekend_box_json["box"] = inpour_config->weekendBox.jsonBox;
		weekend_box_json["flag"] = player->DailyInpour().getWeekend() == false ? 0 : 1;
		//
		single_inpour_box_json["cashes"] = inpour_config->cashListJson;
		single_inpour_box_json["boxes"] = inpour_config->cashAccuBoxesJson;
		single_inpour_box_json["flags"] = inpour_config->zeroCashAccJson;

		InpourList daily_box_access = player->DailyInpour().getDailyAccessRecord();
		InpourList daily_box_list = player->DailyInpour().getDailyRecord();
		for (int i = 0; i < daily_box_access.size(); ++i)
		{
			single_inpour_box_json["flags"][daily_box_access[i]] = 2;
		}
		for (int i = 0; i < daily_box_list.size(); ++i)
		{
			single_inpour_box_json["flags"][daily_box_list[i]] = 1;
		}

		r[strMsg][1u] = accu_box_json;
		r[strMsg][2u] = weekend_box_json;
		r[strMsg][3u] = single_inpour_box_json;
	}

	void daily_inpour_system::reqDailyInpourGetReward(net::Msg& m, Json::Value& r)
	{
		playerDataPtr player = player_mgr.getPlayer(m.playerID);
		if (!player)Return(r, err_illedge);

		ReadJsonArray;
		int type = js_msg[0u].asInt();
		int flag = js_msg[1u].asInt();
		if (type == 1) //�ۻ����ֱ�����ȡ
		{
			int i;
			for (i = 0; i < inpour_config->accuList.size(); ++i)
			{
				if (flag == inpour_config->accuList[i])
				{
					break;
				}
			}
			if (i == inpour_config->accuList.size())
			{
				Return(r, err_invalid_resp_data);
			}
			InpourList exists = player->DailyInpour().getBoxRecord();
			if (std::find(exists.begin(), exists.end(), i) != exists.end())
			{
				Return(r, err_fund_has_gotten);
			}
			//ִ���콱
			int ret = actionDoBox(player, inpour_config->accuBoxes[i].box, false);
			r[strMsg][0u] = ret;
			if (ret == 0)
			{
				r[strMsg][1u] = actionRes();
				player->DailyInpour().delBox(ACCU_KEY);
			}
			else
			{
				r[strMsg][1u] = actionError();
			}
			//���ݸ���
			player->DailyInpour().addBoxRecord(i);
		}
		else if (type == 3) //���ʳ�ֵ������ȡ
		{
			int i;
			for (i = 0; i < inpour_config->cashList.size(); ++i)
			{
				if (flag == inpour_config->cashList[i])
				{
					break;
				}
			}
			if (i == inpour_config->cashList.size())
			{
				Return(r, err_invalid_resp_data);
			}
			InpourList exists = player->DailyInpour().getDailyRecord();
			if (std::find(exists.begin(), exists.end(), i) != exists.end())
			{
				Return(r, err_fund_has_gotten);
			}
			//ִ���콱
			int ret = actionDoBox(player, inpour_config->cashAccuBoxes[i].box, false);
			r[strMsg][0u] = ret;
			if (ret == 0)
			{
				r[strMsg][1u] = actionRes();
				player->DailyInpour().delBox(SINGLE_KEY);
			}
			else
			{
				r[strMsg][1u] = actionError();
			}
			//���ݸ���
			player->DailyInpour().addDailyRecord(i);
		}
		else if (type == 2) //�ܱ�����ȡ
		{
			if (player->DailyInpour().getWeekend())
			{
				Return(r, err_fund_has_gotten);
			}
			//ִ���콱
			int ret = actionDoBox(player, inpour_config->weekendBox.box, false);
			r[strMsg][0u] = ret;
			if (ret == 0)
			{
				r[strMsg][1u] = actionRes();
				player->DailyInpour().delBox(SKEY);
			}
			else
			{
				r[strMsg][1u] = actionError();
			}
			//���ݸ���
			player->DailyInpour().setWeekend();
		}
		else
		{
			Return(r, err_invalid_resp_data);
		}
	}

	void daily_inpour_system::initData()
	{
		
		std::cout << "load ./daily_inpour/rewards.json START	" << std::endl;
		/*
		Json::Value value = Common::loadJsonFile(std::string("./instance/daily_inpour/rewards.json"));

		inpour_config = Creator<daily_inpour::InpourConfig>::Create();
		inpour_config->weekendBox.box = actionFormatBox(value["rnd_box"]);
		inpour_config->weekendBox.jsonBox = parseJson(value["rnd_box"]);
		inpour_config->weekendBox.strBox = parseJsonBox(value["rnd_box"]);
		Json::Value accu_json = value["accu"];
		inpour_config->accuListJson = accu_json;//
		inpour_config->zeroAccuListJson = Json::arrayValue;//
		for (int i = 0; i < accu_json.size(); ++i)
		{
			inpour_config->accuList.push_back(accu_json[i].asInt());
			inpour_config->zeroAccuListJson[i] = 0;//
		}

		Json::Value boxes_json = value["boxes"];
		inpour_config->accuBoxesJson = Json::arrayValue;//
		for (int i = 0; i < boxes_json.size(); ++i)
		{
			daily_inpour::BoxSingle single;
			single.box = actionFormatBox(boxes_json[i]);
			single.jsonBox = parseJson(boxes_json[i]);
			single.strBox = parseJsonBox(boxes_json[i]);
			inpour_config->accuBoxesJson[i] = single.jsonBox;//
			inpour_config->accuBoxes.push_back(single);
		}

		assert(inpour_config->accuList.size() == inpour_config->accuBoxes.size());

		Json::Value rewards_json = value["rewards"];
		inpour_config->cashListJson = Json::arrayValue;//
		for (int i = 0; i < rewards_json.size(); i += 2)
		{
			inpour_config->cashList.push_back(rewards_json[i].asInt());
			inpour_config->cashAccuList.push_back(rewards_json[i + 1].asInt());

			inpour_config->cashListJson[i / 2] = rewards_json[i].asInt();//
		}

		Json::Value s_boxes_json = value["s_boxes"];
		inpour_config->cashAccuBoxesJson = Json::arrayValue;//
		inpour_config->zeroCashAccJson = Json::arrayValue;//
		for (int i = 0; i < s_boxes_json.size(); ++i)
		{
			daily_inpour::BoxSingle single;
			single.box = actionFormatBox(s_boxes_json[i]);
			single.jsonBox = parseJson(s_boxes_json[i]);
			single.strBox = parseJsonBox(s_boxes_json[i]);
			inpour_config->cashAccuBoxes.push_back(single);
			inpour_config->cashAccuBoxesJson[i] = single.jsonBox;//
			inpour_config->zeroCashAccJson[i] = 0;//
		}

		assert(inpour_config->cashList.size() == inpour_config->cashAccuBoxes.size());
		*/
		std::cout << "load ./daily_inpour/rewards.json END	" << std::endl;
		
	}


	daily_inpour_system::~daily_inpour_system()
	{
	}
}

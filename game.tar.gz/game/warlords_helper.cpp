#include "warlords_helper.h"
#include "warlords_system.h"

namespace gg
{
	namespace WarLords
	{
		PlayerInfo::PlayerInfo(playerDataPtr d)
		{
			pid = d->ID();
			face = d->Info().Face();
			name = d->Name();
			lv = d->LV();
			cd = d->WarLords().getCd();
			//power = d->WarFM().currentBV();
			power = d->Info().MaxBV();
			evil_value = d->WarLords().getEvilValue();
		}

		inline void PlayerInfo::getInfo(Json::Value& q) const
		{
			q.append(pid);
			q.append(name);
			q.append(face);
			q.append(lv);
			q.append(cd);
			q.append(power);
			Json::Value ev;
			for(unsigned i = 0; i < 3; ++i)
				ev.append(evil_value[i]);
			q.append(ev);
		}

		void PlayerListMgr::init(unsigned size)
		{
			for(unsigned i = 0; i < Kingdom::nation_num; ++i)
			{
				player_list[i].assign(150, OnOffLineList());
			}

			//STDMAP(int, InitHelpStruct, HelperMap);
			//HelperMap helper_map;


			STDVECTOR(InitHelpStruct, PlayerVec);
			PlayerVec vec[Kingdom::nation_num];

			{
				objCollection objs = db_mgr.Query(DBN::dbPlayerBase);
				ForEachC(objCollection, it, objs)
				{
					const mongo::BSONObj& obj = (*it);
					int nation = obj["nat"].Int();
					if (nation == Kingdom::null)
						continue;
					InitHelpStruct h;
					h.pid = obj[strPlayerID].Int();
					h.lv = obj[strPlayerLV].Int();
					h.nation = nation;
					vec[nation].push_back(h);
				}
			}

			for (unsigned i = 0; i < Kingdom::nation_num; ++i)
				std::sort(vec[i].begin(), vec[i].end());

			for (unsigned i = 0; i < Kingdom::nation_num; ++i)
			{
				std::vector<int> counts;
				counts.assign(size, 0);

				ForEachC(PlayerVec, it, vec[i])
				{
					int pid = it->pid;
					int lv = it->lv;
					int type = warlords_sys.getTypeByLv(lv);
					if (type == -1 || counts[type] >= InitSize)
						continue;
					playerDataPtr d = player_mgr.getPlayer(pid);
					if (d)
					{
						++counts[type];
						player_list[i][lv].offline.push_back(Creator<PlayerInfo>::Create(d));
					}	
				}
			}

	/*		for (unsigned i = 0; i < 3; ++i)
			{
				for (unsigned j = 1; j <= 100; ++j)
				{
					PlayerList& cur = player_list[i][j].offline;
					ForEach(PlayerList, it, cur)
					{
						LogI << "Nation:" << i << ", LV:" << j << ", Name:" << (*it)->name << LogEnd;
					}
				}
			}*/
		}

		int PlayerListMgr::getAllPage(int nation, int begin, int end) const
		{
			int idx = begin;
			int count = 0;
			for (; idx >= end; --idx)
			{
				count += player_list[nation][idx].online.size();
				count += player_list[nation][idx].offline.size();
			}
			if (count == 0)
				return 0;
			return (count - 1) / (int)PageSize + 1;
		}

		int PlayerListMgr::getPageByPid(int nation, int begin, int end, int pid) const
		{
			int offset = 0;
			for (int idx = begin; idx >= end; --idx)
			{
				ForEachC(PlayerList, it, player_list[nation][idx].online)
				{
					++offset;
					if ((*it)->pid == pid)
					{
						return (offset - 1) / (int)PageSize;
					}
				}
			}
			return 0;
		}

		void PlayerListMgr::getInfo(int nation, int begin, int end, int page, Json::Value& q) const
		{
			int begin_offset = page * PageSize; 
			int end_offset = begin_offset + PageSize; 
			int cur_offset = 0;

			int idx = begin;
			bool idx_online = true;

			for(; idx >= end; --idx)
			{
				cur_offset += player_list[nation][idx].online.size();	
				if (cur_offset >= begin_offset)
					break;
			}

			if(idx < end)
			{
				idx_online = false;

				idx = begin;
				for(; idx >= end; --idx)
				{
					cur_offset += player_list[nation][idx].offline.size();
					if(cur_offset >= begin_offset)
						break;
				}
				if(idx < end)
					return;
				else
					cur_offset -= player_list[nation][idx].offline.size();
			}
			else
			{
				cur_offset -= player_list[nation][idx].online.size();
			}
			
			while(true)
			{
				for (; idx >= end; --idx)
				{
					const PlayerList& p = idx_online?
						player_list[nation][idx].online : player_list[nation][idx].offline;	
					ForEachC(PlayerList, it, p)
					{
						if (cur_offset >= end_offset)
							return;
						if (cur_offset >= begin_offset)
						{
							Json::Value tmp;
							(*it)->getInfo(tmp);
							q.append(tmp);
						}
						++cur_offset;
					}
				}
				
				if (!idx_online)
					break;
				idx_online = false;
				idx = begin;
			}
		}

		void PlayerListMgr::updateLv(playerDataPtr d, int olv)
		{
			int nation = d->Info().Nation();
			if (nation == Kingdom::null)
				return;

			PlayerList& pre = d->isOnline()?
				player_list[nation][olv].online : player_list[nation][olv].offline;
			
			PlayerPtr p;
			ForEach(PlayerList, it, pre)
			{
				if ((*it)->pid == d->ID())
				{
					p = *it;
					pre.erase(it);
					break;
				}
			}

			if (!p)
				p = Creator<PlayerInfo>::Create(d);

			PlayerList& cur = d->isOnline()?
				player_list[nation][d->LV()].online : player_list[nation][d->LV()].offline;
				
			cur.push_back(p);
		}

		void PlayerListMgr::updateName(playerDataPtr d)
		{
			int nation = d->Info().Nation();
			if (nation == Kingdom::null)
				return;

			PlayerList& cur = d->isOnline()?
				player_list[nation][d->LV()].online : player_list[nation][d->LV()].offline;
			
			ForEach(PlayerList, it, cur)
			{
				if ((*it)->pid == d->ID())
				{
					(*it)->name = d->Name();
					break;
				}
			}
		}

		void PlayerListMgr::updateCd(playerDataPtr d)
		{
			int nation = d->Info().Nation();
			if (nation == Kingdom::null)
				return;

			PlayerList& cur = d->isOnline()?
				player_list[nation][d->LV()].online : player_list[nation][d->LV()].offline;
			
			ForEach(PlayerList, it, cur)
			{
				if ((*it)->pid == d->ID())
				{
					(*it)->cd = d->WarLords().getCd();
					break;
				}
			}
		}

		void PlayerListMgr::updateLogin(playerDataPtr d)
		{
			int nation = d->Info().Nation();
			if (nation == Kingdom::null)
				return;

			PlayerList& pre = player_list[nation][d->LV()].offline;
			
			PlayerPtr p;
			ForEach(PlayerList, it, pre)
			{
				if ((*it)->pid == d->ID())
				{
					p = *it;
					pre.erase(it);
					break;
				}
			}

			if (!p)
				p = Creator<PlayerInfo>::Create(d);

			PlayerList& cur = player_list[nation][d->LV()].online;
			
			cur.push_back(p);
		}

		void PlayerListMgr::updateLogout(playerDataPtr d)
		{
			int nation = d->Info().Nation();
			if (nation == Kingdom::null)
				return;

			PlayerList& pre = player_list[nation][d->LV()].online;
			
			PlayerPtr p;

			ForEach(PlayerList, it, pre)
			{
				if ((*it)->pid == d->ID())
				{
					p = *it;
					pre.erase(it);
					break;
				}
			}

			if (!p)
				p = Creator<PlayerInfo>::Create(d);

			PlayerList& cur = player_list[nation][d->LV()].offline;
			
			cur.push_back(p);
		}

		void PlayerListMgr::updatePower(playerDataPtr d)
		{
			int nation = d->Info().Nation();
			if (nation == Kingdom::null)
				return;

			PlayerList& cur = d->isOnline()?
				player_list[nation][d->LV()].online : player_list[nation][d->LV()].offline;
			
			ForEach(PlayerList, it, cur)
			{
				if ((*it)->pid == d->ID())
				{
					(*it)->power = d->WarFM().currentBV();
					break;
				}
			}
		}

		void PlayerListMgr::updateEvilValue(playerDataPtr d)
		{
			int nation = d->Info().Nation();
			if (nation == Kingdom::null)
				return;

			PlayerList& cur = d->isOnline()?
				player_list[nation][d->LV()].online : player_list[nation][d->LV()].offline;
			
			ForEach(PlayerList, it, cur)
			{
				if ((*it)->pid == d->ID())
				{
					PlayerPtr p = *it;
					p->evil_value = d->WarLords().getEvilValue();
					break;
				}
			}
		}
	}
}

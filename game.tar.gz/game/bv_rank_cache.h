#pragma once

#include "kingdomwar_helper.h"
#include "auto_base.h"

namespace gg
{
	class BVRankCache
		: public _auto_meta
	{
		SINGLETON_PTR(BVRankCache);
		public:
			unsigned maxSize() const
			{
				return _pid2rank.size();
			}
			int getRank(int pid) const
			{
				PID2Rank::const_iterator it = _pid2rank.find(pid);
				if (it == _pid2rank.end())
					return _pid2rank.size();
				return it->second;
			}
			int getPID(int rank) const
			{
				if (rank > _rank2pid.size())
					return -1;
				return _rank2pid[rank-1];
			}
		private:
			void init();
			void tick();
			virtual bool _auto_save();
			
		private:
			STDVECTOR(int, Rank2PID);
			STDMAP(int, int, PID2Rank);
			Rank2PID _rank2pid;
			PID2Rank _pid2rank;
			unsigned _next_tick_time;
	};
}

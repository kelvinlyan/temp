#include "gamer_daily_card.h"
#include "dbDriver.h"
#include "email_system.h"

namespace gg
{
	playerDailyCard::playerDailyCard(playerData* const own) : _auto_player(own)
	{
		ownCards.clear();
	}

	void playerDailyCard::clearDead()
	{
		for (int i = DAILYCARD::card_begin; i < DAILYCARD::card_num; ++i)
		{
			getCard(i);
		}
	}

	DAILYCARD::ptrData playerDailyCard::getCard(const int cardID)
	{
		CardMap::iterator it = ownCards.find(cardID);
		if (it != ownCards.end())
		{
			DAILYCARD::ptrData ptr = it->second;
			if (ptr->isOver())
			{
				ownCards.erase(it);
				_sign_auto();
				Json::Value p_json = Json::arrayValue;
				EmailPtr email_ptr = email_sys.createSystem(EmailDef::CardOutOfTime, p_json);
				email_sys.sendToPlayer(Own().ID(), email_ptr);
				return DAILYCARD::ptrData();
			}
			return ptr;
		}
		return DAILYCARD::ptrData();
	}

	const static unsigned CardLastTime[] = {30, 0};
	int playerDailyCard::addCard(const int cardID)
	{
		if (!DAILYCARD::isVaildCard(cardID))return err_illedge;
		if (getCard(cardID))return err_daily_card_has_hold;
		ownCards[cardID] = Creator<DAILYCARD::Data>::Create(cardID, CardLastTime[cardID]);
		_sign_auto();
		return res_sucess;
	}

	const static unsigned CardAwardNum[] = {120, 180};
	int playerDailyCard::wardCard(const int cardID, int& rwnum)
	{
		const int res = wardCard(cardID);
		if (res == res_sucess)
		{
			rwnum = CardAwardNum[cardID];
		}
		return res;
	}

	int playerDailyCard::wardCard(const int cardID)
	{
		if (!DAILYCARD::isVaildCard(cardID))return err_illedge;
		DAILYCARD::ptrData ptr = getCard(cardID);
		if (!ptr)return err_daily_card_no_found;
		if (Common::gameTime() <= ptr->wardTime)return err_daily_card_award_cd;
		Own().Res().alterTicket(CardAwardNum[cardID]);
		ptr->wardTime = Common::getNextTime(5);
		_sign_auto();
		Log(DBLOG::strLogDailyCard, Own().getOwnDataPtr(), 1, cardID, CardAwardNum[cardID]);
		return res_sucess;
	}

	void playerDailyCard::classFinal()
	{
		clearDead();
	}

	void playerDailyCard::setData(mongo::BSONObj& obj)
	{
		if (obj.isEmpty())return;
		vector<mongo::BSONElement> vec = obj["arr"].Array();
		for (unsigned i = 0; i < vec.size(); ++i)
		{
			mongo::BSONElement& elem = vec[i];
			const int cardID = elem["id"].Int();
			if (DAILYCARD::isVaildCard(cardID))
			{
				const unsigned endTime = elem["et"].Int();
				const unsigned wardTime = elem["at"].Int();
				DAILYCARD::ptrData ptr = Creator<DAILYCARD::Data>::Create(cardID, 0);
				memmove((void*)(&ptr->dayLeave), &endTime, sizeof(unsigned));
				ptr->wardTime = wardTime;
				ownCards[cardID] = ptr;
			}
		}
	}

	bool playerDailyCard::_auto_save()
	{
		mongo::BSONObj key = BSON(strPlayerID << Own().ID());
		mongo::BSONArrayBuilder arr;
		for (CardMap::iterator it = ownCards.begin(); it != ownCards.end(); ++it)
		{
			DAILYCARD::ptrData ptr = it->second;
			arr << BSON("id" << ptr->cardID << "et" << ptr->dayLeave << "at" << ptr->wardTime);
		}
		mongo::BSONObj obj = BSON("$set" << BSON("DailyCard" << 
			BSON("arr" << arr.arr())
			));
		return db_mgr.SaveMongo(DBN::dbPlayerCollection, key, obj);
	}

	void playerDailyCard::_auto_update()
	{
		qValue list_json(qJson::qj_array), resJson(qJson::qj_array);
		for (CardMap::iterator it = ownCards.begin(); it != ownCards.end(); ++it)
		{
			DAILYCARD::ptrData ptr = it->second;
			qValue sg_json(qJson::qj_array);
			sg_json.append(ptr->cardID);
			sg_json.append(ptr->dayLeave);
			sg_json.append(ptr->wardTime);
			resJson.append(sg_json);
		}
		list_json.append(res_sucess);
		list_json.append(resJson);
		Own().sendToClientFillMsg(gate_client::player_daily_card_update_resp, list_json);
	}
}

#include "player_island_activity.h"
#include "island_activity_system.h"
#include "playerManager.h"

namespace gg
{
	namespace nIsland
	{
		enum
		{
			TreasurePiece = 50084,
			KeyPiece = 50085,
		};

		int KeyPieceID() { return KeyPiece; }

		class Config
		{
			SINGLETON(Config);
			public:
				int TreasurePiecesPerAction;
				int TreasurePiecesPerGold;
				//int TreasurePiecesLimitByAction;
				//int TreasurePiecesLimitByGold;
				int TurnTableCost;
				int OpenBoxCost;
				int randKeyPiece() const;
				
				std::vector<int> _rand_percent;
				std::vector<int> _rand_num;
		};

		Config::Config()
		{
			const Json::Value info = Common::loadJsonFile("./instance/island_activity/param.json");
			TreasurePiecesPerAction = info["treasure_pieces_per_action"].asInt();
			TreasurePiecesPerGold = info["treasure_pieces_per_gold"].asInt();
			//TreasurePiecesLimitByAction = info["treasure_pieces_limit_by_action"].asInt();
			//TreasurePiecesLimitByGold = info["treasure_pieces_limit_by_gold"].asInt();
			TurnTableCost = info["turntable_cost"].asInt();
			OpenBoxCost = info["openbox_cost"].asInt();
			const Json::Value& per = info["key_pieces_percent"];
			int sum = 0;
			ForEachC(Json::Value, it, per)
			{
				sum += (*it).asInt();
				_rand_percent.push_back(sum);
			}
			const Json::Value& num = info["key_pieces_num"];
			ForEachC(Json::Value, it, num)
				_rand_num.push_back((*it).asInt());
		}

		int Config::randKeyPiece() const
		{
			int r = Common::random() % _rand_percent.back();
			for (unsigned i = 0; i < _rand_percent.size(); ++i)
			{
				if (r < _rand_percent[i])
					return _rand_num[i];
			}
			return _rand_num.front();
		}

		int randKeyPiece() { return Config::shared().randKeyPiece(); }
	}

	playerIslandActivity::playerIslandActivity(playerData* const own)
		: _auto_player(own)
	{
		_key_id = -1;
		_treasure_pieces_limit_by_gold = 0;
		_treasure_pieces_limit_by_action = 0;
	}

	void playerIslandActivity::setData(mongo::BSONObj& obj)
	{
		if (obj.isEmpty()) 
			return;
		checkNotEoo(obj["kid"])
			_key_id = obj["kid"].Int();
		checkNotEoo(obj["tplbg"])
			_treasure_pieces_limit_by_gold = obj["tplbg"].Int();
		checkNotEoo(obj["tplba"])
			_treasure_pieces_limit_by_action = obj["tplba"].Int();
		checkNotEoo(obj["rl"])
		{
			std::vector<mongo::BSONElement> ele = obj["rl"].Array();
			for (unsigned i = 0; i < ele.size(); ++i)
				_record_list.push_back(ele[i].String());
		}
	}

	bool playerIslandActivity::_auto_save()
	{
		mongo::BSONObj key = BSON(strPlayerID << Own().ID());
		mongo::BSONObjBuilder obj;
		obj << "kid" << _key_id << "tplbg" << _treasure_pieces_limit_by_gold
			<< "tplba" << _treasure_pieces_limit_by_action;
		{
			mongo::BSONArrayBuilder b;
			ForEachC(std::list<std::string>, it, _record_list)
				b.append(*it);
			obj << "rl" << b.arr();
		}
		mongo::BSONObj set_obj = BSON("$set" << BSON("IslandActivity" << obj.obj()));
		return db_mgr.SaveMongo(DBN::dbPlayerCollection, key, set_obj);
	}

	void playerIslandActivity::sendBase()
	{
		update();
		qValue m;
		m.append(res_sucess);
		qValue q(qJson::qj_object);
		q.addMember("tplba", _treasure_pieces_limit_by_action);
		q.addMember("tplbg", _treasure_pieces_limit_by_gold);
		m.append(q);
		Own().sendToClientFillMsg(gate_client::island_activity_player_info_resp, m);
	}

	void playerIslandActivity::update()
	{
		int key_id = island_activity_sys.current()?
			island_activity_sys.current()->keyID() : -1;
		if (_key_id != key_id)
		{
			_key_id = key_id;
			_treasure_pieces_limit_by_action = 0;
			_treasure_pieces_limit_by_gold = 0;
			{
				int num = Own().Items().itemNum(nIsland::TreasurePiece);
				if (num > 0)
					Own().Items().removeItem(nIsland::TreasurePiece, num);
			}
			{
				int num = Own().Items().itemNum(nIsland::KeyPiece);
				if (num > 0)
					Own().Items().removeItem(nIsland::KeyPiece, num);
			}
			_record_list.clear();
			_sign_save();
		}
	}

	int playerIslandActivity::turnTable(int type, int times_type, Json::Value& r)
	{
		update();
		if (!island_activity_sys.current())
			return err_illedge;
		unsigned times = times_type == 0? 1 : 10;
		int need_piece = times * nIsland::Config::shared().TurnTableCost;
		if (Own().Items().itemNum(nIsland::TreasurePiece) < need_piece)
			return err_item_not_enough;
		bool up_bc = false;
		for (unsigned i = 0; i < times; ++i)
		{
			int idx;
			bool bc;
			ActionBoxList rw = island_activity_sys.current()->turnTableReward(type, idx, bc);
			int res = actionDoBox(Own().getOwnDataPtr(), rw, false);
			if (res == res_sucess)
			{
				Own().Items().removeItem(nIsland::TreasurePiece, nIsland::Config::shared().TurnTableCost);
				const Json::Value rw_json = actionRes();
				r[strMsg][1u].append(rw_json);
				r[strMsg][2u].append(idx);
				if (bc)
				{
					up_bc = true;
					qValue r;
					r << Own().Name() << qValue(rw_json.toIndentString().c_str()) << type;
					island_activity_sys.current()->addRecord(r);
				}
				{
					qValue r;
					r << qValue(rw_json.toIndentString().c_str()) << type << Common::gameTime();
					_record_list.push_front(r.toIndentString());
					while (_record_list.size() > 100)
						_record_list.pop_back();
				}
				Log(DBLOG::strLogIslandActivity, Own().getOwnDataPtr(), 0, type, times, need_piece, "", "", "", "", rw_json.toIndentString());
			}
			else
			{
				r[strMsg][1u].append(Json::arrayValue);
				r[strMsg][2u].append(-1);
			}
		}
		if (up_bc)
			island_activity_sys.current()->sendRecord(Own().getOwnDataPtr());
		_sign_save();
		return res_sucess;
	}

	int playerIslandActivity::openBox(Json::Value& r)
	{
		update();
		if (!island_activity_sys.current())
			return err_illedge;
		int need_piece = nIsland::Config::shared().OpenBoxCost;
		if (Own().Items().itemNum(nIsland::KeyPiece) < need_piece)
			return err_item_not_enough;
		int idx;
		bool bc;
		const ActionBoxList& rw = island_activity_sys.current()->turnTableReward(2, idx, bc);
		int res = actionDoBox(Own().getOwnDataPtr(), rw, false);
		if (res == res_sucess)
		{
			Own().Items().removeItem(nIsland::KeyPiece, nIsland::Config::shared().OpenBoxCost);
			const Json::Value rw_json = actionRes();
			r[strMsg][1u].append(rw_json);
			if (bc)
			{
				qValue r;
				r << Own().Name() << qValue(rw_json.toIndentString().c_str()) << 2;
				island_activity_sys.current()->addRecord(r);
				island_activity_sys.current()->sendRecord(Own().getOwnDataPtr());
			}
			{
				qValue r;
				r << qValue(rw_json.toIndentString().c_str()) << 2 << Common::gameTime();
				_record_list.push_front(r.toIndentString());
			}
			Log(DBLOG::strLogIslandActivity, Own().getOwnDataPtr(), 1, need_piece, "", "", "", "", "", "", rw_json.toIndentString());
		}
		else
		{
			r[strMsg][1u].append(Json::arrayValue);
			r[strMsg][2u].append(-1);
		}
		_sign_save();
		return res_sucess;
	}

	void playerIslandActivity::dailyTick()
	{
		if (_treasure_pieces_limit_by_action != 0
			|| _treasure_pieces_limit_by_gold != 0)
		{
			_treasure_pieces_limit_by_action = 0;
			_treasure_pieces_limit_by_gold = 0;
			_sign_save();
		}
	}

	void playerIslandActivity::sendRecord()
	{
		update();
		if (!island_activity_sys.current())
			return;
		std::string str;
		str += "{\"msg\":[0,[";
		ForEachC(std::list<std::string>, it, _record_list)
		{
			if (it != _record_list.begin())
				str += ",";
			str += *it;
		}
		str += "]]}";
		Own().sendToClient(gate_client::island_activity_own_reward_info_resp, str);
	}

	ActionBoxList playerIslandActivity::getTreasurePieceByAction(int num)
	{
		if (!island_activity_sys.current())
			return ActionBoxList();
		if (_treasure_pieces_limit_by_action >= island_activity_sys.current()->limitByAction())
			return ActionBoxList();
		int max = island_activity_sys.current()->limitByAction() - _treasure_pieces_limit_by_action;
		int val = nIsland::Config::shared().TreasurePiecesPerAction * num;
		val = val > max? max : val;
		_treasure_pieces_limit_by_action += val;
		ACTION::Box b;
		b.actionID = ACTION::item;
		b.boxData._Item.itemID = nIsland::TreasurePiece;
		b.boxData._Item.num = val;
		_sign_save();
		return ActionBoxList(1, b);
	}

	ActionBoxList playerIslandActivity::getTreasurePieceByGold(int num)
	{
		if (!island_activity_sys.current())
			return ActionBoxList();
		if (_treasure_pieces_limit_by_gold >= island_activity_sys.current()->limitByGold())
			return ActionBoxList();
		int max = island_activity_sys.current()->limitByGold() - _treasure_pieces_limit_by_gold;
		int val = nIsland::Config::shared().TreasurePiecesPerGold * num;
		val = val > max? max : val;
		_treasure_pieces_limit_by_gold += val;
		ACTION::Box b;
		b.actionID = ACTION::item;
		b.boxData._Item.itemID = nIsland::TreasurePiece;
		b.boxData._Item.num = val;
		_sign_save();
		return ActionBoxList(1, b);
	}
}

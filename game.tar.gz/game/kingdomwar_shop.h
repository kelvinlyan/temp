#pragma once

#include "dbDriver.h"
#include "commom.h"
#include "shop_mgr.h"

#define kingdomwar_shop (*gg::kingdomwar_shop_system::_Instance)

namespace gg
{
	class kingdomwar_shop_system
	{
		public:
			static kingdomwar_shop_system* const _Instance;

			void initData();

			DeclareRegFunction(boxRewardReq);
			DeclareRegFunction(getBoxRewardReq);
	};
}

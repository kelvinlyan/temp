//###################################
//create by Jim
//2015-11-16
//###################################

#pragma once

#include "man_def.h"
#include "commom.h"
#include "skill_def.h"
#include "passive_def.h"
#include "logger_damage.h"

namespace gg
{
	const static unsigned BigRound_ = 30;
	const static unsigned InvalidBattleIDX = 0xFFFFFFFF;

	namespace BATTLEEVENT
	{
		enum TEAM
		{
			nothing, //ʲô��Ҳû����
			leave,//��ʤ�˳�
			lose,//ʧ���˳�
		};

		enum HPALTER
		{
			hp_attack,//����
			hp_cure,//����
			hp_absorb,//����
			hp_direct,//ֱ������
			hp_effect,//buffӰ��
			hp_block,//���Ը񵲵��˺�
		};

		enum MPALTER
		{
			mp_natural,//��Ȼ����
			mp_cure,//����
			mp_absorb,//����
			mp_effect,//buffӰ��
			mp_skill,//����Ӱ��
			mp_power,//ʹ�ü���
		};

		enum SHIELDALTER
		{
			shield_replace,//buff�滻
			shield_attack,//�ܵ��˺�
			shield_buff,//buff�˺�
		};

		enum BE
		{
			run_failed = 0,//���ܶ��ͷ�ʧ��
			dodge = 1,//����
			block = 2,//��
			hp_alter = 3,//hp�仯
			mp_alter = 4,//mp�仯
			dead = 5,//����
			attack = 6,//ʹ�ü���
			counter_attack = 7,//ʹ�÷�������
			union_attack = 8,//���Ϲ��� 
			effect_run = 9,//buff�����Լ�buff����
			effect_delete = 10,//ɾ��buff
			effect_set = 11,//����buff
			effect_reset = 12,//������ͬ��buff
			user_lock = 13,//�佫�޷��ж�
			battle_begin = 14,//����ս����ʼ
			battle_end = 15,//����ս������
			shield_alter = 16,//����ֵ�仯
			user_child = 17,//ʹ���Ӽ���
		};
	}

	class manBattle;
	namespace MANEFFECT
	{
		struct Stun
		{
			bool isEffect;
		};
		struct EFValue
		{
			int valEffect[BigRound_];
		};
		union Declare
		{
			Stun _stun;
			EFValue _value;
		};
		struct Data
		{
			Data(){
				declare = NULL;
				lastRound = 0;
				holderMan = NULL;
				isNew = true;
				memset(&otherData, 0x0, sizeof(Declare));
			}
			BUFF::Data const *declare;//����//����
			unsigned lastRound;//ʣ��غ���
			manBattle* holderMan;//������
			bool isNew;//�Ƿ��������õ�buff
			Declare otherData;//��������
		};

	}
	BOOSTSHAREPTR(MANEFFECT::Data, ptrManBuff);

	class playerData;
	BOOSTSHAREPTR(playerData, playerDataPtr);
	class battleLogic;
	class manBattle;
	BOOSTSHAREPTR(manBattle, mBattlePtr);

	struct BattleEquip
	{
		BattleEquip(const unsigned ePos = 0, const int eID = 0, const unsigned eLV = 0)
		{
			equipPos = ePos;
			equipID = eID;
			equipLevel = eLV;
		}
		unsigned equipPos;
		int equipID;
		unsigned equipLevel;
	};
	STDVECTOR(BattleEquip, BattleEquipList);

	class manBattle :
		public boost::enable_shared_from_this<manBattle>
	{
	public:
		manBattle()
		{
			manID = -1;
			battleValue = 0;
			holdMorale = false;
			skill_1 = NULL;
			skill_2 = NULL;
			currentHP = 0;
			beginHP = 0;
			skillMorale = 0;//
			currentMorale = 0;//
			armsType = 0;
			manLevel = 0;
			currentIdx = 0;
			currentX = 0;
			currentY = 0;
			currentS = 0;//Ĭ�Ϲ�����
			shield = 0;
			beAtoD = true;//�Ӵ�����
			stateLock.clear();//Ĭ�Ͻ������
			resist.clear();
			passiveHolder.clear();
			passiveHolder.resize(PASSIVE::_passive_tick_num);
			passiveIDList.clear();
			talent.clear();
			talent.reserve(32);
			memset(armsModule, 0x0, sizeof(armsModule));
			memset(initialAttri, 0x0, sizeof(initialAttri));
			memset(battleAttri, 0x0, sizeof(battleAttri));
			memset(addAttri, 0x0, sizeof(addAttri));
			memset(rateAttri, 0x0, sizeof(rateAttri));
			holdBuffs.clear();
			dispatchBuffs.clear();
			loggerDamage = NULL;
		}
		void resetInitial()//������������ļ���, ��ô����������
		{
			beAtoD = true;//�Ӵ�����
			stateLock.clear();//����������
			shield = 0;//������Ϊ0,�����buffÿ�ο�ʼ�Ӷ����������
			skillMorale = 0;//
			currentMorale = 0;//
			memset(addAttri, 0x0, sizeof(addAttri));//���ӵ�����
			memset(rateAttri, 0x0, sizeof(rateAttri));//���ӵ�����
			holdBuffs.clear();
			beginHP = currentHP;//����֮��HP��¼
		}
		inline mBattlePtr OwnPtr() { return shared_from_this(); }
		static mBattlePtr CreateFrom(mBattlePtr from)
		{
			mBattlePtr newMan = Creator<manBattle>::Create();
			if (from)
			{
				newMan->manID = from->manID;
				newMan->battleValue = from->battleValue;
				newMan->holdMorale = from->holdMorale;
				newMan->skill_1 = from->skill_1;
				newMan->skill_2 = from->skill_2;
				newMan->currentHP = from->currentHP;
				newMan->currentIdx = from->currentIdx;
				newMan->currentMorale = from->currentMorale;
				newMan->armsType = from->armsType;
				newMan->manLevel = from->manLevel;
				newMan->currentX = from->currentX;
				newMan->currentY = from->currentY;
				newMan->currentS = from->currentS;
				newMan->shield = from->shield;
				newMan->resist = from->resist;
				newMan->passiveIDList = from->passiveIDList;
				newMan->passiveHolder = from->passiveHolder;
				newMan->talent = from->talent;
				memcpy(newMan->armsModule, from->armsModule, sizeof(from->armsModule));
				memcpy(newMan->initialAttri, from->initialAttri, sizeof(from->initialAttri));
				memcpy(newMan->battleAttri, from->battleAttri, sizeof(from->battleAttri));
				memcpy(newMan->addAttri, from->addAttri, sizeof(from->addAttri));
				memcpy(newMan->rateAttri, from->rateAttri, sizeof(from->rateAttri));
				newMan->equipList = from->equipList;
			}
			return newMan;
		}
		//���д������BUFF//֮�������
		double armsModule[armsModulesNum];//����ϵ��
		int initialAttri[characterNum];//��������
		int battleAttri[characterNum];//ȫ������
		int addAttri[characterNum];
		int rateAttri[characterNum];
		int currentHP;//��ǰhp
		int beginHP;//ս����ʼ��ʱ��HP
		int shield;//����ֵ
		int armsType;//��������
		int manLevel;//�佫�ȼ�
		int manID;//�佫ID
		int battleValue;//�佫ս����
		unsigned currentIdx;//��ǰ����//0~8 9~17
		bool holdMorale;//�Ƿ�ӵ������
		bool beAtoD;//�Ӵ�����
		BattleLog::logger_interface* loggerDamage;
		std::vector<int> talent;//�츳
		BattleEquipList equipList;
		std::set<int> resist;
		inline bool resistBuff(const int buffID)
		{
			return resist.find(buffID) != resist.end();
		}
		typedef std::map<int, passiveData> passiveMap;
		std::vector< passiveMap > passiveHolder;//��������
		typedef boost::unordered_map<int, int> passiveList;
		passiveList passiveIDList;
		void add_passive(const int passiveID);
		//buff
		//���ɳ�ȥ��buff
		std::list<ptrManBuff> dispatchBuffs;

		//�Լ����е�buff
		BOOSTWEAKPTR(MANEFFECT::Data, ptrWeakBuff);
		UNORDERMAP(int, ptrWeakBuff, HoldBuffMap);
		HoldBuffMap holdBuffs;
		ptrManBuff getEffect(const int buffID)
		{
			HoldBuffMap::iterator it = holdBuffs.find(buffID);
			if (it == holdBuffs.end())return ptrManBuff();
			return it->second.lock();
		}

		//ʿ������
		int skillMorale;//����ʿ��
		int currentMorale;//��ǰʿ��
		inline int useSkillMorale(){//ʹ�ü��ܵ�ʿ��
			return skillMorale;
		}
		inline int irrelateMorale(){//�޹�����ʿ��
			return currentMorale;
		}
		inline int totalMorale(){//��ʿ��//��������ޱ����600//���ܻ�Ӱ���˺�ֵ
			return skillMorale + currentMorale;
		}
		int alterMorale(const int mo);
		bool setMorale(const int mo)
		{
			if (!holdMorale)return false;
			currentMorale = mo;
			currentMorale = currentMorale < 0 ? 0 : currentMorale;
			currentMorale = currentMorale > MaxMorale ? MaxMorale : currentMorale;
			return true;
		}
		//hp
		int alterHP(const int hp)
		{
			int tmpHp = currentHP;
			int maxHp = getTotalAttri(idx_hp);
			currentHP += hp;
			currentHP = currentHP < 0 ? 0 : currentHP;
			currentHP = currentHP > maxHp ? maxHp : currentHP;
			if (loggerDamage)
			{
				loggerDamage->on_hp_alter((currentHP - tmpHp));
			}
			return currentHP - tmpHp;
			//return std::abs(tmpHp - currentHP);//�������ӻ��߼��ٵľ���ֵ
		}
		bool replaceShield(const int sh)
		{
			if (sh > shield)
			{
				shield = sh;
				return true;
			}
			return false;
		}
		int alterShield(const int sh)
		{
			int tmpSh = shield;
			shield += sh;
			shield = shield < 0 ? 0 : shield;
			if (loggerDamage)
			{
				loggerDamage->on_shield_alter((shield - tmpSh));
			}
			return shield - tmpSh;
			//return std::abs(tmpSh - shield);//�������ӻ��߼��ٵľ���ֵ
		}
		struct damageRes
		{
			damageRes()
			{
				this->shp = 0;
				this->hp = 0;
			}
			const int totalDamage()
			{
				return this->shp + this->hp;
			}
			int shp;
			int hp;
		};
		damageRes acceptDamage(int damage)
		{
			damageRes res;
			if (damage >= 0)return res;
			res.shp = alterShield(damage);
			damage += std::abs(res.shp);
			res.hp = alterHP(damage);
			return res;
		}
		inline int HP()
		{
			return currentHP;
		}
		inline int loseHP()
		{
			const int lose_hp = beginHP - currentHP;
			return lose_hp < 0 ? 0 : lose_hp;
		}
		void set_skill_1(const int id);
		void set_skill_2(const int id);
		int get_skill_1() const;
		int get_skill_2() const;
		bool passLimit(const AIM::structAIM& declare)
		{
			if (declare.aliveAim && isDead())return false;//Ĭ�������Ĳ��Ӳ������Ŀ�����
			if (declare.deadAim && !isDead())return false;
			if (declare.holdMorale && !holdMorale)return false;
			if (declare.less100Morale && currentMorale >= TickMorale)return false;
			if (declare.over100Morale && currentMorale < TickMorale)return false;
			return true;
		}
		void skillEnd()
		{
			if (skillMorale > 0)
			{
				skillMorale = 0;
			}
		}
		inline bool isUsePowerSkill()
		{
			return (skillMorale > 0);
		}
		const skillDeclare* useSkill()
		{
			if (skill_2 && currentMorale >= TickMorale)
			{
				skillMorale = currentMorale;
				currentMorale = 0;//��ռ���
				return skill_2;
			}
			return skill_1;
		}
		void orderPos(const int side)
		{
			currentS = side % 2;
			currentIdx %= 9;
			currentX = currentIdx / 3;
			currentY = currentIdx % 3;
			currentIdx += (9 * currentS);
		}
		inline int getTalent(const AttributeIDX idx_){
			if (idx_ < 0 || (unsigned)idx_ >= characterNum)return 0;
			return initialAttri[idx_];
		}
		inline int getTotalAttri(const AttributeIDX idx_){
			if (idx_ < 0 || (unsigned)idx_ >= characterNum)return 0;
			return int((battleAttri[idx_] + addAttri[idx_]) * (1.0 + rateAttri[idx_] / 10000.0));
		}
		double getModule(const ArmsModule idx_){
			if (idx_ < 0 || (unsigned)idx_ >= armsModulesNum)return 0.0;
			return armsModule[idx_];
		}
		inline unsigned X(){ return currentX; }
		inline unsigned Y() { return currentY; }
		bool aliveToDead()
		{
			if (beAtoD && currentHP < 1)
			{
				holdBuffs.clear();//����֮������Я����buff���, ���͵�buff�����
				beAtoD = false;
				return true;
			}
			return false;
		}
		inline bool isDead(){ return currentHP < 1; }
		const static int TickMorale = 100;//ʿ��������
		const static int MaxMorale = 300;//����ۼ�300ʿ�� >= 100ʿ�����ͷ�ʿ������ ��ʿ�����

		inline bool checkLockType(const BUFF::lockType type)
		{
			return stateLock[type] > 0;
		}
		inline void plusLockType(const BUFF::lockType type)
		{
			++stateLock[type];
		}
		inline void minusLockType(const BUFF::lockType type)
		{
			unsigned& val = stateLock[type];
			if (val > 0)--val;
		}
	private:
		std::map<unsigned, unsigned> stateLock;//����״̬
		skillDeclare* skill_1;
		skillDeclare* skill_2;//��������
		unsigned currentX;
		unsigned currentY;//��ǰ����
		unsigned currentS;
	};
	typedef vector<mBattlePtr> manList;
	STDMAP(int, int, ManDamage);

	class sideBattle;
	BOOSTSHAREPTR(sideBattle, sBattlePtr);
	class sideBattle
	{
//		friend class battle_system;
	public:
		sideBattle();
		~sideBattle(){}
		int playerID;
		bool isPlayer;
		int playerLevel;
		int playerNation;
		int playerFace;
		string playerName;
		manList battleMan;
		manList useManList;//ʵ��ʹ�õ�ս��list
		int winNum;//ʤ����
		int winMax;//���ʤ����
		int battleValue;//ս����
		mBattlePtr leaderMan;//�ӳ�
	public:
		static sBattlePtr CreateFrom(sBattlePtr from)
		{
			sBattlePtr newBattle = Creator<sideBattle>::Create();
			if (from)
			{
				newBattle->playerID = from->playerID;
				newBattle->isPlayer = from->isPlayer;
				newBattle->playerLevel = from->playerLevel;
				newBattle->playerNation = from->playerNation;
				newBattle->playerFace = from->playerFace;
				newBattle->playerName = from->playerName;
				newBattle->battleValue = from->battleValue;
				for (unsigned i = 0; i < from->battleMan.size(); ++i)
				{
					newBattle->battleMan.push_back(manBattle::CreateFrom(from->battleMan[i]));
					if (from->leaderMan == from->battleMan[i])
					{
						newBattle->leaderMan = newBattle->battleMan[i];
					}
				}
			}
			return newBattle;
		}

		manList getALLUser()
		{
			manList resList;
			for (unsigned x = 0; x < 3; ++x)
				for (unsigned y = 0; y < 3; ++y)
				{
					mBattlePtr m = deployment[x][y];
					if (!m || m->isDead())continue;
					resList.push_back(m);
				}
			return resList;
		}
		manList getALLUser(const AIM::structAIM& declare)
		{
			manList resList;
			for (unsigned x = 0; x < 3; ++x)
				for (unsigned y = 0; y < 3; ++y)
				{
					mBattlePtr m = deployment[x][y];
					if (!m ||!m->passLimit(declare))continue;
					resList.push_back(m);
				}
			return resList;
		}
		void initial(const int side);
		void resetHand();
		void setLogDamage(BattleLog::logger_factory* ifs, const unsigned nr);//���뵱ǰ�غ���
		bool isDeadAll()
		{
			for (unsigned x = 0; x < 3; ++x)
				for (unsigned y = 0; y < 3; ++y)
					if (deployment[x][y] && !deployment[x][y]->isDead())return false;
			return true;
		}
		void Next()
		{
			//ֻ������0~8
			for (unsigned i = findIdx; i < 9; ++i)
			{
				const unsigned x = i / 3;
				const unsigned y = i % 3;
				//if (deployment[x][y] && !deployment[x][y]->isDead())
				if (deployment[x][y])//����Ҫ�ж��Ƿ��Ѿ�����
				{
					settingIdx = i;
					findIdx = i + 1;
					return;
				}
			}
			findIdx = InvalidBattleIDX;//�Ѿ�ִ�������
			settingIdx = InvalidBattleIDX;
		}
		inline mBattlePtr currentHand()
		{
			if (priorityIdx != InvalidBattleIDX)return getUser(priorityIdx);
			return getUser(settingIdx);
		}
		mBattlePtr toNextHand()
		{
			Next();
			return currentHand();
		}
		mBattlePtr getUser(const unsigned x, const unsigned y)
		{
			if (x > 2 || y > 2)return mBattlePtr();
			return deployment[x][y];
		}
		mBattlePtr getUser(const unsigned idx_)
		{
			const unsigned x = idx_ / 3;
			const unsigned y = idx_ % 3;
			return getUser(x, y);
		}
		bool setPriorityIDX(mBattlePtr user)
		{
			if (user && deployment[user->X()][user->Y()] == user)
			{
				priorityIdx = user->X() * 3 + user->Y();
				return true;
			}
			return false;
		}
		void clearPriorityIDX()
		{
			priorityIdx = InvalidBattleIDX;
		}
		inline bool overWin(){ return winNum >= winMax; }
		inline int Side() { return sideID; };
	private:
		unsigned priorityIdx;//�趨ֵ//����ʹ�����
		unsigned settingIdx;//�趨ֵ
		unsigned findIdx;
		int sideID;//���ط�
		mBattlePtr deployment[3][3];
	};
	typedef vector<sBattlePtr> teamSideBattle;
}

#pragma once

#include "commom.h"
#include "dbDriver.h"

#define treasure_sys (*gg::treasure_system::_Instance)

namespace gg
{
	class treasure_system
	{
		public:
			static treasure_system* const _Instance;
			void initData();
			DeclareRegFunction(Info);
			DeclareRegFunction(Upgrade);
			DeclareRegFunction(ActiveTalent);
			DeclareRegFunction(Wear);
			DeclareRegFunction(Unload);
			DeclareRegFunction(GMInfo);
			DeclareRegFunction(GMModifyLV);
	};
}

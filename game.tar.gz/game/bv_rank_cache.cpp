#include "bv_rank_cache.h"
#include "dbDriver.h"

namespace gg
{
	BVRankCache::BVRankCache()
		: _next_tick_time(0)
	{
		init();
	}

	void BVRankCache::init()
	{
		mongo::BSONObj key = BSON("key" << 0);
		mongo::BSONObj obj = db_mgr.FindOne(DBN::dbBattleValueRankCache, key);
		if (!obj.isEmpty())
		{
			_next_tick_time = obj["ntt"].Int();
			{
				std::vector<mongo::BSONElement> ele = obj["rl"].Array();
				for (unsigned i = 0; i < ele.size(); ++i)
				{
					int pid = ele[i].Int();
					_rank2pid.push_back(pid);
					_pid2rank.insert(make_pair(pid, i+1));
				}
			}
		}
		Timer::AddEventTickTime(boostBind(BVRankCache::tick, this), Inter::event_bv_rank_cache_timer, _next_tick_time);
	}

	void BVRankCache::tick()
	{
		_rank2pid.clear();
		_pid2rank.clear();
		mongo::Query query(BSON("mnb" << BSON("$gt" << 0)));
		query.sort(BSON("mnb" << -1 << strPlayerID << 1));
		objCollection objs = db_mgr.Query(DBN::dbPlayerExpedition, query);
		for (unsigned i = 0; i < objs.size(); ++i)
		{
			int pid = objs[i][strPlayerID].Int();
			_rank2pid.push_back(pid);
			_pid2rank.insert(make_pair(pid, i+1));
		}
		_next_tick_time = Common::getNextTimeHMS(Common::gameTime(), 4);
		Timer::AddEventTickTime(boostBind(BVRankCache::tick, this), Inter::event_bv_rank_cache_timer, _next_tick_time);
		_sign_save();
	}

	bool BVRankCache::_auto_save()
	{
		mongo::BSONObj key = BSON("key" << 0);
		mongo::BSONObjBuilder obj;
		obj << "key" << 0 << "ntt" << _next_tick_time;
		{
			mongo::BSONArrayBuilder b;
			ForEachC(Rank2PID, it, _rank2pid)
				b.append(*it);
			obj << "rl" << b.arr();
		}
		return db_mgr.SaveMongo(DBN::dbBattleValueRankCache, key, obj.obj());
	}
}

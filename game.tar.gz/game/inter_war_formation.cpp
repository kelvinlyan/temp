#include "war_formation.h"
#include "inter_war_formation.h"
#include "playerManager.h"

namespace gg
{
	interSGFM::interSGFM(const unsigned ID, playerData* const own) : _auto_player(own), fmID(ID)
	{
		FMPower = 0;
		isNew = true;
	}

	void interSGFM::tryToFormat(const vector<playerManPtr>& vec)
	{
		const FMCFG::HOLEVEC& config = playerWarFM::getConfig(fmID).HOLES;
		unsigned idx = 0;
		for (unsigned i = 0; i < 9 && idx < vec.size(); ++i)
		{
			if (!config[i].Use)continue;
			if (Own().LV() < config[i].LV)continue;
			if (config[i].Process > 0 && !Own().War().isChallengeMap(config[i].Process))continue;
			FMList[i] = vec[idx];
			++idx;
		}
		if (idx > 0)
		{
			isNew = false;
			recalFM();
		}
		_sign_auto();//�Զ����ºͱ���
	}

	int interSGFM::format(const int fm[9])
	{
		int res = rawFormat(fm);
		if (res == res_sucess)
		{
			recalFM();
			_sign_auto(); 
		}
		return res;
	}

	void interSGFM::recalFM(const bool update /* = true */)
	{
		int tmp_val = FMPower;
		FMPower = 0;
		unsigned num = 0;
		for (unsigned i = 0; i < 9; ++i)
		{
			playerManPtr man = FMList[i];
			if (!man)continue;
			++num;
			FMPower += man->battleValue();
		}
		FMPower += playerWarFM::FormationBV(Own().getOwnDataPtr(), fmID, num);
		//���Խ��//��ô10��
		const static int MaxValue = 1000000000;//10��
		if (FMPower < 0 || FMPower > MaxValue)FMPower = MaxValue;

		if (update && tmp_val != FMPower)
		{
			_sign_update();
		}
	}

	int interSGFM::rawFormat(const int fm[9])
	{
		const FMCFG::HOLEVEC& config = playerWarFM::getConfig(fmID).HOLES;
		boost::unordered_set<int> SAMEMAN;
		playerManPtr tmpList[9];//�����б�
		unsigned fomat_num = 0;
		for (unsigned i = 0; i < 9; ++i)
		{
			if (fm[i] < 0)continue;
			if (!config[i].Use)continue;
			if (Own().LV() < config[i].LV)return err_format_hole_limit;
			if (config[i].Process > 0 && !Own().War().isChallengeMap(config[i].Process))return err_format_hole_limit;
			playerManPtr man = Own().Man().findArmyByMan(fm[i]);//�Ƿ����㿪������
			if (man && SAMEMAN.insert(man->uniqueID()).second == false)continue;
			tmpList[i] = man;
			if (man && ++fomat_num >= 5)break;
		}
		for (unsigned i = 0; i < 9; ++i)
		{
			FMList[i] = tmpList[i];
		}
		isNew = false;
		return res_sucess;
	}

	mongo::BSONArray interSGFM::toBsonArr()
	{
		mongo::BSONArrayBuilder arr;
		for (unsigned i = 0; i < 9; ++i)
		{
			arr << (FMList[i] ? FMList[i]->uniqueID() : -1);
		}
		return arr.arr();
	}

	std::vector<playerManPtr> interSGFM::toInvaildFormat()
	{
		std::vector<playerManPtr> list;
		for (unsigned i = 0; i < 9; ++i)
		{
			playerManPtr m = FMList[i];
			if (!m)continue;
			list.push_back(m);
		}
		return list;
	}

	std::vector<playerManPtr> interSGFM::toFormat()
	{
		std::vector<playerManPtr> list;
		for (unsigned i = 0; i < 9; ++i)
		{
			list.push_back(FMList[i]);
		}
		return list;
	}

	bool interSGFM::isEmpty()
	{
		for (unsigned i = 0; i < 9; ++i)
		{
			if(FMList[i])return false;
		}
		return true;
	}

	qValue interSGFM::toJson()
	{
		qValue json(qJson::qj_object);
		json.addMember("id", fmID);
		json.addMember("bv", FMPower);
		qValue m_json(qJson::qj_array);
		for (unsigned i = 0; i < 9; ++i)
		{
			m_json.append(FMList[i] ? FMList[i]->armyID() : -1);
		}
		json.addMember("m", m_json);
		return json;
	}

	bool interSGFM::_on_sign_update()
	{
		Own().InterFM().tickFM(fmID);
		return false;
	}

	Json::Value interSGFM::uploadManJson()
	{
		Json::Value man_json = Json::arrayValue;
		for (unsigned i = 0; i < 9; ++i)
		{
			playerManPtr man = FMList[i];
			if (!man)continue;
			Json::Value single_json = Json::arrayValue;
			single_json.append(man->armyID());
			single_json.append(man->LV());
			single_json.append(man->battleValue());
			single_json.append(man->getSkill_1());
			single_json.append(man->getSkill_2());
			single_json.append(i);
			Json::Value& attri_my_json = single_json[6u] = Json::arrayValue;
			int attri[characterNum];
			man->toBattleAttri(fmID, attri);
			for (unsigned idx = 0; idx < characterNum; ++idx)
			{
				if (attri[idx] != 0)
				{
					Json::Value attri_json;
					attri_json.append(idx);
					attri_json.append(attri[idx]);
					attri_my_json.append(attri_json);
				}
			}
			Json::Value& equip_my_json = single_json[7u] = Json::arrayValue;
			std::vector<itemPtr> equipList = man->getEquipList();
			for (unsigned pos = 0; pos < equipList.size(); ++pos)
			{
				itemPtr item = equipList[pos];
				if (item)
				{
					Json::Value equip_json;
					equip_json.append(pos);
					equip_json.append(item->itemID());
					equip_json.append(item->getLv());
					equip_my_json.append(equip_json);
				}
			}
			Json::Value& talent_my_json = single_json[8u] = Json::arrayValue;
			std::vector<int> talentList = man->getTalentList();
			for (unsigned pos = 0; pos < talentList.size(); ++pos)
			{
				talent_my_json.append(talentList[pos]);
			}
			man_json.append(single_json);
		}
		return man_json;
	}

	void interSGFM::rawInitial(const bool in, vector<mongo::BSONElement>& vec)
	{
		isNew = in;
		unsigned num = 0;
		for (unsigned i = 0; i < vec.size() && i < 9; ++i)
		{
			playerManPtr m = Own().Man().findArmy(vec[i].Int());
			if (m)++num;
			FMList[i] = m;
		}
		if (num > 0)isNew = false;
	}

	bool interSGFM::_auto_save()
	{
		mongo::BSONObj key = BSON(strPlayerID << Own().ID() << "fid" << fmID);
		mongo::BSONObj obj = BSON(strPlayerID << Own().ID() << "fid" << fmID << 
			"arr" << toBsonArr() << "in" << isNew);
		return db_mgr.SaveMongo(DBN::dbPlayerInterWarFM, key, obj);
	}

	//mgr
	interWarFM::interWarFM(playerData* const own) : _auto_player(own)
	{
		upload_json = Json::objectValue;
		base_update = false;
		fmList.clear();
		for (unsigned i = 0; i < 12; ++i)
		{
			interFMPtr dataPtr = Creator<interSGFM>::Create(i, own);
			fmList.push_back(dataPtr);
		}
		currentFMID = 0;
	}

	int interWarFM::format(const unsigned fmID, const int fm[9])
	{
		if (fmID > fmList.size())return err_format_not_find;
		currentFMID = fmID;
		_sign_auto();
		const int res = fmList[fmID]->format(fm);
		return res;
	}

	void interWarFM::_auto_update()
	{
		qValue json(qJson::qj_array);
		json.append(res_sucess).append(currentFMID);
		qValue fmJson(qJson::qj_array);
		for (UINTSET::iterator it = updateList_.begin();it != updateList_.end(); ++it)
		{
			const unsigned idx = *it;
			if (idx >= fmList.size())continue;
			fmJson.append(fmList[idx]->toJson());
		}
		json.append(fmJson);
		updateList_.clear();
		Own().sendToClientFillMsg(gate_client::inter_war_format_update_batch_resp, json);

		if (base_update)
		{
			base_update = false;
			Json::Value r;
			r[strMsg][0u] = res_sucess;
			r[strMsg][1u] = upload_json;
			Own().sendToClient(gate_client::inter_war_format_upload_info_resp, r);
		}
	}

	bool interWarFM::_auto_save()
	{
		mongo::BSONObj key = BSON(strPlayerID << Own().ID());
		mongo::BSONObj obj = BSON(strPlayerID << Own().ID() << "cid" << currentFMID << 
			"json" << upload_json.toIndentString());
		return db_mgr.SaveMongo(DBN::dbPlayerInterWarFMBase, key, obj);
	}

	int interWarFM::defaultFM(const unsigned fmID)
	{
		if (fmID >= fmList.size())return err_format_not_find;
		const unsigned oldFMID = currentFMID;//�ϵ�ID
		currentFMID = fmID;
		if (fmList[currentFMID]->isNewFM() && oldFMID != currentFMID)
		{
			std::vector<playerManPtr> vec = fmList[oldFMID]->toInvaildFormat();
			fmList[currentFMID]->tryToFormat(vec);
		}
		_sign_auto();
		return res_sucess;
	}

	void interWarFM::classLoad()
	{
		mongo::BSONObj key = BSON(strPlayerID << Own().ID());
		mongo::BSONObj baseObj = db_mgr.FindOne(DBN::dbPlayerInterWarFMBase, key);
		if (!baseObj.isEmpty())
		{
			currentFMID = (unsigned)baseObj["cid"].Int();
			upload_json = Common::string2json(baseObj["json"].String());
		}
		objCollection collection = db_mgr.Query(DBN::dbPlayerInterWarFM, key);
		if (collection.empty())return;
		for (unsigned i = 0; i < collection.size(); ++i)
		{
			mongo::BSONObj& obj = collection[i];
			unsigned fmID = (unsigned)obj["fid"].Int();
			bool isNew = obj["in"].eoo() ? true : obj["in"].Bool();
			if (fmID >= fmList.size())continue;
			std::vector<mongo::BSONElement> elems = obj["arr"].Array();
			fmList[fmID]->rawInitial(isNew ,elems);
		}
	}

	void interWarFM::classFinal()
	{
		for (unsigned i = 0; i < fmList.size(); ++i)
		{
			fmList[i]->recalFM(false);
		}
	}

	void interWarFM::updateAll()
	{
		qValue json(qJson::qj_array);
		json.append(res_sucess).append(currentFMID);
		qValue fmJson(qJson::qj_array);
		for (unsigned i = 0; i < fmList.size(); ++i)
		{
			fmJson.append(fmList[i]->toJson());
		}
		json.append(fmJson);
		Own().sendToClientFillMsg(gate_client::inter_war_format_update_batch_resp, json);

		{
			Json::Value r;
			r[strMsg][0u] = res_sucess;
			r[strMsg][1u] = upload_json;
			Own().sendToClient(gate_client::inter_war_format_upload_info_resp, r);
		};
	}

	void interWarFM::updateSingle(const unsigned fmID)
	{
		qValue json(qJson::qj_array);
		if (fmID > fmList.size())
		{
			json.append(err_format_not_find);
			Own().sendToClientFillMsg(gate_client::inter_war_format_update_batch_resp, json);
			return;
		}
		json.append(res_sucess);
		json.append(fmList[fmID]->toJson());
		Own().sendToClientFillMsg(gate_client::inter_war_format_update_batch_resp, json);
		return;
	}

	void interWarFM::recalFMValue(const int fmID, const bool update /* = true */)
	{
		if (fmID >= fmList.size())return;
		fmList[fmID]->recalFM(update);
		if (update)_sign_update();
	}

	void interWarFM::recalFMValue(const bool update /* = true */)
	{
		for (unsigned i = 0; i < fmList.size(); ++i)
		{
			if (fmList[i])fmList[i]->recalFM(update);
		}
		if(update)_sign_update();
	}

	Json::Value interWarFM::uploadFormatJson()
	{
		interFMPtr ptr = fmList[currentFMID];
		Json::Value json = Json::objectValue;
		json["fm"] = currentFMID;
		json["bv"] = ptr->getBV();
		json["man"] = ptr->uploadManJson();
		return json;
	}

	void interWarFM::setUploadFormat(Json::Value& json)
	{
		base_update = true;
		upload_json = json;
		_sign_auto();
	}

	int interWarFM::currentBV()
	{
		return fmList[currentFMID]->getBV();
	}

	std::vector<playerManPtr> interWarFM::currentFM()
	{
		return fmList[currentFMID]->toFormat();
	}

	std::vector<playerManPtr> interWarFM::appointFM(const unsigned FMID)
	{
		if (FMID >= fmList.size())return std::vector<playerManPtr>();
		return fmList[FMID]->toFormat();
	}

	std::vector<playerManPtr> interWarFM::currentInvaildFM()
	{
		return fmList[currentFMID]->toInvaildFormat();
	}

	std::vector<playerManPtr> interWarFM::appointInvaildFM(const unsigned FMID)
	{
		if (FMID >= fmList.size())return std::vector<playerManPtr>();
		return fmList[FMID]->toInvaildFormat();
	}

	void interWarFM::tickFM(const unsigned FMID)
	{
		updateList_.insert(FMID);
		_sign_update();
	}

	bool interWarFM::currentEmpty()
	{
		return appointEmpty(currentFMID);
	}

	bool interWarFM::appointEmpty(const unsigned FMID)
	{
		if (FMID >= fmList.size())return true;
		return fmList[FMID]->isEmpty();
	}

	void interWarFM::tryFullDefalut()
	{
		if (fmList[currentFMID]->isEmpty())
		{
			fmList[currentFMID]->tryToFormat(Own().WarFM().currentInvaildFM());
		}
	}

}

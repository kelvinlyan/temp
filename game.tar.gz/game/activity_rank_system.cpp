#include "activity_rank_system.h"
#include "playerManager.h"
#include "gamer_battle_rank.h"
#include "email_system.h"
#include "chat.h"

namespace gg
{
	using namespace RANKACTIVITY;

	void ActivityCCRank::save_config()
	{
		mongo::BSONObj key = BSON("key" << Type);
		mongo::BSONArrayBuilder condition_list;
		for (unsigned i = 0; i < _condition_list.size(); ++i)
		{
			condition_list << BSON_ARRAY(
				_condition_list[i]._end_idx << 
				_condition_list[i]._value_compare
			);
		}
		mongo::BSONArrayBuilder rank_box_list;
		for (unsigned i = 0; i < _rank_box_list.size(); ++i)
		{
			rank_box_list << BSON_ARRAY(
				_rank_box_list[i]._end_idx << 
				_rank_box_list[i]._box_json.toIndentString()
				);
		}
		mongo::BSONArrayBuilder reach_box_list;
		for (_box_list_type::iterator it = _reach_box_list.begin(); it != _reach_box_list.end(); ++it)
		{
			const _box& box = it->second;
			reach_box_list << BSON_ARRAY(box._limit_value << box._box_json.toIndentString());
		}
		mongo::BSONObj obj = BSON("key" << Type << "time" <<
			BSON_ARRAY(_show_begin << _activity_begin << _activity_end << _show_end) <<
			"part" << condition_list.arr() << "rank" << rank_box_list.arr() << "reach" <<
			reach_box_list.arr() << "create" << _create_time << "run" << _run_type << "url" <<
			_tx_url << "id" << _activity_id
		);
		db_mgr.SaveMongo(DBN::dbActivityRankConfig, key, obj);
	}

	void ActivityCCRank::del_rank_player(const int player_id_)
	{
		db_mgr.RemoveCollection(DBN::dbActivityRankData, BSON("key" << Type << strPlayerID << player_id_));
	}

	void ActivityCCRank::save_rank_player(const _data_type& player_)
	{
		mongo::BSONObj key = BSON("key" << Type << strPlayerID << player_._player_id);
		mongo::BSONObj obj = BSON("key" << Type << strPlayerID << player_._player_id <<
			"vl" << player_._value << "pn" << player_._player_name << "ct" << player_._create_time);
		db_mgr.SaveMongo(DBN::dbActivityRankData, key, obj);
	}

	void ActivityCCRank::save_rank()
	{
		for (unsigned i = 0; i < _rank_list.size(); ++i)
		{
			save_rank_player(*_rank_list[i]);
		}
	}

	void ActivityCCRank::update_player_name(const int playerID, const string name)
	{
		_data_type_ptr ptr = get_player(playerID);
		if (ptr)
		{
			ptr->_player_name = name;
			save_rank_player(*ptr);
		}
	}

	void ActivityCCRank::load_db()
	{
		reset();
		//�������� + ���а�����
		//config
		{
			mongo::BSONObj key = BSON("key" << Type);
			mongo::BSONObj obj = db_mgr.FindOne(DBN::dbActivityRankConfig, key);
			if (!obj.isEmpty())
			{
				_run_type = obj["run"].Int();
				_create_time = obj["create"].Int();
				_activity_id = obj["id"].Int();
				{//ʱ��
					std::vector<mongo::BSONElement> elems = obj["time"].Array();
					_show_begin = elems[0].Int();
					_activity_begin = elems[1].Int();
					_activity_end = elems[2].Int();
					_show_end = elems[3].Int();
				};
				{//��������
					std::vector<mongo::BSONElement> elems = obj["part"].Array();
					unsigned begin_ = 0;
					for (unsigned i = 0; i < elems.size(); ++i)
					{
						mongo::BSONElement& elem = elems[i];
						std::vector<mongo::BSONElement> arr_elem = elem.Array();
						const unsigned end_ = arr_elem[0].Int();
						_condition_list.push_back(_condition(begin_, end_, arr_elem[1].Int()));
						_condition* condition_point = &_condition_list.back();
						for (unsigned idx = begin_; idx < end_; ++idx)
						{
							_condition_list_map.push_back(condition_point);
						}
						begin_ = end_;
					}
				};
				{//���а潱��
					std::vector<mongo::BSONElement> elems = obj["rank"].Array();
					unsigned begin_ = 0;
					for (unsigned i = 0; i < elems.size(); ++i)
					{
						mongo::BSONElement& elem = elems[i];
						std::vector<mongo::BSONElement> arr_elem = elem.Array();
						const unsigned end_ = arr_elem[0].Int();
						_rank_box_list.push_back(
							_rank_box(begin_, end_, 
							Common::string2json(arr_elem[1].String()))
						);
						_rank_box* rank_box_point = &_rank_box_list.back();
						for (unsigned idx = begin_; idx < end_; ++idx)
						{
							_rank_box_map.push_back(rank_box_point);
						}
						begin_ = end_;
					}
				};
				{//�������㽱��
					std::vector<mongo::BSONElement> elems = obj["reach"].Array();
					for (unsigned i = 0; i < elems.size(); ++i)
					{
						mongo::BSONElement& elem = elems[i];
						std::vector<mongo::BSONElement> arr_elem = elem.Array();
						const int reach_id = arr_elem[0].Int();
						_reach_box_list[reach_id] =
							_box(arr_elem[0].Int(),
								Common::string2json(arr_elem[1].String()));
					}
				};
				//url
				_tx_url = obj["url"].String();
			}
		};
		//rank
		{
			mongo::Query key(BSON("key" << Type));
			key.sort(BSON("vl" << -1 << "ct" << 1 << strPlayerID << 1));
			objCollection objs = db_mgr.Query(DBN::dbActivityRankData, key, MaxSize);
			for (unsigned i = 0; i < objs.size(); ++i)
			{
				mongo::BSONObj& obj = objs[i];
				_data_type_ptr data = Creator<RANKACTIVITY::TypeCC>::Create(obj[strPlayerID].Int(), obj["pn"].String(), obj["vl"].Int());
				data->_create_time = obj["ct"].Int();
				_rank_list.push_back(data);
				_players[data->_player_id] = data;
			}
		};
		create_timer();
		create_cast();
	}

	void ActivityCCRank::run_to_begin_event(const unsigned create_id_, const unsigned match_time_)
	{
		if (_run_type != run_to_begin)return;
		if (create_id_ != _create_time || match_time_ != _activity_begin)return;
		_run_type = run_to_end;//Ҫ�ȸı�״̬
		save_config();
		//�κ����а��ڿ�ʼ֮����Ҫ�����������
		_rank_list.clear();
		_players.clear();
		db_mgr.RemoveCollection(DBN::dbActivityRankData, BSON("key" << Type));
		if (Type == ActivityRankEnum::activity_battle_rank)
		{
			NSBattleRank::RankMap rank_ = battle_rank.getAllRank();
			for (NSBattleRank::RankMap::const_iterator it = rank_.begin(); it != rank_.end(); ++it)
			{
				NSBattleRank::ptrRankData data = it->second;
				_data_type_ptr ptr = Creator<_data_type>::Create(data->playerID, data->playerName, data->battleValue);
				_rank_list.push_back(ptr);
				_players[data->playerID] = ptr;
				if (_rank_list.size() >= MaxSize)break;
			}
			save_rank();
		}
		playerManager::playerDataVec vec = player_mgr.allOnline();
		for (unsigned i = 0; i < vec.size(); ++i)
		{
			playerDataPtr player = vec[i];
			player->ActivityRank().check_process();
		}
		create_timer();
	}

	void ActivityCCRank::run_to_end_event(const unsigned create_id_, const unsigned match_time_)
	{
		if (_run_type != run_to_end)return;
		if (create_id_ != _create_time || match_time_ != _activity_end)return;
		_run_type = run_to_over;
		clean_activity();
		save_config();
		create_timer();
	}

	void ActivityCCRank::run_to_over_event(const unsigned create_id_, const unsigned match_time_)
	{
		if (_run_type != run_to_over)return;
		if (create_id_ != _create_time || match_time_ != _show_end)return;
		reset();
		_clean_online_player();
		save_config();//����յ�����
		db_mgr.RemoveCollection(DBN::dbActivityRankData, BSON("key" << Type));//ɾ�����а�
	}

	void ActivityCCRank::scroll_cast_event(const unsigned tml)
	{
		Json::Value p_json = Json::arrayValue;
		p_json.append(Type);
		p_json.append(tml);
		Json::Value scroll_json = Json::objectValue;
		scroll_json["roll"] = 2;
		scroll_json["weight"] = 0;
		chat_sys.despatchAllSP(CHAT::server_activity_rank_nearly_end_broadcast, p_json, scroll_json, CHATPOS::scroll_bar_top);
		if (15 == tml) { _scroll_end_15 = ::ptrTimerIdentify(); }
		if (5 == tml) { _scroll_end_5 = ::ptrTimerIdentify(); }
	}

	void ActivityCCRank::window_cast_event(const unsigned tml)
	{
		Json::Value p_json = Json::arrayValue;
		p_json.append(Type);
		p_json.append(tml);
		chat_sys.despatchAll(CHAT::server_activity_rank_nearly_end_broadcast, p_json, CHATPOS::chat_windows);
		if (120 == tml) { _window_end_120 = ::ptrTimerIdentify(); }
		if (30 == tml) { _window_end_30 = ::ptrTimerIdentify(); }
	}

	void ActivityCCRank::create_cast()
	{
		if (is_null_activity())return;
		const unsigned now = Common::gameTime();
		const unsigned end_120 = _activity_end - 120 * MINUTE;
		const unsigned end_30 = _activity_end - 30 * MINUTE;
		const unsigned end_15 = _activity_end - 15 * MINUTE;
		const unsigned end_5 = _activity_end - 5 * MINUTE;
		if (end_120 > now && end_120 > _activity_begin)
		{
			_window_end_120 = Timer::AddEventTickTime(boostBind(ActivityCCRank::window_cast_event, this, 120), Inter::event_system_common_recall, end_120);
		}
		if (end_30 > now && end_30 > _activity_begin)
		{
			_window_end_30 = Timer::AddEventTickTime(boostBind(ActivityCCRank::window_cast_event, this, 30), Inter::event_system_common_recall, end_30);
		}
		if (end_15 > now && end_15 > _activity_begin)
		{
			_scroll_end_15 = Timer::AddEventTickTime(boostBind(ActivityCCRank::scroll_cast_event, this, 15), Inter::event_system_common_recall, end_15);
		}
		if (end_5 > now && end_5 > _activity_begin)
		{
			_scroll_end_5 = Timer::AddEventTickTime(boostBind(ActivityCCRank::scroll_cast_event, this, 5), Inter::event_system_common_recall, end_5);
		}
	}

	void ActivityCCRank::create_timer()
	{
		if (is_null_activity())return;
		if (run_to_begin == _run_type)
		{
			Timer::AddEventTickTime(boostBind(ActivityCCRank::run_to_begin_event, this, _create_time, _activity_begin), Inter::event_rank_activity_timer, _activity_begin);
		}
		else if(run_to_end == _run_type)
		{
			Timer::AddEventTickTime(boostBind(ActivityCCRank::run_to_end_event, this, _create_time, _activity_end), Inter::event_rank_activity_timer, _activity_end);
		}
		else if(run_to_over == _run_type)
		{
			Timer::AddEventTickTime(boostBind(ActivityCCRank::run_to_over_event, this, _create_time, _show_end), Inter::event_rank_activity_timer, _show_end);
		}
	}

	void ActivityCCRank::_clean_rank_list()
	{
		qValue broadcast_json(qJson::qj_array);
		unsigned rank_index = 0;
		for (unsigned i = 0; i < _condition_list_map.size(); ++i)
		{
			const _condition& condition = *_condition_list_map[i];
			if (rank_index >= _rank_list.size())
			{
				continue;
			}
			const _data_type& data = *_rank_list[rank_index];
			if (data._value < condition._value_compare)
			{
				continue;
			}
			if (i < 5)
			{
				broadcast_json.append(
					qValue(qJson::qj_array).append(i + 1).append(data._player_name)
				);
			}
			//�����ʼ�
			Json::Value param_json;
			param_json.append(Type);
			param_json.append(i + 1);
			EmailPtr email_ptr = email_sys.createPackage(EmailDef::ActivityRankListBoxPay, param_json,
				i >= _rank_box_map.size() ? Json::arrayValue : _rank_box_map[i]->_box_client_json);
			email_sys.sendToPlayer(data._player_id, email_ptr);
			++rank_index;
		}
		if (!broadcast_json.isEmpty())
		{
			chat_sys.despatchAll(CHAT::server_activity_rank_broadcast,
				qValue(qJson::qj_array).
				append(Type).
				append(broadcast_json)
			);
		}
	}

	void ActivityCCRank::_clean_online_player()
	{
		playerManager::playerDataVec vec = player_mgr.allOnline();
		for (unsigned i = 0; i < vec.size(); ++i)
		{
			playerDataPtr player = vec[i];
			player->ActivityRank().check_process();
		}
	}

	void ActivityCCRank::clean_activity()
	{
		if (is_null_activity())return;
		_clean_rank_list();
		_clean_online_player();
	}

	void ActivityCCRank::over_activity()
	{
		if (is_null_activity())return;
		if (_run_type < run_to_over)
		{
			_clean_rank_list();
		}
		_run_type = run_to_over;
		_clean_online_player();
		reset();
		_clean_online_player();
	}

	int ActivityCCRank::set_new_data(Json::Value& json)
	{
		if (!json.isObject())
		{
			return err_param_error;
		}		
		//ʱ���
		Json::Value& time_json = json["time"];
		const unsigned id = json["id"].asUInt();
		const unsigned show_begin = time_json[0u].asUInt();
		const unsigned action_begin = time_json[1u].asUInt();
		const unsigned action_end = time_json[2u].asUInt();
		const unsigned show_end = time_json[3u].asUInt();
		if (
			0 ==  id ||
			show_begin >= action_begin ||
			action_begin >= action_end ||
			action_end >= show_end
			) 
		{
			//�رջ
			over_activity();
			save_config();
			db_mgr.RemoveCollection(DBN::dbActivityRankData, BSON("key" << Type));//ɾ�����а�
			return res_sucess;
		}
		if (Common::gameTime() > action_end)
		{
			return err_param_error;
		}
		//�ж��Ƿ����µĻ
		if (id != _activity_id)
		{
			//�µĻ
			over_activity();
			db_mgr.RemoveCollection(DBN::dbActivityRankData, BSON("key" << Type));//ɾ�����а�
			_create_time = Common::gameTime();
		}
		else//�ϵĻ
		{
			reset_if_old();
		}
		_activity_id = id;
		_show_begin = show_begin;
		_activity_begin = action_begin;
		_activity_end = action_end;
		_show_end = show_end;
// 		if (_run_type <= run_to_over)
// 		{
// 			_show_end = show_end;
// 			if (_run_type <= run_to_end)
// 			{
// 				_activity_end = action_end;
// 				if (_run_type <= run_to_begin)
// 				{
// 					_show_begin = show_begin;
// 					_activity_begin = action_begin;
// 				}
// 			}
// 		}
		//����������
		Json::Value& part_json = json["part"];
		unsigned begin_ = 0;
		for (unsigned i = 0; i < part_json.size(); ++i)
		{
			Json::Value& single_json = part_json[i];
			unsigned end_ = single_json[0u].asUInt();
			if (end_ < 1 || end_ > MaxSize) continue;
			if (end_ <= begin_)continue;
			_condition_list.push_back(_condition(begin_, end_, single_json[1u].asInt()));
			_condition* condition_point = &_condition_list.back();
			for (unsigned idx = begin_; idx < end_; ++idx)
			{
				_condition_list_map.push_back(condition_point);
			}
			begin_ = end_;
		}
		//���а潱��
		Json::Value& rank_box_json = json["rank"];
		begin_ = 0;
		for (unsigned i = 0; i < rank_box_json.size(); ++i)
		{
			Json::Value& single_json = rank_box_json[i];
			unsigned end_ = single_json[0u].asUInt();
			if (end_ < 1 || end_ > MaxSize)continue;
			if (end_ <= begin_)continue;
			_rank_box_list.push_back(_rank_box(begin_, end_, single_json[1u]));
			_rank_box* box_point = &_rank_box_list.back();
			for (unsigned idx = begin_; idx < end_; ++idx)
			{
				_rank_box_map.push_back(box_point);
			}
			begin_ = end_;
		}
		//�������㽱��
		Json::Value& reach_box_json = json["reach"];
		for (unsigned i = 0; i < reach_box_json.size(); ++i)
		{
			Json::Value& single_json = reach_box_json[i];
			const int reach_id = single_json[0u].asInt();
			_reach_box_list[reach_id] = (_box(reach_id, single_json[1u]));
		}
		_tx_url = json["tx_url"].asString();
		if (!is_null_activity())
		{
			if (run_nothing == _run_type)
			{
				_run_type = run_to_begin;
			}
			create_timer();
			create_cast();
		}
		save_config();
		return res_sucess;
	}

	static bool SORT_RANK(ActivityCCRank::_data_type_ptr left, ActivityCCRank::_data_type_ptr right)
	{
		return (*left) < (*right);
	}

	void ActivityCCRank::insert_rank(ActivityCCRank::_data_type insert_data_)
	{
		if (!is_run())return;
		_data_type_ptr ptr = get_player(insert_data_._player_id);
		if (ptr)
		{
			if (*ptr > insert_data_)return;
			*ptr = insert_data_;
		}
		else
		{
			if (_rank_list.size() >= ActivityCCRank::MaxSize &&
				*_rank_list.back() > insert_data_)return;
			ptr = Creator<_data_type>::Create(insert_data_._player_id, insert_data_._player_name, insert_data_._value);
			_rank_list.push_back(ptr);
			_players[ptr->_player_id] = ptr;
		}
		ptr->_create_time = Common::gameTime();
		std::sort(_rank_list.begin(), _rank_list.end(), SORT_RANK);
		save_rank_player(*ptr);
		if (_rank_list.size() > ActivityCCRank::MaxSize)
		{
			del_rank_player(_rank_list.back()->_player_id);
			_players.erase(_rank_list.back()->_player_id);
			_rank_list.pop_back();//ɾ��
		}
	}

	ActivityRankSystem* const ActivityRankSystem::_Instance = new ActivityRankSystem();

	void ActivityRankSystem::initData()
	{
		cout << "loading activity data ..." << endl;
		_activity_data[ActivityRankEnum::activity_battle_rank] = new(::GNew(sizeof(ActivityCCRank))) ActivityCCRank(ActivityRankEnum::activity_battle_rank);
		_activity_data[ActivityRankEnum::activity_recharge_rank] = new(::GNew(sizeof(ActivityCCRank))) ActivityCCRank(ActivityRankEnum::activity_recharge_rank);
		_activity_data[ActivityRankEnum::activity_consume_rank] = new(::GNew(sizeof(ActivityCCRank))) ActivityCCRank(ActivityRankEnum::activity_consume_rank);

		for (int i = 0; i < ActivityRankEnum::activity_rank_num; ++i)
		{
			_activity_data[i]->load_db();//�Լ������ݺ�����������
		}
		
		for (int i = 0; i < ActivityRankEnum::activity_rank_num; ++i)
		{
			_back_up_reach_map[i].clear();//�������
			objCollection objs = db_mgr.Query(DBN::dbActivityRankBackUp, BSON("key" << i));
			for (unsigned n = 0; n < objs.size(); ++n)
			{
				mongo::BSONObj& obj = objs[n];
				ptrReachBoxBackUp new_ptr = Creator<ReachBoxBackUp>::Create();
				new_ptr->_type = i;
				new_ptr->_create_id = obj["id"].Int();
				ActivityCCRank::_box_list_type& use_list = new_ptr->_box_list;
				use_list.clear();
				std::vector<mongo::BSONElement> elems = obj["reach"].Array();
				for (unsigned idx = 0; idx < elems.size(); ++idx)
				{
					mongo::BSONElement& elem = elems[idx];
					std::vector<mongo::BSONElement> arr_elem = elem.Array();
					const int reach_id = arr_elem[0].Int();
					use_list[reach_id] =
						ActivityCCRank::_box(arr_elem[0].Int(),
							Common::string2json(arr_elem[1].String()));
				}
				_back_up_reach_map[i][new_ptr->_create_id] = new_ptr;
			}
		}

	}

	void ActivityRankSystem::timeData(const int type, Json::Value& json)
	{
		if (type < 0 || type >= ActivityRankEnum::activity_rank_num)return;
		const RANKACTIVITY::ActivityCCRank& activity = *_activity_data[type];
		json.append(0 == activity.show_begin_time() ? 0 : Common::toStampTime(activity.show_begin_time()));
		json.append(0 == activity.activity_begin_time() ? 0 : Common::toStampTime(activity.activity_begin_time()));
		json.append(0 == activity.activity_end_time() ? 0 : Common::toStampTime(activity.activity_end_time()));
		json.append(0 == activity.show_end_time() ? 0 : Common::toStampTime(activity.show_end_time()));
	}

	void ActivityRankSystem::updateName(playerDataPtr player)
	{
		const int playerID = player->ID();
		const string playerName = player->Name();
		for (int i = 0; i < ActivityRankEnum::activity_rank_num; ++i)
		{
			_activity_data[i]->update_player_name(playerID, playerName);//�Լ������ݺ�����������
		}
	}

	bool ActivityRankSystem::isOver(const int type, const unsigned create_id)
	{
		if (type < 0 || type >= ActivityRankEnum::activity_rank_num)return false;
		if (create_id == 0)return false;
		return _activity_data[type]->create_id() != create_id || _activity_data[type]->is_end();
	}

	bool ActivityRankSystem::isClose(const int type, const unsigned create_id)
	{
		if (type < 0 || type >= ActivityRankEnum::activity_rank_num)return false;
		if (create_id == 0)return false;
		return _activity_data[type]->create_id() != create_id || //��ǰ��Ѿ�����
			_activity_data[type]->is_null_activity();//��Ѿ���Ч
	}

	unsigned ActivityRankSystem::activityID(const int type)
	{
		if (type < 0 || type >= ActivityRankEnum::activity_rank_num)return 0;
		return _activity_data[type]->activity_id();
	}

	unsigned ActivityRankSystem::createID(const int type)
	{
		if (type < 0 || type >= ActivityRankEnum::activity_rank_num)return 0;
		return _activity_data[type]->create_id();
	}

	bool ActivityRankSystem::isOpen(const int type)
	{
		if (type < 0 || type >= ActivityRankEnum::activity_rank_num)return false;
		return _activity_data[type]->is_open();
	}

	bool ActivityRankSystem::isRun(const int type)
	{
		if (type < 0 || type >= ActivityRankEnum::activity_rank_num)return false;
		return _activity_data[type]->is_run();
	}

	void ActivityRankSystem::insertRank(const int type, playerDataPtr player)
	{
		if (isRun(type))
		{
			ActivityCCRank::_data_type insert_data(player->ID(), player->Name(), player->ActivityRank().get_value(type));
			_activity_data[type]->insert_rank(insert_data);
		}
	}

	bool ActivityRankSystem::findActionBox(ActionBoxList& box, const int type, const int reach)
	{
		if (type < 0 || type >= ActivityRankEnum::activity_rank_num)return false;
		return _activity_data[type]->find_reach_box(box, reach);
	}

	Json::Value ActivityRankSystem::packageOverBox(const int type, const int create_id, const int value, boost::unordered_set<int>& filter)
	{
		if (type < 0 || type >= ActivityRankEnum::activity_rank_num)return Json::arrayValue;
		BackUpMapType::iterator it = _back_up_reach_map[type].find(create_id);
		if (it == _back_up_reach_map[type].end())return Json::arrayValue;
		const ActivityCCRank::_box_list_type& check_box = it->second->_box_list;
		Json::Value json = Json::arrayValue;
		for (ActivityCCRank::_box_list_type::const_iterator it = check_box.begin(); it != check_box.end(); ++it)
		{
			const ActivityCCRank::_box& box = it->second;
			if (filter.find(box._limit_value) != filter.end())continue;
			if (value < box._limit_value)continue;
			filter.insert(box._limit_value);
			combineActionRes(box._box_client_json, json);
		}
		return json;
	}

	void ActivityRankSystem::GMUpdate(net::Msg& m, Json::Value& r)
	{
		ReadJson;
		Json::Value& js_msg = js[strMsg];
		const int type = js_msg["key"].asInt();
		if (type < 0 || type >= ActivityRankEnum::activity_rank_num)Return(r, err_illedge);
		r[strMsg][1u] = _activity_data[type]->package_gm();
		Return(r, res_sucess);
	}

	void ActivityRankSystem::remove_back_up_reach(const int type, const unsigned id)
	{
		db_mgr.RemoveCollection(DBN::dbActivityRankBackUp, BSON("key" << type << "id" << id));
	}

	void ActivityRankSystem::save_back_up_reach(const ReachBoxBackUp& data)
	{
		mongo::BSONObj key = BSON("key" << data._type << "id" << data._create_id);
		mongo::BSONArrayBuilder reach_box_list;
		for (ActivityCCRank::_box_list_type::const_iterator it = data._box_list.begin(); it != data._box_list.end(); ++it)
		{
			const ActivityCCRank::_box& box = it->second;
			reach_box_list << BSON_ARRAY(box._limit_value << box._box_json.toIndentString());
		}
		mongo::BSONObj obj = BSON("key" << data._type << "id" << data._create_id <<
			"reach" << reach_box_list.arr()
		);
		db_mgr.SaveMongo(DBN::dbActivityRankBackUp, key, obj);
	}

	void ActivityRankSystem::GMMotify(net::Msg& m, Json::Value& r)
	{
		ReadJson;
		Json::Value& js_msg = js[strMsg];
		const int type = js_msg["key"].asInt();
		if (type < 0 || type >= ActivityRankEnum::activity_rank_num)Return(r, err_illedge);
		const unsigned time4[] = {
			js_msg["time"][0u].asUInt(),
			js_msg["time"][1u].asUInt(),
			js_msg["time"][2u].asUInt(),
			js_msg["time"][3u].asUInt()
		};
		js_msg["time"][0u] = 0 == time4[0u] ? 0 : Common::toLocalTime(time4[0u]);
		js_msg["time"][1u] = 0 == time4[1u] ? 0 : Common::toLocalTime(time4[1u]);
		js_msg["time"][2u] = 0 == time4[2u] ? 0 : Common::toLocalTime(time4[2u]);
		js_msg["time"][3u] = 0 == time4[3u] ? 0 : Common::toLocalTime(time4[3u]);
		const int res = _activity_data[type]->set_new_data(js_msg);
		//�Ƿ�ɹ���Ҫ����
		{
			qValue json(qJson::qj_array);
			for (int i = 0; i < ActivityRankEnum::activity_rank_num; i++)
			{
				qValue single_json(qJson::qj_array);
				single_json.append(i);
				const ActivityCCRank* data = _activity_data[i];
				single_json.append(data->show_begin_time());
				single_json.append(data->activity_begin_time());
				single_json.append(data->activity_end_time());
				single_json.append(data->show_end_time());
				single_json.append(data->ruler_url());
				json.append(single_json);
			}
			player_mgr.sendToAll(gate_client::activity_rank_title_info_resp,
				qValue(qJson::qj_object).addMember(strMsg,
					qValue(qJson::qj_array).
					append(res_sucess).
					append(json)
				)
			);
		};
		if (res == res_sucess && !_activity_data[type]->is_null_activity())
		{
			//���汸��
			ptrReachBoxBackUp ptr = Creator<ReachBoxBackUp>::Create();
			ptr->_type = type;
			ptr->_create_id = _activity_data[type]->create_id();
			ptr->_box_list = _activity_data[type]->reach_box_list();
			_back_up_reach_map[type][ptr->_create_id] = ptr;
			save_back_up_reach(*ptr);
			if (_back_up_reach_map[type].size() > 100)
			{
				ptrReachBoxBackUp remove_ptr = _back_up_reach_map[type].begin()->second;
				_back_up_reach_map[type].erase(_back_up_reach_map[type].begin());
				remove_back_up_reach(remove_ptr->_type, remove_ptr->_create_id);
			}
		}
		Return(r, res);
	}

	void ActivityRankSystem::UpdatePlayer(net::Msg& m, Json::Value& r)
	{
		playerDataPtr player = player_mgr.getPlayer(m.playerID);
		if (!player)Return(r, err_illedge);//�Ƿ�����
		ReadJsonArray;
		const int type = js_msg[0u].asInt();
		if (type < 0 || type >= ActivityRankEnum::activity_rank_num)Return(r, err_illedge);
		player->ActivityRank().send_type_data(type);
	}

	void ActivityRankSystem::UpdateList(net::Msg& m, Json::Value& r)
	{
		playerDataPtr player = player_mgr.getPlayer(m.playerID);
		if (!player)Return(r, err_illedge);//�Ƿ�����
		ReadJsonArray;
		const int type = js_msg[0u].asInt();
		if (type < 0 || type >= ActivityRankEnum::activity_rank_num)Return(r, err_illedge);
		r[strMsg][2u] = _activity_data[type]->package_rank_list();
		r[strMsg][1u] = type;
		Return(r, res_sucess);
	}

	void ActivityRankSystem::UpdateReach(net::Msg& m, Json::Value& r)
	{
		playerDataPtr player = player_mgr.getPlayer(m.playerID);
		if (!player)Return(r, err_illedge);//�Ƿ�����
		ReadJsonArray;
		const int type = js_msg[0u].asInt();
		if (type < 0 || type >= ActivityRankEnum::activity_rank_num)Return(r, err_illedge);
		r[strMsg][2u] = _activity_data[type]->package_reach_box();
		r[strMsg][1u] = type;
		Return(r, res_sucess);
	}

	void ActivityRankSystem::GetReachBox(net::Msg& m, Json::Value& r)
	{
		playerDataPtr player = player_mgr.getPlayer(m.playerID);
		if (!player)Return(r, err_illedge);//�Ƿ�����
		ReadJsonArray;
		const int type = js_msg[0u].asInt();
		const int reach = js_msg[1u].asInt();
		const int res = player->ActivityRank().get_reach_box(type, reach);
		if (res == res_sucess)
		{
			r[strMsg][1u] = actionRes();
		}
		Return(r, res);
	}

	void ActivityRankSystem::UpdateTitle(net::Msg& m, Json::Value& r)
	{
		playerDataPtr player = player_mgr.getPlayer(m.playerID);
		if (!player)Return(r, err_illedge);//�Ƿ�����
		Json::Value& data_json = r[strMsg][1u] = Json::arrayValue;
		for (int i = 0; i < ActivityRankEnum::activity_rank_num; i++)
		{
			Json::Value single_json = Json::arrayValue;
			single_json.append(i);
			const ActivityCCRank* data = _activity_data[i];
			single_json.append(data->show_begin_time());
			single_json.append(data->activity_begin_time());
			single_json.append(data->activity_end_time());
			single_json.append(data->show_end_time());
			single_json.append(data->ruler_url());
			data_json.append(single_json);
		}
		Return(r, res_sucess);
	}

}
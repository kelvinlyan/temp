#include "player_orders.h"
#include "dbDriver.h"

namespace gg
{
	static void tickAction(const structTimer& timerData, const int playerID)
	{
		playerDataPtr player = player_mgr.getPlayer(playerID);
		if (!player) return;
		if (player->Orders().getTimerID() != timerData.timerID) return;

		//ÿ�λص���ʱ�����30����֮���������
		player->Orders().delTimer();
		player->Orders().clearOrder();
	}

	playerOrders::playerOrders(playerData* const own) : _auto_player(own)
	{
		uiActionTime = Common::gameTime();
		tm now_tm = Common::toTm(uiActionTime);
		uiActionTime = uiActionTime -
			(now_tm.tm_sec + now_tm.tm_min * MINUTE) +
			(now_tm.tm_min >= 30 ? 30 * MINUTE : 0)
			;
		iBuyActionNum = 0;
		eventID = ptrTimerIdentify();
		isClear = false;
	}

	void playerOrders::alterBuyNum(const int val)
	{
		if (0 == val)return;
		iBuyActionNum += val;
		iBuyActionNum = iBuyActionNum < 0 ? 0 : iBuyActionNum;
		_sign_auto();
	}

	void playerOrders::classFinal()
	{
		clearOrder();
	}

	void playerOrders::setData(mongo::BSONObj& objFind)
	{
		if (!objFind.isEmpty())
		{
			uiActionTime = objFind["ActionTime"].Int();
			tm now_tm = Common::toTm(uiActionTime);
			if (
				now_tm.tm_sec != 0 ||
				!(now_tm.tm_min == 30 || now_tm.tm_min == 0)
				)
			{//��������������ô����Ϊ��������
				uiActionTime = uiActionTime -
					(now_tm.tm_sec + now_tm.tm_min * MINUTE) +
					(now_tm.tm_min >= 30 ? 30 * MINUTE : 0)
					;
			}
			iBuyActionNum = objFind["BuyNum"].Int();
			if (uiActionTime <= 0){ uiActionTime = Common::gameTime(); }
		}
	}

	bool playerOrders::_auto_save()
	{
		mongo::BSONObj key = BSON(strPlayerID << Own().ID());
		mongo::BSONObj obj = BSON("$set" << BSON("Orders" <<
			BSON("ActionTime" << uiActionTime << "BuyNum" <<
			iBuyActionNum)
			));
		return db_mgr.SaveMongo(DBN::dbPlayerCollection, key, obj);
	}

	void playerOrders::_auto_update()
	{
		qValue json(qJson::qj_array);
		json.append(res_sucess);
		json.append(getBuyNum());
		json.append(uiActionTime + HARVEST_ACTION_TIME);
		Own().sendToClientFillMsg(gate_client::building_buy_action_num_resp, json);
	}

	void playerOrders::clearOrder()
	{
		do 
		{
			const unsigned action_num = Own().Res().getAction();
			if (action_num >= MAX_ACTION_NUM)break;
			const unsigned limit_add = MAX_ACTION_NUM - action_num;
			const unsigned now = Common::gameTime();
			unsigned add_num = 0;
			if (now > uiActionTime)
			{
				add_num = (now - uiActionTime) / HARVEST_ACTION_TIME;
				uiActionTime += (HARVEST_ACTION_TIME * add_num);
				if (add_num > limit_add)add_num = limit_add;
				_sign_auto();
			}
			Own().Res().alterAction(add_num);
		} while (false);
		isClear = true;
	}

	void playerOrders::addTimer(const bool restart /* = false */)
	{
		if (Own().isOnline())
		{
			if (eventID) { return; }
			if (restart)
			{
				unsigned now = Common::gameTime();
				tm now_tm = Common::toTm(now);
				uiActionTime = now -
					(now_tm.tm_sec + now_tm.tm_min * MINUTE) +
					(now_tm.tm_min >= 30 ? 30 * MINUTE : 0)
					;
				_sign_auto();
			}
			eventID = Timer::AddEventTickTime(boostBind(tickAction, _1, Own().ID()), Inter::event_build_action_timer, uiActionTime + 30 * MINUTE + 1);
		}
	}

	void playerOrders::delTimer()
	{
		if (eventID) { 
			eventID->delTimer();
		}
		eventID = ptrTimerIdentify();
	}
}
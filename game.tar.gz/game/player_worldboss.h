#pragma once

#include "auto_base.h"
#include "worldboss_helper.h"

namespace gg
{
	class playerWorldBoss
		: public _auto_player
	{
		public:
			playerWorldBoss(playerData* const own);

			virtual bool _auto_save();
			virtual void _auto_update();

			void getUIInfo(Json::Value& info);
			void getIncentInfo(Json::Value& info);
			void getReportInfo(Json::Value& info);
			void getRewardInfo(Json::Value& info);

			Json::Value getTotalRewardInfo();

			bool inCd();
			int cleanCd();

			int getDamage();
			int getRank();
			void setRank(int rk, const Json::Value& rank_reward);
			
			void addSilver(int& silver, bool damage = false);
			void addGold(int& gold);
			int doneBattle(int map_id, int damage, int buff, const std::string& rep_id);

			int getIncentNum();
			int addPersonIncent(int resource);
			int checkKingdomIncentLimit(int incent_num, int resource, int& succ);

			void dailyTick();

		private:
			virtual void classLoad();
			void checkAndUpdate();
			
		private:
			unsigned _record_day;
			unsigned _cd;
			int _damage;
			double _damage_rate;
			int _rank;

			unsigned _incent_num;
			unsigned _clean_cd_times;

			WorldBoss::OwnReportMgr _report_mgr;
			bool _nation_incented;
			
			int _damage_silver;
			int _total_silver;
			int _total_gold;
			Json::Value _rank_reward;
	};
}

#pragma once
			
#include "dbDriver.h"
#include "kingdomwar_data.h"
#include "kingdomwar_path.h"
#include "kingdomwar_city.h"
#include "kingdomwar_timer.h"

#define kingdomwar_sys (*gg::kingdomwar_system::_Instance)

namespace gg
{
	class kingdomwar_system
		: public KingdomWar::Observer
	{
		public:
			static kingdomwar_system* const _Instance;

			typedef boost::function<void()> Func;
			STDVECTOR(Func, FuncList);
			typedef boost::function<void(unsigned)> TickFunc;
			STDVECTOR(TickFunc, TickFuncList);

			UNORDERMAP(int, KingdomWar::NpcDataCfgPtr, NpcDataCfgMap);

			kingdomwar_system();

			void initData();

			KingdomWar::CityPtr getCity(int id);
			KingdomWar::PathPtr getPath(int id);
			KingdomWar::CityPtr getMainCity(int nation);
			const Json::Value& getRankReward(playerDataPtr d, int rank) const;
			KingdomWar::NpcDataCfgPtr getNpcData(int map_id);
			void addHpDebuff(sBattlePtr ptr, int hp);

			void updateName(playerDataPtr d);

			void updateBoxInfo();

			double speedRate() const { return KingdomWar::PrimeState::shared()? 2.5 : 1; }
			double supRate() const { return KingdomWar::PrimeState::shared()? 1 : 1; }
			double foodRate() const { return KingdomWar::PrimeState::shared()? 0.5 : 1; }
			double battleRate() const { return KingdomWar::PrimeState::shared()? 0.75 : 1; }

			DeclareRegFunction(quitReq);
			DeclareRegFunction(mainInfoReq);
			DeclareRegFunction(moveReq);
			DeclareRegFunction(playerInfoReq);
			DeclareRegFunction(formationReq);
			DeclareRegFunction(setFormationReq);
			DeclareRegFunction(cityBattleInfoReq);
			DeclareRegFunction(retreatReq);
			DeclareRegFunction(reportInfoReq);
			DeclareRegFunction(rankInfoReq);
			DeclareRegFunction(buyHpItemReq);
			DeclareRegFunction(useHpItemReq);
			DeclareRegFunction(outputInfoReq);
			DeclareRegFunction(getOutputReq);
			DeclareRegFunction(signGatherReq);
			DeclareRegFunction(armyInfoReq);
			DeclareRegFunction(changeFormationReq);
			DeclareRegFunction(militaryInfoReq);
			DeclareRegFunction(playerListReq);
			DeclareRegFunction(upManHpCostReq);
			DeclareRegFunction(upManHpReq);
			DeclareRegFunction(lookUpPlayerReq);
			DeclareRegFunction(personTaskReq);
			DeclareRegFunction(personTaskRewardReq);
			DeclareRegFunction(nationTaskReq);
			DeclareRegFunction(nationTaskRewardReq);
			DeclareRegFunction(greatEventReq);
			DeclareRegFunction(greatEventRewardReq);
			DeclareRegFunction(callShadowReq);
			DeclareRegFunction(callTowerReq);
			DeclareRegFunction(useTowerItemReq);
			DeclareRegFunction(getCityBoxReq);
			DeclareRegFunction(shadowInfoReq);
			DeclareRegFunction(cityBoxInfoReq);
			DeclareRegFunction(exploitRankReq);
			DeclareRegFunction(channelSendReq);
			DeclareRegFunction(transferReq);
			DeclareRegFunction(fightReq);
			DeclareRegFunction(killsRankReq);
			DeclareRegFunction(itemLimitReq);
			DeclareRegFunction(getGoldBoxReq);
			
			int distance(playerDataPtr d, int from, int to) const;
			void getMainInfo(qValue& q);
			void mainInfo();
			void mainInfo(playerDataPtr d);
			void attach(int id);
			void tick();

			void goBackMainCity(unsigned time, playerDataPtr d, int army_id, Json::Value& tips);

			void addTimer(unsigned tick_time, const KingdomWar::Timer::TickFunc& func);
			void addUpdater(const Func& func);
			void add5MinTicker(const TickFunc& func);
			void updateRank(playerDataPtr d, int old_value);
			void updateNationTask(int nation, int type, const Json::Value& arg = Json::nullValue);
			void updatePersonTask(playerDataPtr d, int type, const Json::Value& arg = Json::nullValue);
			void updateGreatEvent(playerDataPtr d, int idx);

			int getCostTime(int from_id, int to_id);
			sBattlePtr getBattlePtr(playerDataPtr d, int army_id);

			const KingdomWar::LineInfo& getLine(int from_id, int to_id) const;

			int checkStar(int star) const
			{
				if (star < 0)
					star = 0 - star;
				if (star >= _win_hp_cost.size())
					star = 0;
				return star;
			}

			int winHpCost(int star) const;
			int loseHpCost(int star) const;
			int winExploit(int star) const { return _win_exploit[checkStar(star)]; }
			int loseExploit(int star) const { return _lose_exploit[checkStar(star)]; }
			int elecAttackExploit() const { return _elec_attack_exploit; }
			int elecAttackHp() const { return _elec_attack_hp; }
			inline int hpExploit(int lv, int hp) const;

			int battleSilver(playerDataPtr d, int result) const;

			void updateHpInfo(playerDataPtr d, int army_id);
			const KingdomWar::HpDebuff& hpDebuff(int hp) const;

			void DoBroadcast(int nation, qValue& m);
			void updateNationTask(playerDataPtr d);
			void noticeUnity(int nation);
			void initPrimeState(unsigned tick_time);
			void tickPrimeTime(unsigned tick_time);
			void tickOrdinaryTime(unsigned tick_time);
			void nearbyID1(playerDataPtr d, const int to, const int from, std::vector<int>& nearby_ids);
			void nearbyID2(playerDataPtr d, const int to, const int from, std::vector<int>& nearby_ids);
			void nearbyID3(playerDataPtr d, const int to, const int from, std::vector<int>& nearby_ids);
			unsigned distance(const int from, const int to);

		private:
			void loadFile();
			void loadPlayer();
			void loadNpc();
			void loadShadow();
			void initMap();
			void loadRank();
			void startTimer();
			void timerTick();
			void outputTick();
			void addTimer();
			void update();
			void resetRandomRange();
			void tickEvery5Min();
			void tickState();
			void tickClearTime();
			void tickUnity(unsigned cur_time);
			void updateSign(int nation);
			void updateSign(playerDataPtr d);
			void updateParam(int nation);
			void updateParam(playerDataPtr d);
			void setPrimeTimeBroadcast();
			void tickBC2020();
			void tickBC2025();
			void tickRollBC2025To2055();
			void tickTime0300();
			void tickTime0500();
			void tickTime2000();
			void personalTaskLog(unsigned cur_time);
			void updateBoxInfo(playerDataPtr d);

			void doLoadNpc(const mongo::BSONObj& obj);
			void doLoadShadow(const mongo::BSONObj& obj);
			void doLoadShadowNpc(const mongo::BSONObj& obj);

			void loadPathPlayer(KingdomWar::PathPtr ptr, unsigned time, int pid, int army_id, int to_city_id);
			void loadPathNpc(KingdomWar::PathPtr ptr, unsigned time, KingdomWar::NpcDataPtr d, int to_city_id);
			void loadPathShadow(KingdomWar::PathPtr ptr, unsigned time, KingdomWar::ShadowDataPtr d, int to_city_id);
			void loadPathShadowNpc(KingdomWar::PathPtr ptr, unsigned time, KingdomWar::ShadowNpcDataPtr d, int to_city_id);

		private:
			KingdomWar::PathList _path_list;
			
			KingdomWar::ShortestPath _shortest_path;

			FuncList _updaters;
			TickFuncList _5_min_tickers;

			NpcDataCfgMap _npc_map;
			std::vector<Json::Value> _rank_reward1;
			std::vector<Json::Value> _rank_reward2;
			std::vector<int> _win_hp_cost;
			std::vector<int> _lose_hp_cost;
			std::vector<int> _win_exploit;
			std::vector<int> _lose_exploit;
			std::vector<double> _hp_exploit;
			std::vector<int> _battle_silver;
			std::vector<int> _win_hp_cost_2;
			std::vector<int> _lose_hp_cost_2;
			std::vector<KingdomWar::HpDebuff> _hp_debuff;
			int _elec_attack_exploit;
			int _elec_attack_hp;

			BOOSTSHAREPTR(KingdomWar::Graph, GraphPtr);
			GraphPtr _graph;

			STDVECTOR(int, NearbyID);
			STDVECTOR(NearbyID, NearbyIDS);
			NearbyIDS _nearby_ids;
	};

	inline int kingdomwar_system::hpExploit(int lv, int hp) const
	{
		if (lv < 1)
			lv = 1;
		if (lv > _hp_exploit.size())
			lv = _hp_exploit.size();
		return hp / _hp_exploit[lv - 1];
	}
}

#include "player_kingdomwar_fm.h"
#include "playerManager.h"
#include "man_system.h"
#include "kingdomwar_def.h"
#include "task_mgr.h"
#include "kingdomwar_system.h"
#include "kingdomwar_task_def.h"

namespace gg
{
	namespace KingdomWar
	{
		int getManMaxHp(playerDataPtr player, int army_id, playerManPtr man)
		{
			mBattlePtr mbattle = Creator<manBattle>::Create();
			cfgManPtr config = man_sys.getConfig(man->armyID());
			if (!config) return 0;
			mbattle->manID = man->armyID();
			mbattle->battleValue = man->battleValue();
			mbattle->holdMorale = config->holdMorale;
			mbattle->set_skill_1(config->skill_1);
			mbattle->set_skill_2(config->skill_2);
			mbattle->armsType = config->armsType;
			mbattle->manLevel = man->LV();
			memcpy(mbattle->armsModule, config->armsModules, sizeof(mbattle->armsModule));
			man->toInitialAttri(mbattle->initialAttri);
			man->toBattleAttri(player->KingDomWarFM().getFMId(army_id), mbattle->battleAttri);
			return mbattle->getTotalAttri(idx_hp);
		}
	}

	using namespace KingdomWar;

	playerKingdomWarSGFM::playerKingdomWarSGFM(int army_id, playerData* const own)
		: _auto_player(own), _army_id(army_id), _inited(false)
	{
		_face = 0;
		_fm_id = 0;
		_power = -1;
		_man_list.assign(9, playerManPtr());
	}

	bool playerKingdomWarSGFM::empty() const
	{
		ForEachC(ManList, it, _man_list)
		{
			if (*it)
				return false;
		}
		return true;
	}

	bool playerKingdomWarSGFM::inFM(int id) const
	{
		ForEachC(ManList, it, _man_list)
		{
			if (!(*it) || (*it)->armyID() != id)
				continue;
			return true;
		}
		return false;
	}

	void playerKingdomWarSGFM::load(const mongo::BSONObj& obj)
	{
		_fm_id = obj["i"].Int();
		_inited = obj["t"].Bool();
		checkNotEoo(obj["fa"])
			_face = obj["fa"].Int();
		const std::vector<mongo::BSONElement> ele = obj["f"].Array();
		for (unsigned i = 0; i < 9; ++i)
			_man_list[i] = Own().Man().findArmy(ele[i].Int());
	}

	bool playerKingdomWarSGFM::_auto_save()
	{
		mongo::BSONObj key = BSON(strPlayerID << Own().ID() << "a" << _army_id);
		mongo::BSONObjBuilder obj;
		obj << strPlayerID << Own().ID() << "a" << _army_id << "i" << _fm_id
			<< "t" << _inited << "fa" << _face;
		{
			mongo::BSONArrayBuilder b;
			ForEachC(ManList, it, _man_list)
				b.append((*it)? (*it)->uniqueID() : -1);
			obj << "f" << b.arr();
		}
		return db_mgr.SaveMongo(DBN::dbPlayerKingdomWarFM, key, obj.obj());
	}

	static qValue getEquipV(playerManPtr& ptr)
	{
		qValue q;
		std::vector<itemPtr> eq = ptr->getEquipList();
		for (unsigned i = 0; i < eq.size(); ++i)
		{
			if (eq[i])
			{
				qValue tmp;
				tmp << i << eq[i]->itemID() << eq[i]->getLv();
				q << tmp;
			}
		}
		return q;
	}

	void playerKingdomWarSGFM::getManInfo(qValue& q)
	{
		ForEach(ManList, it, _man_list)
		{
			playerManPtr& ptr = *it;
			int man_hp;
			if (ptr && (man_hp = Own().KingDomWar().manHp(ptr->armyID())) > 0)
			{
				qValue tmp;
				tmp << ptr->armyID() << getEquipV(ptr) << KingdomWar::getManMaxHp(Own().getOwnDataPtr(), _army_id, ptr) << man_hp;
				q << tmp;
			}
		}
	}

	void playerKingdomWarSGFM::getInfo(qValue& q)
	{
		if (_army_id == 0 && !_inited)
		{
			_inited = true;
			defaultFm();
			//TaskMgr::update(Own().getOwnDataPtr(), gg::Task::EnterKingdomWar);
		}
		q.addMember("a", _army_id);
		q.addMember("i", _fm_id);
		q.addMember("v", bv());
		q.addMember("fa", face());
		qValue f;
		ForEachC(ManList, it, _man_list)
			f.append((*it)? (*it)->armyID() : -1);
		q.addMember("f", f);
	}

	void playerKingdomWarSGFM::getFMInfo(qValue& q)
	{
		ForEachC(ManList, it, _man_list)
		{
			if (!(*it))
				continue;
			qValue tmp;
			tmp.append((*it)->armyID());
			tmp.append(Own().KingDomWar().manHp((*it)->armyID()));
			tmp.append(KingdomWar::getManMaxHp(Own().getOwnDataPtr(), _army_id, (*it)));
			tmp.append((*it)->LV());
			q.append(tmp);
		}
	}
	
	void playerKingdomWarSGFM::_auto_update()
	{
		qValue m;
		m.append(res_sucess);
		qValue q(qJson::qj_object);
		getInfo(q);
		m.append(q);
		Own().sendToClientFillMsg(gate_client::kingdom_war_single_formation_resp, m);
	}

	void playerKingdomWarSGFM::clearBV()
	{
		_power = -1;
		//_face = 0;
		if (Own().KingDomWar().onMain())
			_sign_update();
	}

	void playerKingdomWarSGFM::defaultFm()
	{
		_man_list = Own().WarFM().currentFM();
		_fm_id = Own().WarFM().currentID();
		_power = -1;
		_face = KingdomWar::getMaxBVManID(_man_list);
		_sign_save();
	}

	int playerKingdomWarSGFM::setFormation(int fm_id, const int fm[9])
	{
		if (!Own().KingDomWar().armyHpFilled(_army_id))
			return err_kingdomwar_army_hp_not_enough;

		bool empty_fm = true;
		const FMCFG::HOLEVEC& config = playerWarFM::getConfig(fm_id).HOLES;
		boost::unordered_set<int> SAMEMAN;
		for (unsigned i = 0; i < 9; ++i)
		{
			if (fm[i] < 0)continue;
			empty_fm = false;
			//if (!SAMEMAN.insert(fm[i] / 100).second)return err_fomat_same_man;
			if (Own().KingDomWarFM().manUsed(_army_id, fm[i])) return err_fomat_same_man;
		}
		
		ManList tmpList;
		tmpList.assign(9, playerManPtr());
		if (_fm_id == fm_id)
		{
			unsigned format_num = 0;
			for (unsigned i = 0; i < 9; ++i)
			{
				if (fm[i] < 0)continue;
				if (!config[i].Use)continue;
				if (Own().LV() < config[i].LV)return err_format_hole_limit;
				if (config[i].Process > 0 && !Own().War().isChallengeMap(config[i].Process))return err_format_hole_limit;
				playerManPtr man = Own().Man().findArmyByMan(fm[i]);//ÊÇ·ñÂú×ã¿ªÆôÌõ¼þ
				if (man && SAMEMAN.insert(man->uniqueID()).second == false)continue;//重复了
				tmpList[i] = man;
				if (man && ++format_num >= 5) break;
			}
			_man_list = tmpList;
		}
		else
		{
			bool flag = false;
			_fm_id = fm_id;
			int idx = 0;
			for (unsigned i = 0; i < 9; ++i)
			{
				if (!config[i].Use)continue;
				if (Own().LV() < config[i].LV)continue;
				if (config[i].Process > 0 && !Own().War().isChallengeMap(config[i].Process))continue;
				for(; idx < 9; ++idx)
				{
					if (fm[idx] < 0)
						continue;
					playerManPtr man = Own().Man().findArmyByMan(fm[idx++]);//ÊÇ·ñÂú×ã¿ªÆôÌõ¼þ
					tmpList[i] = man;
					flag = true;
					break;
				}
			}
			if (!empty_fm && !flag)
				return err_format_not_find;
			_man_list = tmpList;
		}

		recalFM();
		_face = KingdomWar::getMaxBVManID(_man_list);
		_sign_auto();
		return res_sucess;
	}

	void playerKingdomWarSGFM::clearManHp()
	{
		ForEach(ManList, it, _man_list)
		{
			if (!(*it)) continue;
			Own().KingDomWar().setManHp((*it)->armyID(), 0);
		}
	}

	void playerKingdomWarSGFM::recalFM()
	{
		_power = CalBV(Own().getOwnDataPtr(), _man_list, _fm_id);
	}

	int playerKingdomWarSGFM::upManHp()
	{
		int add = 0;
		ForEach(ManList, it, _man_list)
		{
			if (!*it) continue;
			int max = KingdomWar::getManMaxHp(Own().getOwnDataPtr(), _army_id, *it);
			int cur = Own().KingDomWar().manHp((*it)->armyID());
			add += (max - cur);
			Own().KingDomWar().setManHp((*it)->armyID(), max);
		}
		return add;
	}

	int playerKingdomWarSGFM::face()
	{
		if (_face == 0)
			_face = KingdomWar::getMaxBVManID(_man_list);
		return _face;
	}

	int playerKingdomWarSGFM::bv()
	{
		if (_power == -1)
		{
			recalFM();
			//_face = KingdomWar::getMaxBVManID(_man_list);
		}
		return _power;
	}

	void playerKingdomWarSGFM::getHpInfo(qValue& q)
	{
		q.addMember("a", _army_id);
		qValue qq;
		ForEachC(ManList, it, _man_list)
		{
			if (!(*it))
				continue;
			qValue tmp;
			tmp.append((*it)->armyID());
			tmp.append(Own().KingDomWar().manHp((*it)->armyID()));
			tmp.append(KingdomWar::getManMaxHp(Own().getOwnDataPtr(), _army_id, (*it)));
			tmp.append((*it)->LV());
			qq.append(tmp);
		}
		q.addMember("h", qq);
	}

	int playerKingdomWarSGFM::getUpHpNum()
	{
		int add = 0;
		ForEach(ManList, it, _man_list)
		{
			if (!*it) continue;
			int max = KingdomWar::getManMaxHp(Own().getOwnDataPtr(), _army_id, *it);
			int cur = Own().KingDomWar().manHp((*it)->armyID());
			add += (max - cur);
			//Own().KingDomWar().setManHp((*it)->mID(), max);
		}
		return add;
	}

	int playerKingdomWarSGFM::getUpHpCost()
	{
		int man_hp = 0;
		ForEachC(ManList, it, _man_list)
		{
			if (!(*it))
				continue;
			int cur_hp = Own().KingDomWar().manHp((*it)->armyID());
			int max_hp = KingdomWar::getManMaxHp(Own().getOwnDataPtr(), _army_id, (*it));
			if (cur_hp < max_hp)
				man_hp += (max_hp - cur_hp);
		}
		if (man_hp == 0)
			return 0;
		int cost = 2000 + Own().LV() * 100 + bv() * 0.5;
		if (XiaoHao::shared().check(Own().getOwnDataPtr()))
			cost *= 2;
		return KingdomWar::PrimeState::shared()? cost * kingdomwar_sys.foodRate() : cost;
	}

	bool playerKingdomWarSGFM::isDead()
	{
		ForEachC(ManList, it, _man_list)
		{
			if (!(*it))
				continue;
			if (Own().KingDomWar().manHp((*it)->armyID()) > 0)
				return false;
		}
		return true;
	}

	playerKingdomWarFM::playerKingdomWarFM(playerData* const own)
		: _auto_player(own)
	{
		for (int i = 0; i < KingdomWar::ArmyNum; ++i)
			_fm_list.push_back(Creator<playerKingdomWarSGFM>::Create(i, own));
	}

	void playerKingdomWarFM::classLoad()
	{
		mongo::BSONObj key = BSON(strPlayerID << Own().ID());
		objCollection objs = db_mgr.Query(DBN::dbPlayerKingdomWarFM, key);
		for (unsigned i = 0; i < objs.size(); ++i)
		{
			int army_id = objs[i]["a"].Int();
			_fm_list[army_id]->load(objs[i]);
		}
	}

	bool playerKingdomWarFM::_auto_save()
	{
		return true;
	}

	void playerKingdomWarFM::_auto_update()
	{
	}

	void playerKingdomWarFM::update()
	{
		qValue m;
		m.append(res_sucess);
		qValue q;
		for (unsigned i = 0; i < _fm_list.size(); ++i)
		{
			qValue tmp(qJson::qj_object);
			_fm_list[i]->getInfo(tmp);
			q.append(tmp);
		}
		m.append(q);
		Own().sendToClientFillMsg(gate_client::kingdom_war_all_formation_resp, m);
	}

	int playerKingdomWarFM::setFormation(int army_id, int fm_id, const int fm[9])
	{
		if (army_id < 0 || army_id >= _fm_list.size())
			return err_illedge;

		return _fm_list[army_id]->setFormation(fm_id, fm);
	}

	bool playerKingdomWarFM::manUsed(int army_id, int man_id) const
	{
		for (unsigned i = 0; i < _fm_list.size(); ++i)
		{
			if (i == army_id)
				continue;
			const ManList& ml = _fm_list[i]->manList();
			ForEachC(ManList, it, ml)
			{
				if ((*it) && (*it)->armyID() == man_id)
					return true;
			}
		}
		return false;
	}

	void playerKingdomWarFM::getHpInfo(int army_id, qValue& q)
	{
		_fm_list[army_id]->getHpInfo(q);
	}

	void playerKingdomWarFM::recalFM(int id)
	{
		if (Own().Info().Nation() == Kingdom::null)
			return;
		for (unsigned i = 0; i < _fm_list.size(); ++i)
		{
			if (_fm_list[i]->inFM(id))
			{
				_fm_list[i]->clearBV();
				break;
			}
		}
	}

	int playerKingdomWarFM::getUpHpCost(int army_id)
	{
		return _fm_list[army_id]->getUpHpCost();
	}

	int playerKingdomWarFM::getUpHpNum(int army_id)
	{
		return _fm_list[army_id]->getUpHpNum();
	}

	int playerKingdomWarFM::upManHpByFood(std::vector<int> army_id_vec, int& cost)
	{
		for (std::vector<int>::iterator it = army_id_vec.begin(); 
			it != army_id_vec.end();)
		{
			int up_hp_state = Own().KingDomWar().getUpHpState(*it);
			if (up_hp_state > 0)
			{
				if (army_id_vec.size() == 1)
				{
					if (up_hp_state == 1)
						return err_kingdomwar_have_used_food_up_hp;
					else
						return err_kingdomwar_have_used_hp_item;
				}
				else
				{
					army_id_vec.erase(it);
					continue;
				}
			}
			++it;
		}
		if (army_id_vec.empty())
			return err_kingdomwar_army_at_war;
		cost = 0;
		for (unsigned i = 0; i < army_id_vec.size(); ++i)
			cost += getUpHpCost(army_id_vec[i]);
		if (cost == 0)
			return err_kingdomwar_army_state_full;
		int prev = Own().Res().getFood();
		if (prev < cost)
			return err_food_not_enough;
		Own().Res().alterFood(0 - cost);
		int add = 0;
		int bv = 0;
		for (unsigned i = 0; i < army_id_vec.size(); ++i)
		{
			if (Own().KingDomWar().getUpHpState(army_id_vec[i]) > 0)
				continue;
			const Position& pos = Own().KingDomWarPos().position(army_id_vec[i]);
			if (pos.type == PosCity)
			{
				CityPtr ptr = CityMgr::shared().getCity(pos.id);
				int num = ptr->upHpNumInBattle(Own().getOwnDataPtr(), army_id_vec[i]);
				if (num != -1)
				{
					Own().KingDomWar().setUpHpState(army_id_vec[i], 1);
					add += num;
					continue;
				}
			}
			add += upManHp(army_id_vec[i]);
			bv += getBV(army_id_vec[i]);
		}
		int exploit = kingdomwar_sys.hpExploit(Own().LV(), bv);
		if (exploit < 1)
			exploit = 1;
		playerKingdomWar::ExploitReason = KingdomWar::UpManHp;
		Own().Res().alterExploit(exploit);
		//Own().KingDomWar().alterDailyExploit(exploit);
		TaskMgr::update(Own().getOwnDataPtr(), gg::Task::KingdomWarUseFoodNum, cost);
		kingdomwar_sys.updatePersonTask(Own().getOwnDataPtr(), KingdomWar::Task::UseFood, Json::Value(cost));
		Log(DBLOG::strLogKingdomWar, Own().getOwnDataPtr(), 7, prev, Own().Res().getFood());
		return res_sucess;
	}

	int playerKingdomWarFM::getCurrentHp(int army_id)
	{
		int sum = 0;
		const ManList& man_list = getFM(army_id);
		ForEachC(ManList, it, man_list)
		{
			if (*it)
				sum += Own().KingDomWar().manHp((*it)->armyID());
		}
		return sum;
	}

	int playerKingdomWarFM::getMaxHp(int army_id)
	{
		int sum = 0;
		const ManList& man_list = getFM(army_id);
		ForEachC(ManList, it, man_list)
		{
			if (*it)
				sum += KingdomWar::getManMaxHp(Own().getOwnDataPtr(), army_id, (*it));
		}
		return sum;
	}
}

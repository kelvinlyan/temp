#include "player_red_paper.h"
#include "dbDriver.h"

const static std::string strLocalID = "li";
const static std::string strDelete = "de";
const static std::string strDate = "dt";
const static std::string strCash = "cr";
const static std::string strNum = "nr";
const static std::string strItemID = "ii";
const static std::string strChannel = "ch";
const static std::string strResType = "rt";
const static std::string strPlayerID2 = "rpi";
const static std::string strIndex = "idx";
const static std::string strTotalPaper = "tp";
const static std::string strTotalRob = "tr";
const static std::string strFaceID = "fi";//
const static std::string strDelLatest = "dl";
const static std::string strLvDate = "ld";
const static std::string strLimitDate = "lld";
const static std::string strLimitPid = "llp";
const static std::string strLimitLid = "lll";

namespace gg
{

	playerRedPaper::playerRedPaper(playerData* const own)
		:_auto_player(own),
		_total_paper(0),
		_lv_date(1),
		_limit_date(1),
		_limit_pid(-1),
		_limit_lid(-1)
	{
	}

	int playerRedPaper::getPaperCount()
	{
		++_total_paper;
		_auto_save();
		return _total_paper;
	}

	void playerRedPaper::addDelLog(int playerID, int local_id, unsigned date)
	{
		if (_wor_delete_map.find(playerID) == _wor_delete_map.end())
		{
			LocalIdToLogIdMap list;
			_wor_delete_map[playerID] = list;
		}
		_wor_delete_map[playerID][local_id] = date;
		save_wor_del_db(playerID, local_id, date);
	}

	bool playerRedPaper::isDel(int playerID, int local_id)
	{
		if (_wor_delete_map.find(playerID) != _wor_delete_map.end()
			&& _wor_delete_map[playerID].find(local_id) != _wor_delete_map[playerID].end())
		{
			return true;
		}
		else
		{
			return false;
		}
	}

	void playerRedPaper::setLvDate()
	{
		_lv_date = Common::gameTime();
		_auto_save();
	}

	bool playerRedPaper::isFree(unsigned date)
	{
		return date > _lv_date ? true : false;
	}

	void playerRedPaper::setLimit(red_paper::UnitPaperPtr paper)
	{
		_limit_date = paper->date;
		_limit_pid = paper->player_id;
		_limit_lid = paper->local_id;
		_auto_save();
	}

	void playerRedPaper::getLimit(unsigned& date, int& playerID, int& local_id)
	{
		date = _limit_date;
		playerID = _limit_pid;
		local_id = _limit_lid;
	}

	bool playerRedPaper::isOpenable(int playerID, int local_id)
	{
		if (_player_rob_map.find(playerID) != _player_rob_map.end()
			&& _player_rob_map[playerID].find(local_id) != _player_rob_map[playerID].end())
		{
			return false;
		}
		return true;
	}
	
	void playerRedPaper::addRobbedLog(int local_id, int playerID, unsigned date)
	{
		if (_player_rob_map.find(playerID) == _player_rob_map.end())
		{
			LocalIdToLogIdMap id_map;
			_player_rob_map[playerID] = id_map;
		}
		_player_rob_map[playerID][local_id] = date;
		//save_robbed_map_db(playerID, local_id, 1, date);//
		save_robbed_map_db(playerID, local_id, date);
	}

	void playerRedPaper::clear()
	{
		unsigned now = Common::gameTime();
		for (PlayerIdToLocalIdMap::iterator fit = _wor_delete_map.begin(); fit != _wor_delete_map.end();++fit)
		{
			for (LocalIdToLogIdMap::iterator sit = fit->second.begin(); sit != fit->second.end();++sit)
			{
				if (sit->second > 10*DAY && now - sit->second > DEAHLINE)
				{
					del_wor_del_db(fit->first, sit->first);
				}
			}
		}

		for (PlayerIdToLocalIdMap::iterator fit = _player_rob_map.begin(); fit != _player_rob_map.end();++fit)
		{
			for (LocalIdToLogIdMap::iterator sit = fit->second.begin(); sit != fit->second.end();++sit)
			{
				if (sit->second > 10*DAY && now - sit->second > DEAHLINE)
				{
					del_robbed_map_db(fit->first, sit->first);
				}
			}
		}
	}

	bool playerRedPaper::save_robbed_map_db(int playerID, int local_id, unsigned date)
	{
		mongo::BSONObj key = BSON(strPlayerID << Own().ID() << strPlayerID2 << playerID << strLocalID << local_id);

		mongo::BSONObj obj = BSON(strPlayerID << Own().ID()
			<< strPlayerID2 << playerID
			<< strLocalID << local_id
			<< strDate << date
		);

		return db_mgr.SaveMongo(DBN::dbPlayerRobbedMapRedPaper, key, obj);
	}

	bool playerRedPaper::save_wor_del_db(int playerID, int local_id, unsigned date)
	{
		mongo::BSONObj key = BSON(strPlayerID << Own().ID() << strPlayerID2 << playerID << strLocalID << local_id);
		mongo::BSONObj obj = BSON(strPlayerID << Own().ID() 
			<< strPlayerID2 << playerID 
			<< strLocalID << local_id
			<< strDate << date
		);

		return db_mgr.SaveMongo(DBN::dbPlayerWorldDeleteRedPaper, key, obj);
	}

	void playerRedPaper::del_robbed_map_db(int playerID, int local_id)
	{
		mongo::BSONObj key = BSON(strPlayerID << Own().ID() << strPlayerID2 << playerID << strLocalID << local_id);

		db_mgr.RemoveCollection(DBN::dbPlayerRobbedMapRedPaper, key);
	}

	void playerRedPaper::del_wor_del_db(int playerID, int local_id)
	{
		mongo::BSONObj key = BSON(strPlayerID << Own().ID() << strPlayerID2 << playerID << strLocalID << local_id);

		db_mgr.RemoveCollection(DBN::dbPlayerWorldDeleteRedPaper, key);
	}

	bool playerRedPaper::_auto_save()
	{
		mongo::BSONObj key = BSON(strPlayerID << Own().ID());

		mongo::BSONObj obj = BSON(strPlayerID << Own().ID()
			<< strTotalPaper << _total_paper
			<< strLvDate << _lv_date
			<< strLimitDate << _limit_date
			<< strLimitPid << _limit_pid
			<< strLimitLid << _limit_lid
		);
		return db_mgr.SaveMongo(DBN::dbPlayerRedPaper, key, obj);
	}

	void playerRedPaper::classLoad()
	{
		unsigned now = Common::gameTime();
		//1.
		mongo::BSONObj key = BSON(strPlayerID << Own().ID());
		mongo::BSONObj obj = db_mgr.FindOne(DBN::dbPlayerRedPaper, key);
		if (!obj.isEmpty())
		{
			_total_paper = obj[strTotalPaper].Int();
			_lv_date = obj[strLvDate].Int();
			_limit_date = obj[strLimitDate].Int();
			_limit_pid = obj[strLimitPid].Int();
			_limit_lid = obj[strLimitLid].Int();
		}
		
		
		//3._player_rob_map
		objCollection objs2 = db_mgr.Query(DBN::dbPlayerRobbedMapRedPaper, key);
		ForEachC(objCollection, it, objs2)
		{
			const mongo::BSONObj& obj = (*it);
			int playerID = obj[strPlayerID2].Int();
			int local_id = obj[strLocalID].Int();
			//int index = obj[strIndex].Int();
			unsigned date = 1;
			if (!obj[strDate].eoo())
			{
				date = obj[strDate].Int();
			}
			if (_player_rob_map.find(playerID) == _player_rob_map.end())
			{
				LocalIdToLogIdMap list;
				_player_rob_map[playerID] = list;
			}
			_player_rob_map[playerID][local_id] = date;
		}

		//5.world delete
		objCollection objs4 = db_mgr.Query(DBN::dbPlayerWorldDeleteRedPaper, key);
		ForEachC(objCollection, it, objs4)
		{
			const mongo::BSONObj& obj = (*it);
			int playerID = obj[strPlayerID2].Int();
			int local_id = obj[strLocalID].Int();
			unsigned date = 1;
			if (!obj[strDate].eoo())
			{
				date = obj[strDate].Int();
			}
			if (_wor_delete_map.find(playerID) == _wor_delete_map.end())
			{
				LocalIdToLogIdMap list;
				_wor_delete_map[playerID] = list;
			}
			_wor_delete_map[playerID][local_id] = date;
		}
		

	}


	playerRedPaper::~playerRedPaper()
	{
	}
}
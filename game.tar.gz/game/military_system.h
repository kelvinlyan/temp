#pragma once

#include "commom.h"
#include "dbDriver.h"

#define military_sys (*gg::military_system::_Instance)

namespace gg
{
	class military_system
	{
		public:
			static military_system* const _Instance;

			DeclareRegFunction(data);
			DeclareRegFunction(levelUp);
	};
}

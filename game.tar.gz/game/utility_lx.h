/*
created by Lin Xing
������ͷ�ļ�
*/

#pragma once

#include "commom.h"
#include "action_system.h"

#define MAX_TIME 2145929760

namespace lx
{
	typedef struct _odds_unit
	{
		int odd;
		int idx;
	} OddUnit;

	STDVECTOR(OddUnit, OddsSequence);

	class utility_lx
	{
	public:
		utility_lx();
		~utility_lx();
	public:
		STDVECTOR(int, AList);
		//������BoxList���͵ı���ϲ�Ϊһ��
		static  Json::Value combineArrayBox(const Json::Value& left, const Json::Value& right);
		static size_t getProbIndex(const std::vector<int>& odds, int sum = 10000);
		static Json::Value parseJson(Json::Value json_box);
		static std::string parseJsonBox(Json::Value json_box);
		static void combineJsonBox(const Json::Value& from, Json::Value& to);//�ϲ�����ԭʼ��(�����ļ��еĸ�ʽ)Box
		static bool is_time_overlap(unsigned begin_n, unsigned end_n, unsigned begin_o, unsigned end_o);
		static void switchToLogJson(Json::Value& json_box);

		template<typename T>
		static void swapVectorElement(std::vector<T>& vec, int idx1, int idx2)
		{
			if (idx1 == idx2)
			{
				return;
			}
			if (idx1 >= vec.size() || idx2 >= vec.size())
			{
				return;
			}
			T temp = vec[idx1];
			vec[idx1] = vec[idx2];
			vec[idx2] = temp;
		}

		//������ظ����������㷨[lbound,ubound]
		static std::vector<int> randomSequence(int lbound, int ubound);

		/*����Ȩ�ز��ظ�ѡȡcount����������ѡ����±�
		* seq��Ȩ��ԭʼ����,seq[0]=0;seq.back() == Ȩ���ܺ�
		*/
		static std::vector<int> randomWeightSequence(OddsSequence seq, int count);
		static int randomWeightSequenceConst(const OddsSequence& seq, int& idx, int& odd);

		static Json::Value toRawBox(int aID, int v = 1, int id = -1);
	};

	STDVECTOR(int, Sequence);

	typedef struct _boxSingle
	{
		ActionBoxList box;
		std::string strBox;
		Json::Value jsonBox;
		Json::Value rawBox;
		void load()
		{
			jsonBox = lx::utility_lx::parseJson(rawBox);
			strBox = lx::utility_lx::parseJsonBox(rawBox);
			box = actionFormatBox(rawBox);
		}
	} BoxSingle;

}


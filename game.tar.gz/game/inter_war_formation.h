//###################################
//create by Jim
//2015-12-08
//###################################

#pragma once

#include "auto_do.h"
#include "mongoDB.h"

namespace gg
{
	class playerMan;
	BOOSTSHAREPTR(playerMan, playerManPtr);
	//�� 0 ~ 11 һ��12����
	class interSGFM : public _auto_player
	{
	public://��ID
		interSGFM(const unsigned ID, playerData* const own);
		virtual ~interSGFM(){}
		virtual int format(const int fm[9]);
		virtual void tryToFormat(const vector<playerManPtr>& vec);
		virtual qValue toJson();
		virtual mongo::BSONArray toBsonArr();
		std::vector<playerManPtr> toFormat();
		std::vector<playerManPtr> toInvaildFormat();
		bool isEmpty();
		void rawInitial(const bool in, vector<mongo::BSONElement>& vec);
		const unsigned fmID;
		inline int getBV(){ return FMPower; }
		void recalFM(const bool update = true);
		inline bool isNewFM(){ return isNew; }
		Json::Value uploadManJson();
	protected:
		virtual int rawFormat(const int fm[9]);
		virtual bool _on_sign_update();
		virtual bool _auto_save();
		playerManPtr FMList[9];//�����б�
		int FMPower;
		bool isNew;//�Ƿ��Ǵ�Ů��
	};
	BOOSTSHAREPTR(interSGFM, interFMPtr);

	class interWarFM : public _auto_player
	{
	public:
		interWarFM(playerData* const own);
		~interWarFM(){}
		virtual int format(const unsigned fmID, const int fm[9]);
		void updateAll();
		void updateSingle(const unsigned fmID);
		int defaultFM(const unsigned fmID);
		inline unsigned currentID(){ return currentFMID; }
		void recalFMValue(const int fmID, const bool update = true);
		void recalFMValue(const bool update = true);//���¼���ս������
		bool currentEmpty();
		bool appointEmpty(const unsigned FMID);
		void tryFullDefalut();
		std::vector<playerManPtr> currentFM();
		std::vector<playerManPtr> appointFM(const unsigned FMID);
		std::vector<playerManPtr> currentInvaildFM();
		std::vector<playerManPtr> appointInvaildFM(const unsigned FMID);
		int currentBV();//��ȡ��ǰĬ���󷨵�ս������ֵ
		void setUploadFormat(Json::Value& json);
		Json::Value uploadFormatJson();
		//tick
		void tickFM(const unsigned FMID);
	private:
		bool base_update;
		Json::Value upload_json;

		virtual void classLoad();
		virtual void classFinal();

		virtual bool _auto_save();
		virtual void _auto_update();
		unsigned currentFMID;
		STDVECTOR(interFMPtr, fmVec);
		fmVec fmList;
		UNORDERSET(unsigned, UINTSET);
		UINTSET updateList_;
	};
}

//###################################
//create by Jim
//2015-11-15
//###################################

#pragma once

#include "rapidjson/document.h"
#include "rapidjson/stringbuffer.h"
#include "rapidjson/prettywriter.h"
#include "commom.h"

namespace gg
{
	namespace qJson
	{
		enum TYPE
		{
			qj_object,
			qj_array,
		};
// 		struct ref_key
// 		{
// 			std::size_t operator()(const docPtr& key)const
// 			{
// 				std::size_t seed = 0;
// 				boost::hash_combine(seed, boost::hash_value(key));
// 				return seed;
// 			}
// 		};
	}
	class qValue
	{
		BOOSTSHAREPTR(rapidjson::Document, docPtr);
		docPtr doc;
		boost::unordered_set<docPtr> refList;
	public:
		inline qValue& This() { return *this; }
		qValue(const qJson::TYPE type = qJson::qj_array)
		{
			refList.clear();
			doc = Creator<rapidjson::Document>::Create();
			if (type == qJson::qj_object)doc->SetObject();
			else if (type == qJson::qj_array)doc->SetArray();
			else doc->SetNull();
		}
		qValue(const char* Ch)
		{
			refList.clear();
			doc = Creator<rapidjson::Document>::Create();
			doc->Parse(Ch);
		}
		qValue(const qValue& other)
		{
			refList.clear();
			this->doc = other.doc;
			this->refList = other.refList;
		}
		qValue Copy();
		~qValue(){}
		bool isEmpty()
		{
			if (doc->IsObject())return doc->ObjectEmpty();
			if (doc->IsArray())return doc->Empty();
			if (doc->IsNull())return true;
			return false;
		}
		inline bool isNull()
		{
			return doc->IsNull();
		}
		void toObject()
		{
			doc = Creator<rapidjson::Document>::Create();
			doc->SetObject();
			refList.clear();
		}
		void toArray()
		{
			doc = Creator<rapidjson::Document>::Create();
			doc->SetArray();
			refList.clear();
		}
		void toNull()
		{
			doc->SetNull();
			refList.clear();
		}
		qValue& append(const long long int value)
		{
			doc->PushBack((int64_t)value, doc->GetAllocator());
			return *this;
		}
		qValue& append(const unsigned value)
		{
			doc->PushBack(value, doc->GetAllocator());
			return *this;
		}
		qValue& append(const int value)
		{
			doc->PushBack(value, doc->GetAllocator());
			return *this;
		}
		qValue& append(const double value)
		{
			doc->PushBack(value, doc->GetAllocator());
			return *this;
		}
		qValue& append(const bool value)
		{
			doc->PushBack(value, doc->GetAllocator());
			return *this;
		}
		qValue& append(const string& value)
		{
			rapidjson::Value rVal(value.c_str(), value.length(), doc->GetAllocator());
			doc->PushBack(rVal, doc->GetAllocator());
			return *this;
		}
		qValue& append(const qValue& value, const bool keep_old = false)
		{
			if (keep_old)
			{
				rapidjson::Value rVal(value.doc->GetType());
				rVal.CopyFrom(*value.doc, doc->GetAllocator());
				doc->PushBack(rVal, doc->GetAllocator());
				return *this;
			}
			doc->PushBack(*value.doc, doc->GetAllocator());
			if (doc != value.doc)refList.insert(value.doc);
			refList.insert(value.refList.begin(), value.refList.end());
			return *this;
		}
		template<typename T>
		qValue& operator<<(const T& t)
		{
			return append(t);
		}
		qValue& addMember(const string& key, const qValue& value, const bool keep_old = false)
		{
			if (keep_old)
			{
				rapidjson::Value rKey(key.c_str(), key.length(), doc->GetAllocator());
				rapidjson::Value rVal(value.doc->GetType());
				rVal.CopyFrom(*value.doc, doc->GetAllocator());
				doc->AddMember(rKey, rVal, doc->GetAllocator());
				return *this;
			}
			rapidjson::Value rKey(key.c_str(), key.length(), doc->GetAllocator());
			doc->AddMember(rKey, *value.doc, doc->GetAllocator());
			if (doc != value.doc)refList.insert(value.doc);
			refList.insert(value.refList.begin(), value.refList.end());
			return *this;

		}
		qValue& addMember(const string& key, const string& value)
		{
			rapidjson::Value rKey(key.c_str(), key.length(), doc->GetAllocator());
			rapidjson::Value rVal(value.c_str(), value.length(), doc->GetAllocator());
			doc->AddMember(rKey, rVal, doc->GetAllocator());
			return *this;
		}
		qValue& addMember(const string& key, const long long int value)
		{
			rapidjson::Value rKey(key.c_str(), key.length(), doc->GetAllocator());
			doc->AddMember(rKey, (int64_t)value, doc->GetAllocator());
			return *this;
		}
		qValue& addMember(const string& key, const unsigned value)
		{
			rapidjson::Value rKey(key.c_str(), key.length(), doc->GetAllocator());
			doc->AddMember(rKey, value, doc->GetAllocator());
			return *this;
		}
		qValue& addMember(const string& key, const int value)
		{
			rapidjson::Value rKey(key.c_str(), key.length(), doc->GetAllocator());
			doc->AddMember(rKey, value, doc->GetAllocator());
			return *this;
		}
		qValue& addMember(const string& key, const double value)
		{
			rapidjson::Value rKey(key.c_str(), key.length(), doc->GetAllocator());
			doc->AddMember(rKey, value, doc->GetAllocator());
			return *this;
		}
		qValue& addMember(const string& key, const bool value)
		{
			rapidjson::Value rKey(key.c_str(), key.length(), doc->GetAllocator());
			doc->AddMember(rKey, value, doc->GetAllocator());
			return *this;
		}
		bool removeMember(const string& key)
		{
			return doc->RemoveMember(key.c_str());
		}
		std::string toIndentString()
		{
			rapidjson::StringBuffer buffer;
			rapidjson::Writer<rapidjson::StringBuffer> writer(buffer);
			doc->Accept(writer);
			return buffer.GetString();
		}
	};
}

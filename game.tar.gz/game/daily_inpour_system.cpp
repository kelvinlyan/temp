#include "daily_inpour_system.h"
#include "utility_lx.h"

//#define ITEM_A 0u
//#define ITEM_B 1u
//#define ITEM_C 2u
//#define X 0U
//#define XX 1U
//
//#define GET_NEED(config,group,x) \
//	config[group][x][1u].jsonBox[0u][1u].asInt()
//#define GET_COIN(config,group) \
//	config[group][1u][1u].jsonBox[1u][1u].asInt()
//#define GET_BOX(config,group,x) \
//	config[group][x][0u].box
//#define GET_PRODUCT(config,group,x) \
//	config[group][x][0u].jsonBox
//#define GET_PRICE(config,group,x) \
//	config[group][x][1u].jsonBox
//#define GET_PRODUCT_LOG(config,group,x) \
//	config[group][x][0u].strBox
//#define GET_PRICE_LOG(config,group,x) \
//	config[group][x][1u].strBox

const static std::string strID = "id";
const static std::string strBegin = "begin";
const static std::string strEnd = "end";
const static std::string strRmb = "rmb";
const static std::string strAccu = "accu";
const static std::string strBox = "box";
const static std::string strSingleList = "single";
const static std::string strBoxList = "box";
const static std::string strFlag = "flag";
const static std::string strVersion = "vs";

const static int iVersion = 2;

namespace gg
{
	static DailyInpourList daily_inpour_config;
	daily_inpour_system* const daily_inpour_system::_Instance = new daily_inpour_system();

	namespace daily_inpour
	{
		//�����ۿ۲��������
		static Json::Value toOrder(Json::Value value)
		{
			if (value.size() == 1)
			{
				return value;
			}
			Json::Value ret = Json::arrayValue;
			Json::Value discount;
			int j = 0;
			bool flag = false;
			for (int i = 0; i < value.size(); ++i)
			{
				if (value[i]["aID"].asInt() == ACTION::recharge_coin)
				{
					discount = value[i];
					flag = true;
				}
				else
				{
					ret[j++] = value[i];
				}
			}
			if (flag)
			{
				ret[j] = discount;
			}
			return ret;
		}

		//����������±�
		static int getDayIndex(int day, const std::vector<int>& days)
		{
			for (int i = 0; i < days.size() - 1; ++i)
			{
				if (day >= days[i] && day < days[i + 1])
				{
					return i;
				}
			}
			return days.size() - 1;
		}

		static int getDays(const int& begin)
		{
			unsigned now = Common::gameTime();
			unsigned s_begin = Common::getNextTimeHMS(begin, 5) - DAY;//ȡ�û��ʼ����5��ʱ��
			if (now > s_begin)
			{
				return (now - s_begin) / DAY;
			}
			else
			{
				return 0;
			}
		}

		//stime��etimeʹ�õ�����Ӧʱ����ʱ��
		static bool isDaysEqual(int total_day, unsigned stime, unsigned etime)
		{
			if (stime >= etime)
			{
				return false;
			}
			/*int count = (etime - stime) / DAY;
			int r = (etime - stime) % DAY;
			if (r != 0)
			{
				++count;
			}*/
			//��������һ���汾�Ĵ���
			stime = stime == 0 ? 0 : Common::toLocalTime(stime);
			etime = etime == 0 ? 0 : Common::toLocalTime(etime);
			int next = Common::getNextTimeHMS(stime, 5);
			int count = 0;
			while (next < etime)
			{
				++count;
				next = Common::getNextTimeHMS(next, 5);
			}
			++count;
			LogS << "daily inpour\tdays:" << total_day << "\tcount:" << count << LogEnd;
			return count == total_day;
		}

		static int getTotalDay(unsigned stime, unsigned etime)
		{
			unsigned begin = stime == 0 ? 0 : Common::toStampTime(stime);
			unsigned end = etime == 0 ? 0 : Common::toStampTime(etime);
			if (begin >= end)
			{
				return 0;
			}

			unsigned s_begin = Common::getNextTimeHMS(begin, 5) - DAY;
			unsigned s_end = Common::getNextTimeHMS(end, 5) - DAY;
			int count = (s_end - s_begin) / DAY;
			++count;
			return count;
		}

		static bool is_time_overlap(const DailyInpourActivity& acti_e, const DailyInpourActivity& acti_l)
		{
			if (acti_e.begin <= acti_l.begin && acti_e.end >= acti_l.begin ||
				acti_e.begin >= acti_l.begin && acti_e.end <= acti_l.end ||
				acti_e.begin <= acti_l.end && acti_e.end >= acti_l.end ||
				acti_e.begin <= acti_l.begin && acti_e.end >= acti_l.end)
			{
				return true;
			}
			return false;
		}
		
		static int validateAndParse(Json::Value msg, DailyInpourActivity& r_acti)
		{
			int id = msg[1u].asInt();
			Json::Value singles_json = msg[2u];
			Json::Value accu_json = msg[3u];
			///������֤��ʼ
			if (!daily_inpour::isDaysEqual(singles_json.size(), msg[4u].asUInt(), msg[5u].asUInt()))
			{
				return err_daily_inpour_day_reward_inequal;
			}
			bool is_valid;
			for (int i = 0; i < singles_json.size(); ++i)
			{
				Json::Value& single_json = singles_json[i];
				is_valid = true;
				if (single_json.size() > 0 && single_json[0]["id"].asInt() != 1)
				{
					return err_invalid_resp_data;
				}
				for (int j = 0; j < single_json.size() - 1; ++j)
				{
					if (single_json[j]["id"].asInt() - single_json[j + 1]["id"].asInt() != -1
						|| single_json[j]["gold"].asInt() > single_json[j + 1]["gold"].asInt())
					{
						is_valid = false;
						break;
					}
				}
				if (!is_valid)
				{
					return err_invalid_resp_data;
				}
			}
			is_valid = true;
			if (accu_json.size() > 0 && accu_json[0]["id"].asInt() != 1)
			{
				return err_invalid_resp_data;
			}
			for (int j = 0; j < accu_json.size() - 1; ++j)
			{
				if (accu_json[j]["id"].asInt() - accu_json[j + 1]["id"].asInt() != -1
					|| accu_json[j]["accu"].asInt() > accu_json[j + 1]["accu"].asInt())
				{
					is_valid = false;
					break;
				}
			}
			if (!is_valid)
			{
				return err_invalid_resp_data;
			}
			if (msg[4u].asUInt() >= msg[5u].asUInt())
			{
				return err_time_data_invalid;
			}
			///������֤����
			daily_inpour::InpourBoxList box_list;
			daily_inpour::InpourSingleSet box_single_set;
			for (int i = 0; i < singles_json.size(); ++i)
			{
				Json::Value& single_json = singles_json[i];
				daily_inpour::InpourSingleList single_list;
				for (int i = 0; i < single_json.size(); ++i)
				{
					daily_inpour::InpourSingle single;
					single.id = single_json[i]["id"].asInt();
					single.gold = single_json[i]["gold"].asInt();
					single.accu = single_json[i]["accu"].asInt();
					single.box.rawBox = single_json[i]["box"];
					single.box.load();
					single_list[single.id] = single;
				}
				box_single_set.push_back(single_list);
			}
			for (int i = 0; i < accu_json.size(); ++i)
			{
				daily_inpour::InpourBox single;
				single.id = accu_json[i]["id"].asInt();
				single.accu = accu_json[i]["accu"].asInt();
				single.box.rawBox = accu_json[i]["box"];
				single.box.load();
				box_list[single.id] = single;
			}
			r_acti.id = id;
			r_acti.single_set = box_single_set;
			r_acti.box_list = box_list;
			r_acti.begin = msg[4u].asUInt() == 0 ? 0 : Common::toLocalTime(msg[4u].asUInt());
			r_acti.end = msg[5u].asUInt() == 0 ? 0 : Common::toLocalTime(msg[5u].asUInt());

			return 0;//success
		}
		
		static void import(Json::Value& json)
		{
			DailyInpourActivity acti;
			//Json::Value msg = json["msg"];
			int retval = validateAndParse(json, acti);
			if (retval == 0)
			{
				daily_inpour_config[acti.id] = acti;
				daily_inpour_sys.saveData(acti.id);
				daily_inpour_config.erase(acti.id);
			}
		}
}
	
	void daily_inpour_system::timeData(Json::Value& json)
	{
		//temp 
		//json.append(0 == begin ? 0 : Common::toStampTime(begin));
		//json.append(0 == end ?  0 : Common::toStampTime(end));
		unsigned now = Common::gameTime();
		bool insert_flag = false;
		for (DailyInpourList::iterator it = daily_inpour_config.begin();
			it != daily_inpour_config.end();
			++it)
		{
			if (it->second.id != -1
				&& it->second.flag == 1
				&& it->second.begin <= now
				&& it->second.end >= now)
			{
				insert_flag = true;
				json.append(0 == it->second.begin ? 0 : Common::toStampTime(it->second.begin));
				json.append(0 == it->second.end ? 0 : Common::toStampTime(it->second.end));
				break;
			}
		}
		if (false == insert_flag)
		{
			json.append(0);
			json.append(0);
		}
	}
	
	daily_inpour_system::daily_inpour_system()
	{
		_curr.id = -1;
	}


	void daily_inpour_system::ReChargePlayerRecord(playerDataPtr player, int gold)
	{
		if (!player || gold < 0)
		{
			return;
		}

		unsigned now = Common::gameTime();
		if (_curr.id == -1 || now >= _curr.end || _curr.flag == 0)
		{
			select_active();
		}
		int ori_id = player->DailyInpour().getActId();
		if (ori_id != _curr.id)
		{
			player->DailyInpour().restart();
			player->DailyInpour().setActId(_curr.id);
		}
		if (_curr.id == -1 || now >= _curr.end || _curr.flag == 0)
		{
			return;
		}
		int days = daily_inpour::getDays(_curr.begin);
		if (days >= _curr.single_set.size())
		{
			return;
		}
		///======== _curr.single_set[days].begin();
		for (daily_inpour::InpourSingleList::iterator it = _curr.single_set[days].begin();
			it != _curr.single_set[days].end();
			++it)
		{
			if (gold == it->second.gold)
			{
				player->DailyInpour().addAcc(it->first, it->second.accu);
				//���ӿ�����ȡ�Ľ��������γ�ֵ�
				InpourList daily_record = player->DailyInpour().getDailyRecord();
				if (std::find(daily_record.begin(), daily_record.end(), it->first) == daily_record.end())
				{
					if (!player->DailyInpour().isExistBox(1, it->first))
					{
						Log(DBLOG::strLogDailyInpour, player, 5, it->second.accu, gold);
					}
					player->DailyInpour().addDailyBox(it->first, it->second.box.jsonBox);
					player->DailyInpour().addDailyAccessRecord(it->first);//���ӿ���ȡ��ID
				}
				break;
			}
		}
		//
		int total_accu = player->DailyInpour().getAcc();
		InpourList box_records = player->DailyInpour().getBoxRecord();//��ȡ��¼
		for (daily_inpour::InpourBoxList::iterator it = _curr.box_list.begin();
			it != _curr.box_list.end();
			++it)
		{
			if (total_accu >= it->second.accu)
			{
				if (std::find(box_records.begin(), box_records.end(), it->first) != box_records.end())
				{
					continue;
				}
				player->DailyInpour().addAccuBox(it->first, it->second.box.jsonBox);
				player->DailyInpour().addBoxAccessRecord(it->first);
			}
		}

	}

	void daily_inpour_system::reqDailyInpourInfo(net::Msg& m, Json::Value& r)
	{
		playerDataPtr player = player_mgr.getPlayer(m.playerID);
		if (!player)Return(r, err_illedge);

		///�����µĻ��
		unsigned now = Common::gameTime();
		if (_curr.id == -1 || now >= _curr.end || _curr.flag == 0)
		{
			select_active();
		}
		int ori_id = player->DailyInpour().getActId();
		if (ori_id != _curr.id)
		{
			player->DailyInpour().restart();
			player->DailyInpour().setActId(_curr.id);
		}

		if (_curr.id == -1 || _curr.flag == 0 || now > _curr.end)
		{
			Return(r, err_beyond_range);
		}

		r[strMsg][0u] = 0;
		updateInfo();

		Json::Value accu_box_json = Json::nullValue;
		Json::Value single_inpour_box_json = Json::nullValue;
		//
		int acc = player->DailyInpour().getAcc();
		accu_box_json["cumsum"] = acc;
		accu_box_json["accu"] = _info.box_accu_list;
		accu_box_json["boxes"] = _info.box_boxes_list;
		accu_box_json["flags"] = _info.box_flag_list;

		InpourList box_list = player->DailyInpour().getBoxRecord();
		InpourList box_access = player->DailyInpour().getBoxAccess();
		for (int i = 0; i < box_access.size(); ++i)
		{
			accu_box_json["flags"][box_access[i] - 1] = 2;
		}
		for (int i = 0; i < box_list.size(); ++i)
		{
			accu_box_json["flags"][box_list[i] - 1] = 1;
		}
		single_inpour_box_json["gold"] = _info.single_gold_list;
		single_inpour_box_json["accu"] = _info.single_accu_list;
		single_inpour_box_json["boxes"] = _info.single_boxes_list;
		single_inpour_box_json["flags"] = _info.single_flag_list;

		InpourList daily_box_access = player->DailyInpour().getDailyAccess();
		InpourList daily_box_list = player->DailyInpour().getDailyRecord();
		for (int i = 0; i < daily_box_access.size(); ++i)
		{
			single_inpour_box_json["flags"][daily_box_access[i] - 1] = 2;
		}
		for (int i = 0; i < daily_box_list.size(); ++i)
		{
			single_inpour_box_json["flags"][daily_box_list[i] - 1] = 1;
		}

		r[strMsg][1u] = accu_box_json;
		r[strMsg][2u] = single_inpour_box_json;
		r[strMsg][3u] = _curr.begin == 0 ? 0 : Common::toStampTime(_curr.begin);
		r[strMsg][4u] = _curr.end == 0 ? 0 : Common::toStampTime(_curr.end);
	}

	void daily_inpour_system::reqDailyInpourGetReward(net::Msg& m, Json::Value& r)
	{
		playerDataPtr player = player_mgr.getPlayer(m.playerID);
		if (!player)Return(r, err_illedge);

		if (player->DailyInpour().isLock())
		{//�����������ò���
			Return(r, err_action_is_not_allowed);//�ý���������ȡ
		}

		ReadJsonArray;
		int type = js_msg[0u].asInt();
		int flag = js_msg[1u].asInt();
		updateInfo();
		if (type == 1) //�ۻ����ֱ�����ȡ
		{
			daily_inpour::InpourBoxList::iterator it = _curr.box_list.begin();
			for (;it != _curr.box_list.end(); ++it)
			{
				if (flag == it->second.accu)
				{
					break;
				}
			}
			if (it == _curr.box_list.end())
			{
				Return(r, err_invalid_resp_data);
			}
			InpourList accesses = player->DailyInpour().getBoxAccess();
			if (std::find(accesses.begin(), accesses.end(), it->first) == accesses.end())
			{
				Return(r, err_action_is_not_allowed);//�ý���������ȡ
			}
			InpourList exists = player->DailyInpour().getBoxRecord();
			if (std::find(exists.begin(), exists.end(), it->first) != exists.end())
			{
				Return(r, err_fund_has_gotten);
			}
			//ִ���콱
			int ret = actionDoBox(player, it->second.box.box, false);
			r[strMsg][0u] = ret;
			if (ret == 0)
			{
				r[strMsg][1u] = actionRes();
				//���ݸ���
				//LogS << "add accu reward record." << LogEnd;
				player->DailyInpour().addBoxRecord(it->first);
				//LogS << "ready to delete accu reward box." << LogEnd;
				player->DailyInpour().delAccuBox(it->first);
				Log(DBLOG::strLogDailyInpour, player, 3, it->second.box.strBox, it->second.accu);
			}
			else
			{
				r[strMsg][1u] = actionError();
			}
		}
		else if (type == 3) //���ʳ�ֵ������ȡ
		{
			int days = daily_inpour::getDays(_curr.begin);
			if (days >= _curr.single_set.size())
			{
				Return(r, err_action_is_not_allowed);
			}
			daily_inpour::InpourSingleList::iterator it = _curr.single_set[days].begin();
			for (;it != _curr.single_set[days].end(); ++it)
			{
				if (flag == it->second.gold)
				{
					break;
				}
			}
			if (it == _curr.single_set[days].end())
			{
				//�Ҳ�����flag��ͬ��it->second.gold
				Return(r, err_invalid_resp_data);
			}
			InpourList accesses = player->DailyInpour().getDailyAccess();
			if (std::find(accesses.begin(), accesses.end(), it->first) == accesses.end())
			{
				Return(r, err_action_is_not_allowed);//�ý���������ȡ
			}
			InpourList exists = player->DailyInpour().getDailyRecord();
			if (std::find(exists.begin(), exists.end(), it->first) != exists.end())
			{
				Return(r, err_fund_has_gotten);
			}
			//ִ���콱
			int ret = actionDoBox(player, it->second.box.box, false);
			r[strMsg][0u] = ret;
			if (ret == 0)
			{
				r[strMsg][1u] = actionRes();
				//���ݸ���
				player->DailyInpour().addDailyRecord(it->first);
				player->DailyInpour().delDailyBox(it->first);
				Log(DBLOG::strLogDailyInpour, player, 2, it->second.box.strBox, it->second.gold);
			}
			else
			{
				r[strMsg][1u] = actionError();
			}
		}
		else
		{
			Return(r, err_invalid_resp_data);
		}
		
	}

	void daily_inpour_system::reqDailyInpourShopReflesh(net::Msg& m, Json::Value& r)
	{
		/*
		playerDataPtr player = player_mgr.getPlayer(m.playerID);
		if (!player)Return(r, err_illedge);

		ReadJsonArray;//0�������ݣ�1Ϊˢ��
		int type = js_msg[0u].asInt();
		if (type < 0 || type > 1)
		{
			Return(r, err_invalid_resp_data);
		}
		*/
		//
		/*
		*��һ�Σ����ݻ�û�г�ʼ����
		*/
		/*
		std::vector<int> items = player->DailyInpour().getShopItem();
		int reflesh = player->DailyInpour().getReflesh();
		if (type == 1 && reflesh >= 5)
		{
			Return(r, err_action_is_not_allowed);
		}
		int player_day = player->DailyInpour().getDay();
		int curr_real_day = getDayTh(shop_config->days);
		int day_idx;
		if (player_day == curr_real_day)
		{
			day_idx = daily_inpour::getDayIndex(player_day, shop_config->days);
		}
		else
		{
			day_idx = daily_inpour::getDayIndex(curr_real_day, shop_config->days);
			player->DailyInpour().setDay(curr_real_day);
			//������Ҫˢ����
			items[0u] = INVALID_DATA;
		}
		if (items[0u] == INVALID_DATA)
		{
			type = 1;//����ִ��ǿˢ��
		}
		if (type == 1)
		{
			//ִ��ˢ��
			if (items[0u] != INVALID_DATA)
			{
				player->DailyInpour().addReflesh(1);
			}
			player->DailyInpour().resetShop();
			int target_a = lx::utility_lx::getProbIndex(shop_config->day_shop[day_idx].odds_a, shop_config->day_shop[day_idx].odds_a.back());
			int target_b = lx::utility_lx::getProbIndex(shop_config->day_shop[day_idx].odds_b, shop_config->day_shop[day_idx].odds_b.back());
			int target_c = lx::utility_lx::getProbIndex(shop_config->day_shop[day_idx].odds_c, shop_config->day_shop[day_idx].odds_c.back());
			player->DailyInpour().setShopItem(ITEM_A, target_a);
			player->DailyInpour().setShopItem(ITEM_B, target_b);
			player->DailyInpour().setShopItem(ITEM_C, target_c);
		}

		//�����������Ҫ�����ݶ�����Ч��
		items = player->DailyInpour().getShopItem();
		reflesh = player->DailyInpour().getReflesh();
		Json::Value ret = Json::arrayValue;
		unsigned idx = 0u;
		Json::Value A = Json::arrayValue;
		Json::Value AA = Json::arrayValue;
		Json::Value B = Json::arrayValue;
		Json::Value BB = Json::arrayValue;
		Json::Value C = Json::arrayValue;
		Json::Value CC = Json::arrayValue;

		A[0U] = GET_PRODUCT(shop_config->day_shop[day_idx].stuff_a, items[ITEM_A], X);
		A[1U] = GET_PRICE(shop_config->day_shop[day_idx].stuff_a, items[ITEM_A], X);
		AA[0U] = GET_PRODUCT(shop_config->day_shop[day_idx].stuff_a, items[ITEM_A], XX);
		AA[1U] = GET_PRICE(shop_config->day_shop[day_idx].stuff_a, items[ITEM_A], XX);

		B[0U] = GET_PRODUCT(shop_config->day_shop[day_idx].stuff_b, items[ITEM_B], X);
		B[1U] = GET_PRICE(shop_config->day_shop[day_idx].stuff_b, items[ITEM_B], X);
		BB[0U] = GET_PRODUCT(shop_config->day_shop[day_idx].stuff_b, items[ITEM_B], XX);
		BB[1U] = GET_PRICE(shop_config->day_shop[day_idx].stuff_b, items[ITEM_B], XX);

		C[0U] = GET_PRODUCT(shop_config->day_shop[day_idx].stuff_c, items[ITEM_C], X);
		C[1U] = GET_PRICE(shop_config->day_shop[day_idx].stuff_c, items[ITEM_C], X);
		CC[0U] = GET_PRODUCT(shop_config->day_shop[day_idx].stuff_c, items[ITEM_C], XX);
		CC[1U] = GET_PRICE(shop_config->day_shop[day_idx].stuff_c, items[ITEM_C], XX);
		//ret[idx++] = 0;
		ret[idx++] = 5 - reflesh;//
		ret[idx++] = A;
		ret[idx++] = AA;
		ret[idx++] = B;
		ret[idx++] = BB;
		ret[idx++] = C;
		ret[idx++] = CC;
		std::vector<int> record = player->DailyInpour().getShopRecords();
		Json::Value record_json = Json::arrayValue;
		for (int i = 0; i < record.size(); ++i)
		{
			record_json[i] = (record[i]^1);
		}
		ret[idx] = record_json;
		r[strMsg][0u] = 0;
		r[strMsg][1u] = ret;
		*/
	}

	void daily_inpour_system::reqDailyInpourShopPurchase(net::Msg& m, Json::Value& r)
	{
		/*
		playerDataPtr player = player_mgr.getPlayer(m.playerID);
		if (!player)Return(r, err_illedge);

		ReadJsonArray;
		int flag = js_msg[0u].asInt();
		if (flag < 1 || flag > 6)
		{
			Return(r, err_invalid_resp_data);
		}
		std::vector<int> record = player->DailyInpour().getShopRecords();
		if (record[flag - 1] == 1)
		{
			Return(r, err_fund_has_gotten);
		}
		std::vector<int> item = player->DailyInpour().getShopItem();
		int cash = player->Res().getCash();
		int recharge_coin = player->Res().getRechargeCoin();
		int need, coin;
		ActionBoxList box;
		std::string strProduct("[]"), strPrice("[]");
		int player_day = player->DailyInpour().getDay();
		int day_idx = daily_inpour::getDayIndex(player_day, shop_config->days);
		if (flag == 1)
		{
			need = GET_NEED(shop_config->day_shop[day_idx].stuff_a, item[ITEM_A], X);
			box = GET_BOX(shop_config->day_shop[day_idx].stuff_a, item[ITEM_A], X);
			strProduct = GET_PRODUCT_LOG(shop_config->day_shop[day_idx].stuff_a, item[ITEM_A], X);
			strPrice = GET_PRICE_LOG(shop_config->day_shop[day_idx].stuff_a, item[ITEM_A], X);
		}
		else if (flag == 2)
		{
			need = GET_NEED(shop_config->day_shop[day_idx].stuff_a, item[ITEM_A], XX);
			coin = GET_COIN(shop_config->day_shop[day_idx].stuff_a, item[ITEM_A]);
			box = GET_BOX(shop_config->day_shop[day_idx].stuff_a, item[ITEM_A], XX);
			strProduct = GET_PRODUCT_LOG(shop_config->day_shop[day_idx].stuff_a, item[ITEM_A], XX);
			strPrice = GET_PRICE_LOG(shop_config->day_shop[day_idx].stuff_a, item[ITEM_A], XX);
		}
		else if (flag == 3)
		{
			need = GET_NEED(shop_config->day_shop[day_idx].stuff_b, item[ITEM_B], X);
			box = GET_BOX(shop_config->day_shop[day_idx].stuff_b, item[ITEM_B], X);
			strProduct = GET_PRODUCT_LOG(shop_config->day_shop[day_idx].stuff_b, item[ITEM_B], X);
			strPrice = GET_PRICE_LOG(shop_config->day_shop[day_idx].stuff_b, item[ITEM_B], X);
		}
		else if (flag == 4)
		{
			need = GET_NEED(shop_config->day_shop[day_idx].stuff_b, item[ITEM_B], XX);
			coin = GET_COIN(shop_config->day_shop[day_idx].stuff_b, item[ITEM_B]);
			box = GET_BOX(shop_config->day_shop[day_idx].stuff_b, item[ITEM_B], XX);
			strProduct = GET_PRODUCT_LOG(shop_config->day_shop[day_idx].stuff_b, item[ITEM_B], XX);
			strPrice = GET_PRICE_LOG(shop_config->day_shop[day_idx].stuff_b, item[ITEM_B], XX);
		}
		else if (flag == 5)
		{
			need = GET_NEED(shop_config->day_shop[day_idx].stuff_c, item[ITEM_C], X);
			box = GET_BOX(shop_config->day_shop[day_idx].stuff_c, item[ITEM_C], X);
			strProduct = GET_PRODUCT_LOG(shop_config->day_shop[day_idx].stuff_c, item[ITEM_C], X);
			strPrice = GET_PRICE_LOG(shop_config->day_shop[day_idx].stuff_c, item[ITEM_C], X);
		}
		else
		{
			need = GET_NEED(shop_config->day_shop[day_idx].stuff_c, item[ITEM_C], XX);
			coin = GET_COIN(shop_config->day_shop[day_idx].stuff_c, item[ITEM_C]);
			box = GET_BOX(shop_config->day_shop[day_idx].stuff_c, item[ITEM_C], XX);
			strProduct = GET_PRODUCT_LOG(shop_config->day_shop[day_idx].stuff_c, item[ITEM_C], XX);
			strPrice = GET_PRICE_LOG(shop_config->day_shop[day_idx].stuff_c, item[ITEM_C], XX);
		}

		if (need > cash)
		{
			Return(r, err_cash_not_enough);//Ԫ������
		}
		if ((flag == 2 || flag == 4 || flag == 6) && coin > recharge_coin)
		{
			Return(r, err_recharge_coin_not_enough);
		}
		if (flag == 2 || flag == 4 || flag == 6)
		{
			player->Res().alterRechargeCoin(-coin);
			player->Res().alterCash(-need);
		}
		else
		{
			player->Res().alterCash(-need);
		}

		//ִ����ȡ
		int ret = actionDoBox(player, box, false);
		r[strMsg][0u] = ret;
		if (ret == 0)
		{
			r[strMsg][1u] = actionRes();
			player->DailyInpour().setShopRecords(flag - 1);
			Log(DBLOG::strLogDailyInpour, player, 4, strProduct, strPrice);
		}
		else
		{
			r[strMsg][1u] = actionError();
		}
		*/

	}

	void daily_inpour_system::reqRedPoint(net::Msg& m, Json::Value& r)
	{
		playerDataPtr player = player_mgr.getPlayer(m.playerID);
		if (!player)Return(r, err_illedge);

		///�����µĻ��
		unsigned now = Common::gameTime();
		if (_curr.id == -1 || now >= _curr.end || _curr.flag == 0)
		{
			select_active();
		}
		int ori_id = player->DailyInpour().getActId();
		if (ori_id != _curr.id)
		{
			player->DailyInpour().restart();
			player->DailyInpour().setActId(_curr.id);
		}
		///�����µĻ��

		if (_curr.id == -1 || now > _curr.end || _curr.flag == 0)
		{
			r[strMsg][0] = 0;
			r[strMsg][1] = 2;
			return;//������뷵��
		}

		player->DailyInpour()._auto_update();
	}

	void daily_inpour_system::getDailyInpourIdList(net::Msg& m, Json::Value& r)
	{
		select_active();
		Json::Value ret = Json::arrayValue;
		r[strMsg][0u] = _curr.id;
		int i = 0;
		for (DailyInpourList::iterator it = daily_inpour_config.begin();
			it != daily_inpour_config.end();
			++it)
		{
			if (_curr.id != it->first)
			{
				ret[i++] = it->first;
			}
		}
		r[strMsg][1u] = ret;
		
	}

	void daily_inpour_system::getDailyInpourInfo(net::Msg& m, Json::Value& r)
	{
		ReadJsonArray;
		int id = js_msg[0u].asInt();
		DailyInpourList::iterator it = daily_inpour_config.find(id);
		if (it == daily_inpour_config.end())
		{
			Return(r, err_invalid_resp_data);
		}
		//Json::Value ret = Json::arrayValue;
		Json::Value single_jsons = Json::arrayValue;
		Json::Value accu_json = Json::arrayValue;
		r[strMsg][0u] = it->first;
		r[strMsg][1u] = it->second.flag;
		unsigned idx;
		for (int i = 0; i < it->second.single_set.size(); ++i)
		{
			Json::Value single_json = Json::arrayValue;
			idx = 0u;
			for (daily_inpour::InpourSingleList::iterator sit = it->second.single_set[i].begin();
				sit != it->second.single_set[i].end();
				++sit)
			{
				Json::Value single = Json::nullValue;
				single["id"] = sit->second.id;
				single["gold"] = sit->second.gold;
				single["accu"] = sit->second.accu;
				single["box"] = sit->second.box.rawBox;
				single_json[idx++] = single;
			}
			single_jsons.append(single_json);
		}
		idx = 0u;
		for (daily_inpour::InpourBoxList::iterator bit = it->second.box_list.begin();
			bit != it->second.box_list.end();
			++bit)
		{
			Json::Value single = Json::nullValue;
			single["id"] = bit->second.id;
			single["accu"] = bit->second.accu;
			single["box"] = bit->second.box.rawBox;
			accu_json[idx++] = single;
		}
		r[strMsg][2u] = single_jsons;
		r[strMsg][3u] = accu_json;
		r[strMsg][4u] = 0 == it->second.begin ? 0 : Common::toStampTime(it->second.begin);
		r[strMsg][5u] = 0 == it->second.end ? 0 : Common::toStampTime(it->second.end);
		//r[strMsg] = ret;
	}

	void daily_inpour_system::ModifyDailyInpour(net::Msg& m, Json::Value& r)
	{
		ReadJsonArray;
		int type = js_msg[0u].asInt();
		int id = js_msg[1u].asInt();
		//LogS << "DailyInpour" <<"\toperator:" << type << "\tid:" << id << LogEnd;
		if (id < 1)
		{
			Return(r, err_invalid_resp_data);
		}
		DailyInpourList::iterator it = daily_inpour_config.find(id);
		if (type == 0)
		{
			if (it == daily_inpour_config.end())
			{
				Return(r, err_invalid_resp_data);
			}
			else
			{
				//LogS << "close..." << "operator:" << type << "\tid:" << id << LogEnd;
				it->second.flag = 0;
				if (saveData(id))
				{
					r[strMsg][0u] = 0;
					r[strMsg][1u] = 0;
				}
				else
				{
					r[strMsg][0u] = 0;
					r[strMsg][1u] = 1;
				}
			}
			if (it->second.id == _curr.id)
			{
				Json::Value json;
				json[strMsg][0u] = 0;
				json[strMsg][1u] = 2;
				player_mgr.sendToAll(gate_client::daily_inpour_get_red_point_resp, json);
			}

		}
		else if (type == 1)
		{
			if (it == daily_inpour_config.end())
			{
				Return(r, err_invalid_resp_data);
			}
			else
			{
				//LogS << "restart..."<< "operator:" << type << "\tid:" << id << LogEnd;
				it->second.flag = 1;
				if (saveData(id))
				{
					r[strMsg][0u] = 0;
					r[strMsg][1u] = 0;
				}
				else
				{
					r[strMsg][0u] = 0;
					r[strMsg][1u] = 1;
				}
			}
		}
		else if (type == 2)
		{
			daily_inpour::DailyInpourActivity new_acti;
			int retval = daily_inpour::validateAndParse(js_msg, new_acti);
			if (retval != 0)
			{
				Return(r, retval);
			}
			daily_inpour_config[new_acti.id] = new_acti;
			Timer::AddEventTickTime(boostBind(daily_inpour_system::ActivityOver, _1), Inter::event_activity_over, new_acti.end);
			if (_curr.id != -1 && _curr.id != id && daily_inpour::is_time_overlap(new_acti, _curr))
			{
				//����ԭ���Ļ����Ҫɾ����ǰ�Ļ
				delData(_curr.id);
				daily_inpour_config.erase(_curr.id);
			}
			if (daily_inpour_sys.saveData(new_acti.id))
			{
				r[strMsg][0u] = 0;
				r[strMsg][1u] = 0;
			}
			else
			{
				r[strMsg][0u] = 0;
				r[strMsg][1u] = 1;
			}

			/*
			Json::Value singles_json = js_msg[2u];
			Json::Value accu_json = js_msg[3u];
			//LogS << "DailyInpour" << "\tsingle:" << single_json.toIndentString() << "\taccu:" << accu_json.toIndentString() << LogEnd;
			///������֤��ʼ
			if (!daily_inpour::isDaysEqual(singles_json.size(), js_msg[4u].asUInt(), js_msg[5u].asUInt()))
			{
				Return(r, err_daily_inpour_day_reward_inequal);
			}
			bool is_valid;
			for (int i = 0; i < singles_json.size(); ++i)
			{
				Json::Value& single_json = singles_json[i];
				is_valid = true;
				if (single_json.size() > 0 && single_json[0]["id"].asInt() != 1)
				{
					Return(r, err_invalid_resp_data);
				}
				for (int j = 0; j < single_json.size() - 1; ++j)
				{
					if (single_json[j]["id"].asInt() - single_json[j + 1]["id"].asInt() != -1
						|| single_json[j]["gold"].asInt() > single_json[j + 1]["gold"].asInt())
					{
						is_valid = false;
						break;
					}
				}
				if (!is_valid)
				{
					Return(r, err_invalid_resp_data);
				}
			}
			is_valid = true;
			if (accu_json.size() > 0 && accu_json[0]["id"].asInt() != 1)
			{
				Return(r, err_invalid_resp_data);
			}
			for (int j = 0; j < accu_json.size() - 1; ++j)
			{
				if (accu_json[j]["id"].asInt() - accu_json[j + 1]["id"].asInt() != -1
					|| accu_json[j]["accu"].asInt() > accu_json[j + 1]["accu"].asInt())
				{
					is_valid = false;
					break;
				}
			}
			if (!is_valid)
			{
				Return(r, err_invalid_resp_data);
			}
			if (js_msg[4u].asUInt() >= js_msg[5u].asUInt())
			{
				Return(r, err_time_data_invalid);
			}
			///������֤����
			LogS << "DailyInpour" << "\tvalidation end and begin to insert new activity." << LogEnd;
			daily_inpour::InpourBoxList box_list;
			daily_inpour::InpourSingleSet box_single_set;
			for (int i = 0; i < singles_json.size(); ++i)
			{
				Json::Value& single_json = singles_json[i];
				daily_inpour::InpourSingleList single_list;
				for (int i = 0; i < single_json.size(); ++i)
				{
					daily_inpour::InpourSingle single;
					single.id = single_json[i]["id"].asInt();
					single.gold = single_json[i]["gold"].asInt();
					single.accu = single_json[i]["accu"].asInt();
					single.box.rawBox = single_json[i]["box"];
					single.box.load();
					single_list[single.id] = single;
				}
				box_single_set.push_back(single_list);
			}
			for (int i = 0; i < accu_json.size(); ++i)
			{
				daily_inpour::InpourBox single;
				single.id = accu_json[i]["id"].asInt();
				single.accu = accu_json[i]["accu"].asInt();
				single.box.rawBox = accu_json[i]["box"];
				single.box.load();
				box_list[single.id] = single;
			}
			daily_inpour::DailyInpourActivity new_acti;
			new_acti.id = id;
			new_acti.single_set = box_single_set;
			new_acti.box_list = box_list;
			new_acti.begin = js_msg[4u].asUInt() == 0 ? 0 : Common::toLocalTime(js_msg[4u].asUInt());
			new_acti.end = js_msg[5u].asUInt() == 0 ? 0 : Common::toLocalTime(js_msg[5u].asUInt());
			daily_inpour_config[id] = new_acti;
			Timer::AddEventTickTime(boostBind(daily_inpour_system::ActivityOver, _1), Inter::event_activity_over, new_acti.end);
			if (_curr.id != -1 && _curr.id != id && daily_inpour::is_time_overlap(new_acti, _curr))
			{
				//����ԭ���Ļ����Ҫɾ����ǰ�Ļ
				delData(_curr.id);
				daily_inpour_config.erase(_curr.id);
			}
			if (saveData(id))
			{
				r[strMsg][0u] = 0;
				r[strMsg][1u] = 0;
			}
			else
			{
				r[strMsg][0u] = 0;
				r[strMsg][1u] = 1;
			}
			*/
		}
		else
		{
			Return(r, err_invalid_resp_data);
		}
		select_active();
	}

	void daily_inpour_system::ActivityOver(const structTimer& timerData)
	{
		Json::Value json;
		json[strMsg][0u] = 0;
		json[strMsg][1u] = 2;
		player_mgr.sendToAll(gate_client::daily_inpour_get_red_point_resp, json);
	}

	void daily_inpour_system::initData()
	{
		//test
		/*Json::Value test_left = Common::string2json("[[24,10],[5,10000],[6,10000],[7,10000],[1,10000]]");
		Json::Value test_right = Common::string2json("[[12,40700,20],[16,1000],[9,1000],[14,1001,1]]");
		Json::Value com = lx::utility_lx::combineArrayBox(test_left, test_right);
		std::string test_str = com.toIndentString();*/
		/*
		std::cout << "load ./daily_inpour/rewards.json START	" << std::endl;
		
		Json::Value value = Common::loadJsonFile(std::string("./instance/daily_inpour/rewards.json"));

		inpour_config = Creator<daily_inpour::InpourConfig>::Create();
		shop_config = Creator<daily_inpour::InpourShopConfig>::Create();

		inpour_config->weekendBox.box = actionFormatBox(value["rnd_box"]);
		inpour_config->weekendBox.jsonBox = parseJson(value["rnd_box"]);
		inpour_config->weekendBox.strBox = parseJsonBox(value["rnd_box"]);
		Json::Value accu_json = value["accu"];
		inpour_config->accuListJson = accu_json;//
		inpour_config->zeroAccuListJson = Json::arrayValue;//
		for (int i = 0; i < accu_json.size(); ++i)
		{
			inpour_config->accuList.push_back(accu_json[i].asInt());
			inpour_config->zeroAccuListJson[i] = 0;//
		}

		Json::Value boxes_json = value["boxes"];
		inpour_config->accuBoxesJson = Json::arrayValue;//
		for (int i = 0; i < boxes_json.size(); ++i)
		{
			daily_inpour::BoxSingle single;
			single.box = actionFormatBox(boxes_json[i]);
			single.jsonBox = parseJson(boxes_json[i]);
			single.strBox = parseJsonBox(boxes_json[i]);
			inpour_config->accuBoxesJson[i] = single.jsonBox;//
			inpour_config->accuBoxes.push_back(single);
		}
		*/
		/*test-*/
		/*Json::Value test_boxes_json = value["test_box"];
		Json::Value left = parseJson(test_boxes_json[0]);
		Json::Value right = parseJson(test_boxes_json[1]);
		Json::Value str = lx::utility_lx::combineArrayBox(inpour_config->accuBoxes[0].jsonBox, inpour_config->accuBoxes[1].jsonBox);
		std::string s1 = str.toIndentString();
		Json::Value str2 = lx::utility_lx::combineArrayBox(left, right);
		std::string s2 = str2.toIndentString();
		s2 = "";*/
		/*Json::Value test_box_json = Json::Value(std::string("[[2,100],[25,2]]"));
		LogS << test_box_json.size() << "\t" << test_box_json.toIndentString() << LogEnd;
		test_box_json = Json::Value(Common::string2json("[[2,100],[25,2]]"));
		LogS << test_box_json.size() << "\t" << test_box_json.toIndentString() << LogEnd;*/
		/*test-*/
		/*
		assert(inpour_config->accuList.size() == inpour_config->accuBoxes.size());

		Json::Value rewards_json = value["rewards"];
		inpour_config->cashListJson = Json::arrayValue;//
		inpour_config->cashAccuListJson = Json::arrayValue;
		for (int i = 0; i < rewards_json.size(); ++i)
		{
			inpour_config->cashList.push_back(rewards_json[i][0u].asInt());
			inpour_config->cashAccuList.push_back(rewards_json[i][1u].asInt());

			inpour_config->cashListJson[i] = rewards_json[i][0u].asInt();//
			inpour_config->cashAccuListJson[i] = rewards_json[i][1u].asInt();//
		}

		Json::Value s_boxes_json = value["s_boxes"];
		inpour_config->cashAccuBoxesJson = Json::arrayValue;//
		inpour_config->zeroCashAccJson = Json::arrayValue;//
		for (int i = 0; i < s_boxes_json.size(); ++i)
		{
			daily_inpour::BoxSingle single;
			single.box = actionFormatBox(s_boxes_json[i]);
			single.jsonBox = parseJson(s_boxes_json[i]);
			single.strBox = parseJsonBox(s_boxes_json[i]);
			inpour_config->cashAccuBoxes.push_back(single);
			inpour_config->cashAccuBoxesJson[i] = single.jsonBox;//
			inpour_config->zeroCashAccJson[i] = 0;//
		}

		assert(inpour_config->cashList.size() == inpour_config->cashAccuBoxes.size());
		
		std::cout << "load ./daily_inpour/rewards.json END	" << std::endl;
		*/
		/*
		std::cout << "load ./daily_inpour/shop.json START	" << std::endl;
		Json::Value shop = Common::loadJsonFile(std::string("./instance/daily_inpour/shop.json"));

		for (int j = 0; j < shop.size(); ++j)
		{
			daily_inpour::DayShopConfig day_config;
			Json::Value stuff_a_json = shop[j]["stuff_a"];
			Json::Value stuff_b_json = shop[j]["stuff_b"];
			Json::Value stuff_c_json = shop[j]["stuff_c"];
			day_config.odds_a.resize(stuff_a_json.size() + 1);
			day_config.odds_a[0] = 0;
			for (int i = 0; i < stuff_a_json.size(); ++i)
			{
				daily_inpour::GroupUnit g_unit;
				daily_inpour::ShopUnit unit_x;
				daily_inpour::BoxSingle single_get_x;
				daily_inpour::BoxSingle single_cost_x;
				single_get_x.box = actionFormatBox(stuff_a_json[i][0][0]);
				single_get_x.jsonBox = parseJson(stuff_a_json[i][0][0]);
				single_get_x.strBox = parseJsonBox(stuff_a_json[i][0][0]);
				single_cost_x.box = actionFormatBox(stuff_a_json[i][0][1]);
				single_cost_x.jsonBox = parseJson(stuff_a_json[i][0][1]);
				single_cost_x.strBox = parseJsonBox(stuff_a_json[i][0][1]);
				unit_x.push_back(single_get_x);
				unit_x.push_back(single_cost_x);

				daily_inpour::ShopUnit unit_xx;
				daily_inpour::BoxSingle single_get_xx;
				daily_inpour::BoxSingle single_cost_xx;
				single_get_xx.box = actionFormatBox(stuff_a_json[i][1][0]);
				single_get_xx.jsonBox = parseJson(stuff_a_json[i][1][0]);
				single_get_xx.strBox = parseJsonBox(stuff_a_json[i][1][0]);
				Json::Value axx = daily_inpour::toOrder(stuff_a_json[i][1][1]);
				single_cost_xx.box = actionFormatBox(axx);
				single_cost_xx.jsonBox = parseJson(axx);
				single_cost_xx.strBox = parseJsonBox(axx);
				unit_xx.push_back(single_get_xx);
				unit_xx.push_back(single_cost_xx);

				g_unit.push_back(unit_x);
				g_unit.push_back(unit_xx);

				day_config.stuff_a.push_back(g_unit);

				day_config.odds_a[i + 1] = stuff_a_json[i][2].asInt();
				day_config.odds_a[i + 1] += day_config.odds_a[i];
			}
			//assert(shop_config->odds_a.back() == 10000);

			day_config.odds_b.resize(stuff_b_json.size() + 1);
			day_config.odds_b[0] = 0;
			for (int i = 0; i < stuff_b_json.size(); ++i)
			{
				daily_inpour::GroupUnit g_unit;
				daily_inpour::ShopUnit unit_x;
				daily_inpour::BoxSingle single_get_x;
				daily_inpour::BoxSingle single_cost_x;
				single_get_x.box = actionFormatBox(stuff_b_json[i][0][0]);
				single_get_x.jsonBox = parseJson(stuff_b_json[i][0][0]);
				single_get_x.strBox = parseJsonBox(stuff_b_json[i][0][0]);
				single_cost_x.box = actionFormatBox(stuff_b_json[i][0][1]);
				single_cost_x.jsonBox = parseJson(stuff_b_json[i][0][1]);
				single_cost_x.strBox = parseJsonBox(stuff_b_json[i][0][1]);
				unit_x.push_back(single_get_x);
				unit_x.push_back(single_cost_x);

				daily_inpour::ShopUnit unit_xx;
				daily_inpour::BoxSingle single_get_xx;
				daily_inpour::BoxSingle single_cost_xx;
				single_get_xx.box = actionFormatBox(stuff_b_json[i][1][0]);
				single_get_xx.jsonBox = parseJson(stuff_b_json[i][1][0]);
				single_get_xx.strBox = parseJsonBox(stuff_b_json[i][1][0]);
				Json::Value bxx = daily_inpour::toOrder(stuff_b_json[i][1][1]);
				single_cost_xx.box = actionFormatBox(bxx);
				single_cost_xx.jsonBox = parseJson(bxx);
				single_cost_xx.strBox = parseJsonBox(bxx);
				unit_xx.push_back(single_get_xx);
				unit_xx.push_back(single_cost_xx);

				g_unit.push_back(unit_x);
				g_unit.push_back(unit_xx);

				day_config.stuff_b.push_back(g_unit);

				day_config.odds_b[i + 1] = stuff_b_json[i][2].asInt();
				day_config.odds_b[i + 1] += day_config.odds_b[i];
			}
			//assert(shop_config->odds_b.back() = 10000);

			day_config.odds_c.resize(stuff_c_json.size() + 1);
			day_config.odds_c[0] = 0;
			for (int i = 0; i < stuff_c_json.size(); ++i)
			{
				daily_inpour::GroupUnit g_unit;
				daily_inpour::ShopUnit unit_x;
				daily_inpour::BoxSingle single_get_x;
				daily_inpour::BoxSingle single_cost_x;
				single_get_x.box = actionFormatBox(stuff_c_json[i][0][0]);
				single_get_x.jsonBox = parseJson(stuff_c_json[i][0][0]);
				single_get_x.strBox = parseJsonBox(stuff_c_json[i][0][0]);
				single_cost_x.box = actionFormatBox(stuff_c_json[i][0][1]);
				single_cost_x.jsonBox = parseJson(stuff_c_json[i][0][1]);
				single_cost_x.strBox = parseJsonBox(stuff_c_json[i][0][1]);
				unit_x.push_back(single_get_x);
				unit_x.push_back(single_cost_x);

				daily_inpour::ShopUnit unit_xx;
				daily_inpour::BoxSingle single_get_xx;
				daily_inpour::BoxSingle single_cost_xx;
				single_get_xx.box = actionFormatBox(stuff_c_json[i][1][0]);
				single_get_xx.jsonBox = parseJson(stuff_c_json[i][1][0]);
				single_get_xx.strBox = parseJsonBox(stuff_c_json[i][1][0]);
				Json::Value cxx = daily_inpour::toOrder(stuff_c_json[i][1][1]);
				single_cost_xx.box = actionFormatBox(cxx);
				single_cost_xx.jsonBox = parseJson(cxx);
				single_cost_xx.strBox = parseJsonBox(cxx);
				unit_xx.push_back(single_get_xx);
				unit_xx.push_back(single_cost_xx);

				g_unit.push_back(unit_x);
				g_unit.push_back(unit_xx);

				day_config.stuff_c.push_back(g_unit);

				day_config.odds_c[i + 1] = stuff_c_json[i][2].asInt();
				day_config.odds_c[i + 1] += day_config.odds_c[i];
			}
			//assert(shop_config->odds_c.back() = 10000);
			shop_config->days.push_back(shop[j]["start"].asInt());
			shop_config->day_shop.push_back(day_config);

		}
		std::cout << "load ./daily_inpour/shop.json END	" << std::endl;
		*/
		
	}

	bool daily_inpour_system::saveData(int activity_id)
	{
		DailyInpourList::iterator it = daily_inpour_config.find(activity_id);
		if (it != daily_inpour_config.end())
		{
			mongo::BSONObj key = BSON(strID << it->first);

			mongo::BSONArrayBuilder single_set, box_list;
			for (int i = 0; i < it->second.single_set.size(); ++i)
			{
				mongo::BSONArrayBuilder single_list;
				for (daily_inpour::InpourSingleList::iterator sit = it->second.single_set[i].begin();
					sit != it->second.single_set[i].end();
					++sit)
				{
					single_list << sit->first << sit->second.gold << sit->second.accu << sit->second.box.rawBox.toIndentString();
				}
				single_set << single_list.arr();
			}
			for (daily_inpour::InpourBoxList::iterator bit = it->second.box_list.begin();
				bit != it->second.box_list.end();
				++bit)
			{
				box_list << bit->first << bit->second.accu << bit->second.box.rawBox.toIndentString();
			}
			mongo::BSONObj obj = BSON(strID << it->first
				<< strFlag << it->second.flag
				<< strBegin << it->second.begin
				<< strEnd << it->second.end
				<< strSingleList << single_set.arr()
				<< strBoxList << box_list.arr()
				<< strVersion << iVersion
			);
			return db_mgr.SaveMongo(DBN::dbSystemDailyInpour, key, obj);
		}
		return true;
	}

	void daily_inpour_system::loadData()
	{
		/*Json::Value msg = Common::loadJsonFile(std::string("./instance/daily_inpour/daily_inpour2.json"));

		daily_inpour::import(msg);*/

		std::cout << "load ./daily_inpour_system START	" << std::endl;

		objCollection objs = db_mgr.Query(DBN::dbSystemDailyInpour);
		ForEachC(objCollection, it, objs)
		{
			daily_inpour::DailyInpourActivity activity;
			const mongo::BSONObj& obj = (*it);
			/*if (obj[strVersion].eoo())
			{
				continue;
			}*/
			activity.id = obj[strID].Int();
			activity.flag = obj[strFlag].Int();
			activity.begin = obj[strBegin].Int();
			activity.end = obj[strEnd].Int();
			std::vector<mongo::BSONElement> single_set = obj[strSingleList].Array();
			std::vector<mongo::BSONElement> box_list = obj[strBoxList].Array();
			if (obj[strVersion].eoo())
			{
				//Ϊ�����ݼ��ݣ�һ�������N�����ݡ�
				daily_inpour::InpourSingleList box_single_list;
				for (int i = 0; i < single_set.size(); i+=4)
				{
					daily_inpour::InpourSingle single;
					single.id = single_set[i].Int();
					single.gold = single_set[i + 1].Int();
					single.accu = single_set[i + 2].Int();
					single.box.rawBox = Common::string2json(single_set[i + 3].String());
					single.box.load();
					box_single_list[single.id] = single;
				}
				//����N��
				int n = daily_inpour::getTotalDay(activity.begin, activity.end);
				for (int i = 0; i < n; ++i)
				{
					activity.single_set.push_back(box_single_list);
				}
				LogS << "daily_inpour:" << "load old format data complete..." << LogEnd;

			}
			else
			{
				for (int j = 0; j < single_set.size(); ++j)
				{
					std::vector<mongo::BSONElement> single_list = single_set[j].Array();
					daily_inpour::InpourSingleList box_single_list;
					for (int i = 0; i < single_list.size(); i += 4)
					{
						daily_inpour::InpourSingle single;
						single.id = single_list[i].Int();
						single.gold = single_list[i + 1].Int();
						single.accu = single_list[i + 2].Int();
						single.box.rawBox = Common::string2json(single_list[i + 3].String());
						single.box.load();
						box_single_list[single.id] = single;
					}
					activity.single_set.push_back(box_single_list);
				}
			}
			for (int i = 0; i < box_list.size(); i += 3)
			{
				daily_inpour::InpourBox box;
				box.id = box_list[i].Int();
				box.accu = box_list[i + 1].Int();
				box.box.rawBox = Common::string2json(box_list[i + 2].String());
				box.box.load();
				activity.box_list[box.id] = box;
			}
			daily_inpour_config[activity.id] = activity;
		}
		//
		select_active();

		//test
		/*Json::Value value_2 = Common::loadJsonFile(std::string("./instance/daily_inpour/test.json"));
		std::string v222 = value_2.toIndentString();
		daily_inpour::import(value_2);*/
		//
		std::cout << "load ./daily_inpour_system END	" << std::endl;
	}

	void daily_inpour_system::delData(int activity_id)
	{
		DailyInpourList::iterator it = daily_inpour_config.find(activity_id);
		if (it != daily_inpour_config.end())
		{
			mongo::BSONObj key = BSON(strID << it->first);
			db_mgr.RemoveCollection(DBN::dbSystemDailyInpour, key);
		}
	}

	void daily_inpour_system::select_active()
	{
		bool flag = false;
		unsigned now = Common::gameTime();
		std::vector<int> record;
		for (DailyInpourList::iterator it = daily_inpour_config.begin();
			it != daily_inpour_config.end();
			++it)
		{
			if (now > it->second.end)
			{
				record.push_back(it->first);
			}
		}

		for (int i = 0; i < record.size(); ++i)
		{
			delData(record[i]);
			daily_inpour_config.erase(record[i]);
		}

		for (DailyInpourList::iterator it = daily_inpour_config.begin();
			it != daily_inpour_config.end();
			++it)
		{
			if (now > it->second.begin && now < it->second.end && it->second.flag == 1)
			{
				_curr = it->second;
				flag = true;
				break;
			}
		}
		if (!flag)
		{
			_curr.id = -1;
		}
	}

	void daily_inpour_system::updateInfo()
	{
		if (_curr.id != -1)
		{
			int days = daily_inpour::getDays(_curr.begin);
			LogS << "daily_inpour:" << "\tdays:" << days << "\tsingle_set:" << _curr.single_set.size() << LogEnd;
			if (days == _curr.days)
			{
				return;
			}
			_curr.days = days;
			if (days >= _curr.single_set.size())
			{
				return;
			}
			//����µ�info
			daily_inpour::FixedInfo info;
			unsigned int i = 0u;
			for (daily_inpour::InpourBoxList::iterator bit = _curr.box_list.begin();
				bit != _curr.box_list.end();
				++bit)
			{
				info.box_accu_list[i] = bit->second.accu;
				info.box_boxes_list[i] = bit->second.box.jsonBox;
				info.box_flag_list[i] = 0;
				++i;
			}
			i = 0u;
			for (daily_inpour::InpourSingleList::iterator sit = _curr.single_set[days].begin();
				sit != _curr.single_set[days].end();
				++sit)
			{
				info.single_accu_list[i] = sit->second.accu;
				info.single_boxes_list[i] = sit->second.box.jsonBox;
				info.single_flag_list[i] = 0;
				info.single_gold_list[i] = sit->second.gold;
				++i;
			}
			_info = info;
		}
	}

	daily_inpour_system::~daily_inpour_system()
	{
	}
}

#include "festival_system.h"
#include "net_helper.hpp"
#include "chat.h"

namespace gg
{
	using namespace nFestival;

	namespace nFestival
	{
		enum
		{
			RESET = 0,	
			CLEAR,
		};

		RewardRecord::RewardRecord(int key_id)
			: _key_id(key_id){}

		void RewardRecord::loadDB()
		{
			mongo::BSONObj key = BSON("key" << _key_id);
			mongo::BSONObj obj = db_mgr.FindOne(DBN::dbFestivalRecord, key);
			if (obj.isEmpty())
				return;
			std::vector<mongo::BSONElement> ele = obj["value"].Array();
			for (unsigned i = 0; i < ele.size(); ++i)
				_records.push_back(ele[i].String());
		}

		void RewardRecord::removeDB()
		{
			mongo::BSONObj key = BSON("key" << _key_id);
			db_mgr.RemoveCollection(DBN::dbFestivalRecord, key);
		}

		bool RewardRecord::_auto_save()
		{
			mongo::BSONObj key = BSON("key" << _key_id);
			mongo::BSONObjBuilder obj;
			obj << "key" << _key_id;
			{
				mongo::BSONArrayBuilder b;
				ForEachC(RecordList, it, _records)
					b.append(*it);
				obj << "value" << b.arr();
			}
			return db_mgr.SaveMongo(DBN::dbFestivalRecord, key, obj.obj());
		}

		void RewardRecord::push(qValue& r)
		{
			_records.push_back(r.toIndentString());
			while(_records.size() > 10)
				_records.pop_front();
			_sign_save();
		}

		void RewardRecord::update(playerDataPtr d)
		{
			std::string str;
			str += "{\"msg\":[0,[";
			ForEachC(RecordList, it, _records)
			{
				if (it != _records.begin())
					str += ",";
				str += *it;
			}
			str += "]]}";
			d->sendToClient(gate_client::festival_reward_info_resp, str);
		}
	}

	festival_system* const festival_system::_Instance = new festival_system();

	Festival::Festival(const Json::Value& info)
		: ActivityBase(info["kid"].asUInt(), info["bt"].asUInt() + Common::timeZone() * HOUR, info["et"].asUInt() + Common::timeZone() * HOUR)
		, _data(info)
	{
		{
			const Json::Value& ttb = info["ttb"];
			ForEachC(Json::Value, it, ttb)
				_turntable_items.push_back(RandItem(*it));
			const Json::Value& egg = info["egg"];
			ForEachC(Json::Value, it, egg)
				_egg_items.push_back(RandItem(*it));
			const Json::Value& exc = info["exc"];
			ForEachC(Json::Value, it, exc)
				_exchange_items.push_back(ExchangeItem(*it));
			const Json::Value& npc = info["npc"];
			ForEachC(Json::Value, it, npc)
				_npc_items.push_back(NpcItem(*it));
			const Json::Value& wld = info["extra"]["wld"];
			ForEachC(Json::Value, it, wld)
				_world_extra.push_back(RandItem(*it));
			const Json::Value& chp = info["extra"]["chp"];
			ForEachC(Json::Value, it, chp)
				_chapter_extra.push_back(RandItem(*it));
			const Json::Value& tmw = info["extra"]["tmw"];
			ForEachC(Json::Value, it, tmw)
				_teamwar_extra.push_back(RandItem(*it));
		}
		{
			_client_info = info;
			Json::Value& ttb = _client_info["ttb"];
			ForEach(Json::Value, it, ttb)
				(*it)["rw"] = jsonFormats2c((*it)["rw"]);
			Json::Value& egg = _client_info["egg"];
			ForEach(Json::Value, it, egg)
				(*it)["rw"] = jsonFormats2c((*it)["rw"]);
			Json::Value& exc = _client_info["exc"];
			ForEach(Json::Value, it, exc)
				(*it)["rw"] = jsonFormats2c((*it)["rw"]);
			Json::Value& npc = _client_info["npc"];
			ForEach(Json::Value, it, npc)
			{
				Json::Value& rwl = (*it)["rwl"];
				ForEach(Json::Value, itr, rwl)
					(*itr)["rw"] = jsonFormats2c((*itr)["rw"]);
			}
			Json::Value& wld = _client_info["extra"]["wld"];
			ForEach(Json::Value, it, wld)
				(*it)["rw"] = jsonFormats2c((*it)["rw"]);
			Json::Value& chp = _client_info["extra"]["chp"];
			ForEach(Json::Value, it, chp)
				(*it)["rw"] = jsonFormats2c((*it)["rw"]);
			Json::Value& tmw = _client_info["extra"]["tmw"];
			ForEach(Json::Value, it, tmw)
				(*it)["rw"] = jsonFormats2c((*it)["rw"]);
		}

	}

	mongo::BSONObj Festival::toBSON() const
	{
		return BSON("str" << _data.toIndentString());
	}

	const ActionBoxList& Festival::turnTableReward(int& idx, bool& bc) const
	{
		int total = 0;
		ForEachC(ItemList, it, _turntable_items)
			total += it->percent;
		int r = Common::random() % total;
		int cur = 0;
		idx = 0;
		ForEachC(ItemList, it, _turntable_items)
		{
			if (r < it->percent + cur)
			{
				bc = it->bc;
				return it->reward;
			}
			++idx;
			cur += it->percent;
		}
		idx = 0;
		bc = _turntable_items.front().bc;
		return _turntable_items.front().reward;
	}

	const ActionBoxList& Festival::eggReward(int& idx, bool& bc) const
	{
		int total = 0;
		ForEachC(ItemList, it, _egg_items)
			total += it->percent;
		int r = Common::random() % total;
		int cur = 0;
		idx = 0;
		ForEachC(ItemList, it, _egg_items)
		{
			if (r < it->percent + cur)
			{
				bc = it->bc;
				return it->reward;
			}
			++idx;
			cur += it->percent;
		}
		idx = 0;
		bc = _egg_items.front().bc;
		return _egg_items.front().reward;
	}

	static int randIndex(const ItemList& rand_list)
	{
		int total = 0;
		ForEachC(ItemList, it, rand_list)
			total += it->percent;
		int r = Common::random() % total;
		int cur = 0;
		int idx = 0;
		ForEachC(ItemList, it, rand_list)
		{
			if (r < it->percent + cur)
				return idx;
			++idx;
			cur += it->percent;
		}
		return 0;
	}

	static ActionBoxList randReward(const ItemList& rand_list)
	{
		unsigned total = 10000;
		ActionBoxList ret_rw;
		ForEachC(ItemList, it, rand_list)
		{
			int r = Common::random() % total;
			if (r < it->percent)
			{
				const ActionBoxList& tmp_rw = it->reward;
				ForEachC(ActionBoxList, itt, tmp_rw)
					ret_rw.push_back(*itt);
			}
		}
		return ret_rw;
	}

	ActionBoxList Festival::worldExtra() const
	{
		return randReward(_world_extra);
	}

	ActionBoxList Festival::chapterExtra() const
	{
		return randReward(_chapter_extra);
	}

	ActionBoxList Festival::teamwarExtra() const
	{
		return randReward(_teamwar_extra);
	}

	ActionBoxList Festival::npcReward(int type) const
	{
		if (type < 0 || type >= _npc_items.size())
		{
			LogE << "festival npc type error: " << type << ", " << _npc_items.size() << LogEnd;
			type = 0;
		}
		const ItemList& rw = _npc_items[type].reward;
		return randReward(rw);
	}

	const std::string& Festival::npcName(int type) const
	{
		if (type < 0 || type >= _npc_items.size())
		{
			LogE << "festival npc type error: " << type << ", " << _npc_items.size() << LogEnd;
			type = 0;
		}
		return _npc_items[type].name;
	}

	int Festival::npcType() const
	{
		int total = 0;
		ForEachC(NpcItems, it, _npc_items)
			total += it->rand_percent;
		int r = Common::random() % total;
		int cur = 0;
		int pos = 0;
		ForEachC(NpcItems, it, _npc_items)
		{
			if (r < it->rand_percent + cur)
				return pos;
			cur += it->rand_percent;
			++pos;
		}
		return 0;
	}

	void Festival::start()
	{
		festival_sys.startTickTimer();
		festival_sys.sendInfo();
		festival_sys.sendNpc();
		_record = Creator<nFestival::RewardRecord>::Create(keyID());
		_record->loadDB();
	}

	void Festival::stop(bool timer_tick)
	{
		festival_sys.stopTickTimer();
		festival_sys.sendInfo();
		festival_sys.sendNpc();
		_record->removeDB();
	}

	void Festival::update()
	{
		festival_sys.sendInfo();
		_record = Creator<nFestival::RewardRecord>::Create(keyID());
		_record->loadDB();
	}

	void Festival::addRecord(qValue& q)
	{
		_record->push(q);
	}

	void Festival::sendRecord(playerDataPtr d)
	{
		_record->update(d);
	}

	festival_system::festival_system()
		: ActivityMgr<Festival>(DBN::dbFestival, Inter::event_festival_timer)
	{
	}

	void festival_system::initData()
	{
		loadDB();
	}

	void festival_system::loadDB()
	{
		objCollection objs = db_mgr.Query(DBN::dbFestival);
		std::map<int, boost::shared_ptr<Festival> > festival_map;
		ForEachC(objCollection, it, objs)
		{
			std::string str = (*it)["value"]["str"].String();
			boost::shared_ptr<Festival> ptr = Creator<Festival>::Create(Common::string2json(str));
			festival_map.insert(make_pair(ptr->beginTime(), ptr));
		}
		unsigned cur_time = Common::gameTime();
		for (std::map<int, boost::shared_ptr<Festival> >::iterator it = festival_map.begin();
			it != festival_map.end(); ++it)
			update(it->second);
	}

	void festival_system::gmIDList(net::Msg& m, Json::Value& r)
	{
		getIDList(r[strMsg][1u]);
		Return(r, res_sucess);
	}

	void festival_system::gmInfo(net::Msg& m, Json::Value& r)
	{
		ReadJsonArray;
		int key_id = js_msg[0u].asInt();
		boost::shared_ptr<Festival> ptr = find(key_id);
		if (!ptr) Return(r, err_illedge);
		r[strMsg][1u] = ptr->data();
		Return(r, res_sucess);
	}

	void festival_system::gmModify(net::Msg& m, Json::Value& r)
	{
		ReadJsonArray;
		const Json::Value& info = js_msg[0u];
		//LogI << "festival modify: " << info.toIndentString() << LogEnd;
		int res;
		if (info["et"].asUInt() == 0)
			res = remove(info["kid"].asInt());
		else
		{
			boost::shared_ptr<Festival> ptr = Creator<Festival>::Create(info);
			res = update(ptr);
		}
		Return(r, res);
	}

	void festival_system::playerInfo(net::Msg& m, Json::Value& r)
	{
		playerDataPtr d = player_mgr.getPlayer(m.playerID);
		if (!d || !current()) Return(r, err_illedge);
		d->Festival().sendBase();
		current()->sendRecord(d);
	}

	void festival_system::buyTurnTableTimes(net::Msg& m, Json::Value& r)
	{
		playerDataPtr d = player_mgr.getPlayer(m.playerID);
		if (!d) Return(r, err_illedge);
		int res = d->Festival().buyTurnTableTimes();
		Return(r, res);
	}

	void festival_system::turnTable(net::Msg& m, Json::Value& r)
	{
		playerDataPtr d = player_mgr.getPlayer(m.playerID);
		if (!d) Return(r, err_illedge);
		ReadJsonArray;
		int type = js_msg[0u].asInt();
		int res = d->Festival().turnTable(type, r);
		Return(r, res);
	}

	void festival_system::throwEgg(net::Msg& m, Json::Value& r)
	{
		playerDataPtr d = player_mgr.getPlayer(m.playerID);
		if (!d) Return(r, err_illedge);
		int res = d->Festival().throwEgg(r);
		Return(r, res);
	}

	void festival_system::exchangeMaterial(net::Msg& m, Json::Value& r)
	{
		playerDataPtr d = player_mgr.getPlayer(m.playerID);
		if (!d) Return(r, err_illedge);
		ReadJsonArray;
		int idx = js_msg[0u].asInt();
		int res = d->Festival().exchangeMaterial(idx, r);
		Return(r, res);
	}

	void festival_system::fightNpc(net::Msg& m, Json::Value& r)
	{
		playerDataPtr d = player_mgr.getPlayer(m.playerID);
		if (!d) Return(r, err_illedge);
		ReadJsonArray;
		int type = js_msg[0u].asInt();
		int id = js_msg[1u].asInt();
		int res = d->Festival().fightNpc(type, id);
		Return(r, res);
	}

	void festival_system::buyThrowEggTimes(net::Msg& m, Json::Value& r)
	{
		playerDataPtr d = player_mgr.getPlayer(m.playerID);
		if (!d) Return(r, err_illedge);
		int res = d->Festival().buyThrowEggTimes();
		Return(r, res);
	}

	void festival_system::ownRecord(net::Msg& m, Json::Value& r)
	{
		playerDataPtr d = player_mgr.getPlayer(m.playerID);
		if (!d || !current()) Return(r, err_illedge);
		d->Festival().sendRecord();
	}

	void festival_system::sendNpc()
	{
		playerManager::playerDataVec vec = player_mgr.allOnline();
		ForEach(playerManager::playerDataVec, it, vec)
			(*it)->Festival().sendNpc();
	}

	void festival_system::tick(unsigned tick_timer, int state)
	{
		if (tick_timer != _tick_timer)
			return;
		if (state == nFestival::RESET)
			broadcast();
		sendNpc();
		startTickTimer();
	}

	void festival_system::broadcast()
	{
		chat_sys.despatchAll(CHAT::server_festival_broadcast, qValue() << 0);
	}

	void festival_system::sendInfo(playerDataPtr d)
	{
		Json::Value m;
		m[strMsg][0u] = res_sucess;
		if (!current())
			m[strMsg][1u]["kid"] = -1;
		else
			m[strMsg][1u] = current()->ClientInfo();
		if (d)
			d->sendToClient(gate_client::festival_activity_info_resp, m);
		else
		{
			//playerManager::playerDataVec vec = player_mgr.allOnline();
			Batch::batchAll(m, gate_client::festival_activity_info_resp);
		}
	}

	void festival_system::startTickTimer()
	{
		const static int ResetHour[] = { 12, 13, 14, 20, 21, 22 };
		const static int ClearHour[] = { 15, 23 };
		unsigned cur_time = Common::gameTime();
		unsigned next_min_time = cur_time + DAY;
		int next_state = nFestival::RESET;
		for (unsigned i = 0; i < sizeof(ResetHour)/sizeof(ResetHour[0]); ++i)
		{
			unsigned next_tick_time = Common::getNextTimeHMS(cur_time, ResetHour[i]);
			if (next_tick_time < next_min_time)
				next_min_time = next_tick_time;
		}
		for (unsigned i = 0; i < sizeof(ClearHour)/sizeof(ClearHour[0]); ++i)
		{
			unsigned next_tick_time = Common::getNextTimeHMS(cur_time, ClearHour[i]);
			if (next_tick_time < next_min_time)
			{
				next_min_time = next_tick_time;
				next_state = nFestival::CLEAR;
			}
		}
		Timer::AddEventTickTime(boostBind(festival_system::tick, this, ++_tick_timer, next_state), Inter::event_festival_timer, next_min_time);
	}

	void festival_system::stopTickTimer()
	{
		++_tick_timer;
	}
}

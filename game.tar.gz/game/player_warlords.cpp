#include "player_warlords.h"
#include "dbDriver.h"
#include "warlords_system.h"
#include "task_mgr.h"
#include "player_enemy.h"

namespace gg
{
	namespace WarLords
	{
		mongo::BSONObj Report::toBSON() const
		{
			return BSON("atk" << attack_side
					<< "pi" << pid
					<< "na" << nation
					<< "nm" << name
					<< "tm" << time
					<< "rp" << red_point
					<< "res" << result
					<< "rw" << Common::json2string(reward)
					<< "rpn" << report_name);
		}

		Report::Report(const mongo::BSONElement& obj)
		{
			attack_side = obj["atk"].Bool();
			pid = obj["pi"].Int();
			nation = obj["na"].Int();
			name = obj["nm"].String();
			time = obj["tm"].Int();
			red_point = obj["rp"].Bool();
			result = obj["res"].Bool();
			reward = Common::string2json(obj["rw"].String());
			report_name = obj["rpn"].String();
		}

		void Report::getInfo(Json::Value& info) const
		{
			info = Json::arrayValue;
			info.append(attack_side);
			info.append(pid);
			info.append(nation);
			info.append(name);
			info.append(time);
			info.append(red_point);
			info.append(result);
			info.append(reward);
			info.append(report_name);
		}
	}

	playerWarLords::playerWarLords(playerData* const own)
		: _auto_player(own), cd(0), attack_times(AttackTimes), defense_times(0), search_cd(0), red_point(false), atk_report_mgr(MaxReport), def_report_mgr(MaxReport), defense_lose_times(0)
		, default_msg(true), msg(""), atk_report_id(0), def_report_id(0)
	{
		evil_value.assign(Kingdom::nation_num, 50);

		std::string path = "./report/warlords/" + Common::toString(Own().ID());
		Common::createDirectories(path);
	}

	void playerWarLords::setData(mongo::BSONObj& obj)
	{
		if (obj.isEmpty())
			return;
		checkNotEoo(obj["cd"])
			cd = obj["cd"].Int();
		checkNotEoo(obj["at"])
			attack_times = obj["at"].Int();
		checkNotEoo(obj["dt"])
			defense_times = obj["dt"].Int();
		checkNotEoo(obj["dlt"])
			defense_lose_times = obj["dlt"].Int();
		checkNotEoo(obj["arpi"])
			atk_report_id = obj["arpi"].Int();
		checkNotEoo(obj["drpi"])
			def_report_id = obj["drpi"].Int();
		checkNotEoo(obj["scd"])
			search_cd = obj["scd"].Int();
		checkNotEoo(obj["rp"])
			red_point = obj["rp"].Bool();
		checkNotEoo(obj["arl"])
			atk_report_mgr.load(obj["arl"]);
		checkNotEoo(obj["drl"])
			def_report_mgr.load(obj["drl"]);
		checkNotEoo(obj["ev"])
		{
			std::vector<mongo::BSONElement> ele = obj["ev"].Array();
			for (unsigned i = 0; i < ele.size(); ++i)
				evil_value[i] = ele[i].Int();
		}
		checkNotEoo(obj["dm"])
			default_msg = obj["dm"].Bool();
		checkNotEoo(obj["mg"])
			msg = obj["mg"].String();
	}

	bool playerWarLords::_auto_save()
	{
		mongo::BSONObj key = BSON(strPlayerID << Own().ID());
		mongo::BSONObjBuilder obj;
		obj << "cd" << cd << "at" << attack_times << "rp" << red_point
		 	<< "dt" << defense_times << "dlt" << defense_lose_times << "arpi" << atk_report_id << "drpi" << def_report_id
			<< "scd" << search_cd << "arl" << atk_report_mgr.toBSON() << "drl" << def_report_mgr.toBSON() << "dm" << default_msg << "mg" << msg;
		{
			mongo::BSONArrayBuilder b;
			for (unsigned i = 0; i < Kingdom::nation_num; ++i)
				b.append(evil_value[i]);
			obj << "ev" << b.arr();
		}
		mongo::BSONObj set_obj = BSON("$set" << BSON("WarLords" << obj.obj()));
		return db_mgr.SaveMongo(DBN::dbPlayerCollection, key, set_obj);
	}

	void playerWarLords::_auto_update()
	{
		update();
	}

	void playerWarLords::update()
	{
		Json::Value msg;
		msg[strMsg][0u] = res_sucess;
		msg[strMsg][1u]["cd"] = cd;
		msg[strMsg][1u]["at"] = attack_times;
		msg[strMsg][1u]["dt"] = defense_times;
		msg[strMsg][1u]["rp"] = red_point;
		msg[strMsg][1u]["scd"] = search_cd;
		Own().sendToClient(gate_client::warlords_player_info_resp, msg);
	}

	void playerWarLords::setAndUpdateRedPoint(bool rp)
	{
		if (red_point != rp)
		{
			red_point = rp;
			updateRedPoint(true);
		}
	}

	void playerWarLords::updateRedPoint(bool check)
	{
		Json::Value msg;
		msg[strMsg][0u] = res_sucess;
		msg[strMsg][1u] = red_point;
		msg[strMsg][2u] = check;
		Own().sendToClient(gate_client::warlords_red_point_resp, msg);
	}

	void playerWarLords::tick()
	{
		attack_times = AttackTimes;
		defense_times = 0;
		defense_lose_times = 0;
		_sign_save();
	}

	bool playerWarLords::inSearchCd()
	{
		unsigned cur_time = Common::gameTime();
		bool result = cur_time < search_cd;
		if (!result)
		{
			search_cd = cur_time + 1 * MINUTE;
			_sign_auto();
		}
		return result;
	}

	std::string playerWarLords::addNpcRep(unsigned now, const std::string& name, O2ORes& res)
	{
		WarLords::ReportPtr ptr = Creator<WarLords::Report>::Create();
		ptr->attack_side = false;
		ptr->pid = -1;
		ptr->nation = -1;
		ptr->name = name;
		ptr->time = now;
		ptr->red_point = true;
		ptr->result = res.res == resBattle::def_win;
		ptr->reward = Json::arrayValue;
		ptr->report_name = getReportId(false);
		def_report_mgr.push(ptr);
		setAndUpdateRedPoint(true);
		return ptr->report_name;
	}

	std::string playerWarLords::atkAddReport(unsigned now, playerDataPtr target, O2ORes& res, const Json::Value& reward)
	{
		std::string rep_id = addRep(now, target, res, reward, true);
		if (Own().Info().Nation() != target->Info().Nation())
		{
			--attack_times;
			Own().Res().alterAction(-1);
			clearCd();
			if (res.res == resBattle::atk_win)
				addEvilValue(target->Info().Nation());

			TaskMgr::update(Own().getOwnDataPtr(), Task::WarLordsAttackTimes, 1);
			Own().Daily().tickTask(DAILY::hit_world_other);
		}
		_sign_auto();
		return rep_id;
	}

	std::string playerWarLords::defAddReport(unsigned now, playerDataPtr target, O2ORes& res, const Json::Value& reward)
	{
		std::string rep_id = addRep(now, target, res, reward, false);
		if (Own().Info().Nation() != target->Info().Nation())
		{
			++defense_times;
			if (res.res == resBattle::atk_win)
			{
				++defense_lose_times;
				subEvilValue(target->Info().Nation());
				resetCd(now);
			}
			else
			{
				defense_lose_times = 0;
			}
		}
		_sign_auto();
		return rep_id;
	}

	std::string playerWarLords::getReportId(bool atk_side)
	{
		unsigned& rid = atk_side? atk_report_id : def_report_id; 
		++rid;
		if (rid > MaxReport)
			rid = 1;
		return Common::toString(atk_side? rid : (rid + 100));
	}

	int playerWarLords::getTitle(int nation) const
	{
		if (nation < 0 || nation > 2)
			return 0;
		int count = 0;
		for (unsigned i = 0; i < Kingdom::nation_num; ++i)
		{
			if (evil_value[i] == 150)
				++count;
		}	
		if (count >= 2)
			return 11;
		return warlords_sys.getTitle(evil_value[nation]);
	}

	void playerWarLords::getReportInfo(Json::Value& info)
	{
		atk_report_mgr.getInfo(info["arl"]);
		def_report_mgr.getInfo(info["drl"]);
		if (red_point)
		{
			setAndUpdateRedPoint(false);
			atk_report_mgr.run(boostBind(playerWarLords::clearRedPoint, this, _1));
			def_report_mgr.run(boostBind(playerWarLords::clearRedPoint, this, _1));
			_sign_auto();
		}
	}

	void playerWarLords::clearRedPoint(const WarLords::ReportPtr& ptr)
	{
		ptr->clearRedPoint();
	}

	int playerWarLords::addFame(int val)
	{
		val = Own().Res().alterFame(val);
		TaskMgr::update(Own().getOwnDataPtr(), Task::WarLordsGetFameNum, val);
		return val;
	}

	void playerWarLords::resetCd(unsigned now)
	{
		cd = now + BaseCd;
		if (defense_lose_times >= AddCdStartCount)
		{
			cd += AddCd * (defense_lose_times - AddCdStartCount + 1);
			if (cd > now + MaxCd)
				cd = now + MaxCd;
		}
		warlords_sys.updatePlayerCd(Own().getOwnDataPtr());
		EnemyMgr::shared().upData(Own().getOwnDataPtr());
	}

	void playerWarLords::clearCd()
	{
		cd = 0;
		warlords_sys.updatePlayerCd(Own().getOwnDataPtr());
		EnemyMgr::shared().upData(Own().getOwnDataPtr());
	}

	void playerWarLords::addEvilValue(int nation)
	{
		if (evil_value[nation] < 105)
			alterEvilValue(nation, 1);
		else
			alterEvilValue(nation, 3);
	}

	void playerWarLords::subEvilValue(int nation)
	{
		if (evil_value[nation] < 105)
			alterEvilValue(nation, -1);
		else
			alterEvilValue(nation, -3);
	}

	void playerWarLords::alterEvilValue(int nation, int val)
	{
		evil_value[nation] += val;
		if (evil_value[nation] < 0)
			evil_value[nation] = 0;
		if (evil_value[nation] > 150)
			evil_value[nation] = 150;
		warlords_sys.updateEvilValue(Own().getOwnDataPtr());
		TaskMgr::update(Own().getOwnDataPtr(), Task::WarLordsGetTitle);
	}

	void playerWarLords::getTable(int nation, Json::Value& info)
	{
		info["pi"] = Own().ID(); 
		info["nm"] = Own().Name(); 
		info["lv"] = Own().LV(); 
		info["fa"] = Own().Info().Face(); 
		info["nt"] = Own().Info().Nation();
		info["cv"] = Own().WarFM().currentBV(); 
		info["ol"] = Own().isOnline(); 
		info["cd"] = cd;
		info["nn"] = getTitle(nation); 
		info["at"] = AttackTimes - attack_times;
		info["dt"] = defense_times;
		info["dm"] = default_msg;
		info["mg"] = msg;
		info["un"] = Own().Info().UsedName();
	}

	std::string playerWarLords::addRep(unsigned now, playerDataPtr target, O2ORes& res, const Json::Value& reward, bool attack_side)
	{
		WarLords::ReportPtr ptr = Creator<WarLords::Report>::Create();
		ptr->attack_side = attack_side;
		ptr->pid = target->ID();
		ptr->nation = target->Info().Nation();
		ptr->name = target->Name();
		ptr->time = now;
		ptr->red_point = !attack_side;
		ptr->result = attack_side? res.res == resBattle::atk_win : res.res == resBattle::def_win;
		ptr->reward = reward;
		ptr->report_name = getReportId(attack_side);
		if (Own().Info().Nation() != target->Info().Nation())
		{
			if (attack_side)
				atk_report_mgr.push(ptr);
			else
				def_report_mgr.push(ptr);
				
			if (!attack_side)
				setAndUpdateRedPoint(true);
		}
		return ptr->report_name;
	}

	int playerWarLords::setMessage(const std::string& str)
	{
		if (str.size() > 50)
			return err_illedge;

		msg = str;
		default_msg = false;
		_sign_save();
		return res_sucess;
	}
}

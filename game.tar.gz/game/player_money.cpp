#include "player_money.h"
#include "dbDriver.h"
#include "money_activity.h"
#include "email_system.h"

namespace gg
{
	playerMoneyActivity::playerMoneyActivity(playerData* const own) : _auto_player(own)
	{
		for (unsigned i = 0; i < MONEYACTIVITY::money_activity_num; ++i)
		{
			dataList[i] = Creator<MONEYACTIVITY::Data>::Create(MONEYACTIVITY::MATYPE(i));
		}
	}

	void playerMoneyActivity::signTickUpdate(const unsigned type)
	{
		if (type > MONEYACTIVITY::money_activity_end)return;
		clearType();
		MONEYACTIVITY::ptrData ptr = dataList[type];
		qValue json(qJson::qj_array);
		json.append(res_sucess);
		json.append(ptr->typeAct);
		json.append(ptr->dealNum);
		qValue filter_json(qJson::qj_array);
		for (MONEYACTIVITY::Data::wonList::iterator it = ptr->awardList.begin(); it != ptr->awardList.end(); ++it)
		{
			filter_json.append(*it);
		}
		json.append(filter_json);
		Own().sendToClientFillMsg(gate_client::player_money_activity_update_own_resp, json);
	}

	void playerMoneyActivity::_auto_update()
	{
		for (unsigned i = 0; i < MONEYACTIVITY::money_activity_num; ++i)
		{
			MONEYACTIVITY::ptrData ptr = dataList[i];
			if (!ptr->dirty)continue;
			signTickUpdate(i);
		}
	}

	bool playerMoneyActivity::hasReward(const unsigned type)
	{
		if (type > MONEYACTIVITY::money_activity_end)return false;
		clearType();
		MONEYACTIVITY::ptrData ptr = dataList[type];
		return money_sys.hasReward(type, ptr->createTime, ptr->awardList, ptr->dealNum);
	}

	void playerMoneyActivity::tickNum(const unsigned type, const int num)
	{
		if (num < 1)return;
		if (type > MONEYACTIVITY::money_activity_end)return;
		clearType();
		MONEYACTIVITY::ptrData ptr = dataList[type];
		ptr->dirty = true;
		ptr->dealNum += num;
		if (money_sys.hasReward(type, ptr->createTime, ptr->awardList, ptr->dealNum))
		{
			//���
			qValue json(qJson::qj_array);
			json.append(res_sucess);
			json.append(type);
			json.append(true);
			Own().sendToClientFillMsg(gate_client::player_money_activity_update_red_resp, json);
		}
		_sign_auto();
	}

	int playerMoneyActivity::tryAward(const unsigned type, const int checkNum)
	{
		if (type > MONEYACTIVITY::money_activity_end)return err_illedge;
		clearType();
		MONEYACTIVITY::ptrData ptr = dataList[type];
		if (ptr->dealNum >= checkNum && ptr->awardList.find(checkNum) == ptr->awardList.end())
		{
			ActionBoxList box = money_sys.currenReward(type, checkNum);
			const int res = actionDoBox(Own().getOwnDataPtr(), box, false);
			if (res != res_sucess)return res;
			ptr->awardList.insert(checkNum);
			ptr->dirty = true;
			_sign_auto();
			Json::Value res_json = actionRes();
			Log(DBLOG::strLogMoneyActivity, Own().getOwnDataPtr(), -1, checkNum, ptr->dealNum, type, "", "", "", "",
				res_json.toIndentString());
			return res_sucess;
		}
		return err_illedge;
	}

	void playerMoneyActivity::clearType()//�õ���ǰ������
	{
		for (unsigned i = 0; i < MONEYACTIVITY::money_activity_num; ++i)
		{
			MONEYACTIVITY::ptrData ptr = dataList[i];
			if (!money_sys.checkMatchCurrent(ptr->typeAct, ptr->createTime))
			{
				vector<Json::Value> boxes = money_sys.backUpReward(i, ptr->createTime, ptr->awardList, ptr->dealNum);
				for (unsigned idx = 0; idx < boxes.size(); ++idx)
				{
					const Json::Value& box = boxes[idx];
					if (!box.empty())
					{
						Json::Value p_json;
						p_json.append(i);
						Json::Value rw_json = jsonFormats2c(box);
						EmailPtr email_ptr = email_sys.createPackage(EmailDef::RechargeCostReward, p_json, rw_json);
						email_sys.sendToPlayer(Own().ID(), email_ptr);
					}
				}
				ptr->clearData();
				ptr->createTime = money_sys.currentRewardKey(ptr->typeAct);
				ptr->dirty = true;
				_sign_auto();
			}
		}
	}

	void playerMoneyActivity::classFinal()
	{
		clearType();
	}

	void playerMoneyActivity::classLoad()
	{
		for (unsigned i = 0; i < MONEYACTIVITY::money_activity_num; ++i)
		{
			mongo::BSONObj key = BSON(strPlayerID << Own().ID() << "type" << i);
			mongo::BSONObj obj = db_mgr.FindOne(DBN::dbPlayerMoneyActivity, key);
			if (obj.isEmpty())continue;
			MONEYACTIVITY::ptrData ptr = dataList[i];
			ptr->createTime = obj["ct"].Int();
			ptr->dealNum = obj["dn"].Int();
			vector<mongo::BSONElement> vecs = obj["arr"].Array();
			for (unsigned idx = 0; idx < vecs.size(); ++idx)
			{
				ptr->awardList.insert(vecs[idx].Int());
			}
		}
	}

	bool playerMoneyActivity::_auto_save()
	{
		for (unsigned i = 0; i < MONEYACTIVITY::money_activity_num; ++i)
		{
			MONEYACTIVITY::ptrData ptr = dataList[i];
			if (!ptr->dirty)continue;
			ptr->dirty = false;
			mongo::BSONObj key = BSON(strPlayerID << Own().ID() << "type" << i);
			mongo::BSONArrayBuilder arr;
			for (MONEYACTIVITY::Data::wonList::iterator it = ptr->awardList.begin(); it != ptr->awardList.end(); ++it)
			{
				arr << *it;
			}
			mongo::BSONObj obj = BSON(strPlayerID << Own().ID() << "type" << i << "ct" << ptr->createTime <<
				 "dn" << ptr->dealNum << "arr" << arr.arr());
			db_mgr.SaveMongo(DBN::dbPlayerMoneyActivity, key, obj);
		}
		return true;
	}

}
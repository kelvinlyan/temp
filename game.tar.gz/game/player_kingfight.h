#pragma once

#include "auto_base.h"

namespace gg
{
	class playerKingFight
		: public _auto_player
	{
		public:
			playerKingFight(playerData* const own);

			void setData(mongo::BSONObj& obj);
			virtual void _auto_update();
			virtual bool _auto_save();
			
			void getInfo(Json::Value& info);

			int bet(int pid, const std::string& name, int silver, int rate);
			int getReward();
			int clearCd();
			bool inBattleCd();
			void setFinalState(int type, int silver);
			void setTitle(int title);
			int getTitle();

		private:
			void checkAndUpdate();

		private:
			unsigned _cd;

			unsigned _open_time;

			int _bet_pid;
			std::string _bet_name;
			int _bet_silver;
			int _bet_rate;
			int _bet_state;

			int _final_state;
			int _final_rewarded;
			int _final_silver;

			unsigned _title_time;
			int _title;
	};
}

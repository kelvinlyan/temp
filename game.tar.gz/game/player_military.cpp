#include "player_military.h"
#include "action_system.h"
#include "kingdomwar_helper.h"
#include "dbDriver.h"

namespace gg
{
	struct MilitaryConfigItem
	{
		MilitaryConfigItem():level(-1){}
		operator bool() const { return level != -1; }
		int level;
		int reputation;
		ActionRandomList reward;
		int attri[characterNum];
		int lv_limit;
	};

	class MilitaryConfig
	{
		SINGLETON(MilitaryConfig);
		public:
			const MilitaryConfigItem& Get(int level) const
			{
				static MilitaryConfigItem null;
				if (level >= _items.size())
					return null;
				return _items[level];
			}
		private:
			void loadFile();
		private:
			std::vector<MilitaryConfigItem> _items;
	};
	
	MilitaryConfig::MilitaryConfig()
	{
		loadFile();
	}

	void MilitaryConfig::loadFile()
	{
		int attri[characterNum];
		memset(attri, 0x0, sizeof(attri));
		Json::Value json = Common::loadJsonFile("./instance/military/military.json");
		ForEach(Json::Value, it, json)
		{
			Json::Value& info = *it;
			MilitaryConfigItem item;
			item.level = info["level"].asInt();
			item.reputation = info["reputation"].asInt();
			item.reward = actionFormat(info["reward"]);
			Json::Value& attribute = info["attribute"];
			item.lv_limit = info["lv_limit"].asInt();
			ForEach(Json::Value, ita, attribute)
				attri[(*ita)[0u].asInt()] += (*ita)[1u].asInt();
			memcpy(item.attri, attri, sizeof(attri));
			_items.push_back(item);
		}
	}

	playerMilitary::playerMilitary(playerData* const own)
		: _auto_player(own), _level(0)
	{
		memset(_attri, 0x0, sizeof(_attri));
	}

	void playerMilitary::setData(mongo::BSONObj& obj)
	{
		if (obj.isEmpty()) 
			return;

		_level = obj["lv"].Int();

		const MilitaryConfigItem& item = MilitaryConfig::shared().Get(_level);
		if (item)
			memcpy(_attri, item.attri, sizeof(_attri));
	}

	bool playerMilitary::_auto_save()
	{
		mongo::BSONObj key = BSON(strPlayerID << Own().ID());
		mongo::BSONObjBuilder obj; 
		obj << "lv" << _level;
		mongo::BSONObj set_obj = BSON("$set" << BSON("Military" << obj.obj()));
		return db_mgr.SaveMongo(DBN::dbPlayerCollection, key, set_obj);
	}

	void playerMilitary::update()
	{
		Json::Value m;
		m[strMsg][0u] = res_sucess;
		m[strMsg][1u]["lv"] = _level;
		Own().sendToClient(gate_client::player_military_data_resp, m);
	}

	int playerMilitary::levelUp(Json::Value& r)
	{
		int up_level = _level + 1;
		const MilitaryConfigItem& item = MilitaryConfig::shared().Get(up_level);
		if (!item)
			return err_illedge;
		if (Own().LV() < item.lv_limit)
			return err_lv_not_enough;
		if (Own().Res().getReputation() < item.reputation)
			return err_reputation_not_enough;
		int res = actionDo(Own().getOwnDataPtr(), item.reward);
		if (res == res_sucess)
		{
			r = actionRes();
			++_level;
			memcpy(_attri, item.attri, sizeof(_attri));
			Own().Res().alterReputation(0-item.reputation);
			Own().Man().recalComonMan();
			Log(DBLOG::strLogMilitary, Own().getOwnDataPtr(), 0, _level-1, _level, "", "", "", "", "", r.toIndentString());
			Own().Info()._sign_update();
			_sign_save();
		}
		else
		{
			Json::Value error_code = actionError();
			res = error_code[0u][1u].asInt();
		}
		return res;
	}

	int playerMilitary::level()
	{
		if (Own().LV() < 70)
			return -1;
		return _level;
	}
}

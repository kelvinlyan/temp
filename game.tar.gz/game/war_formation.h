//###################################
//create by Jim
//2015-12-08
//###################################

#pragma once

#include "auto_do.h"
#include "mongoDB.h"

namespace gg
{
	struct FMCFG
	{
		FMCFG()
		{
			fmID = -1;
			techID = -1;//��Ч
			HOLES.clear();
		}
		int fmID;//��ID
		int techID;//��Ӧ�Ƽ�ID
		struct HOLECFG
		{
			HOLECFG()
			{
				LV = 0;
				Process = -1;
				Use = false;
			}
			unsigned LV;//�����ȼ�����
			int Process;//��ͼ����
			bool Use;//�ɷ�ʹ��
		};
		STDVECTOR(HOLECFG, HOLEVEC);
		HOLEVEC HOLES;
	};
	STDVECTOR(FMCFG, FMCONFIG);

	class playerMan;
	BOOSTSHAREPTR(playerMan, playerManPtr);
	//�� 0 ~ 11 һ��12����
	class playerSGFM : public _auto_player
	{
	public://��ID
		static void initData();
		playerSGFM(const unsigned ID, playerData* const own);
		virtual ~playerSGFM(){}
		virtual int format(const int fm[9]);
		virtual void tryToFormat(const vector<playerManPtr>& vec);
		virtual qValue toJson();
		virtual mongo::BSONArray toBsonArr();
		std::vector<playerManPtr> toFormat();
		std::vector<playerManPtr> toInvaildFormat();
		bool isEmpty();
		void rawInitial(const bool in, vector<mongo::BSONElement>& vec);
		const unsigned fmID;
		inline int getBV(){ return FMPower; }
		void recalFM(const bool initial = false);
		inline bool isNewFM(){ return isNew; }
	protected:
		virtual int rawFormat(const int fm[9]);
		virtual bool _on_sign_update();
		virtual bool _auto_save();
		playerManPtr FMList[9];//�����б�
		int FMPower;
		bool isNew;//�Ƿ��Ǵ�Ů��
	};
	BOOSTSHAREPTR(playerSGFM, playerFMPtr);

	class playerWarFM : public _auto_player
	{
	public:
		static const FMCFG& getConfig(const int FMID);
		static void FormationAttribute(playerDataPtr player, const int fmID, int* attri);
		static int FormationBV(playerDataPtr player, const int fmID, const unsigned num);
		playerWarFM(playerData* const own);
		~playerWarFM(){}
		virtual int format(const unsigned fmID, const int fm[9]);
		void updateAll();
		void updateSingle(const unsigned fmID);
		int defaultFM(const unsigned fmID);
		inline unsigned currentID(){ return currentFMID; }
		void recalFMValue(const int fmID, const bool update = true);
		void recalFMValue(const bool update = true);//���¼���ս������
		bool currentEmpty();
		bool appointEmpty(const unsigned FMID);
		std::vector<playerManPtr> currentFM();
		std::vector<playerManPtr> appointFM(const unsigned FMID);
		std::vector<playerManPtr> currentInvaildFM();
		std::vector<playerManPtr> appointInvaildFM(const unsigned FMID);
		int currentBV();//��ȡ��ǰĬ���󷨵�ս������ֵ

		//tick
		void tickFM(const unsigned FMID);
	private:
		virtual void classLoad();
		virtual void classFinal();

		virtual bool _auto_save();
		virtual void _auto_update();
		unsigned currentFMID;
		STDVECTOR(playerFMPtr, fmVec);
		fmVec fmList;
		UNORDERSET(unsigned, UINTSET);
		UINTSET updateList_;
	};

	STDVECTOR(playerManPtr, ManList);
	int CalBV(playerDataPtr d, const ManList& ml, int fm_id);
	int CalNoEqBV(playerDataPtr d, const ManList& ml, int fm_id);
}

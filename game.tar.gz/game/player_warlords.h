//###################################
//create by CaiJiaWen
//2016-04-08
//###################################

#pragma once

#include "auto_base.h"
#include "mongoDB.h"
#include "battle_system.h"
#include "report_mgr.h"

namespace gg
{
	namespace WarLords
	{
		struct Report
		{
			Report(){}
			Report(const mongo::BSONElement& obj);

			mongo::BSONObj toBSON() const;
			void getInfo(Json::Value& info) const;
			void clearRedPoint() const { red_point = false; }

			bool attack_side;
			int pid;
			int nation;
			std::string name;
			unsigned time;
			mutable bool red_point;
			bool result;
			Json::Value reward;
			std::string report_name;
		};

		BOOSTSHAREPTR(Report, ReportPtr);
	}

	class playerWarLords :
		public _auto_player
	{
		public:
			enum
			{
				AttackTimes = 20,
				MaxReport = 10,
				BaseCd = 10 * 60,
				AddCd = 2 * 60,
				MaxCd = 60 * 60,
				AddCdStartCount = 3,
			};

			playerWarLords(playerData* const own);

			void setData(mongo::BSONObj& obj);
			virtual bool _auto_save();
			virtual void _auto_update();

			void update();
			void tick();
			void getTable(int nation, Json::Value& r);
			void getReportInfo(Json::Value& info);

			unsigned getCd() const { return cd; }
			bool inSearchCd();
			int getTitle(int nation) const;
			const std::vector<int>& getEvilValue() const { return evil_value; }
			unsigned getAttackTimes() const { return AttackTimes - attack_times; }
			
			std::string addNpcRep(unsigned now, const std::string& name, O2ORes& res);

			std::string atkAddReport(unsigned now, playerDataPtr target, O2ORes& res, const Json::Value& reward);
			std::string defAddReport(unsigned now, playerDataPtr target, O2ORes& res, const Json::Value& reward);
			
			int addFame(int val);
			void clearRedPoint(const WarLords::ReportPtr& ptr);
			void updateRedPoint(bool check);

			int setMessage(const std::string& str);

		private:
			void setAndUpdateRedPoint(bool rp);

			std::string getReportId(bool atk_side);
			std::string addRep(unsigned now, playerDataPtr target, O2ORes& res, const Json::Value& reward, bool attack_side);

			void resetCd(unsigned now);
			void clearCd();
			void addEvilValue(int nation);
			void subEvilValue(int nation);
			void alterEvilValue(int nation, int val);

		private:
			unsigned attack_times;
			unsigned defense_times;
			unsigned defense_lose_times;
			unsigned cd;
			unsigned search_cd;
			bool red_point;
			std::vector<int> evil_value;
			unsigned atk_report_id;
			unsigned def_report_id;
			ReportMgr<WarLords::Report> atk_report_mgr;
			ReportMgr<WarLords::Report> def_report_mgr;
			bool default_msg;
			std::string msg;
	};
}

#include "inter_title.h"
#include "dbDriver.h"

namespace gg
{
	playerInterTitle::playerInterTitle(playerData* const own) : _auto_player(own)
	{
		_begin_time = 0;
		_end_time = 0;
		_title_type = 0xFFFFFFFF;
	}

	int playerInterTitle::getTitle()
	{
		const unsigned now = Common::gameTime();
		if (now >= _begin_time && now <= _end_time)
		{
			return _title_type;
		}
		return -1;
	}

	void playerInterTitle::setTitle(const unsigned begin, const unsigned end, const unsigned title)
	{
		if (begin >= end)return;
		const unsigned now = Common::gameTime();
		if (now > end)return;
		if (end <= _end_time)return;
		_begin_time = begin;
		_end_time = end;
		_title_type = title;
		_sign_auto();
	}
	
	void playerInterTitle::setData(mongo::BSONObj& obj)
	{
		if (obj.isEmpty())return;
		_begin_time = obj["bg"].Int();
		_end_time = obj["ed"].Int();
		_title_type = obj["tl"].Int();
	}

	bool playerInterTitle::_auto_save()
	{
		mongo::BSONObj key = BSON(strPlayerID << Own().ID());
		mongo::BSONObj obj = BSON("$set" << BSON("InterTitle" <<
			BSON("bg" << _begin_time << "ed" << _end_time << "tl" << _title_type)
		));
		return db_mgr.SaveMongo(DBN::dbPlayerCollection, key, obj);
	}
}
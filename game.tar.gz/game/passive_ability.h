#pragma once

#include "passive_def.h"
#include "commom.h"

#define passive_mgr (*gg::passiveManager::_Instance)

namespace gg
{
	class passiveManager
	{
	public:
		static passiveManager* const _Instance;

		void initData();
		bool combinePassive(passiveData& main, passiveData& branch);
		const passiveData& getPassive(const int ID);
	private:
		typedef boost::function< bool(passiveData&, passiveData&) > functionCombine;
		typedef boost::unordered_map< int, functionCombine > combineMap;
		combineMap mapCombine;
		typedef boost::unordered_map<int, passiveData> passiveMap;
		passiveMap mapPassive;
	};
}
#pragma once

#include "auto_base.h"
#include "mongoDB.h"

namespace gg
{
	class playerData;
	BOOSTSHAREPTR(playerData, playerDataPtr);

	namespace KingdomWar
	{
		namespace Task
		{
			enum PARAM_TYPE
			{
				INT_ARRAY = 1,
			};

			class IParam
			{
				public:
					virtual int type() const = 0;
					virtual mongo::BSONArray toBSON() const = 0;
					virtual void getInfo(qValue& q) const = 0;
			};
			BOOSTSHAREPTR(IParam, ParamPtr);

			class IntArray
				: public IParam
			{
				public:
					IntArray(){}
					IntArray(const mongo::BSONElement& obj)
					{
						std::vector<mongo::BSONElement> ele = obj.Array();
						for (unsigned i = 1; i < ele.size(); ++i)
							_values.push_back(ele[i].Int());
					}
					virtual int type() const { return INT_ARRAY; }
					virtual mongo::BSONArray toBSON() const
					{
						mongo::BSONArrayBuilder b;
						b.append(type());
						for(unsigned i = 0; i < _values.size(); ++i)
							b.append(_values[i]);
						return b.arr();
					}
					virtual void getInfo(qValue& q) const
					{
						for(unsigned i = 0; i < _values.size(); ++i)
							q.append(_values[i]);
					}

					int& operator[](int idx)
					{
						return _values[idx];
					}

					std::vector<int> _values;
			};
			BOOSTSHAREPTR(IntArray, IntArrayPtr);

			enum PERSONAL_TASK_TYPE
			{
				Empty = 0,
				BattleTimes,
				WinStreakTimes,
				GetExploit,
				UseFood,
				CallAttackNpc,
				CallDefenseNpc,
				CallAdvancedNpc,
				UseItemTimes,
				KillNum,
				PTMax,
			};

			class ICheck
			{
				public:
					ICheck(int type): _type(type){}
					int type() const { return _type; }
					virtual int init(playerDataPtr d, ParamPtr& param) = 0;
					virtual int update(playerDataPtr d, ParamPtr& param, const Json::Value& arg) = 0;
				private:
					int _type;
			};
			BOOSTSHAREPTR(ICheck, CheckPtr);

			enum NATION_TASK_TYPE
			{
				OccupySpecified = Empty + 1,
				GetExploit2,
				OccupyNum1,
				OccupyNum2,
				NTMax,
			};

			class ICheck2
			{
				public:
					ICheck2(int type): _type(type){}
					int type() const { return _type; }
					virtual int update(int nation, ParamPtr& param, const Json::Value& arg) = 0;
					virtual int init(int nation, ParamPtr& param) = 0;
				private:
					int _type;
			};
			BOOSTSHAREPTR(ICheck2, CheckPtr2);

			class ICheckFactory
			{
				SINGLETON(ICheckFactory);
				typedef boost::function<CheckPtr(const Json::Value&)> CreateFunc;
				typedef boost::function<CheckPtr2(const Json::Value&)> CreateFunc2;
				public:
					CheckPtr Get(const Json::Value& info);
					CheckPtr2 Get2(const Json::Value& info);
				private:
					CreateFunc _creator_map[PTMax];
					CreateFunc2 _creator_map2[NTMax];
			};

			ParamPtr GetParam(const mongo::BSONElement& obj);

#define PCHECKER(name)\
	class name\
		: public ICheck\
	{\
		public:\
			static CheckPtr create(const Json::Value& info)\
			{\
				return Creator<name>::Create(info);\
			}\
			name(const Json::Value& info)\
				: ICheck(info["type"].asInt())\
			{\
				ForEachC(Json::Value, it, info["arg"])\
					_args.push_back((*it).asInt());\
			}\
			virtual int update(playerDataPtr d, ParamPtr& param, const Json::Value& arg);\
			virtual int init(playerDataPtr d, ParamPtr& param);\
			std::vector<int> _args;\
	}

			PCHECKER(CBattleTimes);
			PCHECKER(CWinStreakTimes);
			PCHECKER(CGetExploit);
			PCHECKER(CUseFood);
			typedef CBattleTimes CCallAttackNpc;
			typedef CBattleTimes CCallDefenseNpc;
			typedef CBattleTimes CCallAdvancedNpc;
			PCHECKER(CUseItemTimes);
			PCHECKER(CKillNum);

#define NCHECKER(name)\
	class name\
		: public ICheck2\
	{\
		public:\
			static CheckPtr2 create(const Json::Value& info)\
			{\
				return Creator<name>::Create(info);\
			}\
			name(const Json::Value& info)\
				: ICheck2(info["type"].asInt())\
			{\
				ForEachC(Json::Value, it, info["arg"])\
					_args.push_back((*it).asInt());\
			}\
			virtual int update(int nation, ParamPtr& param_ptr, const Json::Value& arg);\
			virtual int init(int nation, ParamPtr& param_ptr);\
		protected:\
			std::vector<int> _args;\
	}

			class COccupySpecified
				: public ICheck2
			{
				public:
					STDVECTOR(int, IDList);
					static CheckPtr2 create(const Json::Value& info)
					{
						return Creator<COccupySpecified>::Create(info);
					}
					COccupySpecified(const Json::Value& info)
						: ICheck2(info["type"].asInt())
					{
						ForEachC(Json::Value, it, info["arg"])
						{
							const Json::Value& id_list = *it;
							IDList tmp;
							ForEachC(Json::Value, itl, id_list)
								tmp.push_back((*itl).asInt());
							_args.push_back(tmp);
						}
					}
					virtual int update(int nation, ParamPtr& param_ptr, const Json::Value& arg);
					virtual int init(int nation, ParamPtr& param_ptr);
					std::vector<IDList> _args;
			};

			NCHECKER(CGetExploit2);
			NCHECKER(COccupyNum);
			typedef COccupyNum COccupyNum1;
			typedef COccupyNum COccupyNum2;
		}
	}
}

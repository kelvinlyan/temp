#include "kingdomwar_task.h"
#include "kingdomwar_city.h"
#include "kingdomwar_system.h"
#include "playerManager.h"
#include "kingdom_system.h"
#include "heroparty_system.h"

namespace gg
{
	namespace KingdomWar
	{
		PersonalTask::PersonalTask(const Json::Value& info)
		{
			_id = info["id"].asInt();
			_weight = info["weight"].asInt();
			_checker = Task::ICheckFactory::shared().Get(info);
			_reward = info["reward"];
			_reward70 = info["reward70"].asInt();
		}

		int PersonalTask::init(playerDataPtr d, Task::ParamPtr& param)
		{
			return _checker->init(d, param);
		}

		int PersonalTask::update(playerDataPtr d, Task::ParamPtr& param, const Json::Value& arg)
		{
			return _checker->update(d, param, arg);
		}

		ActionBoxList PersonalTask::reward(playerDataPtr d) const
		{
			ActionBoxList rw;
			int task_lv = d->KingDomWarTask().taskLv();
			int arg1 = _reward[0u].asInt();
			int arg2 = _reward[1u].asInt();
			int arg3 = _reward[2u].asInt();
			int arg4 = _reward[3u].asInt();
			{
				ACTION::Box b;
				b.actionID = ACTION::silver;
				b.boxData._Res.val = task_lv * arg1 + arg2;
				rw.push_back(b);
			}
			{
				ACTION::Box b;
				b.actionID = ACTION::exploit_coin;
				b.boxData._Res.val = task_lv * arg3 + arg4;
				rw.push_back(b);
			}
			{
				ACTION::Box b;
				b.actionID = ACTION::item;
				b.boxData._Item.itemID = 10005;
				b.boxData._Item.num = 5;
				rw.push_back(b);
			}
			if (d->LV() >= 70)
			{
				ACTION::Box b;
				b.actionID = ACTION::reputation;
				b.boxData._Res.val = _reward70;
				rw.push_back(b);
			}
			return rw;
		}
		/*
		int PersonalTask::target() const
		{
			return 0;
			switch(type())
			{
				case BattleTimes:
				{
					boost::shared_ptr<CBattleTimes> check_ptr = upCast<CBattleTimes>(_checker);
					return check_ptr->_args[0u];
				}
				case WinStreakTimes:
				{
					boost::shared_ptr<CWinStreakTimes> check_ptr = upCast<CWinStreakTimes>(_checker);
					return check_ptr->_args[0u];
				}
				case GetExploit:
				case UseFood:
				{
					TwoInt& param = *(upCast<TwoInt>(_param));
					return param[1];
				}
				default:
					return 0;
			}
		}
		*/

		PersonalTaskMgr::PersonalTaskMgr()
		{
			Json::Value json = Common::loadJsonFile("./instance/kingdom_war/personal_task.json");
			ForEach(Json::Value, it, json)
			{
				_total_weight += (*it)["weight"].asUInt();
				_task_map.insert(make_pair((*it)["id"].asInt(), Creator<PersonalTask>::Create(*it)));
			}
		}

		PersonalTaskPtr PersonalTaskMgr::Get(int id) const
		{
			TaskMap::const_iterator it = _task_map.find(id);
			return it == _task_map.end()? PersonalTaskPtr() : it->second;
		}

		void PersonalTaskMgr::eraseType(std::list<PersonalTaskPtr>& task_list, int type) const
		{
			for (std::list<PersonalTaskPtr>::iterator it = task_list.begin(); it != task_list.end();)
			{
				if ((*it)->type() == type)
					task_list.erase(it++);
				else
					++it;
			}
		}

		PersonalTaskPtr PersonalTaskMgr::tryGetOne(std::list<PersonalTaskPtr>& task_list) const
		{
			unsigned total_weight = 0;
			for (std::list<PersonalTaskPtr>::iterator it = task_list.begin(); it != task_list.end(); ++it)
				total_weight += (*it)->_weight;
			unsigned val = Common::randomUInt(1, total_weight);
			unsigned tmp = 0;
			for (std::list<PersonalTaskPtr>::iterator it = task_list.begin(); it != task_list.end(); ++it)
			{
				if (val <= (*it)->_weight + tmp)
				{
					PersonalTaskPtr ret = *it;
					eraseType(task_list, (*it)->type());
					return ret;
				}
				else
				{
					tmp += (*it)->_weight;
				}
			}
			return PersonalTaskPtr();
		}

		std::vector<PersonalTaskPtr> PersonalTaskMgr::rand() const
		{
			std::vector<PersonalTaskPtr> rand_list;
			std::list<PersonalTaskPtr> all_task;
			ForEachC(TaskMap, it, _task_map)
				all_task.push_back(it->second);
			unsigned total_weight = _total_weight;
			while (rand_list.size() < 3)
			{
				PersonalTaskPtr ptr = tryGetOne(all_task);
				if (!ptr)
					break;
				rand_list.push_back(ptr);
			}
			return rand_list;
		}

		PersonalRecord::PersonalRecord(const mongo::BSONElement& obj)
		{
			int id = obj["i"].Int();
			_state = obj["s"].Int();
			_param = Task::GetParam(obj["p"]);
			_task_ptr = PersonalTaskMgr::shared().Get(id);
		}

		PersonalRecord::PersonalRecord(PersonalTaskPtr task_ptr, playerDataPtr d)
		{
			_task_ptr = task_ptr;
			_state = _task_ptr->init(d, _param);
		}

		mongo::BSONObj PersonalRecord::toBSON() const 
		{
			if (!_task_ptr)
				return BSON("i" << -1);
			else
				return BSON("i" << id() << "s" << _state << "p" << _param->toBSON());
		}

		int PersonalRecord::id() const
		{
			if (!_task_ptr)
				return -1;
			return _task_ptr->id();
		}

		int PersonalRecord::type() const
		{
			if (!_task_ptr)
				return -1;
			return _task_ptr->type();
		}

		void PersonalRecord::update(playerDataPtr d, const Json::Value& arg)
		{
			_state = _task_ptr->update(d, _param, arg);
		}

		int PersonalRecord::getReward(playerDataPtr d, Json::Value& r)
		{
			if (_state != gg::Task::Finished)
				return err_illedge;
			ActionBoxList rw = _task_ptr->reward(d);
			int res = actionDoBox(d, rw, false);
			if (res == res_sucess)
			{
				r[1u] = actionRes();
				_state = gg::Task::Rewarded;
			}
			else
			{
				Json::Value error_code = actionError();
				res = error_code[0u][1u].asInt();
			}
			return res;
		}

		void PersonalRecord::getInfo(qValue& q) const
		{
			if (!_task_ptr)
				q.append(-1);
			else
			{
				q.append(id());
				q.append(_state);
				qValue p;
				_param->getInfo(p);
				q.append(p);
			}
		}

		int PersonalRecord::schedule() const
		{
			if (!_task_ptr)
				return -1;
			Task::IntArray& param = *(upCast<Task::IntArray>(_param));
			return param[0];
		}

		int PersonalRecord::target() const
		{
			if (!_task_ptr)
				return -1;
			//return _task_ptr->target();
			return 0;
		}

		NationTask::NationTask(const Json::Value& info)
		{
			_id = info["id"].asInt();
			_weight = info["weight"].asInt();
			const Json::Value& task = info["task"];
			for (unsigned i = 0; i < Kingdom::nation_num; ++i)
				_checker.push_back(Task::ICheckFactory::shared().Get2(task[i]));
			_reward = info["reward"];
			_reward70 = info["reward70"].asInt();
		}

		int NationTask::init(int nation, int strength, Task::ParamPtr& param)
		{
			return _checker[strength]->init(nation, param);
		}

		int NationTask::update(int nation, int strength, Task::ParamPtr& param, const Json::Value& arg)
		{
			return _checker[strength]->update(nation, param, arg);
		}

		int NationTask::type(int strength) const
		{
			return _checker[strength]->type();
		}

		ActionBoxList NationTask::reward(playerDataPtr d) const
		{
			ActionBoxList rw;
			int arg1 = _reward[0u].asInt();
			int arg2 = _reward[1u].asInt();
			int arg3 = _reward[2u].asInt();
			int arg4 = _reward[3u].asInt();
			NationRecordPtr ptr = NationTaskMgr::shared().getRecord(d->Info().Nation());
			if (!ptr) return rw;
			int nation_lv = ptr->nationLv();
			{
				ACTION::Box b;
				b.actionID = ACTION::silver;
				b.boxData._Res.val = nation_lv * arg1 + arg2;
				rw.push_back(b);
			}
			{
				ACTION::Box b;
				b.actionID = ACTION::exploit_coin;
				b.boxData._Res.val = nation_lv * arg3 + arg4;
				rw.push_back(b);
			}
			if (d->LV() >= 70)
			{
				ACTION::Box b;
				b.actionID = ACTION::reputation;
				b.boxData._Res.val = _reward70;
				rw.push_back(b);
			}
			return rw;
		}

		NationRecord::NationRecord(int nation)
			: _nation(nation)
		{
		}

		void NationRecord::loadDB()
		{
			mongo::BSONObj key = BSON("nt" << _nation);
			mongo::BSONObj obj = db_mgr.FindOne(DBN::dbKingdomWarNationTask, key);
			if (obj.isEmpty())
				return;

			int id = obj["i"].Int();
			if (id == -1)
				return;

			_task_ptr = NationTaskMgr::shared().getTask(id);
			_state = obj["s"].Int();
			_param = Task::GetParam(obj["p"]);
			_strength = obj["st"].Int();
			_nation_lv = obj["nl"].Int();
		}

		bool NationRecord::_auto_save()
		{
			mongo::BSONObj key = BSON("nt" << _nation);
			mongo::BSONObjBuilder obj;
			obj << "nt" << _nation << "i" << id();
			if (id() != -1)
				obj << "s" << _state << "p" << _param->toBSON() << "st" << _strength << "nl" << _nation_lv;
			return db_mgr.SaveMongo(DBN::dbKingdomWarNationTask, key, obj.obj());
		}

		int NationRecord::id() const
		{
			if (!_task_ptr)
				return -1;
			return _task_ptr->id();
		}

		ActionBoxList NationRecord::reward(playerDataPtr d) const
		{
			if (!_task_ptr)
				return ActionBoxList();
			return _task_ptr->reward(d);
		}

		int NationRecord::type() const
		{
			if (!_task_ptr)
				return KingdomWar::Task::Empty;
			return _task_ptr->type(_strength);
		}

		void NationRecord::update(int type, const Json::Value& arg)
		{
			if (!_task_ptr)
				return;
			if (this->type() != type)
				return;
			int s = _task_ptr->update(_nation, _strength, _param, arg);
			if (s != gg::Task::NoChanged)
			{
				_state = s;
				_sign_save();
			}
			if (_state == gg::Task::Finished)
			{
				playerManager::playerDataVec vec = player_mgr.nationOnline((Kingdom::NATION)_nation);
				ForEach(playerManager::playerDataVec, it, vec)
					(*it)->KingDomWarTask().resetNationTaskRPAndUpdate();
			}
		}

		int NationRecord::getSchedule()
		{
			if (!_task_ptr || !_param)
				return -1;
			switch(type())
			{
				case Task::OccupySpecified:
				{
					Task::IntArrayPtr ptr = upCast<Task::IntArray>(_param);
					return ptr->_values.size();
				}
				case Task::GetExploit2:
				case Task::OccupyNum1:
				case Task::OccupyNum2:
				{
					Task::IntArray& param = *(upCast<Task::IntArray>(_param));
					return param[0];
				}
				default:
					return 0;
			}
		}

		int NationRecord::getTarget()
		{
			/*
			if (!_task_ptr || !_param)
				return -1;
			switch(type())
			{
				case Task::OccupySpecified:
				{
					boost::shared_ptr<Task::COccupySpecified> ptr = upCast<Task::COccupySpecified>(_checker);
					return ptr->_args[_nation].size();
				}
				case Task::GetExploit2:
				case Task::OccupyNum1:
				case Task::OccupyNum2:
				{
					Task::IntArray& param = *(upCast<Task::IntArray>(_param));
					return param[1];
				}
				default:
					return 0;
			}
			*/
			return 0;
		}

		void NationRecord::reset(int strength, const NationTaskPtr& task_ptr)
		{
			_strength = strength;
			_nation_lv = kingdom_sys.getData(_nation)->getLevel();
			_task_ptr = task_ptr;
			_state = _task_ptr->init(_nation, _strength, _param);
			_sign_save();
		}

		void NationRecord::clear()
		{
			_task_ptr.reset();
			_state = gg::Task::Running;
			_sign_save();
		}

		void NationRecord::getInfo(playerDataPtr d, qValue& q) const
		{
			q.append(id());
			if (id() != -1)
			{
				q.append(_state == gg::Task::Running? _state : d->KingDomWarTask().nationTaskState() == 1? gg::Task::Rewarded : gg::Task::Finished);
				qValue p;
				_param->getInfo(p);
				q.append(p);
				q.append(_strength);
				q.append(_nation_lv);
			}
		}

		void NationRecord::stop(unsigned cur_time)
		{
			if (!_task_ptr)
				return;
			Log(DBLOG::strLogKingdomWar, 9, cur_time, _nation, type(), getSchedule(), getTarget());
			if (_state == gg::Task::Finished)
			{
				playerManager::playerDataVec vec = player_mgr.nationOnline((Kingdom::NATION)_nation);
				ForEach(playerManager::playerDataVec, it, vec)
					(*it)->KingDomWarTask().resetNationTaskRPAndUpdate();
			}
		}

		NationTaskMgr::NationTaskMgr()
		{
			for (unsigned i = 0; i < Kingdom::nation_num; ++i)
				_record_list.push_back(Creator<NationRecord>::Create(i));
			loadFile();
		}

		void NationTaskMgr::loadFile()
		{
			Json::Value json = Common::loadJsonFile("./instance/kingdom_war/nation_task.json");
			ForEach(Json::Value, it, json)
			{
				NationTaskPtr ptr = Creator<NationTask>::Create(*it);
				_task_map.insert(make_pair(ptr->id(), ptr));
				int rand_type = (*it)["randtype"].asInt();
				_total_weight[rand_type] += (*it)["weight"].asUInt();
				_rand_task[rand_type].push_back(ptr);
			}
		}

		void NationTaskMgr::loadDB()
		{
			for (unsigned i = 0; i < Kingdom::nation_num; ++i)
				_record_list[i]->loadDB();
		}

		NationTaskPtr NationTaskMgr::rand(int type) const
		{
			unsigned val = Common::randomUInt(1, _total_weight[type]);
			unsigned tmp = 0;
			ForEachC(TaskList, it, _rand_task[type])
			{
				if (val <= (*it)->_weight + tmp)
					return *it;
				else
					tmp += (*it)->_weight;
			}
			return NationTaskPtr();
		}

		struct Strength
		{
			Strength(int n, int c)
				: nation(n), city_num(c){}
			bool operator<(const Strength& s) const
			{
				if (city_num == s.city_num)
					return nation < s.nation;
				return city_num > s.city_num;
			}
			int nation;
			int city_num;
		};

		static int randType(const std::vector<Strength>& sort_strength)
		{
			if (sort_strength[0].city_num == sort_strength[1].city_num
					&& sort_strength[1].city_num == sort_strength[2].city_num)
				return 0;
			if (sort_strength[0].city_num == sort_strength[1].city_num)
				return 1;
			if (sort_strength[1].city_num == sort_strength[2].city_num)
				return 2;
			return 3;
		}

		void NationTaskMgr::reset()
		{
			std::vector<Strength> sort_strength;
			for (unsigned i = 0; i < Kingdom::nation_num; ++i)
				sort_strength.push_back(Strength(i, CityCounter::shared().num(i)));
			std::sort(sort_strength.begin(), sort_strength.end());
			int type = randType(sort_strength);
			NationTaskPtr ptr = rand(type);
			for (unsigned i = 0; i < Kingdom::nation_num; ++i)
				_record_list[sort_strength[i].nation]->reset(i, ptr);
		}

		void NationTaskMgr::clear()
		{
			for (unsigned i = 0; i < _record_list.size(); ++i)
				_record_list[i]->clear();
		}

		void NationTaskMgr::start(unsigned cur_time)
		{
			reset();
			for (unsigned i = 0; i < _record_list.size(); ++i)
			{
				update(Task::OccupySpecified, i, Json::Value(1));
				update(Task::OccupyNum1, i, Json::Value(1));
				update(Task::OccupyNum2, i, Json::Value(1));

				playerManager::playerDataVec vec = player_mgr.nationOnline((Kingdom::NATION)i);
				ForEach(playerManager::playerDataVec, it, vec)
					(*it)->KingDomWarTask().resetNationTaskRPAndUpdate();
			}
			TaskParamHelper::shared().clear();
		}

		void NationTaskMgr::stop(unsigned cur_time)
		{
			for (unsigned i = 0; i < _record_list.size(); ++i)
			{
				update(Task::OccupySpecified, i, Json::Value(0));
				update(Task::OccupyNum1, i, Json::Value(0));
				update(Task::OccupyNum2, i, Json::Value(0));
				_record_list[i]->stop(cur_time);
			}
		}

		void NationTaskMgr::getInfo(playerDataPtr d, qValue& q) const
		{
			_record_list[d->Info().Nation()]->getInfo(d, q);
		}

		TaskParamHelper::TaskParamHelper()
		{
			loadDB();
		}

		void TaskParamHelper::loadDB()
		{
			mongo::BSONObj key = BSON("nt" << -1);
			mongo::BSONObj obj = db_mgr.FindOne(DBN::dbKingdomWarNationTask, key);
			if (obj.isEmpty())
				return;

			std::vector<mongo::BSONElement> ele = obj["ps"].Array();
			for (unsigned i = 0; i < ele.size(); ++i)
				_player_set.insert(ele[i].Int());
		}

		bool TaskParamHelper::_auto_save()
		{
			mongo::BSONObj key = BSON("nt" << -1);
			mongo::BSONObjBuilder obj;
			obj << "nt" << -1;
			{
				mongo::BSONArrayBuilder b;
				ForEachC(std::set<int>, it, _player_set)
					b.append(*it);
				obj << "ps" << b.arr();
			}
			return db_mgr.SaveMongo(DBN::dbKingdomWarNationTask, key, obj.obj());
		}

		void TaskParamHelper::update(int pid)
		{
			if (!PrimeState::shared())
				return;
			if (_player_set.find(pid) != _player_set.end())
				return;
			_player_set.insert(pid);
			_sign_save();
		}

		void TaskParamHelper::clear()
		{
			_player_set.clear();
			_sign_save();
		}
	}
}

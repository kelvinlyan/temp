//###################################
//create by Cai
//2016-04-07
//###################################

#pragma once

#include "auto_base.h"
#include "email.h"

namespace gg
{
	class playerEmail
		: public _auto_player
	{
		public:
			STDLIST(EmailPtr, EmailList);

			playerEmail(playerData* const own);
			
			virtual bool _auto_save();
			virtual void _auto_update();

			Json::Value getEmailList();
			Json::Value getEmailList(unsigned begin, unsigned num);
			int removeEmail(int id);
			int getPackage(int id, Json::Value& r);
			void addEmail(EmailPtr& e);
			void addCommonEmail();
			void updateRedPoint(bool check = false);
			std::string getRepId();

		private:
			virtual void classLoad();
			bool getRedPoint();
			unsigned getId();
			void doAddEmail(const EmailPtr& e);
			void findEmailList(const EmailList& email_list, unsigned& cur_pos, unsigned& begin, unsigned end, Json::Value& el);

		private:
			bool _red_point;
			unsigned _rep_id;
				
			unsigned _owner_email_id;
			unsigned _common_email_id;
			EmailList _email_list[EmailDef::TypeMax];
	};
}

//###################################
//create by Jim
//2017-03-27
//###################################

#pragma once 

#include "dbDriver.h"

#define activity_player_sys (*gg::ActivityPlayer::_Instance)

namespace gg
{
	class ActivityPlayer
	{
	public:
		static ActivityPlayer* const _Instance;
		void initData();
		inline unsigned lastActivityPlayer() { return _last_activity; }
		void tickActivityPlayer();
		void on5ClockUpdate();
	private:
		void save();
		unsigned _last_activity;
		unsigned _now_activity;
	};
}
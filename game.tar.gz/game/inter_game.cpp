#include "inter_game.h"
#include "game_server.h"
#include "game_inter_protocol.h"
#include "email_system.h"
#include "net_helper.hpp"
#include "heroparty_system.h"
#include "chat.h"

namespace gg
{
	//�׻�����
	static std::vector<unsigned> VipFlowerNum;//vip�����׻���

	//��������λ����
	struct DanLadder
	{
		int _begin_point;
		int _end_point;
		Json::Value _email_reward;
	};
	static std::vector<DanLadder> DanLadderBalanceList;
	//������ǿ�߽���
	static std::vector<Json::Value> PromoteBalanceList;
	//�������׻�����
	typedef std::map<int, Json::Value> TypeFlowerBalanceMap;
	static TypeFlowerBalanceMap FlowerBalanceMap;

	InterGame* const InterGame::_Instance = new InterGame();

	void InterGame::initData()
	{
		inter_event_list = "{\"msg\":[0]}";
		{//�׻�
			Json::Value json = Common::loadJsonFile("./instance/inter/flower.json");
			VipFlowerNum.clear();
			for (unsigned i = 0; i < json.size(); ++i)
			{
				VipFlowerNum.push_back(json[i].asUInt());
			}
		};
		{//��������λ����
			Json::Value json = Common::loadJsonFile("./instance/inter/dan_ladder_balance.json");
			DanLadderBalanceList.clear();
			for (unsigned i = 0; i < json.size(); ++i)
			{
				Json::Value& single_json = json[i];
				DanLadder ladder;
				ladder._begin_point = single_json["begin"].asInt();
				ladder._end_point = single_json["end"].asInt();
				ladder._email_reward = single_json["reward"];
				DanLadderBalanceList.push_back(ladder);
			}
		};
		{//��������������
			Json::Value json = Common::loadJsonFile("./instance/inter/promote_balance.json");
			PromoteBalanceList.clear();
			for (unsigned i = 0; i < json.size(); ++i)
			{
				Json::Value& single_json = json[i];
				PromoteBalanceList.push_back(single_json);
			}
		};
		{//�������׻�����
			Json::Value json = Common::loadJsonFile("./instance/inter/flower_balance.json");
			FlowerBalanceMap.clear();
			for (unsigned i = 0; i < json.size(); ++i)
			{
				Json::Value& single_json = json[i];
				const unsigned num = single_json["num"].asUInt();
				Json::Value str_reward = single_json["reward"];
				FlowerBalanceMap[num] = str_reward;
			}
		};
		{//���ս����
			inter_ip = "";
			inter_port = "";
			inter_report_port = "";
			inter_server_name = "";//���ս��
			inter_server_id = -1;//���սid
			mongo::BSONObj obj = db_mgr.FindOne(DBN::dbInterServerGame, BSON("key" << 0));
			if (!obj.isEmpty())
			{
				inter_ip = obj["ip"].String();
				inter_port = obj["port"].String();
				inter_report_port = obj["report_port"].String();
				inter_server_name = obj["sn"].String();
				inter_server_id = obj["sid"].Int();
			}
		};
		connect_inter_server();
	}

	void InterGame::updateAllWarFm(net::Msg& m, Json::Value& r)
	{
		playerDataPtr player = player_mgr.getPlayer(m.playerID);
		if (!player)Return(r, err_illedge);
		player->InterFM().updateAll();
		Return(r, res_sucess);
	}

	void InterGame::updateSingleWarFm(net::Msg& m, Json::Value& r)
	{
		playerDataPtr player = player_mgr.getPlayer(m.playerID);
		if (!player)Return(r, err_illedge);
		ReadJsonArray;
		int fmID = js_msg[0u].asInt();
		player->InterFM().updateSingle(fmID);
	}

	void InterGame::warFormatDefalut(net::Msg& m, Json::Value& r)
	{
		playerDataPtr player = player_mgr.getPlayer(m.playerID);
		if (!player)Return(r, err_illedge);
		ReadJsonArray;
		int fID = js_msg[0u].asInt();
		Return(r, player->InterFM().defaultFM(fID));
	}

	void InterGame::warFmFormat(net::Msg& m, Json::Value& r)
	{
		playerDataPtr player = player_mgr.getPlayer(m.playerID);
		if (!player)Return(r, err_illedge);
		ReadJsonArray;
		int fID = js_msg[0u].asInt();
		int fm[9];
		for (unsigned i = 0; i < 9; ++i)
		{
			fm[i] = js_msg[1u][i].asInt();
		}
		Return(r, player->InterFM().format(fID, fm));
	}

	void InterGame::sendInterConfig(playerDataPtr player)
	{
		Json::Value json = Json::objectValue;
		Json::Value& data_json = json[strMsg] = Json::arrayValue;
		data_json.append(res_sucess);
		data_json.append(inter_ip);
		data_json.append(inter_report_port);
		data_json.append(inter_server_name);
		player->sendToClient(gate_client::inter_server_config_resp, json);
	}

	void InterGame::interGameConfig(net::Msg& m, Json::Value& r)
	{
		Json::Value& data_json = r[strMsg] = Json::arrayValue;
		data_json.append(res_sucess);
		data_json.append(inter_ip);
		data_json.append(inter_report_port);
		data_json.append(inter_server_name);
	}

	void InterGame::interEventList(net::Msg& m, Json::Value& r)
	{
		::net::Msg msg(m.playerID, service::process_id::INVAILD_PLAYER_ID, inter_game::update_event_list_resp, inter_event_list);
		game_svr->async_send_to_gate(msg);
	}

	//req
	void InterGame::req_common(net::Msg& m, Json::Value& r)
	{
		m.netID = Common::serverID();
		game_svr->async_send_to_inter(m);
	}
	void InterGame::req_limit_common(net::Msg& m, Json::Value& r)
	{
		playerDataPtr player = player_mgr.getPlayer(m.playerID);
		if (!player)return;
		if (player->LV() < 30)Return(r, err_lv_not_enough);
		req_common(m, r);
	}
	void InterGame::req_sync_battle_data(net::Msg& m, Json::Value& r)
	{
		playerDataPtr player = player_mgr.getPlayer(m.playerID);
		if (!player)return;
		Json::Value json = Json::objectValue;
		Json::Value& info_json = json["info"];
		info_json.append(player->Name());
		info_json.append(player->LV());
		info_json.append(player->Info().Face());
		info_json.append(player->Info().Nation());
		info_json.append(player->InterFM().currentBV());
		info_json.append(player->Military().level());
		info_json.append(player->War().lastWinMap());
		info_json.append(heroparty_sys.getRankNo_(player->ID()));
		info_json.append(player->Info().UsedName());
		json["man"] = player->InterFM().uploadFormatJson();
		string str_send = json.toIndentString();
		net::Msg msg(m.playerID, Common::serverID(), m.protocolID, str_send);
		game_svr->async_send_to_inter(msg);
	}
	void InterGame::req_register_inter_game(net::Msg& m, Json::Value& r)
	{
		playerDataPtr player = player_mgr.getPlayer(m.playerID);
		if (!player)return;
		if (player->LV() < 60)Return(r, err_lv_not_enough);
		Json::Value json = Json::arrayValue;
		json.append(player->Name());
		json.append(player->LV());
		json.append(player->Info().Face());
		json.append(player->Info().Nation());
		json.append(player->Info().MaxBV());
		json.append(player->Military().level());
		json.append(player->War().lastWinMap());
		json.append(heroparty_sys.getRankNo_(player->ID()));
		json.append(player->Info().UsedName());
		string str_send = json.toIndentString();
		net::Msg msg(m.playerID, Common::serverID(), m.protocolID, str_send);
		game_svr->async_send_to_inter(msg);
	}
	void InterGame::req_share_inter_report(net::Msg& m, Json::Value& r)
	{
		playerDataPtr player = player_mgr.getPlayer(m.playerID);
		if (!player)return;
		if (player->LV() < 30)Return(r, err_lv_not_enough);
		const unsigned now = Common::gameTime();
		if (player->ShareLastCD > now)Return(r, err_share_last_rep_cd_limit);
		player->ShareLastCD = now + 15;
		ReadJsonArray;
		const int type = js_msg[0u].asInt();
		if (0 == type)
		{
			req_common(m, r);
		}
		else
		{
			Json::Value json;
			json.append(js_msg);
			chat_sys.despatchAll(CHAT::inter_game_report_share, json, CHATPOS::chat_windows);
			Return(r, res_sucess);
		}
	}
	void InterGame::req_use_flower(net::Msg& m, Json::Value& r)
	{
		playerDataPtr player = player_mgr.getPlayer(m.playerID);
		if (!player)return;
		if (player->LV() < 30)Return(r, err_lv_not_enough);
		ReadJsonArray;
		Json::Value trans_json;
		trans_json[strMsg][0u] = js_msg[0u];
		trans_json[strMsg][1u] = VipFlowerNum[player->Info().VipLv()];
		string str_send = trans_json.toIndentString();
		net::Msg msg(m.playerID, Common::serverID(), m.protocolID, str_send);
		game_svr->async_send_to_inter(msg);
	}

	//resp
	void InterGame::resp_common(net::Msg& m, Json::Value& r)
	{
		playerDataPtr player = player_mgr.getOnlinePlayer(m.playerID);
		//cout << "recv message" << m.protocolID << endl;
		if (player)
		{
			m.netID = service::process_id::INVAILD_PLAYER_ID;
			player_mgr.sendToPlayer(m);
		}
	}
	void InterGame::resp_register_inter_game(net::Msg& m, Json::Value& r)
	{
		//���ﴦ����
		playerDataPtr player = player_mgr.getPlayer(m.playerID);
		if (!player)return;
		player->InterFM().tryFullDefalut();
		resp_common(m, r);
	}
	void InterGame::resp_sync_battle_data(net::Msg& m, Json::Value& r)
	{
		//���ﴦ����
		playerDataPtr player = player_mgr.getPlayer(m.playerID);
		if (!player)return;
		ReadJsonArray;
		if (js_msg[0u].asInt() == res_sucess)
		{
			player->InterFM().setUploadFormat(js_msg[1u]);
		}
		resp_common(m, r);
	}
	void InterGame::resp_batch_inter_server(net::Msg& m, Json::Value& r)
	{
		PARSEJSON;
		player_mgr.sendToAll(inter_game::inter_server_info_resp, js);
	}
	void InterGame::resp_batch_annouce(net::Msg& m, Json::Value& r)
	{
		PARSEJSON;
		const int annouce_type = js[0u].asInt();
		Json::Value param_json = js[1u];
		const unsigned annouce_place = js[2u].asUInt();
		const bool roll = js[3u].asBool();
		Json::Value scroll_json = Json::objectValue;
		if (roll)
		{
			scroll_json["weight"] = 0;
			scroll_json["roll"] = 2;
		}
		chat_sys.despatchAllSP(annouce_type, param_json, scroll_json, annouce_place);
	}
	void InterGame::resp_event_list(net::Msg& m, Json::Value& r)
	{
		inter_event_list = std::string(m.strUTF8, m.packageLen - ::net::MINPACKAGE);
		//�������Ƿ���Ҫ�㲥
	}

	//////////////////////////////////////////////////////////////////////////
	//��������
	//ladder
	struct LadderBLKey
	{
		LadderBLKey(const int pid = -1, const unsigned ss = 0)
		{
			playerID = pid;
			session = ss;
		}
		bool operator==(const LadderBLKey& other)const
		{
			return ((playerID == other.playerID) && (session == other.session));
		}
		int playerID;
		unsigned session;
	};

	struct HashLadder
	{
		std::size_t operator()(const LadderBLKey& key)const
		{
			std::size_t seed = 0;
			boost::hash_combine(seed, boost::hash_value(key.playerID));
			boost::hash_combine(seed, boost::hash_value(key.session));
			return seed;
		}
	};

	typedef boost::unordered_set<LadderBLKey, HashLadder> LadderBalanceSet;
	static LadderBalanceSet LadderSet;

	//promote
	struct PromoteBLKey
	{
		PromoteBLKey(const int pid = -1,
			const unsigned t = 5,
			const unsigned ss = 0)
		{
			playerID = pid;
			type = t;
			session = ss;
		}
		bool operator==(const PromoteBLKey& other)const
		{
			return (
				(playerID == other.playerID) &&
				(type == other.type) &&
				(session == other.session)
				);
		}
		int playerID;
		unsigned type;
		unsigned session;
	};

	struct HashPromote
	{
		std::size_t operator()(const PromoteBLKey& key)const
		{
			std::size_t seed = 0;
			boost::hash_combine(seed, boost::hash_value(key.playerID));
			boost::hash_combine(seed, boost::hash_value(key.type));
			boost::hash_combine(seed, boost::hash_value(key.session));
			return seed;
		}
	};

	typedef boost::unordered_set<PromoteBLKey, HashPromote> PromoteBalanceSet;
	static PromoteBalanceSet PromoteSet;

	//flower
	struct FlowerBLKey
	{
		FlowerBLKey(const int pid = -1,
			const int spid = -1,
			const unsigned t = 4,
			const unsigned ss = 0,
			const unsigned r = 0)
		{
			playerID = pid;
			supportID = spid;
			type = t;
			session = ss;
			round = r;
		}
		bool operator==(const FlowerBLKey& other)const
		{
			return (
				(playerID == other.playerID) &&
				(supportID == other.supportID) &&
				(type == other.type) &&
				(session == other.session) &&
				(round == other.round)
				);
		}
		int playerID;
		int supportID;
		unsigned type;
		unsigned session;
		unsigned round;
	};

	struct HashFlower
	{
		std::size_t operator()(const FlowerBLKey& key)const
		{
			std::size_t seed = 0;
			boost::hash_combine(seed, boost::hash_value(key.playerID));
			boost::hash_combine(seed, boost::hash_value(key.supportID));
			boost::hash_combine(seed, boost::hash_value(key.type));
			boost::hash_combine(seed, boost::hash_value(key.session));
			boost::hash_combine(seed, boost::hash_value(key.round));
			return seed;
		}
	};
	typedef boost::unordered_set<FlowerBLKey, HashFlower> FlowerBalanceSet;
	static FlowerBalanceSet FlowerSet;

	//title
	struct TitleBLKey
	{
		TitleBLKey(const int pid = -1,
			const unsigned t = 0xFFFFFFFF,
			const unsigned ss = 0)
		{
			playerID = pid;
			type = t;
			session = ss;
		}
		bool operator==(const TitleBLKey& other)const
		{
			return (
				(playerID == other.playerID) &&
				(type == other.type) &&
				(session == other.session)
				);
		}
		int playerID;
		unsigned type;
		unsigned session;
	};

	struct HashTitle
	{
		std::size_t operator()(const TitleBLKey& key)const
		{
			std::size_t seed = 0;
			boost::hash_combine(seed, boost::hash_value(key.playerID));
			boost::hash_combine(seed, boost::hash_value(key.type));
			boost::hash_combine(seed, boost::hash_value(key.session));
			return seed;
		}
	};
	typedef boost::unordered_set<TitleBLKey, HashTitle> TitleBalanceSet;
	static TitleBalanceSet TitleSet;
	//����
	void InterGame::resp_balance_ladder(net::Msg& m, Json::Value& r)
	{
		playerDataPtr player = player_mgr.getPlayer(m.playerID);
		if (!player)return;
		PARSEJSON;
		//json.append(data.points).append(data.session);
		const int point = js[0u].asInt();
		const unsigned session = js[1u].asUInt();
		if (LadderSet.find(LadderBLKey(m.playerID, session)) == LadderSet.end())
		{
			LadderSet.insert(LadderBLKey(m.playerID, session));
			Json::Value param_json = Json::arrayValue;
			param_json.append(session);
			param_json.append(point);
			Json::Value reward_json = Json::arrayValue;
			for (unsigned i = 0; i < DanLadderBalanceList.size(); ++i)
			{
				const DanLadder& dan = DanLadderBalanceList[i];
				if (point >= dan._begin_point && point <= dan._end_point)
				{
					reward_json = dan._email_reward;
					break;
				}
			}
			EmailPtr email_ptr = email_sys.createPackage(EmailDef::InterGameLadderDan, param_json, reward_json);
			email_sys.sendToPlayer(player->ID(), email_ptr);
		}
		qValue json(qJson::qj_array);
		json.append(m.playerID).append(session);
		string str_send = json.toIndentString();
		net::Msg msg(m.playerID, Common::serverID(), inter_game::ladder_balance_req, str_send);
		game_svr->async_send_to_inter(msg);
	}
	void InterGame::resp_balance_promote(net::Msg& m, Json::Value& r)
	{
		playerDataPtr player = player_mgr.getPlayer(m.playerID);
		if (!player)return;
		PARSEJSON;
// 		json.append(data.type).
// 			append(data.session)
// 			;
		const unsigned type = js[0u].asUInt();
		const unsigned session = js[1u].asUInt();
		if (PromoteSet.find(PromoteBLKey(m.playerID, type, session)) == PromoteSet.end())
		{
			PromoteSet.insert(PromoteBLKey(m.playerID, type, session));
			Json::Value param_json = Json::arrayValue;
			param_json.append(session);
			param_json.append(type);
			Json::Value reward_json = PromoteBalanceList[type];
			EmailPtr email_ptr = email_sys.createPackage(EmailDef::InterGamerPromote, param_json, reward_json);
			email_sys.sendToPlayer(player->ID(), email_ptr);
		}
		qValue json(qJson::qj_array);
		json.append(m.playerID).append(type).append(session);
		string str_send = json.toIndentString();
		net::Msg msg(m.playerID, Common::serverID(), inter_game::promote_balance_req, str_send);
		game_svr->async_send_to_inter(msg);
	}
	void InterGame::resp_balance_flower(net::Msg& m, Json::Value& r)
	{
		playerDataPtr player = player_mgr.getPlayer(m.playerID);
		if (!player)return;
		PARSEJSON;
// 		json.append(data.supportID).
// 			append(data.supportName).
// 			append(data.type).
// 			append(data.flower).
// 			append(data.session).
// 			append(data.round)
// 			;
		const int support_id = js[0u].asInt();
		const string support_name = js[1u].asString();
		const unsigned type = js[2u].asUInt();
		const unsigned flower = js[3u].asUInt();
		const unsigned session = js[4u].asUInt();
		const unsigned round = js[5u].asUInt();
		if (FlowerSet.find(FlowerBLKey(m.playerID, support_id, type, session, round)) == FlowerSet.end())
		{
			FlowerSet.insert(FlowerBLKey(m.playerID, support_id, type, session, round));
			Json::Value param_json = Json::arrayValue;
			param_json.append(session);
			param_json.append(type);
			param_json.append(support_name);
			param_json.append(flower);
			param_json.append(round);
			Json::Value reward_json = FlowerBalanceMap.find(flower) == FlowerBalanceMap.end() ? Json::arrayValue : FlowerBalanceMap[flower];
			EmailPtr email_ptr = email_sys.createPackage(EmailDef::InterGameFlower, param_json, reward_json);
			email_sys.sendToPlayer(player->ID(), email_ptr);
		}
		
		qValue json(qJson::qj_array);
		json.append(m.playerID).append(support_id).append(type).append(session).append(round);
		string str_send = json.toIndentString();
		net::Msg msg(m.playerID, Common::serverID(), inter_game::flower_balance_req, str_send);
		game_svr->async_send_to_inter(msg);
	}

	void InterGame::resp_balance_title(net::Msg& m, Json::Value& r)
	{
		playerDataPtr player = player_mgr.getPlayer(m.playerID);
		if (!player)return;
		PARSEJSON;
// 		json.append(data.type).
// 			append(data.session).
// 			append(data.begin).
// 			append(data.end)
// 			;
		const unsigned type = js[0u].asUInt();
		const unsigned session = js[1u].asUInt();
		const unsigned begin = js[2u].asUInt();
		const unsigned end = js[3u].asUInt();
		if (TitleSet.find(TitleBLKey(m.playerID, type, session)) == TitleSet.end())
		{
			TitleSet.insert(TitleBLKey(m.playerID, type, session));
			//���Ž���
			player->InterTitle().setTitle(begin, end, type);
		}

		qValue json(qJson::qj_array);
		json.append(m.playerID).append(type).append(session);
		string str_send = json.toIndentString();
		net::Msg msg(m.playerID, Common::serverID(), inter_game::title_balance_req, str_send);
		game_svr->async_send_to_inter(msg);
	}

	//resp ok
	void InterGame::resp_balance_ladder_ok(net::Msg& m, Json::Value& r)
	{
		PARSEJSON;
		const int player_id = js[0u].asInt();
		const unsigned session = js[1u].asUInt();
		LadderSet.erase(LadderBLKey(m.playerID, session));
	}
	void InterGame::resp_balance_promote_ok(net::Msg& m, Json::Value& r)
	{
		PARSEJSON;
		const int player_id = js[0u].asInt();
		const unsigned type = js[1u].asUInt();
		const unsigned session = js[2u].asUInt();
		PromoteSet.erase(PromoteBLKey(player_id, type, session));
	}

	void InterGame::resp_balance_flower_ok(net::Msg& m, Json::Value& r)
	{
		PARSEJSON;
		const int player_id = js[0u].asInt();
		const int support_id = js[1u].asInt();
		const unsigned type = js[2u].asUInt();
		const unsigned session = js[3u].asUInt();
		const unsigned round = js[4u].asUInt();
		FlowerSet.erase(FlowerBLKey(m.playerID, support_id, type, session, round));
	}

	void InterGame::resp_balance_title_ok(net::Msg& m, Json::Value& r)
	{
		PARSEJSON;
		const int player_id = js[0u].asInt();
		const unsigned type = js[1u].asUInt();
		const unsigned session = js[2u].asUInt();
		TitleSet.erase(TitleBLKey(m.playerID, type, session));
	}
	//////////////////////////////////////////////////////////////////////////

	void InterGame::resp_grade_email(net::Msg& m, Json::Value& r)
	{
		playerDataPtr player = player_mgr.getPlayer(m.playerID);
		if (!player)return;
		Json::Value param_json = Json::arrayValue;
		EmailPtr email_ptr = email_sys.createSystem(EmailDef::InterGameGrade, param_json);
		email_sys.sendToPlayer(player->ID(), email_ptr);
	}


	//////////////////////////////////////////////////////////////////////////
	void InterGame::on_connect_sucess()
	{
		{//����ǰ������ʱ���б�����
			::net::Msg msg(-1, Common::serverID(), inter_game::update_event_list_req);
			game_svr->async_send_to_inter(msg);
		};
	}

	void InterGame::connect_inter_server()
	{
		if (inter_ip.empty() || inter_port.empty())return;
		game_svr->connect_inter_svr(inter_ip, inter_port);
	}

	//public
	void InterGame::send_to_inter_svr(const int player_id, const short protocol, qValue& json)
	{
		string str = json.toIndentString();
		send_to_inter_svr(player_id, protocol, str);
	}

	void InterGame::send_to_inter_svr(const int player_id, const short protocol, Json::Value& json)
	{
		string str = json.toIndentString();
		send_to_inter_svr(player_id, protocol, str);
	}

	void InterGame::send_to_inter_svr(const int player_id, const short protocol, string& str)
	{
		net::Msg mj(player_id, Common::serverID(), protocol, str);
		game_svr->async_send_to_inter(mj);
	}

	void InterGame::send_to_inter_svr(const int player_id, const short protocol)
	{
		net::Msg mj(player_id, Common::serverID(), protocol);
		game_svr->async_send_to_inter(mj);
	}


	//////////////////////////////////////////////////////////////////////////
	//gm
	void InterGame::GMUpdateInter(net::Msg& m, Json::Value& r)
	{
		Json::Value& data_json = r[strMsg] = Json::arrayValue;
		data_json.append(res_sucess);
		data_json.append(inter_ip);
		data_json.append(inter_port);
		data_json.append(inter_report_port);
		data_json.append(inter_server_name);
		data_json.append(inter_server_id);
	}

	void InterGame::GMMotifyInter(net::Msg& m, Json::Value& r)
	{
		ReadJsonArray;
		const string ip_str = js_msg[0u].asString();
		const string port_str = js_msg[1u].asString();
		const string report_port = js_msg[2u].asString();
		const string server_name = js_msg[3u].asString();
		const int server_id = js_msg[4u].asInt();
		if (ip_str != inter_ip || port_str != inter_port)
		{
			inter_ip = ip_str;
			inter_port = port_str;
			game_svr->delay_reconnect_inter_svr();
		}
		inter_report_port = report_port;
		inter_server_name = server_name;
		inter_server_id = server_id;
		mongo::BSONObj key = BSON("key" << 0);
		mongo::BSONObj obj = BSON("key" << 0 << "ip" << inter_ip << "port" << inter_port
			<< "report_port" << inter_report_port << "sn" << inter_server_name <<
			"sid" << inter_server_id
		);
		db_mgr.SaveMongo(DBN::dbInterServerGame, key, obj);
		Json::Value json = Json::objectValue;
		Json::Value& data_json = json[strMsg] = Json::arrayValue;
		data_json.append(res_sucess);
		data_json.append(inter_ip);
		data_json.append(inter_report_port);
		data_json.append(inter_server_name);
		Batch::batchAll(json, gate_client::inter_server_config_resp);
		Return(r, res_sucess);
	}
}
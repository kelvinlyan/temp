#pragma once

#include "auto_base.h"
#include "dbDriver.h"
#include "commom.h"
#include "worldboss_helper.h"
#include "battle_system.h"

#define worldboss_sys (*gg::worldboss_system::_Instance)

namespace gg
{
	class worldboss_system
	{
		public:

			static worldboss_system* const _Instance;

			worldboss_system();
			void initData();

			void updateState(playerDataPtr d);
			void updateState();

			DeclareRegFunction(showUI);
			DeclareRegFunction(fight);
			DeclareRegFunction(showrep);
			DeclareRegFunction(showIncentive);
			DeclareRegFunction(incentive);
			DeclareRegFunction(rankKingdom);
			DeclareRegFunction(rankSelf);
			DeclareRegFunction(cleanCd);
			DeclareRegFunction(getReward);
			DeclareRegFunction(bossState);

			unsigned getCurrentRecordDay()
			{
				return _tick_day;
			}
			const WorldBoss::Config& getConfig() const
			{
				return _config;
			}
			Json::Value& getParam()
			{
				return _param;
			}

			int getRank(playerDataPtr d) const;
			int getFaceId(playerDataPtr d);
			int getIncentNum(playerDataPtr d);
			double getDamageRate(unsigned damage);
			BattleEquipList getEquipList(playerDataPtr d);

			void testBroadcast(playerDataPtr d);

		private:
			void loadDB();
			void loadFile();
			void createReportDir();
			void initState();
			void loadRankList();

			void saveCurrentInfo();
			void saveTermInfo();

			int fightBoss(playerDataPtr d);
			void addPlayerAttr(playerDataPtr d, sBattlePtr ptr);
			void doneBattle(BattleReport& reportData, playerDataPtr d);

			void tickOpen(unsigned tick_time);
			void tickClose(unsigned tick_time);
			void createBoss(bool reset);

			int getBuffId(int damage);
			std::string getRepId();
			int getNewMapId(int type, int map_id, int kill_time);

			void getUIPlayerList(Json::Value& info);
			void getUIInfo(playerDataPtr d, Json::Value& info);

			int getKillReward() const;
			int getLastReward() const;
			int getBattleReward(int damage) const;
			int getNationReward(int rank) const;

			void setRankAndGetReward(const WorldBoss::PlayerInfo& p);
			int addKingdomeIncent(playerDataPtr d, int resource);

			void addCachePlayer(playerDataPtr d);

			void resetBoss(unsigned tick_time);

			void setComingBroadcastTimer();
			void setOpenBroadcastTimer();
			void bossComingBroadcast();
			void bossOpenBroadcast();
			void setBroadcastTimer14();
			void setBroadcastTimer15();
			void bossBroadcast14();
			void bossBroadcast15();

		private:
			sBattlePtr _boss_ptr;

			int _map_id;
			int _season;
			int _bg_id;
			int _type;
			STDVECTOR(int, HpList);
			HpList _hp_list;
			int _total_hp;
			int _max_hp;
			unsigned _rep_id;
			int _buff_id;
			int _incent_num[Kingdom::nation_num];
			bool _20hp_broadcast;
			STDVECTOR(std::string, NameList);
			NameList _incent_names[Kingdom::nation_num];
			WorldBoss::ComReportMgr _report_mgr;

			int _state;
			unsigned _tick_time;
			unsigned _tick_day;
			unsigned _next_tick_time;

			Json::Value _cache_list;
			
			WorldBoss::RankList _rank_list;
			WorldBoss::KingdomRank _nation_list;

			Json::Value _person_rank;
			Json::Value _nation_rank;
			Json::Value _reward_info[Kingdom::nation_num];
			Json::Value _ui_info;
			WorldBoss::PrevInfo _prev_info;

			// config
			WorldBoss::Config _config;

			// temp args
			Json::Value _param;
			struct Helper
			{
				Helper(): _kill_pid(-1){}
				int _rank;
				int _kill_pid;
				int _nation_reward[Kingdom::nation_num];
				int _kill_reward;
				int _last_reward;
				int _last_reward_gold;
				unsigned _player_count[Kingdom::nation_num];
			};
			Helper _helper;
	};
}

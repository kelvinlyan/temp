//###################################
//create by Jim
//2016-05-05
//###################################

#pragma once

#include "auto_do.h"

namespace gg
{
	class playerOnlineBox :
		public _auto_player
	{
	public:
		playerOnlineBox(playerData* const own);
		~playerOnlineBox(){}
		void offline();//���߼�¼
		unsigned onlineDur();//����ʱ��
		void reset();
		void online();
		bool isBeenSign(const unsigned idx);
		void goSignBox(const unsigned idx);
		virtual void _auto_update();
		void setData(mongo::BSONObj& obj);
	private:
		virtual bool _auto_save();
		unsigned signBox;//��ʶID
		unsigned countTime;//�ۼ�ʱ��
		unsigned tickTime;//��ʼʱ��
	};
}
#include "gamer_offline.h"
#include "dbDriver.h"

namespace gg
{
	playerOffline::playerOffline(playerData* const own) :_auto_player(own)
	{
		offline = Common::gameTime();
		offlineStander = Common::getNextTime(5);
		offlineStanderDay = 0;
	}

	void playerOffline::Off()
	{
		offline = Common::gameTime();
		offlineStander = Common::getNextTime(5);
		_sign_save();
	}

	void playerOffline::Online()
	{
		if (Own().LV() < 31)return;
		const unsigned now = Common::gameTime();
		unsigned day = (now > offlineStander) ? (now - offlineStander) / DAY : 0;
		if (day > 0)
		{
			offlineStanderDay = day;
			_sign_auto();
		}
	}

	void playerOffline::resetOffDay()
	{
		offlineStanderDay = 0;
		_sign_auto();
	}

	void playerOffline::resetOffDayTime()
	{
		offlineStander = Common::getNextTime(5);
		_sign_auto();
	}

	void playerOffline::_auto_update()
	{
		qValue list_json(qJson::qj_array), resJson(qJson::qj_object);
		resJson.addMember("ofd", offlineStanderDay);
		list_json.append(res_sucess);
		list_json.append(resJson);
		Own().sendToClientFillMsg(gate_client::player_offday_info_resp, list_json);
	}

	void playerOffline::setData(mongo::BSONObj& obj)
	{
		if (obj.isEmpty())return;
		offline = (unsigned)obj["of"].Int();
		if (!obj["sdof"].eoo())offlineStander = obj["sdof"].Int();
		if (!obj["sdofd"].eoo())offlineStanderDay = obj["sdofd"].Int();
	}

	bool playerOffline::_auto_save()
	{
		mongo::BSONObj key = BSON(strPlayerID << Own().ID());
		mongo::BSONObj obj = BSON("$set" << BSON("Offline" << 
			BSON("of" << offline << "sdof" << offlineStander << "sdofd" << offlineStanderDay)
			));
		return db_mgr.SaveMongo(DBN::dbPlayerCollection, key, obj);
	}

}
#pragma once

#include "auto_base.h"

namespace gg
{
	namespace KingdomWar
	{
		class PersonalRecord;
		BOOSTSHAREPTR(PersonalRecord, PersonalRecordPtr);
	}

	class playerKingdomWarTask
		: public _auto_player
	{
		public:
			playerKingdomWarTask(playerData* const own);

			virtual void classLoad();
			void update();

			void update(int type, const Json::Value& arg);

			int getPersonTaskReward(int id, Json::Value& r);
			int getNationTaskReward(Json::Value& r);
			int nationTaskState();

			void personalTaskLog(unsigned end_time);

			int personTaskRP();
			void resetPersonTaskRP();
			void resetPersonTaskRPAndUpdate();
			int nationTaskRP();
			void resetNationTaskRP();
			void resetNationTaskRPAndUpdate();
			void resetRedPoint();

			void reset();

			int taskLv() const { return _task_lv; }

		private:
			virtual bool _auto_save();
			virtual void _auto_update();
			inline void check();
			
		private:
			STDVECTOR(KingdomWar::PersonalRecordPtr, RecordList);
			RecordList _personal_record;

			int _task_lv;
			unsigned _nation_task_time;
			int _nation_task_state; // 0 not rewarded 1 rewarded

			int _pt_rp;
			int _nt_rp;
	};
}

#include "player_mapwar.h"
#include "dbDriver.h"
#include "map_war.h"
#include "res_code.h"
#include "task_mgr.h"
#include "map_war_rank.h"

namespace gg
{
	playerChatperData::playerChatperData(playerData* const own, const int cID) :
		_auto_player(own),
		chaperID(cID)
	{
		eliteBox = 0;
		totalStar = 0;
		filterBox.clear();

		chaperConfig = map_sys.getChaperConfig(chaperID);
		//��ͼ��ϸ����
		mapData.clear();
		mapDataCfgPtr map_config = map_sys.getMapConfig(chaperConfig->beginMapID);
		SelfMapDataPtr ptr = Creator<selfMapData>::Create();
		ptr->mapId = chaperConfig->beginMapID;
		ptr->starNum = 0;
		ptr->challengeTimes = 0;// map_config->chanllengeTimes;
		ptr->reChallengeTimes = 0;
		ptr->mState = warMap::CanCH;
		//��������
		mapData[ptr->mapId] = ptr;
	}

	bool playerChatperData::_auto_save()
	{
		mongo::BSONObj key = BSON(strPlayerID << Own().ID() << "cp" << chaperID);
		mongo::BSONObjBuilder obj;
		obj << strPlayerID << Own().ID() << "cp" << chaperID;
		mongo::BSONArrayBuilder _arrFilter;
		ForEachC(std::set<int>, it, filterBox)
		{
			_arrFilter << *it;
		}
		mongo::BSONArrayBuilder _arrmapData;
		for (MapDataMap::iterator it = mapData.begin(); it != mapData.end(); it++)
		{
			mongo::BSONObj map_obj = BSON("mi" << it->second->mapId << //��ͼID
				"sn" << it->second->starNum << //����
				"st" << it->second->mState << //״̬
				"ct" << it->second->challengeTimes << //������ս�Ĵ���
				"re" << it->second->reChallengeTimes //���ô���
			);
			_arrmapData << map_obj;
		}
		obj << "md" << _arrmapData.arr() << "elb" << eliteBox << "flt" << _arrFilter.arr();

		return db_mgr.SaveMongo(DBN::dbPlayerWarChapter, key, obj.obj());
	}

	qValue playerChatperData::mapDataJson()
	{
		qValue res(qJson::qj_object);
		qValue mapJson(qJson::qj_object);
		for (MapDataMap::iterator it = mapData.begin(); it != mapData.end(); it++)
		{
			SelfMapDataPtr self_data = it->second;
			mapDataCfgPtr mapConfig = map_sys.getMapConfig(self_data->mapId);
			if (mapConfig)
			{
				qValue mdJson(qJson::qj_object);
				mdJson.addMember("sn", self_data->starNum);
				mdJson.addMember("ms", self_data->mState);
				mdJson.addMember("ct", mapConfig->chanllengeTimes - self_data->challengeTimes);
				mdJson.addMember("rt", map_sys.ReNum(Own().Info().VipLv()) - self_data->reChallengeTimes);
				mdJson.addMember("ctt", mapConfig->chanllengeTimes);
				mdJson.addMember("trr", map_sys.ReNum(Own().Info().VipLv()));
				mapJson.addMember(Common::toString(self_data->mapId), mdJson);
			}
		}
		res.addMember("mp", mapJson);
		res.addMember("ch", chaperID);
		res.addMember("elb", eliteBox);
		qValue filterJson(qJson::qj_object);
		const rewardItemMap& checkMap = getChaperConfig()->passBox;
		for (rewardItemMap::const_iterator it = checkMap.begin(); it != checkMap.end(); it++)
		{
			const rewardItemCfgPtr& riConfig = it->second;
			filterJson.addMember(
				Common::toString(riConfig->rewardID),
				riConfig->starNum > totalStar ? warReward::Unfinished :
				(filterBox.find(riConfig->rewardID) == filterBox.end() ? warReward::Notrev : warReward::Finish)
			);
		}
		res.addMember("rw", filterJson);
		return res;
	}

	void playerChatperData::tryOpenNewMap(const int mapID)
	{
		SelfMapDataPtr pre = getMapData(mapID);
		if (pre)return;
		mapDataCfgPtr configMap = map_sys.getMapConfig(mapID);
		if (!configMap) return;
		SelfMapDataPtr ptr = Creator<selfMapData>::Create();
		ptr->mapId = mapID;
		ptr->starNum = 0;
		ptr->challengeTimes = 0;// configMap->chanllengeTimes;
		ptr->reChallengeTimes = 0;
		ptr->mState = warMap::CanCH;
		mapData[ptr->mapId] = ptr;
		_sign_auto();
	}

	bool playerChatperData::setMapStar(const int mapID, const int starNum)
	{
		SelfMapDataPtr ptr = getMapData(mapID);
		if (ptr)
		{
			//if (ptr->mState == warMap::Faile) { return 0; }
			mapDataCfgPtr map_config = map_sys.getMapConfig(mapID);
			if (!map_config)return false;
			bool is_change = false;
			if (ptr->mState != warMap::Success)
			{
				ptr->mState = warMap::Success;
				is_change = true;
			}
			int num = starNum - ptr->starNum;
			if (num > 0)
			{
				totalStar += num;
				Own().War().addStars(num);
				ptr->starNum = starNum;
				TaskMgr::update(Own().getOwnDataPtr(), Task::WarStarSum, num);
				TaskMgr::update(Own().getOwnDataPtr(), Task::WarMapStar, mapID, starNum);
				is_change = true;
			}
			if (is_change)
			{
				_sign_auto();
			}
			return true;
		}
		return false;
	}

	void playerChatperData::reChanllengeTimeDaily(const bool update /* = true */)
	{
		for (MapDataMap::iterator it = mapData.begin(); it != mapData.end(); it++)
		{
			it->second->challengeTimes = 0;
			it->second->reChallengeTimes = 0;
		}
		_sign_save();
		if (update)_sign_update();
	}

	bool playerChatperData::reChanllengeAcc(const int mapID)
	{
		SelfMapDataPtr ptr = getMapData(mapID);
		if (!ptr || ptr->reChallengeTimes >= map_sys.ReNum(Own().Info().VipLv())) return false;
		mapDataCfgPtr mapConfig = map_sys.getMapConfig(mapID);
		if (mapConfig && ptr->challengeTimes >= mapConfig->chanllengeTimes)
		{
			ptr->reChallengeTimes++;
			ptr->challengeTimes = 0;// mapConfig->chanllengeTimes;
			_sign_auto();
			return true;
		}
		return false;
	}

	void playerChatperData::subChanllengeTime(const int mapID, const int times)
	{
		SelfMapDataPtr ptr = getMapData(mapID);
		if (!ptr)return;
		ptr->challengeTimes += times;
		//ptr->challengeTimes = ptr->challengeTimes < 0 ? 0 : ptr->challengeTimes;
		_sign_auto();
	}

	SelfMapDataPtr playerChatperData::getMapData(const int mapID)
	{
		MapDataMap::iterator mIt = mapData.find(mapID);
		if (mIt == mapData.end())return SelfMapDataPtr();
		return mIt->second;
	}

	bool playerChatperData::_on_sign_update()
	{
		Own().War().signChaper(chaperID);
		return false;
	}

	////////////////////////////////////////////////////////////////////////////////////
	///////////////////////////////////Mgr//////////////////////////////////////////////

	playerMapWarMgr::playerMapWarMgr(playerData* const own) :_auto_player(own)
	{
		_signChaper.clear();
		//��ͼ����
		ChapterData.clear();

		//���ʤ��
		_lastWinMap = 0;
		_lastWinMapTime = Common::gameTime();

		//������
		_totalStarsNum = 0;

		//����Ҫ�½�һ����������
		const int minChapterId = map_sys.getMinChapterNum();
		playerChatperDataPtr chatperData = Creator<playerChatperData>::Create(_Own, minChapterId);
		ChapterData[minChapterId] = chatperData;
	}

	bool playerMapWarMgr::_auto_save()
	{
		mongo::BSONObj key = BSON(strPlayerID << Own().ID() << "cp" << -1);
		mongo::BSONObj obj = BSON(strPlayerID << Own().ID() << "cp" << -1
			<< "lwm" << _lastWinMap << "lwmt" << _lastWinMapTime);//������������
		return db_mgr.SaveMongo(DBN::dbPlayerWarChapter, key, obj);
	}

	void playerMapWarMgr::_auto_update()
	{
		qValue chaper_json(qJson::qj_array);
		unsigned count = 0;
		for (std::set<int>::iterator it = _signChaper.begin(); it != _signChaper.end(); it++)
		{
			playerChatperDataPtr ptr = getChatperData(*it);
			if (ptr)
			{
				chaper_json.append(ptr->mapDataJson());
				if (++count >= 40)
				{
					count = 0;
					qValue res(qJson::qj_array);
					res.append(res_sucess).append(chaper_json).append(State::getState());
					Own().sendToClientFillMsg(gate_client::map_war_chaper_detail_resp, res);
					chaper_json.toArray();
				}
			}
		}
		_signChaper.clear();
		if (count > 0)
		{
			count = 0;
			qValue res(qJson::qj_array);
			res.append(res_sucess).append(chaper_json).append(State::getState());
			Own().sendToClientFillMsg(gate_client::map_war_chaper_detail_resp, res);
		}
	}

	void playerMapWarMgr::signChaper(const int chaperID)
	{
		_signChaper.insert(chaperID);
		_sign_update();
	}

	void playerMapWarMgr::addStars(const int num)
	{
		if (num < 1)return;
		_totalStarsNum += num;
	}

	void playerMapWarMgr::classLoad()
	{
		//��ͼ����
		ChapterData.clear();

		const int minChapterId = map_sys.getMinChapterNum();
		const int maxChapterId = map_sys.getMaxChapterNum();

		objCollection objs = db_mgr.Query(DBN::dbPlayerWarChapter, BSON(strPlayerID << Own().ID()));
		for (unsigned i = 0; i < objs.size(); ++i)
		{
			mongo::BSONObj& obj = objs[i];
			const int cp = obj["cp"].Int();
			if (cp == -1)
			{
				_lastWinMap = obj["lwm"].Int();
				_lastWinMapTime = obj["lwmt"].Int();
			}
			else
			{
				playerChatperDataPtr ptr = Creator<playerChatperData>::Create(_Own, cp);
				ptr->eliteBox = obj["elb"].Int();
				std::vector<mongo::BSONElement> elems_filter = obj["flt"].Array();
				for (unsigned i = 0; i < elems_filter.size(); ++i)
				{
					ptr->filterBox.insert(elems_filter[i].Int());
				}
				std::vector<mongo::BSONElement> elems_map = obj["md"].Array();
				for (unsigned i = 0; i < elems_map.size(); ++i)
				{
					mongo::BSONElement& elem = elems_map[i];
					SelfMapDataPtr map_ptr = Creator<selfMapData>::Create();
					map_ptr->mapId = elem["mi"].Int();
					map_ptr->starNum = elem["sn"].Int();
					ptr->totalStar += map_ptr->starNum;
					_totalStarsNum += map_ptr->starNum;
					map_ptr->challengeTimes = elem["ct"].Int();
					map_ptr->reChallengeTimes = elem["re"].Int();
					map_ptr->mState = (warMap::mapState)elem["st"].Int();
					ptr->mapData[map_ptr->mapId] = map_ptr;
				}
				ChapterData[cp] = ptr;
			}
		}
		//����Ƿ�����һ���½�����
		mapDataCfgPtr last_map_config = map_sys.getMapConfig(_lastWinMap);
		if (last_map_config && last_map_config->isEndMap() && last_map_config->hasNextChaper())
		{
			const int nextID = last_map_config->chaperPtr->nextChaperID;
			playerChatperDataPtr pre = getChatperData(nextID);
			if (!pre)
			{
				playerChatperDataPtr ptr = Creator<playerChatperData>::Create(_Own, nextID);
				ChapterData[nextID] = ptr;
			}
		}

		if (ChapterData.empty())//û������//��������
		{
			playerChatperDataPtr chatperData = Creator<playerChatperData>::Create(_Own, minChapterId);
			ChapterData[minChapterId] = chatperData;
		}
	}

	playerChatperDataPtr playerMapWarMgr::getChatperData(const int chapterId)
	{
		ChapterDateMap::iterator it = ChapterData.find(chapterId);
		if (it != ChapterData.end())return it->second;
		return playerChatperDataPtr();
	}

	SelfMapDataPtr playerMapWarMgr::getMapData(const int mapId)
	{
		playerChatperDataPtr ptr = getChatperData(mapId / DivMapChaperRealte);
		if (ptr)
		{
			return ptr->getMapData(mapId);
		}
		return SelfMapDataPtr();
	}

	void playerMapWarMgr::tryOpenNewChaper(const int chaperID)
	{
		playerChatperDataPtr pre = getChatperData(chaperID);
		if (pre)return;
		playerChatperDataPtr ptr = Creator<playerChatperData>::Create(_Own, chaperID);
		ptr->_sign_auto();
		ChapterData[chaperID] = ptr;
	}

	void playerMapWarMgr::alterMapStar(const int mapID, const int starNum)
	{
		if (starNum <= 0 || starNum > 5) { return; }
		//��������
		const int chaperID = mapID / DivMapChaperRealte;
		playerChatperDataPtr ptr = getChatperData(chaperID);
		if (!ptr)return;

		const bool is_ok = ptr->setMapStar(mapID, starNum);
		if (is_ok == false)return;
		if (mapID > _lastWinMap)
		{
			_lastWinMap = mapID;
			_lastWinMapTime = Common::gameTime();
			map_war_rank.updatePlayer(Own().getOwnDataPtr());
			onChangeMaxMapId();
			Log(DBLOG::strLogWarProcess, Own().getOwnDataPtr(), -1, _lastWinMap, mapID);
			_sign_auto();
		}

		const mapDataCfgPtr config = map_sys.getMapConfig(mapID);
		if (!config) { return; }
		if (config->hasNextMap())
		{
			ptr->tryOpenNewMap(config->nextID);
		}
		if (config->isEndMap() && config->hasNextChaper())
		{
			tryOpenNewChaper(config->chaperPtr->nextChaperID);
		}
	}

	int playerMapWarMgr::getEliteBox(const int mapID, Json::Value& r)
	{
		if (!isChallengeMap(mapID))return err_illedge;
		mapDataCfgPtr config = map_sys.getMapConfig(mapID);
		if (!config)return err_illedge;
		const unsigned boxIDX = config->eliteBox;
		if (boxIDX > 31)return err_illedge;
		playerChatperDataPtr ptr = getChatperData(config->chaperID());
		if (!ptr)return err_illedge;
		const unsigned state = ptr->getEliteBox();
		if ((state & (0x0001 << boxIDX)) > 0)return err_illedge;//�Ѿ���ȡ��
		const int res = actionDoBox(
			Own().getOwnDataPtr(),
			config->eliteBoxAction[Own().Info().NationIDX()],
			false
			);
		if (res == res_sucess)
		{
			r = actionRes();
			ptr->eliteBox |= (0x0001 << boxIDX);
			ptr->_sign_auto();
			_sign_auto();
		}
		else
		{
			r = actionError();
		}
		return res;
	}

	void playerMapWarMgr::sendMapData()
	{
		qValue chaper_json(qJson::qj_array);
		unsigned count = 0;
		for (ChapterDateMap::iterator it = ChapterData.begin(); it != ChapterData.end(); it++)
		{
			playerChatperDataPtr ptr = it->second;
			chaper_json.append(ptr->mapDataJson());
			if (++count >= 40)
			{
				count = 0;
				qValue res(qJson::qj_array);
				res.append(res_sucess).append(chaper_json).append(State::getState());
				Own().sendToClientFillMsg(gate_client::map_war_chaper_detail_resp, res);
				chaper_json.toArray();
			}
		}
		if (count > 0)
		{
			qValue res(qJson::qj_array);
			res.append(res_sucess).append(chaper_json).append(State::getState());
			Own().sendToClientFillMsg(gate_client::map_war_chaper_detail_resp, res);
		}
	}

	bool playerMapWarMgr::isChallengeChaper(const int chaperID)
	{
		return chaperID <= map_sys.calCompleteChaperByMapID(_lastWinMap);
	}

	int playerMapWarMgr::getChapterReward(const int chapterId, const int rewardId)
	{
		playerChatperDataPtr ptr = getChatperData(chapterId);
		if (!ptr) return err_charpter_id_not_found;

		if (ptr->filterBox.find(rewardId) != ptr->filterBox.end())return err_charpter_reward_state_not_recv;
		ActionBoxList acPtr = map_sys.getChapterRewardList(ptr->chaperID, rewardId);
		if (acPtr.empty())return err_charpter_reward_id_not_found;
		int res = actionDoBox(Own().getOwnDataPtr(), acPtr, false);
		if (res == res_sucess)
		{
			ptr->filterBox.insert(rewardId);
			ptr->_sign_auto();
			_sign_auto();
		}
		return res;
	}

	int playerMapWarMgr::canSweep(const int mapID, const int times, const int comval)
	{
		SelfMapDataPtr mapPTr = getMapData(mapID);
		if (!mapPTr) return err_illedge;
		if (mapPTr->starNum != MAX_MAP_STAR_NUM) { return err_mapwar_sweep_more_star; }
		if (mapPTr->challengeTimes + times > comval) { return err_mapwar_not_challengtimes; }
		return res_sucess;
	}

	int	playerMapWarMgr::canChanllenge(const int mapID, const int times, const int comval)
	{
		SelfMapDataPtr mapPTr = getMapData(mapID);
		if (!mapPTr || mapPTr->mState == warMap::Faile) return err_illedge;
		if (mapPTr->challengeTimes + times > comval) { return err_mapwar_not_challengtimes; }
		return res_sucess;
	}

	void playerMapWarMgr::subChanllenge(const int mapID, const int times /* = 1 */)
	{
		playerChatperDataPtr ptr = getChatperData(mapID / DivMapChaperRealte);
		if (ptr)
		{
			ptr->subChanllengeTime(mapID, times);
		}
	}

	void playerMapWarMgr::reChanllengeTimeDaily()
	{
		for (ChapterDateMap::iterator it = ChapterData.begin(); it != ChapterData.end(); it++)
		{
			it->second->reChanllengeTimeDaily();
		}
	}

	int playerMapWarMgr::currenChanllenge()
	{
		mapDataCfgPtr config = map_sys.getMapConfig(_lastWinMap);
		if (!config || config->nextID < 1)return _lastWinMap;
		return config->nextID;
	}

	int	 playerMapWarMgr::reChanllengeAcc(const int mapID)
	{
		playerChatperDataPtr ptr = getChatperData(mapID / DivMapChaperRealte);
		if (!ptr)return err_illedge;
		if (ptr->reChanllengeAcc(mapID)) return res_sucess;
		return err_illedge;
	}

	int playerMapWarMgr::getStarSum(int chapterId)
	{
		if (chapterId == -1)
		{
			return _totalStarsNum;
		}
		else
		{
			playerChatperDataPtr ptr = getChatperData(chapterId);
			if (ptr)return ptr->getStarNum();
			return 0;
		}
	}
}

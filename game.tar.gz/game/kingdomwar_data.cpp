#include "kingdomwar_data.h"
#include "playerManager.h"
#include "kingdomwar_system.h"
#include "net_helper.hpp"
#include "game_time.h"
#include "email_system.h"
#include "kingdom_def.h"
#include "map_war.h"
#include "kingdomwar_city.h"
#include "heroparty_system.h"
#include "chat.h"
#include "kingdom_helper.h"
#include "activity_player.h"

namespace gg
{
	namespace KingdomWar
	{
		enum
		{
			OpenTime = 9 * HOUR,
			CloseTime = 22 * HOUR,

			SignMax = 3,
			RetreatSignMax = 1,
			ChannelMsgSize = 15,

			DBIDX_STATE = -1,
			DBIDX_SIGN_BEGIN = -2,
			DBIDX_SIGN_END = -4,
			DBIDX_BUFF = -5,
			DBIDX_PARAM = -6,
			DBIDX_PRIME_STATE = -7,
			DBIDX_EXPLOIT_RANK = -8,
			DBIDX_CHANNEL = -9,

			SIGN_ATTACK = 0,
			SIGN_RETREAT,
		};

		RankItem::RankItem(playerDataPtr d)
		{
			_pid = d->ID();
			_name = d->Name();
			_nation = d->Info().Nation();
			_exploit = d->KingDomWar().getExploit();
			_lv = d->LV();
		}

		RankItem::RankItem(playerDataPtr d, int exploit)
		{
			_pid = d->ID();
			_name = d->Name();
			_nation = d->Info().Nation();
			_lv = d->LV();
			_exploit = exploit;
		}

		void RankItem::getInfo(qValue& q) const
		{
			q << _pid << _name << _nation << _exploit << _lv;
		}

		RankMgr::RankMgr()
		{
		}

		void RankMgr::update(playerDataPtr d, int old_value)
		{
			_rank.update(Creator<RankItem>::Create(d), old_value);
		}

		void RankMgr::insert(playerDataPtr d, int exploit)
		{
			_rank.update(Creator<RankItem>::Create(d, exploit), 0);
		}

		void RankMgr::getInfo(playerDataPtr d, int begin, int end, qValue& q)
		{
			if (begin < 1 || end < begin)
				return;
			_info.toArray();
			_rk = begin;
			_rank.run(boostBind(RankMgr::packageInfo, this, _1), begin - 1, end - begin + 1);
			q.addMember("l", _info);
			q.addMember("n", _rank.size());
			q.addMember("r", getRank(d));
			q.addMember("e", d->KingDomWar().getExploit());
		}

		int RankMgr::getRank(playerDataPtr d) const
		{
			return _rank.getRank(d->ID(), d->KingDomWar().getExploit());
		}

		void RankMgr::packageInfo(const RankItem& item)
		{
			qValue tmp;
			tmp.append(_rk++);
			item.getInfo(tmp);
			_info.append(tmp);
		}

		void RankMgr::packagePID(const RankItem& item, int nation, unsigned num)
		{
			if (_kingfight_items.size() < num
				&& item.nation() == nation)
			{
				if (PrisonerHelper::shared().check(item.id()) == 0)
				{
					++_rk;
					_kingfight_items.push_back(KingFightItem(item.id(), _rk));
				}
			}
		}

		std::vector<KingFightItem> RankMgr::sendChart(int nation, unsigned num)
		{
			_rk = 0;
			_kingfight_items.clear();
			_rank.run(boostBind(RankMgr::packagePID, this, _1, nation, num));
			return _kingfight_items;
		}

		void RankMgr::tickRank()
		{
			_rk = 0;
			_rank.run(boostBind(RankMgr::tickRankItem, this, _1));
			_rank.run(boostBind(RankMgr::tickClearItem, this, _1));
			_rank.clear();
		}

		void RankMgr::tickRankItem(const RankItem& item)
		{
			++_rk;
			playerDataPtr d = player_mgr.getPlayer(item.id());
			if (!d) return;

			Json::Value pl;
			pl.append(State::shared().nextClearTime() - 1);
			pl.append(item.value());
			pl.append(_rk);
			pl.append(kingdomwar_sys.getRankReward(d, _rk));

			EmailPtr e = email_sys.createPackage(EmailDef::KingdomWarRankReward, pl, kingdomwar_sys.getRankReward(d, _rk));
			email_sys.sendToPlayer(d->ID(), e);
		}

		void RankMgr::tickClearItem(const RankItem& item)
		{
			playerDataPtr d = player_mgr.getPlayer(item.id());
			if (!d) return;

			d->KingDomWar().clearExploit();
			d->KingDomWarBox().clear();
		}

		State::State()
		{
			_next_5_min_tick_time = 0;
			_state = -1;
			_next_tick_time = 0;
			_next_clear_time = 0;
			_next_time_05_00 = 0;
			_next_time_20_00 = 0;
			_next_time_03_00 = 0;
			_unity_flag = false;

			init();
		}

		void State::init()
		{
			mongo::BSONObj key = BSON("ci" << (int)DBIDX_STATE);
			mongo::BSONObj obj = db_mgr.FindOne(DBN::dbKingdomWarCityBase, key);
			if (!obj.isEmpty())
			{
				checkNotEoo(obj["5min"])
					_next_5_min_tick_time = obj["5min"].Int();
				checkNotEoo(obj["st"])
					_state = obj["st"].Int();
				checkNotEoo(obj["ntt"])
					_next_tick_time = obj["ntt"].Int();
				checkNotEoo(obj["nct"])
					_next_clear_time = obj["nct"].Int();
				checkNotEoo(obj["tm0500"])
					_next_time_05_00 = obj["tm0500"].Int();
				checkNotEoo(obj["tm2000"])
					_next_time_20_00 = obj["tm2000"].Int();
				checkNotEoo(obj["tm0300"])
					_next_time_03_00 = obj["tm0300"].Int();
				checkNotEoo(obj["ufg"])
					_unity_flag = obj["ufg"].Bool();
			}

			unsigned cur_time = Common::gameTime();
			unsigned day_time = Common::timeZero(cur_time);
			unsigned day_stamp = cur_time - day_time;
			
			if (_next_5_min_tick_time == 0)
				_next_5_min_tick_time = (day_stamp / (5 * MINUTE) + 1) * (5 * MINUTE) + day_time;
			if (_next_clear_time == 0)
				_next_clear_time = season_sys.getNSTimeHMS(cur_time, SEASON::Spring, 5, 0, 0);
			if (_next_tick_time == 0)
			{
				if (day_stamp < OpenTime)
				{
					_state = Closed;
					_next_tick_time = day_time + OpenTime;
				}
				else if (day_stamp < CloseTime)
				{
					_state = Opened;
					_next_tick_time = day_time + CloseTime;
				}
				else
				{
					_state = Closed;
					_next_tick_time = day_time + OpenTime + DAY;
				}
			}
			
			if (_next_time_05_00 == 0)
				_next_time_05_00 = Common::getLastTime(5);
			if (_next_time_20_00 == 0)
				_next_time_20_00 = Common::getLastTime(20);
			if (_next_time_03_00 == 0)
				_next_time_03_00 = Common::getLastTime(3);

		}

		bool State::_auto_save()
		{
			mongo::BSONObj key = BSON("ci" << (int)DBIDX_STATE);
			mongo::BSONObjBuilder obj;
			obj << "ci" << (int)DBIDX_STATE << "5min" << _next_5_min_tick_time
				<< "ntt" << _next_tick_time << "nct" << _next_clear_time << "st" << _state
				<< "tm0500" << _next_time_05_00 << "tm2000" << _next_time_20_00
				<< "tm0300" << _next_time_03_00 << "ufg" << _unity_flag;
			return db_mgr.SaveMongo(DBN::dbKingdomWarCityBase, key, obj.obj());
		}

		void State::reset5MinTime()
		{
			_next_5_min_tick_time += 5 * MINUTE;
			_sign_save();
		}

		void State::resetTickTimeAndState()
		{
			if (_state == Closed)
			{
				_state = Opened;
				_next_tick_time += (CloseTime - OpenTime);
			}
			else
			{
				_state = Closed;
				_next_tick_time = Common::getNextTimeTS(_next_tick_time, OpenTime);
			}
			_sign_save();
		}

		void State::resetClearTime()
		{
			_next_clear_time = season_sys.getNSTimeHMS(_next_clear_time, SEASON::Spring, 5, 0, 0);
			_sign_save();
		}

		void State::resetTime05_00()
		{
			_next_time_05_00 += DAY;
			_sign_save();
		}

		void State::resetTime20_00()
		{
			_next_time_20_00 += DAY;
			_sign_save();
		}

		void State::resetTime03_00()
		{
			_next_time_03_00 += DAY;
			_sign_save();
		}

		void State::setUnityFlag()
		{
			_unity_flag = true;
			_sign_save();
		}

		void State::clearUnityFlag()
		{
			_unity_flag = false;
			_sign_save();
		}

		Sign::Sign(int nation)
			: _nation(nation)
		{
		}

		void Sign::init(const mongo::BSONObj& obj)
		{
			checkNotEoo(obj["sign"])
			{
				std::vector<mongo::BSONElement> ele = obj["sign"].Array();
				for (unsigned i = 0; i < ele.size(); ++i)
				{
					int id = ele[i]["i"].Int();
					std::string str = ele[i]["s"].String();	
					int type = ele[i]["t"].Int();
					if (type == SIGN_RETREAT 
						&& retreatNum() >= RetreatSignMax)
						continue;
					_id_list.push_back(Item(id, str, type));
				}
			}
		}
		
		bool Sign::_auto_save()
		{
			mongo::BSONObj key = BSON("ci" << _nation - 4);
			mongo::BSONObjBuilder obj;
			obj << "ci" << _nation - 4;
			{
				mongo::BSONArrayBuilder b;
				ForEachC(IDList, it, _id_list)
					b.append(BSON("i" << it->id << "s" << it->str << "t" << it->type));
				obj << "sign" << b.arr();
			}
			return db_mgr.SaveMongo(DBN::dbKingdomWarCityBase, key, obj.obj());
		}

		int Sign::retreatNum() const
		{
			int num = 0;
			ForEachC(IDList, it, _id_list)
			{
				if (it->type == SIGN_RETREAT)
					++num;
			}
			return num;
		}

		int Sign::setSign(playerDataPtr d, int type, int id, const std::string& str, int sign_type)
		{
			int title = d->KingFight().getTitle();
			if (title != Kingdom::GuoWang
				&& title != Kingdom::ZuoChengXiang
				&& title != Kingdom::YouChengXiang)
				return err_kingdomwar_not_king;

			if (type == 0)
			{
				ForEach(IDList, it, _id_list)
				{
					if (it->id == id)
					{
						_id_list.erase(it);
						_sign_save();
						return res_sucess;
					}	
				}
				return err_illedge;
			}
			
			ForEach(IDList, it, _id_list)
			{
				if (it->id == id)
				{
					if (sign_type == SIGN_RETREAT
						&& it->type == SIGN_ATTACK
						&& retreatNum() >= RetreatSignMax)
						return err_kingdomwar_retreat_sign_too_much;
					it->str = str;
					it->type = sign_type;
					_sign_save();
					return res_sucess;
				}	
			}

			if (_id_list.size() >= SignMax)
				return err_illedge;
			if (sign_type == RetreatSignMax
				&& retreatNum() > RetreatSignMax)
				return err_kingdomwar_retreat_sign_too_much;
			_id_list.push_back(Item(id, str, sign_type));
			Log(DBLOG::strLogKingdomWar, d, 3, id);
			_sign_save();
			return res_sucess;
		}

		void Sign::clear()
		{
			if (!_id_list.empty())
			{
				_id_list.clear();
				_sign_save();
			}
		}

		void Sign::getInfo(qValue& q)
		{
			ForEachC(IDList, it, _id_list)
			{
				qValue tmp;
				it->getInfo(tmp);
				q.append(tmp);
			}
		}

		bool Sign::access(int id) const
		{
			ForEachC(IDList, it, _id_list)
			{
				if (it->id == id)
					return it->type != SIGN_RETREAT;
			}
			return true;
		}

		void Sign::sendChatInfo(playerDataPtr d)
		{
			ForEachC(IDList, it, _id_list)
			{
				qValue bc;
				bc << 12 << it->id << it->str << it->type;
				qValue data;
				data << (int)res_sucess << (int)CHAT::chat_kingdom << chat_sys.ServerPackageQ(CHAT::server_kingdom_war)
					<< bc << (int)CHATPOS::chat_windows << qValue(qJson::qj_object);
				chat_sys.sendToPlayer(d->ID(), data);
			}
		}

		SignList::SignList()
		{
			init();
		}
		
		void SignList::init()
		{
			for (unsigned i = 0; i < Kingdom::nation_num; ++i)
			{
				_sign.push_back(Creator<Sign>::Create(i));
				mongo::BSONObj key = BSON("ci" << i - 4);
				mongo::BSONObj obj = db_mgr.FindOne(DBN::dbKingdomWarCityBase, key);
				if (obj.isEmpty())
					continue;
				_sign[i]->init(obj);
			}
		}

		bool SignList::access(int nation, int id) const
		{
			return _sign[nation]->access(id);
		}

		int SignList::setSign(playerDataPtr d, int type, int id, const std::string& str, int sign_type)
		{
			return _sign[d->Info().Nation()]->setSign(d, type, id, str, sign_type);
		}

		void SignList::getInfo(qValue& q, int nation)
		{
			return _sign[nation]->getInfo(q);
		}

		void SignList::clear()
		{
			for (unsigned i = 0; i < Kingdom::nation_num; ++i)
				_sign[i]->clear();
		}

		void SignList::sendChatInfo(playerDataPtr d)
		{
			if (d->Info().Nation() == Kingdom::null)
				return;
			_sign[d->Info().Nation()]->sendChatInfo(d);
		}

		KingdomBuff::KingdomBuff()
		{
			_buff.assign(Kingdom::nation_num, 0);
			init();
		}

		void KingdomBuff::init()
		{
			Json::Value info = Common::loadJsonFile("./instance/kingdom_war/kingdom_buff.json");
			Json::Value& max = info["max"];
			ForEach(Json::Value, it, max)
				_max.push_back((*it).asInt());
			_min = info["min"].asInt();
			_add = info["add"].asInt();
			Json::Value& ch = info["change"];
			ForEach(Json::Value, it, ch)
				_change.push_back((*it).asInt());
			Json::Value& down = info["down"];
			ForEach(Json::Value, it, down)
				_down.push_back((*it).asInt());

			mongo::BSONObj key = BSON("ci" << -5);
			mongo::BSONObj obj = db_mgr.FindOne(DBN::dbKingdomWarCityBase, key);
			if (obj.isEmpty())
				return;
			
			std::vector<mongo::BSONElement> ele = obj["b"].Array();
			for (unsigned i = 0; i < ele.size(); ++i)
				_buff[i] = ele[i].Int();
		}

		bool KingdomBuff::_auto_save()
		{
			mongo::BSONObj key = BSON("ci" << -5);
			mongo::BSONObjBuilder obj;
			obj << "ci" << -5;
			{
				mongo::BSONArrayBuilder b;
				for (unsigned i = 0; i < _buff.size(); ++i)
					b.append(_buff[i]);
				obj << "b" << b.arr();
			}
			return db_mgr.SaveMongo(DBN::dbKingdomWarCityBase, key, obj.obj());
		}

		void KingdomBuff::getInfo(qValue& q)
		{
			for (unsigned i = 0; i < _buff.size(); ++i)
				q.append(_buff[i]);
		}

		void KingdomBuff::reset(unsigned tick_time)
		{
			for (unsigned i = 0; i < _buff.size(); ++i)
			{
				int prev = _buff[i];
				int num = CityCounter::shared().num(i);
				int max = num >= _max.size()? _max[_max.size()-1]:_max[num];
				if (_buff[i] > max)
				{
					int down = num >= _down.size()? _down[_down.size()-1]:_down[num];
					_buff[i] -= down;
					if (_buff[i] < max)
						_buff[i] = max;
					if (_buff[i] < _min)
						_buff[i] = _min;
				}
				int add = 0;
				for (unsigned j = 0; j < Kingdom::nation_num; ++j)
				{
					if (i == j)
						add -= (2 * CityCounter::shared().num(j));
					else
						add += CityCounter::shared().num(j);
				}
				if (add > 0)
				{
					if (_buff[i] >= max)
					{
					}
					else
					{
						_buff[i] += add;
						if (_buff[i] > max)
							_buff[i] = max;
					}
				}
				else
				{
					_buff[i] += add;
				}
				if (_buff[i] < _min)
					_buff[i] = _min;
				Log(DBLOG::strLogKingdomWar, 8, i, tick_time, num, prev, _buff[i]);
			}
			_sign_save();
		}

		int KingdomBuff::getBuff(int nation)
		{
			return _buff[nation] * _add;
		}

		NpcRule::NpcRule(const Json::Value& info)
		{
			_power_begin = info["power_start"].asInt();
			_power_end = info["power_end"].asInt();
			_npc_begin = info["npc_start"].asInt();
			_npc_end = info["npc_end"].asInt();
			_food = info["food"].asInt();
			_battle_value = info["battle_value"].asInt();
		}

		NpcRuleMgr::NpcRuleMgr()
			: _cur_index1(-1), _cur_index2(-1)
		{
			loadFile();
			//kingdomwar_sys.add5MinTicker(boostBind(NpcRuleMgr::tick, this));
		}

		void NpcRuleMgr::loadFile()
		{
			Json::Value json = Common::loadJsonFile("./instance/kingdom_war/npc2_power.json");
			_npc_rate = json["rate"].asDouble();
			json = Common::loadJsonFile("./instance/kingdom_war/npc_rule.json");
			ForEach(Json::Value, it, json)
				_rule_list.push_back(NpcRule(*it));
		}

		void NpcRuleMgr::resetIndex1() const
		{
			unsigned param = activity_player_sys.lastActivityPlayer();
			int min = param * 1.47;
			if (min < 100) min = 100;
			int max = param * 1.57;
			if (max < 107) max = 107;
			int bv = heroparty_sys.getAverageBV(min, max);
			for (unsigned i = 0; i < _rule_list.size(); ++i)
			{
				if (bv >= _rule_list[i]._power_begin
					&& bv <= _rule_list[i]._power_end)
				{
					_cur_index1 = i;
					return;
				}
			}
			_cur_index1 = _rule_list.size() - 1;
		}

		void NpcRuleMgr::resetIndex2() const
		{
			unsigned param = activity_player_sys.lastActivityPlayer();
			int min = param * 1.47;
			if (min < 100) min = 100;
			int max = param * 1.57;
			if (max < 107) max = 107;
			int bv = heroparty_sys.getAverageBV(min, max) * _npc_rate;
			for (unsigned i = 0; i < _rule_list.size(); ++i)
			{
				if (bv >= _rule_list[i]._power_begin
					&& bv <= _rule_list[i]._power_end)
				{
					_cur_index2 = i;
					return;
				}
			}
			_cur_index2 = _rule_list.size() - 1;
		}

		ShadowNpcRuleMgr::ShadowNpcRuleMgr()
			: _cur_index(-1)
		{
			loadFile();
			kingdomwar_sys.add5MinTicker(boostBind(ShadowNpcRuleMgr::tick, this));
		}

		void ShadowNpcRuleMgr::loadFile()
		{
			Json::Value json = Common::loadJsonFile("./instance/kingdom_war/npc_shadow_rule.json");
			ForEach(Json::Value, it, json)
				_rule_list.push_back(NpcRule(*it));
		}

		void ShadowNpcRuleMgr::resetIndex() const
		{
			int bv = heroparty_sys.getAverageBV(3, 7);
			for (unsigned i = 0; i < _rule_list.size(); ++i)
			{
				if (bv >= _rule_list[i]._power_begin
					&& bv <= _rule_list[i]._power_end)
				{
					_cur_index = i;
					return;
				}
			}
			_cur_index = _rule_list.size() - 1;
		}

		bool GreatEvent::_auto_save()
		{
			mongo::BSONObj key = BSON("t" << _time);
			mongo::BSONObj obj = BSON("t" << _time << "n" << _nation << "e" << _data.toIndentString());
			return db_mgr.SaveMongo(DBN::dbKingdomWarGreatEvent, key, obj);
		}

		static bool CmpGreatEvent(const GreatEventPtr& a, const GreatEventPtr& b)
		{
			return (*a) < (*b);
		}

		GreatEventMgr::GreatEventMgr()
			: _max_time(0)
		{
			loadFile();
			loadDB();
		}

		void GreatEventMgr::loadFile()
		{
			Json::Value json = Common::loadJsonFile("./instance/kingdom_war/unity_reward.json");
			_win_reward = actionFormat(json["win"].asInt());
			_lose_reward = actionFormat(json["lose"].asInt());
		}
		
		void GreatEventMgr::loadDB()
		{
			objCollection objs = db_mgr.Query(DBN::dbKingdomWarGreatEvent);
			for (unsigned i = 0; i < objs.size(); ++i)
			{
				const mongo::BSONObj& obj = objs[i];
				unsigned time = obj["t"].Int();
				std::string str = obj["e"].String();
				int nation = obj["n"].Int();
				_data.push_back(Creator<GreatEvent>::Create(time, nation, str));
			}
			if (!_data.empty())
			{
				std::sort(_data.begin(), _data.end(), CmpGreatEvent);
				_max_time = _data.back()->time();
			}
		}

		NpcIDCreator::NpcIDCreator()
		{
			mongo::BSONObj key = BSON(strNpcID << 0);
			mongo::BSONObj obj = db_mgr.FindOne(DBN::dbKingdomWarNpc, key);
			if (!obj.isEmpty())
				_id = obj["mi"].Int();
			else
				_id = 0;
		}

		int NpcIDCreator::get()
		{
			--_id;
			_sign_save();
			return _id;
		}

		bool NpcIDCreator::_auto_save()
		{
			mongo::BSONObj key = BSON(strNpcID << 0);
			mongo::BSONObj obj = BSON(strNpcID << 0 << "mi" << _id);
			return db_mgr.SaveMongo(DBN::dbKingdomWarNpc, key, obj);
		}

		ShadowCost::ShadowCost()
			: _error_cost(-1, -1)
		{
			loadFile();
		}

		void ShadowCost::loadFile()
		{
			Json::Value json = Common::loadJsonFile("./instance/kingdom_war/shadow_cost.json");
			Json::Value& rcost = json["cost"];
			ForEach(Json::Value, it, rcost)
			{
				Costs c;
				Json::Value& tmp = *it;
				ForEach(Json::Value, itc, tmp)
					c.push_back(nShadow::Cost(*itc));
				_costs.push_back(c);
			}
			Json::Value& rvip = json["vip"];
			ForEach(Json::Value, it, rvip)
			{
				Times t;
				Json::Value& tmp = *it;
				ForEach(Json::Value, itt, tmp)
					t.push_back((*itt).asInt());
				_times.push_back(t);
			}
		}

		nShadow::Cost ShadowCost::get(int type, playerDataPtr d, unsigned times) const
		{
			if (type == SHADOW::DEFENSE_NPC)
				type = SHADOW::NPC;
			if (type < 0 || type >= _costs.size())
				return _error_cost;
			if (_costs[type].empty())
				return _error_cost;
			if (times >= _costs[type].size())
				times = _costs[type].size() - 1;
			nShadow::Cost c = _costs[type][times];
			if (type == SHADOW::NPC)
				c.food = NpcRuleMgr::shared().food();
			else if (type == SHADOW::PLAYER)
				c.food = d->KingDomWarFM().getMaxHp(0) * c.food;
			return c;
		}

		unsigned ShadowCost::maxTimes(int type, playerDataPtr d) const
		{
			if (XiaoHao::shared().check(d))
				return XiaoHao::shared().shadowTimes(type);
			int idx = (type == SHADOW::NPC || type == SHADOW::DEFENSE_NPC)? d->LV() : d->Info().VipLv();
			if (_times.empty())
				return 0;
			if (idx >= _times.size())
				idx = _times.size() - 1;
			if (type < 0 || type >= _times[idx].size())
				return 0;
			return _times[idx][type];
		}

		BoxLimit::BoxLimit()
		{
			loadFile();
		}

		void BoxLimit::loadFile()
		{
			const Json::Value json = Common::loadJsonFile("./instance/kingdom_war/box_limit.json");
			const Json::Value& gold_box = json["gold_box"];
			ForEachC(Json::Value, it, gold_box)
				_gold_box.push_back((*it).asInt());
			const Json::Value& silver_box = json["silver_box"];
			ForEachC(Json::Value, it, silver_box)
				_silver_box.push_back((*it).asInt());
			const Json::Value& home_box = json["home_box"];
			ForEachC(Json::Value, it, home_box)
				_home_box.push_back((*it).asInt());
		}

		NationParam::NationParam()
		{
			loadFile();
			init();
			loadDB();
		}

		void NationParam::loadFile()
		{
			Json::Value json = Common::loadJsonFile("./instance/kingdom_war/tower_times.json");
			const Json::Value& tt = json["tt"];
			ForEachC(Json::Value, it, tt)
			{
				std::vector<unsigned> temp;
				const Json::Value& ptt = *it;
				ForEachC(Json::Value, itt, ptt)
					temp.push_back((*itt).asInt());
				_type_tower_times.push_back(temp);
			}
		}

		void NationParam::init()
		{
			_call_tower_times.assign(Kingdom::nation_num, 0);
			_max_call_tower_times.assign(Kingdom::nation_num, _type_tower_times[2][0]);
		}

		void NationParam::loadDB()
		{
			mongo::BSONObj key = BSON("ci" << (int)DBIDX_PARAM);
			mongo::BSONObj obj = db_mgr.FindOne(DBN::dbKingdomWarCityBase, key);
			if (obj.isEmpty())
				return;
			
			{
				std::vector<mongo::BSONElement> ele = obj["ctt"].Array();
				for (unsigned i = 0; i < ele.size(); ++i)
					_call_tower_times[i] = ele[i].Int();
			}
			checkNotEoo(obj["mctt"])
			{
				std::vector<mongo::BSONElement> ele = obj["mctt"].Array();
				for (unsigned i = 0; i < ele.size(); ++i)
					_max_call_tower_times[i] = ele[i].Int();
			
			}
		}

		bool NationParam::_auto_save()
		{
			mongo::BSONObj key = BSON("ci" << (int)DBIDX_PARAM);
			mongo::BSONObjBuilder obj;
			obj << "ci" << (int)DBIDX_PARAM;
			{
				mongo::BSONArrayBuilder b;
				for (unsigned i = 0; i < _call_tower_times.size(); ++i)
					 b.append(_call_tower_times[i]);
				obj << "ctt" << b.arr();
			}
			{
				mongo::BSONArrayBuilder b;
				for (unsigned i = 0; i < _call_tower_times.size(); ++i)
					 b.append(_max_call_tower_times[i]);
				obj << "mctt" << b.arr();
			}
			return db_mgr.SaveMongo(DBN::dbKingdomWarCityBase, key, obj.obj());
		}

		struct CmpBuffInfo
		{
			CmpBuffInfo(int n, int b)
				: nation(n), buff(b){}
			bool operator<(const CmpBuffInfo& rhs) const
			{
				return buff > rhs.buff;
			}
			int nation;
			int buff;
		};

		void NationParam::reset()
		{
			for (unsigned i = 0; i < _call_tower_times.size(); ++i)
				_call_tower_times[i] = 0;
			std::vector<CmpBuffInfo> cmp_buff;
			for (unsigned i = 0; i < Kingdom::nation_num; ++i)
				cmp_buff.push_back(CmpBuffInfo(i, KingdomBuff::shared().getBuff(i)));
			std::sort(cmp_buff.begin(), cmp_buff.end());
	
			int type = 0;
			if (cmp_buff[0].buff == cmp_buff[1].buff
				&& cmp_buff[1].buff == cmp_buff[2].buff)
				type = 2;
			else if (cmp_buff[0].buff == cmp_buff[1].buff) // weak weak strong
				type = 0;
			else if (cmp_buff[1].buff == cmp_buff[2].buff) // weak strong strong
				type = 1;
			else
				type = 3;
			for (unsigned i = 0; i < cmp_buff.size(); ++i)
				_max_call_tower_times[cmp_buff[i].nation] = _type_tower_times[type][i];
			_sign_save();
		}
			
		void NationParam::alterTowerTimes(int nation)
		{
			++_call_tower_times[nation];
			_sign_save();
		}
			
		void NationParam::getInfo(qValue& q, int nation) const
		{
			q.addMember("tt", _call_tower_times[nation]);
			q.addMember("mt", _max_call_tower_times[nation]);
		}

		ReturnParam::ReturnParam()
		{
		}

		int ReturnParam::fight_army_id;
		int ReturnParam::fight_target_type;
		std::string ReturnParam::fight_target_name;
		int ReturnParam::result;

		PrimeState::PrimeState()
			: _prime_state(-1), _inited(false), _last_prime_time(0)
		{
			loadDB();
			init();
		}

		void PrimeState::loadDB()
		{
			mongo::BSONObj key = BSON("ci" << (int)DBIDX_PRIME_STATE);
			mongo::BSONObj obj = db_mgr.FindOne(DBN::dbKingdomWarCityBase, key);
			if (obj.isEmpty())
			{
				_inited = true;
				return;
			}
			
			_prime_state = obj["ps"].Int();
			_next_index = obj["ni"].Int();
			_next_tick_time = obj["ntt"].Int();
			{
				std::vector<mongo::BSONElement> ele = obj["cit"].Array();
				for (unsigned i = 0; i < ele.size(); ++i)
					_cur_items.push_back(Item(ele[i]["t"].Int(), ele[i]["s"].Int()));
			}
			if (obj["lpt"].eoo())
			{
				unsigned cur_time = Common::gameTime();	
				unsigned last_prime_time1 = Common::getLastTimeTS(cur_time, _cur_items[0u].tick_time);
				unsigned last_prime_time2 = Common::getLastTimeTS(cur_time, _cur_items[2u].tick_time);
				_last_prime_time = last_prime_time1 > last_prime_time2? last_prime_time1 : last_prime_time2;
			}
			else
			{
				_last_prime_time = obj["lpt"].Int();
			}
		}

		void PrimeState::init()
		{
			_backup_items.push_back(Item(PrimeOpenTime1, PrimeTime));
			_backup_items.push_back(Item(PrimeCloseTime1, OrdinaryTime));
			_backup_items.push_back(Item(PrimeOpenTime2, PrimeTime));
			_backup_items.push_back(Item(PrimeCloseTime2, OrdinaryTime));

			if (_prime_state == -1)
			{
				_cur_items = _backup_items;
				_prime_state = _cur_items.back().state;
				_next_index = 0;
				unsigned cur_time = Common::gameTime();
				unsigned time_zero = Common::timeZero(cur_time);
				_next_tick_time = time_zero + _cur_items.front().tick_time;
			}
			Timer::add(_next_tick_time, boostBind(PrimeState::tick, this));
		}

		bool PrimeState::_auto_save()
		{
			mongo::BSONObj key = BSON("ci" << (int)DBIDX_PRIME_STATE);
			mongo::BSONObjBuilder obj;
			obj << "ci" << (int)DBIDX_PRIME_STATE << "ps" << _last_prime_state
				<< "ni" << _last_index << "ntt" << _last_tick_time << "lpt" << _last_prime_time;
			{
				mongo::BSONArrayBuilder b;
				for (unsigned i = 0; i < _cur_items.size(); ++i)
					b.append(BSON("t" << _cur_items[i].tick_time << "s" << _cur_items[i].state));
				obj << "cit" << b.arr();
			}
			return db_mgr.SaveMongo(DBN::dbKingdomWarCityBase, key, obj.obj());
		}

		void PrimeState::tick()
		{
			if (_next_index == _cur_items.size())
			{
				_cur_items = _backup_items;
				_next_index = 0;
			}
			_last_prime_state = _prime_state;
			_last_index = _next_index;
			_last_tick_time = _next_tick_time;

			_prime_state = _cur_items[_next_index].state;
			unsigned tick_time = _next_tick_time;
			++_next_index;
			if (_next_index == _cur_items.size())
			{
				_next_tick_time = Common::getNextTimeHMS(_next_tick_time, 0, 0, 0);
				_next_tick_time += _backup_items.front().tick_time;
			}
			else
			{
				unsigned add_time = _cur_items[_next_index].tick_time - _cur_items[_next_index - 1].tick_time;
				_next_tick_time += add_time;
			}
			if (_prime_state == PrimeTime)
				_last_prime_time = tick_time;
			Timer::add(_next_tick_time, boostBind(PrimeState::tick, this));
			if (!_inited)
			{
				kingdomwar_sys.initPrimeState(tick_time);
				_inited = true;
			}
			else
			{
				if (_prime_state == PrimeTime)
					kingdomwar_sys.tickPrimeTime(tick_time);
				else
					kingdomwar_sys.tickOrdinaryTime(tick_time);
			}
			_sign_save();
		}

		ChannelMgr::Message::Message(playerDataPtr d, const std::string& s)
		{
			player = chat_sys.ChatPackageQ(d);
			str = s;
		}

		ChannelMgr::Message::Message(const mongo::BSONElement& obj)
		{
			player = qValue(obj["p"].String().c_str());
			str = obj["s"].String();
		}

		void ChannelMgr::Message::getInfo(qValue& q)
		{
			qValue tmp;
			tmp = player.Copy();
			q << tmp << str;
		}

		mongo::BSONObj ChannelMgr::Message::toBSON()
		{
			return BSON("p" << player.toIndentString() << "s" << str);
		}

		ChannelMgr::ChannelMgr()
		{
			_msg_lists.assign(Kingdom::nation_num, MsgList());
			loadDB();
		}

		void ChannelMgr::tick()
		{
			for (unsigned i = 0; i < _msg_lists.size(); ++i)
				_msg_lists[i].clear();
			_sign_save();
		}
			
		const static std::string NATION_STR[] = {"0", "1", "2"};

		void ChannelMgr::loadDB()
		{
			mongo::BSONObj key = BSON("ci" << (int)DBIDX_CHANNEL);
			mongo::BSONObj obj = db_mgr.FindOne(DBN::dbKingdomWarCityBase, key);
			if (obj.isEmpty())
				return;
			for (unsigned i = 0; i < 3; ++i)
			{
				std::vector<mongo::BSONElement> ele = obj[NATION_STR[i]].Array();
				for (unsigned j = 0; j < ele.size(); ++j)
					_msg_lists[i].push_back(Message(ele[j]));
			}
		}

		bool ChannelMgr::_auto_save()
		{
			mongo::BSONObj key = BSON("ci" << (int)DBIDX_CHANNEL);
			mongo::BSONObjBuilder obj;
			obj << "ci" << (int)DBIDX_CHANNEL;
			for (unsigned i = 0; i < _msg_lists.size(); ++i)
			{
				mongo::BSONArrayBuilder b;
				ForEach(MsgList, it, _msg_lists[i])
					b.append(it->toBSON());
				obj << NATION_STR[i] << b.arr();
			}
			return db_mgr.SaveMongo(DBN::dbKingdomWarCityBase, key, obj.obj());
		}

		int ChannelMgr::send(playerDataPtr d, const std::string& str)
		{
			int title = d->KingFight().getTitle();
			if (title != Kingdom::GuoWang
				&& title != Kingdom::ZuoChengXiang
				&& title != Kingdom::YouChengXiang)
				return err_illedge;
			if (Common::gameTime() < d->KingDomWarShop().channelCD())
				return err_illedge;
			int nation = d->Info().Nation();
			_msg_lists[nation].push_back(Message(d, str));
			while (_msg_lists[nation].size() > ChannelMsgSize)
				_msg_lists[nation].pop_front();
			update(nation);
			d->KingDomWarShop().channelSend();
			_sign_save();
			return res_sucess;
		}

		void ChannelMgr::update(playerDataPtr d)
		{
			int nation = d->Info().Nation();
			if (nation == Kingdom::null)
				return;
			qValue m;
			m.append(res_sucess);
			qValue q;
			ForEach(MsgList, it, _msg_lists[nation])
			{
				qValue tmp;
				it->getInfo(tmp);
				q << tmp;
			}
			m.append(q);
			d->sendToClientFillMsg(gate_client::kingdom_war_channel_data_resp, m);
		}

		void ChannelMgr::update(int nation)
		{
			if (_msg_lists[nation].empty())
				return;
			std::vector<int> id_list;
			ForEachC(Observer::IdList, it, kingdomwar_sys.getObserver())
			{
				playerDataPtr d = player_mgr.getOnlinePlayer(*it);
				if (d && d->Info().Nation() == nation)
					id_list.push_back(*it);
			}
			qValue m(qJson::qj_object);
			qValue mm;
			mm.append(res_sucess);
			qValue q;
			qValue tmp;
			_msg_lists[nation].back().getInfo(tmp);
			q.append(tmp);
			mm.append(q);
			m.addMember(strMsg, mm);
			Batch::batchSign(id_list, m, gate_client::kingdom_war_channel_data_resp);
		}

		ItemConfig::ItemConfig()
		{
			loadFile();
		}

		int ItemConfig::getMaxUseTimes(playerDataPtr d, int id) const
		{
			if (XiaoHao::shared().check(d))
				return XiaoHao::shared().itemTimes(id);
			std::map<int, int>::const_iterator it = _id2max.find(id);
			return it == _id2max.end()? 0 : it->second;
		}

		void ItemConfig::loadFile()
		{
			Json::Value json = Common::loadJsonFile("./instance/kingdom_war/items.json");
			_shadow_items.push_back(ShadowItem(json["shadow_item1"]));
			_id2max.insert(make_pair(_shadow_items.back().item_id, _shadow_items.back().max));
			_shadow_items.push_back(ShadowItem(json["shadow_item2"]));
			_id2max.insert(make_pair(_shadow_items.back().item_id, _shadow_items.back().max));
			_shadow_items.push_back(ShadowItem(json["shadow_item3"]));
			_id2max.insert(make_pair(_shadow_items.back().item_id, _shadow_items.back().max));
			_shadow_items.push_back(ShadowItem(json["shadow_item4"]));
			_id2max.insert(make_pair(_shadow_items.back().item_id, _shadow_items.back().max));
			_tower_items.push_back(TowerItem(json["add_tower_time_item"]));
			_id2max.insert(make_pair(_tower_items.back().item_id, _tower_items.back().max));
			_tower_items.push_back(TowerItem(json["sub_tower_time_item"]));
			_id2max.insert(make_pair(_tower_items.back().item_id, _tower_items.back().max));
			_transfer_item.init(json["transfer_item"]);
			_id2max.insert(make_pair(_transfer_item.item_id, _transfer_item.max));
			_fight_item.init(json["fight_item"]);
			_id2max.insert(make_pair(_fight_item.item_id, _fight_item.max));
		}

		XiaoHao::XiaoHao()
		{
			const Json::Value json = Common::loadJsonFile("./instance/kingdom_war/xiaohao.json");
			const Json::Value& lv = json["lv"];
			ForEachC(Json::Value, it, lv)
				_lv_limit.push_back((*it).asInt());
			const Json::Value& bv = json["bv"];
			ForEachC(Json::Value, it, bv)
				_bv_limit.push_back((*it).asInt());
			const Json::Value& st = json["shadow_times"];
			ForEachC(Json::Value, it, st)
				_shadow_times.push_back((*it).asInt());
			_item_rate = json["item_rate"].asDouble();
			const Json::Value& itt = json["item_times"];
			ForEachC(Json::Value, it, itt)
				_item_times.insert(make_pair((*it)[0u].asInt(), (*it)[1u].asInt()));
			tick();
		}

		bool XiaoHao::check(playerDataPtr d) const
		{
			return d->LV() < _cur_lv && d->Info().VipLv() < 3 && d->Info().MaxBV() < _cur_bv;
		}

		void XiaoHao::tick()
		{
			int idx = (Common::gameTime() - season_sys.openTime()) / DAY;
			if (idx < 0)
				idx = 0;
			_cur_lv = _lv_limit[idx >= _lv_limit.size()? (_lv_limit.size()-1):idx];
			_cur_bv = _bv_limit[idx >= _bv_limit.size()? (_bv_limit.size()-1):idx];
			Timer::add(Common::getNextTimeHMS(Common::gameTime(), 5), boostBind(XiaoHao::tick, this));
		}
	}

	enum
	{
		ExploitRankSize = 100,	
	};

	ExploitRankItem::ExploitRankItem(playerDataPtr d)
	{
		_pid = d->ID();
		_name = d->Name();
		_nation = d->Info().Nation();
		_exploit = d->KingDomWar().getTotalExploit();
		_lv = d->LV();
	}

	void ExploitRankItem::getInfo(qValue& q) const
	{
		q << _pid << _name << _nation << _lv << _exploit;
	}

	static bool CmpRankPtr(const ExploitRank::RankItem& a, const ExploitRank::RankItem& b)
	{
		if (a->value() == b->value())
			return a->id() < b->id();
		return a->value() > b->value();
	}

	ExploitRank::ExploitRank()
	{
		loadDB();
		_modified = true;
	}

	void ExploitRank::loadDB()
	{
		objCollection objs = db_mgr.Query(DBN::dbPlayerKingdomWar);
		std::vector<RankItem> sorted_player;
		ForEachC(objCollection, it, objs)
		{
			int pid = (*it)[strPlayerID].Int();
			playerDataPtr d = player_mgr.getPlayer(pid);
			if (d && d->KingDomWar().getTotalExploit() > 0)
				sorted_player.push_back(Creator<ExploitRankItem>::Create(d));
		}
		std::sort(sorted_player.begin(), sorted_player.end(), CmpRankPtr);
		for (unsigned i = 0; i < sorted_player.size(); ++i)
		{
			if (i >= ExploitRankSize
				&& sorted_player[i]->value() != sorted_player[i-1]->value())
				break;
			_rank.update(sorted_player[i], 0);
		}
	}

	void ExploitRank::getInfo(qValue& q)
	{
		if (_modified)
		{
			_modified = false;
			_rk = 0;
			_info.toArray();
			_rank.run(boostBind(ExploitRank::packageItem, this, _1), 0, ExploitRankSize);
		}
		q = _info.Copy();
	}

	void ExploitRank::packageItem(const ExploitRankItem& e)
	{
		++_rk;
		qValue tmp;
		e.getInfo(tmp);
		_info.append(tmp);
	}

	int ExploitRank::rank(playerDataPtr d) const
	{
		int rk = _rank.getRank(d->ID(), d->KingDomWar().getTotalExploit());
		return rk == 0? -1 : rk;
	}

	void ExploitRank::update(playerDataPtr d)
	{
		qValue m;
		m.append(res_sucess);
		qValue q(qJson::qj_object);
		qValue tmp_info;
		getInfo(tmp_info);
		q.addMember("rl", tmp_info);
		q.addMember("rk", rank(d));
		q.addMember("e", d->KingDomWar().getTotalExploit());
		m.append(q);
		d->sendToClientFillMsg(gate_client::kingdom_war_exploit_rank_resp, m);
	}
	
	void ExploitRank::update(playerDataPtr d, int old_val)
	{
		int val = d->KingDomWar().getTotalExploit();
		if (val < _rank.minV() && _rank.size() >= ExploitRankSize)
			return;
		if (old_val < _rank.minV())
			old_val = 0;
		RankItem ptr = Creator<ExploitRankItem>::Create(d);
		_rank.update(ptr, old_val);
		_modified = true;
	}
}


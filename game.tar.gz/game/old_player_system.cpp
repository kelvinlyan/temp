#include "old_player_system.h"
#include "player_old_player.h"

const static std::string strActiID = "ai";
const static std::string strActiSTime = "st";
const static std::string strActiETime = "et";
const static std::string strActiLv = "lv";
const static std::string strActiDay = "day";
const static std::string strActiBacks = "back";
const static std::string strActiRecharge = "recharge";

namespace gg
{

	old_player_system* const old_player_system::_Instance = new old_player_system();

	old_player_system::old_player_system()
	{
		_curr.id = -1;
	}

	//�������ۼƳ�ֵ���
	void old_player_system::rechargeHelper(playerDataPtr player, int gold)
	{
		if (!player || gold < 1)
		{
			return;
		}
		select();
		player->OldPlayer().setActiId(_curr.id);
		if (_curr.id == -1 || player->LV() < _curr.lv)
		{
			return;
		}
		if (player->OldPlayer().canSetOffday())
		{
			int off_day = player->CommonOffline().getStandardDay();
			if (off_day >= _curr.off_day)
			{
				player->OldPlayer().setOffday(off_day);
			}
		}
		if (player->OldPlayer().getOffday() >= _curr.off_day)
		{
			player->OldPlayer().addAccuGold(gold);
			int gold = player->OldPlayer().getGold();
			for (int i = 0; i < _curr.recharge.size(); ++i)
			{
				if (gold >= _curr.recharge[i].m)
				{
					player->OldPlayer().addRechargeBox(_curr.recharge[i].m, _curr.recharge[i].jsonBox);
				}
			}
		}

	}

	//�������ۼƵ�½����
	void old_player_system::reqRedPoint(net::Msg& m, Json::Value& r)
	{
		playerDataPtr player = player_mgr.getPlayer(m.playerID);
		if (!player)Return(r, err_illedge);

		select();//�����һ������
		player->OldPlayer().setActiId(_curr.id);

		unsigned old_offline = player->Offline().OffTime();
		player->CommonOffline().setOffline(old_offline);

		r[strMsg][0u] = 0;
		unsigned now = Common::gameTime();
		if (_curr.id == -1
			|| player->LV() < _curr.lv)
		{
			r[strMsg][1u] = 2;
			r[strMsg][2u] = _curr.id;
			return;
		}
		if (player->OldPlayer().canSetOffday())
		{
			int off_day = player->CommonOffline().getStandardDay();
			if (off_day >= _curr.off_day)
			{
				//LogS << "old_player\toff_day:" << off_day << LogEnd;
				player->OldPlayer().setOffday(off_day);
			}
		}

		if (player->OldPlayer().getOffday() < _curr.off_day)
		{
			r[strMsg][1u] = 2;
			r[strMsg][2u] = _curr.id;
			return;
		}
		//LogS << "login\t" << player->ID() << "\tpn:" << player->Name() << "\tredpoint:" << player->OldPlayer().getRedPoint() << LogEnd;
		//���õ�½
		player->OldPlayer().setLogin();

		player->OldPlayer().addAccuDay();
		int day = player->OldPlayer().getDay();
		for (int i = 0; i < _curr.backs.size(); ++i)
		{
			if (day >= _curr.backs[i].m)
			{
				player->OldPlayer().addBacksBox(_curr.backs[i].m, _curr.backs[i].jsonBox);
			}
		}
		int flag = player->OldPlayer().getRedPoint();
		r[strMsg][1u] = flag;
		r[strMsg][2u] = _curr.id;
	}

	void old_player_system::reqOldPlayerInfo(net::Msg& m, Json::Value& r)
	{
		playerDataPtr player = player_mgr.getPlayer(m.playerID);
		if (!player)Return(r, err_illedge);

		unsigned now = Common::gameTime();
		if (_curr.id == -1
			|| player->LV() < _curr.lv
			|| player->OldPlayer().getOffday() < _curr.off_day
			|| now > _curr.etime
			|| now < _curr.stime)
		{
			Return(r, err_old_player_empty);
		} 
		if (!player->OldPlayer().isOk())
		{
			//LogS << "old player, not ok. redpoint is:" << player->OldPlayer().getRedPoint() << LogEnd;
			Return(r, err_old_player_not_login);
		}

		Json::Value ret_json = Json::arrayValue;
		ret_json.append(_curr.lv);
		ret_json.append(_curr.off_day);
		ret_json.append(_curr.stime == 0 ? 0 : Common::toStampTime(_curr.stime));
		ret_json.append(_curr.etime == 0 ? 0 : Common::toStampTime(_curr.etime));
		ret_json.append(player->OldPlayer().getDay());
		ret_json.append(player->OldPlayer().getGold());
		int has_day = player->OldPlayer().getOffday();
		ret_json.append(has_day);

		Json::Value back_json = Json::arrayValue;
		Json::Value recharge_json = Json::arrayValue;
		for (int i = 0; i < _curr.backs.size(); ++i)
		{
			Json::Value unit = Json::arrayValue;
			unit.append(_curr.backs[i].m);
			unit.append(_curr.backs[i].jsonBox);
			if (player->OldPlayer().isGotDayReward(_curr.backs[i].m))
			{
				unit.append(1);
			}
			else if (player->OldPlayer().hasRewards(1, _curr.backs[i].m))
			{
				unit.append(2);
			}
			else
			{
				unit.append(0);
			}
			back_json.append(unit);
		}
		for (int i = 0; i < _curr.recharge.size(); ++i)
		{
			Json::Value unit = Json::arrayValue;
			unit.append(_curr.recharge[i].m);
			unit.append(_curr.recharge[i].jsonBox);
			if (player->OldPlayer().isGotGoldReward(_curr.recharge[i].m))
			{
				unit.append(1);
			}
			else if (player->OldPlayer().hasRewards(2, _curr.recharge[i].m))
			{
				unit.append(2);
			}
			else
			{
				unit.append(0);
			}
			recharge_json.append(unit);
		}
		ret_json.append(back_json);
		ret_json.append(recharge_json);
		r[strMsg][0u] = 0;
		r[strMsg][1u] = ret_json;
	}

	void old_player_system::reqOldPlayerGetReward(net::Msg& m, Json::Value& r)
	{
		playerDataPtr player = player_mgr.getPlayer(m.playerID);
		if (!player)Return(r, err_illedge);

		ReadJsonArray;
		int type = js_msg[0u].asInt();
		int flag = js_msg[1u].asInt();
		if (!player->OldPlayer().hasRewards(type, flag))
		{
			Return(r, err_reward_empty);
		}
		if (_curr.id == -1
			|| player->LV() < _curr.lv
			|| player->OldPlayer().getOffday() < _curr.off_day)
		{
			Return(r, err_old_player_empty);
		}
		old_player::UnitBox unit_box;
		unit_box.m = -1;
		if (type == 1)
		{
			for (int i = 0; i < _curr.backs.size(); ++i)
			{
				if (_curr.backs[i].m == flag)
				{
					unit_box = _curr.backs[i];
					break;
				}
			}
		}
		else if (type == 2)
		{
			for (int i = 0; i < _curr.recharge.size(); ++i)
			{
				if (_curr.recharge[i].m == flag)
				{
					unit_box = _curr.recharge[i];
					break;
				}
			}
		}
		//ִ���콱
		if (unit_box.m == -1)
		{
			Return(r, err_reward_box_not_found);
		}
		int ret = actionDoBox(player, unit_box.box, false);
		if (ret == 0)
		{
			r[strMsg][0u] = 0;
			r[strMsg][1u] = actionRes();
			player->OldPlayer().delReward(type, flag);
			player->OldPlayer().setRewardRecords(type, flag);
			//log
			int off_day = player->OldPlayer().getOffday();
			if (type == 1)
			{
				int day = player->OldPlayer().getDay();
				Log(DBLOG::strLogOldPlayer, player, type, off_day, day, flag, unit_box.strBox);
			}
			else if (type == 2)
			{
				int gold = player->OldPlayer().getGold();
				Log(DBLOG::strLogOldPlayer, player, type, off_day, gold, flag, unit_box.strBox);
			}
			
		}
		else
		{
			r[strMsg][0u] = 1;
			r[strMsg][1u] = actionError();
		}
	}

	void old_player_system::reqGMOldPlyerIdList(net::Msg& m, Json::Value& r)
	{
		unsigned now = Common::gameTime();
		bool is_has = false;
		Json::Value id_list = Json::arrayValue;
		r[strMsg][0u] = -1;

		for (old_player::ActivityList::iterator it = _activities.begin();
			it != _activities.end();
			++it)
		{
			if (!is_has && it->second.stime <= now && now <= it->second.etime)
			{
				r[strMsg][0u] = it->second.id;
				is_has = true;
			}
			id_list.append(it->second.id);
		}
		r[strMsg][1u] = id_list;

	}

	void old_player_system::reqGMOldPlyerInfo(net::Msg& m, Json::Value& r)
	{
		ReadJsonArray;
		int id = js_msg[0].asInt();
		old_player::ActivityList::iterator it = _activities.find(id);
		if (it == _activities.end())
		{
			Return(r, err_activity_not_found);
		}

		Json::Value ret_json = Json::arrayValue;
		ret_json.append(id);
		ret_json.append(it->second.stime == 0 ? 0 : Common::toStampTime(it->second.stime));
		ret_json.append(it->second.etime == 0 ? 0 : Common::toStampTime(it->second.etime));
		ret_json.append(it->second.lv);
		ret_json.append(it->second.off_day);
		Json::Value back_box = Json::arrayValue;
		for (int i = 0; i < it->second.backs.size(); ++i)
		{
			Json::Value unit = Json::arrayValue;
			unit.append(it->second.backs[i].m);
			unit.append(it->second.backs[i].rawBox);
			back_box.append(unit);
		}
		
		Json::Value recharge_box = Json::arrayValue;
		for (int i = 0; i < it->second.recharge.size(); ++i)
		{
			Json::Value unit = Json::arrayValue;
			unit.append(it->second.recharge[i].m);
			unit.append(it->second.recharge[i].rawBox);
			recharge_box.append(unit);
		}
		ret_json.append(back_box);
		ret_json.append(recharge_box);

		r[strMsg] = ret_json;
	}

	void old_player_system::reqGMOldPlyerModify(net::Msg& m, Json::Value& r)
	{
		ReadJsonArray;

		int type = js_msg[0u].asInt();
		int id = js_msg[1u].asInt();
		if (id < 1)
		{
			Return(r, err_param_error);
		}
		//LogS << "old player\ttype:" << type << "\tid:" << id << LogEnd;
		if (type == 1)
		{
			if (_activities.find(id) != _activities.end())
			{
				_activities.erase(id);
				if (id == _curr.id)
				{
					Json::Value json;
					json[strMsg][0u] = 0;
					json[strMsg][1u] = 2;
					json[strMsg][2u] = -1;
					player_mgr.sendToAll(gate_client::old_player_red_point_resp, json);
				}
			}
			delActi(id);
		}
		if (type == 2)
		{
			//��֤�����ݷ�װ
			unsigned stime = js_msg[2u].asUInt() == 0 ? 0 : Common::toLocalTime(js_msg[2u].asUInt());
			unsigned etime = js_msg[3u].asUInt() == 0 ? 0 : Common::toLocalTime(js_msg[3u].asUInt());
			int lv = js_msg[4u].asInt();
			int offday = js_msg[5u].asInt();
			Json::Value back_box = js_msg[6u];
			Json::Value recharge_box = js_msg[7u];

			unsigned now = Common::gameTime();
			if (stime > MAX_TIME || etime > MAX_TIME)
			{
				Return(r, err_param_error);
			}
			if (etime < now || stime >= etime)
			{
				Return(r, err_param_error);
			}
			if (lv < 1 || offday < 0)
			{
				Return(r, err_param_error);
			}

			old_player::Activity acti;
			for (int i = 0; i < back_box.size(); ++i)
			{
				if (back_box[i].size() != 2)
				{
					Return(r, err_param_error);
				}
				if (back_box[i][0u].asInt() < 1)
				{
					Return(r, err_param_error);
				}
				if (i > 0 && back_box[i][0u].asInt() < back_box[i - 1][0u].asInt())
				{
					Return(r, err_invalid_resp_data);
				}
				old_player::UnitBox unit;
				unit.m = back_box[i][0u].asInt();
				unit.rawBox = back_box[i][1u];
				unit.load();
				acti.backs.push_back(unit);
			}
			for (int i = 0; i < recharge_box.size(); ++i)
			{
				if (recharge_box[i].size() != 2)
				{
					Return(r, err_param_error);
				}
				if (recharge_box[i][0u].asInt() < 1)
				{
					Return(r, err_param_error);
				}
				if (i > 0 && recharge_box[i][0u].asInt() < recharge_box[i - 1][0u].asInt())
				{
					Return(r, err_invalid_resp_data);
				}
				old_player::UnitBox unit;
				unit.m = recharge_box[i][0u].asInt();
				unit.rawBox = recharge_box[i][1u];
				unit.load();
				acti.recharge.push_back(unit);
			}

			acti.id = id;
			acti.stime = stime;
			acti.etime = etime;
			acti.lv = lv;
			acti.off_day = offday;

			//ʱ�����ص�
			std::vector<int> records;
			for (old_player::ActivityList::iterator it = _activities.begin();
				it != _activities.end();
				++it)
			{
				if (lx::utility_lx::is_time_overlap(acti.stime, acti.etime, it->second.stime, it->second.etime))
				{
					records.push_back(it->first);
				}
			}
			//ɾ���ص��ľ�����
			for (int i = 0; i < records.size(); ++i)
			{
				_activities.erase(records[i]);
				delActi(records[i]);
			}
			//�����µ�����
			_activities[acti.id] = acti;
			Timer::AddEventTickTime(boostBind(old_player_system::ActivityOver, _1), Inter::event_activity_over, acti.etime);
			if (!saveActi(acti))
			{
				r[strMsg][0u] = 1;//�����ʧ��
				_activities.erase(acti.id);
				return;
			}
		}
		select();
		r[strMsg][0u] = 0;
	}

	void old_player_system::ActivityOver(const structTimer& timerData)
	{
		Json::Value json;
		json[strMsg][0u] = 0;
		json[strMsg][1u] = 2;
		json[strMsg][2u] = -1;
		player_mgr.sendToAll(gate_client::old_player_red_point_resp, json);
	}

	void old_player_system::select()
	{
		unsigned now = Common::gameTime();
		_curr.id = -1;
		for (old_player::ActivityList::iterator it = _activities.begin();
			it != _activities.end();
			++it)
		{
			if (it->second.stime <= now && it->second.etime > now)
			{
				_curr = it->second;
				break;
			}
		}
	}

	void old_player_system::delActi(int id)
	{
		mongo::BSONObj key = BSON(strActiID << id);

		db_mgr.RemoveCollection(DBN::dbSystemActivityOldPlayer, key);
	}

	bool old_player_system::saveActi(const old_player::Activity& acti)
	{
		mongo::BSONObj key = BSON(strActiID << acti.id);

		mongo::BSONArrayBuilder backs, recharge;
		for (int i = 0; i < acti.backs.size(); ++i)
		{
			backs << acti.backs[i].m << acti.backs[i].rawBox.toIndentString();
		}
		for (int i = 0; i < acti.recharge.size(); ++i)
		{
			recharge << acti.recharge[i].m << acti.recharge[i].rawBox.toIndentString();
		}

		mongo::BSONObj obj = BSON(strActiID << acti.id
			<< strActiSTime << acti.stime
			<< strActiETime << acti.etime
			<< strActiLv << acti.lv
			<< strActiDay << acti.off_day
			<< strActiBacks << backs.arr()
			<< strActiRecharge << recharge.arr()
		);

		return db_mgr.SaveMongo(DBN::dbSystemActivityOldPlayer, key, obj);
	}

	void old_player_system::loadData()
	{
		objCollection objs = db_mgr.Query(DBN::dbSystemActivityOldPlayer);
		unsigned now = Common::gameTime();
		ForEachC(objCollection, it, objs)
		{
			const mongo::BSONObj& obj = (*it);
			old_player::Activity acti;
			acti.id = obj[strActiID].Int();
			acti.stime = obj[strActiSTime].Int();
			acti.etime = obj[strActiETime].Int();
			acti.lv = obj[strActiLv].Int();
			acti.off_day = obj[strActiDay].Int();
			std::vector<mongo::BSONElement> back_box = obj[strActiBacks].Array();
			std::vector<mongo::BSONElement> recharge_box = obj[strActiRecharge].Array();
			for (int i = 0; i < back_box.size(); i += 2)
			{
				old_player::UnitBox unit;
				unit.m = back_box[i].Int();
				unit.rawBox = Common::string2json(back_box[i + 1].String());
				unit.load();
				acti.backs.push_back(unit);
			}
			for (int i = 0; i < recharge_box.size(); i += 2)
			{
				old_player::UnitBox unit;
				unit.m = recharge_box[i].Int();
				unit.rawBox = Common::string2json(recharge_box[i + 1].String());
				unit.load();
				acti.recharge.push_back(unit);
			}
			_activities[acti.id] = acti;
		}
		select();
	}

	old_player_system::~old_player_system()
	{
	}

}

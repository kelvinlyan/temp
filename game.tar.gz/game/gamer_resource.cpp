#include "gamer_resource.h"
#include "dbDriver.h"
#include "task_mgr.h"
#include "kingdom_system.h"
#include "kingdomwar_system.h"
#include "island_activity_system.h"

namespace gg
{
	const static int MaxIntAlter = 0x6FFFFFFF;
	const static int MinIntAlter = -(0x6FFFFFFF);
	const static LargerRes MaxLLI = 0x0FFFFFFFFFFFFFFF;
	const static LargerRes MinLLI = 0x0;

#define ToOKValue(ValueName)\
	ValueName = ValueName < MinLLI ? MinLLI : ValueName;\
	ValueName = ValueName > MaxLLI ? MaxLLI : ValueName;

	static bool ValueOK(const int val)
	{
		return (val >= MinIntAlter && val <= MaxIntAlter && val != 0);
	}
	static bool ValueFail(const int val)
	{
		return !ValueOK(val);
	}

	static bool addSilverByKingdomConstruction()
	{
		int type = State::getState() / 50;
		return type == gate_client::player_worldboss_ui_req / 50
			|| type == gate_client::kingdom_war_quit_req / 50
			|| State::getState() == Inter::event_world_boss_timer
			|| State::getState() == Inter::event_kingdomwar_timer;
	}

	playerResource::playerResource(playerData* const own) : _auto_player(own)
	{
		initial();
	}

	void playerResource::initial()
	{
		Gold = 0;
		Ticket = 50;
		Silver = 0;
		Food = 30000;
		Wood = 30000;
		Iron = 30000;
		Fame = 1000;
		Action = 25;
		Merit = 0;
		HeroPartyMoney = 0;
		LadyCoin = 0;
		ReportShare = 10;
		SearchPoints = 0;
		RechargeNum = 0;
		Dice = 20;
		RechargeCoin = 0;
		SupplyNoon = false;
		SupplyNight = false;
		ExpeditionCoin = 0;
		Reputation = 0;
		GameShare = 0;
		GameSharePoint = 0;
		InterPoint = 0;
	}

	void playerResource::setData(mongo::BSONObj& obj)
	{
		if (obj.isEmpty())return;
		Gold = obj["gl"].Long();
		Ticket = obj["tk"].Long();
		Silver = obj["sil"].Long();
		Food = obj["fd"].Long();
		Wood = obj["wd"].Long();
		Iron = obj["ir"].Long();
		Merit = obj["me"].Long();
		Fame = obj["fa"].Long();
		Action = obj["ac"].Long();
		HeroPartyMoney = obj["hpm"].Long();
		LadyCoin = obj["lc"].Long();
		ReportShare = obj["st"].Long();
		SearchPoints = obj["spt"].Long();
		RechargeNum = obj["rcn"].Long();
		Dice = obj["die"].Long();
		RechargeCoin = obj["rcc"].Long();
		SupplyNoon = obj["noon"].Bool();
		SupplyNight = obj["night"].Bool();
		ExpeditionCoin = obj["epc"].Long();
		Reputation = obj["re"].Long();
		GameShare = obj["gs"].eoo() ? 0 : obj["gs"].Long();
		GameSharePoint = obj["gsp"].eoo() ? 0 : obj["gsp"].Long();
		InterPoint = obj["ip"].eoo() ? 0 : obj["ip"].Long();
	}

	bool playerResource::_auto_save()
	{
		mongo::BSONObj key = BSON(strPlayerID << Own().ID());
		mongo::BSONObj obj = BSON("$set" << BSON("Res" <<
			BSON(
				"gl" << Gold << "tk" << Ticket << "sil" << Silver << "rcc" << 
				RechargeCoin <<	"fd" << Food << "wd" << Wood << "ir" << Iron << 
				"me" << Merit << "fa" << Fame << "ac" << Action << "hpm" << 
				HeroPartyMoney << "lc" << LadyCoin << "st" << ReportShare <<
				"spt" << SearchPoints << "rcn" << RechargeNum << "die" << 
				Dice << "noon" << SupplyNoon << "night" << SupplyNight << 
				"epc" << ExpeditionCoin	<< "re" << Reputation << "gs" <<
				GameShare << "gsp" << GameSharePoint << "ip" << InterPoint
			)
			));
		return db_mgr.SaveMongo(DBN::dbPlayerCollection, key, obj);
	}

	void playerResource::_auto_update()
	{
		qValue json(qJson::qj_object), list_json(qJson::qj_array), resJson(qJson::qj_object);
		resJson.addMember("gl", Gold);
		resJson.addMember("tk", Ticket);
		resJson.addMember("sil", Silver);
		resJson.addMember("fd", Food);
		resJson.addMember("wd", Wood);
		resJson.addMember("ir", Iron);
		resJson.addMember("me", Merit);
		resJson.addMember("fa", Fame);
		resJson.addMember("ac", Action);
		resJson.addMember("co", getContribution());
		resJson.addMember("hpm", HeroPartyMoney);
		resJson.addMember("lc", LadyCoin);
		resJson.addMember("st", ReportShare);
		resJson.addMember("spt", SearchPoints);
		resJson.addMember("exc", getExploit());
		resJson.addMember("die", Dice);
		resJson.addMember("rcc", RechargeCoin);
		resJson.addMember("noon", SupplyNoon);
		resJson.addMember("night", SupplyNight);
		resJson.addMember("epc", ExpeditionCoin);
		resJson.addMember("re", Reputation);
		resJson.addMember("gs", GameShare);
		resJson.addMember("gsp", GameSharePoint);
		resJson.addMember("ip", InterPoint);
		list_json.append(res_sucess);
		list_json.append(resJson);
		list_json.append(State::getState());
		json.addMember(strMsg, list_json);
		Own().sendToClient(gate_client::player_res_update_resp, json);
	}

	LargerRes playerResource::alterSilver(const int val)
	{
		if (ValueFail(val))return 0;
		LargerRes oldVal = Silver;
		Silver += val;
		if (val > 0 
			&& Own().Info().Nation() != Kingdom::null
			&& addSilverByKingdomConstruction())
		{
			KingdomPtr kingdom_ptr = kingdom_sys.getData(Own().Info().Nation());
			if (kingdom_ptr)
				Silver += val * (double)kingdom_ptr->getAddNum(Kingdom::CBoss) / 10000.0;
		}
		ToOKValue(Silver);
		LargerRes add = Silver - oldVal;
		_sign_auto();
		Log(DBLOG::strLogSilver, Own().getOwnDataPtr(), -1, oldVal, Silver);
		if (val > 0)
			TaskMgr::update(Own().getOwnDataPtr(), Task::GetSilverNum, add);
		else
			TaskMgr::update(Own().getOwnDataPtr(), Task::UseSilverNum, 0 - add);
		return add;
	}
	LargerRes playerResource::alterTicket(const int val, const bool isConsume /* = true */)
	{
		if (ValueFail(val))return 0;
		LargerRes oldVal = Ticket;
		Ticket += val;
		ToOKValue(Ticket);
		if (val < 0)
		{
			TaskMgr::update(Own().getOwnDataPtr(), Task::ConsumeNum, 0 - val);
			TaskMgr::update(Own().getOwnDataPtr(), Task::ConsumeTimes, 1);
		}
		_sign_auto();
		onAlterTicket(oldVal);
		Log(DBLOG::strLogGold, Own().getOwnDataPtr(), -1, oldVal, Ticket, Gold, Gold);
		return Ticket - oldVal;
	}
	LargerRes playerResource::alterGold(const int val, const bool isConsume /* = true */)
	{
		if (ValueFail(val))return 0;
		LargerRes oldVal = Gold;
		Gold += val;
		ToOKValue(Gold);
		if (val < 0)
		{
			TaskMgr::update(Own().getOwnDataPtr(), Task::ConsumeNum, 0 - val);
			TaskMgr::update(Own().getOwnDataPtr(), Task::ConsumeTimes, 1);
		}
		_sign_auto();
		onAlterGold(oldVal);
		Log(DBLOG::strLogGold, Own().getOwnDataPtr(), -1, Ticket, Ticket, oldVal, Gold);
		return Gold - oldVal;
	}
	void GoldAlterHelper(LargerRes& first, LargerRes& second, const int num)
	{
		first += num;
		if (first < 0){
			second += first;
		}
	}
	LargerRes playerResource::alterCash(const int val, const bool isConsume /* = true */)
	{
		if (ValueFail(val))return 0;
		LargerRes oldTicket = Ticket;
		LargerRes oldGold = Gold;
		GoldAlterHelper(Ticket, Gold, val);
		ToOKValue(Ticket);
		ToOKValue(Gold);
		if (val < 0)
		{
			TaskMgr::update(Own().getOwnDataPtr(), Task::ConsumeNum, 0 - val);
			TaskMgr::update(Own().getOwnDataPtr(), Task::ConsumeTimes, 1);
		}
		_sign_auto();
		onAlterTicket(oldTicket);
		onAlterGold(oldGold);
		Log(DBLOG::strLogGold, Own().getOwnDataPtr(), -1, oldTicket, Ticket, oldGold, Gold);
		return Ticket + Gold - oldTicket - oldGold;
	}
	LargerRes playerResource::alterFood(const int val)
	{
		if (ValueFail(val))return 0;
		LargerRes oldVal = Food;
		Food += val;
		ToOKValue(Food);
		_sign_auto();
		Log(DBLOG::strLogFood, Own().getOwnDataPtr(), -1, oldVal, Food);
		if (val > 0)
			TaskMgr::update(Own().getOwnDataPtr(), Task::GetFoodNum, val);
		else
			TaskMgr::update(Own().getOwnDataPtr(), Task::UseFoodNum, 0 - val);
		return Food - oldVal;
	}	
	LargerRes playerResource::alterWood(const int val)
	{
		if (ValueFail(val))return 0;
		LargerRes oldVal = Wood;
		Wood += val;
		ToOKValue(Wood);
		_sign_auto();
		Log(DBLOG::strLogWood, Own().getOwnDataPtr(), -1, oldVal, Wood);
		if (val > 0)
			TaskMgr::update(Own().getOwnDataPtr(), Task::GetWoodNum, val);
		else
			TaskMgr::update(Own().getOwnDataPtr(), Task::UseWoodNum, 0 - val);
		return Wood - oldVal;
	}
	LargerRes playerResource::alterIron(const int val)
	{
		if (ValueFail(val))return 0;
		LargerRes oldVal = Iron;
		Iron += val;
		ToOKValue(Iron);
		_sign_auto();
		Log(DBLOG::strLogIron, Own().getOwnDataPtr(), -1, oldVal, Iron);
		if (val > 0)
			TaskMgr::update(Own().getOwnDataPtr(), Task::GetIronNum, val);
		else
			TaskMgr::update(Own().getOwnDataPtr(), Task::UseIronNum, 0 - val);
		return Iron - oldVal;
	}
	LargerRes playerResource::alterMerit(const int val)
	{
		if (ValueFail(val))return 0;
		LargerRes oldVal = Merit;
		Merit += val;
		ToOKValue(Merit);
		_sign_auto();
		Log(DBLOG::strLogMerit, Own().getOwnDataPtr(), -1, oldVal, Merit);
		if (val > 0)
			TaskMgr::update(Own().getOwnDataPtr(), Task::GetMeritNum, val);
		else
			TaskMgr::update(Own().getOwnDataPtr(), Task::UseMeritNum, 0 - val);
		return Merit - oldVal;
	}
	LargerRes playerResource::alterFame(const int val)
	{
		if (ValueFail(val))return 0;
		LargerRes oldVal = Fame;
		Fame += val;
		if (val > 0 && Own().Info().Nation() != Kingdom::null)
		{
			KingdomPtr kingdom_ptr = kingdom_sys.getData(Own().Info().Nation());
			if (kingdom_ptr)
				Fame += val * (double)kingdom_ptr->getAddNum(Kingdom::CFame) / 10000.0;
		}
		ToOKValue(Fame);
		LargerRes add = Fame - oldVal;
		_sign_auto();
		Log(DBLOG::strLogFame, Own().getOwnDataPtr(), -1, oldVal, Fame);
		if (val > 0)
			TaskMgr::update(Own().getOwnDataPtr(), Task::GetFameNum, add);
		else
			TaskMgr::update(Own().getOwnDataPtr(), Task::UseFameNum, 0 - add);
		return add;
	}
	LargerRes playerResource::alterAction(const int val)
	{
		if (ValueFail(val))return 0;
		LargerRes oldVal = Action;
		Action += val;
		ToOKValue(Action);
		_sign_auto();
		Log(DBLOG::strLogAction, Own().getOwnDataPtr(), -1, oldVal, Action);
		onAlterAction(oldVal);
		return Action - oldVal;
	}

	int playerResource::getContribution()
	{
		return Own().KingDom().getCurCon();
	}
	int playerResource::alterContribution(const int val)
	{
		if (0 == val)return 0;
		int oldVal = getContribution();
		Own().KingDom().alterCon(val);
		_sign_update();
		Log(DBLOG::strLogContribution, Own().getOwnDataPtr(), -1, oldVal, getContribution());
		onAlterContribution(val);
		return getContribution() - oldVal;
	}
	LargerRes playerResource::alterHeroCoin(const int val)
	{
		if (ValueFail(val))return 0;
		LargerRes oldVal = HeroPartyMoney;
		HeroPartyMoney += val;
		ToOKValue(HeroPartyMoney);
		_sign_auto();
		Log(DBLOG::strLogHeroPartyMoney, Own().getOwnDataPtr(), -1, oldVal, HeroPartyMoney);
		return HeroPartyMoney - oldVal;
	}
	LargerRes playerResource::alterLadyCoin(const int val)
	{
		if (ValueFail(val))return 0;
		LargerRes oldVal = LadyCoin;
		LadyCoin += val;
		ToOKValue(LadyCoin);
		_sign_auto();
		Log(DBLOG::strLogLadyCoin, Own().getOwnDataPtr(), -1, oldVal, LadyCoin);
		return LadyCoin - oldVal;
	}

	LargerRes playerResource::alterReportShare(const int val)
	{
		if (ValueFail(val))return 0;
		LargerRes oldVal = ReportShare;
		ReportShare += val;
		ToOKValue(ReportShare);
		_sign_auto();
		return ReportShare - oldVal;
	}

	LargerRes playerResource::alterSearchPoints(const int val)
	{
		if (ValueFail(val))return 0;
		LargerRes oldVal = SearchPoints;
		SearchPoints += val;
		ToOKValue(SearchPoints);
		_sign_auto();
		Log(DBLOG::strLogSearchPoint, Own().getOwnDataPtr(), -1, oldVal, SearchPoints);
		return SearchPoints - oldVal;
	}

	void playerResource::addRechargeNum(const int num)
	{
		if (num < 1 || num > MaxIntAlter)return;
		if (0 == RechargeNum)
		{
			Own().Vip().addVipGift(0);
		}
		Log(DBLOG::strLogPoints, Own().getOwnDataPtr(), -1, RechargeNum, RechargeNum + num);
		RechargeNum += num;
		ToOKValue(RechargeNum);
		TaskMgr::update(Own().getOwnDataPtr(), Task::RechargeNum, num);
		if (island_activity_sys.current())
		{
			ActionBoxList extra = Own().IslandActivity().getTreasurePieceByGold(num);
			if (!extra.empty())
				actionDoBox(Own().getOwnDataPtr(), extra);
		}
		_sign_save();
	}

	void playerResource::alterExploit(int num)
	{
		if (num == 0)
			return;
		int oldVal = getExploit();
		Own().KingDomWar().alterExploit(num);
		_sign_update();
		Log(DBLOG::strLogExploit, Own().getOwnDataPtr(), -1, oldVal, getExploit());
		if (num > 0)
		{
			Own().Daily().tickTask(DAILY::won_exploit_coin, num);
		}
	}

	int playerResource::getExploit()
	{
		return Own().KingDomWar().getTotalExploit() - Own().KingDomWarShop().getUsedExploit();
	}

	void playerResource::setNoonTrue()
	{
		SupplyNoon = true;
		_sign_auto();
	}

	void playerResource::setNightTrue()
	{
		SupplyNight = true;
		_sign_auto();
	}

	void playerResource::resetSupply()
	{
		SupplyNoon = false;
		SupplyNight = false;
		_sign_auto();
	}

	LargerRes playerResource::alterDice(const int val)
	{
		if (ValueFail(val))return 0;
		LargerRes oldVal = Dice;
		Dice += val;
		ToOKValue(Dice);
		LargerRes add = Dice - oldVal;
		_sign_auto();
		Log(DBLOG::strLogDice, Own().getOwnDataPtr(), -1, oldVal, Dice);
		return add;
	}

	LargerRes playerResource::alterRechargeCoin(const int val)
	{
		if (ValueFail(val))return 0;
		LargerRes oldVal = RechargeCoin;
		RechargeCoin += val;
		ToOKValue(RechargeCoin);
		LargerRes add = RechargeCoin - oldVal;
		_sign_auto();
		Log(DBLOG::strLogRechargeCoin, Own().getOwnDataPtr(), -1, oldVal, RechargeCoin);
		return add;
	}

	LargerRes playerResource::alterExpeditionCoin(const int val)
	{
		if (ValueFail(val))return 0;
		LargerRes oldVal = ExpeditionCoin;
		ExpeditionCoin += val;
		ToOKValue(ExpeditionCoin);
		LargerRes add = ExpeditionCoin - oldVal;
		_sign_auto();
		Log(DBLOG::strLogExpeditionCoin, Own().getOwnDataPtr(), -1, oldVal, ExpeditionCoin);
		return add;
	}

	LargerRes playerResource::alterReputation(const int val)
	{
		if (ValueFail(val))return 0;
		LargerRes oldVal = Reputation;
		Reputation += val;
		ToOKValue(Reputation);
		LargerRes add = Reputation - oldVal;
		_sign_auto();
		Log(DBLOG::strLogReputation, Own().getOwnDataPtr(), -1, oldVal, Reputation);
		return add;
	}

	LargerRes playerResource::alterGameShare(const int val)
	{
		if (ValueFail(val))return 0;
		LargerRes oldVal = GameShare;
		GameShare += val;
		ToOKValue(GameShare);
		_sign_auto();
		Log(DBLOG::strLogGameShare, Own().getOwnDataPtr(), 0, oldVal, GameShare);
		return GameShare - oldVal;
	}

	LargerRes playerResource::alterGameSharePoint(const int val)
	{
		if (ValueFail(val))return 0;
		LargerRes oldVal = GameSharePoint;
		GameSharePoint += val;
		ToOKValue(GameSharePoint);
		_sign_auto();
		Log(DBLOG::strLogGameShare, Own().getOwnDataPtr(), 1, oldVal, GameSharePoint);
		return GameSharePoint - oldVal;
	}

	LargerRes playerResource::alterInterPoint(const int val)
	{
		if (ValueFail(val))return 0;
		LargerRes oldVal = InterPoint;
		InterPoint += val;
		ToOKValue(InterPoint);
		_sign_auto();
		Log(DBLOG::strLogInterPoint, Own().getOwnDataPtr(), -1, oldVal, InterPoint);
		return InterPoint - oldVal;
	}
}

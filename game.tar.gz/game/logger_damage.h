#pragma once

namespace gg
{
	namespace BattleLog
	{
		//�˺�������
		class logger_interface
		{
		public://idx λ�� //
			virtual void on_shield_alter(const int val) = 0;
			virtual void on_hp_alter(const int val) = 0;
		};

		class logger_per_round :
			public logger_interface
		{
		public:
			logger_per_round()
			{
				_value = 0;
			}
			virtual void on_shield_alter(const int val)
			{
				//_value += val;//ɶҲ����
			}
			virtual void on_hp_alter(const int val)
			{
				_value += val;
			}
			inline int get_value() { return _value; }
		private:
			int _value;
		};

		class logger_only_damage :
			public logger_interface
		{
		public:
			logger_only_damage()
			{
				_value = 0;
			}
			virtual void on_shield_alter(const int val)
			{
				if (val < 0)
				{
					_value += val;
				}
			}
			virtual void on_hp_alter(const int val)
			{
				if (val < 0)
				{
					_value += val;
				}
			}
			inline int get_value() { return _value; }
		private:
			int _value;
		};

		//�˺���¼������
		class logger_factory
		{
		public:
			virtual logger_interface* get_logger_mgr(const unsigned r, const unsigned idx) = 0;
			virtual void reset() = 0;
		};

		//��¼ÿ�غ�ʵ���˺���
		class PerRoundLog :
			public logger_factory
		{
		public:
			typedef boost::unordered_map< unsigned, logger_per_round > _type_index;
			typedef boost::unordered_map< unsigned, _type_index> _type_round_index;
			virtual logger_interface* get_logger_mgr(const unsigned r, const unsigned idx)
			{
				return (logger_interface*)(&_map[r][idx]);
			}
			virtual void reset()
			{
				_map.clear();
			}
			inline _type_round_index map_copy() { return _map; }
		private:
			_type_round_index _map;
		};

		//��¼ָ���佫���յ����˺���
		class SignTotalLog :
			public logger_factory
		{
		public:
			SignTotalLog(const unsigned begin, const unsigned end) :
				_sign_begin(begin), _sign_end(end)
			{

			}
			virtual logger_interface* get_logger_mgr(const unsigned r, const unsigned idx)
			{
				if (idx < _sign_begin || idx > _sign_end)return (logger_interface*)0;
				return (logger_interface*)(&_damage);
			}
			virtual void reset()
			{
				_damage = logger_only_damage();
			}
			inline int get_collect_damage() { return _damage.get_value(); }
		private:
			const unsigned _sign_begin;
			const unsigned _sign_end;
			logger_only_damage _damage;
		};
	}
}
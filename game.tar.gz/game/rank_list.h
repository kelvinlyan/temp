#pragma once

#include "commom.h"

namespace gg
{
	/* template T
	class T
	{
		public:
			int id() const
			{
				return 0;
			}
			int value() const
			{
				return 0;
			}
	};
	*/

	template<typename T>
	class RankList1
	{
		public:
			typedef boost::function<void(const T&)> Handler;
			BOOSTSHAREPTR(T, Ptr);

			int getRank(int id, int value) const;
			void update(const Ptr& p, int old_value);
			void clear();
			
			unsigned size() const;
			int minV() const;
			int maxV() const;

			void run(Handler h) const;
			void run(Handler h, unsigned begin, unsigned count) const;

		private:
			int getIndex(int id, int value) const;
			int binarySearch(int value) const;

		private:
			STDVECTOR(Ptr, RankList);
			RankList _rank_list;
	};

	/**/

	template<typename T>
	int RankList1<T>::getRank(int id, int value) const
	{
		return getIndex(id, value) + 1;
	}

	template<typename T>
	void RankList1<T>::update(const Ptr& t, int old_value)
	{
		if (t->value() == 0 || t->value() < old_value)
		{
			//LogE << "update failed: " << t->id() << ", " << t->value() << ", " << old_value << LogEnd;
			return;
		}

		if (old_value == 0)
		{
			for (int i = _rank_list.size(); i > 0; --i)
			{
				if (_rank_list[i - 1]->value() >= t->value())
				{
					_rank_list.insert(_rank_list.begin() + i, t);
					return;
				}
			}
			_rank_list.insert(_rank_list.begin(), t);
		}
		else
		{
			int idx = getIndex(t->id(), old_value);
			if (idx == -1)
			{
				LogE << "update failed: " << t->id() << ", " << old_value << LogEnd;
				return;
			}

			for (; idx > 0; --idx)
			{
				if (t->value() > _rank_list[idx - 1]->value())
					_rank_list[idx] = _rank_list[idx - 1];
				else
					break;
			}
			_rank_list[idx] = t;
		}
	}

	template<typename T>
	void RankList1<T>::clear()
	{
		_rank_list.clear();
	}
	
	template<typename T>
	unsigned RankList1<T>::size() const
	{
		return _rank_list.size();
	}

	template<typename T>
	int RankList1<T>::minV() const
	{
		if (_rank_list.empty())
			return -1;
		return _rank_list.back()->value();
	}

	template<typename T>
	int RankList1<T>::maxV() const
	{
		if (_rank_list.empty())
			return -1;
		return _rank_list.front()->value();
	}

	template<typename T>
	void RankList1<T>::run(Handler h) const
	{
		for (unsigned i = 0; i < _rank_list.size(); ++i)
			h(*_rank_list[i]);
	}

	template<typename T>
	void RankList1<T>::run(Handler h, unsigned begin, unsigned count) const
	{
		unsigned end = begin + count;
		if (end > _rank_list.size())
			end = _rank_list.size();
		
		for (unsigned i = begin; i < end; ++i)
			h(*_rank_list[i]);
	}
	
	template<typename T>
	int RankList1<T>::getIndex(int id, int value) const
	{
		int idx = binarySearch(value);
		if (idx == -1)
			return -1;

		if (_rank_list[idx]->id() == id)
			return idx;

		int tmp = idx;
		while(++tmp < _rank_list.size() 
			&& _rank_list[tmp]->value() == value)
		{
			if (_rank_list[tmp]->id() == id)
				return tmp;
		}
		tmp = idx;
		while(--tmp >= 0 
			&& _rank_list[tmp]->value() == value)
		{
			if (_rank_list[tmp]->id() == id)
				return tmp;
		}
		return -1;
	}

	template<typename T>
	int RankList1<T>::binarySearch(int value) const
	{
		int low = 0;
		int high = _rank_list.size() - 1;
		while (low <= high)
		{
			int mid = low + (high - low) / 2;
			if(_rank_list[mid]->value() == value)
				return mid;
			else if (_rank_list[mid]->value() < value)
				high = mid - 1;
			else
				low = mid + 1;
		}
		return -1;
	}

	/* EXAMPLE

	struct Key
	{
		Key(int i, int v)
			: id(i), value(v){}
		bool operator<(const Key& k) const
		{
			if (value != k.value)
				return value < k.value;
			return id < k.id;
		}
		int id;
		int value;
	};

	class Value
	{
		Value(int i, int v)
			: _key(i, v){}
		const Key& key() const { return _key; }
		Key _key;
	};
	
	RankList2<Value, Key> rank;
	rank.insert(boost::shared_ptr<Value>(new Value(1, 1)));
	rank.insert(boost::shared_ptr<Value>(new Value(2, 1)));
	std::cout << rank.getRank(Key(1, 1)) << std::endl;

	rank.update(boost::shared_ptr<Value>(new Value(1, 2)), Key(1, 1));
	std::cout << rank.getRank(Key(1, 2)) << std::endl;

	*/

	template<typename V, typename K>
	class RankList2
	{
		public:
			typedef boost::function<void(const V&)> Handler;
			typedef boost::function<bool()> BreakFunc;
			typedef boost::shared_ptr<const V> VPtr;

			RankList2(int max_size = 0)
				: _max_size(max_size){}

			unsigned size() const;
			int getRank(const K& key) const;
			VPtr getValueByKey(const K& key) const;
			VPtr getValueByRank(int rk) const;

			void insert(const VPtr& value);
			bool update(const VPtr& value, const K& key);
			void clear();
			void run(Handler h) const;
			void run(Handler h, BreakFunc f) const;
			void run(Handler h, unsigned begin, unsigned count) const;
			void run(Handler h, unsigned begin, unsigned count, BreakFunc f) const;

		private:
			int binarySearch(const K& key) const;

		private:
			typedef std::vector<VPtr> ValueList;
			ValueList _rank_list;
			unsigned _max_size;
	};

	/**/

	template<typename V, typename K>
	int RankList2<V, K>::binarySearch(const K& key) const
	{
		int low = 0;
		int high = _rank_list.size() - 1;
		while (low <= high)
		{
			int mid = low + (high - low) / 2;
			if (_rank_list[mid]->key() < key)
				high = mid - 1;
			else if (key < _rank_list[mid]->key())
				low = mid + 1;
			else
				return mid;
		}
		return -1;
	}

	template<typename V, typename K>
	typename RankList2<V, K>::VPtr RankList2<V, K>::getValueByKey(const K& key) const
	{
		int idx = binarySearch(key);
		return idx == -1? VPtr() : _rank_list[idx];
	}

	template<typename V, typename K>
	typename RankList2<V, K>::VPtr RankList2<V, K>::getValueByRank(int rk) const
	{
		if (rk < 1 || rk > _rank_list.size())
			return VPtr();
		return _rank_list[rk - 1];
	}

	template<typename V, typename K>
	int RankList2<V, K>::getRank(const K& key) const
	{
		return binarySearch(key) + 1;
	}

	template<typename V, typename K>
	void RankList2<V, K>::insert(const VPtr& value)
	{
		if (_max_size != 0
			&& _rank_list.size() >= _max_size
			&& value->key() < _rank_list.back()->key())
			return;
		for (int i = _rank_list.size(); i > 0; --i)
		{
			if (value->key() < _rank_list[i - 1]->key())
			{
				_rank_list.insert(_rank_list.begin() + i, value);

				if (_max_size != 0
					&& _rank_list.size() > _max_size)
				{
					_rank_list.pop_back();
				}
				return;
			}
		}
		_rank_list.insert(_rank_list.begin(), value);
		if (_max_size != 0
			&& _rank_list.size() > _max_size)
		{
			_rank_list.pop_back();
		}
	}

	template<typename V, typename K>
	bool RankList2<V, K>::update(const VPtr& value, const K& old_key)
	{
		if (_rank_list.empty()
			|| old_key < _rank_list.back()->key())
		{
			insert(value);
			return true;
		}
		if (value->key() < old_key)
			return false;
		int idx = binarySearch(old_key);
		if (idx == -1)
			return false;
		for (; idx > 0; --idx)
		{
			if (_rank_list[idx - 1]->key() < value->key())
				_rank_list[idx] = _rank_list[idx - 1];
			else
				break;
		}
		_rank_list[idx] = value;
		if (_max_size != 0
			&& _rank_list.size() > _max_size)
		{
			_rank_list.pop_back();
		}
		return true;
	}

	template<typename V, typename K>
	void RankList2<V, K>::clear()
	{
		_rank_list.clear();
	}
	
	template<typename V, typename K>
	unsigned RankList2<V, K>::size() const
	{
		return _rank_list.size();
	}

	template<typename V, typename K>
	void RankList2<V, K>::run(Handler h) const
	{
		for (unsigned i = 0; i < _rank_list.size(); ++i)
			h(*_rank_list[i]);
	}

	template<typename V, typename K>
	void RankList2<V, K>::run(Handler h, unsigned begin, unsigned count) const
	{
		unsigned end = begin + count;
		if (end > _rank_list.size())
			end = _rank_list.size();

		for (unsigned i = begin; i < end; ++i)
			h(*_rank_list[i]);
	}

	template<typename V, typename K>
	void RankList2<V, K>::run(Handler h, BreakFunc f) const
	{
		for (unsigned i = 0; i < _rank_list.size(); ++i)
		{
			if (f())
				break;
			h(*_rank_list[i]);
		}
	}

	template<typename V, typename K>
	void RankList2<V, K>::run(Handler h, unsigned begin, unsigned count, BreakFunc f) const
	{
		unsigned end = begin + count;
		if (end > _rank_list.size())
			end = _rank_list.size();

		for (unsigned i = begin; i < end; ++i)
		{
			if (f())
				break;
			h(*_rank_list[i]);
		}
	}
}

#include "business.h"
#include "zip_file.hpp"
#include "battle_helper.hpp"
#include "chat.h"
#include "kingdom_system.h"
#include "task_mgr.h"
#include "email_system.h"
#include "wstar.h"
#include "business_daily_rank.h"
#include "activity_player.h"
#include "net_helper.hpp"
#include "game_time.h"

namespace gg
{
	const static int StanderX = 20;//��ͼ���ӱ���
	const static int StanderY = 12;//��ͼ���ӱ���

	const static unsigned systemUseLimit = 40;

	const static int SilverKeyID = 50005;//��Կ��
	const static int GoldKeyID = 50006;//��Կ��
	const static int CarMaterialID = 50007;//�̴�����
	//50002 fangshui 50003 weishe 50004 yijia
	const static int FangShuiID = 50002;
	const static int WeiSheID = 50003;
	const static int YiJiaID = 50004;
	struct TBstruct
	{
		TBstruct()
		{
			_id_buff = TradeBuff::null;
			_duration = 0;
		}
		TBstruct(const TradeBuff::ID _id, const unsigned _d)
		{
			_id_buff = _id;
			_duration = _d;
		}
		TradeBuff::ID _id_buff;
		unsigned _duration;
	};
	static std::map<int, TBstruct> BuffDoMap;
	TBstruct getBindBuff(const int ID)
	{
		std::map<int, TBstruct>::iterator it = BuffDoMap.find(ID);
		if (it == BuffDoMap.end())return TBstruct();
		return it->second;
	}

	const static int ShunYiID = 50001;



	static unsigned CityWareNeed[2] = { 1, 3 };//������Ʒ
	static unsigned CityEventNum = 3;//�����¼�����//һ������1���¼� �¼�ֻ��1��
	static unsigned MapHaiDaoEvent[2] = { 5, 10 };//��ͼ�����¼�
	static unsigned MapSilverBoxEvent[2] = { 5, 10 };//��ͼ������
	static unsigned MapGoldBoxEvent[2] = { 5, 10 };//��ͼ����


												   //���������¼��ĵ�ͼ����
	namespace MapEvnet
	{
		enum Type
		{
			null,//û���κ��¼�
			haidao,//����
			silver_box,//������
			gold_box,//����
			shark,//�����
			shark_boss,//����boss
			shark_boss_chest,//���㱦��
		};
	}

	enum
	{
		car_enter,
		car_exit
	};

	class AreaData;
	BOOSTSHAREPTR(AreaData, ptrAreaData);
	struct _info;
	BOOSTSHAREPTR(_info, _info_ptr);
	struct _info :
		public boost::enable_shared_from_this<_info>
	{
		static _info_ptr Create(playerDataPtr player);
		_info(playerDataPtr player);
		int playerID;
		string playerName;
		Kingdom::NATION playerNation;
		unsigned cpos_idx;//��ǰ���ڵ���
		unsigned cpos_x;//��ǰx
		unsigned cpos_y;//��ǰy
		unsigned aim_x;//Ŀ��x
		unsigned aim_y;//Ŀ��y
		unsigned speed;//�ٶ�
		unsigned level;//��ֻ�ȼ�
		unsigned state;
		unsigned updateCD;
		bool been_post;
		inline bool isEnter() { return state == car_enter; }
		inline bool isExit() { return state == car_exit; }
		void sendCarePlayer(playerDataPtr player);
		void sendAround(playerDataPtr player);
		void setNewPos(playerDataPtr player, const unsigned x, const unsigned y);
		ptrAreaData currentArea();
		qValue toJson()
		{
			qValue json(qJson::qj_array);
			json.append(playerID);
			json.append(playerName);
			json.append(playerNation);
			json.append(cpos_x);
			json.append(cpos_y);
			json.append(aim_x);
			json.append(aim_y);
			json.append(speed);
			json.append(level);
			return json;
		}
	};
	UNORDERMAP(int, _info_ptr, _brPlayerMap);
	static _brPlayerMap _brPlayers;//�������
	_info_ptr getBRPlayer(const int playerID)
	{
		_brPlayerMap::iterator it = _brPlayers.find(playerID);
		if (it == _brPlayers.end())return _info_ptr();
		return it->second;
	}

	namespace POS
	{
		struct Rect//����//����
		{
			Rect(
				const int lbx,
				const int lby,
				const int rtx,
				const int rty
			)
				: _left_bottom_x(lbx)
				, _left_bottom_y(lby)
				, _right_top_x(rtx)
				, _right_top_y(rty)
			{
			}
			const int _left_bottom_x;
			const int _left_bottom_y;
			const int _right_top_x;
			const int _right_top_y;
			inline bool isMatch(const int x, const int y)const
			{
				return (
					x >= _left_bottom_x &&
					x <= _right_top_x &&
					y >= _left_bottom_y &&
					y <= _right_top_y
					);
			}
		};
	}

	struct SharkData
	{
		SharkData(const unsigned tick)
			: _createTick(tick)
		{
			_hitTime = 0;
			_boxTime = 0;
			_x = 0;
			_y = 0;
			_current_hp = 0;
			_total_hp = 0;
		}
		const unsigned _createTick;
		unsigned _hitTime;//��һ�ι���ʱ��
		unsigned _boxTime;//��ȡ�������ʱ��
		int _x;
		int _y;
		int _total_hp;
		int _current_hp;
		sBattlePtr _shark;
	};
	BOOSTSHAREPTR(SharkData, ptrSharkData);
	static ptrSharkData _ActivityShark;//��ǰ���㱦�佱����ID

	static std::vector< WSTAR::Pos > EventCoor;
	static std::vector< WSTAR::Pos > UsePos;

	//����
	class AreaData :
		public boost::enable_shared_from_this<AreaData>
	{
	public:
		BOOSTWEAKPTR(AreaData, ptrWeakArea);
		STDMAP(int, ptrWeakArea, AreaWeakMap);
	public:
		AreaData(
			const int idx,
			const int lbx,
			const int lby,
			const int rtx,
			const int rty
		) :
			_INDEX(idx),
			_Area(lbx, lby, rtx, rty)
		{
			_Events.clear();
			_Code = "";
			_PlayerIt = _Player.end();
		}
		void bindAreaRelate();
		const unsigned _INDEX;
		const POS::Rect _Area;
		void replacePlayer(_info_ptr info)
		{
			_Player[info->playerID] = info;
		}
		void removePlayer(const int playerID)
		{
			if (_PlayerIt != _Player.end())
			{
				_info_ptr info = _PlayerIt->second;
				if (info->playerID == playerID)
				{
					++_PlayerIt;
				}
			}
			_Player.erase(playerID);
		}
		inline string Code() { return _Code; }
		void removeEvent(const unsigned x, const unsigned y);
		void sendVisibleEvent(playerDataPtr player)
		{
			qValue data_json(qJson::qj_array);
			for (AreaWeakMap::iterator vit = _Visible.begin(); vit != _Visible.end(); ++vit)
			{
				const EvnetMap& checkMap = (vit->second).lock()->_Events;
				for (EvnetMap::const_iterator it = checkMap.begin(); it != checkMap.end(); ++it)
				{
					const WSTAR::Pos& pos = it->first;
					const MapEvnet::Type type = it->second;
					qValue single_json(qJson::qj_array);
					single_json.append(pos.x);
					single_json.append(pos.y);
					single_json.append(type);
					if (type == MapEvnet::shark_boss)
					{
						single_json.append(_ActivityShark->_current_hp);
						single_json.append(_ActivityShark->_total_hp);
					}
					data_json.append(single_json);
				}
			}
			qValue msg_json(qJson::qj_array);
			msg_json.append(res_sucess).append(data_json);
			player->sendToClientFillMsg(gate_client::player_update_trade_map_event_resp, msg_json);
		}
		bool sendSomeVisiblePlayer(playerDataPtr player, _info& player_car)//�����������
		{
			const unsigned now = Common::gameTime();
			if (now < player_car.updateCD)return false;
			qValue data_json(qJson::qj_array);
			for (AreaWeakMap::iterator vit = _Visible.begin(); vit != _Visible.end(); ++vit)
			{
				ptrAreaData ptr = (vit->second).lock();
				_brPlayerMap::const_iterator& checkIt = ptr->_PlayerIt;
				const _brPlayerMap& checkMap = ptr->_Player;
				if (checkIt == checkMap.end())checkIt = checkMap.begin();
				const int playerID = player->ID();
				unsigned num = 0;//��Ҫ�Է������·�
				for (; num < 3 && checkIt != checkMap.end(); ++checkIt)
				{
					_info_ptr info = checkIt->second;
					if (info->playerID == playerID)continue;//�Լ������� ������
					data_json.append(info->toJson());
					++num;
				}
			}
			player_car.updateCD = now + 3;
			if (data_json.isEmpty())return false;
			qValue msg_json(qJson::qj_array);//һ�����·�
			msg_json.append(res_sucess).append(data_json);
			player->sendToClientFillMsg(gate_client::player_trade_map_area_update_resp, msg_json);
			return true;
		}
		void clearEvent();
		void sendAroudNewEvent();
		void addEvent(const unsigned x, const unsigned y, const MapEvnet::Type type);
		inline bool matchArea(const unsigned x, const unsigned y)const { return _Area.isMatch(x, y); }//�Ƿ�����������
	private:
		_brPlayerMap::const_iterator _PlayerIt;
		_brPlayerMap _Player;//������������б�
		STDMAP(WSTAR::Pos, MapEvnet::Type, EvnetMap);
		EvnetMap _Events;//���������¼��б�
		string _Code;//������
		AreaWeakMap _Visible;//�ɼ�������, ����������Ҳ���ļ���
	};
	STDMAP(int, ptrAreaData, AreaMap);
	static AreaMap Areas;//��ͼ�������
	ptrAreaData getArea(const unsigned idx)
	{
		AreaMap::iterator it = Areas.find(idx);
		if (it == Areas.end())return ptrAreaData();
		return it->second;
	}

	struct MapPoint
	{
		explicit MapPoint(
			const int x = 0,
			const int y = 0,
			const MapEvnet::Type type = MapEvnet::null,
			const bool available = false
		)
		{
			_x = x;
			_y = y;
			_Type = type;
			_Available = available;
			_relateArea = NULL;
		}
		void setEvent(const MapEvnet::Type type);
		int _x;
		int _y;
		MapEvnet::Type _Type;
		bool _Available;
		AreaData* _relateArea;
	};
	static vector< vector< MapPoint > > MapData;
	MapEvnet::Type getMapEvent(const int x, const int y)
	{
		if ((unsigned)x < MapData.size())
		{
			vector< MapPoint >& yVec = MapData[x];
			if ((unsigned)y < yVec.size())
			{
				return yVec[y]._Type;
			}
		}
		return MapEvnet::null;
	}

	void removeMapEvent(const int x, const int y)
	{
		const unsigned idx = x / StanderX + (y / StanderY) * (MapData.size() / StanderX);
		ptrAreaData ptr = getArea(idx);
		if (ptr)
		{
			ptr->removeEvent(x, y);
		}
	}

	void AreaData::sendAroudNewEvent()
	{
		qValue data_json(qJson::qj_array);
		for (_brPlayerMap::const_iterator it = _Player.begin(); it != _Player.end(); ++it)
		{
			_info_ptr info = it->second;
			if (info->isEnter())
			{
				playerDataPtr player = player_mgr.getOnlinePlayer(info->playerID);
				if (player)
				{
					sendVisibleEvent(player);
				}
			}
		}
	}

	void AreaData::clearEvent()
	{
		for (EvnetMap::iterator it = _Events.begin(); it != _Events.end(); it++)
		{
			WSTAR::Pos coor = it->first;
			MapData[coor.x][coor.y]._Type = MapEvnet::null;
		}
		_Events.clear();
	}

	void AreaData::addEvent(const unsigned x, const unsigned y, const MapEvnet::Type type)
	{
		if (matchArea(x, y))
		{
			MapData[x][y]._Type = type;
			_Events[WSTAR::Pos(x, y)] = type;
		}
	}

	void AreaData::removeEvent(const unsigned x, const unsigned y)
	{
		if (_Events.erase(WSTAR::Pos(x, y)) > 0)//������¼�ɾ���ɹ���
		{
			MapData[x][y]._Type = MapEvnet::null;
			for (AreaWeakMap::iterator vit = _Visible.begin(); vit != _Visible.end(); ++vit)
			{
				const _brPlayerMap& checkMap = (vit->second).lock()->_Player;
				for (_brPlayerMap::const_iterator it = checkMap.begin(); it != checkMap.end(); ++it)
				{
					_info_ptr ptr = it->second;
					if (ptr->isEnter())
					{
						playerDataPtr player = player_mgr.getOnlinePlayer(ptr->playerID);
						if (player)
						{
							sendVisibleEvent(player);//���͵�ͼ�¼������
						}
					}
				}
			}
		}
	}

	const static unsigned RangeSize = 1;
	void AreaData::bindAreaRelate()
	{
		//range 1
		const unsigned x_length = MapData.size() / StanderX;// 0 <= ? < x_length
		const unsigned y_length = MapData[0u].size() / StanderY;// 0 <= ? < y_length
		const unsigned all_num = x_length * y_length;//���� 0 <= ? < all_n

		_Visible.clear();
		_Code = "";
		//��ȡ�Ź���

		//��ǰ����
		const unsigned spx = _INDEX % x_length;
		const unsigned spy = _INDEX / x_length;

		//��������ƫ��
		const unsigned left_bottom_x = spx < RangeSize ? 0 : spx - RangeSize;
		const unsigned left_bottom_y = spy < RangeSize ? 0 : spy - RangeSize;

		//��������ƫ��
		const unsigned right_top_x = spx + RangeSize < x_length ? spx + RangeSize : spx;
		const unsigned right_top_y = spy + RangeSize < y_length ? spy + RangeSize : spy;

		for (unsigned x = left_bottom_x; x <= right_top_x; x++)
		{
			for (unsigned y = left_bottom_y; y <= right_top_y; y++)
			{
				_Code += Common::toString(x + y * x_length);
				_Visible[x + y * x_length] = Areas[x + y * x_length];
			}
		}
	}


	//boardcast player info
	_info::_info(playerDataPtr player)
	{
		state = car_enter;
		playerID = player->ID();
		playerName = player->Name();
		playerNation = player->Info().Nation();
		playerCarPos& Car = player->CarPos();
		cpos_x = Car.currentX();//��ǰλ��
		cpos_y = Car.currentY();//��ǰλ��
		aim_x = Car.aimX();
		aim_y = Car.aimY();
		cpos_idx = cpos_x / StanderX + (cpos_y / StanderY) * (MapData.size() / StanderX);
		playerBusiness& Trade = player->Biz();
		speed = Trade.getSpeed();
		level = Trade.getLevel();
		updateCD = 0;
		been_post = false;
	}

	static void PlayerAreaUpdate(const structTimer& timerData, boost::weak_ptr<_info> weak_info)
	{
		_info_ptr ptr = weak_info.lock();
		if (!ptr)return;
		ptr->been_post = false;
		if (ptr->isEnter())
		{
			playerDataPtr player = player_mgr.getOnlinePlayer(ptr->playerID);
			if (player)
			{
				ptr->sendCarePlayer(player);
				ptr->been_post = true;
				Timer::AddEventTickTime(boostBind(PlayerAreaUpdate, _1, ptr), Inter::event_trade_area_timer, ptr->updateCD);
			}
		}
	}

	_info_ptr _info::Create(playerDataPtr player)
	{
		_info_ptr info = Creator<_info>::Create(player);
		_brPlayers[player->ID()] = info;
		AreaData* current_area = MapData[info->cpos_x][info->cpos_y]._relateArea;
		current_area->replacePlayer(info);
		info->sendAround(player);
		info->been_post = true;
		Timer::AddEventTickTime(boostBind(PlayerAreaUpdate, _1, info), Inter::event_trade_area_timer, info->updateCD);
		return info;
	}

	void _info::setNewPos(playerDataPtr player, const unsigned x, const unsigned y)
	{
		AreaData* old_area = MapData[cpos_x][cpos_y]._relateArea;
		cpos_x = x;
		cpos_y = y;
		AreaData* new_area = MapData[cpos_x][cpos_y]._relateArea;
		const unsigned old_idx = cpos_idx;
		cpos_idx = cpos_x / StanderX + (cpos_y / StanderY) * (MapData.size() / StanderX);
		if (old_idx != cpos_idx)
		{
			old_area->removePlayer(playerID);
			new_area->replacePlayer(shared_from_this());
			updateCD = 0;
			sendAround(player);
		}
	}

	ptrAreaData _info::currentArea()
	{
		return getArea(cpos_idx);
	}

	void _info::sendAround(playerDataPtr player)
	{
		ptrAreaData now_area = currentArea();
		now_area->sendVisibleEvent(player);
		now_area->sendSomeVisiblePlayer(player, *this);
	}

	void _info::sendCarePlayer(playerDataPtr player)
	{
		ptrAreaData now_area = currentArea();
		now_area->sendSomeVisiblePlayer(player, *this);
	}

	void MapPoint::setEvent(const MapEvnet::Type type)
	{
		_relateArea->addEvent(_x, _y, type);
	}

	//instance
	business* const business::_Instance = new business();
	static zipFile _BusinessFile;//ó���ļ�д����
	static unsigned _RichTickTime = 0;

	struct AreaRange
	{
		int areaID;
		unsigned left_x;
		unsigned left_y;
		unsigned right_x;
		unsigned right_y;
	};
	UNORDERMAP(int, AreaRange, CityRangeMap);
	static CityRangeMap CitiesRange;//���з�Χ
	bool validCityRange(const int cityID, const unsigned x, const unsigned y)
	{
		CityRangeMap::iterator it = CitiesRange.find(cityID);
		if (it == CitiesRange.end())return false;
		const AreaRange& range = it->second;
		return (x >= range.left_x && x <= range.right_x && y >= range.left_y && y <= range.right_y);
	}

	//������Ʒ����
	struct CityData
	{
		CityData()
		{
			cityID = -1;
			EffectValue = 0;//Ӱ��ֵ
			EffectLast = 0;//Ӱ��ʱ��
			NowTrade = 0;//��ǰ������
			DayTrade = 0;//ÿ���������
			TradeModule = 0.0;//������ϵ��
			MinTrade = 0;
			MaxTrade = 0;

			NeedWare = -1;
			NeedLast = 0;
		}
		int cityID;
		struct Wares //��Ʒ
		{
			Wares()
			{
				price = 0;
				leaveStock = 0;
				todayStock = 0;
				history.clear();

				//��������
				minStock = 0;
				maxStock = 0;
				perStock = 0;

				//���ָ�
				perRecover = 0;
				minRecover = 0;
				maxRecover = 0;
			}
			//��仯��ֵ
			int price;//��ǰ�۸�
			unsigned leaveStock;//ʣ������
			unsigned todayStock;//������������

			//�����ֵ
			int wareID;//��ƷID
			int upPrice;//�ۼ�����
			int lowPrice;//�ۼ�����
			int upPriceF;//�ۼ۸�������
			int lowPriceF;//�ۼ۸�������
			//��ʼ��
			unsigned minStock;//��С�����
			unsigned maxStock;//�������
			double perStock;//ÿ�����¼���Ŀ��ϵ��

			unsigned minRecover;//��С�ظ���
			unsigned maxRecover;//���ظ���
			double perRecover;//ÿ��Сʱ�ظ������ϵ��

			vector<int> history;//��ʷ�۸�
			qValue toHisJson()
			{
				qValue json(qJson::qj_object), data_json(qJson::qj_array);
				json.addMember("id", wareID);
				for (unsigned i = 0; i < history.size(); ++i)
				{
					data_json.append(history[i]);
				}
				json.addMember("p", data_json);
				return json;
			}
			qValue toJson(const bool is_shop)
			{
				qValue json(qJson::qj_object);
				json.addMember("id", wareID);
				json.addMember("pr", price);
				if (is_shop)
				{
					json.addMember("ls", leaveStock);
					json.addMember("ts", todayStock);
				}
				return json;
			}
		};
		BOOSTSHAREPTR(Wares, warePtr);
		UNORDERMAP(int, warePtr, wareMap);
		wareMap PawnMap, ShopMap;//������Ʒ�б�, ������Ʒ�б�
		std::vector<int> PawnList, ShopList;//��ƷID�б�
		warePtr saleWare(const int wareID)
		{
			wareMap::iterator it = ShopMap.find(wareID);
			if (it == ShopMap.end())return warePtr();
			return it->second;
		}
		warePtr pawnWare(const int wareID)
		{
			wareMap::iterator it = PawnMap.find(wareID);
			if (it == PawnMap.end())return warePtr();
			return it->second;
		}
		void perDayTick()//���¼��������//�������
		{
			DayTrade = activity_player_sys.lastActivityPlayer() * TradeModule;
			DayTrade = std::max(DayTrade, MinTrade);
			DayTrade = std::min(DayTrade, MaxTrade);
			ForEach(wareMap, it, ShopMap)
			{
				warePtr ptr = it->second;
				ptr->todayStock = activity_player_sys.lastActivityPlayer() * ptr->perStock;
				ptr->todayStock = std::max(ptr->todayStock, ptr->minStock);
				ptr->todayStock = std::min(ptr->todayStock, ptr->maxStock);
				ptr->leaveStock = std::min(ptr->todayStock, ptr->leaveStock);
			}
		}
		//city buff
		int EffectValue;//Ӱ��ֵ
		unsigned EffectLast;//Ӱ��ʱ��
		bool invaildEffect()
		{
			if (EffectLast <= Common::gameTime())
			{
				if (EffectValue <= -5)//��ָ�����¼�
				{
					NowTrade = 0;
				}
				EffectValue = 0;
				EffectLast = 0;
				return true;
			}
			return false;
		}
		int rateEffect()
		{
			if (invaildEffect())return 0;
			return EffectValue;
		}
		int NeedWare;
		unsigned NeedLast;
		bool invaildNeed()
		{
			if (NeedLast <= Common::gameTime())
			{
				NeedWare = -1;
				return true;
			}
			return false;
		}
		int needID()
		{
			if (invaildEffect())return -1;
			return NeedWare;
		}
		unsigned NowTrade;//��ǰ������
		unsigned DayTrade;//ÿ���������
		double TradeModule;//������ϵ��
		unsigned MaxTrade;//��С������
		unsigned MinTrade;//�������
		void addTrade(const unsigned trade);//���ӽ�����
		qValue toJson()
		{
			qValue json(qJson::qj_object);
			json.addMember("id", cityID);
			qValue sj(qJson::qj_array), bj(qJson::qj_array);;
			for (wareMap::iterator it = PawnMap.begin(); it != PawnMap.end(); ++it)
			{
				sj.append(it->second->toJson(false));
			}
			json.addMember("s", sj);
			for (wareMap::iterator it = ShopMap.begin(); it != ShopMap.end(); ++it)
			{
				bj.append(it->second->toJson(true));
			}
			json.addMember("b", bj);
			json.addMember("r", rateEffect());
			json.addMember("t", EffectLast);
			json.addMember("nt", NowTrade);
			json.addMember("dt", DayTrade);
			json.addMember("nw", NeedWare);
			json.addMember("nl", NeedLast);
			return json;
		}
		_type_batch_unordered_set JoinPlayer;
		void despatchPlayer()
		{
			qValue data_json(qJson::qj_array);
			data_json.append(res_sucess)
				.append(cityID)
				.append(toJson());
			Batch::batchSign(JoinPlayer, qValue(qJson::qj_object).addMember(strMsg, data_json), gate_client::player_trade_city_update_resp);
			JoinPlayer.clear();
		}
	};
	BOOSTSHAREPTR(CityData, cityPtr);
	UNORDERMAP(int, cityPtr, cityMap);
	static cityMap Cities;
	static std::vector<int> CitiesIDList;
	qValue qjCityEvent()
	{
		qValue json(qJson::qj_array);
		ForEach(cityMap, it, Cities)
		{
			cityPtr city = it->second;
			json.append(
				qValue(qJson::qj_array).
				append(city->cityID).
				append(city->rateEffect()).
				append(city->EffectLast)
			);
		}
		return json;
	}
	Json::Value jsCityEvent()
	{
		Json::Value json = Json::arrayValue;
		ForEach(cityMap, it, Cities)
		{
			cityPtr city = it->second;
			Json::Value sg_json;
			sg_json.append(city->cityID);
			sg_json.append(city->rateEffect());
			sg_json.append(city->EffectLast);
			json.append(sg_json);
		}
		return json;
	}
	void CityData::addTrade(const unsigned trade)
	{
		if (NowTrade < DayTrade)
		{
			NowTrade += trade;
			NowTrade = std::min(NowTrade, DayTrade);
			if (NowTrade >= DayTrade)
			{
				NowTrade = DayTrade;
				EffectValue = -5;
				EffectLast = Common::gameTime() + 30 * MINUTE;
				despatchPlayer();
				qValue json = qjCityEvent();
				Batch::batchAll(
					qValue(qJson::qj_object).addMember(
						strMsg, qValue(qJson::qj_array).append(res_sucess).append(json)
					),
					gate_client::player_city_event_update_resp);
			}
			despatchPlayer();
		}
	}

	//����
	struct MapBox
	{
		unsigned LevelLimit;
		ActionRandomList BoxReward;
	};
	bool GreaterMapBox(const MapBox& left, const MapBox& right)
	{
		return left.LevelLimit > right.LevelLimit;
	}
	static vector<MapBox> SilverBox, GoldBox;

	//����
	struct Pirate
	{
		Pirate()
		{
			LevelLimit = 0;
			npcLevel = 0;
			battleValue = 0;
			background = -1;
			npcName = "bug";
			npcList.clear();
		}
		unsigned LevelLimit;
		unsigned npcLevel;
		int battleValue;
		int background;
		string npcName;
		int npcFace;
		struct armyNPC
		{
			armyNPC()
			{
				memset(this, 0x0, sizeof(armyNPC));
			}
			int npcID;
			bool holdMorale;
			int initAttri[characterNum];
			//int addAttri[characterNum];
			int armsType;
			double armsModule[armsModulesNum];
			int npcLevel;
			unsigned npcPos;
			int battleValue;
			int skill_1;
			int skill_2;
			BattleEquipList equipList;
		};
		vector< armyNPC > npcList;		//�����б�
		ActionRandomList rewardList;//�����б�
	};
	static bool less_pirate(const Pirate& left, const Pirate& right)
	{
		return left.LevelLimit > right.LevelLimit;
	}
	static vector<Pirate> PirateBox;


	//ÿ�յ�Ʊ���н���
	static Json::Value RichDayBoxes = Json::arrayValue;


	//·�����㷽��
	static WStar staticWStar;
	static bool setPlaceOK(const int x, const int y)
	{
		if ((unsigned)x < MapData.size())
		{
			vector< MapPoint >& yVec = MapData[x];
			if ((unsigned)y < yVec.size())
			{
				return yVec[y]._Available;
			}
		}
		return false;
	}


	//����boss�������
	const static unsigned SharkBossRateBase = 5000;
	const static unsigned SharkBossRateGrow = 2000;

	struct SharkBoss//�����
	{
		SharkBoss()
		{
			npcLevel = 0;
			battleValue = 0;
			background = -1;
			npcName = "bug";
			npcList.clear();
		}
		unsigned npcLevel;
		int battleValue;
		int background;
		string npcName;
		int npcFace;
		struct armyNPC
		{
			armyNPC()
			{
				memset(this, 0x0, sizeof(armyNPC) - sizeof(resist));
				resist.clear();
			}
			int npcID;
			bool holdMorale;
			int initAttri[characterNum];
			//int addAttri[characterNum];
			int armsType;
			double armsModule[armsModulesNum];
			int npcLevel;
			unsigned npcPos;
			int battleValue;
			int skill_1;
			int skill_2;
			BattleEquipList equipList;
			std::set<int> resist;
		};
		vector< armyNPC > npcList;		//�����б�
		ActionRandomList rewardList;//�����б�
	};

	static std::vector< SharkBoss > SharkBossList;

	static void clearSharkBox(
		const structTimer& timerData,
		boost::weak_ptr<SharkData> box
	)
	{
		ptrSharkData lock_data = box.lock();
		if (lock_data == _ActivityShark && _ActivityShark)
		{
			MapPoint& point = MapData[lock_data->_x][lock_data->_y];
			if (MapEvnet::shark_boss == point._Type)
			{
				point.setEvent(MapEvnet::null);
				point._relateArea->sendAroudNewEvent();
			}
		}
	}

	sBattlePtr npcShark(const SharkBoss& sk)
	{
		sBattlePtr sb = Creator<sideBattle>::Create();
		sb->playerID = -1;
		sb->playerName = sk.npcName;
		sb->isPlayer = false;
		sb->playerLevel = sk.npcLevel;
		sb->battleValue = sk.battleValue;
		sb->playerFace = sk.npcFace;
		manList& ml = sb->battleMan;
		ml.clear();
		const vector< SharkBoss::armyNPC >& npcList = sk.npcList;
		for (unsigned i = 0; i < npcList.size(); i++)
		{
			const SharkBoss::armyNPC& npc = npcList[i];
			mBattlePtr man = Creator<manBattle>::Create();
			man->manID = npc.npcID;
			man->holdMorale = npc.holdMorale;
			man->set_skill_1(npc.skill_1);
			man->set_skill_2(npc.skill_2);
			man->armsType = npc.armsType;
			man->manLevel = npc.npcLevel;
			man->currentIdx = npc.npcPos;
			man->battleValue = npc.battleValue;
			memcpy(man->armsModule, npc.armsModule, sizeof(man->armsModule));
			memcpy(man->initialAttri, npc.initAttri, sizeof(man->initialAttri));
			memcpy(man->battleAttri, npc.initAttri, sizeof(man->battleAttri));
			//memcpy(man->battleAttri, npc.addAttri, sizeof(man->battleAttri));
			man->currentHP = man->getTotalAttri(idx_hp);
			man->equipList = npc.equipList;
			man->resist = npc.resist;
			ml.push_back(man);
		}
		return sb;
	}

	static unsigned SharkBossRate = SharkBossRateBase;
	static unsigned SharkBossLevel = 0;

	//vip�����������
	static std::vector< unsigned > _VipBusinessTaskDaily;

	//�ݴ����
	static unsigned _BorrowTimeID;
	struct BorrowRWData
	{
		int _value;
		ActionBoxList _box;
	};
	static std::vector< BorrowRWData > _ArrowsExchangeShop;
	struct BorrowBoss//�ݴ�npc
	{
		BorrowBoss()
		{
			npcLevel = 0;
			battleValue = 0;
			background = -1;
			npcName = "bug";
			npcList.clear();
		}
		int battleValueLimit;//ս������
		unsigned npcLevel;
		int battleValue;
		int background;
		string npcName;
		int npcFace;
		struct armyNPC
		{
			armyNPC()
			{
				memset(this, 0x0, sizeof(armyNPC) - sizeof(resist));
				resist.clear();
			}
			int npcID;
			bool holdMorale;
			int initAttri[characterNum];
			//int addAttri[characterNum];
			int armsType;
			double armsModule[armsModulesNum];
			int npcLevel;
			unsigned npcPos;
			int battleValue;
			int skill_1;
			int skill_2;
			BattleEquipList equipList;
			std::set<int> resist;
		};
		vector< armyNPC > npcList;		//�����б�
	};
	static std::vector< BorrowBoss > _BorrowBossList;
	sBattlePtr npcBorrow(const BorrowBoss& bb)
	{
		sBattlePtr sb = Creator<sideBattle>::Create();
		sb->playerID = -1;
		sb->playerName = bb.npcName;
		sb->isPlayer = false;
		sb->playerLevel = bb.npcLevel;
		sb->battleValue = bb.battleValue;
		sb->playerFace = bb.npcFace;
		manList& ml = sb->battleMan;
		ml.clear();
		const vector< BorrowBoss::armyNPC >& npcList = bb.npcList;
		for (unsigned i = 0; i < npcList.size(); i++)
		{
			const BorrowBoss::armyNPC& npc = npcList[i];
			mBattlePtr man = Creator<manBattle>::Create();
			man->manID = npc.npcID;
			man->holdMorale = npc.holdMorale;
			man->set_skill_1(npc.skill_1);
			man->set_skill_2(npc.skill_2);
			man->armsType = npc.armsType;
			man->manLevel = npc.npcLevel;
			man->currentIdx = npc.npcPos;
			man->battleValue = npc.battleValue;
			memcpy(man->armsModule, npc.armsModule, sizeof(man->armsModule));
			memcpy(man->initialAttri, npc.initAttri, sizeof(man->initialAttri));
			memcpy(man->battleAttri, npc.initAttri, sizeof(man->battleAttri));
			//memcpy(man->battleAttri, npc.addAttri, sizeof(man->battleAttri));
			man->currentHP = man->getTotalAttri(idx_hp);
			man->equipList = npc.equipList;
			man->resist = npc.resist;
			ml.push_back(man);
		}
		return sb;
	}

	static std::vector< BorrowRWData > _BorrowStepRW;

	void business::initData()
	{
		cout << "load business ..." << endl;
		{//�ݴ�
			mongo::BSONObj obj = db_mgr.FindOne(DBN::dbBorrowWithBoat, BSON("key" << 1));
			if (obj.isEmpty())
			{
				_BorrowTimeID = season_sys.getNrAndNSTime(SEASON::Summer);
			}
			else
			{
				_BorrowTimeID = obj["time"].Int();
			}
		};
		{//vipÿ�������������
			_VipBusinessTaskDaily.clear();
			Json::Value json = Common::loadJsonFile("./instance/business/vip_task_daily.json");
			for (unsigned i = 0; i < json.size(); ++i)
			{
				_VipBusinessTaskDaily.push_back(json[i].asUInt());
			}
		};
		{
			RichDayBoxes = Common::loadJsonFile("./instance/business/rich_day_boxes.json");
		};
		{
			std::map<unsigned, Pirate> tmpPirateBox;
			PirateBox.clear();
			Json::Value json = Common::loadJsonFile("./instance/business/pirate.json");
			for (unsigned i = 0; i < json.size(); ++i)
			{
				Json::Value& pirateJson = json[i];
				const unsigned llimit = pirateJson["limit"].asUInt();
				Pirate pi = tmpPirateBox[llimit];
				pi.LevelLimit = llimit;
				pi.npcName = pirateJson["name"].asString();
				pi.npcFace = pirateJson["face"].asInt();
				pi.npcLevel = pirateJson["level"].asUInt();
				pi.background = pirateJson.isMember("background") ? pirateJson["background"].asInt() : 1;
				pi.battleValue = pirateJson["battleValue"].asInt();
				vector< Pirate::armyNPC >& npcl = pi.npcList;
				for (unsigned n = 0; n < pirateJson["army"].size(); ++n)
				{
					Pirate::armyNPC npc;
					Json::Value& sg_npc = pirateJson["army"][n];
					npc.npcID = sg_npc["npcID"].asInt();
					npc.holdMorale = sg_npc["holdMorale"].asBool();
					for (unsigned cn = 0; cn < characterNum; ++cn)
					{
						npc.initAttri[cn] = sg_npc["initAttri"][cn].asInt();
						//npc.addAttri[cn] = sg_npc["addAttri"][cn].asInt();
					}
					npc.armsType = sg_npc["armsType"].asInt();
					for (unsigned cn = 0; cn < armsModulesNum; ++cn)
					{
						npc.armsModule[cn] = sg_npc["armsModule"][cn].asDouble();
					}
					npc.npcLevel = sg_npc["npcLevel"].asInt();
					npc.npcPos = sg_npc["npcPos"].asUInt() % 9;
					npc.battleValue = sg_npc["battleValue"].asInt();
					npc.skill_1 = sg_npc["skill_1"].asInt();
					npc.skill_2 = sg_npc["skill_2"].asInt();
					for (unsigned eq_idx = 0; eq_idx < sg_npc["equip"].size(); ++eq_idx)
					{
						npc.equipList.push_back(BattleEquip(sg_npc["equip"][eq_idx][0u].asUInt(),
							sg_npc["equip"][eq_idx][1u].asInt(),
							sg_npc["equip"][eq_idx][2u].asUInt()));
					}
					npcl.push_back(npc);
				}
				pi.rewardList = actionFormat(pirateJson["box"].asInt());
				tmpPirateBox[pi.LevelLimit] = pi;
			}
			for (std::map<unsigned, Pirate>::iterator it = tmpPirateBox.begin(); it != tmpPirateBox.end(); ++it)
			{
				PirateBox.push_back(it->second);
			}
			std::sort(PirateBox.begin(), PirateBox.end(), less_pirate);
		};//����
		{
			SilverBox.clear();
			Json::Value json = Common::loadJsonFile("./instance/business/silver_box.json");
			for (unsigned i = 0; i < json.size(); ++i)
			{
				Json::Value& boxJson = json[i];
				MapBox box;
				box.LevelLimit = boxJson["limit"].asUInt();
				// 				Json::Value& reward = boxJson["box"];
				// 				box.BoxReward = actionFormat(reward);
				const unsigned rewardID = boxJson["box"].asUInt();
				box.BoxReward = actionFormat(rewardID);
				SilverBox.push_back(box);
			}
			std::sort(SilverBox.begin(), SilverBox.end(), GreaterMapBox);
		};//������
		{
			GoldBox.clear();
			Json::Value json = Common::loadJsonFile("./instance/business/gold_box.json");
			for (unsigned i = 0; i < json.size(); ++i)
			{
				Json::Value& boxJson = json[i];
				MapBox box;
				box.LevelLimit = boxJson["limit"].asUInt();
				// 				Json::Value& reward = boxJson["box"];
				// 				box.BoxReward = actionFormat(reward);
				const unsigned rewardID = boxJson["box"].asUInt();
				box.BoxReward = actionFormat(rewardID);
				GoldBox.push_back(box);
			}
			std::sort(GoldBox.begin(), GoldBox.end(), GreaterMapBox);
		};//����
		{
			BuffDoMap[FangShuiID] = TBstruct(TradeBuff::fangshui, 30 * MINUTE);
			BuffDoMap[WeiSheID] = TBstruct(TradeBuff::weishe, 60 * MINUTE);
			BuffDoMap[YiJiaID] = TBstruct(TradeBuff::yijia, 30 * MINUTE);
		};//buff�¼�
		//��ʼ����ص������ļ�
		{
			Business::initData();
		};
		{
			Common::createDirectories("./report/business/city/");//������Ϣ
		};//�����ļ���
		{
			Json::Value json = Common::loadJsonFile("./instance/business/event.json");
			CityWareNeed[0] = json["need"][0u].asUInt();
			CityWareNeed[1] = json["need"][0u].asUInt();
			CityEventNum = json["city"].asUInt();
			MapHaiDaoEvent[0] = json["haidao"][0u].asUInt();
			MapHaiDaoEvent[1] = json["haidao"][1u].asUInt();
			MapSilverBoxEvent[0] = json["silver_box"][0u].asUInt();
			MapSilverBoxEvent[1] = json["silver_box"][1u].asUInt();
			MapSilverBoxEvent[0] = json["gold_box"][0u].asUInt();
			MapSilverBoxEvent[1] = json["gold_box"][1u].asUInt();
		};//�¼���ʼ��

		{
			MapData.clear();
			Json::Value json = Common::loadJsonFile("./instance/business/map.json");
			const unsigned data_length = json[0u].size() +
				(json[0u].size() % StanderX > 0 ? (StanderX - json[0u].size() % StanderX) : 0);
			const unsigned json_data_high = json.size();
			const unsigned data_high = json.size() +
				(json.size() % StanderY > 0 ? (StanderY - json.size() % StanderY) : 0);//
			//ע��������� Ҫ������������
			//����ͼ��������ΪStander�ı���
			for (unsigned y = 0; y < data_length; ++y)//����ոպ��������� ���ò���
			{
				vector< MapPoint > vec;
				for (unsigned x = json_data_high - 1; x < json_data_high; --x)
				{
					const bool pass = (json[x][y].asInt() != 0);
					vec.push_back(
						MapPoint(0, 0, MapEvnet::null, pass)
					);
				}
				for (unsigned repair = json_data_high; repair < data_high; repair++)
				{
					vec.push_back(
						MapPoint(0, 0, MapEvnet::null, false)
					);
				}
				MapData.push_back(vec);
			}

			//Ѱ·������ʼ��
			staticWStar.publicReach = boostBind(setPlaceOK, _1, _2);//��⺯��
			staticWStar.publicCorner = true;//����б������

			//������ʼ��
			std::set<WSTAR::Pos> staticShowShark;
			staticShowShark.clear();
			json = Common::loadJsonFile("./instance/business/shark.json");
			for (unsigned i = 0; i < json.size(); ++i)
			{
				Json::Value& cityJson = json[i];
				const unsigned spx = cityJson["x"].asUInt();
				const unsigned spy = cityJson["y"].asUInt();
				MapData[spx][spy]._Type = MapEvnet::shark;//���������
				staticShowShark.insert(WSTAR::Pos(spx, spy));


				//��������ƫ��
				const unsigned left_bottom_x = spx < 2 ? 0 : spx - 2;
				const unsigned left_bottom_y = spy < 2 ? 0 : spy - 2;

				//��������ƫ��
				const unsigned right_top_x = spx + 2 < data_length ? spx + 2 : spx;
				const unsigned right_top_y = spy + 2 < data_high ? spy + 2 : spy;

				for (unsigned x = left_bottom_x; x <= right_top_x; x++)
				{
					for (unsigned y = left_bottom_y; y <= right_top_y; y++)
					{
						staticShowShark.insert(WSTAR::Pos(x, y));
					}
				}
			}

			//�¼�����//��ͼ�������
			EventCoor.clear();
			for (unsigned x = 0; x < MapData.size(); ++x)
			{
				vector< MapPoint >& vec = MapData[x];
				for (unsigned y = 0; y < vec.size(); ++y)
				{
					MapPoint& point = vec[y];
					point._x = x;
					point._y = y;
					if (point._Available &&
						staticShowShark.find(WSTAR::Pos(x, y)) == staticShowShark.end())
					{
						if (
							point._x < 2 ||
							point._y < 2 ||
							point._x + 2 >= data_length ||
							point._y + 2 >= data_high
							)continue;
						EventCoor.push_back(WSTAR::Pos(x, y));
					}
				}
			}

			//������ͼ��������
			for (unsigned x = 0; x < MapData.size(); ++x)
			{
				vector< MapPoint >& vec = MapData[x];
				for (unsigned y = 0; y < vec.size(); ++y)
				{
					MapPoint& point = vec[y];
					const unsigned idx = x / StanderX + (y / StanderY) * (MapData.size() / StanderX);
					ptrAreaData ptr = Areas[idx];
					if (!ptr)
					{
						Areas[idx] = Creator<AreaData>::Create(
							idx,//���
							(x / StanderX) * StanderX,//����x
							(y / StanderY) * StanderY,//����y
							(x / StanderX) * StanderX + (x / StanderX) * StanderX + StanderX - 1,//����x
							(y / StanderY) * StanderY + (y / StanderY) * StanderY + StanderY - 1//����y
						);
						ptr = Areas[idx];
					}
					point._relateArea = ptr.get();
				}
			}

			//���������ϵ
			for (AreaMap::iterator it = Areas.begin(); it != Areas.end(); it++)
			{
				ptrAreaData ptr = it->second;
				ptr->bindAreaRelate();//�󶨹�ϵ, ����������
			}

			//���ó�����
			UsePos.clear();
			for (unsigned bron_x = 10; bron_x <= 12; bron_x++)
			{
				for (unsigned bron_y = 17; bron_y <= 20; bron_y++)
				{
					if (availablePlace(bron_x, bron_y))
					{
						UsePos.push_back(WSTAR::Pos(bron_x, bron_y));
					}
				}
			}

		};//��ͼ��Ϣ

		{
			CitiesRange.clear();
			Json::Value json = Common::loadJsonFile("./instance/business/city_range.json");
			for (unsigned i = 0; i < json.size(); ++i)
			{
				Json::Value& cityJson = json[i];
				AreaRange range;
				range.areaID = cityJson["cityID"].asInt();
				range.left_x = cityJson["left_x"].asUInt();
				range.left_y = cityJson["left_y"].asUInt();
				range.right_x = cityJson["right_x"].asUInt();
				range.right_y = cityJson["right_y"].asUInt();
				CitiesRange[range.areaID] = range;
			}
		};//��ͼ�������귶Χ

		{
			Json::Value json = Common::loadJsonFile("./instance/business/city.json");
			for (unsigned i = 0; i < json.size(); ++i)
			{
				Json::Value& city_json = json[i];
				cityPtr city = Creator<CityData>::Create();
				city->cityID = city_json["id"].asInt();
				city->TradeModule = city_json["module"].asDouble();
				city->MinTrade = city_json["min"].asInt();
				city->MaxTrade = city_json["max"].asInt();
				for (unsigned n = 0; n < city_json["buy"].size(); ++n)
				{
					Json::Value& ware_json = city_json["buy"][n];
					CityData::warePtr ware = Creator<CityData::Wares>::Create();
					ware->wareID = ware_json["wareID"].asInt();
					ware->lowPrice = ware_json["lowPrice"].asInt();
					ware->upPrice = ware_json["upPrice"].asInt();
					ware->lowPriceF = ware_json["lowPriceF"].asInt();
					ware->upPriceF = ware_json["upPriceF"].asInt();
					ware->minStock = ware_json["minStock"].asUInt();
					ware->maxStock = ware_json["maxStock"].asUInt();
					ware->perStock = ware_json["perStock"].asDouble();
					ware->minRecover = ware_json["minRecover"].asUInt();
					ware->maxRecover = ware_json["maxRecover"].asUInt();
					ware->perRecover = ware_json["perRecover"].asDouble();
					ware->leaveStock = ware_json["stock"].asDouble();
					city->ShopMap[ware->wareID] = ware;
					city->ShopList.push_back(ware->wareID);
				}
				for (unsigned n = 0; n < city_json["sale"].size(); ++n)
				{
					Json::Value& ware_json = city_json["sale"][n];
					CityData::warePtr ware = Creator<CityData::Wares>::Create();
					ware->wareID = ware_json["wareID"].asInt();
					ware->lowPrice = ware_json["lowPrice"].asInt();
					ware->upPrice = ware_json["upPrice"].asInt();
					ware->lowPriceF = ware_json["lowPriceF"].asInt();
					ware->upPriceF = ware_json["upPriceF"].asInt();
					city->PawnMap[ware->wareID] = ware;
					city->PawnList.push_back(ware->wareID);
				}
				city->perDayTick();
				Cities[city->cityID] = city;
				CitiesIDList.push_back(city->cityID);
			}
			for (cityMap::iterator it = Cities.begin(); it != Cities.end(); ++it)
			{
				cityPtr city = it->second;
				const string file_name = "./report/business/city/" + Common::toString(it->first);
				Json::Value json = _BusinessFile.read_json(file_name);
				if (json.isNull())//�ļ�Ϊ��, ��ô�������ɼ۸�
				{
					qValue write_json(qJson::qj_object), buy_json(qJson::qj_array), sale_json(qJson::qj_array);
					for (CityData::wareMap::iterator wit = city->ShopMap.begin(); wit != city->ShopMap.end(); ++wit)
					{
						CityData::warePtr ware = wit->second;
						ware->price = Common::randomBetween(ware->lowPrice, ware->upPrice);
						ware->history.push_back(ware->price);
						buy_json.append(ware->toHisJson());
					}
					for (CityData::wareMap::iterator wit = city->PawnMap.begin(); wit != city->PawnMap.end(); ++wit)
					{
						CityData::warePtr ware = wit->second;
						ware->price = Common::randomBetween(ware->lowPrice, ware->upPrice);
						ware->history.push_back(ware->price);
						sale_json.append(ware->toHisJson());
					}
					write_json.addMember("b", buy_json);
					write_json.addMember("s", sale_json);
					_BusinessFile.write(file_name, write_json);
					continue;
				}
				for (unsigned i = 0; i < json["b"].size(); ++i)
				{
					Json::Value& item_json = json["b"][i];
					CityData::wareMap::iterator wit = city->ShopMap.find(item_json["id"].asInt());
					if (wit == city->ShopMap.end())continue;
					CityData::warePtr ware = wit->second;
					for (unsigned n = 0; n < item_json["p"].size(); ++n)
					{
						ware->history.push_back(item_json["p"][n].asInt());
					}
					ware->price = ware->history.back();
				}
				for (unsigned i = 0; i < json["s"].size(); ++i)
				{
					Json::Value& item_json = json["s"][i];
					CityData::wareMap::iterator wit = city->PawnMap.find(item_json["id"].asInt());
					if (wit == city->PawnMap.end())continue;
					CityData::warePtr ware = wit->second;
					for (unsigned n = 0; n < item_json["p"].size(); ++n)
					{
						ware->history.push_back(item_json["p"][n].asInt());
					}
					ware->price = ware->history.back();
				}
				for (CityData::wareMap::iterator wit = city->ShopMap.begin(); wit != city->ShopMap.end(); ++wit)
				{
					CityData::warePtr ware = wit->second;
					if (ware->history.empty())
					{
						ware->price = Common::randomBetween(ware->lowPrice, ware->upPrice);
						ware->history.push_back(ware->price);
					}
				}
				for (CityData::wareMap::iterator wit = city->PawnMap.begin(); wit != city->PawnMap.end(); ++wit)
				{
					CityData::warePtr ware = wit->second;
					if (ware->history.empty())
					{
						ware->price = Common::randomBetween(ware->lowPrice, ware->upPrice);
						ware->history.push_back(ware->price);
					}
				}
			}
		};//������Ϣ

		{
			//timer
			{
				_RichTickTime = Common::timeZero(Common::gameTime()) + DAY;
				mongo::BSONObj key = BSON("key" << 4);
				mongo::BSONObj obj = db_mgr.FindOne(DBN::dbPlayerTradeRich, key);
				if (!obj.isEmpty())
				{
					_RichTickTime = (unsigned)obj["tt"].Int();
				}
				else
				{
					saveTimerRich();
				}
			};
		};//���������ݶ�ȡ//���ݿ�

		{//�������ݳ�ʼ��
			SharkBossList.clear();
			Json::Value json = Common::loadJsonFile("./instance/business/shark_boss.json");
			for (unsigned i = 0; i < json.size(); ++i)
			{
				Json::Value& sharkJson = json[i];
				SharkBoss sk;
				sk.npcName = sharkJson["name"].asString();
				sk.npcFace = sharkJson["face"].asInt();
				sk.npcLevel = sharkJson["level"].asUInt();
				sk.background = sharkJson.isMember("background") ? sharkJson["background"].asInt() : 1;
				sk.battleValue = sharkJson["battleValue"].asInt();
				vector< SharkBoss::armyNPC >& npcl = sk.npcList;
				for (unsigned n = 0; n < sharkJson["armys"].size(); ++n)
				{
					SharkBoss::armyNPC npc;
					Json::Value& sg_npc = sharkJson["armys"][n];
					npc.npcID = sg_npc["npcID"].asInt();
					npc.holdMorale = sg_npc["holdMorale"].asBool();
					for (unsigned cn = 0; cn < characterNum; ++cn)
					{
						npc.initAttri[cn] = sg_npc["initAttri"][cn].asInt();
						//npc.addAttri[cn] = sg_npc["addAttri"][cn].asInt();
					}
					npc.armsType = sg_npc["armsType"].asInt();
					for (unsigned cn = 0; cn < armsModulesNum; ++cn)
					{
						npc.armsModule[cn] = sg_npc["armsModule"][cn].asDouble();
					}
					npc.npcLevel = sg_npc["npcLevel"].asInt();
					npc.npcPos = sg_npc["npcPos"].asUInt() % 9;
					npc.battleValue = sg_npc["battleValue"].asInt();
					npc.skill_1 = sg_npc["skill_1"].asInt();
					npc.skill_2 = sg_npc["skill_2"].asInt();
					for (unsigned eq_idx = 0; eq_idx < sg_npc["equip"].size(); ++eq_idx)
					{
						npc.equipList.push_back(BattleEquip(sg_npc["equip"][eq_idx][0u].asUInt(),
							sg_npc["equip"][eq_idx][1u].asInt(),
							sg_npc["equip"][eq_idx][2u].asUInt()));
					}
					for (unsigned idx_resist = 0; idx_resist < sg_npc["resist"].size(); ++idx_resist)
					{
						npc.resist.insert(sg_npc["resist"][idx_resist].asInt());
					}
					npcl.push_back(npc);
				}
				sk.rewardList = actionFormat(sharkJson["box"].asInt());
				SharkBossList.push_back(sk);
			}

			mongo::BSONObj key = BSON("key" << 5);
			mongo::BSONObj obj = db_mgr.FindOne(DBN::dbPlayerTradeRich, key);
			if (!obj.isEmpty())
			{
				SharkBossRate = obj["ra"].Int();
				SharkBossLevel = obj["lv"].Int();
				if (SharkBossLevel >= SharkBossList.size())
				{
					SharkBossLevel = 0;
					saveSharkBoss();
				}
			}
			else
			{
				saveSharkBoss();
			}

			key = BSON("key" << 6);
			obj = db_mgr.FindOne(DBN::dbPlayerTradeRich, key);
			if (!obj.isEmpty())
			{
				_ActivityShark = Creator<SharkData>::Create(obj["ct"].Int());
				_ActivityShark->_shark = npcShark(SharkBossList[SharkBossLevel]);
				manList& checkMan = _ActivityShark->_shark->battleMan;
				vector<mongo::BSONElement> vec = obj["hp"].Array();
				for (unsigned i = 0; i < checkMan.size() && i < vec.size(); i++)
				{
					checkMan[i]->currentHP = vec[i].Int();
					_ActivityShark->_current_hp += checkMan[i]->currentHP;
					_ActivityShark->_total_hp += checkMan[i]->getTotalAttri(idx_hp);
				}
				_ActivityShark->_boxTime = obj["bt"].Int();
				_ActivityShark->_hitTime = obj["ht"].Int();
				_ActivityShark->_x = obj["ax"].Int();
				_ActivityShark->_y = obj["ay"].Int();
			}
		};


		//�ݴ����
		{
			//�һ��̵�
			_ArrowsExchangeShop.clear();
			Json::Value exch_json = Common::loadJsonFile("./instance/business/arrow_exch.json");
			for (unsigned i = 0; i < exch_json.size(); ++i)
			{
				BorrowRWData data;
				data._value = exch_json[i]["cost"].asInt();
				data._box = actionFormatBox(exch_json[i]["box"]);
				_ArrowsExchangeShop.push_back(data);
			}

			//�ݴ�npc
			_BorrowBossList.clear();
			Json::Value npc_json = Common::loadJsonFile("./instance/business/borrow_npc.json");
			for (unsigned i = 0; i < npc_json.size(); ++i)
			{
				Json::Value& borrowNpc = npc_json[i];
				BorrowBoss bb;
				bb.battleValueLimit = borrowNpc["limit"].asInt();
				bb.npcName = borrowNpc["name"].asString();
				bb.npcFace = borrowNpc["face"].asInt();
				bb.npcLevel = borrowNpc["level"].asUInt();
				bb.background = borrowNpc.isMember("background") ? borrowNpc["background"].asInt() : 1;
				bb.battleValue = borrowNpc["battleValue"].asInt();
				vector< BorrowBoss::armyNPC >& npcl = bb.npcList;
				for (unsigned n = 0; n < borrowNpc["armys"].size(); ++n)
				{
					BorrowBoss::armyNPC npc;
					Json::Value& sg_npc = borrowNpc["armys"][n];
					npc.npcID = sg_npc["npcID"].asInt();
					npc.holdMorale = sg_npc["holdMorale"].asBool();
					for (unsigned cn = 0; cn < characterNum; ++cn)
					{
						npc.initAttri[cn] = sg_npc["initAttri"][cn].asInt();
						//npc.addAttri[cn] = sg_npc["addAttri"][cn].asInt();
					}
					npc.armsType = sg_npc["armsType"].asInt();
					for (unsigned cn = 0; cn < armsModulesNum; ++cn)
					{
						npc.armsModule[cn] = sg_npc["armsModule"][cn].asDouble();
					}
					npc.npcLevel = sg_npc["npcLevel"].asInt();
					npc.npcPos = sg_npc["npcPos"].asUInt() % 9;
					npc.battleValue = sg_npc["battleValue"].asInt();
					npc.skill_1 = sg_npc["skill_1"].asInt();
					npc.skill_2 = sg_npc["skill_2"].asInt();
					for (unsigned eq_idx = 0; eq_idx < sg_npc["equip"].size(); ++eq_idx)
					{
						npc.equipList.push_back(BattleEquip(sg_npc["equip"][eq_idx][0u].asUInt(),
							sg_npc["equip"][eq_idx][1u].asInt(),
							sg_npc["equip"][eq_idx][2u].asUInt()));
					}
					for (unsigned idx_resist = 0; idx_resist < sg_npc["resist"].size(); ++idx_resist)
					{
						npc.resist.insert(sg_npc["resist"][idx_resist].asInt());
					}
					npcl.push_back(npc);
				}
				_BorrowBossList.push_back(bb);
			}

			//�ݴ��׶ν���
			_BorrowStepRW.clear();
			Json::Value step_json = Common::loadJsonFile("./instance/business/borrow_step.json");
			for (unsigned i = 0; i < step_json.size(); ++i)
			{
				BorrowRWData rw;
				rw._value = step_json[i]["limit"].asInt();
				rw._box = actionFormatBox(step_json[i]["box"]);
				_BorrowStepRW.push_back(rw);
			}

		};

		//�׳���ʱ��
		{
			Timer::AddEventPerTimeCT(boostBind(business::borrowWithBoat, this, _1), Inter::event_borrow_with_boat, _BorrowTimeID, 4 * DAY);
			const unsigned now = Common::gameTime();
			const tm tm_now = Common::toTm(now);
			const unsigned tick_price = now - tm_now.tm_sec - (tm_now.tm_min % 10) * MINUTE + 10 * MINUTE;
			Timer::AddEventPerTimeCT(boostBind(business::per10MTick, this, _1), Inter::event_city_price_timer, tick_price, 10 * MINUTE);
			const unsigned tick_city = now - tm_now.tm_sec - tm_now.tm_min * MINUTE + (tm_now.tm_min >= 30 ? MINUTE * 30 : 0);
			Timer::AddEventPerTimeCT(boostBind(business::perHalfHourTick, this, _1), Inter::event_city_event_timer, tick_city, 30 * MINUTE);
			const unsigned tick_event = now - tm_now.tm_sec - tm_now.tm_min * MINUTE;
			Timer::AddEventTickTime(boostBind(business::perHourEventTick, this, _1), Inter::event_map_event_timer, tick_event);
			const unsigned tick_day_rich = now - tm_now.tm_sec - tm_now.tm_min * MINUTE;
			Timer::AddEventTickTime(boostBind(business::richTick, this, _1), Inter::event_rich_event_timer, _RichTickTime);//�����¼�
		};//��ʱ���趨����
	}

	void business::per10MTick(const structTimer& timerData)
	{
		for (cityMap::iterator it = Cities.begin(); it != Cities.end(); ++it)
		{
			cityPtr city = it->second;
			const string file_name = "./report/business/city/" + Common::toString(it->first);
			qValue write_json(qJson::qj_object), buy_json(qJson::qj_array), sale_json(qJson::qj_array);
			for (CityData::wareMap::iterator wit = city->ShopMap.begin(); wit != city->ShopMap.end(); ++wit)
			{
				CityData::warePtr ware = wit->second;
				int alter_price = Common::randomBetween(ware->lowPriceF, ware->upPriceF);
				if (Common::randomOk(0.5))alter_price = -alter_price;
				int final_price = ware->price + alter_price;
				if (final_price <= ware->upPrice && final_price >= ware->lowPrice)
				{
					ware->price = final_price;
				}
				else
				{
					final_price = ware->price - alter_price;
					if (final_price <= ware->upPrice && final_price >= ware->lowPrice)
					{
						ware->price = final_price;
					}
					else
					{
						ware->price = Common::randomBetween(ware->lowPrice, ware->upPrice);
					}
				}
				ware->history.push_back(ware->price);
				if (ware->history.size() > 100)ware->history.erase(ware->history.begin());
				buy_json.append(ware->toHisJson());
			}
			for (CityData::wareMap::iterator wit = city->PawnMap.begin(); wit != city->PawnMap.end(); ++wit)
			{
				CityData::warePtr ware = wit->second;
				int alter_price = Common::randomBetween(ware->lowPriceF, ware->upPriceF);
				if (Common::randomOk(0.5))alter_price = -alter_price;
				int final_price = ware->price + alter_price;
				if (final_price <= ware->upPrice && final_price >= ware->lowPrice)
				{
					ware->price = final_price;
				}
				else
				{
					final_price = ware->price - alter_price;
					if (final_price <= ware->upPrice && final_price >= ware->lowPrice)
					{
						ware->price = final_price;
					}
					else
					{
						ware->price = Common::randomBetween(ware->lowPrice, ware->upPrice);
					}
				}
				ware->history.push_back(ware->price);
				if (ware->history.size() > 100)ware->history.erase(ware->history.begin());
				sale_json.append(ware->toHisJson());
			}
			write_json.addMember("b", buy_json);
			write_json.addMember("s", sale_json);
			_BusinessFile.async_write(file_name, write_json);
			//����
			city->despatchPlayer();
		}
	}

	const static int cityRate[] = { -3, 3, 5 };
	void business::perHalfHourTick(const structTimer& timerData)
	{
		boost::unordered_set<cityPtr> update_city_list;
		//�ȴ��������¼�, �ָ����
		ForEach(cityMap, it, Cities)
		{
			cityPtr city = it->second;
			ForEach(CityData::wareMap, ware_it, city->PawnMap)
			{
				CityData::warePtr ware = ware_it->second;
				unsigned reover = (activity_player_sys.lastActivityPlayer() * ware->perRecover);
				reover = std::max(ware->minRecover, reover);
				reover = std::min(ware->maxRecover, reover);
				ware->leaveStock += reover;
				ware->leaveStock = std::min(ware->todayStock, ware->leaveStock);
				update_city_list.insert(city);
			}
		}
		const unsigned need_event = Common::randomBetween(CityWareNeed[0], CityWareNeed[1]);
		const unsigned end_buff_time = timerData.tickTime + 30 * MINUTE;
		std::vector<int> random_list = CitiesIDList;
		random_shuffle(random_list.begin(), random_list.end());
		for (unsigned i = 0; i < CityEventNum; ++i)
		{
			cityPtr city = Cities[random_list[i]];
			if (city->invaildEffect())
			{
				city->EffectValue = cityRate[Common::randomBetween(0, 2)];
				city->EffectLast = end_buff_time;
				update_city_list.insert(city);
			}
		}
		random_shuffle(random_list.begin(), random_list.end());
		for (unsigned i = 0; i < CityEventNum; ++i)
		{
			cityPtr city = Cities[random_list[i]];
			std::vector<int> pawn_list = city->PawnList;
			random_shuffle(pawn_list.begin(), pawn_list.end());
			city->NeedWare = pawn_list[0];
			city->NeedLast = end_buff_time;
			update_city_list.insert(city);
		}
		ForEach(boost::unordered_set<cityPtr>, it, update_city_list)
		{
			cityPtr city = *it;
			city->despatchPlayer();
		}
		qValue json = qjCityEvent();
		Batch::batchAll(
			qValue(qJson::qj_object).addMember(
				strMsg, qValue(qJson::qj_array).append(res_sucess).append(json)
			),
			gate_client::player_city_event_update_resp);
	}

	void business::perHourEventTick(const structTimer& timerData)
	{
		//����ֵ������ ��Լ��8 * 5,  ��ô���� max_x - 4 >= x >= 4  max_y - 3 >= y >= 3 ��Χ��Ҫ�����õ�
		vector<MapPoint> EventList;
		std::set<WSTAR::Pos> filterList;
		random_shuffle(EventCoor.begin(), EventCoor.end());//
		const unsigned now = Common::gameTime();
		const tm tm_now = Common::toTm(now);

		const unsigned shark_tick = now - tm_now.tm_min * MINUTE - tm_now.tm_sec;
		if (_ActivityShark && _ActivityShark->_createTick == shark_tick)//�����ǰ���¼�ID == Ԥ�����ɵ��¼�ID, ��ô
		{
			if (_ActivityShark->_boxTime > now)
			{
				for (int x = _ActivityShark->_x - 3; x <= _ActivityShark->_x + 3; x++)
				{
					for (int y = _ActivityShark->_y - 2; y <= _ActivityShark->_y + 2; y++)
					{
						if (setPlaceOK(x, y))
						{
							filterList.insert(WSTAR::Pos(x, y));
							continue;
						}
						filterList.clear();
						goto __NOVAILDINITDATA__;
					}
				}

				EventList.push_back(MapPoint(_ActivityShark->_x, _ActivityShark->_y, MapEvnet::shark_boss_chest));
				Timer::AddEventTickTime(
					boostBind(clearSharkBox, _1, _ActivityShark),
					Inter::event_clear_shark_chest_timer,
					_ActivityShark->_boxTime
				);

			__NOVAILDINITDATA__:
				;
			}
			else if (!_ActivityShark->_shark->isDeadAll())
			{
				filterList.insert(WSTAR::Pos(_ActivityShark->_x, _ActivityShark->_y));
				EventList.push_back(MapPoint(_ActivityShark->_x, _ActivityShark->_y, MapEvnet::shark_boss));
			}
		}
		else
		{
			if (tm_now.tm_hour >= 12 && tm_now.tm_hour <= 18)//ÿ��12�㵽18��֮��
			{
				if (Common::randomOk((int)SharkBossRate))
				{
					SharkBossRate = SharkBossRateBase;//��ʼֵ
					for (unsigned i = 0; i < EventCoor.size(); ++i)
					{
						const WSTAR::Pos& coor = EventCoor[i];
						filterList.clear();
						for (int x = coor.x - 3; x <= coor.x + 3; x++)
						{
							for (int y = coor.y - 2; y <= coor.y + 2; y++)
							{
								if (!setPlaceOK(x, y))
								{
									goto __NOACCESSPOS__;
								}
								filterList.insert(WSTAR::Pos(x, y));
							}
						}

						EventList.push_back(MapPoint(coor.x, coor.y, MapEvnet::shark_boss));
						break;

					__NOACCESSPOS__:
						continue;
					}
				}
				else
				{
					SharkBossRate += SharkBossRateGrow;
				}
				saveSharkBoss();
			}
		}

		//�����¼�
		const unsigned pirate_num = Common::randomBetween(MapHaiDaoEvent[0], MapHaiDaoEvent[1]);
		const unsigned silver_box_num = Common::randomBetween(MapSilverBoxEvent[0], MapSilverBoxEvent[1]);
		const unsigned gold_box_num = Common::randomBetween(MapGoldBoxEvent[0], MapGoldBoxEvent[1]);
		unsigned begin_idx = 0;
		unsigned num = 0;
		for (unsigned i = begin_idx; i < EventCoor.size() && num < pirate_num; ++i)
		{
			const WSTAR::Pos& coor = EventCoor[i];
			if (filterList.find(coor) != filterList.end())continue;
			++num;
			EventList.push_back(MapPoint(coor.x, coor.y, MapEvnet::haidao));
		}
		begin_idx += pirate_num;
		num = 0;
		for (unsigned i = begin_idx; i < EventCoor.size() && num < silver_box_num; ++i)
		{
			const WSTAR::Pos& coor = EventCoor[i];
			if (filterList.find(coor) != filterList.end())continue;
			++num;
			EventList.push_back(MapPoint(coor.x, coor.y, MapEvnet::silver_box));
		}
		begin_idx += silver_box_num;
		num = 0;
		for (unsigned i = begin_idx; i < EventCoor.size() && num < gold_box_num; ++i)
		{
			const WSTAR::Pos& coor = EventCoor[i];
			if (filterList.find(coor) != filterList.end())continue;
			++num;
			EventList.push_back(MapPoint(coor.x, coor.y, MapEvnet::gold_box));
		}
		begin_idx += gold_box_num;
		num = 0;


		for (AreaMap::iterator it = Areas.begin(); it != Areas.end(); it++)
		{
			ptrAreaData ptr = it->second;
			ptr->clearEvent();
		}
		for (unsigned i = 0; i < EventList.size(); i++)
		{
			const MapPoint& point = EventList[i];
			MapData[point._x][point._y].setEvent(point._Type);
			if (point._Type == MapEvnet::shark_boss)
			{
				_ActivityShark = Creator<SharkData>::Create(shark_tick);
				_ActivityShark->_shark = npcShark(SharkBossList[SharkBossLevel]);//�����µ����㲢�ҹ㲥
				_ActivityShark->_x = point._x;
				_ActivityShark->_y = point._y;
				const manList& checkMan = _ActivityShark->_shark->battleMan;
				for (unsigned i = 0; i < checkMan.size(); i++)
				{
					_ActivityShark->_total_hp += checkMan[i]->getTotalAttri(idx_hp);
				}
				_ActivityShark->_current_hp = _ActivityShark->_total_hp;
				saveSharkState();//����״̬
				qValue json(qJson::qj_array);
				chat_sys.despatchAll(CHAT::server_business_shark_boss_appear, json);
			}
		}
		//������ó�׵��������һ������
		for (AreaMap::iterator it = Areas.begin(); it != Areas.end(); it++)
		{
			ptrAreaData ptr = it->second;
			ptr->sendAroudNewEvent();
		}

		const unsigned tick_event = now - tm_now.tm_sec - tm_now.tm_min * MINUTE + 1 + HOUR;
		Timer::AddEventTickTime(boostBind(business::perHourEventTick, this, _1), Inter::event_map_event_timer, tick_event);
	}

	// key 1,2,3�Ѿ�����
	void business::saveTimerRich()
	{
		mongo::BSONObj key = BSON("key" << 4);
		mongo::BSONObj obj = BSON("key" << 4 << "tt" << _RichTickTime);
		db_mgr.SaveMongo(DBN::dbPlayerTradeRich, key, obj);
	}

	void business::saveSharkBoss()
	{
		mongo::BSONObj key = BSON("key" << 5);
		mongo::BSONObj obj = BSON("key" << 5 << "ra" << SharkBossRate << "lv" << SharkBossLevel);
		db_mgr.SaveMongo(DBN::dbPlayerTradeRich, key, obj);
	}

	void business::saveSharkState()
	{
		if (_ActivityShark)
		{
			mongo::BSONObj key = BSON("key" << 6);
			mongo::BSONArrayBuilder arr;
			const manList& checkMan = _ActivityShark->_shark->battleMan;
			for (unsigned i = 0; i < checkMan.size(); i++)
			{
				arr << checkMan[i]->currentHP;
			}
			mongo::BSONObj obj = BSON(
				"key" << 6 << "ct" << _ActivityShark->_createTick << "ht" <<
				_ActivityShark->_hitTime << "bt" << _ActivityShark->_boxTime << "ax" << _ActivityShark->_x
				<< "ay" << _ActivityShark->_y << "hp" << arr.arr()
			);
			db_mgr.SaveMongo(DBN::dbPlayerTradeRich, key, obj);
		}
	}

	void business::richTick(const structTimer& timerData)
	{
		{
			qValue data_json(qJson::qj_array);
			unsigned box_idx = 0;
			for (
				BusinessDailyRank::iterator_type it = business_daily_rank.rank_begin();
				it != business_daily_rank.rank_end();
				++it
				)
			{
				if (RichDayBoxes.size() <= box_idx)break;

				NSBusinessDailyRank::ptrRankData rich = it->second;
				Json::Value p_json;
				p_json.append(rich->playerName);
				p_json.append(box_idx + 1);
				Json::Value rw_json = jsonFormats2c(RichDayBoxes[box_idx]);
				EmailPtr email_ptr = email_sys.createPackage(EmailDef::RichDayEmailReward, p_json, rw_json);
				email_sys.sendToPlayer(rich->playerID, email_ptr);
				Log(DBLOG::strLogTradeRank, 0, rich->playerID, rich->playerName, rich->rankNo, rich->businessMoney);
				++box_idx;
			}
			business_daily_rank.clearAllData();
		};//���յ�Ʊ
		//д���¸�richд���ʱ��
		_RichTickTime += DAY;
		saveTimerRich();
		Timer::AddEventTickTime(boostBind(business::richTick, this, _1), Inter::event_rich_event_timer, _RichTickTime);//�����¼�
	}

	void business::playerOFFLine(const int playerID)
	{
		_info_ptr info = getBRPlayer(playerID);
		if (info)
		{
			AreaData* current_area = MapData[info->cpos_x][info->cpos_y]._relateArea;
			current_area->removePlayer(playerID);
			_brPlayers.erase(playerID);//ɾ������
		}
	}

	bool business::inSharkArea(const int x, const int y)
	{
		if ((unsigned)x < MapData.size())
		{
			vector< MapPoint >& yVec = MapData[x];
			if ((unsigned)y < yVec.size())
			{
				return yVec[y]._Type == MapEvnet::shark;
			}
		}
		return false;
	}

	WSTAR::Pos business::getAvailablePos()
	{
		return UsePos[Common::randomBetween(0, UsePos.size() - 1)];
	}

	bool business::availablePlace(const int x, const int y)
	{
		return setPlaceOK(x, y);
	}

	void business::update_car(net::Msg& m, Json::Value& r)
	{
		playerDataPtr player = player_mgr.getPlayer(m.playerID);
		if (!player)Return(r, err_illedge);
		r[strMsg][1u] = player->CarPos().currentX();
		r[strMsg][2u] = player->CarPos().currentY();
		Return(r, res_sucess);
	}

	void business::update_base(net::Msg& m, Json::Value& r)
	{
		playerDataPtr player = player_mgr.getPlayer(m.playerID);
		if (!player)Return(r, err_illedge);
		player->Biz()._auto_update();
	}
	void business::update_ware(net::Msg& m, Json::Value& r)
	{
		playerDataPtr player = player_mgr.getPlayer(m.playerID);
		if (!player)Return(r, err_illedge);
		player->BizTask()._auto_update();
	}
	void business::update_buff(net::Msg& m, Json::Value& r)
	{
		playerDataPtr player = player_mgr.getPlayer(m.playerID);
		if (!player)Return(r, err_illedge);
		player->BizBuff()._auto_update();
	}

	void business::update_move(net::Msg& m, Json::Value& r)
	{
		playerDataPtr player = player_mgr.getPlayer(m.playerID);
		if (!player)Return(r, err_illedge);
		if (player->LV() < systemUseLimit)Return(r, err_player_lv_too_low);
		if ((boost::get_system_time() - player->CarMoveCD).total_milliseconds() < 250)Return(r, err_car_move_too_fast);
		player->CarMoveCD = boost::get_system_time();
		ReadJsonArray;
		unsigned sucess_num = 0;
		//player->CarPos().stopMove();
		const int start_x = js_msg[0u][0u].asInt();
		const int start_y = js_msg[0u][1u].asInt();
		WSTAR::Pos start_pos = WSTAR::Pos(start_x, start_y);// player->CarPos().aimXY();
// 		if (!player->CarPos().canSetStartPos(start_pos))
// 		{
// 			r[strMsg][1u] = player->CarPos().currentX();
// 			r[strMsg][2u] = player->CarPos().currentY();
// 			r[strMsg][3u] = player->CarPos().aimX();
// 			r[strMsg][4u] = player->CarPos().aimY();
// 			Return(r, err_car_move_too_far);
// 		}
		std::vector<WSTAR::Pos> new_route;
		//for (unsigned i = 1; i < 6 && i < js_msg.size(); i++)
		for (unsigned i = 1; i < 2 && i < js_msg.size(); i++)
		{
			const int aim_x = js_msg[i][0u].asInt();
			const int aim_y = js_msg[i][1u].asInt();
			staticWStar.publicStart = start_pos;
			staticWStar.publicEnd = WSTAR::Pos(aim_x, aim_y);
			std::vector<WSTAR::Pos> vec = staticWStar.find();
			if (vec.empty())break;
			new_route.insert(new_route.end(), vec.begin(), vec.end());
			++sucess_num;
			start_pos.x = aim_x;
			start_pos.y = aim_y;
		}
		if (sucess_num > 0)
		{
			player->CarPos().newRoute(WSTAR::Pos(start_x, start_y), new_route);
		}
		if (sucess_num < 1)Return(r, err_car_move_forbidden);
		r[strMsg][0u] = res_sucess;
		r[strMsg][1u] = player->CarPos().currentX();
		r[strMsg][2u] = player->CarPos().currentY();
		r[strMsg][3u] = player->CarPos().aimX();
		r[strMsg][4u] = player->CarPos().aimY();
		player->sendToClient(gate_client::player_car_move_update_resp, r);
		r = Json::nullValue;
		player->CarPos().sendFuturePos();
	}

	void business::end_move(net::Msg& m, Json::Value& r)
	{
		playerDataPtr player = player_mgr.getPlayer(m.playerID);
		if (!player)Return(r, err_illedge);
		if (player->LV() < systemUseLimit)Return(r, err_player_lv_too_low);
		player->CarPos().stopMove();
		r[strMsg][1u] = player->CarPos().currentX();
		r[strMsg][2u] = player->CarPos().currentY();
		Return(r, res_sucess);
	}

	const static int taskBegin[3] = { 120000, 80000, 60000 };
	const static int taskEnd[3] = { 240000, 160000, 120000 };
	void business::accept_task(net::Msg& m, Json::Value& r)
	{
		playerDataPtr player = player_mgr.getPlayer(m.playerID);
		if (!player)Return(r, err_illedge);
		if (player->LV() < systemUseLimit)Return(r, err_player_lv_too_low);
		if (player->Info().Nation() == Kingdom::null)Return(r, err_illedge);
		if (player->BizTask().taskType() != TradeType::null)Return(r, err_illedge);
		if (player->BizTask().taskTimes() >= _VipBusinessTaskDaily[player->Info().VipLv()])Return(r, err_trade_task_over_times);
		const unsigned playerLV = player->LV();
		int bg_num = 0;
		int ed_num = 0;
		if (playerLV > 80) { bg_num = taskBegin[0]; ed_num = taskEnd[0]; }
		else if (playerLV > 60) { bg_num = taskBegin[1]; ed_num = taskEnd[1]; }
		else if (playerLV > 30) { bg_num = taskBegin[2]; ed_num = taskEnd[2]; }
		else Return(r, err_illedge);
		player->BizTask().acceptTask(bg_num, ed_num);
		Log(DBLOG::strLogBusiness, player, 0, bg_num, ed_num);
		Return(r, res_sucess);
	}

	void business::money_show(net::Msg& m, Json::Value& r)
	{
		playerDataPtr player = player_mgr.getPlayer(m.playerID);
		if (!player)Return(r, err_illedge);
		if (player->LV() < systemUseLimit)Return(r, err_player_lv_too_low);
		if (player->BizTask().taskType() == TradeType::null)Return(r, err_illedge);
		unsigned now = Common::gameTime();
		if (player->BusinessCD > now)Return(r, err_business_show_cd_limit);
		player->BusinessCD = now + 60;//60s
		Json::Value chatJson = Json::arrayValue;
		chatJson.append(chat_sys.ChatPackage(player));
		chatJson.append(player->BizTask().getMoney());
		chatJson.append(player->BizTask().getComplete());
		chat_sys.despatchAll(CHAT::server_business_money, chatJson);
		Return(r, res_sucess);
	}

	void business::sence_enter(net::Msg& m, Json::Value& r)
	{
		playerDataPtr player = player_mgr.getPlayer(m.playerID);
		if (!player)Return(r, err_illedge);

		_info_ptr info = getBRPlayer(player->ID());
		if (!info)
		{
			info = _info::Create(player);
		}
		else
		{
			if (info->state != car_enter)
			{
				info->state = car_enter;
				info->sendAround(player);
				if (false == info->been_post)
				{
					info->been_post = true;
					Timer::AddEventTickTime(boostBind(PlayerAreaUpdate, _1, info), Inter::event_trade_area_timer, info->updateCD);
				}
			}
		}
		Return(r, res_sucess);
	}

	void business::sence_exit(net::Msg& m, Json::Value& r)
	{
		playerDataPtr player = player_mgr.getPlayer(m.playerID);
		if (!player)Return(r, err_illedge);

		_info_ptr info = getBRPlayer(player->ID());
		if (info)
		{
			info->state = car_exit;
		}
		Return(r, res_sucess);
	}

	static bool _NeedFlushShark = true;
	void business::RefreshShark(const int x, const int y)
	{
		MapPoint& point = MapData[x][y];
		point._relateArea->sendAroudNewEvent();
		business_sys.saveSharkState();
		_NeedFlushShark = true;
	}

	void business::needSaveSharkState()
	{
		if (!_NeedFlushShark)
		{
			saveSharkState();
		}
	}

	void business::hit_shark_boss(net::Msg& m, Json::Value& r)
	{
		playerDataPtr player = player_mgr.getPlayer(m.playerID);
		if (!player)Return(r, err_illedge);
		if (player->LV() < systemUseLimit)Return(r, err_player_lv_too_low);
		if (player->Info().Nation() == Kingdom::null)Return(r, err_illedge);
		if (!_ActivityShark)Return(r, err_no_found_shark_boss);
		const unsigned now = Common::gameTime();
		if (player->Biz().hitBossCD() > now)Return(r, err_shark_boss_in_cd);
		player->CarPos().stopMove();
		const int x = player->CarPos().currentX();
		const int y = player->CarPos().currentY();
		ReadJsonArray;
		const int ax = js_msg[0u].asUInt();
		const int ay = js_msg[1u].asUInt();
		const MapEvnet::Type type = getMapEvent(ax, ay);
		if (type != MapEvnet::shark_boss)Return(r, err_no_found_shark_boss);
		if (std::abs(ax - x) > 3 || std::abs((ay - y) > 2))Return(r, err_illedge);
		sBattlePtr atk = BattleHelp::WarPlayer(player);
		BattleReport reportData;
		const O2ORes res = reportData.One2One(atk, _ActivityShark->_shark, typeBattle::trade_shark);
		reportData.addNotice(player->ID());
		const SharkBoss& sk = SharkBossList[SharkBossLevel];
		reportData.addReportdeclare("bg", sk.background);
		Json::Value me_json;
		unsigned total_me = BattleHelp::AddManExp(player, 0, me_json);
		reportData.addReportdeclare("me", me_json);
		Json::Value playerJson;
		playerJson.append(player->LV());
		playerJson.append(player->Info().EXP());
		playerJson.append(player->LV());
		playerJson.append(player->Info().EXP());
		playerJson.append(0);
		playerJson.append(player->Info().isMaxLevel());
		reportData.addReportdeclare("plv", playerJson);
		reportData.Done(typeBattle::trade_shark);
		r[strMsg][1u] = res.res;
		Json::Value& reward_json = r[strMsg][2u] = Json::objectValue;
		if (0 == _ActivityShark->_hitTime)
		{
			//�״ι���
			_ActivityShark->_hitTime = now;
			//�״ι����㲥
			qValue json(qJson::qj_array);
			json.append(chat_sys.ChatPackageQ(player));
			json.append(50);
			json.append(5);
			chat_sys.despatchAll(CHAT::server_business_shark_boss_first_hit, json);
			player->Res().alterTicket(50);//��50Ԫ��
			player->Items().addItem(ShunYiID, 5);
			reward_json["tk"] = 50;
			reward_json["sy"] = 5;
		}
		if (player->Biz().bossHitTimes() < 10)
		{
			player->Biz().hitBossTick();
			const int add_silver = player->LV() * 20 + 3000;
			player->Res().alterSilver(add_silver);
			reward_json["sil"] = add_silver;
		}
		if (_ActivityShark->_shark->isDeadAll())
		{
			MapPoint& point = MapData[ax][ay];
			point.setEvent(MapEvnet::shark_boss_chest);
			_ActivityShark->_boxTime = now + 10 * MINUTE > _ActivityShark->_createTick + HOUR ? _ActivityShark->_createTick + HOUR : now + 10 * MINUTE;
			Timer::AddEventTickTime(
				boostBind(clearSharkBox, _1, _ActivityShark),
				Inter::event_clear_shark_chest_timer,
				_ActivityShark->_boxTime
			);
			//�㲥
			chat_sys.despatchAll(CHAT::server_business_shark_boss_defeat,
				qValue(qJson::qj_array).This()
			);
			chat_sys.despatchAll(CHAT::server_business_shark_boss_player_defear,
				qValue(qJson::qj_array).
				append(chat_sys.ChatPackageQ(player)).
				append(50).
				append(5)
			);

			//β������
			player->Res().alterTicket(50);
			player->Items().addItem(ShunYiID, 5);
			reward_json["tk"] = 50;
			reward_json["sy"] = 5;

			point._relateArea->sendAroudNewEvent();

			unsigned offset = 0;
			bool is_not_plus = false;
			const unsigned pass_time = now - _ActivityShark->_hitTime;
			if (pass_time <= 3 * MINUTE)offset = 2;
			else if (pass_time <= 5 * MINUTE)offset = 1;
			else if (pass_time > 10 * MINUTE) { offset = -2; is_not_plus = true; }
			SharkBossLevel += offset;
			if (SharkBossLevel >= SharkBossList.size())SharkBossLevel = is_not_plus ? 0 : SharkBossList.size() - 1;
			saveSharkBoss();
			saveSharkState();//����֮�󱣴�һ��
		}
		else
		{
			const manList& checkMan = _ActivityShark->_shark->battleMan;
			_ActivityShark->_current_hp = 0;
			for (unsigned i = 0; i < checkMan.size(); i++)
			{
				_ActivityShark->_current_hp += checkMan[i]->currentHP;
			}
			if (_NeedFlushShark)
			{
				_NeedFlushShark = false;
				::Timer::AddEventSeconds(boostBind(business::RefreshShark, ax, ay), Inter::event_system_common_recall, 3);
			}
		}
		player->Biz().nextBossCD();
		TaskMgr::update(player, Task::BusinessBattleTimes, 1);
		Return(r, res_sucess);
	}

	void business::reward_shark_boss(net::Msg& m, Json::Value& r)
	{
		playerDataPtr player = player_mgr.getPlayer(m.playerID);
		if (!player)Return(r, err_illedge);
		if (player->LV() < systemUseLimit)Return(r, err_player_lv_too_low);
		if (player->Info().Nation() == Kingdom::null)Return(r, err_illedge);
		player->CarPos().stopMove();
		if (!_ActivityShark)Return(r, err_shark_chest_no_found);
		const int res = player->Biz().usefulBossBox(_ActivityShark->_createTick);
		if (res_sucess != res)Return(r, res);
		const int x = player->CarPos().currentX();
		const int y = player->CarPos().currentY();
		ReadJsonArray;
		const int ax = js_msg[0u].asUInt();
		const int ay = js_msg[1u].asUInt();
		const MapEvnet::Type type = getMapEvent(ax, ay);
		if (type != MapEvnet::shark_boss_chest)Return(r, err_shark_chest_no_found);
		if (std::abs(ax - x) > 3 || std::abs(ay - y) > 2)Return(r, err_illedge);
		actionDo(player, SharkBossList[SharkBossLevel].rewardList, 1);
		r[strMsg][1u] = actionRes();
		player->Biz().tickSharkBox(_ActivityShark->_createTick);
		Log(DBLOG::strLogBusiness, player, 8, player->Biz().bossBoxSize(), "", "", "", "", "", "", r[strMsg][1u].toIndentString());
		Return(r, res_sucess);
	}

	void business::route_data(net::Msg& m, Json::Value& r)
	{
		playerDataPtr player = player_mgr.getPlayer(m.playerID);
		if (!player)Return(r, err_illedge);
		if (player->LV() < systemUseLimit)Return(r, err_player_lv_too_low);
		//player->CarPos().sendRoute();
		player->CarPos().resetFuture();
		WSTAR::Pos pos = player->CarPos().currentXY();
		r[strMsg][0u] = res_sucess;
		r[strMsg][1u] = pos.x;
		r[strMsg][2u] = pos.y;
		r[strMsg][3u] = player->Biz().getSpeed();
		WSTAR::Pos aim = player->CarPos().aimXY();
		r[strMsg][4u] = aim.x;
		r[strMsg][5u] = aim.y;//����Ŀ�ĵ�
		player->sendToClient(gate_client::player_car_route_data_resp, r);
		r = Json::nullValue;
		player->CarPos().sendFuturePos();
	}

	void business::city_event(net::Msg& m, Json::Value& r)
	{
		playerDataPtr player = player_mgr.getPlayer(m.playerID);
		if (!player)Return(r, err_illedge);

		r[strMsg][1u] = jsCityEvent();
		Return(r, res_sucess);
	}

	void business::cancel_task(net::Msg& m, Json::Value& r)
	{
		playerDataPtr player = player_mgr.getPlayer(m.playerID);
		if (!player)Return(r, err_illedge);
		if (player->LV() < systemUseLimit)Return(r, err_player_lv_too_low);
		ReadJsonArray;
		const unsigned idx = js_msg[0u].asUInt();
		if (player->Info().Nation() == Kingdom::null)Return(r, err_illedge);
		if (player->BizTask().taskType() != TradeType::runing)Return(r, err_illedge);
		Log(DBLOG::strLogBusiness, player, 1, player->BizTask().getMoney(), player->BizTask().getComplete());
		player->BizTask().cancelTask();
		Return(r, res_sucess);
	}

	void business::complete_task(net::Msg& m, Json::Value& r)
	{
		playerDataPtr player = player_mgr.getPlayer(m.playerID);
		if (!player)Return(r, err_illedge);
		if (player->LV() < systemUseLimit)Return(r, err_player_lv_too_low);
		if (player->Info().Nation() == Kingdom::null)Return(r, err_illedge);
		if (player->BizTask().taskType() != TradeType::complete)Return(r, err_illedge);
		if (
			player->Items().isOver
			(
				player->Items().itemUsePos(CarMaterialID, 5)
			)
			)Return(r, err_bag_full);
		int am = player->BizTask().getMoney();
		int cm = player->BizTask().getMoney() - player->BizTask().getComplete();
		cm = cm < 0 ? 0 : cm;
		//1.8 * ��Ʊ��� / 4 + 18000 + ����������� * 10 %
		const int silver = int(1.8 * player->BizTask().getComplete() / 4 + 18000 + cm * 0.1);
		const int contribute = 900 + (int)player->LV() * 9;
		kingdom_sys.upgradeConstruction(player->Info().Nation(), Kingdom::CLevel, contribute);
		player->Res().alterSilver(silver);
		player->Res().alterContribution(contribute);
		player->Items().addItem(CarMaterialID, 5);
		player->BizTask().overTask();
		r[strMsg][1u] = silver;
		r[strMsg][2u] = contribute;
		r[strMsg][3u] = 5;
		r[strMsg][4u] = contribute;
		Log(DBLOG::strLogBusiness, player, 2, cm, silver, contribute, 5);
		{
			//�ճ�
			TaskMgr::update(player, Task::BusinessTimes, 1);
			TaskMgr::update(player, Task::BusinessAllTimes);
			TaskMgr::update(player, Task::BusinessTicketValueTimes, am);
			player->Daily().tickTask(DAILY::business_trade);
		}
		Return(r, res_sucess);
	}

	void business::complete_task_ok(net::Msg& m, Json::Value& r)
	{
		playerDataPtr player = player_mgr.getPlayer(m.playerID);
		if (!player)Return(r, err_illedge);
		if (player->Info().VipLv() < 3)Return(r, err_vip_lv_too_low);
		if (player->LV() < systemUseLimit)Return(r, err_player_lv_too_low);
		if (player->Info().Nation() == Kingdom::null)Return(r, err_illedge);
		if (player->BizTask().taskType() == TradeType::null
			&& player->BizTask().taskTimes() >= _VipBusinessTaskDaily[player->Info().VipLv()])Return(r, err_trade_task_over_times);
		if (player->Res().getCash() < 50)Return(r, err_cash_not_enough);
		if (player->BizTask().taskType() == TradeType::null)//û������ͽ�������
		{
			const unsigned playerLV = player->LV();
			if (playerLV > 80)player->BizTask().acceptTask(taskBegin[0], taskEnd[0]);
			else if (playerLV > 60)player->BizTask().acceptTask(taskBegin[1], taskEnd[1]);
			else if (playerLV > 30)player->BizTask().acceptTask(taskBegin[2], taskEnd[2]);
		}
		if (
			player->Items().isOver
			(
				player->Items().itemUsePos(CarMaterialID, 5)
			)
			)Return(r, err_bag_full);
		//1.8 * ��������Ʊ��� / 4 + 18000
		const int silver = int(1.8 * player->BizTask().getComplete() / 4 + 18000);
		const int contribute = 900 + (int)player->LV() * 9;
		kingdom_sys.upgradeConstruction(player->Info().Nation(), Kingdom::CLevel, contribute);
		player->Res().alterSilver(silver);
		player->Res().alterContribution(contribute);
		player->Items().addItem(CarMaterialID, 5);
		player->BizTask().overTask();
		player->Res().alterCash(-50);
		r[strMsg][1u] = silver;
		r[strMsg][2u] = contribute;
		r[strMsg][3u] = 5;
		r[strMsg][4u] = contribute;
		Log(DBLOG::strLogBusiness, player, 3, 0, silver, contribute, 5);
		{
			//�ճ�
			TaskMgr::update(player, Task::BusinessTimes, 1);
			TaskMgr::update(player, Task::BusinessAllTimes);
			player->Daily().tickTask(DAILY::business_trade);
		}
		Return(r, res_sucess);
	}

	void business::join_city(net::Msg& m, Json::Value& r)
	{
		playerDataPtr player = player_mgr.getPlayer(m.playerID);
		if (!player)Return(r, err_illedge);
		if (player->LV() < systemUseLimit)Return(r, err_player_lv_too_low);
		if (!player->CarPos().isNearlyAim())Return(r, err_car_is_moving);
		const unsigned x = player->CarPos().currentX();
		const unsigned y = player->CarPos().currentY();
		ReadJsonArray;
		const int cityID = js_msg[0u].asInt();
		if (!validCityRange(cityID, x, y))Return(r, err_illedge);
		Cities[cityID]->JoinPlayer.insert(player->ID());
	}

	void business::quit_city(net::Msg& m, Json::Value& r)
	{
		playerDataPtr player = player_mgr.getPlayer(m.playerID);
		if (!player)Return(r, err_illedge);
		if (player->LV() < systemUseLimit)Return(r, err_player_lv_too_low);
		if (!player->CarPos().isNearlyAim())Return(r, err_car_is_moving);
		const unsigned x = player->CarPos().currentX();
		const unsigned y = player->CarPos().currentY();
		ReadJsonArray;
		const int cityID = js_msg[0u].asInt();
		if (!validCityRange(cityID, x, y))Return(r, err_illedge);
		Cities[cityID]->JoinPlayer.erase(player->ID());
	}

	void business::update_city(net::Msg& m, Json::Value& r)
	{
		playerDataPtr player = player_mgr.getPlayer(m.playerID);
		if (!player)Return(r, err_illedge);
		if (player->LV() < systemUseLimit)Return(r, err_player_lv_too_low);
		if (!player->CarPos().isNearlyAim())Return(r, err_car_is_moving);
		const unsigned x = player->CarPos().currentX();
		const unsigned y = player->CarPos().currentY();
		ReadJsonArray;
		const int cityID = js_msg[0u].asInt();
		if (!validCityRange(cityID, x, y))Return(r, err_illedge);
		qValue data_json(qJson::qj_array);
		data_json.append(res_sucess)
			.append(cityID)
			.append(Cities[cityID]->toJson());
		player->sendToClientFillMsg(gate_client::player_trade_city_update_resp, data_json);
	}

	void business::buy_item(net::Msg& m, Json::Value& r)
	{
		playerDataPtr player = player_mgr.getPlayer(m.playerID);
		if (!player)Return(r, err_illedge);
		if (player->LV() < systemUseLimit)Return(r, err_player_lv_too_low);
		if (player->Info().Nation() == Kingdom::null)Return(r, err_illedge);
		if (player->BizTask().taskType() != TradeType::runing)Return(r, err_business_task_been_complete);
		if (!player->CarPos().isNearlyAim())Return(r, err_car_is_moving);
		const unsigned x = player->CarPos().currentX();
		const unsigned y = player->CarPos().currentY();
		ReadJsonArray;
		const int cityID = js_msg[0u].asInt();
		const int wareID = js_msg[1u].asInt();
		const unsigned wareNum = js_msg[2u].asUInt();
		const int warePrice = js_msg[3u].asInt();
		if (!validCityRange(cityID, x, y))Return(r, err_illedge);
		cityPtr city = Cities[cityID];
		CityData::warePtr ware = city->saleWare(wareID);
		if (!ware)Return(r, err_illedge);
		const unsigned buyNum = std::min(ware->leaveStock, wareNum);
		//û�п����
		if (buyNum < 1)
		{
			qValue data_json(qJson::qj_array);
			data_json.append(res_sucess)
				.append(cityID)
				.append(city->toJson());
			player->sendToClientFillMsg(gate_client::player_trade_city_update_resp, qValue(qJson::qj_object).addMember(strMsg, data_json));
			Return(r, err_business_ware_stock_not_enough);
		}
		if (ware->price != warePrice)
		{
			qValue data_json(qJson::qj_array);
			data_json.append(res_sucess)
				.append(cityID)
				.append(city->toJson());
			player->sendToClientFillMsg(gate_client::player_trade_city_update_resp, qValue(qJson::qj_object).addMember(strMsg, data_json));
			Return(r, err_refresh_trade_city);
		}
		const int need_money = ware->price * buyNum;
		if (player->BizTask().getMoney() < need_money)Return(r, err_trade_money_not_enough);
		if (player->BizTask().addWare(wareID, buyNum, warePrice) == res_sucess)
		{
			ware->leaveStock -= buyNum;//���ٿ��
			city->despatchPlayer();//��������
			player->BizTask().alterMoney(-need_money);
			r[strMsg][1u] = need_money;
			r[strMsg][2u] = wareNum;
			r[strMsg][3u] = buyNum;
			Return(r, res_sucess);
		}
		Return(r, err_trade_bag_full);
	}

	int CarDurable(const int rate)
	{
		if (rate < 100)
		{
			if (rate < 90)
			{
				if (rate < 80)
				{
					if (rate < 70)
					{
						if (rate < 60)
						{
							if (rate < 50)
							{
								if (rate < 40)
								{
									if (rate < 30)
									{
										if (rate < 20)
										{
											if (rate < 10)
											{
												return -20;
											}
											return -18;
										}
										return -16;
									}
									return -14;
								}
								return -12;
							}
							return -10;
						}
						return -8;
					}
					return -6;
				}
				return -4;
			}
			return -2;
		}
		return 0;
	}
	void business::sale_item(net::Msg& m, Json::Value& r)
	{
		playerDataPtr player = player_mgr.getPlayer(m.playerID);
		if (!player)Return(r, err_illedge);
		if (player->LV() < systemUseLimit)Return(r, err_player_lv_too_low);
		if (player->Info().Nation() == Kingdom::null)Return(r, err_illedge);
		if (player->BizTask().taskType() == TradeType::null)Return(r, err_illedge);
		if (!player->CarPos().isNearlyAim())Return(r, err_car_is_moving);
		const unsigned x = player->CarPos().currentX();
		const unsigned y = player->CarPos().currentY();
		ReadJsonArray;
		const int cityID = js_msg[0u].asInt();
		const int cityRate = js_msg[1u].asInt();
		const int wareID = js_msg[2u].asInt();
		const unsigned wareNum = js_msg[3u].asUInt();
		const int warePrice = js_msg[4u].asInt();
		if (!validCityRange(cityID, x, y))Return(r, err_illedge);
		cityPtr city = Cities[cityID];//��ֵ��֤����һ��
		const int rate = city->rateEffect();
		CityData::warePtr ware = city->pawnWare(wareID);
		if (!ware)Return(r, err_illedge);
		if (rate != cityRate || ware->price != warePrice)
		{
			qValue data_json(qJson::qj_array);
			data_json.append(res_sucess)
				.append(cityID)
				.append(city->toJson());
			player->sendToClientFillMsg(gate_client::player_trade_city_update_resp, qValue(qJson::qj_object).addMember(strMsg, data_json));
			Return(r, err_refresh_trade_city);
		}
		if (player->BizTask().checkWare(wareID, wareNum))
		{
			player->BizTask().removeWare(wareID, wareNum);
			int all_rate = 100 +
				CarDurable(player->Biz().getDurable()) +
				player->Biz().getSaleRate() +
				(
				((rate < 0 && player->BizBuff().checkBuff(TradeBuff::fangshui)) ? 0 : rate) +
					(player->BizBuff().checkBuff(TradeBuff::yijia) ? 10 : 0)
					) +
					(city->needID() == wareID ? 10 : 0)
				;
			const int reward = int(
				all_rate / 100.0 * warePrice * wareNum
				);
			player->BizTask().alterMoney(reward);
			city->addTrade(wareNum);
			r[strMsg][1u] = reward;
			Return(r, res_sucess);
		}
		Return(r, err_illedge);
	}

	void business::car_upgrade(net::Msg& m, Json::Value& r)
	{
		playerDataPtr player = player_mgr.getPlayer(m.playerID);
		if (!player)Return(r, err_illedge);
		if (player->LV() < systemUseLimit)Return(r, err_player_lv_too_low);
		if (!player->CarPos().isNearlyAim())Return(r, err_car_is_moving);
		ReadJsonArray;
		const int times = js_msg[0u].asUInt();
		if (times < 1 || times > 10)Return(r, err_illedge);
		if (player->Info().Nation() == Kingdom::null)Return(r, err_illedge);
		if (!player->Items().overItem(CarMaterialID, 1 * times))Return(r, err_item_not_enough);
		player->Items().removeItem(CarMaterialID, 1 * times);
		player->Biz().addExp(10 * times);
		r[strMsg][3u] = player->Biz().getExp();
		r[strMsg][2u] = player->Biz().getLevel();
		r[strMsg][1u] = 1000 * times;
		Log(DBLOG::strLogBusiness, player, 6, CarMaterialID, times, 10 * times);
		Return(r, res_sucess);
	}

	void business::item_use(net::Msg& m, Json::Value& r)
	{
		playerDataPtr player = player_mgr.getPlayer(m.playerID);
		if (!player)Return(r, err_illedge);
		if (player->LV() < systemUseLimit)Return(r, err_player_lv_too_low);
		if (player->Info().Nation() == Kingdom::null)Return(r, err_illedge);
		if (player->BizTask().taskType() == TradeType::null)Return(r, err_illedge);
		ReadJsonArray;
		const int itemID = js_msg[0u].asInt();
		if (!player->Items().overItem(itemID, 1))Return(r, err_item_not_enough);
		const TBstruct dataBuff = getBindBuff(itemID);
		if (dataBuff._id_buff == TradeBuff::null)Return(r, err_illedge);
		if (player->BizBuff().checkBuff(dataBuff._id_buff))Return(r, err_trade_buff_hold);
		player->BizBuff().insertBuff(dataBuff._id_buff, dataBuff._duration);
		player->Items().removeItem(itemID, 1);
		Log(DBLOG::strLogBusiness, player, 4, itemID, 1);
		r[strMsg][2u] = dataBuff._duration;
		r[strMsg][1u] = dataBuff._id_buff;
		Return(r, res_sucess);
	}

	void business::open_box(net::Msg& m, Json::Value& r)
	{
		playerDataPtr player = player_mgr.getPlayer(m.playerID);
		if (!player)Return(r, err_illedge);
		if (player->LV() < systemUseLimit)Return(r, err_player_lv_too_low);
		if (player->Info().Nation() == Kingdom::null)Return(r, err_illedge);
		player->CarPos().stopMove();
		const unsigned x = player->CarPos().currentX();
		const unsigned y = player->CarPos().currentY();
		ReadJsonArray;
		const unsigned ax = js_msg[0u].asUInt();
		const unsigned ay = js_msg[1u].asUInt();
		const MapEvnet::Type type = getMapEvent(ax, ay);
		if (!(type == MapEvnet::silver_box || type == MapEvnet::gold_box))Return(r, err_trade_box_not_found);
		if ((ax > x && ax - x > 3) || (ay > y && ay - y > 3) || (ax < x && x - ax > 3) || (ay < y && y - ay > 3))Return(r, err_illedge);
		const unsigned lv = player->LV();
		if (MapEvnet::silver_box == type)
		{
			if (!player->Items().overItem(SilverKeyID, 1))Return(r, err_item_not_enough);
			for (unsigned i = 0; i < SilverBox.size(); ++i)
			{
				if (lv > SilverBox[i].LevelLimit)
				{
					const int res = actionDo(player, SilverBox[i].BoxReward, 1, false);
					if (res != res_sucess)
					{
						r[strMsg][1u] = actionError();
						Return(r, res);
					}
					break;
				}
			}
			player->Items().removeItem(SilverKeyID, 1);
			Log(DBLOG::strLogBusiness, player, 4, SilverKeyID, 1);
		}
		if (MapEvnet::gold_box == type)
		{
			if (!player->Items().overItem(GoldKeyID, 1))Return(r, err_item_not_enough);
			for (unsigned i = 0; i < GoldBox.size(); ++i)
			{
				if (lv > GoldBox[i].LevelLimit)
				{
					const int res = actionDo(player, GoldBox[i].BoxReward, 1, false);
					if (res != res_sucess)
					{
						r[strMsg][1u] = actionError();
						Return(r, res);
					}
					break;
				}
			}
			player->Items().removeItem(GoldKeyID, 1);
			Log(DBLOG::strLogBusiness, player, 4, GoldKeyID, 1);
		}
		r[strMsg][1u] = actionRes();
		removeMapEvent(ax, ay);
		TaskMgr::update(player, Task::BusinessOpenBoxTimes, 1);
		Return(r, res_sucess);
	}

	sBattlePtr npcPirate(const Pirate& pir)
	{
		sBattlePtr sb = Creator<sideBattle>::Create();
		sb->playerID = -1;
		sb->playerName = pir.npcName;
		sb->isPlayer = false;
		sb->playerLevel = pir.npcLevel;
		sb->battleValue = pir.battleValue;
		sb->playerFace = pir.npcFace;
		manList& ml = sb->battleMan;
		ml.clear();
		const vector< Pirate::armyNPC >& npcList = pir.npcList;
		for (unsigned i = 0; i < npcList.size(); i++)
		{
			const Pirate::armyNPC& npc = npcList[i];
			mBattlePtr man = Creator<manBattle>::Create();
			man->manID = npc.npcID;
			man->holdMorale = npc.holdMorale;
			man->set_skill_1(npc.skill_1);
			man->set_skill_2(npc.skill_2);
			man->armsType = npc.armsType;
			man->manLevel = npc.npcLevel;
			man->currentIdx = npc.npcPos;
			man->battleValue = npc.battleValue;
			memcpy(man->armsModule, npc.armsModule, sizeof(man->armsModule));
			memcpy(man->initialAttri, npc.initAttri, sizeof(man->initialAttri));
			memcpy(man->battleAttri, npc.initAttri, sizeof(man->battleAttri));
			//memcpy(man->battleAttri, npc.addAttri, sizeof(man->battleAttri));
			man->currentHP = man->getTotalAttri(idx_hp);
			man->equipList = npc.equipList;
			ml.push_back(man);
		}
		return sb;
	}

	void business::challenge_pirate(net::Msg& m, Json::Value& r)
	{
		playerDataPtr player = player_mgr.getPlayer(m.playerID);
		if (!player)Return(r, err_illedge);
		if (player->LV() < systemUseLimit)Return(r, err_player_lv_too_low);
		if (player->Info().Nation() == Kingdom::null)Return(r, err_illedge);
		if (player->Biz().hitPirate() > 4)Return(r, err_trade_pirate_times_over);
		player->CarPos().stopMove();
		const unsigned x = player->CarPos().currentX();
		const unsigned y = player->CarPos().currentY();
		ReadJsonArray;
		const unsigned ax = js_msg[0u].asUInt();
		const unsigned ay = js_msg[1u].asUInt();
		const MapEvnet::Type type = getMapEvent(ax, ay);
		if (type != MapEvnet::haidao)Return(r, err_trade_haidao_not_found);
		if ((ax > x && ax - x > 2) || (ay > y && ay - y > 2) || (ax < x && x - ax > 2) || (ay < y && y - ay > 2))Return(r, err_illedge);
		const unsigned lv = player->LV();
		for (unsigned i = 0; i < PirateBox.size(); ++i)
		{
			const Pirate& pir = PirateBox[i];
			if (lv > pir.LevelLimit)
			{
				sBattlePtr atk = BattleHelp::WarPlayer(player);
				sBattlePtr def = npcPirate(pir);
				BattleReport reportData;
				const O2ORes res = reportData.One2One(atk, def, typeBattle::trade_pirate);
				reportData.addNotice(player->ID());
				reportData.addReportdeclare("bg", pir.background);
				if (resBattle::atk_win == res.res)
				{
					removeMapEvent(ax, ay);
				}
				Json::Value me_json;
				unsigned total_me = BattleHelp::AddManExp(player, 0, me_json);
				reportData.addReportdeclare("me", me_json);
				Json::Value res_json = Json::arrayValue;
				if (resBattle::atk_win == res.res)
				{
					player->Biz().tickPirate();
					actionDo(player, pir.rewardList, 1);
					res_json = actionRes();
				}
				reportData.addReportdeclare("wb", res_json);
				Json::Value playerJson;
				playerJson.append(player->LV());
				playerJson.append(player->Info().EXP());
				playerJson.append(player->LV());
				playerJson.append(player->Info().EXP());
				playerJson.append(0);
				playerJson.append(player->Info().isMaxLevel());
				reportData.addReportdeclare("plv", playerJson);
				reportData.Done(typeBattle::trade_pirate);
				r[strMsg][1u] = res.res;
				if (res.res == resBattle::atk_win)
					TaskMgr::update(player, Task::BusinessWinTimes, 1);
				Return(r, res_sucess);
			}
		}
		Return(r, err_illedge);
	}

	void business::car_teleport(net::Msg& m, Json::Value& r)
	{
		playerDataPtr player = player_mgr.getPlayer(m.playerID);
		if (!player)Return(r, err_illedge);
		if (player->LV() < systemUseLimit)Return(r, err_player_lv_too_low);
		if (player->Info().Nation() == Kingdom::null)Return(r, err_illedge);
		if (!player->Items().overItem(ShunYiID, 1))Return(r, err_item_not_enough);
		ReadJsonArray;
		const unsigned x = js_msg[0u].asUInt();
		const unsigned y = js_msg[1u].asUInt();
		if (availablePlace(x, y))
		{
			player->Items().removeItem(ShunYiID, 1);
			player->CarPos().setPos(x, y);
			r[strMsg][1u] = player->CarPos().currentX();
			r[strMsg][2u] = player->CarPos().currentY();
			Log(DBLOG::strLogBusiness, player, 4, ShunYiID, 1);
			Return(r, res_sucess);
		}
		Return(r, err_illedge);
	}
	void business::car_repair(net::Msg& m, Json::Value& r)
	{
		playerDataPtr player = player_mgr.getPlayer(m.playerID);
		if (!player)Return(r, err_illedge);
		if (player->LV() < systemUseLimit)Return(r, err_player_lv_too_low);
		if (player->Info().Nation() == Kingdom::null)Return(r, err_illedge);
		const int cost_silver = player->Biz().getDurableLimit() * 100;
		if (cost_silver == 0)Return(r, err_illedge);
		if (cost_silver > player->Res().getSilver())Return(r, err_silver_not_enough);
		player->Res().alterSilver(-cost_silver);
		player->Biz().fullDurable();
		r[strMsg][1u] = cost_silver;
		Log(DBLOG::strLogBusiness, player, 7, cost_silver, player->Res().getSilver());
		Return(r, res_sucess);
	}

	void business::newDayTick()
	{
		ForEach(cityMap, it, Cities)
		{
			cityPtr city = it->second;
			city->perDayTick();
		}
	}

	void business::updateMoveCar(playerDataPtr player)
	{
		_info_ptr info = getBRPlayer(player->ID());
		if (!info) {
			info = _info::Create(player);
		}
		info->state = car_enter;
		playerCarPos& Car = player->CarPos();
		info->aim_x = Car.aimX();
		info->aim_y = Car.aimY();
		playerBusiness& Trade = player->Biz();
		info->speed = Trade.getSpeed();
		info->level = Trade.getLevel();
		//�����µ�λ��
		info->setNewPos(player, Car.currentX(), Car.currentY());
	}


	//�ݴ�
	unsigned business::getBorrowID()
	{
		return _BorrowTimeID;
	}
	void business::borrowWithBoat(const structTimer& timerData)
	{
		_BorrowTimeID += (4 * DAY);
		db_mgr.SaveMongo(DBN::dbBorrowWithBoat, BSON("key" << 1), BSON("key" << 1 << "time" << _BorrowTimeID));
		playerManager::playerDataVec vec = player_mgr.allOnline();
		for (unsigned i = 0; i < vec.size(); ++i)
		{
			playerDataPtr player = vec[i];
			player->Borrow().rawCheckRes();
		}
	}

	//�ݴ�
	void business::borrowing_update(net::Msg& m, Json::Value& r)
	{
		playerDataPtr player = player_mgr.getPlayer(m.playerID);
		if (!player)Return(r, err_illedge);
		if (player->LV() < systemUseLimit)Return(r, err_player_lv_too_low);
		player->Borrow()._auto_update();
	}
	void business::borrowing(net::Msg& m, Json::Value& r)
	{
		playerDataPtr player = player_mgr.getPlayer(m.playerID);
		if (!player)Return(r, err_illedge);
		if (player->LV() < systemUseLimit)Return(r, err_player_lv_too_low);
		if (season_sys.getSeason() != SEASON::Summer)Return(r, err_illedge);
		if (!player->Borrow().allowBorrow())Return(r, err_illedge);
		const int max_battle_value = player->Info().MaxBV();
		sBattlePtr npc;
		for (unsigned i = 0; i < _BorrowBossList.size(); ++i)
		{
			const BorrowBoss& boss = _BorrowBossList[i];
			if (max_battle_value >= boss.battleValueLimit)
			{
				npc = npcBorrow(boss);
				break;
			}
		}
		if (!npc)Return(r, err_illedge);
		sBattlePtr atk = BattleHelp::WarPlayer(player);
		BattleLog::SignTotalLog log(0,8);
		BattleReport reportData;
		const O2ORes res = reportData.One2One(atk, npc, typeBattle::borrow_with_boat, &log);
		reportData.addNotice(player->ID());
		unsigned deadT = 0;
		ForEach(manList, it, atk->useManList)
		{
			const mBattlePtr m = *it;
			if (m->isDead()) ++deadT;
		}
		const int battle_res = 5 - ((atk->useManList.size() == deadT) ? 4 : deadT);
		reportData.addReportdeclare("brlt", battle_res);
		const int arrows = log.get_collect_damage() / 500;
		player->Borrow().alterArrows(arrows);
		player->Borrow().alterBorrow(1);
		player->Borrow().newBorrowArrows(arrows);
		r[strMsg][1u] = arrows;
		Return(r, res_sucess);
	}
	void business::buy_borrow(net::Msg& m, Json::Value& r)
	{
		playerDataPtr player = player_mgr.getPlayer(m.playerID);
		if (!player)Return(r, err_illedge);
		if (player->LV() < systemUseLimit)Return(r, err_player_lv_too_low);
		if (season_sys.getSeason() != SEASON::Summer)Return(r, err_illedge);
		Return(r, player->Borrow().buyBorrow());
	}
	void business::exchange_borrow(net::Msg& m, Json::Value& r)
	{
		playerDataPtr player = player_mgr.getPlayer(m.playerID);
		if (!player)Return(r, err_illedge);
		if (player->LV() < systemUseLimit)Return(r, err_player_lv_too_low);
		if (season_sys.getSeason() != SEASON::Summer)Return(r, err_illedge);
		ReadJsonArray;
		const unsigned id = js_msg[0u].asUInt();
		const int times = js_msg[1u].asInt();
		if (times < 1 || times > 99)Return(r, err_illedge);
		if (id >= _ArrowsExchangeShop.size())Return(r, err_illedge);
		const BorrowRWData& data = _ArrowsExchangeShop[id];
		if (player->Borrow().getArrows() < (times * data._value))Return(r, err_borrowing_arrows_not_enough);
		const ActionBoxList& box = data._box;
		ActionRateMap rate_for_exch;
		for (unsigned i = 0; i < box.size(); ++i)
		{
			rate_for_exch[box[i].actionID] = ACTION::Rate(times);
		}
		if (res_sucess == actionDoBox(player, box, false))
		{
			player->Borrow().alterArrows(-(times * data._value));
			r[strMsg][1u] = actionRes();
			Return(r, res_sucess);
		}
		r[strMsg][1u] = actionError();
		Return(r, err_action_do_failed);
	}
	void business::step_borrow(net::Msg& m, Json::Value& r)
	{
		playerDataPtr player = player_mgr.getPlayer(m.playerID);
		if (!player)Return(r, err_illedge);
		if (player->LV() < systemUseLimit)Return(r, err_player_lv_too_low);
		ReadJsonArray;
		const unsigned step = js_msg[0u].asUInt();
		if (step >= _BorrowStepRW.size())Return(r, err_illedge);
		if ((player->Borrow().borrowStep() & (0x1 << step)) != 0x0)Return(r, err_illedge);
		if (res_sucess == actionDoBox(player, _BorrowStepRW[step]._box, false))
		{
			player->Borrow().setBorrowStep(step);
			r[strMsg][1u] = actionRes();
			Return(r, res_sucess);
		}
		r[strMsg][1u] = actionError();
		Return(r, err_action_do_failed);
	}
}

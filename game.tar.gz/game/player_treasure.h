#pragma once

#include "auto_base.h"
#include "man_def.h"

namespace gg
{
	class TreasureConf;
	BOOSTSHAREPTR(TreasureConf, TreasureConfPtr);
	class Talent;
	BOOSTSHAREPTR(Talent, TalentPtr);

	class playerTreasure
		: public _auto_player
	{
		public:
			playerTreasure(playerData* const own, int id);
			playerTreasure(playerData* const own, const mongo::BSONObj& obj);

			int id() const;
			int skillID();
			const int* attri();
			const double* attriRate();
			int extraBV();
			
			void getInfo(qValue& q) const;
			std::vector<int> getTalentList();
			void getGMInfo(Json::Value& info);

			int upgrade(int type);
			int activeTalent(int type, int id);
			int initFromMan(int man_id, int tid1, int tid2);
			int wear(int man_id);
			int unload(int man_id);
			void clear(int man_id);
			void modifyLv(int lv);

		private:
			virtual bool _auto_save();
			virtual void _auto_update();
			void recalAttri();
			int recalSkillID();
			void switchTalent();
			TalentPtr getCorrectTalent(int id);
			void tickManAttri();
			int talentEnabled(TalentPtr ptr);

		private:
			int _lv;
			int _wear_man;
			TalentPtr _talent1;
			TalentPtr _talent2;
			TreasureConfPtr _conf;

			bool _attri_valid;
			int _attri[characterNum];
			double _attri_rates[characterNum];
			int _extra_bv;
			int _skill_id;
	};

	BOOSTSHAREPTR(playerTreasure, TreasurePtr);

	class playerTreasureMgr
		: public _auto_player
	{
		STDMAP(int, TreasurePtr, TreasureMap);
		public:
			playerTreasureMgr(playerData* const own);

			void update();

			int upgrade(int id, int type);
			int activeTalent(int id, int type, int talent_id);
			int wear(int id, int man_id);
			int unload(int id, int man_id);

			void getGMInfo(Json::Value& info);
			int modifyLv(int id, int lv);

			TreasurePtr getTreasure(int id) const
			{
				TreasureMap::const_iterator it = _treasure_map.find(id);
				return it == _treasure_map.end()? TreasurePtr() : it->second;
			}

		private:
			virtual void classLoad();

		private:
			TreasureMap _treasure_map;
	};
}

#pragma once

#include <client/dbclient.h>
#include <json/json.h>
#include <boost/thread/mutex.hpp>
#include <vector>

#define db_mgr (*gg::db_manager::dbMgr)

namespace gg
{	
	typedef std::vector<mongo::BSONObj> objCollection;
	class db_manager
	{
	public:
		static db_manager* const dbMgr;
		db_manager(void);
		~db_manager(void);
		typedef boost::function<void(mongo::BSONObj&)> AnyFunction;

		bool			InitialMongo(const std::string uri_str);
		
		void			EnsureIndex(const std::string &collection, const mongo::BSONObj& key);
		unsigned		Count(const std::string& db_name_str, const mongo::BSONObj& key);
		bool			SetMongoMulti(const std::string& db_name_str, const mongo::BSONObj& key, const mongo::BSONObj& val);//upsert false multi true
		bool			SetMongo(const std::string& db_name_str, const mongo::BSONObj& key, const mongo::BSONObj& val);//upsert false
		bool			SaveMongoMulti(const std::string& db_name_str, const mongo::BSONObj& key, const mongo::BSONObj& val);//upsert true multi true
		bool			SaveMongo(const std::string& db_name_str, const mongo::BSONObj& key, const mongo::BSONObj& val);//upsert true
		void			InsertMongo(const std::string& db_name_str, const objCollection& objs);
		mongo::BSONObj	FindOne(
			const std::string& db_name_str,
			const mongo::Query custom = mongo::Query(),
			const mongo::BSONObj* fields = NULL
		);
		objCollection	Query(
			const std::string& db_name_str, 
			const mongo::Query custom = mongo::Query(), 
			const int limit_num = 0, 
			const mongo::BSONObj* fields = NULL
		);
		void			RemoveCollection(const std::string &collection, const mongo::BSONObj key = mongo::BSONObj());//ɾ������
		bool			DropTable(const std::string& table_name);//ɾ����

	private:
		std::string		convert_server_db_name(const std::string& db_str);
		void checkConnect();
		mongo::DBClientBase* _DB_Pointer;
		mongo::ConnectionString conn_str;
	};
}
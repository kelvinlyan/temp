#include "player_common_offline.h"
#include "dbDriver.h"

const static string strPreciseOffline = "pfl";
const static string strStandardOffline = "sfl";
const static string strPreciseOnline = "pnl";
const static string strStandardOnline = "snl";
const static string strLastStandardOnline = "lsnl";
const static string strPreciseDay = "pd";
const static string strStandardDay = "sd";
const static string strPreciseTime = "pt";
const static string strStandardTime = "st";
const static string strSetFlag = "sf";

namespace gg
{

	playerCommonOffline::playerCommonOffline(playerData* const own)
		:_auto_player(own),
		_precise_offline(1),
		_precise_online(1),
		_standard_offline(1),
		_standard_online(1),
		_last_standard_online(1),
		_standard_day(0),
		_precise_day(0),
		_standard_time(0),
		_precise_time(0),
		_set_flag(0)
	{
	}

	void playerCommonOffline::setOffline(const unsigned& offline)
	{
		if (_set_flag != 0 || offline < 1)
		{
			return;
		}
		_precise_offline = offline;
		_standard_offline = Common::getNextTimeHMS(offline, 5);
		if (_standard_online > _standard_offline)
		{
			_standard_day = (_standard_online - _standard_offline) / DAY;
			_standard_time = _standard_online - _standard_offline;
		}
		_precise_day = (_precise_online - _precise_offline) / DAY;
		_precise_time = _precise_online - _precise_offline;

		_set_flag = 1;
		_auto_save();
	}

	void playerCommonOffline::online()
	{
		_precise_online = Common::gameTime();
		_last_standard_online = _standard_online;
		_standard_online = Common::getNextTime(5) - DAY;
		if (_standard_offline == 1 || _precise_offline == 1)
		{
			_standard_day = 0;
			_precise_day = 0;
			_standard_time = 0;
			_precise_time = 0;
			_sign_auto();
			return;
		}

		if (_standard_online > _standard_offline)
		{
			_standard_day = (_standard_online - _standard_offline) / DAY;
			_standard_time = _standard_online - _standard_offline;
		}
		else
		{
			_standard_day = 0;
			_standard_time = 0;
		}
		_precise_day = (_precise_online - _precise_offline) / DAY;
		_precise_time = _precise_online - _precise_offline;
		_sign_auto();
	}

	void playerCommonOffline::offline()
	{
		_precise_offline = Common::gameTime();
		_standard_offline = Common::getNextTime(5);
		_sign_auto();
	}

	int playerCommonOffline::getStandardDay()
	{
		//LogS << "off_line\tstandard_day:" << _standard_day << LogEnd;
		return _standard_day;
	}

	int playerCommonOffline::getPreciseDay()
	{
		return _precise_day;
	}

	unsigned playerCommonOffline::getStandardLastLoginTime()
	{
		return _last_standard_online;
	}

	unsigned playerCommonOffline::getStandardTime()
	{
		return _standard_time;
	}

	unsigned playerCommonOffline::getPreciseTime()
	{
		return _precise_time;
	}

	void playerCommonOffline::setData(mongo::BSONObj& obj)
	{
		if (!obj.isEmpty())
		{
			_precise_offline = obj[strPreciseOffline].Int();
			_standard_offline = obj[strStandardOffline].Int();
			_precise_online = obj[strPreciseOnline].Int();
			_standard_online = obj[strStandardOnline].Int();
			_precise_day = obj[strPreciseDay].Int();
			_standard_day = obj[strStandardDay].Int();
			_precise_time = obj[strPreciseTime].Int();
			_standard_time = obj[strStandardTime].Int();
			_set_flag = obj[strSetFlag].Int();
			if (!obj[strLastStandardOnline].eoo())
			{
				_last_standard_online = obj[strLastStandardOnline].Int();
			}
		}
	}

	bool playerCommonOffline::_auto_save()
	{
		mongo::BSONObj key = BSON(strPlayerID << Own().ID());

		mongo::BSONObj obj = BSON("$set" << BSON("CommonOffline" <<
			BSON(strPreciseOffline << _precise_offline
			<< strStandardOffline << _standard_offline
			<< strPreciseOnline << _precise_online
			<< strStandardOnline << _standard_online
			<< strPreciseDay << _precise_day
			<< strStandardDay << _standard_day
			<< strPreciseTime << _precise_time
			<< strStandardTime << _standard_time
			<< strLastStandardOnline << _last_standard_online
			<< strSetFlag << _set_flag
		)));

		return db_mgr.SaveMongo(DBN::dbPlayerCollection, key, obj);
	}


	playerCommonOffline::~playerCommonOffline()
	{
		
	}

}

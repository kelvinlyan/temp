//###################################
//create by Jim
//2015-11-04
//###################################

#pragma once

#include "dbDriver.h"

#define gamer (*gg::Gamer::_Instance)

namespace gg
{
	class Gamer
	{
	public:
		std::string randomName();
		std::string randomBoyName();
		std::string randomGirlName();
	public:
		static Gamer* const _Instance;
		void initData();
		DeclareRegFunction(AccountLogin);
		DeclareRegFunction(Login);
		DeclareRegFunction(CreateRole);
		DeclareRegFunction(motifyProcess);
		DeclareRegFunction(motifyName);
		DeclareRegFunction(motifyFace);
		DeclareRegFunction(SharePathRep);
		DeclareRegFunction(LinkLogin);
		DeclareRegFunction(LinkLogout);
		DeclareRegFunction(GateReset);
		DeclareRegFunction(TestAnnouce);
		DeclareRegFunction(GamerTable);
		DeclareRegFunction(OnlineBoxUpdate);
		DeclareRegFunction(OnlineBoxGet);
		DeclareRegFunction(logProcess);
		DeclareRegFunction(GMPushAnnouce);
		DeclareRegFunction(DailyCardUpdate);
		DeclareRegFunction(DailyCardBuy);
		DeclareRegFunction(DailyCardAward);
		DeclareRegFunction(OfflineReward);
		DeclareRegFunction(LoginDayBox);
		DeclareRegFunction(SupplyGet);
		DeclareRegFunction(GameShareOK);//�����ɹ��ص�
		DeclareRegFunction(ShareShopBuy);//���������̵�
	public:
		void sendSwitchData(playerDataPtr player);
		DeclareRegFunction(SwitchUpdate);//�Զ��忪�����ݻ�ȡ
		DeclareRegFunction(SwitchMotify);//�Զ��忪�������޸�
	private:
		void onPlayerLoginReq(playerDataPtr player);
		bool _custom_switch;
		std::string _custtom_data;
		void saveSwitch();
	};
}

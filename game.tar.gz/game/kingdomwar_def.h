#pragma once

#include <string>
#include "commom.h"

namespace gg
{
	namespace KingdomWar
	{
		enum
		{
			// param
			ArmyNum = 3,
			ArmyMaxHp = 100,

			// position type
			PosEmpty = -1,
			PosCity,
			PosPath,

			// state
			Closed = 0,
			Opened,
			AttackerWait,
			DefenderWait,
			StartWait,
			Protected,

			// prime state
			OrdinaryTime = 0,
			PrimeTime,

			// prime time
			PrimeOpenHour1 = 12,
			PrimeOpenMin1 = 30,
			PrimeOpenTime1 = PrimeOpenHour1 * HOUR + PrimeOpenMin1 * MINUTE,
			
			PrimeCloseHour1 = 13,
			PrimeCloseMin1 = 0,
			PrimeCloseTime1 = PrimeCloseHour1 * HOUR + PrimeCloseMin1 * MINUTE,

			PrimeOpenHour2 = 20,
			PrimeOpenMin2 = 0,
			PrimeOpenTime2 = PrimeOpenHour2 * HOUR + PrimeOpenMin2 * MINUTE,
			
			PrimeCloseHour2 = 20,
			PrimeCloseMin2 = 30,
			PrimeCloseTime2 = PrimeCloseHour2 * HOUR + PrimeCloseMin2 * MINUTE,

			// side
			Left = 0,
			Right,
			MaxSide,

			// item type
			Player = 0,
			Npc,
			ActiveNpc,
			Shadow,
			ShadowNpc,
			ShadowAdvanceNpc,
			ShadowDefenseNpc, 
			ForeignNpc,

			// battle result
			Win = 0,
			Lose,
		};
	
		// shadow type
		namespace SHADOW
		{
			enum
			{
				NPC = 0,
				PLAYER,
				ADVANCED_NPC,
				DEFENSE_NPC,
				TYPEMAX
			};
		}

		// turn back reason
		namespace TIPS
		{
			enum
			{
				NONE = 0,       
				HPEMPTY,
				DEFEATED,    
				SIEGEFAILED,
				UNITY,
				ELECATTACK,
				CITYPROTECTED,
				TRANSFER,
				RETREAT,
			};
		}

		// rep type
		namespace REP
		{
			enum
			{
				BATTLE = 0,
				ELECATTACK,
			};
		}

		const static std::string strNpcID = "ni";
	}
}

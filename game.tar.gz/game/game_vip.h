//###################################
//create by Jim
//2016-3-14
//###################################

#pragma once

#include "auto_do.h"

namespace gg
{
	class playerVip :
		public _auto_player
	{
	public:
		playerVip(playerData* const own) :_auto_player(own)
		{
			tick5C = Common::getNextTime(5);
		}
		void loadDB();
		virtual void _auto_update();
		virtual bool _auto_save();
	private:

	};
}
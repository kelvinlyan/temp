//###################################
//create by Jim
//2015-11-04
//###################################

#pragma once
#include <boost/thread/mutex.hpp>
#include <boost/thread/recursive_mutex.hpp>
#include <boost/shared_ptr.hpp>
#include <boost/enable_shared_from_this.hpp>
#include "commom.h"
#include "channel.h"
#include "quickjson.h"

//@�������ͷ�ļ�
#include "gamer_data.h"
#include "gamer_tick.h"
#include "player_man.h"
#include "gamer_resource.h"
#include "player_mapwar.h"
#include "player_task.h"
#include "war_formation.h"
#include "player_card.h"
#include "player_item.h"
#include "player_search.h"
#include "gamer_face.h"
#include "pokedex.h"
#include "playerCount.h"
#include "player_trade.h"
#include "player_kingfight.h"
#include "player_kingdom.h"
#include "player_rescue.h"
#include "player_team.h"
#include "player_vip.h"
#include "player_worldboss.h"
#include "player_research.h"
#include "player_market.h"
#include "player_orders.h"
#include "player_mall.h"
#include "player_warlords.h"
#include "player_email.h"
#include "player_daily.h"
#include "player_build_team.h"
#include "player_feod.h"
#include "player_admin.h"
#include "gamer_offline.h"
#include "gamer_custom.h"
#include "player_days_activity.h"
#include "gamer_online_box.h"
#include "player_affair.h"
#include "player_sign.h"
#include "player_money.h"
#include "gamer_daily_card.h"
#include "player_fund.h"
#include "player_kingdomwar.h"
#include "player_kingdomwar_shop.h"
#include "player_kingdomwar_output.h"
#include "player_kingdomwar_fm.h"
#include "player_kingdomwar_pos.h"
#include "player_kingdomwar_box.h"
#include "player_kingdomwar_task.h"
#include "player_patrol.h"
#include "player_open_activity.h"
#include "player_shops.h"
#include "player_daily_inpour.h"
#include "player_expedition.h"
#include "player_expedition_fm.h"
#include "player_recharge.h"
#include "player_secondary_compensation.h"
#include "player_festival.h"
#include "player_activity_rank.h"
#include "player_red_paper.h"
#include "lose_formation.h"
#include "player_enemy.h"
#include "player_common_offline.h"
#include "player_old_player.h"
#include "inter_war_formation.h"
#include "player_military.h"
#include "inter_title.h"
#include "player_mystery_area.h"
#include "player_treasure.h"
#include "player_kingdomwar_tips.h"
#include "player_imperial_exam.h"
#include "player_island_activity.h"
//@�������ͷ�ļ�

namespace gg
{
	const static string strPlayerID = "pi";

#define PlayerDataInitial(TYPENAME, NICKNAME) \
protected:\
	boost::shared_ptr<TYPENAME> _##NICKNAME;\
	boost::shared_ptr<TYPENAME> ptr_##NICKNAME(){\
		_##NICKNAME->toFull();\
		if(!isOnline()){_##NICKNAME->classRefresh();}\
		return _##NICKNAME;\
	}\
public:\
	inline TYPENAME& NICKNAME(){return *ptr_##NICKNAME();}\


	class playerData :
		public boost::enable_shared_from_this<playerData>
	{
		friend class playerManager;
	public:
		inline playerDataPtr getOwnDataPtr(){
			return shared_from_this();
		}
		bool isVaild();
//		inline int Net(){ return netID; }
		inline bool isOnline()
		{
			return Online;
		}
		void sendToClient(const short protocol, Json::Value& msg);
		void sendToClient(const short protocol, qValue& msg);
		void sendToClientFillMsg(const short protocol, qValue& msg);
		void sendToClient(const short protocol, string& msg);
		void sendToClientFillMsg(const short protocol, string& msg);
		void Logout();
		void Login();
//		bool outLine();
		inline int ID(){ return Info().ID(); }
		inline string Name(){ return Info().Name(); }
		inline unsigned LV(){ return Info().LV(); }
		inline bool motifyName(const string name){ return Info().motifyName(name); }

		//////////////////////////////////////////////////////////////////////////
		PlayerDataInitial(playerBase, Info);
		PlayerDataInitial(playerTick, Tick);
		PlayerDataInitial(playerManMgr, Man);
		PlayerDataInitial(playerResource, Res);
		PlayerDataInitial(playerMapWarMgr, War);//
		PlayerDataInitial(playerTask, Task);//
		PlayerDataInitial(playerWarFM, WarFM);
		PlayerDataInitial(playerCardMgr, Card);
		PlayerDataInitial(playerCardTs, CardTs);
		PlayerDataInitial(playerItemMgr, Items);
		PlayerDataInitial(playerSearch, Sch);
		PlayerDataInitial(playerFace, Face);
		PlayerDataInitial(playerPoke, Poke);
		PlayerDataInitial(playerCount, Count);
		PlayerDataInitial(playerCarPos, CarPos);
		PlayerDataInitial(playerBusiness, Biz);
		PlayerDataInitial(playerBusinessTask, BizTask);
		PlayerDataInitial(playerBusinessBuff, BizBuff);
		PlayerDataInitial(playerKingFight, KingFight);//
		PlayerDataInitial(playerKingdom, KingDom);//
		PlayerDataInitial(playerRescue, RescueData);
		PlayerDataInitial(playerTeam, Team);//
		PlayerDataInitial(playerVipMgr, Vip);//
		PlayerDataInitial(playerWorldBoss, WorldBoss);//
		PlayerDataInitial(playerWarLords, WarLords);//
		PlayerDataInitial(playerResearch, Research);
		PlayerDataInitial(playerMarket, Market);
		PlayerDataInitial(playerOrders, Orders);
		PlayerDataInitial(playerMall, Malls);
		PlayerDataInitial(playerEmail, Email);
		PlayerDataInitial(playerDaily, Daily);
		PlayerDataInitial(playerBuildTeam, BuildTeam);
		PlayerDataInitial(playerBuilds, Builds);
		PlayerDataInitial(playerAdmin, Admin);
		PlayerDataInitial(playerOffline, Offline);
		PlayerDataInitial(playerCustom, Custom);
		PlayerDataInitial(playerDaysActivity, DaysActivity);
		PlayerDataInitial(playerOnlineBox, OnlineBox);
		PlayerDataInitial(playerAffair, Affair);
		PlayerDataInitial(playerSign, Sign);
		PlayerDataInitial(playerMoneyActivity, MoneyActivity);
		PlayerDataInitial(playerDailyCard, DailyCard);
		PlayerDataInitial(playerFund, Fund);
		PlayerDataInitial(playerKingdomWar, KingDomWar);
		PlayerDataInitial(playerKingdomWarShop, KingDomWarShop);
		PlayerDataInitial(playerKingdomWarOutput, KingDomWarOutput);
		PlayerDataInitial(playerKingdomWarFM, KingDomWarFM);
		PlayerDataInitial(playerKingdomWarPos, KingDomWarPos);
		PlayerDataInitial(playerKingdomWarBox, KingDomWarBox);
		PlayerDataInitial(playerKingdomWarTask, KingDomWarTask);
		PlayerDataInitial(playerPatrol1, Patrol);
		PlayerDataInitial(playerOpenActivity, OpenActivity);
		PlayerDataInitial(playerShops, Shops);
		PlayerDataInitial(playerDailyInpour, DailyInpour);
		PlayerDataInitial(playerExpedition, Expedition);
		PlayerDataInitial(playerShadow, Shadow);
		PlayerDataInitial(playerExpeditionFM, ExpeditionFM);
		PlayerDataInitial(playerRecharge, RechargeLog);
		PlayerDataInitial(playerSecondaryCompensation, SecondaryCompensation);
		PlayerDataInitial(playerFestival, Festival);
		PlayerDataInitial(playerActivityRank, ActivityRank);
		PlayerDataInitial(playerRedPaper, RedPaper);
		PlayerDataInitial(playerLoseFM, LoseFM);
		PlayerDataInitial(playerEnemy, Enemy);
		PlayerDataInitial(playerCommonOffline, CommonOffline);
		PlayerDataInitial(playerOldPlayer, OldPlayer);
		PlayerDataInitial(interWarFM, InterFM);
		PlayerDataInitial(playerMilitary, Military);
		PlayerDataInitial(playerInterTitle, InterTitle);
		PlayerDataInitial(playerMysteryArea, MysteryArea);
		PlayerDataInitial(playerTreasureMgr, Treasure);
		PlayerDataInitial(playerKingdomWarTips, KingDomWarTips);
		PlayerDataInitial(playerImperialExam, ImperialExam);
		PlayerDataInitial(playerBoatBorrow, Borrow);
		PlayerDataInitial(playerIslandActivity, IslandActivity);

		//////////////////////////////////////////////////////////////////////////
		//memory
		unsigned Chat[CHAT::user_channel];
		unsigned TeamCD;
		unsigned BusinessCD;
		unsigned EquipShowCD;
		unsigned ShareLastCD;
		unsigned TeamAnnCD;
		unsigned ExchangeEquipCD;
		unsigned ShareInterCD;
		boost::system_time CarMoveCD;
		//end
		//public method
		void onBVAlter();//�����ս���ı��ʱ��
	protected:
		void clearData();
		bool Dirty;
		bool Online;
		void initial();
		void onLogin();//��ҵ�½��ʱ��
		void onOFFLine();//�������
		void onCreateRole();//��Ҵ�����ɫ��ʱ��
	public:
		playerData(const int pID);
		playerData(const string pName);
		~playerData();
		static playerDataPtr Create(const int playerID)
		{
			return Creator<playerData>::Create(playerID);
		}
		static playerDataPtr Create(const string playerName)
		{
			return Creator<playerData>::Create(playerName);
		}
	};
}

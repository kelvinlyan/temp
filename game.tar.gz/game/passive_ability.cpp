#include "passive_ability.h"

namespace gg
{
	//���ݳ�ʼ��
	typedef boost::function< void(passiveData&, Json::Value&) > formatF;
	typedef boost::unordered_map<int, formatF> formatPassiveMap;
	static formatPassiveMap _formatPassiveMap;

	static void formatMP_1(passiveData& data, Json::Value& json)
	{
		data._passiveMP._value = json["value"].asInt();
	}

	//����
	static void formatData(passiveData& data, Json::Value& json)
	{
		interfaceIDResolve<passiveData> resolve(data);
		((passiveBase*)&resolve._data)->_passive_id =
			PASSIVE::Combine2PassiveID(json["tick"].asInt(), json["event"].asInt());
		_formatPassiveMap[resolve.event_id()](data, json);
	}


	static passiveData NullPassiveData;
	passiveManager* const passiveManager::_Instance = new passiveManager();

	template<int type>
	static bool PassiveCommonCombine(passiveData& main, passiveData& branch)
	{
		typedef passiveResolve<type> _ThisType;
		_ThisType main_resolve(main), branch_resolve(branch);
		return main_resolve.combine_passive(branch_resolve);
	}

	void passiveManager::initData()
	{
		//��ʼ��������
		_formatPassiveMap[PASSIVE::_passive_event_add_power] = boost::bind(&formatMP_1, _1, _2);

		//�ϲ�������
		mapCombine[PASSIVE::_passive_event_add_power] = boost::bind(&PassiveCommonCombine<0>, _1, _2);

		//�����ļ���ȡ
		memset(&NullPassiveData, 0x0, sizeof(LenPassiveData));
		passiveBase* base = (passiveBase*)&NullPassiveData;
		base->_passive_id = -1;

		cout << "load ./instance/passive/" << endl;
		FileJsonSeq seq = Common::loadFileJsonFromDir("./instance/passive/");
		mapPassive.clear();
		for (unsigned i = 0; i < seq.size(); ++i)
		{
			Json::Value& json = seq[i];
			passiveData data;
			formatData(data, json);
			interfaceIDResolve<const passiveData> resolve(data);
			if (resolve.vaild_data())
			{
				mapPassive[json["id"].asInt()] = data;
			}
		}
	}

	bool passiveManager::combinePassive(passiveData& main, passiveData& branch)
	{
		interfaceIDResolve<passiveData> main_resolve(main), branch_resolve(branch);
		if (!main_resolve.vaild_data() || !branch_resolve.vaild_data())return false;//����Ч����
		return mapCombine[main_resolve.event_id()](main, branch);
	}

	const passiveData& passiveManager::getPassive(const int ID)
	{
		passiveMap::const_iterator it = mapPassive.find(ID);
		if (it == mapPassive.end())return NullPassiveData;
		return it->second;
	}

}
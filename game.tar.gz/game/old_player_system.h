#pragma once

/*
* ����һع�ϵͳ
* Created by Lin Xing
* 2017.2.6
*/

#include "dbDriver.h"
#include "commom.h"
#include "utility_lx.h"

#define old_player_sys (*gg::old_player_system::_Instance)

namespace gg
{

	namespace old_player
	{
		typedef struct _package_unit
		{
			int m;
			ActionBoxList box;
			std::string strBox;
			Json::Value jsonBox;
			Json::Value rawBox;
			void load()
			{
				jsonBox = lx::utility_lx::parseJson(rawBox);
				strBox = lx::utility_lx::parseJsonBox(rawBox);
				box = actionFormatBox(rawBox);
			}
		} UnitBox;

		typedef struct _activity
		{
			int id;
			unsigned stime;
			unsigned etime;
			unsigned lv;
			unsigned off_day;
			std::vector<UnitBox> backs;
			std::vector<UnitBox> recharge;
		} Activity;

		STDMAP(int, Activity, ActivityList);
	}

	class old_player_system
	{
	public:
		old_player_system();

		void rechargeHelper(playerDataPtr player, int gold);

		DeclareRegFunction(reqOldPlayerInfo);
		DeclareRegFunction(reqOldPlayerGetReward);
		DeclareRegFunction(reqRedPoint);//��������Ĵ���
		//GM
		DeclareRegFunction(reqGMOldPlyerIdList);
		DeclareRegFunction(reqGMOldPlyerInfo);
		DeclareRegFunction(reqGMOldPlyerModify);

		void loadData();
		static void ActivityOver(const structTimer& timerData);

	public:
		static old_player_system* const _Instance;

	private:
		void select();//ѡ���µĻ�ʹ�����ĸı�
		bool saveActi(const old_player::Activity& acti);
		void delActi(int id);

	private:
		old_player::ActivityList _activities;
		old_player::Activity _curr;


		~old_player_system();
	};

}


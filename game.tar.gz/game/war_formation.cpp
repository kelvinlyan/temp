#include "war_formation.h"
#include "playerManager.h"
#include "lose_formation.h"

namespace gg
{
	static FMCONFIG FMConfig;
	static FMCFG NullConfig;

	const FMCFG& playerWarFM::getConfig(const int FMID)//������ʹ��
	{
		if (FMID < 0 || FMID >= (int)FMConfig.size())return NullConfig;
		return FMConfig[FMID];
	}

	static void CommonFormation(playerDataPtr player, const int fmID, int* attri)
	{
		const FMCFG& config = playerWarFM::getConfig(fmID);
		player->Research().getForAttr(config.techID, attri);
	}

	static void LoseFormation(playerDataPtr player, const int fmID, int* attri)
	{
		const int* la = player->LoseFM().lose_attribute();
		for (unsigned i = 0; i < characterNum; ++i)
		{
			attri[i] += la[i];
		}
	}

	typedef std::map<int, boost::function<void(playerDataPtr, const int, int*)> > GetFunctionMap;
	static GetFunctionMap staticGetFunctionMap;

	static int CommonFormationBV(playerDataPtr player, const int num, const int fmID)
	{
		const FMCFG& config = playerWarFM::getConfig(fmID);
		const int scLV = player->Research().getForLV(config.techID);
		return (scLV * 7 * num);
	}
	
	static int LoseFormationBV(playerDataPtr player, const int num, const int fmID)
	{
		return player->LoseFM().battle_value() * num;
	}

	//������� �Ƽ�ID
	typedef std::map<int, boost::function<int(playerDataPtr, const int)> > BattleValueFunctionMap;
	static BattleValueFunctionMap staticBattleValueFunctionMap;

	void playerWarFM::FormationAttribute(playerDataPtr player, const int fmID, int* attri)
	{
		if (fmID < 0 || fmID > 11)return;
		staticGetFunctionMap[fmID](player, fmID, attri);
	}

	int playerWarFM::FormationBV(playerDataPtr player, const int fmID, const unsigned num)
	{
		if (fmID < 0 || fmID > 11)return 0;
		return staticBattleValueFunctionMap[fmID](player, num);
	}

	void playerSGFM::initData()
	{
		{//�����
			FMConfig.clear();
			FMConfig.resize(12);
			cout << "load ./instance/formation/" << endl;
			FileJsonSeq seq = Common::loadFileJsonFromDir("./instance/formation/");
			for (unsigned i = 0; i < seq.size(); ++i)
			{
				Json::Value& json = seq[i];
				unsigned fmID = json["fmID"].asUInt();
				FMCFG& config = FMConfig[fmID];
				config.techID = json["techID"].asInt();
				config.HOLES.resize(9);
				for (unsigned n = 0; n < json["fm"].size() && n < 9; ++n)
				{
					Json::Value& holeJson = json["fm"][n];
					unsigned hID = holeJson["hole"].asUInt();
					config.HOLES[hID].LV = holeJson["lv"].asUInt();
					config.HOLES[hID].Process = holeJson["process"].asInt();
					config.HOLES[hID].Use = true;
				}
			}
		};

		{//��ȡ���Է�ʽ��
			staticGetFunctionMap.clear();
			staticGetFunctionMap[0] = boostBind(CommonFormation, _1, _2, _3);
			staticGetFunctionMap[1] = boostBind(CommonFormation, _1, _2, _3);
			staticGetFunctionMap[2] = boostBind(CommonFormation, _1, _2, _3);
			staticGetFunctionMap[3] = boostBind(CommonFormation, _1, _2, _3);
			staticGetFunctionMap[4] = boostBind(CommonFormation, _1, _2, _3);
			staticGetFunctionMap[5] = boostBind(CommonFormation, _1, _2, _3);
			staticGetFunctionMap[6] = boostBind(CommonFormation, _1, _2, _3);
			staticGetFunctionMap[7] = boostBind(CommonFormation, _1, _2, _3);
			staticGetFunctionMap[8] = boostBind(LoseFormation, _1, _2, _3);
			staticGetFunctionMap[9] = boostBind(CommonFormation, _1, _2, _3);
			staticGetFunctionMap[10] = boostBind(CommonFormation, _1, _2, _3);
			staticGetFunctionMap[11] = boostBind(CommonFormation, _1, _2, _3);
		};

		{//��ȡ���Է�ʽ��
			staticBattleValueFunctionMap.clear();
			staticBattleValueFunctionMap[0] = boostBind(CommonFormationBV, _1, _2, 0);
			staticBattleValueFunctionMap[1] = boostBind(CommonFormationBV, _1, _2, 1);
			staticBattleValueFunctionMap[2] = boostBind(CommonFormationBV, _1, _2, 2);
			staticBattleValueFunctionMap[3] = boostBind(CommonFormationBV, _1, _2, 3);
			staticBattleValueFunctionMap[4] = boostBind(CommonFormationBV, _1, _2, 4);
			staticBattleValueFunctionMap[5] = boostBind(CommonFormationBV, _1, _2, 5);
			staticBattleValueFunctionMap[6] = boostBind(CommonFormationBV, _1, _2, 6);
			staticBattleValueFunctionMap[7] = boostBind(CommonFormationBV, _1, _2, 7);
			staticBattleValueFunctionMap[8] = boostBind(LoseFormationBV, _1, _2, 8);
			staticBattleValueFunctionMap[9] = boostBind(CommonFormationBV, _1, _2, 9);
			staticBattleValueFunctionMap[10] = boostBind(CommonFormationBV, _1, _2, 10);
			staticBattleValueFunctionMap[11] = boostBind(CommonFormationBV, _1, _2, 11);
		};

		//�Ϲ�����
		playerLoseFM::initData();
	}

	playerSGFM::playerSGFM(const unsigned ID, playerData* const own) : _auto_player(own), fmID(ID)
	{
		FMPower = 0;
		isNew = true;
	}

	void playerSGFM::tryToFormat(const vector<playerManPtr>& vec)
	{
		const FMCFG::HOLEVEC& config = FMConfig[fmID].HOLES;
		unsigned idx = 0;
		for (unsigned i = 0; i < 9 && idx < vec.size(); ++i)
		{
			if (!config[i].Use)continue;
			if (Own().LV() < config[i].LV)continue;
			if (config[i].Process > 0 && !Own().War().isChallengeMap(config[i].Process))continue;
			FMList[i] = vec[idx];
			++idx;
		}
		if (idx > 0)
		{
			isNew = false;
			recalFM(true);
		}
		_sign_auto();//�Զ����ºͱ���
	}

	int playerSGFM::format(const int fm[9])
	{
		int res = rawFormat(fm);
		if (res == res_sucess)
		{
			recalFM();
			_sign_auto(); 
		}
		return res;
	}

	void playerSGFM::recalFM(const bool initial /* = false */)
	{
		int tmp_val = FMPower;
		FMPower = 0;
		unsigned num = 0;
		for (unsigned i = 0; i < 9; ++i)
		{
			playerManPtr man = FMList[i];
			if (!man)continue;
			++num;
			FMPower += man->battleValue();
		}
		if (fmID >= 0 && fmID < 12)
		{
			FMPower += staticBattleValueFunctionMap[fmID](Own().getOwnDataPtr(), num);
		}
		//���Խ��//��ô10��
		const static int MaxValue = 1000000000;//10��
		if (FMPower < 0 || FMPower > MaxValue)FMPower = MaxValue;

		if (tmp_val != FMPower)
		{
			if (!initial)
			{
				_sign_update();
				const unsigned currentFMID = Own().WarFM().currentID();
				if (currentFMID == fmID)
				{
					Own().onBVAlter();
				}
			}
		}
	}

	int playerSGFM::rawFormat(const int fm[9])
	{
		const FMCFG::HOLEVEC& config = FMConfig[fmID].HOLES;
		boost::unordered_set<int> SAMEMAN;
		playerManPtr tmpList[9];//�����б�
		unsigned fomat_num = 0;
		for (unsigned i = 0; i < 9; ++i)
		{
			if (fm[i] < 0)continue;
			if (!config[i].Use)continue;
			if (Own().LV() < config[i].LV)return err_format_hole_limit;
			if (config[i].Process > 0 && !Own().War().isChallengeMap(config[i].Process))return err_format_hole_limit;
			playerManPtr man = Own().Man().findArmyByMan(fm[i]);//�Ƿ����㿪������
			if (man && SAMEMAN.insert(man->uniqueID()).second == false)continue;
			tmpList[i] = man;
			if (man && ++fomat_num >= 5)break;
		}
		for (unsigned i = 0; i < 9; ++i)
		{
			FMList[i] = tmpList[i];
		}
		isNew = false;
		return res_sucess;
	}

	mongo::BSONArray playerSGFM::toBsonArr()
	{
		mongo::BSONArrayBuilder arr;
		for (unsigned i = 0; i < 9; ++i)
		{
			arr << (FMList[i] ? FMList[i]->uniqueID() : -1);
		}
		return arr.arr();
	}

	std::vector<playerManPtr> playerSGFM::toInvaildFormat()
	{
		std::vector<playerManPtr> list;
		for (unsigned i = 0; i < 9; ++i)
		{
			playerManPtr m = FMList[i];
			if (!m)continue;
			list.push_back(m);
		}
		return list;
	}

	std::vector<playerManPtr> playerSGFM::toFormat()
	{
		std::vector<playerManPtr> list;
		for (unsigned i = 0; i < 9; ++i)
		{
			list.push_back(FMList[i]);
		}
		return list;
	}

	bool playerSGFM::isEmpty()
	{
		for (unsigned i = 0; i < 9; ++i)
		{
			if(FMList[i])return false;
		}
		return true;
	}

	qValue playerSGFM::toJson()
	{
		qValue json(qJson::qj_object);
		json.addMember("id", fmID);
		json.addMember("bv", FMPower);
		qValue m_json(qJson::qj_array);
		for (unsigned i = 0; i < 9; ++i)
		{
			m_json.append(FMList[i] ? FMList[i]->armyID() : -1);
		}
		json.addMember("m", m_json);
		return json;
	}

	bool playerSGFM::_on_sign_update()
	{
		Own().WarFM().tickFM(fmID);
		return false;
	}

	void playerSGFM::rawInitial(const bool in, vector<mongo::BSONElement>& vec)
	{
		isNew = in;
		unsigned num = 0;
		for (unsigned i = 0; i < vec.size() && i < 9; ++i)
		{
			playerManPtr m = Own().Man().findArmy(vec[i].Int());
			if (m)++num;
			FMList[i] = m;
		}
		if (num > 0)isNew = false;
	}

	bool playerSGFM::_auto_save()
	{
		mongo::BSONObj key = BSON(strPlayerID << Own().ID() << "fid" << fmID);
		mongo::BSONObj obj = BSON(strPlayerID << Own().ID() << "fid" << fmID << 
			"arr" << toBsonArr() << "in" << isNew);
		return db_mgr.SaveMongo(DBN::dbPlayerWarFM, key, obj);
	}

	//mgr
	playerWarFM::playerWarFM(playerData* const own) : _auto_player(own)
	{
		fmList.clear();
		for (unsigned i = 0; i < 12; ++i)
		{
			playerFMPtr dataPtr = Creator<playerSGFM>::Create(i, own);
			fmList.push_back(dataPtr);
		}
		currentFMID = 0;
	}

	int playerWarFM::format(const unsigned fmID, const int fm[9])
	{
		if (fmID > fmList.size())return err_format_not_find;
		currentFMID = fmID;
		_sign_auto();
		const int res = fmList[fmID]->format(fm);
		qValue log_val = fmList[currentFMID]->toJson();
		Log(DBLOG::strLogFormation, Own().getOwnDataPtr(), -1, currentFMID, "","","","","","", log_val.toIndentString());
		return res;
	}

	void playerWarFM::_auto_update()
	{
		qValue json(qJson::qj_array);
		json.append(res_sucess).append(currentFMID);
		qValue fmJson(qJson::qj_array);
		for (UINTSET::iterator it = updateList_.begin();it != updateList_.end(); ++it)
		{
			const unsigned idx = *it;
			if (idx >= fmList.size())continue;
			fmJson.append(fmList[idx]->toJson());
		}
		json.append(fmJson);
		updateList_.clear();
		Own().sendToClientFillMsg(gate_client::war_format_update_resp, json);
	}

	bool playerWarFM::_auto_save()
	{
		mongo::BSONObj key = BSON(strPlayerID << Own().ID());
		mongo::BSONObj obj = BSON(strPlayerID << Own().ID() << "cid" << currentFMID);
		return db_mgr.SaveMongo(DBN::dbPlayerWarFMBase, key, obj);
	}

	int playerWarFM::defaultFM(const unsigned fmID)
	{
		if (fmID >= fmList.size())return err_format_not_find;
		const unsigned oldFMID = currentFMID;//�ϵ�ID
		currentFMID = fmID;
		if (fmList[currentFMID]->isNewFM() && oldFMID != currentFMID)
		{
			std::vector<playerManPtr> vec = fmList[oldFMID]->toInvaildFormat();
			fmList[currentFMID]->tryToFormat(vec);
		}
		_sign_auto();
		Own().onBVAlter();
		qValue log_val = fmList[currentFMID]->toJson();
		Log(DBLOG::strLogFormation, Own().getOwnDataPtr(), -1, currentFMID, "", "", "", "", "", "", log_val.toIndentString());
		return res_sucess;
	}

	void playerWarFM::classLoad()
	{
		mongo::BSONObj key = BSON(strPlayerID << Own().ID());
		mongo::BSONObj baseObj = db_mgr.FindOne(DBN::dbPlayerWarFMBase, key);
		if (!baseObj.isEmpty())
		{
			currentFMID = (unsigned)baseObj["cid"].Int();
		}
		objCollection collection = db_mgr.Query(DBN::dbPlayerWarFM, key);
		if (collection.empty())return;
		for (unsigned i = 0; i < collection.size(); ++i)
		{
			mongo::BSONObj& obj = collection[i];
			unsigned fmID = (unsigned)obj["fid"].Int();
			bool isNew = obj["in"].eoo() ? true : obj["in"].Bool();
			if (fmID >= fmList.size())continue;
			std::vector<mongo::BSONElement> elems = obj["arr"].Array();
			fmList[fmID]->rawInitial(isNew ,elems);
		}
	}

	void playerWarFM::classFinal()
	{
		for (unsigned i = 0; i < fmList.size(); ++i)
		{
			fmList[i]->recalFM(true);
		}
	}

	void playerWarFM::updateAll()
	{
		qValue json(qJson::qj_array);
		json.append(res_sucess).append(currentFMID);
		qValue fmJson(qJson::qj_array);
		for (unsigned i = 0; i < fmList.size(); ++i)
		{
			fmJson.append(fmList[i]->toJson());
		}
		json.append(fmJson);
		Own().sendToClientFillMsg(gate_client::war_format_update_resp, json);
	}

	void playerWarFM::updateSingle(const unsigned fmID)
	{
		qValue json(qJson::qj_array);
		if (fmID > fmList.size())
		{
			json.append(err_format_not_find);
			Own().sendToClientFillMsg(gate_client::war_format_update_single_resp, json);
			return;
		}
		json.append(res_sucess);
		json.append(fmList[fmID]->toJson());
		Own().sendToClientFillMsg(gate_client::war_format_update_single_resp, json);
		return;
	}

	void playerWarFM::recalFMValue(const int fmID, const bool update /* = true */)
	{
		if (fmID >= fmList.size())return;
		fmList[fmID]->recalFM(false);
		if (update)_sign_update();
	}

	void playerWarFM::recalFMValue(const bool update /* = true */)
	{
		for (unsigned i = 0; i < fmList.size(); ++i)
		{
			if (fmList[i])fmList[i]->recalFM(false);
		}
		if(update)_sign_update();
	}

	int playerWarFM::currentBV()
	{
		return fmList[currentFMID]->getBV();
	}

	std::vector<playerManPtr> playerWarFM::currentFM()
	{
		return fmList[currentFMID]->toFormat();
	}

	std::vector<playerManPtr> playerWarFM::appointFM(const unsigned FMID)
	{
		if (FMID >= fmList.size())return std::vector<playerManPtr>();
		return fmList[FMID]->toFormat();
	}

	std::vector<playerManPtr> playerWarFM::currentInvaildFM()
	{
		return fmList[currentFMID]->toInvaildFormat();
	}

	std::vector<playerManPtr> playerWarFM::appointInvaildFM(const unsigned FMID)
	{
		if (FMID >= fmList.size())return std::vector<playerManPtr>();
		return fmList[FMID]->toInvaildFormat();
	}

	void playerWarFM::tickFM(const unsigned FMID)
	{
		updateList_.insert(FMID);
		_sign_update();
	}

	bool playerWarFM::currentEmpty()
	{
		return appointEmpty(currentFMID);
	}

	bool playerWarFM::appointEmpty(const unsigned FMID)
	{
		if (FMID >= fmList.size())return true;
		return fmList[FMID]->isEmpty();
	}

	int CalNoEqBV(playerDataPtr d, const ManList& ml, int fm_id)
	{
		int power = 0;
		unsigned num = 0;
		ForEachC(ManList, it, ml)
		{
			const playerManPtr& man = *it;
			if (!man)continue;
			++num;
			power += man->noeqBattleValue();
		}
		if (fm_id >= 0 && fm_id < 12)
		{
			power += staticBattleValueFunctionMap[fm_id](d, num);
		}
		//���Խ��//��ô10��
		const static int MaxValue = 1000000000;//10��
		if (power < 0 || power > MaxValue)
			power = MaxValue;
		return power;
	}

	int CalBV(playerDataPtr d, const ManList& ml, int fm_id)
	{
		int power = 0;
		unsigned num = 0;
		ForEachC(ManList, it, ml)
		{
			const playerManPtr& man = *it;
			if (!man)continue;
			++num;
			power += man->battleValue();
		}
		if (fm_id >= 0 && fm_id < 12)
		{
			power += staticBattleValueFunctionMap[fm_id](d, num);
		}
		//���Խ��//��ô10��
		const static int MaxValue = 1000000000;//10��
		if (power < 0 || power > MaxValue)
			power = MaxValue;
		return power;
	}
}

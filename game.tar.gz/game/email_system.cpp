#include "email_system.h"

namespace gg
{
	email_system* const email_system::_Instance = new email_system();

	void email_system::initData()
	{
		classLoad();
	}
	
	void email_system::playerInfoReq(net::Msg& m, Json::Value& r)
	{
		playerDataPtr d = player_mgr.getPlayer(m.playerID);
		if (!d) Return(r, err_illedge);

		r[strMsg][1u] = d->Email().getEmailList();
		Return(r, res_sucess);
	}

	void email_system::sendEmailReq(net::Msg& m, Json::Value& r)
	{
		playerDataPtr d = player_mgr.getPlayer(m.playerID);
		if (!d) Return(r, err_illedge);
		if (d->LV() < 45) Return(r, err_lv_not_enough);
		ReadJsonArray;
		const std::string& name = js_msg[0u].asString();
		const std::string& data = js_msg[1u].asString();
		
		playerDataPtr target = player_mgr.getPlayer(name);
		if (!target) Return(r, err_email_name_not_found);

		EmailPtr e = createGamer(d, data);
		target->Email().addEmail(e);
		Return(r, res_sucess);
	}

	void email_system::getPackageReq(net::Msg& m, Json::Value& r)
	{
		playerDataPtr d = player_mgr.getPlayer(m.playerID);
		if (!d) Return(r, err_illedge);
		ReadJsonArray;
		int res = res_sucess;
		r[strMsg][1u] = Json::arrayValue;
		r[strMsg][2u] = Json::arrayValue;
		ForEach(Json::Value, it, js_msg)
		{
			int id = (*it).asInt();
			Json::Value rw;
			res = d->Email().getPackage(id, rw);
			if (res == res_sucess)
			{
				r[strMsg][1u].append(id);
				combineActionRes(rw, r[strMsg][2u]);
			}
		}
		if (r[strMsg][1u].size() == 0)
			Return(r, res)
		else
			Return(r, res_sucess)
	}

	void email_system::redPointReq(net::Msg& m, Json::Value& r)
	{
		playerDataPtr d = player_mgr.getPlayer(m.playerID);
		if (!d) Return(r, err_illedge);
		
		d->Email().updateRedPoint();
	}

	void email_system::gmEmailInfoReq(net::Msg& m, Json::Value& r)
	{
		ReadJsonArray;
		int pid = js_msg[0u].asInt();
		int begin = js_msg[1u].asInt() * 20;
		
		if (pid == -1)
		{
			Json::Value& ref = r[strMsg][1u];
			ref["n"] = 0;
			int pos = 0;
			int end = begin + 20;
			ForEach(ServerID2Email, itc, _common_emails)
			{
				EmailData& emd = itc->second;
				ref["n"] = ref["n"].asUInt() + (unsigned)emd.common_emails.size();
				for (CommonEmailMap::const_reverse_iterator it = emd.common_emails.rbegin();
						it != emd.common_emails.rend(); ++it)
				{
					if (pos++ < begin)
						continue;
					if (begin++ > end)
						break;
					Json::Value info = it->second->getEmail()->toJson();
					info["svr"] = itc->first;
					ref["l"].append(info);
				}
			}
		}
		else
		{
			playerDataPtr d = player_mgr.getPlayer(pid);
			if (!d) Return(r, err_illedge);

			r[strMsg][1u] = d->Email().getEmailList(begin, 20);
		}
		Return(r, res_sucess);
	}

	void email_system::gmRemoveEmailReq(net::Msg& m, Json::Value& r)
	{
		ReadJsonArray;
		int pid = js_msg[0u].asInt();
		int eid = js_msg[1u].asInt();
		int res;
		if (pid == -1)
		{
			int svr_id = js_msg[2u].asInt();
			res = removeCommonEmail(svr_id, eid);
		}
		else
		{
			playerDataPtr d = player_mgr.getPlayer(pid);
			if (!d) Return(r, err_illedge);
			res = d->Email().removeEmail(eid);
		}
		Return(r, res);
	}

	void email_system::gmSendEmailReq(net::Msg& m, Json::Value& r)
	{
		ReadJsonArray;
		Json::Value& data = js_msg[0u];
		int type = data["ty"].asInt();
		if (type < 0 || type > 3)
			Return(r, err_illedge);
		const std::string& str = data["m"].asString();
		Json::Value param;
		param.append(str);
		EmailPtr e;
		if (data["rw"] != Json::nullValue && data["rw"].size() != 0)
		{
			Json::Value& rw = data["rw"];
			ForEach(Json::Value, it, rw)
			{
				Json::Value& act = (*it)["act"];
				act = jsonFormats2c(act);
			}
			e = createGmPackage(EmailDef::GmEmail, param, rw);
		}
		else
		{
			e = createSystem(EmailDef::GmEmail, param);
		}
		if (type == 0)
		{
			const Json::Value& pid_v = data["arg"];
			if (pid_v.size() == 1)
			{
				int pid = pid_v[0u].asInt();
				sendToPlayer(pid, e);
			}
			else
			{
				std::vector<int> pids;
				ForEachC(Json::Value, it, pid_v)
					pids.push_back((*it).asInt());
				sendToPart(pids, e);
			}
		}
		else if (type == 1)
		{
			int nation = data["arg"][0u].asInt();
			const Json::Value& svr = data["svr"];
			if (svr.size() == 1 && svr[0u].asInt() == -1)
				sendToKingdom(nation, e);
			else
			{
				std::vector<int> server_ids;
				ForEachC(Json::Value, it, svr)
					server_ids.push_back((*it).asInt());
				sendToKingdom(server_ids, nation, e);
			}
		}
		else if (type == 2)
		{
			const Json::Value& svr = data["svr"];
			if (svr.size() == 1 && svr[0u].asInt() == -1)
				sendToAll(e);
			else
			{
				std::vector<int> server_ids;
				ForEachC(Json::Value, it, svr)
					server_ids.push_back((*it).asInt());
				sendToAll(server_ids, e);
			}
		}
		else
		{
			const Json::Value& ch = data["arg"][0u];
			std::vector<std::string> channels;
			ForEachC(Json::Value, it, ch)
				channels.push_back((*it).asString());
			unsigned over_time = data["arg"][1u].asUInt() + Common::timeZone() * HOUR;
			const Json::Value& svr = data["svr"];
			if (svr.size() == 1 && svr[0u].asInt() == -1)
				sendToChannel(channels, over_time, e);
			else
			{
				std::vector<int> server_ids;
				ForEachC(Json::Value, it, svr)
					server_ids.push_back((*it).asInt());
				sendToChannel(server_ids, channels, over_time, e);
			}
		}

		Return(r, res_sucess);
	}

	int email_system::removeCommonEmail(int server_id, int id)
	{
		ServerID2Email::iterator ite = _common_emails.find(server_id);
		if (ite == _common_emails.end())
			return err_email_id_not_found;
		CommonEmailMap& common_emails = ite->second.common_emails;
		CommonEmailMap::iterator it = common_emails.find(id);
		if (it == common_emails.end())
			return err_email_id_not_found;
		it->second->setDeleted();
		common_emails.erase(it);
		return res_sucess;
	}

	void email_system::sendToAll(EmailPtr& e)
	{
		std::vector<int> server_ids;
		ForEach(ServerID2Email, it, _common_emails)
			server_ids.push_back(it->first);
		sendToAll(server_ids, e);
	}

	void email_system::sendToAll(const std::vector<int>& server_ids, EmailPtr& e)
	{
		if (server_ids.empty())
			return;
		ForEachC(std::vector<int>, it, server_ids)
		{
			int server_id = *it;
			ServerID2Email::iterator ite = _common_emails.find(server_id);
			if (ite == _common_emails.end())
				continue;
			EmailPtr ne = Creator<Email>::Create(*e);
			CommonEmailPtr c = createAll(server_id, ne);
			ite->second.common_emails.insert(make_pair(c->getId(), c));
		}
		playerManager::playerDataVec vec = player_mgr.allOnline();
		ForEach(playerManager::playerDataVec, it, vec)
			(*it)->Email().addCommonEmail();
	}

	void email_system::sendToKingdom(int nation, EmailPtr& e)
	{
		std::vector<int> server_ids;
		ForEach(ServerID2Email, it, _common_emails)
			server_ids.push_back(it->first);
		sendToKingdom(server_ids, nation, e);
	}

	void email_system::sendToKingdom(const std::vector<int>& server_ids, int nation, EmailPtr& e)
	{
		if (server_ids.empty())
			return;
		ForEachC(std::vector<int>, it, server_ids)
		{
			int server_id = *it;
			ServerID2Email::iterator ite = _common_emails.find(server_id);
			if (ite == _common_emails.end())
				continue;
			EmailPtr ne = Creator<Email>::Create(*e);
			CommonEmailPtr c = createNation(server_id, nation, ne);
			ite->second.common_emails.insert(make_pair(c->getId(), c));
		}
		playerManager::playerDataVec vec = player_mgr.nationOnline((Kingdom::NATION)nation);
		ForEach(playerManager::playerDataVec, it, vec)
			(*it)->Email().addCommonEmail();
	}

	void email_system::sendToPart(const std::vector<int>& player_list, EmailPtr& e)
	{
		if (player_list.empty())
			return;

		ForEach(ServerID2Email, it, _common_emails)
		{
			EmailPtr ne = Creator<Email>::Create(*e);
			CommonEmailPtr c = createPart(it->first, player_list, ne);
			it->second.common_emails.insert(make_pair(c->getId(), c));
		}
		ForEachC(std::vector<int>, it, player_list)
		{
			playerDataPtr d = player_mgr.getOnlinePlayer(*it);
			if (d)
				d->Email().addCommonEmail();
		}
	}

	void email_system::sendToChannel(const std::vector<std::string>& channels, unsigned over_time, EmailPtr& e)
	{
		std::vector<int> server_ids;
		ForEach(ServerID2Email, it, _common_emails)
			server_ids.push_back(it->first);
		sendToChannel(server_ids, channels, over_time, e);
	}

	void email_system::sendToChannel(const std::vector<int>& server_ids, const std::vector<std::string>& channels, unsigned over_time, EmailPtr& e)
	{
		if (server_ids.empty())
			return;
		ForEachC(std::vector<int>, it, server_ids)
		{
			int server_id = *it;
			ServerID2Email::iterator ite = _common_emails.find(server_id);
			if (ite == _common_emails.end())
				continue;
			EmailPtr ne = Creator<Email>::Create(*e);
			CommonEmailPtr c = createChannel(server_id, channels, over_time, ne);
			ite->second.common_emails.insert(make_pair(c->getId(), c));
		}
		playerManager::playerDataVec vec = player_mgr.allOnline();
		ForEach(playerManager::playerDataVec, it, vec)
			(*it)->Email().addCommonEmail();
	}

	void email_system::sendToPlayer(int player_id, EmailPtr& e)
	{
		playerDataPtr d = player_mgr.getPlayer(player_id);
		if (!d) return;

		d->Email().addEmail(e);
	}

	unsigned email_system::getCommonId(int server_id)
	{
		unsigned id = ++_common_emails[server_id].max_common_id;
		saveCommonID(server_id);
		return id;
	}

	EmailPtr email_system::createSystem(const std::string& msg)
	{
		Json::Value m;
		m[EmailDef::MsgType] = EmailDef::Normal;
		m[EmailDef::ParamList].append(msg);
		return Creator<Email>::Create(Common::gameTime(), (int)EmailDef::System, "sys", m);
	}

	EmailPtr email_system::createSystem(int msg_type, const Json::Value& param_list)
	{
		Json::Value m;
		m[EmailDef::MsgType] = msg_type;
		m[EmailDef::ParamList] = param_list;
		return Creator<Email>::Create(Common::gameTime(), (int)EmailDef::System, "sys", m);
	}

	EmailPtr email_system::createGamer(playerDataPtr& d, const std::string& msg)
	{
		Json::Value m;
		m[EmailDef::MsgType] = EmailDef::Normal;
		m[EmailDef::ParamList].append(msg);
		return Creator<Email>::Create(Common::gameTime(), (int)EmailDef::Gamer, d->ID(), d->Name(), m);
	}

	EmailPtr email_system::createPackage(int msg_type, const Json::Value& param_list, const Json::Value& reward)
	{
		Json::Value m;
		m[EmailDef::MsgType] = msg_type;
		m[EmailDef::ParamList] = param_list;
		Json::Value rw;
		rw[EmailDef::RewardType] = EmailDef::NormalReward;
		rw[EmailDef::ActionList] = reward;
		return Creator<Email>::Create(Common::gameTime(), (int)EmailDef::Package, "sys", m, rw);
	}
	
	EmailPtr email_system::createGmPackage(int msg_type, const Json::Value& param_list, const Json::Value& reward)
	{
		Json::Value m;
		m[EmailDef::MsgType] = msg_type;
		m[EmailDef::ParamList] = param_list;
		Json::Value rw;
		rw[EmailDef::RewardType] = EmailDef::GmGift;
		rw[EmailDef::GmGiftList] = reward;
		return Creator<Email>::Create(Common::gameTime(), (int)EmailDef::Package, "sys", m, rw);
	}

	EmailPtr email_system::createReport(int msg_type, const Json::Value& param_list, const std::string& report)
	{
		Json::Value m;
		m[EmailDef::MsgType] = msg_type;
		m[EmailDef::ParamList] = param_list;
		return Creator<Email>::Create(Common::gameTime(), (int)EmailDef::Report, "sys", m, report);
	}

	EmailPtr email_system::createFromBSON(const mongo::BSONElement& obj)
	{
		return Creator<Email>::Create(obj);
	}

	CommonEmailPtr email_system::createAll(int server_id, EmailPtr& e)
	{
		CommonEmailPtr c = Creator<CommonEmail>::Create(server_id, e);
		c->_sign_save();
		return c;
	}

	CommonEmailPtr email_system::createNation(int server_id, int nation, EmailPtr& e)
	{
		CommonEmailPtr c = Creator<CommonEmail>::Create(server_id, nation, e);
		c->_sign_save();
		return c;
	}

	CommonEmailPtr email_system::createPart(int server_id, const std::vector<int>& parts, EmailPtr& e)
	{
		CommonEmailPtr c = Creator<CommonEmail>::Create(server_id, parts, e);
		c->_sign_save();
		return c;
	}

	CommonEmailPtr email_system::createChannel(int server_id, const std::vector<std::string>& channels, unsigned over_time, EmailPtr& e)
	{
		CommonEmailPtr c = Creator<CommonEmail>::Create(server_id, channels, over_time, e);
		c->_sign_save();
		return c;
	}

	unsigned email_system::getCommonEmails(playerDataPtr d, int player_common_email_id, EmailVec& vec)
	{
		int server_id = d->Info().ServerID();
		ServerID2Email::iterator itc = _common_emails.find(server_id);
		if (itc == _common_emails.end())
			return 100000;

		EmailData& emd = itc->second;
		if (player_common_email_id == emd.max_common_id)
			return emd.max_common_id;

		for (CommonEmailMap::reverse_iterator it = emd.common_emails.rbegin();
			it != emd.common_emails.rend(); ++it)
		{
			if (it->first <= player_common_email_id)
				break;
			if (it->second->needed(d))
				vec.push_back(it->second->getEmail());
		}

		return emd.max_common_id;
	}

	EmailPtr email_system::getCommonEmail(int server_id, int id)
	{
		ServerID2Email::iterator it = _common_emails.find(server_id);
		if (it == _common_emails.end())
			return EmailPtr();
		CommonEmailMap& em = it->second.common_emails;
		CommonEmailMap::iterator it2 = em.find(id);
		if (it2 == em.end())
			return EmailPtr();
		return it2->second->getEmail();
	}

	void email_system::classLoad()
	{
		objCollection objs = db_mgr.Query(DBN::dbCommonEmails);
		if (objs.empty())
		{
			saveCommonID(Common::serverID());
			return;
		}
		
		ForEachC(objCollection, it, objs)
		{
			const mongo::BSONObj& obj = *it;
			int server_id = Common::serverID();
			int id = obj[EmailDef::Id].Int();
			bool up = false;
			if (obj["svr"].eoo())
			{
				mongo::BSONObj key = BSON(EmailDef::Id << id);
				db_mgr.RemoveCollection(DBN::dbCommonEmails, key);
				up = true;
			}
			else
			{
				server_id = obj["svr"].Int();
			}
			if (id == -1)
			{
				_common_emails[server_id].max_common_id = obj["cei"].Int();
				if (up)
					saveCommonID(Common::serverID());
				continue;
			}
			CommonEmailPtr c = Creator<CommonEmail>::Create(obj);	
			if (c->outOfDate())
				c->setDeleted();
			else
			{
				if (up)
					c->_sign_save();
				_common_emails[server_id].common_emails.insert(make_pair(c->getId(), c));
			}
		}
		ForEach(ServerID2Email, it, _common_emails)
		{
			EmailData& data = it->second;
			if (data.max_common_id == 100000
					&& !data.common_emails.empty())
				data.max_common_id = data.common_emails.rbegin()->second->getId();
		}
	}

	void email_system::saveCommonID(int server_id)
	{
		mongo::BSONObj key = BSON(EmailDef::Id << -1 << "svr" << server_id);
		mongo::BSONObj obj = BSON(EmailDef::Id << -1 << "svr" << server_id
			<< "cei" << _common_emails[server_id].max_common_id);
		db_mgr.SaveMongo(DBN::dbCommonEmails, key, obj);
	}
}

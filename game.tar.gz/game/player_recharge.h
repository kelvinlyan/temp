#pragma once

#include "auto_base.h"
#include "commom.h"

namespace gg
{
	class playerRecharge : public _auto_player
	{
	public:
		playerRecharge(playerData* const own);

		int getTotalCash() { return _cash; }
		int getTotalGold() { return _gold; }
		void addRecharge(int cash, int rate);
		bool _auto_save();

		~playerRecharge();
		void setData(mongo::BSONObj& obj);
	private:
		int _cash;//��ֵ���ֽ�����Ŀ
		int _gold;//��ֵ��Ԫ������Ŀ
	};
}


#include "player_imperial_exam.h"
#include "dbDriver.h"

namespace gg
{

	imperial::ExamState playerImperialExam::_state;
	int playerImperialExam::_require_grade;
	int playerImperialExam::_country_grade;

	playerImperialExam::playerImperialExam(playerData* const own)
		:_auto_player(own),
		_answer_group_c(INVALID_NUM),
		_suggection_group_c(INVALID_NUM),
		_fight_group_c(INVALID_NUM),
		_purchase_group_c(INVALID_NUM),
		_answer_topic_c(INVALID_NUM),
		_suggection_topic_c(INVALID_NUM),
		_fight_topic_c(INVALID_NUM),
		_purchase_topic_c(INVALID_NUM)
	{
	}

	int playerImperialExam::getGroupCount(int type)
	{
		return 0;
	}
	void playerImperialExam::addGroupCount(int type, int inc)
	{
	}

	void playerImperialExam::emptyGroupCount(int type)
	{}

	int playerImperialExam::getTopicCount(int type)
	{
		return 0;
	}

	void playerImperialExam::addTopicCount(int type, int inc)
	{}

	void playerImperialExam::createNewGroup(int type, int group_id)
	{}

	void playerImperialExam::startCountryExam(unsigned stamp)
	{}

	void playerImperialExam::restart()
	{}

	void playerImperialExam::sign(int require, unsigned deadline)
	{
		_deadline = deadline;
		_timer = Timer::AddEventTickTime(boostBind(playerImperialExam::ExamOver, _1), 1, _deadline);
		_auto_save();
	}

	void playerImperialExam::ExamOver(const structTimer& timerData)
	{
		if (_country_grade >= _require_grade)
		{
			_state = imperial::StateTempleIn;
		}
		///����ִ��֪ͨ
	}

	unsigned playerImperialExam::start()
	{
		return 0;
	}

	void playerImperialExam::setCountryOut()
	{
		if (_country_grade >= _require_grade)
		{
			_e_state = imperial::StateTempleIn;
		}
		else
		{
			_e_state = imperial::StateCountryOut;
		}
	}

	void playerImperialExam::alterCountryCount(int alter)
	{
		if (_country_count + alter >= 0)
		{
			_country_count += alter;
		}
	}

	void playerImperialExam::addTempleCount(int inc)
	{
		if (_temple_count == 0)
		{
			_temple_start = Common::gameTime();
		}
		_temple_count += inc;
		_auto_save();
	}

	void playerImperialExam::alterCountryGrade(int alter)
	{
		if (_country_grade + alter >= 0)
		{
			_country_grade += alter;
		}
	}

	void playerImperialExam::addTimeRestCountryGrade(const lx::Sequence& seq, unsigned time_rest)
	{
		if (time_rest == 0)
		{
			time_rest = _deadline - Common::gameTime() >= 0 ? _deadline - Common::gameTime() : 0;
		}
		if (seq.size() < 2)
		{
			return;
		}
		for (int i = 0; i < seq.size(); i += 3)
		{
			if (time_rest <= seq[i + 1])
			{
				_country_grade += seq[i + 2];
				_auto_save();
				break;
			}
		}
	}

	unsigned playerImperialExam::templeTime()
	{
		return Common::gameTime() - _temple_start;
	}

	void playerImperialExam::setTempleGrade(unsigned time)
	{
		if (time == 0)
		{
			_temple_grade = Common::gameTime() - _temple_start;
		}
		else
		{
			_temple_grade = time;
		}
		_auto_save();
	}

	void playerImperialExam::delTimer()
	{
		if (_timer)
		{
			_timer->delTimer();
		}
	}

	void playerImperialExam::setCountryReward(const lx::BoxSingle& box)
	{}

	void playerImperialExam::setTempleReward(const lx::BoxSingle& box)
	{}

	void playerImperialExam::removeCountryReward()
	{}

	void playerImperialExam::removeTempleReward()
	{}

	bool playerImperialExam::isExistCountryReward()
	{
		return false;
	}

	bool playerImperialExam::isExistTempleReward()
	{
		return false;
	}

	playerImperialExam::~playerImperialExam()
	{
	}

}

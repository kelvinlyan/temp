#pragma once

#include "auto_base.h"
#include "kingdomwar_helper.h"

namespace gg
{
	class Enemy
	{
		public:
			Enemy(playerDataPtr d);

			void getInfo(qValue& q) const;
			void upData(playerDataPtr d);
			int pid() const { return _pid; }

		private:
			int _pid;
			std::string _name;
			int _nation;
			int _lv;
			int _bv;
			int _protected_cd;
	};

	BOOSTSHAREPTR(Enemy, EnemyPtr);
	STDMAP(int, EnemyPtr, EnemyMap);
	STDLIST(EnemyPtr, EnemyList);

	class EnemyMgr
	{
		SINGLETON(EnemyMgr);
		public:
			void upData(playerDataPtr d);
			EnemyPtr getEnemy(int pid);
		private:
			EnemyMap _enemy_map;
	};

	class playerEnemy
		: public _auto_player
	{
		public:
			playerEnemy(playerData* const own);
			void setData(mongo::BSONObj& obj);		
			
			int add(playerDataPtr target);
			int remove(playerDataPtr target);
			void update();
			void updateBase();

		private:
			virtual bool _auto_save();
			virtual void _auto_update();
			virtual void classFinal();

		private:
			EnemyList _enemy_list;
			std::vector<int> _temp_enemy_list_id;
	};
}

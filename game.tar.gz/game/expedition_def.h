#pragma once

#include "mongoDB.h"

namespace gg
{
	namespace Expedition
	{
		struct Record
		{
			Record(): progress(0), percent(0){}
			Record(const mongo::BSONElement& obj)
			{
				progress = obj["p"].Int();
				time = obj["t"].Int();
				if (!obj["pr"].eoo())
					percent = obj["pr"].Int();
				else
					percent = 10000;
			}

			int progress;
			int percent;
			unsigned time;
		};
	}
}

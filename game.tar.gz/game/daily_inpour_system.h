//###################################
//created by Lin Xing
//2016-11-3
//###################################

#pragma once

#include "dbDriver.h"
#include "player_daily_inpour.h"
#include "utility_lx.h"
#include "game_time.h"

#define daily_inpour_sys (*gg::daily_inpour_system::_Instance)

namespace gg
{
	namespace daily_inpour
	{
		//��ͨ�ñ�������
		typedef struct _boxSingle
		{
			ActionBoxList box;
			std::string strBox;
			Json::Value jsonBox;
			Json::Value rawBox;//save to db
			int weight;
			void load()
			{
				jsonBox = lx::utility_lx::parseJson(rawBox);
				strBox = lx::utility_lx::parseJsonBox(rawBox);
				box = actionFormatBox(rawBox);
			}
		} BoxSingle;
	
		//�µİ汾
		typedef struct _inpourSingle
		{
			int id;
			int gold;
			int accu;
			BoxSingle box;
		}InpourSingle;//ÿ�յ��γ�ֵ

		typedef struct _inpourBox
		{
			int id;
			int accu;
			BoxSingle box;
		}InpourBox;//�ۻ����ֽ�������

		STDMAP(int, daily_inpour::InpourSingle, InpourSingleList);
		STDVECTOR(InpourSingleList, InpourSingleSet);//ÿ����һ��InpourSingleList
		STDMAP(int, daily_inpour::InpourBox, InpourBoxList);

		typedef struct _dailyInpourActivity
		{
			_dailyInpourActivity()
			{
				flag = 1;//Ĭ�Ͽ���
				days = -1;
			}
			int id;
			int days;
			unsigned begin;
			unsigned end;
			int flag;//��������߹ر�
			InpourSingleList single_list;
			InpourSingleSet single_set;
			InpourBoxList box_list;
		} DailyInpourActivity;

		//��̶���Ϣ�����ڷ��أ�
		typedef struct _fixedInfo
		{
			Json::Value box_accu_list;
			Json::Value box_flag_list;//����Ϊ0
			Json::Value box_boxes_list;
			Json::Value single_gold_list;
			Json::Value single_accu_list;
			Json::Value single_boxes_list;
			Json::Value single_flag_list;//����Ϊ0
		} FixedInfo;
	}

	STDMAP(int, daily_inpour::DailyInpourActivity, DailyInpourList);

	//BOOSTSHAREPTR(daily_inpour::InpourConfig, InpourConfigPtr);
	//BOOSTSHAREPTR(daily_inpour::InpourShopConfig, ShopConfigPtr);

	//ÿ�յ��ʳ�ֵϵͳ
	class daily_inpour_system
	{
	public:
		daily_inpour_system();
		~daily_inpour_system();
		void initData();
		bool saveData(int activity_id);
		void delData(int activity_id);
		void loadData();
		//int getDayTh(const std::vector<int>& days);//���뿪��������
		void ReChargePlayerRecord(playerDataPtr player, int gold); //��ֵϵͳ�ӿ�
		void timeData(Json::Value& json);
		static void ActivityOver(const structTimer& timerData);

		DeclareRegFunction(reqDailyInpourInfo);
		DeclareRegFunction(reqDailyInpourGetReward);
		DeclareRegFunction(reqDailyInpourShopReflesh);
		DeclareRegFunction(reqDailyInpourShopPurchase);
		DeclareRegFunction(reqRedPoint);
		//GM
		DeclareRegFunction(getDailyInpourIdList);
		DeclareRegFunction(getDailyInpourInfo);
		DeclareRegFunction(ModifyDailyInpour);

		//ÿ��ˢ��ʱ�Ľ��㹦�ܣ�����

	public:
		static daily_inpour_system* const _Instance;
	private:
		daily_inpour::DailyInpourActivity _curr;
		daily_inpour::FixedInfo _info;
	private:
		void select_active();
		void updateInfo();
	private:
	};
}


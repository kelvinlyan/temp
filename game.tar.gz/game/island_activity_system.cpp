#include "island_activity_system.h"
#include "net_helper.hpp"
#include "chat.h"

namespace gg
{
	using namespace nIsland;

	namespace nIsland
	{
		RewardRecord::RewardRecord(int key_id)
			: _key_id(key_id){}

		void RewardRecord::loadDB()
		{
			mongo::BSONObj key = BSON("key" << _key_id);
			mongo::BSONObj obj = db_mgr.FindOne(DBN::dbIslandRecord, key);
			if (obj.isEmpty())
				return;
			std::vector<mongo::BSONElement> ele = obj["value"].Array();
			for (unsigned i = 0; i < ele.size(); ++i)
				_records.push_back(ele[i].String());
		}

		void RewardRecord::removeDB()
		{
			mongo::BSONObj key = BSON("key" << _key_id);
			db_mgr.RemoveCollection(DBN::dbIslandRecord, key);
		}

		bool RewardRecord::_auto_save()
		{
			mongo::BSONObj key = BSON("key" << _key_id);
			mongo::BSONObjBuilder obj;
			obj << "key" << _key_id;
			{
				mongo::BSONArrayBuilder b;
				ForEachC(RecordList, it, _records)
					b.append(*it);
				obj << "value" << b.arr();
			}
			return db_mgr.SaveMongo(DBN::dbIslandRecord, key, obj.obj());
		}

		void RewardRecord::push(qValue& r)
		{
			_records.push_back(r.toIndentString());
			while(_records.size() > 30)
				_records.pop_front();
			_sign_save();
		}

		void RewardRecord::update(playerDataPtr d)
		{
			std::string str;
			str += "{\"msg\":[0,[";
			ForEachC(RecordList, it, _records)
			{
				if (it != _records.begin())
					str += ",";
				str += *it;
			}
			str += "]]}";
			d->sendToClient(gate_client::island_activity_reward_info_resp, str);
		}
	}

	island_activity_system* const island_activity_system::_Instance = new island_activity_system();

	IslandActivity::IslandActivity(const Json::Value& info)
		: ActivityBase(info["kid"].asUInt(), info["bt"].asUInt() + Common::timeZone() * HOUR, info["et"].asUInt() + Common::timeZone() * HOUR)
		, _data(info)
	{
		{
			const Json::Value& ttb1 = info["ttb1"];
			ForEachC(Json::Value, it, ttb1)
				_turntable_east.push_back(RandItem(*it));
			const Json::Value& ttb2 = info["ttb2"];
			ForEachC(Json::Value, it, ttb2)
				_turntable_west.push_back(RandItem(*it));
			const Json::Value& box = info["box"];
			ForEachC(Json::Value, it, box)
				_turntable_high.push_back(RandItem(*it));
			_limit_by_action = info["tplba"].asInt();
			_limit_by_gold = info["tplbg"].asInt();
		}
		{
			_client_info = info;
			Json::Value& ttb1 = _client_info["ttb1"];
			ForEach(Json::Value, it, ttb1)
				(*it)["rw"] = jsonFormats2c((*it)["rw"]);
			Json::Value& ttb2 = _client_info["ttb2"];
			ForEach(Json::Value, it, ttb2)
				(*it)["rw"] = jsonFormats2c((*it)["rw"]);
			Json::Value& box = _client_info["box"];
			ForEach(Json::Value, it, box)
				(*it)["rw"] = jsonFormats2c((*it)["rw"]);
		}
	}

	mongo::BSONObj IslandActivity::toBSON() const
	{
		return BSON("str" << _data.toIndentString());
	}

	const nIsland::ItemList& IslandActivity::getTurnTable(int type) const
	{
		if (type == 0)
			return _turntable_east;
		else if (type == 1)
			return _turntable_west;
		else
			return _turntable_high;
	}

	ActionBoxList IslandActivity::turnTableReward(int type, int& idx, bool& bc) const
	{
		ActionBoxList ab;
		const nIsland::ItemList& turntable = getTurnTable(type);
		int total = 0;
		ForEachC(ItemList, it, turntable)
			total += it->percent;
		int r = Common::random() % total;
		int cur = 0;
		idx = 0;
		bool found = false;
		ForEachC(ItemList, it, turntable)
		{
			if (r < it->percent + cur)
			{
				bc = it->bc;
				ab = it->reward;
				found = true;
				break;
			}
			++idx;
			cur += it->percent;
		}
		if (!found)
		{
			idx = 0;
			bc = turntable.front().bc;
			ab = turntable.front().reward;
		}
		if (type == 0 || type == 1)
		{
			int num = nIsland::randKeyPiece();
			ACTION::Box b;
			b.actionID = ACTION::item;
			b.boxData._Item.itemID = nIsland::KeyPieceID();
			b.boxData._Item.num = num;
			ab.push_back(b);
		}
		return ab;
	}

	void IslandActivity::start()
	{
		island_activity_sys.sendInfo();
		_record = Creator<nIsland::RewardRecord>::Create(keyID());
		_record->loadDB();
	}

	void IslandActivity::stop(bool timer_tick)
	{
		island_activity_sys.sendInfo();
		_record->removeDB();
	}

	void IslandActivity::update()
	{
		island_activity_sys.sendInfo();
		_record = Creator<nIsland::RewardRecord>::Create(keyID());
		_record->loadDB();
	}

	void IslandActivity::addRecord(qValue& q)
	{
		_record->push(q);
	}

	void IslandActivity::sendRecord(playerDataPtr d)
	{
		_record->update(d);
	}

	island_activity_system::island_activity_system()
		: ActivityMgr<IslandActivity>(DBN::dbIslandActivity, Inter::event_island_activity_timer)
	{
	}

	void island_activity_system::initData()
	{
		loadDB();
	}

	void island_activity_system::loadDB()
	{
		objCollection objs = db_mgr.Query(DBN::dbIslandActivity);
		std::map<int, boost::shared_ptr<IslandActivity> > island_activity_map;
		ForEachC(objCollection, it, objs)
		{
			std::string str = (*it)["value"]["str"].String();
			boost::shared_ptr<IslandActivity> ptr = Creator<IslandActivity>::Create(Common::string2json(str));
			island_activity_map.insert(make_pair(ptr->beginTime(), ptr));
		}
		unsigned cur_time = Common::gameTime();
		for (std::map<int, boost::shared_ptr<IslandActivity> >::iterator it = island_activity_map.begin();
			it != island_activity_map.end(); ++it)
			update(it->second);
	}

	void island_activity_system::gmIDList(net::Msg& m, Json::Value& r)
	{
		getIDList(r[strMsg][1u]);
		Return(r, res_sucess);
	}

	void island_activity_system::gmInfo(net::Msg& m, Json::Value& r)
	{
		ReadJsonArray;
		int key_id = js_msg[0u].asInt();
		boost::shared_ptr<IslandActivity> ptr = find(key_id);
		if (!ptr) Return(r, err_illedge);
		r[strMsg][1u] = ptr->data();
		Return(r, res_sucess);
	}

	void island_activity_system::gmModify(net::Msg& m, Json::Value& r)
	{
		ReadJsonArray;
		const Json::Value& info = js_msg[0u];
		//LogI << "festival modify: " << info.toIndentString() << LogEnd;
		int res;
		if (info["et"].asUInt() == 0)
			res = remove(info["kid"].asInt());
		else
		{
			boost::shared_ptr<IslandActivity> ptr = Creator<IslandActivity>::Create(info);
			res = update(ptr);
		}
		Return(r, res);
	}

	void island_activity_system::record(net::Msg& m, Json::Value& r)
	{
		playerDataPtr d = player_mgr.getPlayer(m.playerID);
		if (!d || !current()) Return(r, err_illedge);
		current()->sendRecord(d);
	}

	void island_activity_system::turnTable(net::Msg& m, Json::Value& r)
	{
		playerDataPtr d = player_mgr.getPlayer(m.playerID);
		if (!d) Return(r, err_illedge);
		ReadJsonArray;
		int type = js_msg[0u].asInt();
		int times_type = js_msg[1u].asInt();
		int res = d->IslandActivity().turnTable(type, times_type, r);
		Return(r, res);
	}

	void island_activity_system::openBox(net::Msg& m, Json::Value& r)
	{
		playerDataPtr d = player_mgr.getPlayer(m.playerID);
		if (!d) Return(r, err_illedge);
		ReadJsonArray;
		int res = d->IslandActivity().openBox(r);
		Return(r, res);
	}


	void island_activity_system::ownRecord(net::Msg& m, Json::Value& r)
	{
		playerDataPtr d = player_mgr.getPlayer(m.playerID);
		if (!d || !current()) Return(r, err_illedge);
		d->IslandActivity().sendRecord();
	}

	void island_activity_system::playerInfo(net::Msg& m, Json::Value& r)
	{
		playerDataPtr d = player_mgr.getPlayer(m.playerID);
		if (!d || !current()) Return(r, err_illedge);
		d->IslandActivity().sendBase();
	}

	void island_activity_system::sendInfo(playerDataPtr d)
	{
		Json::Value m;
		m[strMsg][0u] = res_sucess;
		if (!current())
			m[strMsg][1u]["kid"] = -1;
		else
			m[strMsg][1u] = current()->ClientInfo();
		if (d)
		{
			d->IslandActivity().update();
			d->sendToClient(gate_client::island_activity_info_resp, m);
		}
		else
		{
			playerManager::playerDataVec vec = player_mgr.allOnline();
			ForEach(playerManager::playerDataVec, it, vec)
				(*it)->IslandActivity().update();
			Batch::batchAll(m, gate_client::island_activity_info_resp);
		}
	}
}

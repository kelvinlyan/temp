#pragma once

#include "auto_base.h"

namespace gg
{
	class playerFestival
		: public _auto_player
	{
		public:
			playerFestival(playerData* const own);

			void sendBase();
			void sendNpc();
			void sendRecord();

			int buyTurnTableTimes();
			int buyThrowEggTimes();
			int turnTable(int type, Json::Value& r);
			int throwEgg(Json::Value& r);
			int exchangeMaterial(int idx, Json::Value& r);
			int fightNpc(int type, int id);

			void dailyTick();
			void setData(mongo::BSONObj& obj);
		private:
			virtual bool _auto_save();

			void update();
			void updateNpc();
			void resetNpc(unsigned cur_time);

		private:
			int _key_id;
			int _points;
			unsigned _buy_times;

			struct Npc
			{
				Npc(int i, int t): id(i), type(t){}
				int id;
				int type;
			};
			std::vector<Npc> _kingdomwar_npc;
			std::vector<Npc> _maincity_npc;
			unsigned _next_npc_reset_time;

			std::list<std::string> _record_list;
	};
}

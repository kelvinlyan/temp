#pragma once

#include "auto_base.h"
#include "mongoDB.h"
#include "battle_def.h"

namespace gg
{
	class playerMan;

	namespace Expedition
	{
		BOOSTSHAREPTR(playerMan, playerManPtr);
		STDVECTOR(playerManPtr, ManList);
	};

	class playerExpeditionFM
		: public _auto_player
	{
		public:
			playerExpeditionFM(playerData* const own);

			void classLoad();
			void update();

			void resetFM();
			void recalFM() { _bv = -1; }
			sBattlePtr getBattlePtr();

			void tickAt0500();

			int changeFormation(int fm_id);
			int setFormation(const std::vector<int>& fm);

			int bv();
			int curFMID();

		private:
			virtual bool _auto_save(); 
			virtual void _auto_update();
			void initFM();
			int calBV();
			void getInfo(qValue& q);

		private:
			int _bv;

			int _cur_fm_id;
			Expedition::ManList _cur_fm;
	};
}

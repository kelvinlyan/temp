#include "player_old_player.h"
#include "dbDriver.h"
#include "email_system.h"

const static std::string strAccuDay = "ad";
const static std::string strAccuGold = "ag";
const static std::string strActiId = "ai";
const static std::string strOffday = "od";
const static std::string strOffFlag = "of";
const static std::string strLoginFlag = "lf";
const static std::string strLastLogin = "ll";
const static std::string strBackR = "br";
const static std::string strRechargeR = "rr";
const static std::string strBackBox = "bb";
const static std::string strRechargeBox = "rb";
const static std::string strOtherDay = "aod";

namespace gg
{

	playerOldPlayer::playerOldPlayer(playerData* const own)
		:_auto_player(own),
		_login_flag(0),
		_off_flag(0),
		_acti_id(-1),
		_accu_gold(0),
		_accu_day(0),
		_last_login(3),
		_off_day(0),
		_another_day(1)
	{
	}

	void playerOldPlayer::setLogin()
	{
		_login_flag = 1;
	}

	bool playerOldPlayer::isOk()
	{
		return _login_flag == 1;
	}

	void playerOldPlayer::addAccuDay(const int& day/* =1 */)
	{
		//LogS << "old_player\tflag:" << _another_day << "\tday:" << day << LogEnd;
		if (_another_day == 1)
		{
			_accu_day += day;
			_another_day = 0;
			_auto_save();
		}
	}

	void playerOldPlayer::addAccuGold(const int& gold)
	{
		_accu_gold += gold;
		_auto_save();
	}

	void playerOldPlayer::addBacksBox(int key, const Json::Value& box)
	{
		if (_back_boxes.find(key) == _back_boxes.end()
			&& _back_records.find(key) == _back_records.end())
		{
			_back_boxes[key] = box;
			_sign_auto();
		}
	}

	void playerOldPlayer::addRechargeBox(int key, const Json::Value& box)
	{
		if (_recharge_boxes.find(key) == _recharge_boxes.end()
			&& _recharge_records.find(key) == _recharge_records.end())
		{
			_recharge_boxes[key] = box;
			_sign_auto();
		}
	}

	void playerOldPlayer::delReward(int type, int key)
	{
		if (type == 1 && _back_boxes.find(key) != _back_boxes.end())
		{
			_back_boxes.erase(key);
		}
		if (type == 2 && _recharge_boxes.find(key) != _recharge_boxes.end())
		{
			_recharge_boxes.erase(key);
		}
		_sign_auto();
	}

	void playerOldPlayer::setRewardRecords(int type, int key)
	{
		if (type == 1 && _back_records.find(key) == _back_records.end())
		{
			_back_records[key] = key;
		}
		if (type == 2 && _recharge_records.find(key) == _recharge_records.end())
		{
			_recharge_records[key] = key;
		}
		_auto_save();
	}

	bool playerOldPlayer::isGotDayReward(int key)
	{
		return _back_records.find(key) != _back_records.end();
	}

	bool playerOldPlayer::isGotGoldReward(int key)
	{
		return _recharge_records.find(key) != _recharge_records.end();
	}

	bool playerOldPlayer::hasRewards(int type, int key)
	{
		if (type == 1 && _back_boxes.find(key) != _back_boxes.end())
		{
			return true;
		}
		if (type == 2 && _recharge_boxes.find(key) != _recharge_boxes.end())
		{
			return true;
		}
		return false;
	}

	Json::Value playerOldPlayer::getReward(int type, int key)
	{
		if (type == 1)
		{
			old_player::RewardBoxList::iterator it = _back_boxes.find(key);
			if (it != _back_boxes.end())
			{
				return it->second;
			}
		}
		if (type == 2)
		{
			old_player::RewardBoxList::iterator it = _recharge_boxes.find(key);
			if (it != _recharge_boxes.end())
			{
				return it->second;
			}
		}
		return Json::arrayValue;
	}

	void playerOldPlayer::reset()
	{
		_another_day = 1;
		_auto_save();
	}

	void playerOldPlayer::setOffday(const int& off_day)
	{
		if (_off_flag == 1)
		{
			return;
		}
		//LogS << "old_player\tpid:" << Own().ID()<< "_off_flag:" << _off_flag << "\toff_day:" << off_day << LogEnd;
		_off_flag = 1;
		if (off_day < 1)
		{
			return;
		}
		_off_day = off_day;
		_auto_save();

	}

	void playerOldPlayer::setActiId(int id)
	{
		if (id != _acti_id)
		{
			restart();
		}
		_acti_id = id;
		_sign_auto();
	}

	void playerOldPlayer::_auto_update()
	{
		int flag = getRedPoint();
		Json::Value ret_json;
		ret_json[strMsg][0u] = 0;
		ret_json[strMsg][1u] = flag;
		ret_json[strMsg][2u] = _acti_id;
		Own().sendToClient(gate_client::old_player_red_point_resp, ret_json);
	}

	void playerOldPlayer::restart()
	{
		_accu_day = 0;
		_accu_gold = 0;
		_acti_id = -1;
		_off_day = 0;
		_off_flag = 0;
		_login_flag = 0;
		_last_login = 3;
		_back_records.clear();
		_recharge_records.clear();
		Json::Value boxes = Json::arrayValue;
		for (old_player::RewardBoxList::iterator it = _back_boxes.begin();
			it != _back_boxes.end();
			++it)
		{
			combineActionRes(it->second, boxes);
		}
		for (old_player::RewardBoxList::iterator it = _recharge_boxes.begin();
			it != _recharge_boxes.end();
			++it)
		{
			combineActionRes(it->second, boxes);
		}
		if (boxes.size() > 0)
		{
			EmailPtr e = email_sys.createPackage(EmailDef::OldPlayerBack, Json::nullValue, boxes);
			email_sys.sendToPlayer(Own().ID(), e);
		}
		_back_boxes.clear();
		_recharge_boxes.clear();
		_sign_auto();

	}

	int playerOldPlayer::getRedPoint()
	{
		if (_acti_id == -1 || _login_flag != 1)
		{
			//LogS << "old player\tred point:" << 2 << "\tpi:" << Own().ID() << LogEnd;
			return 2;
		}
		if (_back_boxes.size() > 0 || _recharge_boxes.size() > 0)
		{
			//LogS << "old player\tred point:" << 1 << "\tpi:" << Own().ID() << LogEnd;
			return 1;
		}
		//LogS << "old player\tred point:" << 3 << "\tpi:" << Own().ID() << LogEnd;
		return 3;
	}

	void playerOldPlayer::setData(mongo::BSONObj& obj)
	{
		if (obj.isEmpty())
		{
			return;
		}
		std::vector<mongo::BSONElement> back_box = obj[strBackBox].Array();
		std::vector<mongo::BSONElement> recharge_box = obj[strRechargeBox].Array();
		std::vector<mongo::BSONElement> back_r = obj[strBackR].Array();
		std::vector<mongo::BSONElement> reacharge_r = obj[strRechargeR].Array();
		for (int i = 0; i < back_box.size(); i += 2)
		{
			_back_boxes[back_box[i].Int()] = Common::string2json(back_box[i + 1].String());
		}
		for (int i = 0; i < recharge_box.size(); i += 2)
		{
			_recharge_boxes[recharge_box[i].Int()] = Common::string2json(recharge_box[i + 1].String());
		}
		for (int i = 0; i < back_r.size(); ++i)
		{
			_back_records[back_r[i].Int()] = back_r[i].Int();
		}
		for (int i = 0; i < reacharge_r.size(); ++i)
		{
			_recharge_records[reacharge_r[i].Int()] = reacharge_r[i].Int();
		}
		_accu_day = obj[strAccuDay].Int();
		_accu_gold = obj[strAccuGold].Int();
		_acti_id = obj[strActiId].Int();
		_off_day = obj[strOffday].Int();
		_off_flag = obj[strOffFlag].Int();
		_another_day = obj[strOtherDay].Int();
		//_login_flag = obj[strLoginFlag].Int();
		_last_login = obj[strLastLogin].Int();

	}

	bool playerOldPlayer::_auto_save()
	{
		mongo::BSONArrayBuilder back_boxes, recharge_boxes, back_r, recharge_r;
		for (old_player::RewardBoxList::iterator it = _back_boxes.begin();
			it != _back_boxes.end();
			++it)
		{
			back_boxes << it->first << it->second.toIndentString();
		}
		for (old_player::RewardBoxList::iterator it = _recharge_boxes.begin();
			it != _recharge_boxes.end();
			++it)
		{
			recharge_boxes << it->first << it->second.toIndentString();
		}
		for (old_player::Records::iterator it = _back_records.begin();
			it != _back_records.end();
			++it)
		{
			back_r << it->first;
		}
		for (old_player::Records::iterator it = _recharge_records.begin();
			it != _recharge_records.end();
			++it)
		{
			recharge_r << it->first;
		}

		mongo::BSONObj key = BSON(strPlayerID << Own().ID());
		mongo::BSONObj obj = BSON("$set" << BSON("OldPlayer" << 
			BSON(strAccuDay << _accu_day
			<< strAccuGold << _accu_gold
			<< strActiId << _acti_id
			<< strOffday << _off_day
			<< strOffFlag << _off_flag
			<< strLastLogin << _last_login
			<< strOtherDay << _another_day
			<< strBackBox << back_boxes.arr()
			<< strRechargeBox << recharge_boxes.arr()
			<< strBackR << back_r.arr()
			<< strRechargeR << recharge_r.arr()
		)));

		return db_mgr.SaveMongo(DBN::dbPlayerCollection, key, obj);
	}

	playerOldPlayer::~playerOldPlayer()
	{
	}

}

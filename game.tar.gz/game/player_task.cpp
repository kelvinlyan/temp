#include "player_task.h"
#include "task_system.h"

namespace gg
{
	MTaskRecord::MTaskRecord(const mongo::BSONElement& obj)
		: Task::Record(obj)
	{
	}

	MTaskRecord::MTaskRecord(int id, const Task::CheckPtr& ptr, playerDataPtr d)
		: Task::Record(id, ptr, d)
	{
	}

	bool MTaskRecord::getCheckPtr() const
	{
		if (!_check_ptr)
		{
			TaskConfigPtr ptr = task_sys.getMainTask(_id);
			if (!ptr)
				return false;
			_check_ptr = ptr->_check_ptr;
		}
		return true;
	}

	BTaskRecord::BTaskRecord(const mongo::BSONElement& obj)
		: Task::Record(obj)
	{
	}

	BTaskRecord::BTaskRecord(int id, const Task::CheckPtr& ptr, playerDataPtr d)
		: Task::Record(id, ptr, d)
	{
	}

	bool BTaskRecord::getCheckPtr() const
	{
		if (!_check_ptr)
		{
			TaskConfigPtr ptr = task_sys.getBranchTask(_id);
			if (!ptr)
				return false;
			_check_ptr = ptr->_check_ptr;
		}
		return true;
	}

	playerTask::playerTask(playerData* const own)
		: _auto_player(own), _version_id(0), _red_point(false)
	{
	}

	void playerTask::setData(mongo::BSONObj& obj)
	{
		if (obj.isEmpty())
			return;
		checkNotEoo(obj["mr"])
			_main_records.load(obj["mr"]);
		checkNotEoo(obj["br"])
			_branch_records.load(obj["br"]);
		checkNotEoo(obj["vi"])
			_version_id = obj["vi"].Int();
		checkNotEoo(obj["smi"])
		{
			std::vector<mongo::BSONElement> ele = obj["smi"].Array();
			for (unsigned i = 0; i < ele.size(); ++i)
				_start_main_id_list.push_back(ele[i].Int());
		}
		checkNotEoo(obj["emi"])
		{
			std::vector<mongo::BSONElement> ele = obj["emi"].Array();
			for (unsigned i = 0; i < ele.size(); ++i)
				_end_main_id_list.push_back(ele[i].Int());
		}
		checkNotEoo(obj["sbi"])
		{
			std::vector<mongo::BSONElement> ele = obj["sbi"].Array();
			for (unsigned i = 0; i < ele.size(); ++i)
				_start_branch_id_list.push_back(ele[i].Int());
		}
		checkNotEoo(obj["ebi"])
		{
			std::vector<mongo::BSONElement> ele = obj["ebi"].Array();
			for (unsigned i = 0; i < ele.size(); ++i)
				_end_branch_id_list.push_back(ele[i].Int());
		}
		checkNotEoo(obj["umi"])
		{
			std::vector<mongo::BSONElement> ele = obj["umi"].Array();
			for (unsigned i = 0; i < ele.size(); ++i)
				_unopened_main_id_list.push_back(ele[i].Int());
		}
		checkNotEoo(obj["ubi"])
		{
			std::vector<mongo::BSONElement> ele = obj["ubi"].Array();
			for (unsigned i = 0; i < ele.size(); ++i)
				_unopened_branch_id_list.push_back(ele[i].Int());
		}

		_red_point = getRedPoint();
	}

	bool playerTask::_auto_save()
	{
		mongo::BSONObj key = BSON(strPlayerID << Own().ID());
		mongo::BSONObjBuilder obj;
		obj << "mr" << _main_records.toBSON()
			<< "br" << _branch_records.toBSON() << "vi" << _version_id;
		{
			mongo::BSONArrayBuilder b;
			ForEachC(TaskIdList, it, _start_main_id_list)
				b.append(*it);
			obj << "smi" << b.arr();
		}
		{
			mongo::BSONArrayBuilder b;
			ForEachC(TaskIdList, it, _end_main_id_list)
				b.append(*it);
			obj << "emi" << b.arr();
		}
		{
			mongo::BSONArrayBuilder b;
			ForEachC(TaskIdList, it, _start_branch_id_list)
				b.append(*it);
			obj << "sbi" << b.arr();
		}
		{
			mongo::BSONArrayBuilder b;
			ForEachC(TaskIdList, it, _end_branch_id_list)
				b.append(*it);
			obj << "ebi" << b.arr();
		}
		{
			mongo::BSONArrayBuilder b;
			ForEachC(TaskIdList, it, _unopened_main_id_list)
				b.append(*it);
			obj << "umi" << b.arr();
		}
		{
			mongo::BSONArrayBuilder b;
			ForEachC(TaskIdList, it, _unopened_branch_id_list)
				b.append(*it);
			obj << "ubi" << b.arr();
		}
		mongo::BSONObj set_obj = BSON("$set" << BSON("Task" << obj.obj()));
		return db_mgr.SaveMongo(DBN::dbPlayerCollection, key, set_obj);
	}

	void playerTask::_auto_update()
	{
		update();
	}
	
	void playerTask::update()
	{
		checkAndUpdate();

		Json::Value msg;
		msg[strMsg][0u] = res_sucess;
		_main_records.getInfo(msg[strMsg][1u]["mr"]);
		_branch_records.getInfo(msg[strMsg][1u]["br"]);
		Own().sendToClient(gate_client::task_player_info_resp, msg);
	}

	void playerTask::updateMain(int type, int arg1, int arg2)
	{
		checkAndUpdate();

		bool modified = _main_records.check(Own().getOwnDataPtr(), type, arg1, arg2);
		if (modified)
		{
			const std::vector<int>& finished_list = _main_records.getFinishedList();
			if (!finished_list.empty())
				updateRedPoint(true);
			Json::Value m;
			m[strMsg][0u] = res_sucess;
			_main_records.getInfo(m[strMsg][1u]["mr"]);
			Own().sendToClient(gate_client::task_main_update_resp, m);
			_sign_save();
		}
	}

	void playerTask::updateBranch(int type, int arg1, int arg2)
	{
		checkAndUpdate();

		bool modified = _branch_records.check(Own().getOwnDataPtr(), type, arg1, arg2);
		if (modified)
		{
			const std::vector<int>& finished_list = _branch_records.getFinishedList();
			if (!finished_list.empty())
				updateRedPoint(true);
			Json::Value m;
			m[strMsg][0u] = res_sucess;
			_branch_records.getInfo(m[strMsg][1u]["br"]);
			Own().sendToClient(gate_client::task_main_update_resp, m);
			_sign_save();
		}
	}
	
	int playerTask::getReward(int type, int id)
	{
		int res = type == 0? 
			getMainReward(id) : getBranchReward(id);
		if (res == res_sucess)
			updateRedPoint(true);
		return res;
	}

	int playerTask::getMainReward(int id)
	{
		TaskConfigPtr conf = task_sys.getMainTask(id);
		if (!conf)
			return err_illedge;

		/*
		Task::RecordPtr rcd = _main_records.getRecord(id);
		if (!rcd)
			return err_illedge;

		if (rcd->state() != Task::Finished)
			return err_illedge;*/

		int state = _main_records.getState(id);
		if (state != Task::Finished)
			return err_illedge;

		int res = actionDoBox(Own().getOwnDataPtr(), conf->_reward, false);
		if (res == res_sucess)
		{
			//rcd->setRewarded();
			Json::Value rw = actionRes();
			_main_records.pop(id);
			Log(DBLOG::strLogTask, Own().getOwnDataPtr(), 1, id, "", "", "", "", "", "", rw.toIndentString());
			if (conf->_follow_id != -1)
				openMainTask(conf->_follow_id, false);
			else
				_end_main_id_list.push_back(id);

			task_sys.param() = rw;
			_sign_auto();
		}
		else
		{
			Json::Value error_code = actionError();
			res = error_code[0u][1u].asInt();
		}
		return res;	
	}

	int playerTask::getBranchReward(int id)
	{
		TaskConfigPtr conf = task_sys.getBranchTask(id);
		if (!conf)
			return err_illedge;

		/*Task::RecordPtr rcd = _branch_records.getRecord(id);
		if (!rcd)
			return err_illedge;

		if (rcd->state() != Task::Finished)
			return err_illedge; */

		int state = _branch_records.getState(id);
		if (state != Task::Finished)
			return err_illedge;

		int res = actionDoBox(Own().getOwnDataPtr(), conf->_reward, false);
		if (res == res_sucess)
		{
			//rcd->setRewarded();
			Json::Value rw = actionRes();
			_branch_records.pop(id);
			Log(DBLOG::strLogTask, Own().getOwnDataPtr(), 3, id, "", "", "", "", "", "", rw.toIndentString());
			if (conf->_follow_id != -1)
				openBranchTask(conf->_follow_id, false);
			else
				_end_branch_id_list.push_back(id);
			task_sys.param() = rw;
			_sign_auto();
		}
		else
		{
			Json::Value error_code = actionError();
			res = error_code[0u][1u].asInt();
		}
		return res;	
	}

	void playerTask::checkAndUpdate()
	{
		if (_version_id != task_sys.getVersionId())
		{
			_version_id = task_sys.getVersionId();

			_main_records.recheck(Own().getOwnDataPtr());
			_branch_records.recheck(Own().getOwnDataPtr());
			
			task_sys.openStartTask(Own().getOwnDataPtr());
			
			for (TaskIdList::iterator it = _end_main_id_list.begin(); it != _end_main_id_list.end();)
			{
				TaskConfigPtr ptr = task_sys.getMainTask(*it);
				if (ptr && ptr->_follow_id != -1)
				{
					TaskConfigPtr n_ptr = task_sys.getMainTask(ptr->_follow_id);
					if (n_ptr && Own().LV() >= n_ptr->_open_lv)
					{
						_main_records.push(Creator<MTaskRecord>::Create(n_ptr->_id, n_ptr->_check_ptr, Own().getOwnDataPtr()));
						Log(DBLOG::strLogTask, Own().getOwnDataPtr(), 0, n_ptr->_id);
						it = _end_main_id_list.erase(it);
						continue;
					}
				}
				++it;
			}

			for (TaskIdList::iterator it = _end_branch_id_list.begin(); it != _end_branch_id_list.end();)
			{
				TaskConfigPtr ptr = task_sys.getBranchTask(*it);
				if (ptr && ptr->_follow_id != -1)
				{
					TaskConfigPtr n_ptr = task_sys.getBranchTask(ptr->_follow_id);
					if (n_ptr && Own().LV() >= n_ptr->_open_lv)
					{
						_branch_records.push(Creator<BTaskRecord>::Create(n_ptr->_id, n_ptr->_check_ptr, Own().getOwnDataPtr()));
						Log(DBLOG::strLogTask, Own().getOwnDataPtr(), 2, n_ptr->_id);
						it = _end_branch_id_list.erase(it);
						continue;
					}
				}
				++it;
			}

			checkUnOpenedTask();

			_sign_save();
		}
	}

	void playerTask::openMainTask(int id, bool start_task)
	{
		if (start_task)
		{
			ForEachC(TaskIdList, it, _start_main_id_list)
			{
				if (*it == id)
					return;
			}

			_start_main_id_list.push_back(id);
		}

		TaskConfigPtr ptr = task_sys.getMainTask(id);
		if (ptr && Own().LV() >= ptr->_open_lv)
		{
			_main_records.push(Creator<MTaskRecord>::Create(ptr->_id, ptr->_check_ptr, Own().getOwnDataPtr()));
			Log(DBLOG::strLogTask, Own().getOwnDataPtr(), 0, ptr->_id);
			Json::Value m;
			m[strMsg][0u] = res_sucess;
			_main_records.getInfo(m[strMsg][1u]["mr"]);
			Own().sendToClient(gate_client::task_main_update_resp, m);
		}
		else
			_unopened_main_id_list.push_back(id);
	}

	void playerTask::openBranchTask(int id, bool start_task)
	{
		if (start_task)
		{
			ForEachC(TaskIdList, it, _start_branch_id_list)
			{
				if (*it == id)
					return;
			}

			_start_branch_id_list.push_back(id);
		}

		TaskConfigPtr ptr = task_sys.getBranchTask(id);
		if (ptr && Own().LV() >= ptr->_open_lv)
		{
			_branch_records.push(Creator<BTaskRecord>::Create(ptr->_id, ptr->_check_ptr, Own().getOwnDataPtr()));
			Log(DBLOG::strLogTask, Own().getOwnDataPtr(), 2, ptr->_id);
			Json::Value m;
			m[strMsg][0u] = res_sucess;
			_branch_records.getInfo(m[strMsg][1u]["br"]);
			Own().sendToClient(gate_client::task_main_update_resp, m);
		}
		else
			_unopened_branch_id_list.push_back(id);
	}

	void playerTask::checkUnOpenedTask()
	{
		for (TaskIdList::iterator it = _unopened_main_id_list.begin()
			; it != _unopened_main_id_list.end();)
		{
			TaskConfigPtr conf = task_sys.getMainTask(*it);
			if (conf && Own().LV() >= conf->_open_lv)
			{
				_main_records.push(Creator<MTaskRecord>::Create(conf->_id, conf->_check_ptr, Own().getOwnDataPtr()));		
				Log(DBLOG::strLogTask, Own().getOwnDataPtr(), 0, conf->_id);
				it = _unopened_main_id_list.erase(it);
				Json::Value m;
				m[strMsg][0u] = res_sucess;
				_main_records.getInfo(m[strMsg][1u]["mr"]);
				Own().sendToClient(gate_client::task_main_update_resp, m);
			}
			else
			{
				++it;
			}
		}
		for (TaskIdList::iterator it = _unopened_branch_id_list.begin()
			; it != _unopened_branch_id_list.end();)
		{
			TaskConfigPtr conf = task_sys.getBranchTask(*it);
			if (conf && Own().LV() >= conf->_open_lv)
			{
				_branch_records.push(Creator<BTaskRecord>::Create(conf->_id, conf->_check_ptr, Own().getOwnDataPtr()));
				Log(DBLOG::strLogTask, Own().getOwnDataPtr(), 2, conf->_id);
				it = _unopened_branch_id_list.erase(it);
				Json::Value m;
				m[strMsg][0u] = res_sucess;
				_branch_records.getInfo(m[strMsg][1u]["br"]);
				Own().sendToClient(gate_client::task_main_update_resp, m);
			}
			else
			{
				++it;
			}
		}
	}

	bool playerTask::getRedPoint()
	{
		bool rp = _main_records.taskFinished();
		if (!rp)
			rp = _branch_records.taskFinished();
		return rp;
	}

	void playerTask::updateRedPoint(bool check)
	{
		bool rp = getRedPoint();
		if (check && rp == _red_point)
			return;
		
		_red_point = rp;

		Json::Value msg;
		msg[strMsg][0u] = res_sucess;
		msg[strMsg][1u] = _red_point;
		Own().sendToClient(gate_client::task_red_point_resp, msg);
	}

}

#include "player_secondary_compensation.h"
#include "dbDriver.h"
#include "email_system.h"

const static std::string strBegin = "begin";
const static std::string strFlag = "flag";
const static std::string strCardID = "card_id";
const static std::string strCardID2 = "card_id_2";
const static std::string strGold = "gold";

#define INVALID_TIME 1

namespace gg
{

	playerSecondaryCompensation::playerSecondaryCompensation(playerData* const own)
		:_auto_player(own),
		_begin(INVALID_TIME),
		_flag(0),
		_gold(0),
		_cardID(INVALID_CARDID),
		_cardID2(INVALID_CARDID)
	{
	}

	void playerSecondaryCompensation::perception(int gold_need, int add_gold)
	{
		if (add_gold < 0)
		{
			return;
		}
		unsigned now = Common::gameTime();
		//LogS << "per..now:" << now << "\t_begin:" << _begin << LogEnd;
		if (_begin != INVALID_TIME && now > _begin && now - _begin <= DAY)
		{
			_gold += add_gold;
			if (_gold >= gold_need && _flag == 0)
			{
				_flag = 2;
			}
			_sign_auto();
			Log(DBLOG::strLogSecondaryDay, Own().getOwnDataPtr(), 2, add_gold, _gold);
		}
	}

	void playerSecondaryCompensation::_auto_update()
	{
		TIME_T now = Common::gameTime();
		Json::Value r;
		r[strMsg][0u] = 0;
		//LogS << "now:" << now << "\tbegin:" << _begin  << "\tflag:" << _flag << LogEnd;
		if (_begin > now || now - _begin > DAY || _flag == 1)
		{
			r[strMsg][1u] = 2;
		}
		else if (now - _begin <= DAY && _flag == 2)
		{
			r[strMsg][1u] = 1;
		}
		else
		{
			r[strMsg][1u] = 0;
		}
		//���ڡ�δ��ȡ���������ʼ�
		if (now > _begin && now - _begin > DAY && _flag == 2 && _cardID != INVALID_CARDID)
		{
			Json::Value json = Json::arrayValue;
			json[0u] = ACTION::lady;
			json[1u] = _cardID;
			json[2u] = 1;
			Json::Value json2 = Json::arrayValue;
			json2[0u] = ACTION::lady;
			json2[1u] = _cardID2;
			json2[2u] = 1;
			Json::Value json_log = Json::arrayValue;
			json_log[0u] = json;
			json_log[1u] = json2;
			EmailPtr e = email_sys.createPackage(EmailDef::SecondaryCompensationReward, Json::nullValue, json_log);
			email_sys.sendToPlayer(Own().ID(), e);
			_flag = 1;
			_auto_save();
		}
		Own().sendToClient(gate_client::secondary_compensation_red_point_resp, r);
		
	}

	void playerSecondaryCompensation::setCardIDFirst(int id)
	{
		_cardID = id; 
		_sign_auto();
	}

	void playerSecondaryCompensation::setCardIDSecond(int id)
	{
		_cardID2 = id;
		_sign_auto();
	}

	void playerSecondaryCompensation::setFlag(int flag) 
	{
		_flag = flag;
		_sign_auto(); 
	}

	void playerSecondaryCompensation::action()
	{
		unsigned now = Common::gameTime();
		//LogS << "role create at:" << now << LogEnd;
		_begin = Common::getNextTimeHMS(now, 5);
		//LogS << "begin is :" << _begin << LogEnd;
		_sign_auto();
	}

	void playerSecondaryCompensation::reflesh()
	{
		TIME_T now = Common::gameTime();
		Json::Value r;
		r[strMsg][0u] = 0;
		/*if (now >= _begin && now - _begin < DAY)
		{
			r[strMsg][1u] = 3;
			Own().sendToClient(gate_client::secondary_compensation_red_point_resp, r);
		}*/
		if (now > _begin && now - _begin >= DAY && now - _begin < 2 * DAY)
		{
			r[strMsg][1u] = 2;
			Own().sendToClient(gate_client::secondary_compensation_red_point_resp, r);
		}
	}

	bool playerSecondaryCompensation::_auto_save()
	{
		mongo::BSONObj key = BSON(strPlayerID << Own().ID());
		mongo::BSONObj obj = BSON("$set" << BSON("SecCompensation" <<
			BSON(strBegin << _begin
			<< strFlag << _flag
			<< strCardID << _cardID
			<< strCardID2 << _cardID2
			<< strGold << _gold)
			));
		return db_mgr.SaveMongo(DBN::dbPlayerCollection, key, obj);
	}

	void playerSecondaryCompensation::setData(mongo::BSONObj& obj)
	{
		if (obj.isEmpty())
		{
			return;
		}
		if (!obj[strBegin].eoo())
		{
			_begin = obj[strBegin].Int();
		}
		if (!obj[strFlag].eoo())
		{
			_flag = obj[strFlag].Int();
		}
		if (!obj[strCardID].eoo())
		{
			_cardID = obj[strCardID].Int();
		}
		if (!obj[strCardID2].eoo())
		{
			_cardID2 = obj[strCardID2].Int();
		}
		if (!obj[strGold].eoo())
		{
			_gold = obj[strGold].Int();
		}
	}

	playerSecondaryCompensation::~playerSecondaryCompensation()
	{
	}
}

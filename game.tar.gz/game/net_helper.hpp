//###################################
//create by Jim
//2015-11-04
//###################################

#pragma once

#include "game_server.h"
#include "commom.h"
#include "playerManager.h"

namespace gg
{
	typedef std::vector<int> _type_batch_list;
	typedef std::vector<playerDataPtr> _type_batch_player_list;
	typedef std::set<int> _type_batch_set;
	typedef boost::unordered_set<int> _type_batch_unordered_set;
	typedef std::map<int, playerDataPtr> _type_batch_map;
	typedef boost::unordered_map<int, playerDataPtr> _type_batch_unordered_map;

	class Batch
	{
	public:
		template<typename _type_list, typename _type_message>
		static void batchSign(const _type_list& vec, _type_message& message, const short protocol);
		template<typename _type_message>
		static void batchAll(_type_message& message, const short protocol);
	};

	const static unsigned PerPlayer = sizeof(int);
	const static unsigned MaxMessage = 32 * ::net::KB;
	const static unsigned UsePlayerMemory = 31 * ::net::KB;
	const static unsigned MaxPlayerPer = UsePlayerMemory / PerPlayer;

	template<typename _type_reslove>
	class _list_reslove {};

	template<>
	class _list_reslove<_type_batch_list>
	{
	public:
		_list_reslove(const _type_batch_list& _val) : _data(_val)
		{
			_cursor = _data.begin();
		}
		bool empty()
		{
			return _data.empty();
		}
		size_t size()
		{
			return _data.size();
		}
		bool more()
		{
			return (_cursor != _data.end());
		}
		int next()
		{
			if (more())
			{
				const int val = *_cursor;
				++_cursor;
				return val;
			}
			throw("no more value ...");
		}
	private:
		const _type_batch_list& _data;
		_type_batch_list::const_iterator _cursor;
	};

	template<>
	class _list_reslove<_type_batch_player_list>
	{
	public:
		_list_reslove(const _type_batch_player_list& _val) : _data(_val)
		{
			_cursor = _data.begin();
		}
		bool empty()
		{
			return _data.empty();
		}
		size_t size()
		{
			return _data.size();
		}
		bool more()
		{
			return (_cursor != _data.end());
		}
		int next()
		{
			if (more())
			{
				const int val = (*_cursor)->ID();
				++_cursor;
				return val;
			}
			throw("no more value ...");
		}
	private:
		const _type_batch_player_list& _data;
		_type_batch_player_list::const_iterator _cursor;
	};

	template<>
	class _list_reslove<_type_batch_set>
	{
	public:
		_list_reslove(const _type_batch_set& _val) : _data(_val)
		{
			_cursor = _data.begin();
		}
		bool empty()
		{
			return _data.empty();
		}
		size_t size()
		{
			return _data.size();
		}
		bool more()
		{
			return (_cursor != _data.end());
		}
		int next()
		{
			if (more())
			{
				const int val = *_cursor;
				++_cursor;
				return val;
			}
			throw("no more value ...");
		}
	private:
		const _type_batch_set& _data;
		_type_batch_set::const_iterator _cursor;
	};

	template<>
	class _list_reslove<_type_batch_unordered_set>
	{
	public:
		_list_reslove(const _type_batch_unordered_set& _val) : _data(_val)
		{
			_cursor = _data.begin();
		}
		bool empty()
		{
			return _data.empty();
		}
		size_t size()
		{
			return _data.size();
		}
		bool more()
		{
			return (_cursor != _data.end());
		}
		int next()
		{
			if (more())
			{
				const int val = *_cursor;
				++_cursor;
				return val;
			}
			throw("no more value ...");
		}
	private:
		const _type_batch_unordered_set& _data;
		_type_batch_unordered_set::const_iterator _cursor;
	};

	template<>
	class _list_reslove<_type_batch_map>
	{
	public:
		_list_reslove(const _type_batch_map& _val) : _data(_val)
		{
			_cursor = _data.begin();
		}
		bool empty()
		{
			return _data.empty();
		}
		size_t size()
		{
			return _data.size();
		}
		bool more()
		{
			return (_cursor != _data.end());
		}
		int next()
		{
			if (more())
			{
				const int val = _cursor->first;
				++_cursor;
				return val;
			}
			throw("no more value ...");
		}
	private:
		const _type_batch_map& _data;
		_type_batch_map::const_iterator _cursor;
	};

	template<>
	class _list_reslove<_type_batch_unordered_map>
	{
	public:
		_list_reslove(const _type_batch_unordered_map& _val) : _data(_val)
		{
			_cursor = _data.begin();
		}
		bool empty()
		{
			return _data.empty();
		}
		size_t size()
		{
			return _data.size();
		}
		bool more()
		{
			return (_cursor != _data.end());
		}
		int next()
		{
			if (more())
			{
				const int val = _cursor->first;
				++_cursor;
				return val;
			}
			throw("no more value ...");
		}
	private:
		const _type_batch_unordered_map& _data;
		_type_batch_unordered_map::const_iterator _cursor;
	};

	template<typename _type_reslove>
	class _messge_reslove {};

	template<>
	class _messge_reslove<Json::Value>
	{
	public:
		_messge_reslove(Json::Value& _val) : _data(_val) {}
		std::string to_string()
		{
			return _data.toIndentString();
		}
	private:
		Json::Value& _data;
	};

	template<>
	class _messge_reslove<qValue>
	{
	public:
		_messge_reslove(qValue& _val) : _data(_val) {}
		std::string to_string()
		{
			return _data.toIndentString();
		}
	private:
		qValue& _data;
	};

	template<>
	class _messge_reslove<std::string>
	{
	public:
		_messge_reslove(std::string& _val) : _data(_val) {}
		std::string to_string()
		{
			return _data;
		}
	private:
		std::string& _data;
	};

	template<typename _type_list, typename _type_message>
	void Batch::batchSign(const _type_list& vec, _type_message& message, const short protocol)
	{
		_list_reslove<_type_list> list_reslove(vec);
		if (list_reslove.empty())return;
		_messge_reslove<_type_message> message_reslove(message);
		std::string _message_string = message_reslove.to_string();
		if (_message_string.length() < 1 || _message_string.length() > MaxMessage)return;
		::net::Msg msg;
		msg.netID = service::process_id::SERVER_BATCH_SIGN_ID;
		msg.protocolID = protocol;
		const unsigned need_max_memory = _message_string.length() + (MaxPlayerPer > list_reslove.size() ? list_reslove.size() : MaxPlayerPer) * PerPlayer;
		char* memory_pointer = (char*)::GNew(need_max_memory);
		msg.strUTF8 = memory_pointer;
		int count = 0;
		while (list_reslove.more())
		{
			int id = list_reslove.next();
			memmove(memory_pointer + count * PerPlayer, &id, PerPlayer);
			++count;
			if (count >= MaxPlayerPer)
			{
				msg.playerID = count;
				msg.packageLen = ::net::MINPACKAGE + count * PerPlayer + _message_string.length();
				memmove(memory_pointer + count * PerPlayer, _message_string.c_str(), _message_string.length());
				game_svr->async_send_to_gate(msg);
				count = 0;
			}
		}
		if (count > 0)
		{
			msg.playerID = count;
			msg.packageLen = ::net::MINPACKAGE + count * PerPlayer + _message_string.length();
			memmove(memory_pointer + count * PerPlayer, _message_string.c_str(), _message_string.length());
			game_svr->async_send_to_gate(msg);
			count = 0;
		}
		::GDelete(memory_pointer);
	}

	template<typename _type_message>
	void Batch::batchAll(_type_message& message, const short protocol)
	{
		_messge_reslove<_type_message> message_reslove(message);
		std::string _message_string = message_reslove.to_string();
		if (_message_string.length() < 1 || _message_string.length() > MaxMessage)return;
		::net::Msg msg(-1, service::process_id::SERVER_BATCH_ID,
			protocol, _message_string);
		game_svr->async_send_to_gate(msg);
	}

}
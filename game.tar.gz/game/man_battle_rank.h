//###################################
//create by Jim
//2016-11-07
//###################################

#pragma once

#include "dbDriver.h"

#define man_battle_rank (*gg::ManBattleRank::_Instance)

namespace gg
{
	namespace NSManRank
	{
		struct Rankey
		{
			Rankey()
			{
				playerID = -1;
				manID = -1;
				battleValue = 0;
				manLV = 0;
			}
			bool operator<(const Rankey& other)const
			{
				if (battleValue != other.battleValue)return battleValue > other.battleValue;
				if (manLV != other.manLV)return manLV > other.manLV;
				const int OwnStar = manID % 100;
				const int OtherStar = other.manID % 100;
				if (OwnStar != OtherStar)return OwnStar > OtherStar;
				if (manID != other.manID)return manID < other.manID;
				return playerID < other.playerID;
			}
			bool operator>(const Rankey& other)const
			{
				return *this < other;
			}
			int playerID;
			int manID;
			unsigned manLV;
			int battleValue;
		};

		struct RankData
		{
			Rankey Key()
			{
				Rankey key;
				key.playerID = playerID;
				key.manID = manID;
				key.manLV = manLV;
				key.battleValue = battleValue;
				return key;
			}
			RankData()
			{
				playerID = -1;
				playerName = "";
				manID = -1;
				fatherID = -1;
				battleValue = 0;
				manLV = 0;
				memset(attri, 0x0, sizeof(attri));
			}
			RankData(playerDataPtr player, playerMan& man)
			{
				setNewData(player, man);
			}
			void setNewData(playerDataPtr player, playerMan& man)
			{
				playerID = player->ID();
				playerName = player->Name();
				fatherID = man.uniqueID();
				manID = man.armyID();
				battleValue = man.battleValue();
				manLV = man.LV();
				man.all_attribute(attri);
			}
			RankData(playerDataPtr player, playerManPtr man)
			{
				setNewData(player, man);
			}
			void setNewData(playerDataPtr player, playerManPtr man)
			{
				playerID = player->ID();
				playerName = player->Name();
				fatherID = man->uniqueID();
				manID = man->armyID();
				battleValue = man->battleValue();
				manLV = man->LV();
				man->all_attribute(attri);
			}
			bool isNull()
			{
				return playerID < 0 || manID < 1 || battleValue < 1;
			}
			qValue toAttriJson()
			{
				qValue json(qJson::qj_array);
				for (unsigned i = 0; i < characterNum; ++i)
				{
					json.append(attri[i]);
				}
				return json;
			}
			inline int rawID() { return manID / 100; }
			inline int uniqueID() { return fatherID; }
			int playerID;
			string playerName;
			int fatherID;
			int manID;
			unsigned manLV;
			int battleValue;
			int attri[characterNum];
		};

		BOOSTSHAREPTR(RankData, ptrRankData);
		STDMAP(Rankey, ptrRankData, RankMap);
		struct FindKey
		{
			explicit FindKey(const int pid = -1,
				const int fid = -1)
			{
				playerID = pid;
				fatherID = fid;
			}
			bool operator<(const FindKey& other)const
			{
				if (fatherID != other.fatherID)return fatherID < other.fatherID;
				return playerID < other.playerID;
			}
			int playerID;
			int fatherID;
		};
		STDMAP(FindKey, ptrRankData, PlayerMap);
	}

	class ManBattleRank
	{
	public:
		ManBattleRank() { isInitial = false; }
		static ManBattleRank* const _Instance;
		void initData();
		DeclareRegFunction(RankList);
		DeclareRegFunction(ManDetail);
	public:
		void updateInfo(playerDataPtr player);
		void updatePlayer(playerDataPtr player, playerMan& man);
		void updatePlayer(playerDataPtr player, playerManPtr man);
	private:
		NSManRank::ptrRankData getData(const int playerID, const int fatherID);

		NSManRank::RankMap Rank;
		NSManRank::PlayerMap Player;

		bool isInitial;
	};
}

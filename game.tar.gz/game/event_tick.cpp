#include "gamer.h"
#include "playerData.h"
#include "gamer_data.h"
#include "game_time.h"
#include "business.h"
#include "heroparty_system.h"
#include "game_server.h"
#include "team_war.h"
#include "compensate.h"
#include "warlords_system.h"
#include "gamer_online_box.h"
#include "chat.h"
#include "task_mgr.h"
#include "task_system.h"
#include "email_system.h"
#include "despatch_task.h"
#include "money_activity.h"
#include "kingfight_system.h"
#include "worldboss_system.h"
#include "kingdomwar_system.h"
#include "discount.h"
#include "gamer_battle_rank.h"
#include "map_war_rank.h"
#include "man_battle_rank.h"
#include "card_rank.h"
#include "business_daily_rank.h"
#include "business_single_rank.h"
#include "business_total_rank.h"
#include "channel_accnouce.h"
#include "festival_system.h"
#include "man_system.h"
#include "expedition_system.h"
#include "lose_formation.h"
#include "kingdom_system.h"
#include "activity_rank_system.h"
#include "inter_game.h"
#include "mall_system.h"
#include "island_activity_system.h"

namespace gg
{
	//����ҽ�ɫ������ʱ��
	void playerData::onCreateRole()
	{
		BuildTeam().checkBuildTeam();//������ѵĽ������
		Builds().checkNewBuild();//����Ƿ�����������
		Builds().openBuildAndLand(true);// �������ǻ��߷������Ľ���
		Tick().classLoad();//������ʼ��������
		Orders().clearOrder();//�ȴ����������ӵľ���

		//���ͻ�ӭ�ʼ�
		EmailPtr e = email_sys.createSystem(EmailDef::WelcomeEmail);
		Email().addEmail(e);

		//
		OpenActivity().init();

		festival_sys.sendInfo(getOwnDataPtr());
		Festival().sendNpc();

		island_activity_sys.sendInfo(getOwnDataPtr());

		//to do here
		SecondaryCompensation().action();//������ȡ��Ů��ʼ��
	}

#define logTimeD(WHAT)\
	WHAT;\
	//LogS << #WHAT << (boost::get_system_time() - begin).total_milliseconds() << LogEnd;

	//����ҵ����ʱ��
	void playerData::onLogin()
	{
		boost::system_time begin = boost::get_system_time();
		logTimeD(Info().Online());
		logTimeD(Info().addVipExp(0));
		logTimeD(CommonOffline().online());

		//�����������
		logTimeD(Tick().loginTick());
		logTimeD(Orders().clearOrder());
		logTimeD(MoneyActivity().clearType());
		logTimeD(Builds());
		logTimeD(BuildTeam().clearTeam());
		logTimeD(Admin().clearAdmin());
		logTimeD(Offline().Online());
		logTimeD(ActivityRank().check_process());

		//��ʱ���Ĳ���
		logTimeD(Orders().addTimer());
		logTimeD(BuildTeam().addTimer());
		logTimeD(Admin().addTimer());
		logTimeD(heroparty_sys.openHeroParty(Info().ID()));
		logTimeD(warlords_sys.updateLogin(getOwnDataPtr()));
		logTimeD(OnlineBox().online());
		logTimeD(worldboss_sys.updateState(getOwnDataPtr()));
		logTimeD(KingDomWarTips().updateAll());
		logTimeD(WarLords().update());
		logTimeD(Expedition().update());
		logTimeD(Patrol().addTimer(Patrol().addTickTimer(), true));

		logTimeD(festival_sys.sendInfo(getOwnDataPtr()));
		logTimeD(Festival().sendNpc());
		logTimeD(island_activity_sys.sendInfo(getOwnDataPtr()));

		logTimeD(Enemy().updateBase());
	}

	//�佫��ս���ı��ʱ��
	void playerData::onBVAlter()
	{
		const int current_value = WarFM().currentBV();//��ǰ��ս��ֵ//���ս����
		Log(DBLOG::strLogPlayerBattleValue, getOwnDataPtr(), -1, current_value);
		Info().motifyMaxBV(current_value);
		//to do
		heroparty_sys.openHeroParty(Info().ID());
		warlords_sys.updatePower(getOwnDataPtr());
		EnemyMgr::shared().upData(getOwnDataPtr());
		TaskMgr::update(getOwnDataPtr(), Task::Power);
		Expedition().recalFM();
		ExpeditionFM().recalFM();
	}

	//��ҷ��͵��������ʱ��
	void Gamer::onPlayerLoginReq(playerDataPtr player)
	{
		if (!player)return;
		season_sys.sendServerInfo(player);
		player->Info()._auto_update();
		player->Res()._auto_update();
		player->War().sendMapData();
		//player->Task().check();
		player->WarFM().updateAll();
		player->InterFM().updateAll();
		player->Man().updateAll();
		player->Card().updateAll();
		player->Items().updateAll();
		player->Tick()._auto_update();
		player->Orders()._auto_update();
		player->OnlineBox()._auto_update();
		player->WarLords().updateRedPoint(false);
		heroparty_sys.sendHeroPartyData(player->ID());
		player->Team()._auto_update();
		player->DailyCard()._auto_update();
		player->Offline()._auto_update();
		discout_sys.sendData(player);
		channel_acc.sendMessage(player);
		player->ActivityRank().update_all();
		player->Market().sendMarketData();//����
		man_sys.SaleTableUpdate(player);
		player->LoseFM()._auto_update();
		player->Research().sendResearch();
		player->Sch()._auto_update();
		inter_svr.sendInterConfig(player);
		gamer.sendSwitchData(player);

		//���
		chat_sys.sendBufferChat(player);
		KingdomWar::SignList::shared().sendChatInfo(player);
	}

	//����ҶϿ����ӻ������ߵ�ʱ��
	void playerData::onOFFLine()
	{
		//War().clearTimerID();
		Orders().delTimer();
		BuildTeam().delTimer();
		Admin().delTimer();
		CarPos().stopMove();
		CarPos().toSave();
		business_sys.playerOFFLine(ID());
		Team().leaveTeam();
		warlords_sys.updateLogout(getOwnDataPtr());
		KingDomWar().detach(-1);
		Patrol().delTimer();
		Patrol().delTickTimer();

		//���߼�¼
		Offline().Off();
		OnlineBox().offline();
		CommonOffline().offline();

		//LOG
		Log(DBLOG::strLogPlayerOnline, getOwnDataPtr(), -1, Common::toStampTime(Info().LastOnline()), Common::toStampTime(Common::gameTime()));
	}

	//����Ҹı����ֵ�ʱ��
	void playerBase::onNameMotify()
	{
		playerDataPtr ptrOwnData = Own().getOwnDataPtr();
		player_mgr.rebindPlayer(usedName, ptrOwnData);
 		heroparty_sys.modifyName(Own().ID());
		warlords_sys.updatePlayerName(ptrOwnData);
		kingfight_sys.updateName(ptrOwnData);
		kingdomwar_sys.updateName(ptrOwnData);
		battle_rank.updatePlayer(ptrOwnData);
		man_battle_rank.updateInfo(ptrOwnData);
		card_rank.updatePlayer(ptrOwnData);
		map_war_rank.updatePlayer(ptrOwnData);
		business_daily_rank.updateInfo(ptrOwnData);
		business_single_rank.updatePlayer(ptrOwnData);
		business_total_rank.updatePlayer(ptrOwnData);
		ExploitRank::shared().update(ptrOwnData, ptrOwnData->KingDomWar().getTotalExploit());
		Expedition::HistoryRankMgr::shared().alterName(ptrOwnData);
		Expedition::DailyRank::shared().alterName(ptrOwnData);
		EnemyMgr::shared().upData(ptrOwnData);
		kingdom_sys.upData(ptrOwnData);
		activity_rank_sys.updateName(ptrOwnData);


		if (LV() >= 80)
		{
			qValue json(qJson::qj_array);
			json.append(usedName);
			json.append(chat_sys.ChatPackageQ(ptrOwnData));
			chat_sys.despatchAll(CHAT::server_motify_name_announce, json);
		}
	}

	//����ҹ��Ҹı��ʱ��
	void playerBase::onSetNation(const Kingdom::NATION old)
	{
		playerDataPtr ptrOwnData = Own().getOwnDataPtr();
		heroparty_sys.modifyNation(Own().ID());
		heroparty_sys.openHeroParty(Own().Info().ID());
		warlords_sys.updatePlayerLv(ptrOwnData, Own().LV());
		battle_rank.updatePlayer(ptrOwnData);
		card_rank.updatePlayer(ptrOwnData);
		business_daily_rank.updateInfo(ptrOwnData);
		business_single_rank.updatePlayer(ptrOwnData);
		business_total_rank.updatePlayer(ptrOwnData);


	}

	//ÿ��Сʱ����
	void playerManager::timePerHourTick(const structTimer& timerData)
	{
		const unsigned now = Common::gameTime();
		const std::tm now_tm = Common::toTm(now);
		const unsigned current_zero_ms = now + HOUR - now_tm.tm_min * MINUTE - now_tm.tm_sec;
		Timer::AddEventTickTime(boostBind(playerManager::timePerHourTick, this, _1), Inter::event_system_common_recall, current_zero_ms);

		//���а�log
		battle_rank.sendLog();
		heroparty_sys.sendLog();
		map_war_rank.sendLog();
	}

	//������ÿ��5���ˢ�µ��ʱ��
	void playerTick::on5ClockTick(const bool is_timer, const unsigned per_timer, const bool is_login /* = false */)
	{
		//���۶�ʱ����������, ͬ��ˢ��
		Own().CardTs().gT = EachGoldTimes;
		Own().CardTs().sT = EachSilverTimes;
		Own().CardTs()._sign_auto();
		//Ѱ�ô�������
		Own().Sch().dailyTick();
		// ˢ�¼���
		Own().Market().resetMarket();
		//ˢ��ó��
		Own().BizTask()._task_times = 0;
		Own().BizTask()._sign_auto();
		Own().Biz()._pirate_hit_times = 0;
		Own().Biz()._boss_hit_times = 0;
		Own().Biz()._boss_box.clear();
		Own().Biz()._sign_auto();
		//���õ�ͼ��ս������ɨ������
		Own().War().reChanllengeTimeDaily();
		//��������
		Own().RescueData().rewardNum = 0;
		Own().RescueData().rewardTimes = 0;
		Own().RescueData()._sign_auto();
		//ȺӢ���̵�ˢ��
		heroparty_sys.flashHero(Own().getOwnDataPtr());
		//��ְٺ»��ȡˢ��
		Own().Info().loginBoxPP();
		Own().Info().resetWarLose();
		//����ս��������
		Own().Team().buyToday = 0;
		Own().Team().challengeTimes = 0;
		Own().Team()._sign_auto();
		//������������
		//Own().KingDom().refConTimes();
		Own().KingDom().dailyTick();
		Own().WorldBoss().dailyTick();
		//���÷�������
		Own().Res().GameShare = 0;
		Own().Res().ReportShare = 10;
		Own().Res()._sign_auto();
		//���þ�������
		Own().Orders().iBuyActionNum = 0;
		Own().Orders()._sign_auto();
		//���ù������
		Own().Malls().resetNum();
		//����ÿ�ջ
		Own().Daily().resetTask();
		//Ⱥ������ÿ������
		Own().WarLords().tick();
		//���߽�������
		Own().OnlineBox().reset();
		//�����Զ������
		Own().Custom().resetTimes();
		Own().Sign().dailyTick();
		//����
		//Own().Affair().clearAffairs();
		Own().Affair().addAffairs(10);
		//�¿�
		Own().DailyCard().clearDead();
		Own().KingDomWarShop().dailyTick();
		Own().KingDomWar().dailyTick();
		Own().KingDomWarTask().reset();
		//Ѳ�η������
		Own().Patrol().restart();
		Own().OpenActivity().dailyTick();
		Own().KingDomWarBox().dailyTick();
		Own().Shops().dailyReset();
		Own().Shadow().tickAt0500();
		Own().Festival().dailyTick();
		Own().ExpeditionFM().tickAt0500();
		Own().RedPaper().clear();
		Own().IslandActivity().dailyTick();

		//���鲹��ˢ�µ�
		Own().Res().resetSupply();
		//�̵�ˢ��

		//ÿ�ճ�ֵ����ˢ��
		Own().DailyInpour().reset();
		//��ȡ��Ů���������Զ���ʧ
		Own().SecondaryCompensation().reflesh();
		Own().OldPlayer().reset();
		Own().MysteryArea().restart();

		//��ͬ��ˢ��
		if (is_timer)
		{
		}
		else//�Ƕ�ʱ���¼�
		{
			if (is_login)//�����¼�
			{
			}
		}
	}

	//������ÿ��8���ˢ�µ��ʱ��
	void playerTick::on8ClockTick(const bool is_timer, const unsigned per_timer, const bool is_login /* = false */)
	{
	}

	//������ÿ��18���ˢ�µ��ʱ��
	void playerTick::on18ClockTick(const bool is_timer, const unsigned per_timer, const bool is_login /* = false */)
	{
		if (is_timer)//��ʱ���ٷ�
		{
			Own().Affair().async_addAffairs(10, Own().Tick().stander18());
		}
		else
		{
			Own().Affair().addAffairs(10, Own().Tick().stander18());
		}
	}

	void playerTick::on22ClockTick(const bool is_timer, const unsigned per_timer, const bool is_login /* = false */)
	{
		Own().Shadow().tickAt2200();
	}

	void playerMapWarMgr::onChangeMaxMapId()
	{
		Own().Builds().openBuildAndLand();
		TaskMgr::update(Own().getOwnDataPtr(), Task::WarCharpter);
	}

	//��ҵȼ������ʱ��
	void playerBase::onLevelAlter(const unsigned old, const unsigned now)
	{
		playerDataPtr ptrOwnData = Own().getOwnDataPtr();
		LVUpLast = Common::gameTime();
		heroparty_sys.openHeroParty(Own().Info().ID());
		Own().Research().sendResearch();
		compensate_sys.tickLevel(old, now);//���ͼ���������
		compensate_sys.tryGetCompenstate(Own().getOwnDataPtr(), old, now);//�鿴���ŵͼ�����
		if (old < 40 && now >= 40)
			warlords_sys.npcBattle(Own().getOwnDataPtr());
		if (old < 70 && now >= 70)
			Own().KingDomWar().sendExploitBox2();

		if (old < 31 && now >= 31)
		{
			Own().Offline().resetOffDayTime();
		}

		// �������ǻ��߷������Ľ���
		Own().Builds().openBuildAndLand();

		task_sys.checkUnopenedTask(ptrOwnData);
		TaskMgr::update(ptrOwnData, Task::Lv);
		warlords_sys.updatePlayerLv(ptrOwnData, old);
		battle_rank.updatePlayer(ptrOwnData);
		ExploitRank::shared().update(ptrOwnData, ptrOwnData->KingDomWar().getTotalExploit());
		EnemyMgr::shared().upData(ptrOwnData);

		//���Ӷ�ʱ���Ա���һ��
		if (now >= PATROL_LEVEL_LIMIT)
		{
			Own().Patrol().addTimer(0);
			Own().Patrol().addTickTimer();
		}
		//���ϵͳ����
		if (now == RED_PAPER_LEVEL_LIMIT)
		{
			Own().RedPaper().setLvDate();
		}
	}

	//���VIP�ȼ����
	void playerBase::onVipAlter(const unsigned old, const unsigned now)
	{
		Own().War().sendMapData();
	}

	void playerBase::onOfficialAlter(const int now)
	{
		// �������ǻ��߷������Ľ���
		Own().Builds().openBuildAndLand();
		TaskMgr::update(Own().getOwnDataPtr(), Task::OfficialLv);
		TaskMgr::update(Own().getOwnDataPtr(), Task::MilitaryRank);
	}

	//����ҽ�Ʊ�ı��ʱ��
	void playerResource::onAlterTicket(const LargerRes old_val)
	{
		if (old_val > Ticket)
		{
			money_sys.tickNum(Own().getOwnDataPtr(), MONEYACTIVITY::money_activity_consume, old_val - Ticket);
			Own().ActivityRank().add_process(ActivityRankEnum::activity_consume_rank, old_val - Ticket);
		}
	}
	//����ҽ�Ҹı��ʱ��
	void playerResource::onAlterGold(const LargerRes old_val)
	{
		if (MALL::BuyType() == MALL::RED_PAPER)
			return;
		if (old_val > Gold)
		{
			money_sys.tickNum(Own().getOwnDataPtr(), MONEYACTIVITY::money_activity_consume, old_val - Gold);
			Own().ActivityRank().add_process(ActivityRankEnum::activity_consume_rank, old_val - Gold);
		}
	}

	//����Ҿ���ֵ�ı��ʱ��
	void playerResource::onAlterAction(const LargerRes old_val)
	{
		if (Action < old_val)
		{
			Own().Info().addExp((old_val - Action) * 10);
			TaskMgr::update(Own().getOwnDataPtr(), Task::UseActionNum, old_val - Action);
		}
		if (Action < MAX_ACTION_NUM && Own().Orders().hasClear())
		{
			if (old_val >= MAX_ACTION_NUM)Own().Orders().addTimer(true);
			else Own().Orders().addTimer();
		}
		if (Action >= MAX_ACTION_NUM && Own().Orders().hasClear())
		{
			Own().Orders().delTimer();
		}
	}

	//����ҹ���ֵ�ı��ʱ��
	void playerResource::onAlterContribution(const int alter_val)
	{
		//Own().KingDom().restoCon(alter_val);
		if (alter_val > 0)
			TaskMgr::update(Own().getOwnDataPtr(), Task::KingdomContributeNum, alter_val);
	}

	// �ı�ͷ��
	void playerBase::onSetFace(const int iOld)
	{
		heroparty_sys.modifyFace(Own().Info().ID());
		TaskMgr::update(Own().getOwnDataPtr(), Task::ChangeFace, 1);
		kingdom_sys.upData(Own().getOwnDataPtr());
	}

	//�������Ա��
	void playerLoseFM::onRecalFormation()
	{
		//�̶���ˢ�¹�����, idΪ8
		Own().WarFM().recalFMValue(8, true);
		Own().InterFM().recalFMValue(8, true);
	}

	//��Ϸ���̽���ǰ
	//��������IO�Ѿ��ر�
	//�������߳�֮����߳��Ѿ��ر�
	//�����Զ�ִ��(�Զ�����, �Զ����µĹ���)ʧЧ
	//�ֶ�����
	void playerManager::gameOver()
	{
		LogS << color_pink("game over dealing ...") << LogEnd;
		LogS << color_pink("user task clear now ...") << LogEnd;
		UserTask::shutDown();
		LogS << color_pink("player data clear now ...") << onlineIDMap.size() << " player to deal ..." << LogEnd;
		for (BHIDMAP::iterator it = onlineIDMap.begin(); it != onlineIDMap.end(); ++it)
		{
			playerDataPtr player = it->second;
			//���߱������߱���
			player->OnlineBox().offline();
			//���߼�¼
			player->Offline().Off();
			//�ص��¼
			player->CarPos().stopMove();
			player->CarPos().toSave();
		}

		LogS << color_pink("player data last save tick now ...") << LogEnd;
		//���һ�ε���
		helper_mgr._over_tick();

		//ϵͳ����
		business_sys.needSaveSharkState();
		//ϵͳ�ͷ�
		LogS << color_pink("system clear now ...") << LogEnd;
		team_war.clearTeamWarSystem();

		//timer clear
		LogS << color_pink("timer event clear now ...") << LogEnd;
		Timer::ClearTimer();
	}


}

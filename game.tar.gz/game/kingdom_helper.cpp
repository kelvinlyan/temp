#include "kingdom_helper.h"
#include "kingdom_system.h"
#include "heroparty_system.h"
#include "chat.h"
#include "email_system.h"
#include "kingfight_system.h"
#include "gamer_battle_rank.h"

namespace gg
{
	const static int KingdomRankSize = 100;
	const static int PrisonerMaxSize = 100;
	const static std::string KeyRank[Kingdom::nation_num] = {"rank0", "rank1", "rank2"};
	const static std::string KeyInfo[Kingdom::nation_num] = {"info0", "info1", "info2"};
	const static std::string KeyPrisoner[Kingdom::nation_num] = {"prisoner0", "prisoner1", "prisoner2"};
	const static std::string KeySalary[Kingdom::nation_num] = {"salary0", "salary1", "salary2"};

	enum{
		PRISONER_CD = 1 * HOUR,
		PRISONER_LOCK_TIME = 1 * HOUR + 30 * MINUTE
	};

	class SalaryReward
	{
		SINGLETON(SalaryReward);
		public:
			const ActionBoxList& getReward(int nation, int title) const
			{
				const KingdomPtr ptr = kingdom_sys.getData(nation);
				int lv = ptr->getLevel();
				if (lv >= _rw.size())
					lv = _rw.size() - 1;
				return _rw[lv][title-1];
			}
		private:
			void loadFile();
		private:
			STDVECTOR(ActionBoxList, RewardList);
			STDVECTOR(RewardList, LV2RewardList);
			LV2RewardList _rw;
	};

	SalaryReward::SalaryReward()
	{
		loadFile();
	}

	void SalaryReward::loadFile()
	{
		Json::Value json = Common::loadJsonFile("./instance/kingfight/salary.json");
		ForEach(Json::Value, it, json)
		{
			RewardList tmp;
			Json::Value& lv2rw = *it;
			ForEach(Json::Value, it2, lv2rw)
				tmp.push_back(actionFormatBox(*it2));
			_rw.push_back(tmp);
		}
	}

	KingdomConstructionConf::KingdomConstructionConf(const Json::Value& info)
	{
		_id = info["id"].asInt();
		_open_lv = info["kingdomLv"].asInt();
		const Json::Value& exps = info["exp"];
		ForEachC(Json::Value, it, exps)
			_exp.push_back((*it).asInt());
		const Json::Value& add_nums = info["addNum"];
		ForEachC(Json::Value, it, add_nums)
			_add_num.push_back((*it).asInt());
	}

	void KingdomContributionConf::load(const Json::Value& info)
	{
		const Json::Value& silver_num = info["silverNum"];
		ForEachC(Json::Value, it, silver_num)
			_silver_cost.push_back((*it).asInt());
		const Json::Value& silver_con = info["silverConNum"];
		ForEachC(Json::Value, it, silver_con)
			_silver_con.push_back((*it).asInt());
		const Json::Value& silver_con_self = info["silverConNumSelf"];
		ForEachC(Json::Value, it, silver_con_self)
			_silver_con_self.push_back((*it).asInt());

		const Json::Value& gold_num = info["goldNum"];
		ForEachC(Json::Value, it, gold_num)
			_gold_cost.push_back((*it).asInt());
		const Json::Value& gold_con = info["goldConNum"];
		ForEachC(Json::Value, it, gold_con)
			_gold_con.push_back((*it).asInt());
		const Json::Value& gold_con_self = info["goldConNumSelf"];
		ForEachC(Json::Value, it, gold_con_self)
			_gold_con_self.push_back((*it).asInt());
	}

	KingdomShopConf::KingdomShopConf(const Json::Value& info)
	{
		_id = info["id"].asInt();
		_consume_con = info["consumeCon"].asInt();
		_buy_times = info["buynum"].asInt();
		_weight = info["weight"].asInt();
		_kingdom_id = (Kingdom::NATION)info["nation"].asInt();
		Json::Value box = info["box"];
		_box = actionFormatBox(box);
	}

	KingdomConstructionData::KingdomConstructionData(int id)
		: _id(id), _total_exp(0)
	{
		init();
	}

	void KingdomConstructionData::load(const mongo::BSONElement& obj)
	{
		_total_exp = obj["t"].Int();
		init();
	}

	mongo::BSONObj KingdomConstructionData::toBSON() const
	{
		return BSON("i" << _id << "t" << _total_exp);
	}

	void KingdomConstructionData::getInfo(Json::Value& info) const
	{
		info.append(_lv);
		info.append(_exp);
	}

	void KingdomConstructionData::init()
	{
		_lv = 0;
		_exp = _total_exp;
		_add_num = 0;
		KingdomConstructionConfPtr conf = kingdom_sys.getConstructionConf(_id);
		if (conf)
		{
			_add_num = conf->_add_num[_lv];
			while (_lv < conf->_exp.size() 
				&& _exp >= conf->_exp[_lv])
			{
				_exp -= conf->_exp[_lv];
				++_lv;
				_add_num = (_lv >= conf->_add_num.size())?
					conf->_add_num.back() : conf->_add_num[_lv];
			}
		}
	}

	void KingdomConstructionData::alterExp(int num)
	{
		_exp += num;
		_total_exp += num;
		KingdomConstructionConfPtr conf = kingdom_sys.getConstructionConf(_id);
		if (conf)
		{
			while (_lv < conf->_exp.size() 
				&& _exp >= conf->_exp[_lv])
			{
				_exp -= conf->_exp[_lv];
				++_lv;
				_add_num = (_lv >= conf->_add_num.size())?
					conf->_add_num.back() : conf->_add_num[_lv];
			}
		}
	}

	bool KingdomConstructionData::upgradeAble() const
	{
		KingdomConstructionConfPtr conf = kingdom_sys.getConstructionConf(_id);
		return (conf && _lv < conf->_exp.size());
	}
	KingdomConInfo::KingdomConInfo(playerDataPtr d)
	{
		_pid = d->ID();
		_cons = d->KingDom().getTotalCon();
	}

	void KingdomConInfo::getInfo(Json::Value& info, int rk) const
	{
		info.append(rk);
		playerDataPtr d = player_mgr.getPlayer(_pid);
		info.append(d? d->Name() : "");
		info.append(_pid);
		info.append(_cons);
		info.append(d? d->KingDom().getJoinTime() : 0);
	}

	KingdomConRank::KingdomConRank()
		: _info(Json::arrayValue)
	{
	}

	std::string KingdomConRank::toBSON() const
	{
		return _info.toIndentString();
	}

	void KingdomConRank::load(const mongo::BSONElement& obj)
	{
		_info = Common::string2json(obj.String());
	}

	void KingdomConRank::tick()
	{
		_info = Json::arrayValue;
		_rk = 0;
		_rank.run(boostBind(KingdomConRank::packageInfo, this, _1), 0, KingdomRankSize);
	}

	void KingdomConRank::packageInfo(const KingdomConInfo& con)
	{
		Json::Value tmp;
		con.getInfo(tmp, ++_rk);
		_info.append(tmp);
	}
	
	void KingdomConRank::update(playerDataPtr d, int old_con)
	{
		if (d->KingDom().getTotalCon() < _rank.minV()
				&& _rank.size() >= KingdomRankSize)
			return;
		if (old_con < _rank.minV())
			old_con = 0;
		KingdomConPtr ptr = Creator<KingdomConInfo>::Create(d);
		_rank.update(ptr, old_con);
	}

	void KingdomConRank::insert(const KingdomConPtr& ptr)
	{
		_rank.update(ptr, 0);
	}

	KingdomInfo::KingdomInfo(Kingdom::NATION n)
		: _nation(n), _strength_rank(2), _hero_party_info(Json::arrayValue)
	{
		_client_param = -1;
		_prisoner_mgr = Creator<PrisonerMgr>::Create(_nation);
		_prisoner_mgr->loadDB();
		_salary_data = Creator<SalaryData>::Create(_nation);
		_salary_data->loadDB();
	}

	void KingdomInfo::init()
	{
		for (unsigned i = Kingdom::CBegin + 1; i < Kingdom::CEnd; ++i)
			_constructions.push_back(Creator<KingdomConstructionData>::Create(i));
		loadInfo();
		loadRank();
	}

	void KingdomInfo::loadInfo()
	{
		mongo::BSONObj key = BSON("key" << KeyInfo[_nation]);
		mongo::BSONObj obj = db_mgr.FindOne(DBN::dbKingdom, key);

		if (obj.isEmpty())
			return;

		_player_num = obj["pn"].Int();
		_announcement = obj["an"].String();
		checkNotEoo(obj["pa"])
			_client_param = obj["pa"].Int();
		std::vector<mongo::BSONElement> ele = obj["cn"].Array();
		for (unsigned i = 0; i < ele.size(); ++i)
		{
			int id = ele[i]["i"].Int();
			if (id <= Kingdom::CBegin || id >= Kingdom::CEnd)
				continue;
			_constructions[id - 1]->load(ele[i]);
		}
	}

	static bool CmpKingdomConPtr(const KingdomConPtr& a, const KingdomConPtr& b)
	{
		if (a->value() == b->value())
			return a->id() < b->id();
		return a->value() > b->value();
	}

	void KingdomInfo::loadRank()
	{
		objCollection objs = db_mgr.Query(DBN::dbPlayerKingdom);
		std::vector<KingdomConPtr> sorted_player;
		ForEachC(objCollection, it, objs)
		{
			int pid = (*it)[strPlayerID].Int();
			int con = (*it)["to"].Int();
			if (con > 0)
			{
				playerDataPtr d = player_mgr.getPlayer(pid);
				if (d->Info().Nation() == _nation)
					sorted_player.push_back(Creator<KingdomConInfo>::Create(pid, con));
			}
		}
		
		std::sort(sorted_player.begin(), sorted_player.end(), CmpKingdomConPtr);
		for (unsigned i = 0; i < sorted_player.size(); ++i)
		{
			if (i >= KingdomRankSize 
				&& sorted_player[i]->value() != sorted_player[i-1]->value())
				break;
			_con_rank.insert(sorted_player[i]);
		}

		mongo::BSONObj key = BSON("key" << KeyRank[_nation]);
		mongo::BSONObj obj = db_mgr.FindOne(DBN::dbKingdom, key);

		if (obj.isEmpty())
			return;
		
		_con_rank.load(obj["cr"]);
		std::string hero_party_rank = obj["hr"].String();
		_hero_party_info = Common::string2json(hero_party_rank);
		_strength_rank = obj["sr"].Int();
	}

	void KingdomInfo::saveInfo()
	{
		mongo::BSONObj key = BSON("key" << KeyInfo[_nation]);
		mongo::BSONObjBuilder obj;
		obj << "key" << KeyInfo[_nation] << "pn" << _player_num << "an" << _announcement
			<< "pa" << _client_param;
		{
			mongo::BSONArrayBuilder b;
			ForEachC(KingdomConstructionDatas, it, _constructions)
				b.append((*it)->toBSON());
			obj << "cn" << b.arr();
		}
		db_mgr.SaveMongo(DBN::dbKingdom, key, obj.obj());
	}

	void KingdomInfo::saveRank()
	{
		mongo::BSONObj key = BSON("key" << KeyRank[_nation]);
		mongo::BSONObjBuilder obj;
		obj << "key" << KeyRank[_nation] << "sr" << _strength_rank
		    << "cr" << _con_rank.toBSON() << "hr" << Common::json2string(_hero_party_info);
		db_mgr.SaveMongo(DBN::dbKingdom, key, obj.obj());
	}
	
	bool KingdomInfo::_auto_save()
	{
		saveInfo();
		return true;
	}

	void KingdomInfo::tickHeroParty()
	{
		_hero_party_info = Json::arrayValue;
		std::vector<heroPartyPtr> vec = heroparty_sys.sendChart(_nation);
		for (unsigned i = 0; i < vec.size(); ++i)
		{
			const heroPartyPtr& ptr = vec[i];
			Json::Value tmp;
			tmp.append(i + 1);
			tmp.append(ptr->sPlayerName);
			tmp.append(ptr->iPlayerID);
			tmp.append(ptr->iHeroNo);
			tmp.append(ptr->uiPlayerLV);
			_hero_party_info.append(tmp);
		}
	}

	void KingdomInfo::tick()
	{
		_con_rank.tick();
		tickHeroParty();
		_strength_rank = kingdom_sys.getStrengthRank(_nation);
		saveRank();
		_salary_data->tick();
	}

	const SalaryState& KingdomInfo::getSalaryState(int pid) const
	{
		return _salary_data->getSalaryState(pid);
	}

	int KingdomInfo::join(playerDataPtr d)
	{
		int res = d->KingDom().addKingdom(_nation);
		if (res == res_sucess)
		{
			++_player_num;
			_sign_save();
		}
		return res;
	}

	int KingdomInfo::getSalary(playerDataPtr d, Json::Value& r)
	{
		const SalaryState& s = _salary_data->getSalaryState(d->ID());
		if (s.state == -1)
		{
			if (d->KingFight().getTitle() != Kingdom::PingMin)
				return err_new_officer_get_salary;
			else
				return err_illedge;
		}
		if (s.state == 1)
			return err_illedge;
		int title = s.title;
		const ActionBoxList& rw = SalaryReward::shared().getReward(d->Info().Nation(), title);
		int res = actionDoBox(d, rw, false);
		if (res == res_sucess)
		{
			r = actionRes();
			_salary_data->clearSalaryState(d->ID());
			Log(DBLOG::strLogKingdom, d, 3, "", "", "", "", "", "", "", r.toIndentString());
			_sign_save();
		}
		else
		{
			Json::Value error_code = actionError();
			res = error_code[0u][1u].asInt();
		}
		return res;
	}

	int KingdomInfo::setAnnouncement(playerDataPtr d, const std::string& str)
	{
		if (d->Info().NationOf_() != Kingdom::GuoWang)
			return err_illedge;
		_announcement = str;
		_sign_save();
		return res_sucess;
	}

	void KingdomInfo::update(playerDataPtr d, int old_con)
	{
		_con_rank.update(d, old_con);
	}

	void KingdomInfo::getConRank(Json::Value& info) const
	{
		info = _con_rank.getInfo();
	}

	void KingdomInfo::getHeroPartyRank(Json::Value& info) const
	{
		info = _hero_party_info;
	}

	void KingdomInfo::getConstruction(Json::Value& info) const
	{
		const static std::string KeyConstruction[] = {"1", "2", "3", "4", "5", "6", "7", "8", "9"};
		Json::Value& ref = info["bi"];
		ref = Json::objectValue;
		ForEachC (KingdomConstructionDatas, it, _constructions)
		{
			const std::string& key = KeyConstruction[(*it)->id() - 1];
			(*it)->getInfo(ref[key]);
		}
		info["rt"] = kingdom_sys.getRate(_strength_rank);
		info["pa"] = _client_param;
	}

	int KingdomInfo::playerCon(playerDataPtr d, int id, int type)
	{
		const KingdomConstructionConfPtr conf = kingdom_sys.getConstructionConf(id);
		if (!conf) return err_illedge;
		if (id != Kingdom::CLevel && getLevel() < conf->_open_lv)
			return err_illedge;
		KingdomConstructionDataPtr ptr = _constructions[id-1];
		if (!ptr) return err_illedge;
		if (id != Kingdom::CLevel && ptr->lv() >= getLevel())
			return err_kingdom_cant_kingdomlv;
		if (!ptr->upgradeAble())
			return err_illedge;
		int exp = 0;
		int res = d->KingDom().playerCon(type, exp);
		if (res == res_sucess)
		{
			int pre_lv = ptr->lv();
			ptr->alterExp(exp);
			d->Daily().tickTask(DAILY::kingdom_contribute);
			Log(DBLOG::strLogKingdom, d, 2, type, id, exp, ptr->lv(), getLevel());
			kingdom_sys.updateBuilding(d);
			if (ptr->lv() != pre_lv)
			{
				qValue bc;
				bc << 1 << id << ptr->lv();
				chat_sys.despatchKingdom(CHAT::server_kingdom_broadcast, _nation, bc);
				if (id == Kingdom::CLevel)
				{
					qValue bc2;
					bc2 << 0 << (int)_nation << ptr->lv();
					chat_sys.despatchAll(CHAT::server_kingdom_broadcast, bc2);
				}
			}		
			_sign_save();
		}
		return res;
	}

	int KingdomInfo::addConstuctionExp(int id, int exp)
	{
		if (id <= Kingdom::CBegin || id >= Kingdom::CEnd)
			return err_illedge;
		KingdomConstructionDataPtr ptr = _constructions[id-1];
		if (!ptr) return err_illedge;
		if (!ptr->upgradeAble())
			return err_illedge;
		ptr->alterExp(exp);
		_sign_save();
		return res_sucess;
	}

	void KingdomInfo::getBaseInfo(Json::Value& info) const
	{
		info["id"] = _nation;
		info["lv"] = getLevel();
		info["ann"] = _announcement; 
		info["st"] = _strength_rank;
		info["ra"] = getRate();
	}

	int KingdomInfo::getTotalLv() const
	{
		int sum = 0;
		ForEachC(KingdomConstructionDatas, it, _constructions)
			sum += (*it)->lv();
		return sum;
	}

	int KingdomInfo::getAddNum(int type) const
	{
		if (type <= Kingdom::CLevel || type >= Kingdom::CEnd)
			return 0;
		return _constructions[type-1]->addNum();
	}

	int KingdomInfo::getLevel() const
	{
		return _constructions[Kingdom::CLevel-1]->lv();
	}

	int KingdomInfo::getRate() const
	{
		return kingdom_sys.getRate(_strength_rank);
	}

	int KingdomInfo::setClientParam(playerDataPtr d, int val)
	{
		if (val < 0 || val > 5)
			return err_illedge;
		if (d->Info().NationOf_() != Kingdom::GuoWang)
			return err_illedge;
		_client_param = val;
		_sign_save();
		return res_sucess;
	}

	int KingdomInfo::addPrisoner(playerDataPtr prisoner, playerDataPtr guard, Json::Value& r)
	{
		return _prisoner_mgr->add(prisoner, guard, r);
	}

	int KingdomInfo::freePrisoner(playerDataPtr prisoner, playerDataPtr guard)
	{
		return _prisoner_mgr->free(prisoner, guard);
	}

	void KingdomInfo::upPrisonerData(playerDataPtr d)
	{
		_prisoner_mgr->upData(d);
	}

	void KingdomInfo::updatePrisoner(playerDataPtr d)
	{
		_prisoner_mgr->update(d);
	}

	unsigned KingdomInfo::isPrisoner(int pid) const
	{
		return _prisoner_mgr->isPrisoner(pid);
	}

	PrisonerCD::PrisonerCD(const mongo::BSONElement& obj, PrisonerMgrPtr ptr)
		: _prisoner_mgr(ptr)
	{
		_pid = obj[strPlayerID].Int();
		_cd = obj["cd"].Int();
	}

	PrisonerCD::PrisonerCD(int pid, unsigned cd, PrisonerMgrPtr ptr)
		: _pid(pid), _cd(cd), _prisoner_mgr(ptr)
	{
	}

	mongo::BSONObj PrisonerCD::toBSON() const
	{
		return BSON(strPlayerID << _pid << "cd" << _cd);
	}

	void PrisonerCD::startTimer()
	{
		Timer::AddEventTickTime(boostBind(PrisonerCD::tick, shared_from_this()), Inter::event_kingdom_prisoner_timer, _cd);
	}

	void PrisonerCD::tick()
	{
		_prisoner_mgr->removeCD(_pid);
	}

	Prisoner::Prisoner(const mongo::BSONElement& obj, PrisonerMgrPtr ptr)
		: _prisoner_mgr(ptr)
	{
		_prisoner_pid = obj[strPlayerID].Int();
		_free_time = obj["ft"].Int();
		_guard_pid = obj["gp"].Int();

		playerDataPtr prisoner = player_mgr.getPlayer(_prisoner_pid);
		playerDataPtr guard = player_mgr.getPlayer(_guard_pid);

		_prisoner_name = prisoner->Name();
		_prisoner_face = prisoner->Info().Face();
		_guard_name = guard->Name();
	}

	Prisoner::Prisoner(playerDataPtr prisoner, playerDataPtr guard, unsigned free_time, PrisonerMgrPtr ptr)
		: _prisoner_mgr(ptr)
	{
		_prisoner_pid = prisoner->ID();
		_free_time = free_time;
		_guard_pid = guard->ID();

		_prisoner_name = prisoner->Name();
		_prisoner_face = prisoner->Info().Face();
		_guard_name = guard->Name();
	}

	mongo::BSONObj Prisoner::toBSON() const
	{
		return BSON(strPlayerID << _prisoner_pid << "ft" << _free_time << "gp" << _guard_pid);
	}

	void Prisoner::getInfo(qValue& q) const
	{
		q << _prisoner_pid << _prisoner_name << _prisoner_face 
			<< _guard_pid << _guard_name << _free_time;
	}
	
	void Prisoner::upData(playerDataPtr d)
	{
		if (d->ID() == _prisoner_pid)
		{
			_prisoner_name = d->Name();
			_prisoner_face = d->Info().Face();
		}
		if (d->ID() == _guard_pid)
		{
			_guard_name = d->Name();
		}
	}

	void Prisoner::startTimer()
	{
		_timer_id = Timer::AddEventTickTime(boostBind(Prisoner::stopTimer, shared_from_this()), Inter::event_kingdom_prisoner_timer, _free_time);
	}

	void Prisoner::stopTimer()
	{
		if (_timer_id)
		{
			_timer_id->delTimer();
			_prisoner_mgr->removePrisoner(_prisoner_pid);
		}
	}

	PrisonerMgr::PrisonerMgr(int nation)
		: _nation(nation)
	{
	}

	void PrisonerMgr::loadDB()
	{
		mongo::BSONObj key = BSON("key" << KeyPrisoner[_nation]);
		mongo::BSONObj obj = db_mgr.FindOne(DBN::dbKingdom, key);

		if (obj.isEmpty())
			return;

		{
			std::vector<mongo::BSONElement> ele = obj["pl"].Array();
			for (unsigned i = 0; i < ele.size(); ++i)
			{
				PrisonerPtr ptr = Creator<Prisoner>::Create(ele[i], upCast<PrisonerMgr>(shared_from_this()));
				ptr->startTimer();
				PrisonerHelper::shared().add(ptr->pid(), ptr->cd());
				_prisoner_list.push_back(ptr);
			}
		}
		{
			std::vector<mongo::BSONElement> ele = obj["pcd"].Array();
			for (unsigned i = 0; i < ele.size(); ++i)
			{
				PrisonerCDPtr ptr = Creator<PrisonerCD>::Create(ele[i], upCast<PrisonerMgr>(shared_from_this()));
				ptr->startTimer();
				_prisoner_cd.push_back(ptr);
			}
		}
	}

	bool PrisonerMgr::_auto_save()
	{
		mongo::BSONObj key = BSON("key" << KeyPrisoner[_nation]);
		mongo::BSONObjBuilder obj;
		obj << "key" << KeyPrisoner[_nation];
		{
			mongo::BSONArrayBuilder b;
			ForEachC(PrisonerList, it, _prisoner_list)
				b.append((*it)->toBSON());
			obj << "pl" << b.arr();
		}
		{
			mongo::BSONArrayBuilder b;
			ForEachC(PrisonerCDList, it, _prisoner_cd)
				b.append((*it)->toBSON());
			obj << "pcd" << b.arr();
		}
		return db_mgr.SaveMongo(DBN::dbKingdom, key, obj.obj());
	}

	unsigned PrisonerMgr::isPrisoner(int pid) const
	{
		ForEachC(PrisonerList, it, _prisoner_list)
		{
			if ((*it)->pid() == pid)
			{
				return (*it)->_free_time;
			}
		}
		return 0;
	}

	int PrisonerMgr::add(playerDataPtr prisoner, playerDataPtr guard, Json::Value& r)
	{
		if (prisoner->ID() == guard->ID())
			return err_illedge;
		if (guard->KingFight().getTitle() > Kingdom::SiTu)
			return err_add_prisoner_need_title_at_least_situ;
		if (prisoner->Info().Nation() != _nation
			|| guard->Info().Nation() != _nation)
			return err_add_other_nation_prisoner;
		if (_prisoner_list.size() >= PrisonerMaxSize)
		{
			update(guard);
			return err_reach_prisoner_limit_size;
		}
		if (prisoner->KingFight().getTitle() != Kingdom::PingMin)
			return err_add_officer_prisoner;
		int rk = battle_rank.getRank(prisoner->ID());
		if (rk > 0 && rk <= 50)
			return err_add_bv_rank_limit_prisoner;
		ForEachC(PrisonerList, it, _prisoner_list)
		{
			if ((*it)->pid() == prisoner->ID())
			{
				update(guard);
				return err_add_same_prisoner;
			}
		}
		unsigned cd = 0;
		if (inProtectedCD(prisoner->ID(), cd))
		{
			r[1u] = cd;
			return err_prisoner_in_protected_cd;
		}
		PrisonerPtr ptr = Creator<Prisoner>::Create(prisoner, guard, Common::gameTime() + PRISONER_LOCK_TIME, upCast<PrisonerMgr>(shared_from_this()));
		ptr->startTimer();
		PrisonerHelper::shared().add(ptr->pid(), ptr->cd());
		_prisoner_list.push_back(ptr);
		prisoner->Info()._sign_update();
		Json::Value pl;
		pl.append(guard->Name());
		EmailPtr e = email_sys.createSystem(EmailDef::PrisonerLocked, pl);
		email_sys.sendToPlayer(prisoner->ID(), e);
		qValue bc;
		bc << 2 << chat_sys.ChatPackageQ(prisoner) << chat_sys.ChatPackageQ(guard);
		chat_sys.despatchKingdom(CHAT::server_kingdom_broadcast, (Kingdom::NATION)_nation, bc);
		update(guard);
		r[1u] = prisoner->Name();
		_sign_save();
		return res_sucess;
	}

	void PrisonerMgr::update(playerDataPtr d)
	{
		qValue m;
		m.append(res_sucess);
		qValue q;
		ForEach(PrisonerList, it, _prisoner_list)	
		{
			qValue tmp;
			(*it)->getInfo(tmp);
			q.append(tmp);
		}
		m.append(q);
		d->sendToClientFillMsg(gate_client::player_prisoner_info_resp, m);
	}

	int PrisonerMgr::free(playerDataPtr prisoner, playerDataPtr guard)
	{
		if (guard->KingFight().getTitle() > Kingdom::SiTu)
			return err_free_prisoner_need_title_at_least_situ;
		if (prisoner->Info().Nation() != _nation
			|| guard->Info().Nation() != _nation)
			return err_illedge;
		ForEach(PrisonerList, it, _prisoner_list)	
		{
			if ((*it)->pid() == prisoner->ID())
			{
				(*it)->stopTimer();
				update(guard);
				return res_sucess;
			}
		}
		update(guard);
		return err_prisoner_not_found;
	}

	void PrisonerMgr::upData(playerDataPtr d)
	{
		ForEach(PrisonerList, it, _prisoner_list)
			(*it)->upData(d);
	}

	void PrisonerMgr::removePrisoner(int prisoner_id)
	{
		ForEach(PrisonerList, it, _prisoner_list)
		{
			if ((*it)->pid() == prisoner_id)
			{
				_prisoner_list.erase(it);
				PrisonerCDPtr ptr = Creator<PrisonerCD>::Create(prisoner_id, Common::gameTime() + PRISONER_CD, upCast<PrisonerMgr>(shared_from_this()));
				ptr->startTimer();
				_prisoner_cd.push_back(ptr);
				PrisonerHelper::shared().remove(prisoner_id);
				playerDataPtr d = player_mgr.getPlayer(prisoner_id);
				if (d) d->Info()._sign_update();
				_sign_save();
				return;
			}
		}
	}

	void PrisonerMgr::removeCD(int pid)
	{
		ForEach(PrisonerCDList, it, _prisoner_cd)
		{
			if ((*it)->pid() == pid)
			{
				_prisoner_cd.erase(it);
				_sign_save();
				return;
			}
		}
	}

	bool PrisonerMgr::inProtectedCD(int pid, unsigned& cd) const	
	{
		ForEachC(PrisonerCDList, it, _prisoner_cd)
		{
			if ((*it)->pid() == pid)
			{
				cd = (*it)->cd();
				return true;
			}
		}
		return false;
	}

	PrisonerHelper::PrisonerHelper(){}

	SalaryState::SalaryState(const mongo::BSONElement& obj)
	{
		state = obj["s"].Int();
		title = obj["t"].Int();
	}

	mongo::BSONObj SalaryState::toBSON(int pid) const
	{
		return BSON("p" << pid << "s" << state << "t" << title);
	}

	SalaryData::SalaryData(int nation)
		: _nation(nation)
	{
	}

	void SalaryData::tick()
	{
		const KingFightManager data = kingfight_sys.getData(_nation);
		std::map<int, int> salary_data = data->getSalaryData();
		_salary_map.clear();
		for (std::map<int, int>::iterator it = salary_data.begin(); it != salary_data.end(); ++it)
		{
			SalaryState s;
			s.state = 0;
			s.title = it->second;
			_salary_map.insert(make_pair(it->first, s));
		}
		_sign_save();
	}

	bool SalaryData::_auto_save()
	{
		mongo::BSONObj key = BSON("key" << KeySalary[_nation]);
		mongo::BSONObjBuilder obj;
		obj << "key" << KeySalary[_nation];
		{
			mongo::BSONArrayBuilder b;
			ForEachC(PID2SalaryTitle, it, _salary_map)
				b.append(it->second.toBSON(it->first));
			obj << "ps" << b.arr();
		}
		return db_mgr.SaveMongo(DBN::dbKingdom, key, obj.obj());
	}

	void SalaryData::loadDB()
	{
		mongo::BSONObj key = BSON("key" << KeySalary[_nation]);
		mongo::BSONObj obj = db_mgr.FindOne(DBN::dbKingdom, key);

		if (obj.isEmpty())
		{
			tick();
			return;
		}

		{
			std::vector<mongo::BSONElement> ele = obj["ps"].Array();
			for (unsigned i = 0; i < ele.size(); ++i)
				_salary_map.insert(make_pair(ele[i]["p"].Int(), SalaryState(ele[i])));
		}
	}

	void SalaryData::removeSalaryTitle(int pid)
	{
		_salary_map.erase(pid);
		_sign_save();
	}

	void SalaryData::clearSalaryState(int pid)
	{
		PID2SalaryTitle::iterator it = _salary_map.find(pid);
		if (it != _salary_map.end())
		{
			it->second.state = 1;
			_sign_save();
		}
	}
}

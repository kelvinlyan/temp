#include "player_enemy.h"
#include "playerManager.h"

namespace gg
{
	Enemy::Enemy(playerDataPtr d)
	{
		_pid = d->ID();
		_name = d->Name();
		_nation = d->Info().Nation();
		_lv = d->LV();
		_bv = d->WarFM().currentBV();
		_protected_cd = d->WarLords().getCd();
	}

	void Enemy::getInfo(qValue& q) const
	{
		q << _pid << _name << _nation << _lv << _bv << _protected_cd;
	}

	void Enemy::upData(playerDataPtr d)
	{
		_name = d->Name();
		_lv = d->LV();
		_bv = d->WarFM().currentBV();
		_protected_cd = d->WarLords().getCd();
	}

	EnemyMgr::EnemyMgr()
	{
	}

	void EnemyMgr::upData(playerDataPtr d)
	{
		EnemyMap::iterator it = _enemy_map.find(d->ID());
		if (it == _enemy_map.end())
			return;
		it->second->upData(d);
	}
	
	EnemyPtr EnemyMgr::getEnemy(int pid)
	{
		EnemyMap::iterator it = _enemy_map.find(pid);
		if (it != _enemy_map.end())
			return it->second;

		playerDataPtr d = player_mgr.getPlayer(pid);
		if (!d) return EnemyPtr();
		EnemyPtr ptr = Creator<Enemy>::Create(d);
		_enemy_map.insert(make_pair(pid, ptr));
		return ptr;
	}

	playerEnemy::playerEnemy(playerData* const own)
		: _auto_player(own)
	{
		_temp_enemy_list_id.clear();
	}

	void playerEnemy::setData(mongo::BSONObj& obj)
	{
		if (obj.isEmpty()) 
			return;

		checkNotEoo(obj["el"])
		{
			std::vector<mongo::BSONElement> ele = obj["el"].Array();
			_temp_enemy_list_id.reserve(ele.size());
			for (unsigned i = 0; i < ele.size(); ++i)
			{
				_temp_enemy_list_id.push_back(ele[i].Int());
			}
		}
	}

	bool playerEnemy::_auto_save()
	{
		mongo::BSONObj key = BSON(strPlayerID << Own().ID());
		mongo::BSONObjBuilder obj;
		{
			mongo::BSONArrayBuilder b;
			ForEachC(EnemyList, it, _enemy_list)
				b.append((*it)->pid());
			obj << "el" << b.arr();
		}
		mongo::BSONObj set_obj = BSON("$set" << BSON("Enemy" << obj.obj()));
		return db_mgr.SaveMongo(DBN::dbPlayerCollection, key, set_obj);
	}

	void playerEnemy::_auto_update()
	{
		update();
		updateBase();
	}

	void playerEnemy::classFinal()
	{
		for (unsigned i = 0; i < _temp_enemy_list_id.size(); ++i)
		{
			int pid = _temp_enemy_list_id[i];
			EnemyPtr ptr = EnemyMgr::shared().getEnemy(pid);
			if (!ptr) continue;
			_enemy_list.push_back(ptr);
		}
		_temp_enemy_list_id.clear();
	}

	int playerEnemy::add(playerDataPtr target)
	{
		if (target->ID() == Own().ID()
			|| target->Info().Nation() == Own().Info().Nation())
			return err_illedge;
		if (_enemy_list.size() >= 50)
			return err_illedge;
		ForEachC(EnemyList, it, _enemy_list)
		{
			if (target->ID() == (*it)->pid())
				return err_illedge;
		}
		_enemy_list.push_back(EnemyMgr::shared().getEnemy(target->ID()));
		updateBase();
		_sign_save();
		return res_sucess;
	}

	int playerEnemy::remove(playerDataPtr target)
	{
		ForEach(EnemyList, it, _enemy_list)
		{
			if (target->ID() == (*it)->pid())
			{
				_enemy_list.erase(it);
				_sign_auto();
				return res_sucess;
			}
		}
		return err_illedge;
	}

	void playerEnemy::update()
	{
		qValue m;
		m.append(res_sucess);
		qValue q(qJson::qj_object);
		qValue el;
		ForEachC(EnemyList, it, _enemy_list)
		{
			qValue tmp;
			(*it)->getInfo(tmp);
			el.append(tmp);
		}
		q.addMember("el", el);
		m.append(q);
		Own().sendToClientFillMsg(gate_client::warlords_enemy_info_resp, m);
	}

	void playerEnemy::updateBase()
	{
		qValue m;
		m.append(res_sucess);
		qValue q(qJson::qj_object);
		qValue el;
		ForEachC(EnemyList, it, _enemy_list)
			el.append((*it)->pid());
		q.addMember("el", el);
		m.append(q);
		Own().sendToClientFillMsg(gate_client::warlords_enemy_base_resp, m);
	}
}

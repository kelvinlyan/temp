//###################################
//create by Lin Xing
//2016-9-16
//###################################

#pragma once

#include "action_system.h"
#include "commom.h"
#include <vector>
#include <string>
#include <boost/shared_ptr.hpp>

#define ODDS_SUM 10000

namespace gg {

	namespace patrol {

		enum EventType
		{
			AnswerQuestionEvent = 100, //���������¼�
			SleepEvent = 101, //���������¼�
			FireEyeEvent = 102, //���۽������¼�
			FishEvent = 103, //�����¼�
			EnjoyFlowerEvent = 104, //�ͻ��¼�
			FingerGuessEvent = 105, //��ȭ�¼�
			AnecdoteEvent = 106, //Ѳ������
			EndBoxEvent = 107, //�յ㱦��
			PokerEvent = 108,//�ƻ�����
			EventEnd = 109 //��Ч���¼�
		};

		enum FishResultType
		{
			GoodLuck = 20, //��������
			BeautyBesides = 21, //�����ڲ�
			BeautyGitf = 22 //��������
		};

		enum EnjoyFlowerProcess
		{
			MeetScholar = 10, //ż�����
			HoneyTalk = 11, //�黰����
			BeautyAgain = 12, //��������
			PlayOnly = 13 //��ɽ��ˮ
		};

		//�ƻ�����
		enum PokerCalc
		{
			SameCard = 30, //�ҳ���ͬ����
			AdjacentCard = 31,//�ҳ����ڵ���
			BiggerCard = 32 //�ҳ��ȶԷ������
		};

		enum StateType
		{
			PatrolUninit = 201,//δ����Ѳ��
			PatrolPenddingDice = 202, //�ȴ�������
			PatrolPenddingEvent = 203, //�ȴ���ȡ��ǰ�¼�
			PatrolPendingBox = 204, //�ȴ���ȡ��ȡ
		};

		//��ͨ�ñ�������
		typedef struct _boxSingle
		{
			int id;
			ActionBoxList box;
			std::string strBox;
			Json::Value jsonBox;
			int weight;
		} BoxSingle;

		typedef struct _questionSingle
		{
			int id;
			struct
			{
				std::string topic;
				std::vector<std::string> options;
				int ans;
			} subject;
			ActionBoxList box;
			ActionBoxList doubleBox;
			Json::Value jsonBox;
			std::string strBox;
			Json::Value jsonDoubleBox;
			std::string strDoubleBox;
		} QuestionSingle;

		//0. �ʴ��¼�
		typedef struct _asnwerQuestionConfig
		{
			std::vector<QuestionSingle> questions;
		} AQConfig;

		//1. �����¼�
		typedef struct _sleepConfig
		{
			std::vector<BoxSingle> beauty;
			std::vector<Json::Value> rawBox; //ԭʼbox��json����
			//std::vector<int> odds;���ѡ��6�������ʲ�������
			std::vector<int> odds;
		} SleepConfig;

		//���۽𾦵���
		typedef struct _eyeSingle
		{
			int id;
			ActionBoxList box;
			ActionBoxList doubleBox;
			Json::Value jsonBox;
			std::string strBox;
			Json::Value jsonDoubleBox;
			std::string strDoubleBox;
			int weight;
		} EyeSingle;

		//2. ���۽��¼�
		typedef struct _eyeConfig
		{
			std::vector<EyeSingle> fires;
			std::vector<int> odds;
		} EyeConfig;

		//3. �����¼�
		typedef struct _fishConfig
		{
			std::vector<int> odds;
			std::vector<BoxSingle> luck;
			std::vector<BoxSingle> gift;
			//�ۻ�����
			std::vector<int> oddsLuck;
			std::vector<int> oddsGift;
			ActionBoxList emptyBox;
			std::string strEmptyBox;
			Json::Value jsonEmptyBox;

		} FishConfig;

		//4. �ͻ��¼�����
		typedef struct _enjoyFlowerConfig
		{
			std::vector<int> odds;
			std::vector<BoxSingle> meetBoxes;
			std::vector<BoxSingle> talkBoxes;
			std::vector<BoxSingle> againBoxes;
			std::vector<int> meetOdds;
			std::vector<int> talkOdds;
			std::vector<int> againOdds;

			ActionBoxList boxMeet;
			ActionBoxList boxTalk;
			ActionBoxList boxAgain;
			ActionBoxList boxPlay;
			Json::Value jsonMeet;
			Json::Value jsonTalk;
			Json::Value jsonAgain;
			Json::Value jsonPlay;
			std::string strMeet;
			std::string strTalk;
			std::string strAgain;
			std::string strPlay;
		} EnjoyFlowerConfig;

		//5. ��ȭ�¼�����
		typedef struct _fingerGuessConfig
		{
			std::vector<BoxSingle> succ;
			std::vector<BoxSingle> fail;
			std::vector<int> succOdds;
			std::vector<int> failOdds;
		} FingerGuessConfig;

		//Ѳ�����µ���
		typedef struct _anecdoteSingle
		{
			int id;
			struct
			{
				std::string topic;
				std::vector<std::string> options;
			} subject;
			std::vector<ActionBoxList> boxes;
			std::vector<std::string> strBoxes;//ԭ���ı�����Ϣ
			std::vector<Json::Value> jsonBoxes;
			int weight;
		} AnecdoteSingle;

		//6. Ѳ����������
		typedef struct _anecdoteConfig
		{
			std::vector<AnecdoteSingle> anecdotes;
			std::vector<int> odds;
		} AnecdoteConfig;

		//�ƻ�����
		typedef struct _pokerCalculus
		{
			std::vector<int> odds;
			std::vector<EyeSingle> boxes;
			std::vector<int> subOdds;
		} PokerConfig;

		//. �յ㱦��
		typedef struct _terminalBox
		{
			std::vector<BoxSingle> boxes;
			std::vector<int> odds;
		} EndBoxConfig;

		class sleep_node
		{
		public:
			int idx;
			int weight;
			int sums;
		};

		//���ݸ��ʷ�����Ӧ���±�
		size_t getProbIndex(const std::vector<int>& odds, int sum = ODDS_SUM);

	}///namespace patrol

	BOOSTSHAREPTR(patrol::AQConfig, AQConfigPtr);
	BOOSTSHAREPTR(patrol::AnecdoteConfig, AnecdoteConfigPtr);
	BOOSTSHAREPTR(patrol::FingerGuessConfig, FingerGuessConfigPtr);
	BOOSTSHAREPTR(patrol::EnjoyFlowerConfig, EnjoyFlowerConfigPtr);
	BOOSTSHAREPTR(patrol::FishConfig, FishConfigPtr);
	BOOSTSHAREPTR(patrol::EyeConfig, EyeConfigPtr);
	BOOSTSHAREPTR(patrol::SleepConfig, SleepConfigPtr);
	BOOSTSHAREPTR(patrol::EndBoxConfig, EndBoxConfigPtr);
	BOOSTSHAREPTR(patrol::PokerConfig, PokerConfigPtr);

	BOOSTSHAREPTR(patrol::sleep_node, SleepNodePtr);
	typedef std::list<SleepNodePtr> SleepNodeList;

	class patrol_event;
	class patrol_fish_event;
	class patrol_flower_event;
	class patrol_aq_event;
	class patrol_finger_event;
	class patrol_anecdote_event;
	class patrol_sleep_event;
	class patrol_eye_event;
	class patrol_end_event;
	class patrol_poker_event;

	BOOSTSHAREPTR(patrol_event, EventPtr);
	BOOSTSHAREPTR(patrol_fish_event, FishEventPtr);
	BOOSTSHAREPTR(patrol_flower_event, FlowerEventPtr);
	BOOSTSHAREPTR(patrol_aq_event, AQEventPtr);
	BOOSTSHAREPTR(patrol_finger_event,FingerEventPtr);
	BOOSTSHAREPTR(patrol_anecdote_event, AnecdoteEventPtr);
	BOOSTSHAREPTR(patrol_sleep_event, SleepEventPtr);
	BOOSTSHAREPTR(patrol_eye_event, EyeEventPtr);
	BOOSTSHAREPTR(patrol_end_event, EndEventPtr);
	BOOSTSHAREPTR(patrol_poker_event, PokerEventPtr);

	//���ú���
	Json::Value parseJson(Json::Value json_box);
	std::string parseJsonBox(Json::Value json_box);
	void combineJsonBox(const Json::Value& from, Json::Value& to);//�ϲ�����ԭʼ��(�����ļ��еĸ�ʽ)Box

	//static_pointer_cast
	//�����¼���Ļ���
	class patrol_event
	{
	public:
		patrol_event(patrol::EventType type);
		patrol::EventType Type();//�¼�����
		virtual ActionBoxList getBox(int flag = 0) = 0;//��ñ���
		virtual void getDetail(Json::Value& r) = 0;//ǰ�����
		virtual std::string getStr(int flag = 0) = 0;//Log��� 
		virtual Json::Value getBoxJson(int flag = 0) = 0;//ԭʼLog���Json
		virtual int subType() { return -1; } //������
		virtual ~patrol_event();
	protected:
		patrol::EventType _type;
	};

	class patrol_fish_event : public patrol_event
	{
	public:
		patrol_fish_event(FishConfigPtr config, patrol::EventType type = patrol::FishEvent);
		patrol_fish_event(FishConfigPtr config, int subType, int idx, patrol::EventType type = patrol::FishEvent);
		virtual void getDetail(Json::Value& r);
		virtual ActionBoxList getBox(int flag = 0);
		virtual std::string getStr(int flag = 0);
		virtual Json::Value getBoxJson(int flag = 0);
		virtual int subType() { return _sub_type; }
		int getIndex() { return _idx; }
	private:
		patrol::FishResultType _sub_type;
		FishConfigPtr _config;
		int _idx;
	};

	class patrol_flower_event : public patrol_event
	{
	public:
		patrol_flower_event(EnjoyFlowerConfigPtr config, patrol::EventType type = patrol::EnjoyFlowerEvent);
		patrol_flower_event(EnjoyFlowerConfigPtr config, int subType, int idx, patrol::EventType type = patrol::EnjoyFlowerEvent);
		virtual int subType() { return _sub_type; }
		virtual ActionBoxList getBox(int flag = 0);
		virtual std::string getStr(int flag = 0);
		virtual Json::Value getBoxJson(int flag = 0);
		virtual void getDetail(Json::Value& r);
		int getIndex() { return _idx; }
	private:
		patrol::EnjoyFlowerProcess _sub_type;
		EnjoyFlowerConfigPtr _config;
		int _idx;
	};

	class patrol_aq_event : public patrol_event
	{
	public:
		patrol_aq_event(AQConfigPtr config, patrol::EventType type = patrol::AnswerQuestionEvent);
		patrol_aq_event(AQConfigPtr config, int idx, patrol::EventType type = patrol::AnswerQuestionEvent);
		virtual ActionBoxList getBox(int flag = 0);
		virtual void getDetail(Json::Value& r);
		virtual std::string getStr(int flag = 0);
		virtual Json::Value getBoxJson(int flag = 0);
		int getIndex() { return _idx; }
	private:
		AQConfigPtr _config;
		int _idx;
	};

	class patrol_finger_event : public patrol_event
	{
	public:
		patrol_finger_event(FingerGuessConfigPtr config, patrol::EventType type = patrol::FingerGuessEvent);
		patrol_finger_event(FingerGuessConfigPtr config, int idxSucc, int idxFail, patrol::EventType type = patrol::FingerGuessEvent);
		virtual ActionBoxList getBox(int flag = 0);
		virtual void getDetail(Json::Value& r);
		virtual std::string getStr(int flag = 0);
		virtual Json::Value getBoxJson(int flag = 0);
		int getSuccIndex() { return _idxSucc; }
		int getFailIndex() { return _idxFail; }
	private:
		FingerGuessConfigPtr _config;
		int _idxSucc;
		int _idxFail;
	};

	class patrol_anecdote_event : public patrol_event
	{
	public:
		patrol_anecdote_event(AnecdoteConfigPtr config, patrol::EventType type = patrol::AnecdoteEvent);
		patrol_anecdote_event(AnecdoteConfigPtr config, int idx, patrol::EventType type = patrol::AnecdoteEvent);
		virtual ActionBoxList getBox(int flag = 0);
		virtual void getDetail(Json::Value& r);
		virtual std::string getStr(int flag = 0);
		virtual Json::Value getBoxJson(int flag = 0);
		int getIndex() { return _idx; }
	private:
		AnecdoteConfigPtr _config;
		int _idx;
	};

	class patrol_sleep_event : public patrol_event
	{
	public:
		patrol_sleep_event(SleepConfigPtr config, patrol::EventType type = patrol::SleepEvent);
		patrol_sleep_event(SleepConfigPtr config, const std::vector<int>& ids, patrol::EventType type = patrol::SleepEvent);
		virtual ActionBoxList getBox(int flag = 0);
		virtual void getDetail(Json::Value& r);
		virtual std::string getStr(int flag = 0);
		virtual Json::Value getBoxJson(int flag = 0);
		std::vector<int> getIndexs() { return _ids; }
	private:
		SleepConfigPtr _config;
		std::vector<int> _ids;
		SleepNodeList _list;
		ActionBoxList _box;
		Json::Value _jsonBox;
		std::string _strBox;
	private:
		void buildList();
		//��N��ѡ���в��ظ���ѡ��6�����㷨
		void selectListItem();
	};

	class patrol_eye_event : public patrol_event
	{
	public:
		patrol_eye_event(EyeConfigPtr config, patrol::EventType type = patrol::FireEyeEvent);
		patrol_eye_event(EyeConfigPtr config, int idx, patrol::EventType type = patrol::FireEyeEvent);
		virtual ActionBoxList getBox(int flag = 0);
		virtual void getDetail(Json::Value& r);
		virtual std::string getStr(int flag = 0);
		virtual Json::Value getBoxJson(int flag = 0);
		int getIndex() { return _idx; }
	private:
		EyeConfigPtr _config;
		int _idx;
	};

	class patrol_poker_event : public patrol_event
	{
	public:
		patrol_poker_event(PokerConfigPtr config, patrol::EventType type = patrol::PokerEvent);
		patrol_poker_event(PokerConfigPtr config, int subType, int idx, patrol::EventType type = patrol::PokerEvent);
		virtual ActionBoxList getBox(int flag = 0);
		virtual void getDetail(Json::Value& r);
		virtual std::string getStr(int flag = 0);
		virtual Json::Value getBoxJson(int flag = 0);
		int getIndex() { return _idx; };
		virtual int subType() { return _sub_type; }
	private:
		PokerConfigPtr _config;
		patrol::PokerCalc _sub_type;
		int _idx;
	};

	class patrol_end_event : public patrol_event
	{
	public:
		patrol_end_event(EndBoxConfigPtr config, patrol::EventType type = patrol::EndBoxEvent);
		patrol_end_event(EndBoxConfigPtr config, int idx, patrol::EventType type = patrol::EndBoxEvent);
		virtual ActionBoxList getBox(int flag = 0);
		virtual void getDetail(Json::Value& r);
		Json::Value getJson();
		virtual std::string getStr(int flag = 0);
		virtual Json::Value getBoxJson(int flag = 0);
		int getIndex() { return _idx; }
	private:
		EndBoxConfigPtr _config;
		int _idx;

	};

}


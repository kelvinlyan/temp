#include "player_worldboss.h"
#include "worldboss_system.h"
#include "dbDriver.h"
//#include "king_fight.h"
#include "task_mgr.h"
#include "kingdom_def.h"

namespace gg
{
	playerWorldBoss::playerWorldBoss(playerData* const own)
		: _auto_player(own), _cd(0), _record_day(0), _damage(0), _clean_cd_times(0), _incent_num(0), _nation_incented(false)
		, _report_mgr(10), _rank(0), _damage_silver(0), _total_silver(0), _total_gold(0), _rank_reward(Json::arrayValue), _damage_rate(0.0)
	{
	}

	void playerWorldBoss::classLoad()
	{
		mongo::BSONObj key = BSON(strPlayerID << Own().ID());
		mongo::BSONObj obj = db_mgr.FindOne(DBN::dbPlayerWorldBoss, key);
		if (obj.isEmpty())
			return;
		checkNotEoo(obj["cd"])
			_cd = obj["cd"].Int();
		checkNotEoo(obj["rd"])
			_record_day = obj["rd"].Int();
		checkNotEoo(obj["dm"])
			_damage = obj["dm"].Int();
		checkNotEoo(obj["in"])
			_incent_num = obj["in"].Int();
		checkNotEoo(obj["ct"])
			_clean_cd_times = obj["ct"].Int();
		checkNotEoo(obj["ni"])
			_nation_incented = obj["ni"].Bool();
		checkNotEoo(obj["rk"])
			_rank = obj["rk"].Int();
		checkNotEoo(obj["sl"])
			_damage_silver = obj["sl"].Int();
		checkNotEoo(obj["ts"])
			_total_silver = obj["ts"].Int();
		checkNotEoo(obj["tg"])
			_total_gold = obj["tg"].Int();
		checkNotEoo(obj["rl"])
			_report_mgr.load(obj["rl"]);
		checkNotEoo(obj["dr"])
			_damage_rate = obj["dr"].Double();
		checkNotEoo(obj["rr"])
			_rank_reward = Common::string2json(obj["rr"].String());
	}

	bool playerWorldBoss::_auto_save()
	{
		mongo::BSONObj key = BSON(strPlayerID << Own().ID());
		mongo::BSONObjBuilder obj;
		obj << strPlayerID << Own().ID() << "cd" << _cd << "rd" << _record_day
		 	<< "dm" << _damage << "in" << _incent_num << "ct" << _clean_cd_times
			<< "ni" << _nation_incented << "rk" << _rank << "rl" << _report_mgr.toBSON()
			<< "sl" << _damage_silver << "ts" << _total_silver << "rr" << Common::json2string(_rank_reward)
			<< "dr" << _damage_rate << "tg" << _total_gold;
		return db_mgr.SaveMongo(DBN::dbPlayerWorldBoss, key, obj.obj());
	}

	void playerWorldBoss::_auto_update()
	{
	}

	void playerWorldBoss::getUIInfo(Json::Value& info)
	{
		checkAndUpdate();
		info["in"] = worldboss_sys.getIncentNum(Own().getOwnDataPtr());
		info["ras"] = worldboss_sys.getRank(Own().getOwnDataPtr());
		info["gn"] = _clean_cd_times;
		info["cd"] = _cd;
		info["das"] = _damage_rate;
	}

	void playerWorldBoss::getIncentInfo(Json::Value& info)
	{
		checkAndUpdate();
		info["si"] = _incent_num;
		info["ii"] = _nation_incented;
	}

	void playerWorldBoss::getReportInfo(Json::Value& info)
	{
		checkAndUpdate();
		_report_mgr.getInfo(info);
	}

	bool playerWorldBoss::inCd()
	{
		checkAndUpdate();
		return Common::gameTime() < _cd;
	}

	int playerWorldBoss::cleanCd()
	{
		checkAndUpdate();	
		int cost = worldboss_sys.getConfig().getCleanCdCost(_clean_cd_times);
		if (Own().Res().getCash() < cost)
			return err_gold_not_enough;
		Own().Res().alterCash(0 - cost);
		++_clean_cd_times;
		_cd = 0;
		Log(DBLOG::strLogWorldBoss, Own().getOwnDataPtr(), 0, _clean_cd_times, cost);
		_sign_save();
		return res_sucess;
	}

	int playerWorldBoss::getDamage()
	{
		checkAndUpdate();
		return _damage;
	}

	int playerWorldBoss::getRank()
	{
		checkAndUpdate();
		return _rank;
	}

	void playerWorldBoss::setRank(int rk, const Json::Value& rank_reward)
	{
		checkAndUpdate();
		_rank = rk;
		_rank_reward = rank_reward;
		_sign_save();
	}

	int playerWorldBoss::getIncentNum()
	{
		checkAndUpdate();
		return _incent_num;
	}

	int playerWorldBoss::doneBattle(int m, int d, int b, const std::string& rep_id)
	{
		checkAndUpdate();
		int tmp = _damage;
		_cd = Common::gameTime() + 30;
		_damage += d;
		_damage_rate = worldboss_sys.getDamageRate(_damage);
		TaskMgr::update(Own().getOwnDataPtr(), Task::WorldBossDamage, d);
		_report_mgr.push(Creator<WorldBoss::OwnReport>::Create(d, m, b, rep_id));
		_sign_save();
		return tmp;
	}

	void playerWorldBoss::checkAndUpdate()
	{
		if (worldboss_sys.getCurrentRecordDay() != _record_day)
		{
			_record_day = worldboss_sys.getCurrentRecordDay();
			_damage = 0;
			_damage_rate = 0.0;
			_clean_cd_times = 0;
			_rank = 0;
			_damage_silver = 0;
			_total_silver = 0;
			_total_gold = 0;
			_report_mgr.clear();
			_rank_reward = Json::arrayValue;
		}
	}


	int playerWorldBoss::addPersonIncent(int resource)
	{
		checkAndUpdate();

		if (_incent_num >= worldboss_sys.getConfig().getIncentMaxId(WorldBoss::PersonType))
			return err_illedge;

		int cost = worldboss_sys.getConfig().getIncentCost(WorldBoss::PersonType, resource, _incent_num);

		if (resource == WorldBoss::UseMerit)
		{
			if (Own().Res().getMerit() < cost)
				return err_merit_not_enough;
			Own().Res().alterMerit(0 - cost);
		}
		else
		{
			if (Own().Res().getCash() < cost)
				return err_gold_not_enough;
			Own().Res().alterCash(0 - cost);
		}

		int prev_incent = _incent_num;
		int succ = 0;
		double suc_rate = worldboss_sys.getConfig().getIncentSucRate(WorldBoss::PersonType, _incent_num);
		if (Common::randomOk(suc_rate))
		{
			succ = 1;
			++_incent_num;
			_sign_save();
		}

		if (resource == WorldBoss::UseMerit)
			Log(DBLOG::strLogWorldBoss, Own().getOwnDataPtr(), 1, cost, succ, prev_incent, _incent_num);
		else
			Log(DBLOG::strLogWorldBoss, Own().getOwnDataPtr(), 2, cost, succ, prev_incent, _incent_num);

		TaskMgr::update(Own().getOwnDataPtr(), Task::WorldBossIncentTimes, 1);

		worldboss_sys.getParam()["is"] = succ;
		worldboss_sys.getParam()["it"] = (int)WorldBoss::PersonType;
		return res_sucess;
	}

	void playerWorldBoss::addGold(int& gold)
	{
		checkAndUpdate();
		gold = Own().Res().alterCash(gold);
	
	}

	void playerWorldBoss::addSilver(int& silver, bool damage)
	{
		checkAndUpdate();
		silver = Own().Res().alterSilver(silver);
		if (damage)
			_damage_silver += silver;
		_total_silver += silver;
		_sign_save();
	}

	Json::Value playerWorldBoss::getTotalRewardInfo()
	{
		checkAndUpdate();
		Json::Value info = _rank_reward;
		
		bool succ_silver = _total_silver == 0;
		bool succ_gold = _total_gold == 0;
		if (!succ_silver)
		{
			ForEach(Json::Value, it, info)
			{
				if ((*it)[0u].asInt() == ACTION::silver)
				{
					(*it)[1u] = (*it)[1u].asInt() + _total_silver;
					succ_silver = true;
				}
			}
			if (!succ_silver)
			{
				Json::Value tmp;
				tmp.append(ACTION::silver);
				tmp.append(_total_silver);
				info.append(tmp);
			}
		}
		if (!succ_gold)
		{
			ForEach(Json::Value, it, info)
			{
				if ((*it)[0u].asInt() == ACTION::ticket)
				{
					(*it)[1u] = (*it)[1u].asInt() + _total_gold;
					succ_gold = true;
				}
			}
			if (!succ_gold)
			{
				Json::Value tmp;
				tmp.append(ACTION::ticket);
				tmp.append(_total_gold);
				info.append(tmp);
			}
		}
		return info;
	}

	void playerWorldBoss::getRewardInfo(Json::Value& info)
	{
		checkAndUpdate();
		info["pd"] = _damage;
		info["rn"] = _rank;
		info["rs"] = _rank_reward;
		info["ds"] = _damage_silver;
		if (_rank == 0)
		{
			info["ks"] = 0;
			info["bs"] = 0;
		}
	}

	int playerWorldBoss::checkKingdomIncentLimit(int incent_num, int resource, int& succ)
	{
		checkAndUpdate();

		if (_nation_incented)
			return err_worldboss_nation_incented;

		if (incent_num >= worldboss_sys.getConfig().getIncentMaxId(WorldBoss::KingdomType))
			return err_worldboss_max_incent;

		int cost = 0;

		if (Own().KingFight().getTitle() != Kingdom::GuoWang)//kingfight_sys.playerOfficialType(Own().ID()) != KINGDEF::king)
		{
			cost = worldboss_sys.getConfig().getIncentCost(WorldBoss::KingdomType, resource, incent_num);

			if (resource == WorldBoss::UseMerit)
			{
				if (Own().Res().getMerit() < cost)
					return err_merit_not_enough;
				Own().Res().alterMerit(0 - cost);
			}
			else
			{
				if (Own().Res().getCash() < cost)
					return err_gold_not_enough;
				Own().Res().alterCash(0 - cost);
			}

			double suc_rate = worldboss_sys.getConfig().getIncentSucRate(WorldBoss::KingdomType, incent_num);
			if (!Common::randomOk(suc_rate))
			{
				succ = 0;
				Log(DBLOG::strLogWorldBoss, Own().getOwnDataPtr(), 3, succ, cost, incent_num, incent_num);
				TaskMgr::update(Own().getOwnDataPtr(), Task::WorldBossIncentTimes, 1);
				TaskMgr::update(Own().getOwnDataPtr(), Task::WorldBossKingdomIncentTimes, 1);
				return res_sucess;
			}
		}
		else
		{
			Log(DBLOG::strLogWorldBoss, Own().getOwnDataPtr(), 4, incent_num, incent_num + 1);
		}

		succ = 1;
		_nation_incented = true;

		Log(DBLOG::strLogWorldBoss, Own().getOwnDataPtr(), 3, succ, cost, incent_num, incent_num + 1);
		TaskMgr::update(Own().getOwnDataPtr(), Task::WorldBossIncentTimes, 1);
		TaskMgr::update(Own().getOwnDataPtr(), Task::WorldBossKingdomIncentTimes, 1);
		
		_sign_save();
		return res_sucess;
	}

	void playerWorldBoss::dailyTick()
	{
		_incent_num = 0;
		_nation_incented = false;
		_sign_save();
	}
}

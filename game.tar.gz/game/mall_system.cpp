#include "mall_system.h"
#include "task_mgr.h"

namespace gg
{
	const static int ownIDPart = 10000;//�Լ���Ʒ�ͺ�̨��Ʒ����

	namespace MALL
	{
		bool Data::isOver()
		{
			if (goodID <= ownIDPart)return false;//����Ĺ̶�û��ʱ������
			if (0 == startTime && 0 == endTime)return false;//�����δ0, ��ô������ʱ������
			const unsigned now = Common::gameTime();
			if (now > endTime)return true;
			return false;
		}

		static int buy_type = EMPTY;

		int BuyType()
		{
			int type = buy_type;
			buy_type = EMPTY;
			return type;
		}
	}

	mall* const mall::_Instance = new mall();

	STDMAP(int, MALL::DataPtr, MALLMAP);
	static MALLMAP MallData;
	static void saveGood(MALL::DataPtr data_ptr)
	{
		if (data_ptr->goodID <= ownIDPart)return;//�Լ������ݲ�����
		mongo::BSONObj key = BSON("gid" << data_ptr->goodID);
		mongo::BSONObj obj = BSON("gid" << data_ptr->goodID << "gn" << 
			data_ptr->goodName << "gd" << data_ptr->goodDeclare << "gi" << 
			data_ptr->goodIcon << "ct" << data_ptr->costType << "ih" << 
			data_ptr->isHot << "pv" << data_ptr->priceVal << "pos" << 
			data_ptr->position << "lmb" << data_ptr->limitBuy << "lmv" <<
			data_ptr->limitVip << "lml" << data_ptr->limitLV << "st" << 
			data_ptr->startTime << "et" << data_ptr->endTime << "box" << 
			data_ptr->jsonBox.toIndentString() << "dis" << data_ptr->discout <<
			"od" << data_ptr->outDeclare << "mb" << data_ptr->moduleBox.toIndentString() <<
			"st" << data_ptr->sortWeigth
		);
		db_mgr.SaveMongo(DBN::dbMallSystem, key, obj);
	}
	static bool insertGood(MALL::DataPtr data_ptr)
	{
		if (data_ptr->isOver())return false;
		MallData[data_ptr->goodID] = data_ptr;
		saveGood(data_ptr);
		return true;
	}
	static void removeGood(const int goodID)
	{
		mongo::BSONObj key = BSON("gid" << goodID);
		MallData.erase(goodID);
		db_mgr.RemoveCollection(DBN::dbMallSystem, key);
	}
	static MALL::DataPtr getGood(const int goodID)
	{
		MALLMAP::iterator it = MallData.find(goodID);
		if (it == MallData.end())return MALL::DataPtr();
		MALL::DataPtr data_ptr = it->second;
		if (data_ptr->isOver())
		{
			removeGood(goodID);
			data_ptr = MALL::DataPtr();
		}
		return data_ptr;
	}

	void mall::initData()
	{
		cout << "load mall system ..." << endl;

		MallData.clear();
		FileJsonSeq vec = Common::loadFileJsonFromDir("./instance/mall/");
		for (unsigned i = 0; i < vec.size(); ++i)
		{
			Json::Value& json = vec[i];
			MALL::DataPtr data_ptr = Creator<MALL::Data>::Create();
			const int goodID = json["goodID"].asInt();
			if (goodID > ownIDPart)continue;
			data_ptr->goodID = goodID;
			data_ptr->goodName = json["goodname"].asString();
			data_ptr->goodDeclare = json["goodDeclare"].asString();
			data_ptr->goodIcon = json["goodIcon"].asInt();
			data_ptr->costType = json["costType"].asInt();
			data_ptr->isHot = json["isHot"].asBool();
			data_ptr->discout = json["discout"].asInt();
			data_ptr->priceVal = json["priceVal"].asInt();
			data_ptr->position = json["position"].asInt();
			data_ptr->limitBuy = json["limitBuy"].asInt();
			data_ptr->limitVip = json["limitVip"].asUInt();
			data_ptr->limitLV = json["limitLV"].asUInt();
			data_ptr->limitMan = json["limitMan"].asInt();
			data_ptr->sortWeigth = json["sortWeigth"].asInt();
			data_ptr->startTime = 0;
			data_ptr->endTime = 0;
			data_ptr->outDeclare = json["outDeclare"].asString();
			Json::Value& box = json["box"];
			data_ptr->jsonBox = box;
			data_ptr->Box = actionFormatBox(box);
			data_ptr->moduleBox = json["module"];
			insertGood(data_ptr);
		}

		objCollection collects = db_mgr.Query(DBN::dbMallSystem);
		for (unsigned i = 0; i < collects.size(); ++i)
		{
			mongo::BSONObj& obj = collects[i];
			const int goodID = obj["gid"].Int();
			if (goodID > ownIDPart)
			{
				MALL::DataPtr data_ptr = Creator<MALL::Data>::Create();
				data_ptr->goodID = goodID;
				data_ptr->goodName = obj["gn"].String();
				data_ptr->goodDeclare = obj["gd"].String();
				data_ptr->goodIcon = obj["gi"].Int();
				data_ptr->costType = obj["ct"].Int();
				data_ptr->isHot = obj["ih"].Bool();
				data_ptr->priceVal = obj["pv"].Int();
				data_ptr->position = obj["pos"].Int();
				data_ptr->discout = obj["dis"].Int();
				data_ptr->limitBuy = obj["lmb"].Int();
				data_ptr->limitVip = (unsigned)obj["lmv"].Int();
				data_ptr->limitLV = (unsigned)obj["lml"].Int();
				data_ptr->startTime = (unsigned)obj["st"].Int();
				data_ptr->endTime = (unsigned)obj["et"].Int();
				data_ptr->jsonBox = Common::string2json(obj["box"].String());
				data_ptr->outDeclare = obj["od"].String();
				data_ptr->sortWeigth = obj["st"].ok() ? obj["st"].Int() : 0;
				Json::Value box = data_ptr->jsonBox;
				data_ptr->Box = actionFormatBox(box);
				data_ptr->moduleBox = Common::string2json(obj["mb"].String());
				insertGood(data_ptr);
			}
			else
			{
				MALL::DataPtr data_ptr = getGood(goodID);
				if (!data_ptr)
				{
					removeGood(goodID);
				}
			}
		}
	}

	void mall::gmUpdate(net::Msg& m, Json::Value& r)
	{
		const static unsigned PageNum = 15;
		ReadJsonArray;
		const unsigned page = js_msg[0u].asUInt();
		const unsigned page_start = page * PageNum;
		Json::Value& data_json = (r[strMsg][1u] = Json::arrayValue);
		unsigned cNum = 0;
		for (MALLMAP::iterator it = MallData.begin(); it != MallData.end();)
		{
			MALL::DataPtr data_ptr = it->second;
			++it;
			if (data_ptr->isOver())
			{
				removeGood(data_ptr->goodID);
				continue;
			}
			if (cNum++ < page_start)continue;
			Json::Value sg_json = Json::arrayValue;
			sg_json.append(data_ptr->goodID);
			sg_json.append(data_ptr->goodName);
			sg_json.append(data_ptr->goodDeclare);
			sg_json.append(data_ptr->goodIcon);
			sg_json.append(data_ptr->costType);
			sg_json.append(data_ptr->isHot);
			sg_json.append(data_ptr->priceVal);
			sg_json.append(data_ptr->position);
			sg_json.append(data_ptr->discout);
			sg_json.append(data_ptr->limitBuy);
			sg_json.append(data_ptr->limitVip);
			sg_json.append(data_ptr->limitLV);
			sg_json.append(data_ptr->startTime == 0 ? 0 : Common::toStampTime(data_ptr->startTime));
			sg_json.append(data_ptr->endTime == 0 ? 0 : Common::toStampTime(data_ptr->endTime));
			sg_json.append(data_ptr->jsonBox);
			sg_json.append(data_ptr->outDeclare);
			sg_json.append(data_ptr->moduleBox);
			sg_json.append(data_ptr->sortWeigth);
			data_json.append(sg_json);
			if (data_json.size() >= PageNum)break;
		}
		r[strMsg][2u] = unsigned(MallData.size() / PageNum + ((MallData.size() % PageNum > 0) ? 1 : 0));
		Return(r, res_sucess);
	}

	void mall::gmMotify(net::Msg& m, Json::Value& r)
	{
		Json::Value& res_code = r[strMsg];
		ReadJsonArray;
		for (unsigned i = 0; i < js_msg.size() && i < 100; ++i)
		{
			Json::Value sg_res;
			Json::Value& json = js_msg[i];
			const int goodID = json[0u].asInt();
			sg_res.append(goodID);
			if (goodID > ownIDPart)
			{
				if (json[1u].isBool())
				{
					sg_res.append(true);
					res_code.append(sg_res);
					removeGood(goodID);
					continue;
				}
				MALL::DataPtr data_ptr = Creator<MALL::Data>::Create();
				data_ptr->goodID = goodID;
				data_ptr->goodName = json[1u].asString();
				data_ptr->goodDeclare = json[2u].asString();
				data_ptr->goodIcon = json[3u].asInt();
				data_ptr->costType = json[4u].asInt();
				data_ptr->isHot = json[5u].asBool();
				data_ptr->priceVal = json[6u].asInt();
				data_ptr->position = json[7u].asInt();
				data_ptr->discout = json[8u].asInt();
				data_ptr->limitBuy = json[9u].asInt();
				data_ptr->limitVip = json[10u].asUInt();
				data_ptr->limitLV = json[11u].asUInt();
				const unsigned start_time = json[12u].asUInt();
				const unsigned end_time = json[13u].asUInt();
				data_ptr->startTime = start_time == 0 ? 0 : Common::toLocalTime(start_time);
				data_ptr->endTime = end_time == 0 ? 0 : Common::toLocalTime(end_time);
				Json::Value& box = json[14u];
				data_ptr->jsonBox = box;
				data_ptr->Box = actionFormatBox(box);
				data_ptr->outDeclare = json[15u].asString();
				data_ptr->moduleBox = json[16u];
				data_ptr->sortWeigth = json[17u].asUInt();
				sg_res.append(insertGood(data_ptr));
				res_code.append(sg_res);
			}
			else
			{
				sg_res.append(false);
				res_code.append(sg_res);
			}
		}
	}

	void mall::UpdatePlayer(net::Msg& m, Json::Value& r)
	{
		playerDataPtr player = player_mgr.getPlayer(m.playerID);
		if (!player)Return(r, err_illedge);
		player->Malls()._sign_update();
	}

	void mall::Update(net::Msg& m, Json::Value& r)
	{
		playerDataPtr player = player_mgr.getPlayer(m.playerID);
		if (!player)Return(r, err_illedge);
		Json::Value data_json = Json::arrayValue;
		int iCount = 0;
		for (MALLMAP::iterator it = MallData.begin(); it != MallData.end(); )
		{
			MALL::DataPtr data_ptr = it->second;
			++it;
			if (data_ptr->isOver())
			{
				removeGood(data_ptr->goodID);
				continue;
			}
			Json::Value sg_json;
			sg_json.append(data_ptr->goodID);
			sg_json.append(data_ptr->goodName);
			sg_json.append(data_ptr->goodDeclare);
			sg_json.append(data_ptr->goodIcon);
			sg_json.append(data_ptr->costType);
			sg_json.append(data_ptr->isHot);
			sg_json.append(data_ptr->priceVal);
			sg_json.append(data_ptr->position);
			sg_json.append(data_ptr->discout);
			sg_json.append(data_ptr->limitBuy);
			sg_json.append(data_ptr->limitVip);
			sg_json.append(data_ptr->limitLV);
			sg_json.append(data_ptr->startTime);
			sg_json.append(data_ptr->endTime);
			sg_json.append(data_ptr->jsonBox);
			sg_json.append(data_ptr->outDeclare);
			sg_json.append(data_ptr->moduleBox);
			sg_json.append(data_ptr->limitMan);
			sg_json.append(data_ptr->sortWeigth);
			data_json.append(sg_json);
			++iCount;
			if (iCount > 49)
			{
				Json::Value package_json;
				package_json[strMsg][0u] = res_sucess;
				package_json[strMsg][1u] = data_json;
				iCount = 0;
				player->sendToClient(gate_client::mall_goods_part_update_resp, package_json);
				data_json = Json::arrayValue;
			}
		}
		if (iCount > 0)
		{
			Json::Value package_json;
			package_json[strMsg][0u] = res_sucess;
			package_json[strMsg][1u] = data_json;
			iCount = 0;
			player->sendToClient(gate_client::mall_goods_part_update_resp, package_json);
		}
		Return(r, res_sucess);
	}

	int CheckRes(const int type, const int val, playerDataPtr player)
	{
		if (type == 0 && player->Res().getGold() < val)return err_gold_not_enough;
		if (type == 1 && player->Res().getCash() < val)return err_cash_not_enough;
		//if (type == 2 && player->Res().getChargePoints() < val)return err_charge_points_not_enough;
		//if (type == 3 && player->Res().getPaper() < val)return err_paper_not_enough;
		if (type == 4 && player->Res().getSilver() < val)return err_silver_not_enough;
		return res_sucess;
	}

	void CutRes(const int type, const int val, playerDataPtr player)
	{
		if (type == 0)
		{
			player->Res().alterGold(-val);
			return;
		}
		if (type == 1)
		{
			player->Res().alterCash(-val);
			return;
		}
// 		if (type == 2)
// 		{
// 			player->Res().alterChargePoints(-val);
// 			return;
// 		}
// 		if (type == 3)
// 		{
// 			player->Res().alterPaper(-val);
// 			return;
// 		}
		if (type == 4)
		{
			player->Res().alterSilver(-val);
			return;
		}
	}

	void mall::Buy(net::Msg& m, Json::Value& r)
	{
		playerDataPtr player = player_mgr.getPlayer(m.playerID);
		if (!player)Return(r, err_illedge);
		ReadJsonArray;
		const int goodID = js_msg[0u].asInt();
		const int costType = js_msg[1u].asInt();
		const int goodPrice = js_msg[2u].asInt();
		const int buyNum = js_msg[3u].asUInt();
		if (buyNum < 1 || buyNum > 999)Return(r, err_illedge);
		MALL::DataPtr data_ptr = getGood(goodID);
		if (!data_ptr)Return(r, err_mall_good_no_found);
		if(!data_ptr->isSale())Return(r, err_mall_goods_isnt_in_sale_time);
		if (goodPrice != data_ptr->priceVal || costType != data_ptr->costType)Return(r, err_mall_gool_no_match);
		if (data_ptr->limitVip > player->Info().VipLv())Return(r, err_vip_lv_too_low);
		const unsigned OwnLV = player->LV();
		if (data_ptr->limitLV > OwnLV)Return(r, err_player_lv_too_low);
		if (data_ptr->limitMan > 0 && false == bool(player->Man().findArmy(data_ptr->limitMan)))Return(r, err_no_man);
		const int cost_price = data_ptr->priceVal * buyNum;
		const int res_res = CheckRes(data_ptr->costType, cost_price, player);
		if (res_res != res_sucess)Return(r, res_res);
		const int beenBuyNum = player->Malls().getNum(goodID);
		const bool limitBuy = data_ptr->isLimitBuy();
		if (limitBuy && (beenBuyNum >= data_ptr->limitBuy || beenBuyNum + buyNum > data_ptr->limitBuy))Return(r, err_mall_buy_num_limit);
		Json::Value& module_json = data_ptr->moduleBox;
		ActionRateMap rateMap;
		for (unsigned i = 0; i < module_json.size(); ++i)
		{
			Json::Value& sg_json = module_json[i];
			rateMap[sg_json[0u].asInt()] = ACTION::Rate(1.0, int(OwnLV *  sg_json[1u].asInt()));
		}
		Json::Value& data_json = r[strMsg][1u] = Json::arrayValue;
		setActionRate(rateMap);
		const int res = actionDoBoxNum(player, data_ptr->Box, buyNum, false);
		if (res_sucess == res)
		{
			if (goodID >= 25 && goodID <= 39)
				MALL::buy_type = MALL::RED_PAPER;
			data_json = actionRes();
			player->Malls().alterNum(goodID, buyNum);
			CutRes(data_ptr->costType, cost_price, player);
			Log(DBLOG::strLogMall, player, -1, data_ptr->costType, data_ptr->priceVal, data_ptr->goodID, data_ptr->goodName, buyNum, "", "", data_json.toIndentString());
			TaskMgr::update(player, Task::MallTimes, buyNum);
			TaskMgr::update(player, Task::MallConsumeNum, cost_price);
			if (1 == goodID ||
				7 == goodID || 
				8 == goodID || 
				9 == goodID )
			{
				player->Daily().tickTask(DAILY::buy_days_gift, buyNum);
			}
		}
		else
		{
			data_json = actionError();
		}
		Return(r, res);
	}

	void mall::UpdateItem(net::Msg& m, Json::Value& r)
	{
		playerDataPtr player = player_mgr.getPlayer(m.playerID);
		if (!player)Return(r, err_illedge);
		ReadJsonArray;
		const int goodID = js_msg[0u].asInt();
		MALLMAP::iterator it = MallData.find(goodID);
		if (it == MallData.end())
			Return(r, err_illedge);
		MALL::DataPtr data_ptr = it->second;
		Json::Value sg_json;
		sg_json.append(data_ptr->goodID);
		sg_json.append(data_ptr->goodName);
		sg_json.append(data_ptr->goodDeclare);
		sg_json.append(data_ptr->goodIcon);
		sg_json.append(data_ptr->costType);
		sg_json.append(data_ptr->isHot);
		sg_json.append(data_ptr->priceVal);
		sg_json.append(data_ptr->position);
		sg_json.append(data_ptr->discout);
		sg_json.append(data_ptr->limitBuy);
		sg_json.append(data_ptr->limitVip);
		sg_json.append(data_ptr->limitLV);
		sg_json.append(data_ptr->startTime);
		sg_json.append(data_ptr->endTime);
		sg_json.append(data_ptr->jsonBox);
		sg_json.append(data_ptr->outDeclare);
		sg_json.append(data_ptr->moduleBox);
		sg_json.append(data_ptr->limitMan);
		r[strMsg][1u] = sg_json;
		r[strMsg][2u] = player->Malls().getNum(goodID);
		Return(r, res_sucess);
	}
}

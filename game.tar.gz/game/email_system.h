//###################################
//create by Cai
//2016-04-07
//###################################

#pragma once

#include "dbDriver.h"
#include "email.h"

#define email_sys (*gg::email_system::_Instance)

namespace gg
{	
	class email_system
	{
		public:
			static email_system* const _Instance;
			void initData();
		
			DeclareRegFunction(playerInfoReq);
			DeclareRegFunction(sendEmailReq);
			DeclareRegFunction(getPackageReq);
			DeclareRegFunction(redPointReq);

			DeclareRegFunction(gmSendEmailReq);
			DeclareRegFunction(gmEmailInfoReq);
			DeclareRegFunction(gmRemoveEmailReq);
			
			// create email
			EmailPtr createSystem(const std::string& msg);
			EmailPtr createSystem(int msg_type, const Json::Value& param = Json::arrayValue);
			EmailPtr createGamer(playerDataPtr& d, const std::string& msg);
			EmailPtr createPackage(int msg_type, const Json::Value& param_list, const Json::Value& reward);
			EmailPtr createReport(int msg_type, const Json::Value& param_list, const std::string& report);

			// send email
			void sendToAll(EmailPtr& e);
			void sendToKingdom(int nation, EmailPtr& e);
			void sendToPart(const std::vector<int>& player_list, EmailPtr& e);
			void sendToPlayer(int player_id, EmailPtr& e);
			void sendToChannel(const std::vector<std::string>& channels, unsigned over_time, EmailPtr& e);

			void sendToAll(const std::vector<int>& server_ids, EmailPtr& e);
			void sendToKingdom(const std::vector<int>& server_ids, int nation, EmailPtr& e);
			void sendToChannel(const std::vector<int>& server_ids, const std::vector<std::string>& channels, unsigned over_time, EmailPtr& e);

			EmailPtr createFromBSON(const mongo::BSONElement& obj);
			EmailPtr getCommonEmail(int server_id, int id);
			unsigned getCommonEmails(playerDataPtr d, int player_owner_email_id, EmailVec& vec);
			unsigned getCommonId(int server_id);

		private:
			CommonEmailPtr createAll(int server_id, EmailPtr& e);
			CommonEmailPtr createNation(int server_id, int nation, EmailPtr& e);
			CommonEmailPtr createPart(int server_id, const std::vector<int>& parts, EmailPtr& e);
			CommonEmailPtr createChannel(int server_id, const std::vector<std::string>& channels, unsigned over_time, EmailPtr& e);
			EmailPtr createGmPackage(int msg_type, const Json::Value& param_list, const Json::Value& reward);

			void saveCommonID(int server_id);
			int removeCommonEmail(int server_id, int id);

		private:
			virtual void classLoad();
			struct EmailData
			{
				EmailData(): max_common_id(100000){}
				unsigned max_common_id;
				CommonEmailMap common_emails;
			};
			STDMAP(int, EmailData, ServerID2Email);
			ServerID2Email _common_emails;
	};
}

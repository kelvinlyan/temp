//###################################
//create by Jim
//2016-03-03
//###################################

#pragma once

#include "auto_base.h"

namespace gg
{
	class playerTick;
	class playerRescue :
		public _auto_player
	{
		friend class playerTick;
	public:
		playerRescue(playerData* const own);
		~playerRescue(){}
		static void initData();
		virtual void _auto_update();
		int tickReward();
		
		void setData(mongo::BSONObj& obj);
	private:
		int getLimit();
		int getSingleReward();
		virtual bool _auto_save();
		int rewardNum;//���������õĹ���ֵ
		unsigned rewardTimes;//��������Ĵ���
	};
}
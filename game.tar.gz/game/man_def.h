//###################################
//create by Jim
//2015-11-11
//###################################

#pragma once

namespace gg
{
	const static unsigned equipHoleSize = 4;
	const static unsigned armsModulesNum = 6;//ϵ��

	namespace MANTYPE
	{
		enum
		{
			jixie = (0x0001 << 0),//��е��
			zhanfa = (0x0001 << 1),//ս����
			celue = (0x0001 << 2),//���Խ�
			fuzhu = (0x0001 << 3),//������
		};
	}


	struct armsRestraint
	{
		armsRestraint(){
			atkModule = 0.0;
			defModule = 0.0;
		}
		armsRestraint(double aM, double dM){
			atkModule = aM;
			defModule = dM;
		}
		double atkModule;
		double defModule;
	};

	enum ArmsModule
	{
		idx_atkModule,
		idx_defModule,
		idx_warModule,
		idx_warDefModule,
		idx_magicModule,
		idx_magicDefModule,
	};

	enum AttributeIDX{
		idx_hp,
		idx_tl_phy,
		idx_tl_phy_def,
		idx_tl_war,
		idx_tl_war_def,
		idx_tl_magic,
		idx_tl_magic_def,
		idx_phy,
		idx_phy_def,
		idx_war,
		idx_war_def,
		idx_magic,
		idx_magic_def,
		idx_dodge,
		idx_block,
		idx_crit,
		idx_counter,//�佫���������
		idx_phyHurtRate,
		idx_phyCutRate,
		idx_warHurtRate,
		idx_warCutRate,
		idx_magicHurtRate,
		idx_magicCutRate,
		idx_cureRate,
		idx_beCureRate,
		idx_phyHurt,
		idx_phyCut,
		idx_warHurt,
		idx_warCut,
		idx_magicHurt,
		idx_magicCut,
		idx_cure,
		idx_beCure,
		idx_hit,
		idx_defend_block,
		idx_defend_crit,
		idx_defend_counter,

		idx_total_num,
	};

	struct AttriBase
	{
		AttriBase(AttributeIDX i = idx_hp, const int v = 0)
		{
			idx = i;
			val = v;
		}
		AttributeIDX idx;
		int val;
	};

	const static unsigned characterNum = idx_total_num;//37������
}

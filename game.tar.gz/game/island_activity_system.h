#pragma once

#include "activity_mgr.h"
#include "action_system.h"
#include "dbDriver.h"

#define island_activity_sys (*gg::island_activity_system::_Instance)

namespace gg
{
	namespace nIsland
	{
		int randKeyPiece();
		int KeyPieceID();
		
		struct RandItem
		{
			RandItem(const Json::Value& info)
			{
				Json::Value rw = info["rw"];
				reward = actionFormatBox(rw);
				percent = info["per"].asInt();
				if (info["bc"] != Json::nullValue)
					bc = info["bc"].asBool();
				else
					bc = false;
			}
			ActionBoxList reward;
			int percent;
			bool bc;
		};
		STDVECTOR(RandItem, ItemList);

		class RewardRecord
			: public _auto_meta
		{	
			public:
				RewardRecord(int key_id);

				void loadDB();
				void removeDB();

				void push(qValue& r);
				void update(playerDataPtr d);

			private:
				virtual bool _auto_save();

			private:
				const int _key_id;
				STDLIST(std::string, RecordList);
				RecordList _records;
		};

		BOOSTSHAREPTR(RewardRecord, RecordPtr);
	}

	class IslandActivity
		: public ActivityBase
	{
		public:
			IslandActivity(const Json::Value& info);
			virtual mongo::BSONObj toBSON() const;

			const Json::Value& ClientInfo() const { return _client_info; }

			const nIsland::ItemList& getTurnTable(int type) const;
			ActionBoxList turnTableReward(int type, int& idx, bool& bc) const;

			int limitByAction() const { return _limit_by_action; }
			int limitByGold() const { return _limit_by_gold; }

			const Json::Value& data() const { return _data; }

			virtual void start();
			virtual void update();
			virtual void stop(bool timer_tick);

			void addRecord(qValue& q);
			void sendRecord(playerDataPtr d);

		private:
			nIsland::ItemList _turntable_east;
			nIsland::ItemList _turntable_west;
			nIsland::ItemList _turntable_high;

			int _limit_by_gold;
			int _limit_by_action;
			nIsland::RecordPtr _record;

			const Json::Value _data;
			Json::Value _client_info;
	};

	class island_activity_system 
		: public ActivityMgr<IslandActivity>
	{
		public:
			static island_activity_system* const _Instance;

			island_activity_system();
			void initData();

			DeclareRegFunction(turnTable);
			DeclareRegFunction(openBox);
			DeclareRegFunction(record);
			DeclareRegFunction(ownRecord);
			DeclareRegFunction(playerInfo);

			DeclareRegFunction(gmIDList);
			DeclareRegFunction(gmInfo);
			DeclareRegFunction(gmModify);

			void sendInfo(playerDataPtr d = playerDataPtr());

		private:
			void loadDB();
	};
}

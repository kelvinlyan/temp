#include "military_system.h"

namespace gg
{
	military_system* const military_system::_Instance = new military_system();

	void military_system::data(net::Msg& m, Json::Value& r)
	{
		playerDataPtr player = player_mgr.getPlayer(m.playerID);
		if (!player)Return(r, err_illedge);
		player->Military().update();
	}

	void military_system::levelUp(net::Msg& m, Json::Value& r)
	{
		playerDataPtr player = player_mgr.getPlayer(m.playerID);
		if (!player)Return(r, err_illedge);
		int res = player->Military().levelUp(r[strMsg][1u]);
		Return(r, res);
	}
}

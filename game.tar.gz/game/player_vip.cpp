#include "player_vip.h"
#include "vip_system.h"
#include "chat.h"
#include "email_system.h"

namespace gg
{
	class FirstGift
	{
		SINGLETON(FirstGift);
		public:
			const ActionBoxList& reward(int day) const { return _first_reward[day-1]; }
			const Json::Value& buchang() const { return _buchang_reward; }
		private:
			std::vector<ActionBoxList> _first_reward;
			Json::Value _buchang_reward;
	};

	FirstGift::FirstGift()
	{
		Json::Value info = Common::loadJsonFile("./instance/vip/firstgift.json");
		Json::Value& first = info["firstgift"];
		ForEach(Json::Value, it, first)
			_first_reward.push_back(actionFormatBox(*it));
		_buchang_reward = jsonFormats2c(info["buchanggift"]);
	}

	playerVipMgr::playerVipMgr(playerData* const own) :_auto_player(own)//, first_gift_state(0)
		, first_recharge_time(0)
	{
		
	}

	void	 playerVipMgr::setData(mongo::BSONObj& obj)
	{
		if (obj.isEmpty())
		{
			return;
		}
		if (!obj["pv"].eoo())
		{
			vector<mongo::BSONElement> sets = obj["pv"].Array();
			for (unsigned i = 0; i < sets.size(); i++)
			{
				vipGiftPtr ptr = Creator<vipGift>::Create();
				ptr->giftId = sets[i]["gi"].Int();
				ptr->rState = sets[i]["rs"].Int();
				playerVipGift[ptr->giftId] = ptr;
			}
		}
		checkNotEoo(obj["frt"])
			first_recharge_time = obj["frt"].Int();
		checkNotEoo(obj["fgs"])
		{
			std::vector<mongo::BSONElement> ele = obj["fgs"].Array();
			for (unsigned i = 0; i < ele.size(); ++i)
				first_gift_state.push_back(ele[i].Int());
		}

	//	checkNotEoo(obj["fg"])
	//		first_gift_state = obj["fg"].Int();
	}

	void playerVipMgr::_auto_update()
	{
		Json::Value msg;
		msg[strMsg][0u] = res_sucess;
		msg[strMsg][1u] = formatgift();
		Own().sendToClient(gate_client::player_vip_show_resp, msg);
	}

	bool playerVipMgr::_auto_save()
	{
		mongo::BSONObj key = BSON(strPlayerID << Own().ID());
		mongo::BSONObjBuilder obj;
		mongo::BSONArrayBuilder pv;
		for (vipGiftMap::iterator it = playerVipGift.begin(); it != playerVipGift.end(); it++)
		{
			mongo::BSONObj obj = BSON("gi" << it->second->giftId << "rs" << it->second->rState);
			pv << obj;
		}
		obj << "pv" << pv.arr();// << "fg" << first_gift_state;
		obj << "frt" << first_recharge_time;
		mongo::BSONArrayBuilder b;
		for (unsigned i = 0; i < first_gift_state.size(); ++i)
			b.append(first_gift_state[i]);
		obj << "fgs" << b.arr();
		mongo::BSONObj set_obj = BSON("$set" << BSON("Vip" << obj.obj()));
		return db_mgr.SaveMongo(DBN::dbPlayerCollection, key, set_obj);
	}

	void playerVipMgr::addVipGift(int id)
	{
		if (id != 0)
		{
			vipGiftPtr giftPtr = Creator<vipGift>::Create();
			giftPtr->giftId = id;
			giftPtr->rState = 0;
			playerVipGift[giftPtr->giftId] = giftPtr;
		}
		else
		{
			first_recharge_time = Common::getLastTimeHMS(Common::gameTime(), 5);
			first_gift_state.insert(first_gift_state.end(),	3, 0);
		}
		_sign_auto();
	}

	int playerVipMgr::getVipGift(int id, int is_broadcast)
	{
		vipGiftMap::iterator it = playerVipGift.find(id);
		if (it == playerVipGift.end()) return err_illedge;
		if (it->second->rState != 0) return err_illedge;
		vipGiftDataPtr configPtr = vip_sys.getVipGif(id);
		if (!configPtr) return err_illedge;

		const int res = actionDoBox(Own().getOwnDataPtr(), configPtr->box);
		if (res_sucess == res)
		{
			it->second->rState = 1;
			_sign_auto();
			Json::Value res_json = actionRes();
			if (id == 0)
				Log(DBLOG::strLogFirstGift, Own().getOwnDataPtr(), 0, Own().Info().VipLv()
					, "", "", "", "", "", "", res_json.toIndentString());
			else
			{
				Log(DBLOG::strLogVipGift, Own().getOwnDataPtr(), -1, Own().Info().VipLv(),
					it->second->rState, "", "", "", "", "", res_json.toIndentString());
				if (is_broadcast == 1)
				{
					Json::Value bc;
					bc.append(chat_sys.ChatPackage(Own().getOwnDataPtr()));
					bc.append(id);
					bc.append(res_json);
					chat_sys.despatchAll(CHAT::server_vip_gift_broadcast, bc);
				}
			}
			return res_sucess;
		}
		else
		{
			return res;
		}
		_sign_auto();
	}

	Json::Value playerVipMgr::formatgift()
	{
		if (!playerVipGift.empty() && first_gift_state.empty())
		{
			vipGiftMap::iterator it = playerVipGift.find(0);
			if (it != playerVipGift.end() && it->second->rState == 1)
			{
				first_gift_state.insert(first_gift_state.end(), 3, 1);
				EmailPtr e = email_sys.createPackage(EmailDef::VipBuchangGift, Json::arrayValue, FirstGift::shared().buchang());
				email_sys.sendToPlayer(Own().ID(), e);
			}
			else
			{
				first_recharge_time = Common::getLastTimeHMS(Common::gameTime(), 5);
				first_gift_state.insert(first_gift_state.end(),	3, 0);
			}
			_sign_save();
		}
		Json::Value info;
		info["vg"] = Json::objectValue;
		Json::Value& vg = info["vg"];
		for (vipGiftMap::iterator it = playerVipGift.begin(); it != playerVipGift.end(); it++)
		{
			vg[Common::toString(it->second->giftId)] = it->second->rState;
		}
		info["frt"] = first_recharge_time;
		info["fgs"] = Json::arrayValue;
		Json::Value& fgs = info["fgs"];
		for (unsigned i = 0; i < first_gift_state.size(); ++i)
			fgs.append(first_gift_state[i]);
		return info;
	}

	int playerVipMgr::getFirstGift(int id, Json::Value& r)
	{
		if (id < 1 || id > 3)
			return err_illedge;
		if (first_gift_state.empty()
			|| first_gift_state[id-1] == 1)
			return err_illedge;
		if (((Common::gameTime() - first_recharge_time) / DAY + 1) < id)
			return err_illedge;

		const ActionBoxList& rw = FirstGift::shared().reward(id);
		int res = actionDoBox(Own().getOwnDataPtr(), rw, false);
		if (res == res_sucess)
		{
			r = actionRes();
			first_gift_state[id-1] = 1;
			Log(DBLOG::strLogFirstGift, Own().getOwnDataPtr(), 0, Own().Info().VipLv()
				, id, "", "", "", "", "", r.toIndentString());
			_sign_auto();
		}
		else
		{
			Json::Value error_code = actionError();
			res = error_code[0u][1u].asInt();
		}
		return res;
	}
	/*
		if (first_gift_state != 0 || Own().Info().VipExp() == 0)
			return err_illedge;
		first_gift_state = 1;
		const ActionBoxList& box = vip_sys.getFirstGift();
		actionDoBox(Own().getOwnDataPtr(), box);
		r = formatgift();
		_sign_auto();
		return res_sucess;
	*/
}

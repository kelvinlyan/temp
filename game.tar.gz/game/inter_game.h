//###################################
//create by Jim
//2017-02-10
//###################################

#pragma once 

#include "dbDriver.h"

#define inter_svr (*gg::InterGame::_Instance)

namespace gg
{
	class InterGame
	{
	public:
		static InterGame* const _Instance;
		//req and resp
		DeclareRegFunction(req_common);//common req
		DeclareRegFunction(req_limit_common);//common limit req
		DeclareRegFunction(req_register_inter_game);//register
		DeclareRegFunction(req_sync_battle_data);//sync
		DeclareRegFunction(req_share_inter_report);//share
		DeclareRegFunction(req_use_flower);//flower
		DeclareRegFunction(resp_common);//common resp
		DeclareRegFunction(resp_register_inter_game);//regist
		DeclareRegFunction(resp_sync_battle_data);//sync
		DeclareRegFunction(resp_batch_inter_server);//batch
		DeclareRegFunction(resp_batch_annouce);//batch
		DeclareRegFunction(resp_event_list);//event list

		//common reward
		DeclareRegFunction(resp_balance_ladder);//ladder balance
		DeclareRegFunction(resp_balance_promote);//promote balance
		DeclareRegFunction(resp_balance_flower);//flower balance
		DeclareRegFunction(resp_balance_title);//title balance

		DeclareRegFunction(resp_balance_ladder_ok);//ladder balance ok
		DeclareRegFunction(resp_balance_promote_ok);//promote balance ok
		DeclareRegFunction(resp_balance_flower_ok);//flower balance ok
		DeclareRegFunction(resp_balance_title_ok);//title balance ok

		//annouce email
		DeclareRegFunction(resp_grade_email);//grade email

		//local
		DeclareRegFunction(updateAllWarFm);//ȫ��������Ϣ
		DeclareRegFunction(updateSingleWarFm);//ָ��������Ϣ
		DeclareRegFunction(warFmFormat);//ָ��������Ϣ
		DeclareRegFunction(warFormatDefalut);//ָ��Ĭ������
		DeclareRegFunction(interGameConfig);//���ս��Ϣ
		DeclareRegFunction(interEventList);//�¼��б�
		void sendInterConfig(playerDataPtr player);

		//gm
		DeclareRegFunction(GMUpdateInter);//��ȡ���õĿ��ս��Ϣ
		DeclareRegFunction(GMMotifyInter);//���ÿ��ս��Ϣ

		void on_connect_sucess();
		void connect_inter_server();
		void initData();

		//public
		void send_to_inter_svr(const int player_id, const short protocol, Json::Value& json);
		void send_to_inter_svr(const int player_id, const short protocol, qValue& json);
		void send_to_inter_svr(const int player_id, const short protocol, string& str);
		void send_to_inter_svr(const int player_id, const short protocol);

	private:
		std::string inter_ip;
		std::string inter_port;
		std::string inter_report_port;
		std::string inter_server_name;//���ս��
		int			inter_server_id;//���սid
		std::string inter_event_list;
	};
}
#include "player_kingdom.h"
#include "kingdom_system.h"
#include "task_mgr.h"
#include "kingdom_def.h"
#include "kingdomwar_helper.h"
#include "kingfight_system.h"

namespace gg
{
	class KingdomSkillConf
	{
		public:
			KingdomSkillConf(const Json::Value& info)
			{
				_id = info["id"].asInt();
				_open_lv = info["kingdomLv"].asInt();

				_arms_id = info["attribute"][0u].asInt();
				_arms_num = info["attribute"][1u].asInt();

				_arms_id100 = info["attribute100"][0u].asInt();
				_arms_num100 = info["attribute100"][1u].asInt();

				ForEachC(Json::Value, it, info["silverNum"])
					_silver.push_back((*it).asInt());
				ForEachC(Json::Value, it, info["conNum"])
					_con.push_back((*it).asInt());
			}

			int getSilverCost(int lv) const
			{
				return lv >= _silver.size()? -1 : _silver[lv];
			}
			int getConCost(int lv) const
			{
				return lv >= _con.size()? -1 : _con[lv];
			}

			int _id;
			int _open_lv;
			STDVECTOR(int, Vec);
			Vec _silver;
			Vec _con;
			int _arms_id;
			int _arms_num;
			int _arms_id100;
			int _arms_num100;
	};

	BOOSTSHAREPTR(KingdomSkillConf, KingdomSkillConfPtr);
	STDMAP(int, KingdomSkillConfPtr, KingdomSkillConfMap);

	static KingdomSkillConfPtr getSkillConf(int id)
	{
		static KingdomSkillConfMap skill_conf;
		if (skill_conf.empty())
		{
			Json::Value json = Common::loadJsonFile("./instance/kingdom/kingdomskill.json");
			ForEach(Json::Value, it, json)
			{
				int id = (*it)["id"].asInt();
				skill_conf[id] = Creator<KingdomSkillConf>::Create(*it);
			}
			if (skill_conf.empty())
				LogE << "kingdom skill config error" << LogEnd;
		}
		KingdomSkillConfMap::iterator it = skill_conf.find(id);
		return it == skill_conf.end()? KingdomSkillConfPtr() : it->second;
	}

	KingdomSkillData::KingdomSkillData(int id)
		: _id(id), _lv(0)
	{
	}

	KingdomSkillData::KingdomSkillData(const mongo::BSONElement& obj)
	{
		_id = obj["i"].Int();
		_lv = obj["l"].Int();
	}

	mongo::BSONObj KingdomSkillData::toBSON() const
	{
		return BSON("i" << _id << "l" << _lv);
	}

	void KingdomSkillData::getInfo(Json::Value& info) const
	{
		info[Common::toString(_id)] = _lv;
	}

	class SkillResetCost
	{
		SINGLETON(SkillResetCost);
		public:
			int Get(unsigned times) const
			{
				if (times >= _times2cost.size())
					times = _times2cost.size() - 1;
				return _times2cost[times];
			}
		private:
			std::vector<int> _times2cost;
	};

	SkillResetCost::SkillResetCost()
	{
		const Json::Value json = Common::loadJsonFile("./instance/kingdom/skillResetCost.json");
		ForEachC(Json::Value, it, json)
			_times2cost.push_back((*it).asInt());
	}

	playerKingdom::playerKingdom(playerData* const own)
		: _auto_player(own), _con_times(0), _total_con(0), _cur_con(0), _join_time(0), _flush_times(0), _all_con_times(0), _skill_reset_times(0)
	{
		memset(_attrs, 0x0, sizeof(_attrs[0u]) * characterNum);
		_attrs_inited = false;
	}

	void playerKingdom::classLoad()
	{
		mongo::BSONObj key = BSON(strPlayerID << Own().ID());
		mongo::BSONObj obj = db_mgr.FindOne(DBN::dbPlayerKingdom, key);
		
		if (obj.isEmpty()) 
			return;

		checkNotEoo(obj["ct"])
			_con_times = obj["ct"].Int();
		checkNotEoo(obj["to"])
			_total_con = obj["to"].Int();
		checkNotEoo(obj["cu"])
			_cur_con = obj["cu"].Int();
		checkNotEoo(obj["ti"])
			_join_time = obj["ti"].Int();
		checkNotEoo(obj["ft"])
			_flush_times = obj["ft"].Int();
		checkNotEoo(obj["act"])
			_all_con_times = obj["act"].Int();
		checkNotEoo(obj["sd"])
		{
			std::vector<mongo::BSONElement> ele = obj["sd"].Array();
			for (unsigned i = 0; i < ele.size(); ++i)
			{
				int id = ele[i]["i"].Int();
				_skill_datas[id] = Creator<KingdomSkillData>::Create(ele[i]);
			}
		}
		checkNotEoo(obj["srt"])
			_skill_reset_times = obj["srt"].Int();
	}

	bool playerKingdom::_auto_save()
	{
		mongo::BSONObj key = BSON(strPlayerID << Own().ID());
		mongo::BSONObjBuilder obj;
		obj << strPlayerID << Own().ID() << "ct" << _con_times << "to" << _total_con
			<< "cu" << _cur_con << "ti" << _join_time << "ft" << _flush_times
			<< "act" << _all_con_times << "srt" << _skill_reset_times;
		{
			mongo::BSONArrayBuilder b;
			ForEachC(KingdomSkillDatas, it, _skill_datas)
				b.append(it->second->toBSON());
			obj << "sd" << b.arr();
		}
		return db_mgr.SaveMongo(DBN::dbPlayerKingdom, key, obj.obj());
	}

	void playerKingdom::_auto_update()
	{
	}

	void playerKingdom::getInfo(Json::Value& info)
	{
		info["tc"] = _total_con;
		info["cc"] = _cur_con;
		info["tn"] = kingdom_sys.getMaxConTimes(Own().Info().VipLv());
		info["nm"] = kingdom_sys.getMaxConTimes(Own().Info().VipLv()) - _con_times;
		const KingdomPtr ptr = kingdom_sys.getData(Own().Info().Nation());
		if (ptr)
		{
			const SalaryState& s = ptr->getSalaryState(Own().ID());
			info["gs"] = s.state;
			info["otl"] = s.title;
		}
		else
		{
			info["gs"] = -1;
		}
	}

	int playerKingdom::playerCon(int type, int& exp)
	{
		if (_con_times >= kingdom_sys.getMaxConTimes(Own().Info().VipLv()))
			return err_kingdom_notimes;
		const KingdomContributionConf& conf = kingdom_sys.getContributionConf();
		int rate = kingdom_sys.getData(Own().Info().Nation())->getRate();
		if (type == 1)
		{
			int cost = conf.silverCost(Own().Info().LV() - 1);
			cost += cost * ((double)rate / 100.0);
			if (Own().Res().getSilver() < cost)
				return err_silver_not_enough;
			Own().Res().alterSilver(0 - cost);
			exp = conf.silverCon(Own().Info().LV() - 1);
			Own().Res().alterContribution(conf.silverConSelf(Own().Info().LV() - 1));
		}
		else
		{
			int cost = conf.goldCost(Own().Info().LV() - 1);
			if (Own().Res().getCash() < cost)
				return err_gold_not_enough;
			Own().Res().alterCash(0 - cost);
			exp = conf.goldCon(Own().Info().LV() - 1);
			Own().Res().alterContribution(conf.goldConSelf(Own().Info().LV() - 1));
		}
		++_con_times;
		++_all_con_times;
		TaskMgr::update(Own().getOwnDataPtr(), Task::KingdomContributeTimes, 1);
		TaskMgr::update(Own().getOwnDataPtr(), Task::KingdomContributeAllTimes);
		_sign_save();
		return res_sucess;
	}

	void playerKingdom::alterCon(int num)
	{
		if (num >= 0)
		{
			int tmp = _total_con;
			_total_con += num;
			kingdom_sys.updateConRank(Own().getOwnDataPtr(), tmp);
		}
		_cur_con += num;
		if (_cur_con < 0)
			_cur_con = 0;
		//Own().Res().alterContribution(num);
		_sign_save();
	}

	int playerKingdom::addKingdom(int nation)
	{
		if (Own().Info().Nation() != Kingdom::null)
			return err_illedge;

	//	if (!Own().War().isChallengeChatper(AddKingdomChapterId))
	//		return err_illedge;

		Own().Info().setNation((Kingdom::NATION)nation);
		Own().KingFight().setTitle(Kingdom::PingMin);
		Own().KingDomWarBox().initGreatEventBox();
		_join_time = Common::gameTime();
		const KingFightManager ptr = kingfight_sys.getData(Own().Info().Nation());
		ptr->firstSetTitle(Own().getOwnDataPtr());
		Own().KingDomWarTips().updateAll();
		_sign_save();
		return res_sucess;
	}

	int playerKingdom::resetSkill()
	{
		int cost = SkillResetCost::shared().Get(_skill_reset_times);
		if (Own().Res().getCash() < cost)
			return err_gold_not_enough;
		int sum = 0;
		ForEach(KingdomSkillDatas, it, _skill_datas)
		{
			KingdomSkillDataPtr ptr = it->second;
			sum += ptr->_lv;
		}
		if (sum == 0)
			return err_illedge;
		int all_silver = 0;
		int all_con = 0;
		ForEach(KingdomSkillDatas, it, _skill_datas)
		{
			KingdomSkillDataPtr ptr = it->second;
			int id = ptr->_id;
			KingdomSkillConfPtr conf = getSkillConf(id);
			if (!conf) return err_illedge;
			int cur_lv = 0;
			int end_lv = ptr->_lv;
			for (; cur_lv < end_lv; ++cur_lv)
			{
				all_silver += conf->getSilverCost(cur_lv);
				all_con += conf->getConCost(cur_lv);
			}
		}
		ForEach(KingdomSkillDatas, it, _skill_datas)
		{
			int tmp = it->second->_lv;
			it->second->_lv = 0;
			Log(DBLOG::strLogKingdom, Own().getOwnDataPtr(), 0, it->second->_id, Own().Info().NationOf_(), 0/*ԭ����ְ,����û����,Ĭ�����һ����ֵ*/, tmp, 0);
		}
		Own().Res().alterCash(0 - cost);
		Own().Res().alterSilver(all_silver);
		_cur_con += all_con;
		++_skill_reset_times;
		TaskMgr::update(Own().getOwnDataPtr(), Task::KingdomSkillLvSum);
		resetAttr();
		_sign_save();
		return res_sucess;
	}
	
	int playerKingdom::upSkill(int id, int batch, Json::Value& r)
	{
		KingdomSkillConfPtr conf = getSkillConf(id);
		if (!conf) return err_illedge;

		if (kingdom_sys.getData(Own().Info().Nation())->getLevel() < conf->_open_lv)
			return err_kingdom_kinglv_not;
		
		KingdomSkillDatas::iterator it = _skill_datas.find(id);
		if (it == _skill_datas.end())
		{
			_skill_datas[id] = Creator<KingdomSkillData>::Create(id);
			it = _skill_datas.find(id);
		}
		KingdomSkillDataPtr ptr = it->second;
		
		unsigned times = batch == 1? 10 : 1;
		unsigned up_times = 0;
		int break_reason = 0;
		
		for (; up_times < times; ++up_times)
		{
			if (ptr->_lv < 100 && ptr->_lv >= Own().LV())
			{
				break_reason = err_kingdom_cant_kingdomlv_skill;
				break;
			}
			int silver_cost = conf->getSilverCost(ptr->_lv);
			int con_cost = conf->getConCost(ptr->_lv);
			if (silver_cost == -1 || con_cost == -1)
			{
				break_reason = err_kingdom_skill_max_lv;
				break;
			}
			if (Own().Res().getSilver() < silver_cost)
			{
				break_reason = err_silver_not_enough;
				break;
			}
			if (Own().Res().getContribution() < con_cost)
			{
				break_reason = err_kingdom_con_not_enough;
				break;
			}
			Own().Res().alterSilver(0 - silver_cost);
			Own().Res().alterContribution(0 - con_cost);
			++ptr->_lv;
			Log(DBLOG::strLogKingdom, Own().getOwnDataPtr(), 0, id, Own().Info().NationOf_(), 0/*ԭ����ְ,����û����,Ĭ�����һ����ֵ*/, ptr->_lv - 1, ptr->_lv);
		}
		
		if (up_times > 0)
		{
			TaskMgr::update(Own().getOwnDataPtr(), Task::KingdomSkillLvSum);
			TaskMgr::update(Own().getOwnDataPtr(), Task::KingdomUpSkillTimes, up_times);
			resetAttr();
			r[strMsg][2u] = break_reason;
			r[strMsg][3u] = up_times;
			_sign_save();
			return res_sucess;
		}
		else
		{
			return break_reason;
		}
		
		//updateSkill();
	}

	void playerKingdom::dailyTick()
	{
		_con_times = 0;
		if (Own().isOnline())
			kingdom_sys.updateBuilding(Own().getOwnDataPtr());
		_sign_save();
	}

	void playerKingdom::getSkillInfo(Json::Value& info) const
	{
		const static std::string IdStr[] = {"0", "1", "2", "3", "4", "5", "6", "7", "8", "9"};
		info = Json::objectValue;
		ForEachC(KingdomSkillDatas, it, _skill_datas)
		{
			int id = it->first;
			info[id >= 10? Common::toString(id) : IdStr[id]] = it->second->_lv;
		}
		info["srt"] = _skill_reset_times;
	}

	void playerKingdom::updateSkill()
	{
		Json::Value msg;
		msg[strMsg][0u] = res_sucess;
		Json::Value& ref_skill = msg[strMsg][1u];
		ref_skill = Json::arrayValue;
		ForEachC(KingdomSkillDatas, it, _skill_datas)
		{
			Json::Value tmp;
			it->second->getInfo(tmp);
			ref_skill.append(tmp);
		}
		Own().sendToClient(gate_client::player_kingdom_showskill_resp, msg);
	}

	const int* playerKingdom::getAttr()
	{
		if (!_attrs_inited)
		{
			resetAttr();
			_attrs_inited = true;
		}
		return _attrs;
	}

	void playerKingdom::resetAttr()
	{
		memset(_attrs, 0x0, sizeof(_attrs[0u]) * characterNum);
		ForEachC(KingdomSkillDatas, it, _skill_datas)
		{
			KingdomSkillDataPtr ptr = it->second;
			KingdomSkillConfPtr conf = getSkillConf(ptr->_id);
			if (conf)
			{
				if (ptr->_lv <= 100)
					_attrs[conf->_arms_id] += ptr->_lv * conf->_arms_num;
				else
				{
					_attrs[conf->_arms_id] += 100 * conf->_arms_num;
					_attrs[conf->_arms_id100] += (ptr->_lv - 100) * conf->_arms_num100;
				}
			}
		}
		if (_attrs_inited)
			Own().Man().recalComonMan();
	}

	int playerKingdom::getSkillLvSum() const
	{
		int sum = 0;
		ForEachC(KingdomSkillDatas, it, _skill_datas)
			sum += it->second->_lv;
		return sum;
	}
}

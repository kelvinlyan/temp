#include "player_item.h"
#include "dbDriver.h"
#include "item_system.h"
#include "task_mgr.h"
#include "rescue_system.h"

namespace gg
{
	class AttriColor
	{
		public:
			static int Get(int eq_type, int attri_idx, int attri_val)
			{
				static AttriColor instance;
				return instance.getColor(eq_type, attri_idx, attri_val);
			}
		private:
			AttriColor()
			{
				loadFile();
			}
			void loadFile();
			int getColor(int eq_type, int attri_idx, int attri_val) const;
		private:
			typedef std::pair<int, int> Range;
			STDVECTOR(Range, Idx2Range);
			STDVECTOR(Idx2Range, Color2Idx);
			STDVECTOR(Color2Idx, Eq2Color);
			Eq2Color _eq_color;
	};

	void AttriColor::loadFile()
	{
		const Json::Value json = Common::loadJsonFile("./instance/equipment/reborn_limit.json");
		ForEachC(Json::Value, it1, json)
		{
			Color2Idx ci;
			const Json::Value& info1 = *it1;
			ForEachC(Json::Value, it2, info1)
			{
				Idx2Range ir;
				const Json::Value& info2 = *it2;
				ForEachC(Json::Value, it3, info2)
				{
					Range r;
					r.first = (*it3)[0u].asInt();
					r.second = (*it3)[1u].asInt();
					ir.push_back(r);
				}
				ci.push_back(ir);
			}
			_eq_color.push_back(ci);
		}
	}

	int AttriColor::getColor(int eq_type, int attri_idx, int attri_val) const
	{
		int eq = eq_type - 3;
		if (eq < 0 || eq >= _eq_color.size())
			return 0;
		const Color2Idx& ci = _eq_color[eq];
		for (unsigned c = 0; c < ci.size(); ++c)
	{
			const Idx2Range& ir = ci[c];
			if (attri_idx < 0 || attri_idx >= ir.size())
				continue;
			if (attri_val >= ir[attri_idx].first
				&& attri_val <= ir[attri_idx].second)
				return c + 1;
		}
		return 0;
	}

	enum
	{
		ACTIVE_REBORN2_COST = 100,
	};

	playerItem::playerItem(playerData* const own, const int id, const unsigned num /* = 1 */)
		: _auto_player(own)
	{
		localID = id;
		pos = itemDef::pos_bag;
		alive = true;
		memset(&declare, 0x0, sizeof(declare));
		cfgItemPtr config = getConfig();
		if (!config)return;
		declare._com.num = num;
		declare._com.num = declare._com.num > config->stackNum() ? config->stackNum() : declare._com.num;
		if (config->isEquip())
		{//����ϴ������
			declare._equip.gemID = -1;//��ʯ��ʼ��ΪûӴ-1
			declare._equip.level = 1;//װ����ʼ�ȼ�Ϊ1
			declare._equip.hold = -1;//װ����ʼ��Ĭ��ô���佫����
			declare._equip.rba = new(::GNew(sizeof(itemDeclare::equip::rbAttriList)))  itemDeclare::equip::rbAttriList();
			declare._equip.rba->resize(itemDeclare::rbNum);//���¶�λ����//��Ҫ����ı�
			declare._equip.rba_bk = new(::GNew(sizeof(itemDeclare::equip::rbAttriList)))  itemDeclare::equip::rbAttriList();
			declare._equip.rba_bk->resize(itemDeclare::rbNum);//���¶�λ����//��Ҫ����ı�
			declare._equip.rba2 = new(::GNew(sizeof(itemDeclare::equip::rbAttriList)))  itemDeclare::equip::rbAttriList();
			declare._equip.rba2->resize(itemDeclare::rbNum);//���¶�λ����//��Ҫ����ı�
		}
	}

	playerItem::~playerItem()
	{
		cfgItemPtr config = getConfig();
		if (config && config->isEquip())
		{
			declare._equip.rba->~vector();
			::GDelete(declare._equip.rba);
			declare._equip.rba = NULL;
			declare._equip.rba_bk->~vector();
			::GDelete(declare._equip.rba_bk);
			declare._equip.rba_bk = NULL;
			declare._equip.rba2->~vector();
			::GDelete(declare._equip.rba2);
			declare._equip.rba2 = NULL;
		}
	}
	
	cfgItemPtr playerItem::getConfig()
	{
		if (!handlerCfg)handlerCfg = item_sys.getConfig(itemID());
		return handlerCfg;
	}

	bool playerItem::stackFull()
	{
		cfgItemPtr config = getConfig();
		return declare._com.num >= config->stackNum();
	}

	void playerItem::setPos(const itemDef::Position p)
	{
		pos = p;//����װ��������Ҫ����
		if (itemDef::pos_bag == pos)
		{
			Own().Items().moveToBag(localID);
			return;
		}
		if (itemDef::pos_man == pos)
		{
			Own().Items().moveToMan(localID);
			return;
		}
	}

	unsigned playerItem::getLv()
	{
		cfgItemPtr config = getConfig();
		if (!config->isEquip())return 0;
		return declare._equip.level;
	}

	void playerItem::clearUncertainRB()
	{
		cfgItemPtr config = getConfig();
		if (config->isEquip() && uncertainRB())
		{
			itemDeclare::equip::rbAttriList& vec = *declare._equip.rba_bk;
			for (unsigned i = 0; i < vec.size(); ++i)
			{
				vec[i].idx = -1;
				vec[i].val = 0;
			}
			_sign_auto();
		}
	}

	void playerItem::replaceUncertainRB(const bool recal /* = true */)
	{
		cfgItemPtr config = getConfig();
		if (config->isEquip() && uncertainRB())
		{
			itemDeclare::equip::rbAttriList& vec = *declare._equip.rba;
			itemDeclare::equip::rbAttriList& vec_bk = *declare._equip.rba_bk;
			for (unsigned i = 0; i < itemDeclare::rbNum; ++i)
			{
				vec[i] = vec_bk[i];
				vec_bk[i].idx = -1;
				vec_bk[i].val = 0;
				int color = AttriColor::Get(config->quality, vec[i].idx, vec[i].val);
				TaskMgr::update(Own().getOwnDataPtr(), Task::AttriColorNum, color);
			}
			if (recal && declare._equip.hold > 0)
			{
				playerManPtr man = Own().Man().findArmy(declare._equip.hold);
				if (man)
				{
					man->recalEquipAttri();
				}
			}
			_sign_auto();
		}
	}

	bool playerItem::uncertainRB()
	{
		cfgItemPtr config = getConfig();
		if (config->isEquip())
		{
			const itemDeclare::equip::rbAttriList& vec = *declare._equip.rba_bk;
			for (unsigned i = 0; i < vec.size(); ++i)
			{
				if (vec[i].idx >= 0)
				{
					return true;
				}
			}
			return false;
		}
		return false;
	}

	void playerItem::deleteAllReborn()
	{
		cfgItemPtr config = getConfig();
		if (!config->isEquip())return;
		itemDeclare::equip::rbAttriList& vec = *declare._equip.rba;
		itemDeclare::equip::rbAttriList& vec2 = *declare._equip.rba2;
		itemDeclare::equip::rbAttriList& vec_bk = *declare._equip.rba_bk;
		for (unsigned i = 0; i < itemDeclare::rbNum; ++i)
		{
			vec[i] = itemDeclare::rbAttri();
			vec2[i] = itemDeclare::rbAttri();
			vec_bk[i] = itemDeclare::rbAttri();
		}
		_sign_auto();
	}

	unsigned playerItem::activeRBNum()
	{
		cfgItemPtr config = getConfig();
		if (!config->isEquip())return 0;
		const itemDeclare::equip::rbAttriList& vec = *declare._equip.rba;
		unsigned num = 0;
		for (unsigned i = 0; i < vec.size(); ++i)
		{
			if (vec[i].idx >= 0)++num;
		}
		return num;
	}

	const static itemDeclare::rbAttri EmptyAttri = itemDeclare::rbAttri();
	const itemDeclare::rbAttri& playerItem::getReborn(const itemDeclare::rbIDX idx)
	{
		cfgItemPtr config = getConfig();
		if (!config->isEquip())return EmptyAttri;
		if (idx < 0 || idx >= (int)declare._equip.rba->size())return EmptyAttri;
		return declare._equip.rba->operator[](idx);
	}

	const itemDeclare::rbAttri& playerItem::getBKReborn(const itemDeclare::rbIDX idx)
	{
		cfgItemPtr config = getConfig();
		if (!config->isEquip())return EmptyAttri;
		if (idx < 0 || idx >= (int)declare._equip.rba_bk->size())return EmptyAttri;
		return declare._equip.rba_bk->operator[](idx);
	}

	void playerItem::tryRecal()
	{
		cfgItemPtr config = getConfig();
		if (!config->isEquip())return;
		if (declare._equip.hold > 0)
		{
			playerManPtr man = Own().Man().findArmy(declare._equip.hold);
			if (man)
			{
				man->recalEquipAttri();
			}
		}
	}

	vector<AttributeIDX> playerItem::rebornBKIdxList()
	{
		vector<AttributeIDX> list;
		cfgItemPtr config = getConfig();
		if (!config->isEquip() || !item_sys.canRebornQuality(config->_declare._equip.rebornIdx))return list;
		itemDeclare::equip::rbAttriList& vec = *declare._equip.rba_bk;
		for (unsigned i = 0; i < vec.size(); ++i)
		{
			if (vec[i].idx < 0)continue;
			list.push_back((AttributeIDX)vec[i].idx);
		}
		return list;
	}

	vector<AttributeIDX> playerItem::reborn2IdxList()
	{
		vector<AttributeIDX> list;
		cfgItemPtr config = getConfig();
		if (!config->isEquip() || !item_sys.canRebornQuality(config->_declare._equip.rebornIdx))return list;
		itemDeclare::equip::rbAttriList& vec = *declare._equip.rba2;
		for (unsigned i = 0; i < vec.size(); ++i)
		{
			if (vec[i].idx < 0)continue;
			list.push_back((AttributeIDX)vec[i].idx);
		}
		return list;
	}

	vector<AttributeIDX> playerItem::rebornIdxList()
	{
		vector<AttributeIDX> list;
		cfgItemPtr config = getConfig();
		if (!config->isEquip() || !item_sys.canRebornQuality(config->_declare._equip.rebornIdx))return list;
		itemDeclare::equip::rbAttriList& vec = *declare._equip.rba;
		for (unsigned i = 0; i < vec.size(); ++i)
		{
			if (vec[i].idx < 0)continue;
			list.push_back((AttributeIDX)vec[i].idx);
		}
		return list;
	}

	static bool rebornActived(const itemDeclare::equip::rbAttriList& vec)
	{
		for (unsigned i = 0; i < vec.size(); ++i)
		{
			if (vec[i].idx >= 0)
				return true;
		}
		return false;
	}

	int playerItem::activeReborn2()
	{
		cfgItemPtr config = getConfig();
		if (!config->isEquip() || !item_sys.canRebornQuality(config->_declare._equip.rebornIdx))
			return err_item_can_not_reborn;

		if (rebornActived(*declare._equip.rba2)
			|| !rebornActived(*declare._equip.rba))
			return err_illedge;

		if (Own().Res().getCash() < ACTIVE_REBORN2_COST)
			return err_cash_not_enough;

		Own().Res().alterCash(0-(int)ACTIVE_REBORN2_COST);

		const unsigned rbIdx = config->_declare._equip.rebornIdx;

		itemDeclare::equip::rbAttriList& vec = *declare._equip.rba;
		itemDeclare::equip::rbAttriList& vec2 = *declare._equip.rba2;

		for (unsigned i = 0; i < vec.size(); ++i)
		{
			if (vec[i].idx >= 0)
			{
				vec2[i] = item_sys.CreateRebornValue(rbIdx, reborn2IdxList());
			}
		}
		Log(DBLOG::strLogPlayerItem, Own().getOwnDataPtr(), 5, ID(), (int)ACTIVE_REBORN2_COST);
		_sign_auto();
		return res_sucess;
	}

	int playerItem::switchReborn()
	{
		if (!rebornActived(*declare._equip.rba)
			|| !rebornActived(*declare._equip.rba2))
			return err_illedge;
		
		itemDeclare::equip::rbAttriList* tmp = declare._equip.rba;
		declare._equip.rba = declare._equip.rba2;
		declare._equip.rba2 = tmp;

		clearUncertainRB();
		tryRecal();
		Log(DBLOG::strLogPlayerItem, Own().getOwnDataPtr(), 6, ID(), 0);
		_sign_auto();
		return res_sucess;
	}

	int playerItem::activeReborn(const AttributeIDX atIdx, const int val)
	{
		return activeReborn(itemDeclare::rbAttri(atIdx, val));
	}

	int playerItem::activeReborn(const itemDeclare::rbAttri attri)
	{
		cfgItemPtr config = getConfig();
		if (!config->isEquip() || !item_sys.canRebornQuality(config->_declare._equip.rebornIdx))return err_item_can_not_reborn;
		itemDeclare::equip::rbAttriList& vec = *declare._equip.rba;
		itemDeclare::equip::rbAttriList& vec2 = *declare._equip.rba2;
		itemDeclare::equip::rbAttriList& vec_bk = *declare._equip.rba_bk;
		const unsigned rbIdx = config->_declare._equip.rebornIdx;
		unsigned num = 0;
		for (unsigned i = 0; i < vec.size(); ++i)
		{
			if (vec[i].idx == attri.idx)
			{
				return err_item_same_reborn;
			}
			if (vec[i].idx < 0)
			{
				vec[i] = attri;
				if (uncertainRB())
				{
					vec_bk[i] = item_sys.CreateRebornValue(rbIdx, rebornBKIdxList());
				}
				if (rebornActived(vec2))
				{
					vec2[i] = item_sys.CreateRebornValue(rbIdx, reborn2IdxList());
				}
				_sign_auto();
				break;
			}
		}
		tryRecal();
		return res_sucess;
	}

	int playerItem::setReborn(const itemDeclare::rbIDX idx, const AttributeIDX atIdx, const int val, const bool recal /* = true */, const bool force /* = false */)
	{
		return setReborn(idx, itemDeclare::rbAttri(atIdx, val));
	}

	int playerItem::setReborn(const itemDeclare::rbIDX idx, const itemDeclare::rbAttri attri, const bool recal /* = true */, const bool force /* = false */)
	{
		cfgItemPtr config = getConfig();
		if (!config->isEquip() || !item_sys.canRebornQuality(config->_declare._equip.rebornIdx))return err_item_can_not_reborn;
		itemDeclare::equip::rbAttriList& vec = *declare._equip.rba;
		if(!force)
		{
			for (unsigned i = 0; i < vec.size(); ++i)
			{
				if (vec[i].idx == attri.idx)
				{
					return err_item_same_reborn;
				}
			}
		}
		vec[idx] = attri;
		_sign_auto();
		if (recal && declare._equip.hold > 0)
		{
			playerManPtr man = Own().Man().findArmy(declare._equip.hold);
			if (man)
			{
				man->recalEquipAttri();
			}
		}
		return res_sucess;
	}

	void playerItem::setBKReborn(const itemDeclare::rbIDX idx, const AttributeIDX atIdx, const int val)
	{
		setBKReborn(idx, itemDeclare::rbAttri(atIdx, val));
	}

	void playerItem::setBKReborn(const itemDeclare::rbIDX idx, const itemDeclare::rbAttri attri)
	{
		cfgItemPtr config = getConfig();
		if (!config->isEquip())return;
		itemDeclare::equip::rbAttriList& vec = *declare._equip.rba_bk;
		vec[idx] = attri;
		_sign_auto();
	}

	cfgItemPtr playerItem::getGemConfig()
	{
		cfgItemPtr config = getConfig();
		if (config->isEquip())return item_sys.getConfig(declare._equip.gemID);
		return cfgItemPtr();
	}

	bool playerItem::hasGem()
	{
		cfgItemPtr config = getConfig();
		if (!config->isEquip())return false;
		return declare._equip.gemID > 0;
	}

	int playerItem::canOnGem()
	{
		cfgItemPtr config = getConfig();
		if (!config->isEquip() || config->quality < itemDef::yellow)return err_illedge;
		if(hasGem())return err_equip_hold_gem;
		return res_sucess;
	}

	int playerItem::canOFFGem()
	{
		if (!hasGem())return res_sucess;
		if (Own().Items().canAddItem(declare._equip.gemID))return res_sucess;
		return err_bag_full;
	}

	void playerItem::ExchangeGem(playerItem& other_item, const bool recal /* = true */)
	{
		{
			cfgItemPtr config = getConfig();
			if (!config->isEquip() || config->quality < itemDef::yellow)return;
		};
		{
			cfgItemPtr config = other_item.getConfig();
			if (!config->isEquip() || config->quality < itemDef::yellow)return;
		};
		const int item_1_gem = gemID();
		const int item_2_gem = other_item.gemID();
		declare._equip.gemID = item_2_gem;
		other_item.declare._equip.gemID = item_1_gem;
		if (recal && declare._equip.hold > 0)
		{
			playerManPtr man = Own().Man().findArmy(declare._equip.hold);
			if (man)	man->recalEquipAttri();
		}
		if (recal && other_item.declare._equip.hold > 0)
		{
			playerManPtr man = Own().Man().findArmy(other_item.declare._equip.hold);
			if (man)	man->recalEquipAttri();
		}
		_sign_auto();
		other_item._sign_auto();
	}

	int playerItem::OnGem(const int itemID, const bool recal /* = true */)
	{
		int res = canOnGem();
		if (res != res_sucess)return res;
		cfgItemPtr gem_config = item_sys.getConfig(itemID);
		if (!gem_config || !gem_config->isGem())return err_illedge;
		declare._equip.gemID = itemID;
		if (recal && declare._equip.hold > 0)
		{
			playerManPtr man = Own().Man().findArmy(declare._equip.hold);
			if (man)	man->recalEquipAttri();
		}
		_sign_auto();
		TaskMgr::update(Own().getOwnDataPtr(), Task::InlayGemOfLv);
		TaskMgr::update(Own().getOwnDataPtr(), Task::InLayTimes, 1);
		return res_sucess;
	}

	int playerItem::OFFGem(const bool recal /* = true */)
	{
		int res = canOFFGem();
		if (res != res_sucess)return res;
		Own().Items().addItem(declare._equip.gemID);
		declare._equip.gemID = 0;
		if (recal && declare._equip.hold > 0)
		{
			playerManPtr man = Own().Man().findArmy(declare._equip.hold);
			if (man)man->recalEquipAttri();
		}
		_sign_auto();
		TaskMgr::update(Own().getOwnDataPtr(), Task::InlayGemOfLv);
		return res_sucess;
	}

	int playerItem::gemID()
	{
		cfgItemPtr config = getConfig();
		if (!config->isEquip())return -1;
		return declare._equip.gemID;
	}

	int playerItem::setLv(const unsigned lv, const bool recal /* = true */)
	{
		cfgItemPtr config = getConfig();
		if (!config->isEquip())return err_illedge;
		const vector<int>& costList = item_sys.equipRiseUpCost(config->_declare._equip.upgradeUse);
		if (lv > costList.size())return err_illedge;
		declare._equip.level = lv;
		if (recal && declare._equip.hold > 0)
		{
			playerManPtr man = Own().Man().findArmy(declare._equip.hold);
			if (man)	man->recalEquipAttri();
		}
		_sign_auto();
		return res_sucess;
	}

	int playerItem::riseUpLv(const unsigned lv, const bool recal /* = true */)
	{
		cfgItemPtr config = getConfig();
		if (!config->isEquip())return err_illedge;
		const vector<int>& costList = item_sys.equipRiseUpCost(config->_declare._equip.upgradeUse);
		unsigned setlv = lv + declare._equip.level;
		if (setlv > costList.size())setlv = costList.size();
		declare._equip.level = setlv;
		if (recal && declare._equip.hold > 0)
		{
			playerManPtr man = Own().Man().findArmy(declare._equip.hold);
			if (man)	man->recalEquipAttri();
		}
		_sign_auto();
		return res_sucess;
	}

	int playerItem::getHandler()
	{
		cfgItemPtr config = getConfig();
		if (config->isEquip())
		{
			return declare._equip.hold;
		}
		return -1;
	}

	bool playerItem::hasHandler()
	{
		cfgItemPtr config = getConfig();
		if (config->isEquip())
		{
			return declare._equip.hold > 0;
		}
		return false;
	}

	void playerItem::setHandler(const int manID)
	{
		cfgItemPtr config = getConfig();
		if (config->isEquip())
		{
// 			if (manID < 100)declare._equip.hold = -1;//û���佫
// 			else declare._equip.hold = manID / 100;//ԭʼID
			declare._equip.hold = manID;
			_sign_update();
		}
	}

	bool playerItem::deleteItem(const bool update /* = true */)
	{
		if (!Alive())return false;
		cfgItemPtr config = getConfig();
		const int old_num = declare._com.num;
		declare._com.num = 0;
		checkOver();
		_sign_save();
		if (update)_sign_update();
		Log(DBLOG::strLogItemStack, Own().getOwnDataPtr(), -1, Pos(), itemID(), ID(), old_num, 0, config->quality, config->isEquip() ? config->_declare._equip.equipPos : -1, getLv());
		return true;
	}

	void playerItem::checkOver()
	{
		if (declare._com.num < 1)
		{
			alive = false;
			cfgItemPtr config = getConfig();
			if (config->isEquip())
			{
				OFFGem(false);
				playerManPtr man = Own().Man().findArmy(declare._equip.hold);
				if (man)	man->offEquipByItem(localID);
			}
		}
	}

	void playerItem::setNum(const unsigned num, const bool update /* = true */)
	{
		if (!Alive())return;
		cfgItemPtr config = getConfig();
		declare._com.num = num;
		declare._com.num = declare._com.num > config->stackNum() ? config->stackNum() : declare._com.num;
		checkOver();
		_sign_save();
		if (update)_sign_update();
	}

	unsigned playerItem::addNum(const unsigned num)
	{
		if (!Alive())return 0;
		cfgItemPtr config = getConfig();
		int old_num = declare._com.num;
		declare._com.num += num;
		declare._com.num = declare._com.num > config->stackNum() ? config->stackNum() : declare._com.num;
		if (declare._com.num >= config->stackNum()){ Own().Items().tickFull(localID); }
		_sign_auto();
		Log(DBLOG::strLogItemStack, Own().getOwnDataPtr(), -1, Pos(), itemID(), ID(), old_num, Num(), config->quality, config->isEquip() ? config->_declare._equip.equipPos : -1, getLv());
		return declare._com.num - old_num;
	}

	unsigned playerItem::cutNum(const unsigned num)
	{
		if (!Alive())return 0;
		if (num < 1)return 0;
		cfgItemPtr config = getConfig();
		int old_num = declare._com.num;
		if (declare._com.num >= num){ declare._com.num -= num; }
		else declare._com.num = 0;
		checkOver();
		if (Alive() && declare._com.num < config->stackNum()){ Own().Items().tickNotFull(localID); }
		_sign_auto();
		Log(DBLOG::strLogItemStack, Own().getOwnDataPtr(), -1, Pos(), itemID(), ID(), old_num, Num(), config->quality, config->isEquip() ? config->_declare._equip.equipPos : -1, getLv());
		return old_num - declare._com.num;
	}

	Json::Value playerItem::toGMJson()
	{
		Json::Value jItem;
		jItem[0u] = localID;
		jItem[1u] = declare._com.num;
		cfgItemPtr config = getConfig();
		if (config->isEquip())
		{
			jItem[2u] = declare._equip.level;
			jItem[3u] = declare._equip.gemID;
			Json::Value& eqRB = (jItem[4u] = Json::arrayValue);
			Json::Value& eqRB2 = (jItem[5u] = Json::arrayValue);
			const itemConfig::EQUIP& _equip = config->_declare._equip;
			if (_equip.rebornIdx < itemDeclare::rbNum)//��ϴ����ֵ
			{
				for (unsigned i = 0; i < itemDeclare::rbNum; ++i)
				{
					const itemDeclare::rbAttri& rb = (*declare._equip.rba)[i];
					const itemDeclare::rbAttri& rb2 = (*declare._equip.rba2)[i];
					if (rb.idx >= 0)
					{
						Json::Value attriJson;
						attriJson.append(rb.idx);
						attriJson.append(rb.val);
						eqRB.append(attriJson);
					}
					if (rb2.idx >= 0)
					{
						Json::Value attriJson;
						attriJson.append(rb2.idx);
						attriJson.append(rb2.val);
						eqRB2.append(attriJson);
					}
				}
			}
		}
		return jItem;
	}

	qValue playerItem::toJson()
	{
		qValue jItem(qJson::qj_object);
		jItem.addMember("id", localID);
		jItem.addMember("al", Alive());
		if (Alive())
		{
			jItem.addMember("n", declare._com.num);
			cfgItemPtr config = getConfig();
			jItem.addMember("t", config->state);
			if (config->isEquip())
			{
				jItem.addMember("lv", declare._equip.level);
				jItem.addMember("h", declare._equip.hold);
				jItem.addMember("g", declare._equip.gemID);
				qValue at_arr(qJson::qj_array);
				unsigned at_idx = declare._equip.level; 
				const itemConfig::EQUIP& _equip = config->_declare._equip;
				const vector<int>& attri = at_idx < _equip.equipAttri->size() ? _equip.equipAttri->operator[](at_idx) : _equip.equipAttri->back();
				const vector<double>& attri_rate = at_idx < _equip.equipAttriRate->size() ? _equip.equipAttriRate->operator[](at_idx) : _equip.equipAttriRate->back();
				for (unsigned i = 0; i < characterNum; ++i)
				{
					if (attri[i] != 0 || attri_rate[i] != 0.0)
					{
						qValue attriJson(qJson::qj_array);
						attriJson.append(i);
						attriJson.append(attri[i]);
						attriJson.append(attri_rate[i]);
						at_arr.append(attriJson);
					}
				}
				jItem.addMember("at", at_arr);

				qValue rb_arr(qJson::qj_array), rbb_arr(qJson::qj_array), rb2_arr(qJson::qj_array);
				if (item_sys.canRebornQuality(_equip.rebornIdx))
				{
					for (unsigned i = 0; i < itemDeclare::rbNum; ++i)
					{
						const itemDeclare::rbAttri& rb = (*declare._equip.rba)[i];
						const itemDeclare::rbAttri& rbb = (*declare._equip.rba_bk)[i];
						const itemDeclare::rbAttri& rb2 = (*declare._equip.rba2)[i];
						if (rb.idx >= 0)
						{
							qValue attriJson(qJson::qj_array);
							attriJson.append(rb.idx);
							attriJson.append(rb.val);
							rb_arr.append(attriJson);
						}
						if (rbb.idx >= 0)
						{
							qValue attriJson(qJson::qj_array);
							attriJson.append(rbb.idx);
							attriJson.append(rbb.val);
							rbb_arr.append(attriJson);
						}
						if (rb2.idx >= 0)
						{
							qValue attriJson(qJson::qj_array);
							attriJson.append(rb2.idx);
							attriJson.append(rb2.val);
							rb2_arr.append(attriJson);
						}
					}
				}
				jItem.addMember("rb", rb_arr);
				jItem.addMember("rbb", rbb_arr);
				jItem.addMember("rb2", rb2_arr);
			}
		}
		return jItem;
	}

	unsigned playerItem::Num()
	{
		cfgItemPtr config = getConfig();
		if (!alive)return 0;//ɾ��
		return declare._com.num;
	}

	void playerItem::_auto_end()
	{
		if (!alive)
		{
			Own().Items().rmItem(localID);
		}
	}

	bool playerItem::_auto_save()
	{
		mongo::BSONObj key = BSON(strPlayerID << Own().ID() << "lid" << localID);
		if (!alive)
		{
			db_mgr.RemoveCollection(DBN::dbPlayerItem, key);
			return true;
		}
		cfgItemPtr config = getConfig();
		if (config->isEquip())
		{
			mongo::BSONArrayBuilder arr, arr_bk, arr2;
			for (unsigned i = 0; i < itemDeclare::rbNum; ++i)
			{
				const itemDeclare::rbAttri& rb = (*declare._equip.rba)[i];
				const itemDeclare::rbAttri& rbb = (*declare._equip.rba_bk)[i];
				const itemDeclare::rbAttri& rb2 = (*declare._equip.rba2)[i];
				if (rb.idx >= 0)
				{
					arr << BSON("i" << rb.idx << "v" << rb.val);
				}
				if (rbb.idx >= 0)
				{
					arr_bk << BSON("i" << rbb.idx << "v" << rbb.val);
				}
				if (rb2.idx >= 0)
				{
					arr2 << BSON("i" << rb2.idx << "v" << rb2.val);
				}
			}
			mongo::BSONObj obj = BSON(strPlayerID << Own().ID() << "lid" << localID << "g" << declare._equip.gemID <<
				"n" << 1 << "lv" << declare._equip.level << "rb" << arr.arr() << "rbb" << arr_bk.arr() << "rb2" << arr2.arr());//װ���Ķѵ����Բ����� > 1
			return db_mgr.SaveMongo(DBN::dbPlayerItem, key, obj);
		}
		mongo::BSONObj obj = BSON(strPlayerID << Own().ID() << "lid" << localID <<
			"n" << declare._com.num);
		return db_mgr.SaveMongo(DBN::dbPlayerItem, key, obj);
	}

	bool playerItem::_on_sign_update()
	{
		Own().Items().tickItem(localID);
		return false;
	}

	//mgr
	playerItemMgr::playerItemMgr(playerData* const own) : _auto_player(own),
		/*CDRise(600),*/ _equipBuildTimes(0), UpCD(0), UpCDLock(false), _highWashTimes(0), _equipStrengthenTimes(0)
	{
		CDHelp = false;
	}

	void playerItemMgr::tickItem(const int localID)
	{
		updateItem[localID] = directGetItem(localID, itemDef::pos_bag | itemDef::pos_man);
		_sign_update();
	}

	void playerItemMgr::classFinal()
	{
		sortOut(false);//��������//����//���ǲ�����
	}

	void playerItemMgr::classLoad()
	{
		mongo::BSONObj key = BSON(strPlayerID << Own().ID());
		objCollection collection = db_mgr.Query(DBN::dbPlayerItem, key);
		for (unsigned i = 0; i < collection.size(); ++i)
		{
			mongo::BSONObj& obj = collection[i];
			const int localID = obj["lid"].Int();
			const unsigned num = (unsigned)obj["n"].Int();
			itemPtr item = Creator<playerItem>::Create(_Own, localID);
			cfgItemPtr config = item->getConfig();
			if (!config)continue;
			item->declare._com.num = num;
			if (config->isEquip())
			{
				if (!obj["lv"].eoo()){ item->declare._equip.level = (unsigned)obj["lv"].Int(); }
				if (!obj["g"].eoo()){ item->declare._equip.gemID = obj["g"].Int(); }
				if (!obj["rb"].eoo())
				{
					vector<mongo::BSONElement> vec = obj["rb"].Array();
					for (unsigned n = 0; n < itemDeclare::rbNum && n < vec.size(); ++n)
					{
						itemDeclare::rbAttri& rb = (*(item->declare._equip.rba))[n];
						rb.idx = vec[n]["i"].Int();
						rb.val = vec[n]["v"].Int();
					}
				}
				if (!obj["rbb"].eoo())
				{
					vector<mongo::BSONElement> vec = obj["rbb"].Array();
					for (unsigned n = 0; n < itemDeclare::rbNum && n < vec.size(); ++n)
					{
						itemDeclare::rbAttri& rb = (*(item->declare._equip.rba_bk))[n];
						rb.idx = vec[n]["i"].Int();
						rb.val = vec[n]["v"].Int();
					}
				}
				if (!obj["rb2"].eoo())
				{
					vector<mongo::BSONElement> vec = obj["rb2"].Array();
					for (unsigned n = 0; n < itemDeclare::rbNum && n < vec.size(); ++n)
					{
						itemDeclare::rbAttri& rb = (*(item->declare._equip.rba2))[n];
						rb.idx = vec[n]["i"].Int();
						rb.val = vec[n]["v"].Int();
					}
				}
			}
			mapItem[item->ID()] = item;
			mapBagItem[item->ID()] = item;
			mapFItem[item->itemID()][item->ID()] = item;
			if (item->Num() < config->stackNum())
			{
				mapFVItem[item->itemID()][item->ID()] = item;
			}
		};

		{//������CD����������
			mongo::BSONObj key = BSON(strPlayerID << Own().ID());
			mongo::BSONObj obj = db_mgr.FindOne(DBN::dbPlayerItemInfo, key);
			if (!obj.isEmpty())
			{
// 				CDRise = obj["cd"].Int();
// 				CDRise = obj["l"].Bool();
				UpCD = obj["cd"].Int();
				UpCDLock = obj["l"].Bool();
				checkNotEoo(obj["ebt"])
					_equipBuildTimes = obj["ebt"].Int();
				checkNotEoo(obj["hwt"])
					_highWashTimes = obj["hwt"].Int();
				checkNotEoo(obj["cdh"])
					CDHelp = obj["cdh"].Bool();
				checkNotEoo(obj["est"])
					_equipStrengthenTimes = obj["est"].Int();
			}
		};
	}

	Json::Value playerItemMgr::gmPackage()
	{
		Json::Value json;
		for (itemMap::iterator it = mapItem.begin(); it != mapItem.end(); ++it)
		{
			itemPtr item = it->second;
			if (!item || !item->Alive())continue;
			json.append(item->toGMJson());
		}
		return json;
	}


	void playerItemMgr::updateAll()
	{
		qValue data_list(qJson::qj_array), data_items(qJson::qj_array);
		unsigned num = 0;
		for (itemMap::iterator it = mapItem.begin(); it != mapItem.end(); )
		{
			itemPtr item = it->second;
			++it;
			if (!item)continue;
			++num;
			data_items.append(item->toJson());
			if (num > 100 || it == mapItem.end())
			{
				data_list.append(res_sucess);
				data_list.append(data_items);
				num = 0;
				Own().sendToClientFillMsg(gate_client::player_item_update_resp, data_list);
				data_list.toArray();
				data_items.toArray();
			}
		}
	}

	void playerItemMgr::updateUpCD()
	{
		UpOK();
		Json::Value json;
		json[strMsg][0u] = res_sucess;
		json[strMsg][1u] = UpCD;
		json[strMsg][2u] = UpCDLock;
		json[strMsg][3u] = Own().EquipShowCD;
		json[strMsg][4u] = CDHelp;
		Own().sendToClient(gate_client::equip_cd_update_resp, json);
	}

	bool playerItemMgr::reduceUpCD(const unsigned num)
	{
		if (num < 1)return false;
		if (UpOK())return false;
		const unsigned now = Common::gameTime();
		if (UpCD >= num)
		{
			UpCD -= num;
		}
		if (now > UpCD)
		{
			if (UpCDLock)
			{
				UpCDLock = false;
				CDHelp = false;
			}
		}
		ownUpdate = true;
		_sign_auto();
		return true;
	}

	void playerItemMgr::clearUpCD()
	{
		UpCD = 0;
		UpCDLock = false;
		if (CDHelp)
		{
			CDHelp = false;
			rescue_sys.removeRescue(Rescue::rescue_equip_cd, Own().getOwnDataPtr());
		}
		ownUpdate = true;
		_sign_auto();
	}

	void playerItemMgr::addUpCD(const unsigned cd)
	{
		const unsigned now = Common::gameTime();
		if (now > UpCD)
		{
			UpCD = now;
			if (UpCDLock)
			{
				UpCDLock = false;
				CDHelp = false;
				rescue_sys.removeRescue(Rescue::rescue_equip_cd, Own().getOwnDataPtr());
			}
		}
		UpCD += cd;
		if (UpCD >= now + 10 * MINUTE)
		{
			UpCDLock = true;
		}
		ownUpdate = true;
		_sign_auto();
	}

	bool playerItemMgr::UpOK()
	{
		const unsigned now = Common::gameTime();
		if (now > UpCD)
		{
			if (UpCDLock)
			{
				UpCDLock = false;
				CDHelp = false;
				rescue_sys.removeRescue(Rescue::rescue_equip_cd, Own().getOwnDataPtr());
				ownUpdate = true;
				_sign_auto();
			}
		}
		return !UpCDLock;
	}

	bool playerItemMgr::_auto_save()
	{
		mongo::BSONObj key = BSON(strPlayerID << Own().ID());
		mongo::BSONObj obj = BSON(strPlayerID << Own().ID() << 
			"cd" << UpCD << "l" << UpCDLock << "ebt" << _equipBuildTimes <<
		"cdh" << CDHelp << "hwt" << _highWashTimes << "est" << _equipStrengthenTimes);
		return db_mgr.SaveMongo(DBN::dbPlayerItemInfo, key, obj);
	}

	void playerItemMgr::_auto_update()
	{
		qValue data_list(qJson::qj_array), data_items(qJson::qj_array);
		unsigned num = 0;
		for (itemMap::iterator it = updateItem.begin(); it != updateItem.end(); )
		{
			itemPtr item = it->second;
			++it;
			if (!item)continue;
			++num;
			data_items.append(item->toJson());
			if (num > 100 || it == updateItem.end())
			{
				data_list.append(res_sucess);
				data_list.append(data_items);
				num = 0;
				Own().sendToClientFillMsg(gate_client::player_item_update_resp, data_list);
				data_list.toArray();
				data_items.toArray();
			}
		}
		updateItem.clear();

		{//CD����
			if (ownUpdate)
			{
				ownUpdate = false;
				Json::Value json;
				json[strMsg][0u] = res_sucess;
				json[strMsg][1u] = UpCD;
				json[strMsg][2u] = UpCDLock;
				json[strMsg][3u] = Own().EquipShowCD;
				json[strMsg][4u] = CDHelp;
				Own().sendToClient(gate_client::equip_cd_update_resp, json);
			}
		};//
	}

	void playerItemMgr::rmItem(const int localID)
	{
		mapItem.erase(localID);//��������
		mapBagItem.erase(localID);
		mapManItem.erase(localID);
		itemMap& mapF = mapFItem[localID / 1000];
		mapF.erase(localID);//����Ȧ����
		itemMap& mapFV = mapFVItem[localID / 1000];
		mapFV.erase(localID);//δ��������Ȧ����
	}

	itemPtr playerItemMgr::getLocalItem(const int localID, const unsigned pos_set /* = itemDef::pos_bag */)
	{
		itemPtr item = directGetItem(localID, pos_set);
		if (item && item->Alive())return item;
		return itemPtr();
	}

	itemPtr playerItemMgr::directGetItem(const int localID, const unsigned pos_set /* = itemDef::pos_bag */)
	{
		itemMap::iterator it = mapItem.find(localID);
		if (it == mapItem.end())return itemPtr();
		itemPtr item = it->second;
		if ((item->Pos() & pos_set) > 0)return item;
		return itemPtr();
	}

	unsigned playerItemMgr::itemNum(const int itemID, const unsigned pos_set /* = itemDef::pos_bag */)
	{
		unsigned num = 0;
		itemMap& checkMap = mapFItem[itemID];
		for (itemMap::iterator it = checkMap.begin(); it != checkMap.end(); ++it)
		{
			itemPtr item = it->second;
			if ((item->Pos() & pos_set) > 0 && item->Alive())num += item->Num();
		}
		return num;
	}

	bool playerItemMgr::overItem(const int itemID, const unsigned num, const unsigned pos_set /* = itemDef::pos_bag */)
	{
		if (num == 0)return true;
		unsigned n = 0;
		itemMap& checkMap = mapFItem[itemID];
		for (itemMap::iterator it = checkMap.begin(); it != checkMap.end(); ++it)
		{
			itemPtr item = it->second;
			if ((item->Pos() & pos_set) > 0 && item->Alive())
			{
				n += item->Num();
			}
			if (n >= num)return true;
		}
		return false;
	}

	itemVec playerItemMgr::getItem(const int itemID, const unsigned pos_set /* = itemDef::pos_bag */)
	{
		itemVec vec;
		itemMap& checkMap = mapFItem[itemID];
		for (itemMap::iterator it = checkMap.begin(); it != checkMap.end(); ++it)
		{
			itemPtr item = it->second;
			if ((item->Pos() & pos_set) > 0 && item->Alive())
			{
				vec.push_back(item);
			}
		}
		return vec;
	}

	unsigned playerItemMgr::itemUsePos(const int itemID, const unsigned num /* = 1 */)
	{
		if (num < 1)return 0;
		cfgItemPtr config = item_sys.getConfig(itemID);
		if (!config)return 0xFFFFFFFF;
		itemMap& mapF = mapFVItem[itemID];
		unsigned cn = playerItemMgr::CalNum(mapF);
		unsigned cost_num = mapF.size() * config->stackNum() - cn;
		if (cost_num >= num)return 0;
		unsigned real_need_add = num - cost_num;
		unsigned real_need_pos = real_need_add / config->stackNum() + real_need_add % config->stackNum() ? 1 : 0;
		return real_need_pos;
	}

	bool playerItemMgr::canAddItem(const int itemID, const unsigned num /* = 1 */)
	{
		if (num < 1)return true;
		cfgItemPtr config = item_sys.getConfig(itemID);
		if (!config)return false;
		itemMap& mapF = mapFVItem[itemID];
		unsigned cn = playerItemMgr::CalNum(mapF);
		unsigned cost_num = mapF.size() * config->stackNum() - cn;
		if (cost_num >= num)return true;
		unsigned real_need_add = num - cost_num;
		unsigned real_need_pos = real_need_add / config->stackNum() + real_need_add % config->stackNum() ? 1 : 0;
		return !isOver(real_need_pos);
	}

	itemVec playerItemMgr::addItem(const int itemID, const unsigned num /* = 1 */)
	{
		itemVec vec;
		if (num < 1)return vec;
		if (!canAddItem(itemID, num))return vec;
		itemMap& checkMap = mapFVItem[itemID];
		cfgItemPtr config = item_sys.getConfig(itemID);
		if (!config)return vec;
		unsigned stackNum = config->stackNum();
		unsigned leave_num = num;
		if (config->canStack())
		{
			for (itemMap::iterator it = checkMap.begin(); it != checkMap.end();)
			{
				itemPtr item = it->second;
				++it;
				if (item->Num() < stackNum && item->Alive())
				{
					leave_num -= item->addNum(leave_num);
					vec.push_back(item);
				}
			}
		}
		if (leave_num > 0)
		{
			unsigned loop_times = leave_num / config->stackNum();
			for (unsigned i = 0; i < loop_times; ++i)
			{
				itemPtr item = CreateItem(config, config->stackNum());
				if(item)vec.push_back(item);
			}
			unsigned other_leave = leave_num % config->stackNum();
			if (other_leave > 0)
			{
				itemPtr item = CreateItem(config, other_leave);
				if (item)vec.push_back(item);
			}
		}
		if (itemID == 80001)
			TaskMgr::update(Own().getOwnDataPtr(), Task::StoneNum, num);
		if (config->isEquip())
			TaskMgr::update(Own().getOwnDataPtr(), Task::EquipNumOfColor);
		if (config->isGem())
			TaskMgr::update(Own().getOwnDataPtr(), Task::GemStoneNumOfLv);
		return vec;
	}

	itemPtr playerItemMgr::CreateItem(cfgItemPtr config, const unsigned num)
	{
		if (num < 1)return itemPtr();
		int localID = config->itemID * 1000;
		while (getLocalItem(localID, itemDef::pos_bag | itemDef::pos_man))
		{
			++localID;
		}
		if (localID / 1000 != config->itemID)return itemPtr();
		itemPtr item = Creator<playerItem>::Create(_Own, localID, num);
		itemMap& mapF = mapFItem[config->itemID];
		mapItem[item->ID()] = item;
		mapBagItem[item->ID()] = item;
		mapF[item->ID()] = item;
		if (!item->stackFull())
		{
			itemMap& mapFV = mapFVItem[config->itemID];
			mapFV[item->ID()] = item;
		}
		if (config->isEquip())
		{
			const unsigned rbIdx = config->_declare._equip.rebornIdx;
			if (item_sys.canRebornQuality(rbIdx))
			{
				unsigned num = item_sys.CreateRebornNum();
				vector<itemDeclare::rbAttri> vec = item_sys.CreateRebornValueList(rbIdx, num);
				for (unsigned i = 0; i < vec.size(); ++i)
				{
					itemDeclare::rbAttri& attri = (*(item->declare._equip.rba))[i];
					attri = vec[i];
				}
			}
		}
		item->_sign_auto();
		Log(DBLOG::strLogItemStack, Own().getOwnDataPtr(), -1, item->Pos(), item->itemID(), item->ID(), 0, item->Num(), config->quality, config->isEquip() ? config->_declare._equip.equipPos : -1, item->getLv());
		return item;
	}

	unsigned playerItemMgr::CalNum(itemMap& checkMap)
	{
		unsigned num = 0;
		for (itemMap::iterator it = checkMap.begin(); it != checkMap.end(); ++it)
		{
			itemPtr item = it->second;
			if (!item->Alive())continue;
			num += item->Num();
		}
		return num;
	}

	void playerItemMgr::sortOut(const bool update /* = true */)
	{
		for (itemFMap::iterator it = mapFVItem.begin(); it != mapFVItem.end(); ++it)
		{
			int itemID = it->first;
			itemMap& mapF = it->second;
			if (mapF.size() > 1)//��Ҫ����
			{
				unsigned num = playerItemMgr::CalNum(mapF);
				cfgItemPtr config = item_sys.getConfig(itemID);
				for (itemMap::iterator iit = mapF.begin(); iit != mapF.end();)
				{
					itemPtr item = iit->second;
					++iit;
					if (!item->Alive())continue;
					if (num > 0)
					{
						if (config->stackNum() > num)
						{
							item->setNum(num, update);
							num = 0;
						}
						else
						{
							item->setNum(config->stackNum(), update);
							num -= config->stackNum();
						}
					}
					else
					{
						item->deleteItem(update);
					}
				}
			}
		}
	}

	int playerItemMgr::removeItem(const int itemID, const unsigned num /* = 1 */, const unsigned pos_set /* = itemDef::pos_bag */)
	{
		if (num < 1)return res_sucess;
		unsigned hold_num = itemNum(itemID, pos_set);
		if (hold_num < num)return err_item_not_enough;
		unsigned cut_num = num;
		{//���ȿ۳�δ���ĵ���
			itemMap& checkMap = mapFVItem[itemID];
			for (itemMap::iterator it = checkMap.begin(); it != checkMap.end();)
			{
				itemPtr item = it->second;
				++it;
				if (cut_num > 0)
				{
					cut_num -= item->cutNum(cut_num);
					continue;
				}
				break;
			}
		};
		if (cut_num > 0)
		{
			itemMap& checkMap = mapFItem[itemID];
			for (itemMap::iterator it = checkMap.begin(); it != checkMap.end();)
			{
				itemPtr item = it->second;
				++it;
				if (!item->Alive())continue;
				if (cut_num > 0)
				{
					cut_num -= item->cutNum(cut_num);
					continue;
				}
				break;
			}
		}
		
		cfgItemPtr config = item_sys.getConfig(itemID);
		if (config->isGem())
			TaskMgr::update(Own().getOwnDataPtr(), Task::GemStoneNumOfLv);
		if (config->isEquip())
			TaskMgr::update(Own().getOwnDataPtr(), Task::EquipNumOfColor);
		return res_sucess;
	}

	void playerItemMgr::tickFull(const int localID)
	{
		itemMap& mapFV = mapFVItem[localID / 1000];
		mapFV.erase(localID);//δ��������Ȧ����
	}

	void playerItemMgr::tickNotFull(const int localID)
	{
		itemPtr item = getLocalItem(localID);
		if (!item)return;
		itemMap& mapFV = mapFVItem[localID / 1000];
		mapFV[localID] = item;//δ��������Ȧ����
	}

	void playerItemMgr::moveToBag(const int localID)
	{
		itemPtr item = getLocalItem(localID, itemDef::pos_man | itemDef::pos_bag);
		if (!item)return;
		mapBagItem[item->ID()] = item;
		mapManItem.erase(item->ID());
	}

	void playerItemMgr::moveToMan(const int localID)
	{
		itemPtr item = getLocalItem(localID, itemDef::pos_man | itemDef::pos_bag);
		if (!item)return;
		mapManItem[item->ID()] = item;
		mapBagItem.erase(item->ID());
	}
	
	unsigned playerItemMgr::getMaxEquipLv()
	{
		unsigned max = 0;
		ForEach(itemMap, it, mapItem)
		{
			if (it->second->getConfig()->isEquip()
				&& it->second->getLv() > max)
				max = it->second->getLv();
		}
		return max;
	}

	unsigned playerItemMgr::getEquipNumOfColor(int color)
	{
		unsigned sum = 0;
		ForEach(itemMap, it, mapItem)
		{
			cfgItemPtr ptr = it->second->getConfig();
			if (ptr->isEquip() && ptr->quality == color)
				++sum;
		}
		return sum;
	}

	unsigned playerItemMgr::getOnGemNumOfLv(int lv)
	{
		int sum = 0;
		if (lv == 0)
		{
			ForEach(itemMap, it, mapManItem)
			{
				int gem_id = it->second->gemID();
				if (gem_id != -1)
					++sum;
			}
		}
		else
		{
			ForEach(itemMap, it, mapManItem)
			{
				int gem_id = it->second->gemID();
				if (gem_id != -1 && (gem_id % 100 - 1) == lv)
					++sum;
			}
		}
		return sum;
	}

	unsigned playerItemMgr::getGemNumOfLv(int lv)
	{
		int sum = 0;
		if (lv == 0)
		{
			ForEach(itemMap, it, mapItem)
			{
				cfgItemPtr ptr = it->second->getConfig();
				if (ptr->isGem())
					sum += it->second->Num();
				else if (ptr->isEquip() && it->second->gemID() != -1)
					++sum;
			}
		}
		else
		{
			ForEach(itemMap, it, mapItem)
			{
				cfgItemPtr ptr = it->second->getConfig();
				if (ptr->isGem())
				{
					int item_id = ptr->itemID;
					if ((item_id % 100 - 1) == lv)
						sum += it->second->Num();
				}
				else if (ptr->isEquip() && it->second->gemID() != -1)
				{
					int item_id = it->second->gemID();
					if ((item_id % 100 - 1) == lv)
						++sum;
				}
			}
		}
		return sum;
	}

	void playerItemMgr::tickEquipBuild()
	{
		++_equipBuildTimes;
		TaskMgr::update(Own().getOwnDataPtr(), Task::ForgeAllTimes);
		_sign_save();
	}

	void playerItemMgr::tickWashTimes(bool high, unsigned times)
	{
		TaskMgr::update(Own().getOwnDataPtr(), Task::WashTimes, times);
		if (high)
		{
			++_highWashTimes;
			_sign_save();
			TaskMgr::update(Own().getOwnDataPtr(), Task::HighWashTimes, times);
			TaskMgr::update(Own().getOwnDataPtr(), Task::HighWashTimes2, times);
		}
	}

	void playerItemMgr::tickEquipStrengthen(unsigned times)
	{
		_equipStrengthenTimes += times;
		TaskMgr::update(Own().getOwnDataPtr(), Task::StrengthenTimes, times);
		TaskMgr::update(Own().getOwnDataPtr(), Task::StrengthenAllTimes);
		_sign_save();
	}

	int playerItemMgr::switchReborn(const Json::Value& el)
	{
		int res = err_illedge;
		ForEachC(Json::Value, it, el)
		{
			int localID = (*it).asInt();
			itemPtr item = getLocalItem(localID, itemDef::pos_bag | itemDef::pos_man);
			if (!item) continue;
			cfgItemPtr config = item->getConfig();
			if (!config->isEquip()) continue;
			if (item->switchReborn() == res_sucess)
				res = res_sucess;
		}
		return res;
	}

	int playerItemMgr::treasureResolve(int type, int item_id, int num, Json::Value& r)
	{
		return err_illedge;
		/*
		if (num < 1)
			return err_illedge;
		int piece_num = TreasureResolve::shared().GetPieceNum(item_id);
		if (piece_num < 1)
			return err_illedge;
		int own_num = itemNum(item_id);
		if (own_num < num)
			return err_item_not_enough;
		if (type == 1 && Own().Res().getCash() < (piece_num * num * TreasureResolve::CostRate))
			return err_cash_not_enough;
		int ret_num = piece_num * num;
		int times = TreasureResolve::shared().randTimes(type);
		ret_num *= times;
		if (!canAddItem(TreasureResolve::PieceItemID, ret_num))
			return err_item_can_not_reborn;
		if (type == 1)
			Own().Res().alterCash(0-(piece_num * num * TreasureResolve::CostRate));
		removeItem(item_id, num);
		addItem(TreasureResolve::PieceItemID, ret_num);
		r[1u] = ret_num;
		return res_sucess;
		*/
	}
}

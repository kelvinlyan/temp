#include "exam_event.h"

namespace gg
{

	exam_event::exam_event(imperial::EventType type)
		: _type(type)
	{
	}


	exam_event::~exam_event()
	{
	}

	///////////////////////////////////Answer///////////////////////////////////////

	exam_answer_event::exam_answer_event(imperial::AnswerSinglePtr ptr)
		:exam_event(imperial::Answer),
		_config(ptr)
	{}

	ActionBoxList exam_answer_event::getBox(int flag)
	{
		ActionBoxList list;
		return list;
	}

	void exam_answer_event::getDetail(Json::Value& r)
	{}

	std::string exam_answer_event::getStr(int flag)
	{
		return std::string();
	}

	int exam_answer_event::getGrade(int flag)
	{
		return 0;
	}

	exam_answer_event::~exam_answer_event()
	{}

	//////////////////////////////////Suggection////////////////////////////////////////

	exam_suggection_event::exam_suggection_event(imperial::SuggectionSinglePtr ptr)
		:exam_event(imperial::Suggection),
		_config(ptr)
	{}

	ActionBoxList exam_suggection_event::getBox(int flag)
	{
		ActionBoxList list;
		return list;
	}

	void exam_suggection_event::getDetail(Json::Value& r)
	{}

	std::string exam_suggection_event::getStr(int flag)
	{
		return std::string();
	}

	int exam_suggection_event::getGrade(int flag)
	{
		return 0;
	}

	exam_suggection_event::~exam_suggection_event()
	{}

	//////////////////////////////////Fight////////////////////////////////////////

	exam_fight_event::exam_fight_event(imperial::FightSinglePtr ptr)
		:exam_event(imperial::Fight),
		_config(ptr)
	{}

	ActionBoxList exam_fight_event::getBox(int flag)
	{
		ActionBoxList list;
		return list;
	}

	void exam_fight_event::getDetail(Json::Value& r)
	{}

	std::string exam_fight_event::getStr(int flag)
	{
		return std::string();
	}

	int exam_fight_event::getGrade(int flag)
	{
		return 0;
	}

	exam_fight_event::~exam_fight_event()
	{}

	////////////////////////////////////Purchase//////////////////////////////////////

	exam_purchase_event::exam_purchase_event(imperial::PurchaseSinglePtr ptr)
		:exam_event(imperial::Purchase),
		_config(ptr)
	{}

	ActionBoxList exam_purchase_event::getBox(int flag)
	{
		ActionBoxList list;
		return list;
	}

	void exam_purchase_event::getDetail(Json::Value& r)
	{}

	std::string exam_purchase_event::getStr(int flag)
	{
		return std::string();
	}

	int exam_purchase_event::getGrade(int flag)
	{
		return 0;
	}

	exam_purchase_event::~exam_purchase_event()
	{}

}

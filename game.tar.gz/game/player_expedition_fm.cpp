#include "player_expedition_fm.h"
#include "man_system.h"
#include "game_time.h"

namespace gg
{
	playerExpeditionFM::playerExpeditionFM(playerData* const own)
		: _auto_player(own), _cur_fm_id(-1), _bv(-1)
	{
		_cur_fm.assign(9, playerManPtr());
	}

	void playerExpeditionFM::resetFM()
	{
		bool save = false;
		for (unsigned i = 0; i < _cur_fm.size(); ++i)
		{
			if (_cur_fm[i] &&
				Own().Expedition().dead(_cur_fm[i]->uniqueID()))
			{
				_cur_fm[i].reset();
				calBV();
				save = true;
			}
		}
		if (save)
			_sign_save();
	}

	void playerExpeditionFM::classLoad()
	{
		mongo::BSONObj key = BSON(strPlayerID << Own().ID());
		mongo::BSONObj obj = db_mgr.FindOne(DBN::dbPlayerExpeditionFM, key);
		if (obj.isEmpty())
			return;
		_cur_fm_id = obj["ci"].Int();
		{
			const std::vector<mongo::BSONElement> ele = obj["cf"].Array();
			for (unsigned i = 0; i < 9; ++i)
				_cur_fm[i] = Own().Man().findArmy(ele[i].Int());
		}
	}

	bool playerExpeditionFM::_auto_save()
	{
		mongo::BSONObj key = BSON(strPlayerID << Own().ID());
		mongo::BSONObjBuilder obj;
		obj << strPlayerID << Own().ID() << "ci" << _cur_fm_id;
		{
			mongo::BSONArrayBuilder b;
			ForEachC(Expedition::ManList, it, _cur_fm)
				b.append((*it)? (*it)->uniqueID() : -1);
			obj << "cf" << b.arr();
		}
		return db_mgr.SaveMongo(DBN::dbPlayerExpeditionFM, key, obj.obj());
	}

	void playerExpeditionFM::initFM()
	{
		_cur_fm_id = Own().WarFM().currentID();
		std::vector<int> fm;
		std::vector<playerManPtr> war_fm = Own().WarFM().currentFM();
		for (unsigned i = 0; i < war_fm.size(); ++i)
		{
			if (war_fm[i] && war_fm[i]->LV() >= 40)
				fm.push_back(war_fm[i]->armyID());
			else
				fm.push_back(-1);
		}
		setFormation(fm);
		_sign_save();
	}

	void playerExpeditionFM::tickAt0500()
	{
		bool modified = false;
		if (_cur_fm_id != Own().WarFM().currentID())
		{
			_cur_fm_id = Own().WarFM().currentID();
			modified = true;
		}
		
		std::vector<playerManPtr> war_fm = Own().WarFM().currentFM();
		for (unsigned i = 0; i < war_fm.size(); ++i)
		{
			if (!war_fm[i] || war_fm[i]->LV() < 40)
			{
				if (_cur_fm[i])
				{
					_cur_fm[i].reset();
					modified = true;
				}
			}
			else
			{
				if (_cur_fm[i] != war_fm[i])
				{
					_cur_fm[i] = war_fm[i];
					modified = true;
				}
			}
		}

		if (modified)
		{
			_bv = -1;
			_sign_save();
		}
	}

	sBattlePtr playerExpeditionFM::getBattlePtr()
	{
		sBattlePtr sb = Creator<sideBattle>::Create();
		sb->playerID = Own().ID();
		sb->playerName = Own().Name();
		sb->isPlayer = true;
		sb->playerLevel = Own().LV();
		sb->playerNation = Own().Info().Nation();
		sb->playerFace = Own().Info().Face();
		sb->battleValue = bv();
		manList& ml = sb->battleMan;
		ml.clear();
		vector<Expedition::playerManPtr> ownMan = _cur_fm;
		for (unsigned i = 0; i < ownMan.size(); i++)
		{
			Expedition::playerManPtr man = ownMan[i];
			if (!man)continue;
			mBattlePtr mbattle = Creator<manBattle>::Create();
			cfgManPtr config = man_sys.getConfig(man->armyID());
			if (!config)continue;
			mbattle->manID = man->armyID();
			mbattle->battleValue = man->battleValue();
			mbattle->holdMorale = config->holdMorale;
			mbattle->set_skill_1(man->getSkill_1());
			mbattle->set_skill_2(man->getSkill_2());
			std::vector<int> talentList = man->getTalentList();
			for (unsigned tidx = 0; tidx < talentList.size(); ++tidx)
				mbattle->talent.push_back(talentList[tidx]);
			mbattle->armsType = config->armsType;
			mbattle->manLevel = man->LV();
			mbattle->currentIdx = i % 9;
			memcpy(mbattle->armsModule, config->armsModules, sizeof(mbattle->armsModule));
			man->toInitialAttri(mbattle->initialAttri);
			man->toNoEquipAttri(curFMID(), mbattle->battleAttri);
			mbattle->currentHP = mbattle->getTotalAttri(idx_hp);
			const Expedition::ManInfo& man_info = Own().Expedition().getManInfo(man->uniqueID());
			if (man_info.hp != -1 && mbattle->currentHP > man_info.hp)
				mbattle->currentHP = man_info.hp;
			if (man_info.mp != -1)
				mbattle->setMorale(man_info.mp);
			if (0 == i)
			{
				sb->leaderMan = mbattle;
			}
			ml.push_back(mbattle);
		}
		return sb;
	}

	int playerExpeditionFM::curFMID()
	{
		if (_cur_fm_id == -1)
			initFM();
		return _cur_fm_id;
	}
	
	void playerExpeditionFM::getInfo(qValue& q)
	{
		q.addMember("i", curFMID());
		qValue f;
		ForEach(Expedition::ManList, it, _cur_fm)
		{
			playerManPtr& ptr = *it;	
			f.append(ptr? ptr->armyID() : -1);
		}
		q.addMember("f", f);
		q.addMember("bv", bv());
	}

	int playerExpeditionFM::changeFormation(int fm_id)
	{
		std::vector<int> fm;
		ForEachC(Expedition::ManList, it, _cur_fm)
		{
			if (*it)
				fm.push_back((*it)->armyID());
			else
				fm.push_back(-1);
		}
		bool fm_opened = false;
		const FMCFG::HOLEVEC& config = playerWarFM::getConfig(fm_id).HOLES;
		Expedition::ManList tmpList(9, playerManPtr());
		int idx = 0;
		for (unsigned i = 0; i < 9; ++i)
		{
			if (Own().LV() < config[i].LV) continue;
			if (!config[i].Use)continue;
			if (config[i].Process > 0 && !Own().War().isChallengeMap(config[i].Process))continue;
			fm_opened = true;
			for (; idx < 9; ++idx)
			{
				if (fm[idx] < 0)
					continue;
				playerManPtr man = Own().Man().findArmyByMan(fm[idx++]);
				if (man && man->LV() >= 40)
					tmpList[i] = man;
				break;
			}
		}
		if (!fm_opened)
			return err_format_hole_limit;
		_cur_fm_id = fm_id;
		_cur_fm = tmpList;
		calBV();
		_sign_auto();
		return res_sucess;
	}

	int playerExpeditionFM::setFormation(const std::vector<int>& fm)
	{
		if (fm.size() != 9)
			return err_illedge;
		const FMCFG::HOLEVEC& config = playerWarFM::getConfig(curFMID()).HOLES;
		boost::unordered_set<int> SAMEMAN;
		Expedition::ManList tmpList(9, playerManPtr());
		for (unsigned i = 0; i < 9; ++i)
		{
			if (fm[i] < 0)continue;
			//if (!SAMEMAN.insert(fm[i] / 100).second)return err_fomat_same_man;
			if (Own().LV() < config[i].LV)return err_format_hole_limit;
			if (!config[i].Use)return err_format_hole_limit;
			if (config[i].Process > 0 && !Own().War().isChallengeMap(config[i].Process))return err_format_hole_limit;
			if (Own().Expedition().dead(fm[i]))return err_illedge;
			playerManPtr man = Own().Man().findArmyByMan(fm[i]);
			if (!man || man->LV() < 40) return err_illedge;
			if (man && SAMEMAN.insert(man->uniqueID()).second == false)continue;//�ظ���
			tmpList[i] = man;
		}
		_cur_fm = tmpList;
		calBV();
		_sign_auto();
		return res_sucess;
	}

	int playerExpeditionFM::bv()
	{
		if (_bv == -1)
			_bv = calBV();
		return _bv;
	}

	int playerExpeditionFM::calBV()
	{
		_bv =  CalNoEqBV(Own().getOwnDataPtr(), _cur_fm, curFMID());
		return _bv;
	}
	
	void playerExpeditionFM::_auto_update()
	{
		update();
	}

	void playerExpeditionFM::update()
	{
		qValue m;
		m.append(res_sucess);
		qValue q(qJson::qj_object);
		getInfo(q);
		m.append(q);
		Own().sendToClientFillMsg(gate_client::expedition_formation_resp, m);
	}
}

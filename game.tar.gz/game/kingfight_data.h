#pragma once

#include "auto_base.h"
#include "dbDriver.h"

namespace gg
{
	namespace KingFight
	{
		enum
		{
			Left = 0,
			Right,
			MaxSide
		};

		enum // state
		{
			Unsetted = -1,
			Closed,
			Challenged,
			Betting,
			Final,
		};

		enum // report type
		{
			LeftCrown = 1,
			RightCrown,
			FinalOne,
			FinalTwo,
			FinalThree
		};

		enum // time node
		{
			Time1400 = 0,
			Time2130,
			Time2140_50,
			MaxTimeNode
		};

		static const std::string KeyTitle[] = {"title0", "title1", "title2"};
		static const std::string KeyReport[] = {"report0", "report1", "report2"};
		static const std::string KeyChallenger[] = {"challenger0", "challenger1", "challenger2"};
		static const std::string KeyState[] = {"state0", "state1", "state2"};
		static const std::string ReportDir[] = {"kingfight/0/", "kingfight/1/", "kingfight/2/"};
		static const std::string ReportPath = "kingfile/";

		class State
			: public _auto_meta
		{
			public:
				State(int nation);

				void classLoad();

				const int nation() const { return _nation; }
				int state() const { return _state; }
				unsigned nextUpdateTime() const { return _next_update_time; }
				int nextTimeNode() const { return _next_time_node; }
				unsigned lastOpenTime() const { return _last_open_time; }
				unsigned lastCloseTime() const { return _last_close_time; }
				bool firstDay() const { return _first_day; }

				void setState(int s);
				void setNextUpdateTime(unsigned nt);
				void setNextTimeNode(int ns);
				void setLastOpenTime(unsigned lt);
				void setLastCloseTime(unsigned lt);
				void setFirstDay(bool fd);
			
			private:
				virtual bool _auto_save();

			private:
				const int _nation;

				int _state;
				unsigned _next_update_time;
				int _next_time_node;
				unsigned _last_open_time;
				unsigned _last_close_time;
				bool _first_day;
		};

		class Title
		{
			public:
				Title(int title);
				
				void load(const mongo::BSONElement& obj);
				mongo::BSONObj toBSON() const;
				void getInfo(Json::Value& info) const;
				void getInfo(qValue& q) const;
				
				int pid() const { return _pid; }
				int face() const { return _face; }
				const std::string& name() const { return _name; }
				int title() const { return _title; }
				void setPlayer(playerDataPtr d);
				bool empty() const { return _pid == -1; }
				void clear() { _pid = -1; }

			private:
				const int _title;
				int _pid;
				std::string _name;
				int _face;
		};

		class TitleInfo
			: public _auto_meta
		{
			public:
				BOOSTSHAREPTR(Title, TitlePtr);

				TitleInfo(const int nation);

				virtual void classLoad();
				void getInfo(Json::Value& info) const;
				void getInfo(qValue& q) const;
				std::map<int, int> getSalaryData() const;

				int setPlayer(int title, playerDataPtr d, bool first = false);
				void update(playerDataPtr d);
				void clear();
				bool notSetted() const;
				bool notFilled() const;

				const TitlePtr& get(int title) const { return _title_list[title]; }

				bool exist(int pid) const;

			private:
				virtual bool _auto_save();

			private:
				const int _nation;

				STDVECTOR(TitlePtr, TitleList);
				TitleList _title_list;
		};

		BOOSTSHAREPTR(TitleInfo, TitleList);

		class Report
		{
			public:
				Report(const mongo::BSONElement& obj);
				Report(playerDataPtr pa, playerDataPtr pb, int type, const std::string& rep_id);
				
				mongo::BSONObj toBSON() const;
				void getInfo(Json::Value& info) const;
			
			private:
				int _pid_a;
				int _pid_b;
				std::string _name_a;
				std::string _name_b;
				std::string _rep_id;
				int _type;
		};
		
		class ReportInfo
			: public _auto_meta
		{
			public:
				ReportInfo(const int nation);

				virtual void classLoad();
				void getInfo(Json::Value& info) const;

				std::string add(playerDataPtr pa, playerDataPtr pb, int type);
				void clear();

			private:
				virtual bool _auto_save();

			private:
				const int _nation;

				unsigned _report_id;
				BOOSTSHAREPTR(Report, ReportPtr);
				STDLIST(ReportPtr, ReportList);
				ReportList _report_list;
		};

		BOOSTSHAREPTR(ReportInfo, ReportList);

		class Term
			: public _auto_meta
		{
			public:
				Term(const int nation);
				void load(const mongo::BSONObj& obj);

				void getInfo(Json::Value& info, int term_id) const;
				int pid() const { return _pid; }
			
				void setBeginTime(unsigned bt);
				void setEndTime(unsigned et);
				void setPlayer(playerDataPtr d);
				
				bool operator<(const Term& rhs) const
				{
					return _begin_time < rhs._begin_time;
				}

			private:
				virtual bool _auto_save();

			private:
				const int _nation;
				unsigned _begin_time;
				unsigned _end_time;
				int _pid;
				std::string _name;
				int _lv;
				int _face;
		};

		class TermInfo
		{
			public:
				TermInfo(const int nation);
				virtual void classLoad();
				void getInfo(Json::Value& info, int begin, int end) const;
				bool empty() const { return _term_list.empty(); }
				void add(unsigned begin_time, playerDataPtr d);

			private:
				BOOSTSHAREPTR(Term, TermPtr);
				STDVECTOR(TermPtr, TermList);
				const int _nation;
				TermList _term_list;
		};

		class Challenger
		{
			public:
				Challenger();

				void load(const mongo::BSONElement& obj);
				mongo::BSONObj toBSON() const;
				void getInfo(Json::Value& info) const;

				int pid() const { return _pid; }
				const std::string& name() const { return _name; }
				int score() const { return _score; }
				bool empty() const { return _pid == -1; }
				void clear() { _pid = -1; _score = 0; }
				
				void setPlayer(playerDataPtr d);
				void setRepId(const std::string& rep_id) { _rep_id = rep_id; }
				void addScore() { ++_score; }

			private:
				int _pid;
				std::string _name;
				int _lv;
				int _face;
				std::string _rep_id;
				int _score;
		};

		class Challengers
			: public _auto_meta
		{
			public:
				Challengers(const int nation);

				virtual void classLoad();
				void getInfo(Json::Value& info) const;

				const Challenger& get(int side) const { return _challenger[side]; }

				void setPlayer(int side, playerDataPtr d);
				void setRepId(int side, const std::string& rep_id);
				void addScore(int side);
				void clear();

				bool inCrown(int pid) const;

			private:
				virtual bool _auto_save();

			private:
				const int _nation;
				Challenger _challenger[MaxSide];
		};

		BOOSTSHAREPTR(Challengers, ChallengerInfo);

		class Manager
			: public State
		{
			public:
				typedef boost::function<void(Manager*, unsigned)> Handler;

				Manager(int nation);
				void init();
				static void setHandler();

				int challenge(playerDataPtr d, int side);
				int autoSetTitle(playerDataPtr d, int type);
				int setTitle(playerDataPtr d, const std::string& name, int title);
				int firstSetTitle(playerDataPtr d);
				int bet(playerDataPtr d, int side, int type);

				const std::string& getKingName() const;
				void getKingInfo(Json::Value& info) const;
				void getUnityInfo(qValue& q) const;
				void getInfo(playerDataPtr d, Json::Value& info) const;
				void getTitleInfo(Json::Value& info) const;
				void getTitleInfo(qValue& q) const;
				void getTermInfo(Json::Value& info, int begin, int end) const;
				int getPidByTitle(int title) const;
				std::map<int, int> getSalaryData() const;

				void updateName(playerDataPtr d);

			private:
				void createDir();
				void checkInited();

				void setTimer();
				void tick(int time_node, unsigned tick_time);
				void tickAt1400(unsigned tick_time);
				void tickAt2130(unsigned tick_time);
				void tickAt2140_50(unsigned tick_time);

				void setKingInfo(unsigned tick_time, playerDataPtr d, bool first = false);
				void addReportDeclare(BattleReport& reportData, playerDataPtr atkp, playerDataPtr defp);

				int getFinalNum() const;
				unsigned getNextOpenTime(unsigned tick_time) const;
				int getChallengerNum() const;
				int getWinner() const;
				int getUIType() const;
				void finalBroadcast(Json::Value json, std::string path);
				void addFinalBroadcast(int type, playerDataPtr d, playerDataPtr target, const std::string& rep_id);

			private:
				ChallengerInfo _challenger;
				TermInfo _term_list;
				ReportList _report_list;
				TitleList _title_list;

				static Handler _tick_func[MaxTimeNode];
		};
	}
}

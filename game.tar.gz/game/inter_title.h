//###################################
//create by Jim
//2017-03-17
//###################################

#pragma once

#include "auto_do.h"

namespace gg
{
	class playerInterTitle :
		public _auto_player
	{
		friend class playerTick;
	public:
		playerInterTitle(playerData* const own);
		~playerInterTitle() {}

		int getTitle();
		void setTitle(const unsigned begin, const unsigned end, const unsigned title);
		//other
		void setData(mongo::BSONObj& obj);
	private:
		virtual bool _auto_save();
		unsigned _begin_time;
		unsigned _end_time;
		int _title_type;
	};
}

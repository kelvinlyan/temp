#include "pokedex.h"
#include "card_system.h"

namespace gg
{
	const static int RecallTimes = 3;

	playerPoke::playerPoke(playerData* const own) : _auto_player(own)
	{
		pokeData.resize(card_sys.totalCard(), '0');
		pokeRecall.resize(card_sys.totalCard(), '0');
	}

	void playerPoke::setData(mongo::BSONObj& obj)
	{
		if (obj.isEmpty())return;
		{
			std::string db_data = obj["pk"].String();
			if (pokeData.size() > db_data.size())
			{
				memmove((void*)pokeData.c_str(), db_data.c_str(), db_data.size());
			}
			else
			{
				pokeData = db_data;
			}
		};
		{
			std::string db_data = obj["pkr"].eoo() ? "" : obj["pkr"].String();
			if (pokeRecall.size() > db_data.size())
			{
				memmove((void*)pokeRecall.c_str(), db_data.c_str(), db_data.size());
			}
			else
			{
				pokeRecall = db_data;
			}
		};
		for (unsigned i = 0; i < pokeData.size(); ++i)
		{
			if (pokeData[i] == '1')
			{
				cfgCardPtr config = card_sys.getConfigByOrder(i);
				if (config)
				{
					Own().Face().insertFace(config->faceID);
				}
			}
		}
	}

	bool playerPoke::isOpen(const int pokeID)
	{
		cfgCardPtr config = card_sys.getConfig(pokeID);
		if (config && config->orderID < pokeData.size())
		{
			return pokeData[config->orderID] == '1';
		}
		return false;
	}

	bool playerPoke::recallAvailable(const int pokeID)
	{
		if (isOpen(pokeID))
		{
			cfgCardPtr config = card_sys.getConfig(pokeID);
			if (config && config->orderID < pokeData.size())
			{
				const int times = boost::lexical_cast<int, char>(pokeRecall[config->orderID]);
				return times < RecallTimes;
			}
		}
		return false;
	}

	void playerPoke::tickRecall(const int pokeID)
	{
		cfgCardPtr config = card_sys.getConfig(pokeID);
		if (config && config->orderID < pokeData.size())
		{
			int times = boost::lexical_cast<int, char>(pokeRecall[config->orderID]);
			if (times < RecallTimes)
			{
				pokeRecall[config->orderID] = boost::lexical_cast<char, int>(++times);
				_sign_auto();
			}
		}
	}

	void playerPoke::signPoke(const int pokeID)
	{
		cfgCardPtr config = card_sys.getConfig(pokeID);
		if (config && config->orderID < pokeData.size())
		{
			pokeData[config->orderID] = '1';
			Own().Face().insertFace(config->faceID);
			_sign_auto();
		}
	}

	void playerPoke::removePoke(const int pokeID)
	{
		cfgCardPtr config = card_sys.getConfig(pokeID);
		if (config && config->orderID < pokeData.size())
		{
			pokeData[config->orderID] = '0';
			Own().Face().removeFace(config->faceID);
			_sign_auto();
		}
	}

	void playerPoke::_auto_update()
	{
		Json::Value json;
		json[strMsg][0u] = res_sucess;
		{
			Json::Value& resJson = json[strMsg][1u];
			resJson = pokeData;
		};
		{
			Json::Value& resJson = json[strMsg][2u];
			resJson = pokeRecall;
		};
		Own().sendToClient(gate_client::player_card_poke_update_resp, json);
	}

	bool playerPoke::_auto_save()
	{
		mongo::BSONObj key = BSON(strPlayerID << Own().ID());
		mongo::BSONObj obj = BSON("$set" << BSON("Poke" <<
			BSON("pk" << pokeData << "pkr" << pokeRecall)
			));
		return db_mgr.SaveMongo(DBN::dbPlayerCollection, key, obj);
	}
}
//###################################
//create by Jim
//2016-01-26
//###################################


#pragma once

#include "auto_base.h"

namespace gg
{
	class playerPoke :
		public _auto_player
	{
	public:
		playerPoke(playerData* const own);
		~playerPoke(){}
		bool isOpen(const int pokeID);
		void signPoke(const int pokeID);//��ʶͼ��
		void removePoke(const int pokeID);//��ʶͼ��
		bool recallAvailable(const int pokeID);//�Ƿ������ٻ�
		void tickRecall(const int pokeID);//�ٻ�
		virtual void _auto_update();
		inline string getData() { return pokeData; }
		void setData(mongo::BSONObj& obj);
	private:
		virtual bool _auto_save();
		std::string pokeData;//ͼ������ 0,1���
		std::string pokeRecall;//��Ů�ٻ�
	};
}
/*
#########################
Created by Lin Xing
2016.12.28
#########################
*/

#pragma once

#include "dbDriver.h"
#include "commom.h"
#include "player_red_paper.h"

#define red_paper_sys (*gg::red_paper_system::_Instance)
#define MAX_TIME 2145929760
#define LIST_LIMITATION 50

namespace gg
{

	class red_paper_system
	{
	public:
		STDVECTOR(ptrTimerIdentify, TimerIdsVec);
		UNORDERMAP(int, TimerIdsVec, TimerIdsMap);
		UNORDERMAP(int, Json::Value, GMPapers);
		STDVECTOR(int, HID);
		STDVECTOR(HID, VID);
		red_paper_system();
		void initData();
		void loadData();
		DeclareRegFunction(reqSendRedPaper);
		DeclareRegFunction(reqOpenRedPaper);

		DeclareRegFunction(reqInfoRedPaper);
		DeclareRegFunction(reqDelHistoryRedPaper);
		DeclareRegFunction(reqInfoHistoryRedPaper);
		DeclareRegFunction(reqAssetRedPaper);
		DeclareRegFunction(reqPanelTotalRedPaper);
		DeclareRegFunction(reqDelete);
		DeclareRegFunction(reqRobInfo);

		//GM
		DeclareRegFunction(reqGMRedPaperIdList);
		DeclareRegFunction(reqGMRedPaperInfo);
		DeclareRegFunction(reqGMRedPaperModify);

		static void sendSystemRedPaper(const structTimer& timerData, red_paper::UnitPaperPtr paper);
		static void notify(const structTimer& timerData, int type, int time, red_paper::UnitPaperPtr ptr);
		static void settle(const structTimer& timerData, red_paper::UnitPaperPtr ptr);//�������/���ڷ��ظ��û�
		int generateLocalPaperId();

		~red_paper_system();

	public:
		static red_paper_system* const _Instance;
	private:
		static RedPaperSet _paper_player_set;//ÿ����Ҷ�Ӧһ������б�
		static MultiRedPaperList _paper_player_list;//��ʱ�������mutlimap��
		//����[���ID,�������ID]==>�������Ϣ�б�
		static RobberPlayerSet _robber_player_set;
		RawRedPaperPtrList _raw_paper_list;
		RawRedPaperPtrList _sys_raw_paper_list;
		RawRedPaperPtrList _raw_s_paper_list;//�����صĺ������
		static ActivityCompleteList sys_activity_config;
		static int _local_id;
		static TimerIdsMap _timer_ids_map;
	private:
		void getPaperInfo(Json::Value& info, playerDataPtr player);
		int getRobCash(int rest_cash, int rest_num);
		//�������µĺ����Ϣ
		static bool auto_db(red_paper::UnitPaperPtr ptr);
		static void delRedPaper(red_paper::UnitPaperPtr ptr);
		//�������Ϣ
		bool save_robber(int playerID, int local_id, int idx = -1);
		void start_system_paper(const red_paper::ActivityComplete& complete);
		bool save_acti(const red_paper::ActivityComplete& complete);
		void del_acti(int id);
		bool save_local_id();
	};
}

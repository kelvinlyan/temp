﻿//###################################
//create by Jim
//2016-09-18
//###################################

#pragma once

#include <vector>
#include "commom.h"

namespace WSTARKW
{
	typedef boost::function<void(const int, vector<int>&)> NearlyFunc;
	typedef boost::function<unsigned(const int, const int)> FareFunc;
}

class WStarKW
{
private:
	//节点状态
	enum NodeState
	{
		NOTEXIST,
		IN_OPENLIST,
		IN_CLOSELIST
	};

public:
	struct Node
	{
		unsigned		g;//开始点到当前点的消耗量
		unsigned		h;//当前点到目标点的消耗量
		int				pos;//位置
		NodeState		state;//状态
		Node*			parent;//父节点

		int f() const//总值
		{
			return g + h;
		}
		inline Node()
			: g(0)
			, h(0)
			, pos(0)
			, parent(NULL)
			, state(NOTEXIST)
		{
		}
		inline Node(const int p)
			: g(0)
			, h(0)
			, pos(p)
			, parent(NULL)
			, state(NOTEXIST)
		{
		}

		bool operator==(const int p)const
		{
			return pos == p;
		}

		bool operator==(const Node& node)const
		{
			return pos == node.pos;
		}

// 		void* operator new(std::size_t size)
// 		{
// 			return GNew(size);
// 		}
// 
// 		void operator delete(void* p) throw()
// 		{
// 			if (p != NULL)
// 			{
// 				GDelete(p);
// 			}
// 		}
	};

public:
	//参数配置
	WSTARKW::NearlyFunc	publicNearly;//判断能否移动的依据
	WSTARKW::FareFunc	publicFare;//判断消耗值

	//开始结束节点
	int					publicStart;
	int					publicEnd;

	WStarKW()
		: publicNearly(NULL)
		, publicFare(NULL)
		, publicStart(0)
		, publicEnd(0)
	{

	}
	~WStarKW();

public:
	bool isValidParam();

	std::vector<int> find();
private:
	void clear();

private:
	unsigned calculGValue(Node *parent_node, const int current_pos);

	unsigned calculHValue(const int current_pos, const int end_pos);

	bool findInOpenList(const int pos, Node *&out);

	bool isInCloseList(const int pos);

	void findNearlyPos(const int current_pos, std::vector<int> &nearly_pos);

	void handleInOpenNode(Node *current_node, Node *target_node);

	void handleNotInOpenNode(Node *current_node, Node *target_node, const int end_pos);

private:
	UNORDERMAP(int, Node, XMap);
	XMap _maps;

	struct lessNode
	{
		const bool operator()(WStarKW::Node* const &left, WStarKW::Node* const &right)const
		{
			return left->f() < right->f();
		}
	};
	typedef std::multiset< Node*, WStarKW::lessNode > multiList;
	multiList _openList;//小值在前的顺序
};

#include "player_kingdomwar_task.h"
#include "kingdomwar_task.h"
#include "kingdomwar_data.h"
#include "playerManager.h"
#include "kingdomwar_system.h"

namespace gg
{
	using namespace KingdomWar;

	playerKingdomWarTask::playerKingdomWarTask(playerData* const own)
		: _auto_player(own), _task_lv(0)
	{
		_nation_task_time = 0;
		_nation_task_state = -1;
		_pt_rp = -1;
		_nt_rp = -1;
	}

	void playerKingdomWarTask::classLoad()
	{
		mongo::BSONObj key = BSON(strPlayerID << Own().ID());
		mongo::BSONObj obj = db_mgr.FindOne(DBN::dbPlayerKingdomWarTask, key);
		if (!obj.isEmpty())
		{
			checkNotEoo(obj["prtk"])
			{
				std::vector<mongo::BSONElement> ele = obj["prtk"].Array();
				for (unsigned i = 0; i < ele.size(); ++i)
					_personal_record.push_back(Creator<PersonalRecord>::Create(ele[i]));
			}
			checkNotEoo(obj["nts"])
				_nation_task_state = obj["nts"].Int();
			checkNotEoo(obj["nttm"])
				_nation_task_time = obj["nttm"].Int();
			checkNotEoo(obj["tl"])
				_task_lv = obj["tl"].Int();
		}
	}

	bool playerKingdomWarTask::_auto_save()
	{
		mongo::BSONObj key = BSON(strPlayerID << Own().ID());
		mongo::BSONObjBuilder obj;
		obj << strPlayerID << Own().ID() << "nts" << _nation_task_state << "nttm" << _nation_task_time
			<< "tl" << _task_lv;
		{
			mongo::BSONArrayBuilder b;
			ForEachC(RecordList, it, _personal_record)
				b.append((*it)->toBSON());
			obj << "prtk" << b.arr();
		}
		return db_mgr.SaveMongo(DBN::dbPlayerKingdomWarTask, key, obj.obj());
	}

	void playerKingdomWarTask::_auto_update()
	{
		update();
	}

	inline void playerKingdomWarTask::check()
	{
		if (_personal_record.empty())
			reset();
	}

	void playerKingdomWarTask::update()
	{
		check();
		qValue m;
		m.append(res_sucess);
		qValue q(qJson::qj_object);
		qValue l;
		ForEachC(RecordList, it, _personal_record)
		{
			qValue tmp;
			(*it)->getInfo(tmp);
			l.append(tmp);
		}
		q.addMember("l", l);
		q.addMember("t", KingdomWar::PrimeState::shared()? KingdomWar::PrimeState::shared().nextTickTime() : 0);
		q.addMember("lv", _task_lv);
		m.append(q);
		Own().sendToClientFillMsg(gate_client::kingdom_war_person_task_resp, m);
	}

	void playerKingdomWarTask::update(int type, const Json::Value& arg)
	{
		ForEach(RecordList, it, _personal_record)
		{
			if ((*it)->type() != type
				|| (*it)->state() != gg::Task::Running)
				continue;

			(*it)->update(Own().getOwnDataPtr(), arg);
			if ((*it)->state() == gg::Task::Finished)
				resetPersonTaskRPAndUpdate();
			_sign_save();
		}
	}

	int playerKingdomWarTask::getPersonTaskReward(int id, Json::Value& r)
	{
		ForEach(RecordList, it, _personal_record)
		{
			if ((*it)->id() == id)
			{
				if ((*it)->state() != gg::Task::Finished)
					return err_illedge;
				int res = (*it)->getReward(Own().getOwnDataPtr(), r);
				if (res == res_sucess)
				{
					resetPersonTaskRPAndUpdate();
					_sign_auto();
				}
				return res;
			}
		}
		return err_illedge;
	}

	int playerKingdomWarTask::getNationTaskReward(Json::Value& r)
	{
		if (nationTaskState() == 1)
			return err_illedge;
		NationRecordPtr ptr = NationTaskMgr::shared().getRecord(Own().Info().Nation());
		if (!ptr || ptr->state() == gg::Task::Running)
			return err_illedge;
		ActionBoxList rw = ptr->reward(Own().getOwnDataPtr());
		int res = actionDoBox(Own().getOwnDataPtr(), rw, false);
		if (res == res_sucess)
		{
			_nation_task_state = 1;
			r[1u] = actionRes();
			resetNationTaskRPAndUpdate();
			_sign_auto();
		}
		else
		{
			Json::Value error_code = actionError();
			res = error_code[0u][1u].asInt();
		}
		return res;
	}

	int playerKingdomWarTask::nationTaskState()
	{
		if (_nation_task_time != PrimeState::shared().lastPrimeTime())
		{
			_nation_task_time = PrimeState::shared().lastPrimeTime();
			_nation_task_state = 0;
		}
		return _nation_task_state;
	}

	void playerKingdomWarTask::personalTaskLog(unsigned end_time)
	{
		/*if (_personal_record.id() != -1)
		{
			Log(DBLOG::strLogKingdomWar, Own().getOwnDataPtr(), 10, end_time, _personal_record.type()
				, _personal_record.getSchedule(), _personal_record.getTarget());
		}*/
	}

	int playerKingdomWarTask::personTaskRP()
	{
		if (_pt_rp == -1)
			resetPersonTaskRP();
		return _pt_rp;
	}

	void playerKingdomWarTask::resetPersonTaskRP()
	{
		check();
		_pt_rp = 0;
		ForEach(RecordList, it, _personal_record)
		{
			if ((*it)->state() == gg::Task::Finished)
			{
				_pt_rp = 1;
				break;
			}
		}
	}

	void playerKingdomWarTask::resetPersonTaskRPAndUpdate()
	{
		int tmp = _pt_rp;
		resetPersonTaskRP();
		if (tmp != _pt_rp)
			Own().KingDomWarTips().add(PERSON_TASK_RP);
	}

	int playerKingdomWarTask::nationTaskRP()
	{
		if (_nt_rp == -1)
			resetNationTaskRP();
		return _nt_rp;
	}

	void playerKingdomWarTask::resetNationTaskRP()
	{
		if (nationTaskState() == 0
			&& NationTaskMgr::shared().getRecord(Own().Info().Nation())->state() == gg::Task::Finished)
		{
			_nt_rp = 1;
		}
		else
		{
			_nt_rp = 0;
		}
	}

	void playerKingdomWarTask::resetNationTaskRPAndUpdate()
	{
		int tmp = _nt_rp;
		resetNationTaskRP();
		if (tmp != _nt_rp)
			Own().KingDomWarTips().add(NATION_TASK_RP);
	}

	void playerKingdomWarTask::reset()
	{
		_task_lv = Own().LV();
		_personal_record.clear();
		std::vector<PersonalTaskPtr> task_list = PersonalTaskMgr::shared().rand();
		ForEachC(std::vector<PersonalTaskPtr>, it, task_list)
			_personal_record.push_back(Creator<PersonalRecord>::Create(*it, Own().getOwnDataPtr()));
		_nt_rp = -1;
		_pt_rp = -1;
		Own().KingDomWarTips().add(PERSON_TASK_RP);
		Own().KingDomWarTips().add(NATION_TASK_RP);
		_sign_save();
	}

	void playerKingdomWarTask::resetRedPoint()
	{
		_nt_rp = -1;
		_pt_rp = -1;
	}
}

#include "player_fund.h"
#include "dbDriver.h"
#include "fund_system.h"
#include <iterator>

namespace gg
{

	playerFund::playerFund(playerData* const own)
		:_auto_player(own),
		_strListName(std::string("done_list")),
		_strFlagName(std::string("flag"))
	{
	}

	int playerFund::buyFund()
	{
		//
		if (hasBoughtFund())
		{
			return err_fund_has_bought;
		}
		_flag = 1;
		_auto_save();
		//�۳����
		const int rest = fund_sys.GoldCost();
		Own().Res().alterGold(-rest);

		//log�����id��ʱ�䣬���Ľ��
		Log<int>(DBLOG::strLogFund, Own().getOwnDataPtr(), 1, rest);
		return res_sucess;
	}

	int playerFund::getReward(const int& id, Json::Value& r)
	{
		//����
		if (hasGottenReward(id))
		{
			return err_fund_has_gotten;
		}
		//1.��ȡ
		const int res = actionDoBox(Own().getOwnDataPtr(), fund_sys.GetRewards().find(id)->second.box_list, false);
		if (res == res_sucess)
		{
			//����ͨ�ý�������
			Json::Value d = Json::Value::null;
			d["box"] = fund_sys.getBoxJson(id);
			r[strMsg][1u] = d;

			//2.����_done_list
			_done_list.insert(id);
			_auto_save();
			//log
			Log<std::string>(DBLOG::strLogFund, Own().getOwnDataPtr(), 2, fund_sys.getBoxDesc(id));
		}
		else
		{
			r[strMsg][1u] = actionError();
			//log
			Log<std::string>(DBLOG::strLogFund, Own().getOwnDataPtr(), 23, fund_sys.getBoxDesc(id));
		}
		return res;

	}

	//{f:0,it:[{st:0,id:0,lv:30,box:[{"aID":1,"v":3000},{"aID":12,"id":10007,"v":1}],...]}
	void playerFund::_auto_update()
	{
		std::string strMsg("{\"msg\":[0,{\"f\":");
		strMsg += boost::lexical_cast<std::string>(_flag);
		strMsg += std::string(",\"it\":[");

		//���еĽ�����
		const fund_system::RewardList& list = fund_sys.GetRewards();
		fund_system::RewardList::const_iterator it = list.begin();
		int comma = 0;
		while (it != list.end())
		{
			strMsg += getItemDesc(it->first);
			++it;

			++comma;
			if (comma < list.size())
			{
				strMsg += std::string(",");
			}

		}
		strMsg += std::string("]}]}");
		//LogS << "player id" << Own().ID() << "\tFund Info: " << strMsg << LogEnd;
		Own().sendToClient(gate_client::player_fund_info_update_resp, strMsg);
	}

	//��ý�������������
	std::string playerFund::getItemDesc(const int& id) const
	{
		std::string retStr("{\"st\":");
		std::string state = (_done_list.find(id) == _done_list.end() ?
			std::string("0,") : std::string("1,"));
		retStr += state;

		//retStr += fund_config.getIdLvBoxDesc(id);
		retStr += std::string("\"id\":");
		retStr += boost::lexical_cast<std::string>(id);
		retStr += std::string("}");

		return retStr;
	}

	void playerFund::setData(mongo::BSONObj& obj)
	{
		if (obj.isEmpty())
		{
			//�龰��ϵͳ��ʼ�����������
			//1.�½�����
			//2.����_flagΪ0��_done_listΪ��
			//3.���ʵ���ʱ��������ݱ��棨�����ݿ⣩
			_flag = 0;
		}
		else
		{
			_flag = obj[_strFlagName].Int();
			if (_flag)
			{
				std::vector<mongo::BSONElement> done_list_obj = obj[_strListName].Array();
				for (unsigned i = 0; i < done_list_obj.size(); ++i)
				{
					mongo::BSONElement ele = done_list_obj[i];
					_done_list.insert(ele.Int());
				}
			}
		}
	}

	bool playerFund::_auto_save()
	{
		mongo::BSONObj key = BSON(strPlayerID << Own().ID());
		mongo::BSONArrayBuilder done_list;
		for (FundDoneIdList::iterator it = _done_list.begin(); it != _done_list.end(); ++it)
		{
			done_list << *it;
		}
		mongo::BSONObj obj = BSON("$set" << BSON("Fund" <<
			BSON(_strFlagName << _flag << _strListName << done_list.arr())
			));
		return db_mgr.SaveMongo(DBN::dbPlayerCollection, key, obj);
	}

	playerFund::~playerFund()
	{
	}
}

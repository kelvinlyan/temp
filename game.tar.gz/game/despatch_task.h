//###################################
//create by Jim
//2016-05-10
//###################################

#pragma once

#include "commom.h"
#include "core_helper.h"
#include "quickjson.h"

namespace gg
{
	class UserTask
	{
	private:
		typedef boost::function<void()> BINDFUNCTION;
	public:
		static void initData();
		static void shutDown();
		static void Add(BINDFUNCTION delay_task, const int eventID);
	private:
		static std::queue<BINDFUNCTION> _TaskList;//�����б�
		static bool _Once;//����һ��
		static void run_tick();//�����¼�
		static void run();
		static void impl_run();
		static void impl_add(BINDFUNCTION delay_task, const int eventID);
		static void task_box(BINDFUNCTION delay_task, const int eventID);
	};

}
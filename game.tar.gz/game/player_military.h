#pragma once

#include "auto_base.h"
#include "man_def.h"

namespace gg
{
	class playerMilitary
		: public _auto_player
	{
		public:
			playerMilitary(playerData* const own);

			void update();

			int level();// { return _level; }
			const int* attri() const { return _attri; }
			int levelUp(Json::Value& r);
			void setData(mongo::BSONObj& obj);
		private:
			virtual bool _auto_save();

		private:
			int _level;
			int _attri[characterNum];
	};
}

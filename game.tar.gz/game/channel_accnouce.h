//###################################
//create by Jim
//2016-11-24
//###################################

#pragma once 

#include "dbDriver.h"

#define channel_acc (*gg::ChannelAccnouce::_Instance)

namespace gg
{
	class ChannelAccnouce
	{
	public:
		static ChannelAccnouce* const _Instance;
		void initData();
		DeclareRegFunction(UpdateAccnouce);
		DeclareRegFunction(GMUpdateAccnouce);
		DeclareRegFunction(GMMotifyAccnouce);

		void sendMessage(playerDataPtr player);
		string GetMessage(playerDataPtr player);
		string GetMessage(const string channel_key);
	private:
		bool is_runing();
		void save_message();
		void send_to_all();
		UNORDERMAP(string, string, MessageMap);
		unsigned _begin_time;
		unsigned _end_time;
		string _title;
		MessageMap _message_map;
	};
}
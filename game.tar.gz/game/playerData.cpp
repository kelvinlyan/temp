#include "playerData.h"
#include "playerManager.h"
#include "service_config.h"

namespace gg
{
	playerData::playerData(const int pID)
	{
		_Info = Creator<playerBase>::Create(this, pID);
		initial();
	}

	playerData::playerData(const string pName)
	{
		_Info = Creator<playerBase>::Create(this, pName);
		initial();
	}
	
#define CreatePlayerClass(ClassType, VarName, StateValue) \
{\
_##VarName = Creator<ClassType>::Create(this);\
_##VarName->setClassState(StateValue);\
}


#define CreatePlayerClassM(ClassType, VarName, StateValue, ...) \
{\
_##VarName = Creator<ClassType>::Create(this, __VA_ARGS__);\
_##VarName->setClassState(StateValue);\
}

#define InitialCollectionClass(KEY, CLASS)\
	if (obj[KEY].ok())\
	{\
		mongo::BSONObj format_obj = obj[KEY].Obj();\
		CLASS->setData(format_obj);\
		CLASS->setClassState(AutoPlayer::class_load);\
	}

	void playerData::initial()
	{
		unsigned dataState = AutoPlayer::class_all_empty;
		//����ʵ��
		_Info->setClassState(dataState);
		_Info->toFull();
		const bool vaild = isVaild();
		if (!vaild)
		{
			dataState = AutoPlayer::class_all_over;
		}

		CreatePlayerClass(playerTick, Tick, dataState);
		CreatePlayerClass(playerManMgr, Man, dataState);
		CreatePlayerClass(playerResource, Res, dataState);
		CreatePlayerClass(playerMapWarMgr, War, dataState);//
		CreatePlayerClass(playerTask, Task, dataState);//
		CreatePlayerClass(playerWarFM, WarFM, dataState);
		CreatePlayerClass(playerCardMgr, Card, dataState);
		CreatePlayerClass(playerCardTs, CardTs, dataState);
		CreatePlayerClass(playerItemMgr, Items, dataState);
		CreatePlayerClass(playerSearch, Sch, dataState);
		CreatePlayerClass(playerFace, Face, dataState);
		CreatePlayerClass(playerPoke, Poke, dataState);
		CreatePlayerClass(playerCount, Count, dataState);
		CreatePlayerClass(playerCarPos, CarPos, dataState);
		CreatePlayerClass(playerBusiness, Biz, dataState);
		CreatePlayerClass(playerBusinessTask, BizTask, dataState);
		CreatePlayerClass(playerBusinessBuff, BizBuff, dataState);
		CreatePlayerClass(playerKingFight, KingFight, dataState);//
		CreatePlayerClass(playerKingdom, KingDom, dataState);//
		CreatePlayerClass(playerRescue, RescueData, dataState);
		CreatePlayerClass(playerTeam, Team, dataState);//
		CreatePlayerClass(playerVipMgr, Vip, dataState);//
		CreatePlayerClass(playerWorldBoss, WorldBoss, dataState);//
		CreatePlayerClass(playerWarLords, WarLords, dataState);//
		CreatePlayerClass(playerResearch, Research, dataState);
		CreatePlayerClass(playerMarket, Market, dataState);
		CreatePlayerClass(playerOrders, Orders, dataState);
		CreatePlayerClass(playerMall, Malls, dataState);
		CreatePlayerClass(playerEmail, Email, dataState);
		CreatePlayerClass(playerDaily, Daily, dataState);
		CreatePlayerClass(playerBuildTeam, BuildTeam, dataState);
		CreatePlayerClass(playerBuilds, Builds, dataState);
		CreatePlayerClass(playerAdmin, Admin, dataState);
		CreatePlayerClass(playerOffline, Offline, dataState);
		CreatePlayerClass(playerCustom, Custom, dataState);
		CreatePlayerClass(playerDaysActivity, DaysActivity, dataState);
		CreatePlayerClass(playerOnlineBox, OnlineBox, dataState);
		CreatePlayerClass(playerAffair, Affair, dataState);
		CreatePlayerClass(playerSign, Sign, dataState);
		CreatePlayerClass(playerMoneyActivity, MoneyActivity, dataState);
		CreatePlayerClass(playerDailyCard, DailyCard, dataState);
		CreatePlayerClass(playerFund, Fund, dataState);
		CreatePlayerClass(playerKingdomWar, KingDomWar, dataState);
		CreatePlayerClass(playerKingdomWarShop, KingDomWarShop, dataState);
		CreatePlayerClass(playerKingdomWarOutput, KingDomWarOutput, dataState);
		CreatePlayerClass(playerKingdomWarFM, KingDomWarFM, dataState);
		CreatePlayerClass(playerKingdomWarPos, KingDomWarPos, dataState);
		CreatePlayerClass(playerKingdomWarBox, KingDomWarBox, dataState);
		CreatePlayerClass(playerKingdomWarTask, KingDomWarTask, dataState);
		CreatePlayerClass(playerPatrol1, Patrol, dataState);
		CreatePlayerClass(playerOpenActivity, OpenActivity, dataState);
		CreatePlayerClass(playerShops, Shops, dataState);
		CreatePlayerClass(playerDailyInpour, DailyInpour, dataState);
		CreatePlayerClass(playerExpedition, Expedition, dataState);
		CreatePlayerClass(playerShadow, Shadow, dataState);
		CreatePlayerClass(playerExpeditionFM, ExpeditionFM, dataState);
		CreatePlayerClass(playerRecharge, RechargeLog, dataState);
		CreatePlayerClass(playerSecondaryCompensation, SecondaryCompensation, dataState);
		CreatePlayerClass(playerFestival, Festival, dataState);
		CreatePlayerClass(playerActivityRank, ActivityRank, dataState);
		CreatePlayerClass(playerRedPaper, RedPaper, dataState);
		CreatePlayerClass(playerLoseFM, LoseFM, dataState);
		CreatePlayerClass(playerEnemy, Enemy, dataState);
		CreatePlayerClass(playerCommonOffline, CommonOffline, dataState);
		CreatePlayerClass(playerOldPlayer, OldPlayer, dataState);
		CreatePlayerClass(interWarFM, InterFM, dataState);
		CreatePlayerClass(playerMilitary, Military, dataState);
		CreatePlayerClass(playerInterTitle, InterTitle, dataState);
		CreatePlayerClass(playerMysteryArea, MysteryArea, dataState);
		CreatePlayerClass(playerTreasureMgr, Treasure, dataState);
		CreatePlayerClass(playerKingdomWarTips, KingDomWarTips, dataState);
		CreatePlayerClass(playerImperialExam, ImperialExam, dataState);
		CreatePlayerClass(playerBoatBorrow, Borrow, dataState);
		CreatePlayerClass(playerIslandActivity, IslandActivity, dataState);
		//���ݳ�ʼ��
		memset(Chat, 0x0, sizeof(Chat));
		Online = false;
		TeamCD = 0;
		BusinessCD = 0;
		EquipShowCD = 0;
		ShareLastCD = 0;
		ShareInterCD = 0;
		TeamAnnCD = 0;
		ExchangeEquipCD = 0;
		CarMoveCD = boost::get_system_time();
		Dirty = false;

		if (vaild)
		{
			mongo::BSONObj obj = db_mgr.FindOne(DBN::dbPlayerCollection, BSON(strPlayerID << ID()));
			InitialCollectionClass("Tick", _Tick);
			InitialCollectionClass("Res", _Res);
			InitialCollectionClass("Task", _Task);
			InitialCollectionClass("CardTs", _CardTs);
			InitialCollectionClass("Sch", _Sch);
			InitialCollectionClass("Poke", _Poke);
			InitialCollectionClass("CarPos", _CarPos);
			InitialCollectionClass("KingFight", _KingFight);
			InitialCollectionClass("Rescue", _RescueData);
			InitialCollectionClass("Team", _Team);
			InitialCollectionClass("Vip", _Vip);
			InitialCollectionClass("Market", _Market);
			InitialCollectionClass("Orders", _Orders);
			InitialCollectionClass("Affair", _Affair);
			InitialCollectionClass("Malls", _Malls);
			InitialCollectionClass("Daily", _Daily);
			InitialCollectionClass("Builds", _Builds);
			InitialCollectionClass("BuildTeam", _BuildTeam);
			InitialCollectionClass("Admin", _Admin);
			InitialCollectionClass("WarLords", _WarLords);
			InitialCollectionClass("Offline", _Offline);
			InitialCollectionClass("Custom", _Custom);
			InitialCollectionClass("OnlineBox", _OnlineBox);
			InitialCollectionClass("Sign", _Sign);
			InitialCollectionClass("DailyCard", _DailyCard);
			InitialCollectionClass("Fund", _Fund);
			InitialCollectionClass("Patrol", _Patrol);
			InitialCollectionClass("OpenActivity", _OpenActivity);
			InitialCollectionClass("DailyInpour", _DailyInpour);
			InitialCollectionClass("RechargeLog", _RechargeLog);
			InitialCollectionClass("Festival", _Festival);
			InitialCollectionClass("LoseFM", _LoseFM);
			InitialCollectionClass("Military", _Military);
			InitialCollectionClass("OldPlayer", _OldPlayer);
			InitialCollectionClass("Research", _Research);
			InitialCollectionClass("SecCompensation", _SecondaryCompensation);
			InitialCollectionClass("CommonOffline", _CommonOffline);
			InitialCollectionClass("Enemy", _Enemy);
			InitialCollectionClass("InterTitle", _InterTitle);
			InitialCollectionClass("Biz", _Biz);
			InitialCollectionClass("BizTask", _BizTask);
			InitialCollectionClass("BizBuff", _BizBuff);
			InitialCollectionClass("BizBuff", _BizBuff);
			InitialCollectionClass("IslandActivity", _IslandActivity);
			InitialCollectionClass("Borrow", _Borrow);
			InitialCollectionClass("MysteryArea", _MysteryArea);
		}
	}

	void playerData::clearData()
	{
		if (Dirty)
		{
			Tick().loginTick();
			Dirty = false;
		}
	}

	playerData::~playerData()
	{
//		cout << "~playerData call" << endl;
	}

	void playerData::Login()
	{
		if (!isOnline())
		{
			Online = true;
			onLogin();
		}
	}

	void playerData::Logout()
	{
		if (isOnline())
		{
			Online = false;
			onOFFLine();
		}
	}

	void playerData::sendToClient(const short protocol, Json::Value& msg)
	{
		if (!isOnline())return;
		string str = msg.toIndentString();
		net::Msg mj(ID(), service::process_id::INVAILD_PLAYER_ID, protocol, str);
		player_mgr.sendToPlayer(mj);
	}

	void playerData::sendToClient(const short protocol, qValue& msg)
	{
		if (!isOnline())return;
		string str = msg.toIndentString();
		net::Msg mj(ID(), service::process_id::INVAILD_PLAYER_ID, protocol, str);
		player_mgr.sendToPlayer(mj);
	}

	void playerData::sendToClientFillMsg(const short protocol, qValue& msg)
	{
		if (!isOnline())return;
		qValue cmMsg(qJson::qj_object);
		cmMsg.addMember(strMsg, msg);
		string str = cmMsg.toIndentString();
		net::Msg mj(ID(), service::process_id::INVAILD_PLAYER_ID, protocol, str);
		player_mgr.sendToPlayer(mj);
	}

	void playerData::sendToClient(const short protocol, string& msg)
	{
		if (!isOnline())return;
		net::Msg mj(ID(), service::process_id::INVAILD_PLAYER_ID, protocol, msg);
		player_mgr.sendToPlayer(mj);
	}

	void playerData::sendToClientFillMsg(const short protocol, string& msg)
	{
		if (!isOnline())return;
		string str = "{\"msg\":[" + msg + "]";
		net::Msg mj(ID(), service::process_id::INVAILD_PLAYER_ID, protocol, str);
		player_mgr.sendToPlayer(mj);
	}


// 	bool playerData::outLine()
// 	{
// 		if (isOnline())return false;
// 		unsigned now = Common::gameTime();
// 		if (now < OFFTime || now - OFFTime > 7200)return true;
// 		return false;
// 	}

	bool playerData::isVaild()
	{
		return (ID() > 0 && Name().size() > 0);
	}
}

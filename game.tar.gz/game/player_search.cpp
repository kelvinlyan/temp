#include "player_search.h"
#include "search_system.h"
#include "res_code.h"
#include "playerManager.h"
#include "task_mgr.h"
#include "item_system.h"

namespace gg
{
	playerSearch::playerSearch(playerData* const own)
		: _auto_player(own)
	{
		_first_search_ww = 0;
		_first_search_cs = 0;
		_free_search_ww = 0;
		_free_search_cs = 0;

		_ww_search_times = 0;
		_cs_search_times = Search::fixCSTimes & Search::zeroDiv;

		_normal_serach_times = 0;
		_high_serach_times = 0;
	}

	void playerSearch::setData(mongo::BSONObj& obj)
	{
		if (obj.isEmpty()) 
			return;

		checkNotEoo(obj["cdww"])
			_free_search_ww = obj["cdww"].Int();
		checkNotEoo(obj["cdcs"])
			_free_search_cs = obj["cdcs"].Int();
		checkNotEoo(obj["fww"])
			_first_search_ww = obj["fww"].Int();
		checkNotEoo(obj["fcs"])
			_first_search_cs = obj["fcs"].Int();
		checkNotEoo(obj["wwst"])
			_ww_search_times = obj["wwst"].Int();
		checkNotEoo(obj["csst"])
			_cs_search_times = obj["csst"].Int();
		checkNotEoo(obj["nst"])
			_normal_serach_times = obj["nst"].Int();
		checkNotEoo(obj["hst"])
			_high_serach_times = obj["hst"].Int();
	}

	bool playerSearch::_auto_save()
	{
		mongo::BSONObj key = BSON(strPlayerID << Own().ID());
		mongo::BSONObjBuilder obj;
		obj << "wwst" << _ww_search_times << "csst" << _cs_search_times <<
			"cdww" << _free_search_ww << "cdcs" << _free_search_cs <<
			"fww" << _first_search_ww << "fcs" << _first_search_cs
			<< "nst" << _normal_serach_times << "hst" << _high_serach_times;
		mongo::BSONObj set_obj = BSON("$set" << BSON("Sch" << obj.obj()));
		return db_mgr.SaveMongo(DBN::dbPlayerCollection, key, set_obj);
	}

	void playerSearch::_auto_update()
	{
		update();
	}

	void playerSearch::update()
	{
		Json::Value res;
		res[strMsg][0u] = res_sucess;
		res[strMsg][1u]["wwst"] = _ww_search_times;//��n��
		res[strMsg][1u]["csst"] = _cs_search_times;//��n��
		res[strMsg][1u]["fww"] = _first_search_ww;
		res[strMsg][1u]["fcs"] = _first_search_cs;
		res[strMsg][1u]["cdww"] = _free_search_ww;
		res[strMsg][1u]["cdcs"] = _free_search_cs;
		Own().sendToClient(gate_client::player_search_data_resp, res);
	}

	void playerSearch::dailyTick()
	{
		_ww_search_times = 0;
		_sign_auto();
	}

	void playerSearch::tickSearch(bool high, unsigned times)
	{
		TaskMgr::update(Own().getOwnDataPtr(), Task::SearchTimes, times);
		if (high)	
		{
			_high_serach_times += times;
			TaskMgr::update(Own().getOwnDataPtr(), Task::HighSearchTimes, times);
			TaskMgr::update(Own().getOwnDataPtr(), Task::HighSearchAllTimes);
		}
		else
		{
			_normal_serach_times += times;
			TaskMgr::update(Own().getOwnDataPtr(), Task::NormalSearchTimes, times);
			TaskMgr::update(Own().getOwnDataPtr(), Task::NormalSearchAllTimes);
		}
	}
}

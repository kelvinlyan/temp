#include "player_trade.h"
#include "business.h"
#include "business_daily_rank.h"
#include "business_single_rank.h"
#include "business_total_rank.h"

namespace gg
{
	//business config data
	static struct CfgCar
	{
		vector<unsigned> speeds;
		vector<unsigned> exps;
		vector<int> durables;
		vector<unsigned> bags;
		vector<int> sales;
	}_cfg_Car;

	const CfgCar& staticCar()
	{
		return _cfg_Car;
	}

	//�ݴ�
	static std::vector< int > _BuyBorrowCost;//ÿ�ι�������
	static std::vector< int > _VipBuyBorrowLimits;//vip�����������

	namespace Business
	{
		void initData()
		{
			//�̴�
			{
				Json::Value json = Common::loadJsonFile("./instance/business/car.json");
				_cfg_Car.speeds.clear();
				for (unsigned i = 0; i < json["speed"].size(); i++)
				{
					_cfg_Car.speeds.push_back(json["speed"][i].asUInt());
				}
				_cfg_Car.exps.clear();
				for (unsigned i = 0; i < json["exp"].size(); i++)
				{
					_cfg_Car.exps.push_back(json["exp"][i].asUInt());
				}
				_cfg_Car.durables.clear();
				for (unsigned i = 0; i < json["durable"].size(); i++)
				{
					_cfg_Car.durables.push_back(json["durable"][i].asInt());
				}
				_cfg_Car.bags.clear();
				for (unsigned i = 0; i < json["bag"].size(); i++)
				{
					_cfg_Car.bags.push_back(json["bag"][i].asUInt());
				}
				_cfg_Car.sales.clear();
				for (unsigned i = 0; i < json["sale"].size(); i++)
				{
					_cfg_Car.sales.push_back(json["sale"][i].asInt());
				}
			}

			//�ݴ����
			{
				Json::Value vip_json = Common::loadJsonFile("./instance/business/vip_borrow.json");
				for (unsigned i = 0; i < vip_json.size(); ++i)
				{
					_VipBuyBorrowLimits.push_back(vip_json[i].asInt());
				}
				Json::Value buy_json = Common::loadJsonFile("./instance/business/buy_borrow.json");
				for (unsigned i = 0; i < buy_json.size(); ++i)
				{
					_BuyBorrowCost.push_back(buy_json[i].asInt());
				}
			};
		}
	}

	//car move
	void playerCarPos::staticLoopRoute(const structTimer& timerData, const int playerID)
	{
		playerDataPtr player = player_mgr.getCachePlayer(playerID);
		if (!player)return;
		player->CarPos().loopRoute();
	}

	void playerCarPos::loopRoute()
	{
		if (Own().isOnline())//�������
		{
			loopMove();
			if (_move_list.size() > 0)
			{
				//1s ��ѯһ��
				Timer::AddEventSeconds(boostBind(playerCarPos::staticLoopRoute, _1, Own().ID()), 
					Inter::event_business_car_move_timer, 0);
				_is_need_timer = false;
				return;
			}
		}
		else
		{
			resetMove();
			_history_pos.clear();
		}
		_is_need_timer = true;
	}

	void playerCarPos::sendFuturePos(const unsigned num /* = 5 */)
	{
		if (_move_list.empty() || _show_idx >= _move_list.size())return;
		qValue move_json(qJson::qj_array);
		qValue x_move_json(qJson::qj_array);
		qValue y_move_json(qJson::qj_array);
		if(_show_idx < 1)//��ʼ��
		{
			x_move_json.append(_current_pos.x);
			y_move_json.append(_current_pos.y);
		}
		else
		{
			x_move_json.append(_move_list[_show_idx - 1].x);
			y_move_json.append(_move_list[_show_idx - 1].y);
		}
		for (unsigned i = 0; i < num && _show_idx < _move_list.size(); i++)
		{
			WSTAR::Pos pos = _move_list[_show_idx];
			++_show_idx;
			x_move_json.append(pos.x);
			y_move_json.append(pos.y);
		}
		move_json.append(x_move_json).append(y_move_json);
		Own().sendToClientFillMsg(gate_client::player_car_move_annouce_resp, move_json);
	}

	void playerCarPos::loopMove(const unsigned to_client /* = true */)
	{
		const unsigned size = _move_list.size();
		if (_current_idx >= size) 
		{
			if (to_client && _show_idx < size)
			{
				sendFuturePos(size - _show_idx);
			}
			return;
		}
		boost::system_time now = boost::get_system_time();
		_leave_time += (now - _star_move_time).total_milliseconds();
		_star_move_time = now;
		const unsigned step_speed = Own().Biz().getSpeed();
		const unsigned obli_speed = step_speed * 1.414;

		bool update = false;
		const bool weishe_buff = Own().BizBuff().checkBuff(TradeBuff::weishe);
		while (_current_idx < size)//��������Ҫ�ƶ�
		{
			WSTAR::Pos pos = _move_list[_current_idx];
			const int dispart = pos - _current_pos;
// 			cout << "now pos: " << currentPos.x << "," << currentPos.y <<
// 			" to move: " << pos.x << "," << pos.y << endl;
			if (dispart == 0)
			{
				++_current_idx;
				continue;
			}
// 			const double rate = currentIDX < 5 ? (currentIDX < 2 ? 0.4 : 0.8) : 1.0;
// 			const unsigned need_time = (dispart == 1 ? step_speed * rate : obli_speed * rate);
			const unsigned need_time = (dispart == 1 ? step_speed : obli_speed);
			if (_leave_time < need_time)break;

			_history_pos.push_back(pos);
			if (_history_pos.size() > 5)
			{
				_history_pos.pop_front();
			}
			++_current_idx;
			_current_pos = pos;
			update = true;
			_leave_time -= need_time;

			if (!weishe_buff && business_sys.inSharkArea(pos.x, pos.y))//�����
			{
				Own().Biz().alterDurable(-5);
			}
		}

		if (update)//�����ƶ���һ��
		{
			_is_dirty = true;
			if (Own().isOnline())
			{
				business_sys.updateMoveCar(Own().getOwnDataPtr());
			}
		}

		if (to_client && _current_idx + 10 > _show_idx)
		{
			sendFuturePos();
		}

		//��������ݱ仯
		if (_current_idx >= size)
		{
			if (to_client && _show_idx < size)
			{
				sendFuturePos(size - _show_idx);
			}
			resetMove();
		}
	}

	//pos
	playerCarPos::playerCarPos(playerData* const own) : _auto_player(own)
	{
		_leave_time = 0;//����
		_star_move_time = boost::get_system_time();
		_current_pos = business_sys.getAvailablePos();
		_is_dirty = false;
		_current_idx = 0;
		_is_need_timer = true;
		_move_list.clear();
		_history_pos.clear();
	}

	bool playerCarPos::_auto_save()
	{
		return toSave();
	}

	bool playerCarPos::isNearlyAim()
	{
		//�Ƿ��Ѿ�����Ŀ����	
		WSTAR::Pos aim = aimXY();
		WSTAR::Pos left_bottom;
		left_bottom.x = aim.x > 1 ? aim.x - 1 : aim.x;
		left_bottom.y = aim.y > 1 ? aim.y - 1 : aim.y;
		WSTAR::Pos right_top;
		right_top.x = aim.x + 1;
		right_top.y = aim.y + 1;
		return (
			_current_pos.x >= left_bottom.x &&
			_current_pos.x <= right_top.x &&
			_current_pos.y >= left_bottom.y &&
			_current_pos.y <= right_top.y
			);
	}

	void playerCarPos::newRoute(WSTAR::Pos start_pos, std::vector<WSTAR::Pos>& vec)
	{
		resetMove();
		_move_list.swap(vec);
		_star_move_time = boost::get_system_time();
		_current_pos = start_pos;
		//sendFuturePos();
		//�������ϵͳ��ѯ
		if (_is_need_timer)
		{
			Timer::AddEventSeconds(boostBind(playerCarPos::staticLoopRoute, _1, Own().ID()),
				Inter::event_business_car_move_timer, 0);
			_is_need_timer = false;
		}
	}

	bool playerCarPos::setPos(const int x, const int y)
	{
		if (business_sys.availablePlace(x, y))
		{
			_current_pos = WSTAR::Pos(x, y);
			resetMove();
			_history_pos.clear();
			_is_dirty = true;
			_sign_auto();
			return true;
		}
		return false;
	}

	bool  playerCarPos::toSave()
	{
		if (_is_dirty)
		{
			_is_dirty = false;
			mongo::BSONObj key = BSON(strPlayerID << Own().ID());
			mongo::BSONObj obj = BSON("$set" << BSON("CarPos" <<
				BSON("x" << _current_pos.x << "y" << _current_pos.y)
				));
			return db_mgr.SaveMongo(DBN::dbPlayerCollection, key, obj);
		}
		return true;
	}

	void playerCarPos::resetMove()
	{
		_leave_time = 0;
		_current_idx = 0;
		_show_idx = 0;
		_move_list.clear();
	}

	void playerCarPos::setData(mongo::BSONObj& obj)
	{
		if (obj.isEmpty())return;
		_current_pos.x = obj["x"].Int();
		_current_pos.y = obj["y"].Int();
		if (!business_sys.availablePlace(_current_pos.x, _current_pos.y))
		{
			_current_pos = business_sys.getAvailablePos();
		}
	}

// 	void playerCarPos::sendRoute(const unsigned num /* = 100 */)
// 	{
// 		qValue json(qJson::qj_array);
// 		json.append(Own().Trade().getSpeed()).
// 			append(currentPos.x).append(currentPos.y).
// 			append(aimX()).append(aimY());
// 		qValue move_xjson(qJson::qj_array), move_yjson(qJson::qj_array);
// 		unsigned n = 0;
// 		for (unsigned i = currentIDX; i < moveList.size() && n < num; i++)
// 		{
// 			const WSTAR::Pos& pos = moveList[i];
// 			move_xjson.append(pos.x);
// 			move_yjson.append(pos.y);
// 			++n;
// 		}
// 		json.append(move_xjson).append(move_yjson);
// 		Own().sendToClientFillMsg(gate_client::player_car_route_data_resp, json);
// 	}

	bool playerCarPos::canSetStartPos(WSTAR::Pos pos)
	{
		loopMove(false);
		if (pos == _current_pos)return true;
		for (std::list<WSTAR::Pos>::const_iterator it = _history_pos.begin(); it != _history_pos.end(); it++)
		{
			if (*it == pos)return true;
		}
		for (unsigned i = _current_idx; i < _current_idx + 1 && i < _move_list.size(); i++)
		{
			if (_move_list[i] == pos)return true;
		}
		return false;
	}

	void playerCarPos::stopMove()
	{
		//�����ƶ�����
		loopMove();
		resetMove();
	}

	//business buff
	playerBusinessBuff::playerBusinessBuff(playerData* const own) : _auto_player(own)
	{
		//buff
		_business_buff.clear();
	}


	//business
	playerBusiness::playerBusiness(playerData* const own) : _auto_player(own)
	{
		//��ֻ��Ϣ
		_car_level = 1;
		_car_exp = 0;
		_car_durable = staticCar().durables[_car_level];
		//������Ϣ
		_boss_hit_times = 0;
		_pirate_hit_times = 0;
		_cumulative_task = 0;
		_single_max = 0;
		_cumulative_money = 0;
		_boss_hit_cd = 0;
		_boss_box.clear();
	}

	int playerBusiness::usefulBossBox(const unsigned id)
	{
		if (_boss_box.size() >= 3)return err_shark_chest_been_over;
		if (_boss_box.find(id) == _boss_box.end())return err_shark_chest_been_get;
		return res_sucess;
	}

	void playerBusiness::tickPirate()
	{
		++_pirate_hit_times;
		_sign_auto();
	}

	int playerBusiness::addExp(const unsigned num)
	{
		const vector<unsigned> exps = staticCar().exps;
		if (_car_level >= exps.size())return err_trade_car_level_max;
		const unsigned old_level = _car_level;
		this->_car_exp += num;
		for (unsigned idx = _car_level; idx < exps.size(); ++idx)
		{
			if (this->_car_exp >= exps[idx])
			{
				this->_car_exp -= exps[idx];
				_car_level = idx + 1;
				continue;
			}
			break;
		}
		if (_car_level >= exps.size())
		{
			this->_car_exp = 0;
		}
		if (old_level != _car_level)
		{
			Log(DBLOG::strLogBusiness, Own().getOwnDataPtr(), 5, old_level, _car_level);
			_car_durable = staticCar().durables[_car_level];
		}
		_sign_auto();
		return 0;
	}
	unsigned playerBusiness::getSpeed()
	{
		return staticCar().speeds[_car_level];
	}
	unsigned playerBusiness::getCapacity()
	{
		return staticCar().bags[_car_level];
	}
	int playerBusiness::getSaleRate()
	{
		return staticCar().sales[_car_level];
	}

	double playerBusiness::getDurableRate()
	{
		const double md = staticCar().durables[_car_level];
		return _car_durable / md;
	}

	unsigned playerBusiness::getDurableLimit()
	{
		const int md = staticCar().durables[_car_level];
		if (md > _car_durable)return md - _car_durable;
		return 0;
	}

	void playerBusiness::fullDurable()
	{
		_car_durable = staticCar().durables[_car_level];
		_sign_auto();
	}

	void playerBusiness::overCollect(const int money)
	{
		if (money < 1)return;
		if (money > _single_max)
		{
			_single_max = money;
		}
		_cumulative_money += money;
		++_cumulative_task;//�ۼ���ɴ���
		const static long long int MaxTotal = 0x0FFFFFFFFFFFFFFF;
		_cumulative_money = _cumulative_money > MaxTotal ? MaxTotal : _cumulative_money;
		_sign_auto();
	}

	void playerBusiness::alterDurable(const int num)
	{
		_car_durable += num;
		_car_durable = _car_durable < 0 ? 0 : _car_durable;
		_sign_auto();
	}
	
	void playerBusiness::setData(mongo::BSONObj& obj)
	{
		if (obj.isEmpty())return;
		_car_level = obj["lv"].Int();
		_car_exp = obj["e"].Int();
		_car_durable = obj["d"].Int();
		_boss_hit_times = obj["hbt"].Int();
		_pirate_hit_times = obj["hpt"].Int();
		_cumulative_task = obj["tt"].Int();
		_single_max = obj["hm"].Int();
		_cumulative_money = obj["tm"].Long();
		std::vector<mongo::BSONElement> vecs = obj["sb"].Array();
		for (unsigned i = 0; i < vecs.size(); i++)
		{
			_boss_box.insert(vecs[i].Int());
		}
	}

	bool playerBusiness::_auto_save()
	{
		mongo::BSONObj key = BSON(strPlayerID << Own().ID());
		mongo::BSONArrayBuilder arr;
		for (std::set<unsigned>::const_iterator it = _boss_box.begin(); it != _boss_box.end(); it++)
		{
			arr << *it;
		}
		mongo::BSONObj obj = BSON("$set" << BSON("Biz" <<
			BSON("lv" << _car_level << "e" << _car_exp << "d" << _car_durable <<
				"tt" << _cumulative_task << "hm" << _single_max << "tm" << 
				_cumulative_money << "hpt" << _pirate_hit_times << "hbt" << _boss_hit_times <<
				"sb" << arr.arr())
		));
		return db_mgr.SaveMongo(DBN::dbPlayerCollection, key, obj);
	}

	void playerBusiness::_auto_update()
	{
		Json::Value json;
		json[strMsg][0u] = res_sucess;
		Json::Value& data_json = json[strMsg][1u];
		data_json["lv"] = _car_level;
		data_json["e"] = _car_exp;
		data_json["d"] = _car_durable;
		data_json["tt"] = _cumulative_task;
		data_json["hm"] = _single_max;
		data_json["tm"] = _cumulative_money;
		data_json["hpt"] = _pirate_hit_times;
		data_json["hscd"] = _boss_hit_cd;
		data_json["hbt"] = _boss_hit_times;
		Own().sendToClient(gate_client::player_trade_base_resp, json);
	}

	//business task
	playerBusinessTask::playerBusinessTask(playerData* const own) : _auto_player(own)
	{
		//������Ϣ
		_business_money = 0;
		_task_complete = 0;
		_task_type = TradeType::null;
		_task_times = 0;
		//������Ϣ
		_ware_bag.clear();
		_ware_num = 0;
	}

	void playerBusinessTask::setData(mongo::BSONObj& obj)
	{
		if (obj.isEmpty())return;
		_business_money = obj["m"].Int();
		_task_times = obj["tk"].Int();
		_task_complete = obj["cm"].Int();
		_task_type = (TradeType::Type)obj["tp"].Int();
		vector<mongo::BSONElement> elems = obj["v"].Array();
		for (unsigned i = 0; i < elems.size(); ++i)
		{
			mongo::BSONElement& elem = elems[i];
			playerWarePtr ware = Creator<Ware>::Create();
			ware->wareID = elem["i"].Int();
			ware->wareNum = elem["n"].Int();
			ware->avPrice = elem["p"].Int();
			_ware_bag[ware->wareID] = ware;
			_ware_num += ware->wareNum;
		}
	}

	bool playerBusinessTask::_auto_save()
	{
		mongo::BSONObj key = BSON(strPlayerID << Own().ID());
		mongo::BSONArrayBuilder arr;
		for (WareMap::iterator it = _ware_bag.begin(); it != _ware_bag.end(); ++it)
		{
			playerWarePtr ware = it->second;
			arr << BSON("i" << ware->wareID << "n" << ware->wareNum <<
				"p" << ware->avPrice);
		}
		mongo::BSONObj obj = BSON("$set" << BSON("BizTask" <<
			BSON("v" << arr.arr() << "m" <<
				_business_money << "cm" << _task_complete << "tk" << _task_times << "tp" <<
				_task_type)
		));
		return db_mgr.SaveMongo(DBN::dbPlayerCollection, key, obj);
	}

	void playerBusinessTask::_auto_update()
	{
		Json::Value json;
		json[strMsg][0u] = res_sucess;
		Json::Value& ware_json = json[strMsg][1u] = Json::arrayValue;
		for (WareMap::iterator it = _ware_bag.begin(); it != _ware_bag.end(); ++it)
		{
			playerWarePtr ware = it->second;
			Json::Value item_json;
			item_json.append(ware->wareID);
			item_json.append(ware->wareNum);
			item_json.append(ware->avPrice);
			ware_json.append(item_json);
		}
		Json::Value& data_json = json[strMsg][2u] = Json::objectValue;
		data_json["m"] = _business_money;
		data_json["cm"] = _task_complete;
		data_json["tk"] = _task_times;
		data_json["tp"] = _task_type;
		Own().sendToClient(gate_client::player_trade_ware_resp, json);
	}

	void playerBusinessTask::alterMoney(const int num)
	{
		_business_money += num;
		_business_money = _business_money < 0 ? 0 : _business_money;
		if (_task_type == TradeType::runing && _business_money >= _task_complete)
		{
			_task_type = TradeType::complete;
		}
		_sign_auto();
	}

	int playerBusinessTask::acceptTask(const int m, const int t)
	{
		if (taskType() != TradeType::null)return err_trade_has_task;
		_business_money = m;
		_task_complete = t;
		_task_type = TradeType::runing;
		++_task_times;
		_sign_auto();
		return res_sucess;
	}

	void playerBusinessTask::cancelTask()
	{
		_task_type = TradeType::null;
		_business_money = 0;
		_task_complete = 0;
		_ware_bag.clear();
		_sign_auto();
	}

	int playerBusinessTask::overTask()
	{
		if (taskType() == TradeType::null)return err_illedge;
		_task_type = TradeType::null;//����Ϊ��
		int max_money = std::max(_business_money, _task_complete);
		Own().Biz().overCollect(max_money);
		business_daily_rank.updatePlayer(Own().getOwnDataPtr(), max_money);//ÿ�յ�Ʊ
		business_single_rank.updatePlayer(Own().getOwnDataPtr());//��ʷ��Ʊ���
		business_total_rank.updatePlayer(Own().getOwnDataPtr());//��ʷ�������
		_business_money = 0;
		_task_complete = 0;

		_ware_bag.clear();
		_ware_num = 0;
		_sign_auto();
		return res_sucess;
	}

	playerBusinessTask::playerWarePtr playerBusinessTask::getWare(const int wareID)
	{
		WareMap::iterator it = _ware_bag.find(wareID);
		if (it == _ware_bag.end())return playerWarePtr();
		return it->second;
	}

	bool playerBusinessTask::checkWare(const int wareID, const unsigned num)
	{
		playerWarePtr ware = getWare(wareID);
		if (!ware || ware->wareNum < num)return false;
		return true;
	}

	int playerBusinessTask::addWare(const int wareID, const unsigned num, const int unit_price)
	{
		if (num < 1)return err_illedge;
		if (num + _ware_num > Own().Biz().getCapacity())return err_trade_bag_full;
		playerWarePtr ware = getWare(wareID);
		if (!ware)
		{
			ware = Creator<Ware>::Create();
			ware->wareID = wareID;
			_ware_bag[ware->wareID] = ware;
		}
		ware->avPrice = (ware->avPrice * ware->wareNum + unit_price * num) / (ware->wareNum + num);
		ware->wareNum += num;
		_ware_num += num;
		_sign_auto();
		return res_sucess;
	}

	int playerBusinessTask::removeWare(const int wareID, const unsigned num)
	{
		if (!checkWare(wareID, num))return err_illedge;
		playerWarePtr ware = getWare(wareID);
		ware->wareNum -= num;
		if (ware->wareNum == 0)
		{
			_ware_bag.erase(ware->wareID);
		}
		_ware_num -= num;
		_sign_auto();
		return res_sucess;
	}

	//Business Buff
	void playerBusinessBuff::_auto_update()
	{
		Json::Value json;
		json[strMsg][0u] = res_sucess;
		Json::Value& data_json = json[strMsg][1u] = Json::arrayValue;
		const unsigned now = Common::gameTime();
		for (BuffMap::iterator it = _business_buff.begin(); it != _business_buff.end();)
		{
			const TradeBuff::ID id = it->first;
			const unsigned over = it->second;
			++it;
			if (now >= over)continue;
			Json::Value buff_json;
			buff_json.append(id);
			buff_json.append(over);
			data_json.append(buff_json);
		}
		Own().sendToClient(gate_client::player_trade_buff_resp, json);
	}

	bool playerBusinessBuff::checkBuff(const TradeBuff::ID id)
	{
		unsigned now = Common::gameTime();
		BuffMap::iterator it = _business_buff.find(id);
		if (it == _business_buff.end())return false;
		if (now >= it->second)
		{
			_business_buff.erase(it);
			_sign_auto();
			return false;
		}
		return true;
	}

	bool playerBusinessBuff::insertBuff(const TradeBuff::ID id, const unsigned time)
	{
		if (!checkBuff(id))
		{
			_business_buff[id] = Common::gameTime() + time;
			_sign_auto();
			return true;
		}
		return false;
	}

	bool playerBusinessBuff::_auto_save()
	{
		mongo::BSONObj key = BSON(strPlayerID << Own().ID());
		const unsigned now = Common::gameTime();
		mongo::BSONArrayBuilder arr;
		for (BuffMap::iterator it = _business_buff.begin(); it != _business_buff.end();)
		{
			const TradeBuff::ID id = it->first;
			const unsigned over = it->second;
			++it;
			if (now >= over)
			{
				_business_buff.erase(id);
				continue;
			}
			arr << BSON("i" << id << "o" << over);
		}
		mongo::BSONObj obj = BSON("$set" << BSON("BizBuff" <<
			BSON("v" << arr.arr())
			));
		return	db_mgr.SaveMongo(DBN::dbPlayerCollection, key, obj);
	}

	void playerBusinessBuff::setData(mongo::BSONObj& obj)
	{
		if (obj.isEmpty())return;
		const unsigned now = Common::gameTime();
		vector<mongo::BSONElement> elems = obj["v"].Array();
		for (unsigned i = 0; i < elems.size(); ++i)
		{
			mongo::BSONElement& elem = elems[i];
			const TradeBuff::ID id = (TradeBuff::ID)elem["i"].Int();
			const unsigned over = elem["o"].Int();
			if (now >= over)continue;
			_business_buff[id] = over;
		}
	}


/////////////////

	playerBoatBorrow::playerBoatBorrow(playerData * const own) : _auto_player(own)
	{
		_arrows = 0;
		_borrow_use = 0;
		_borrow_buy = 0;
		_daily_borrow = 0;
		_borrow_time = 0;

		//
		_max_borrow = 0;
		_step_rewards = 0;
	}

	long long int playerBoatBorrow::getArrows()
	{
		check_res();
		return _arrows;
	}
	bool playerBoatBorrow::allowBorrow()
	{
		check_res();
		return _borrow_use < 2;
	}
	int playerBoatBorrow::buyBorrow()
	{
		check_res();
		const unsigned vip = Own().Info().VipLv();
		if (_borrow_buy >= _VipBuyBorrowLimits[vip])return err_business_buy_borrow_over;
		const int cost = _borrow_buy < (int)_BuyBorrowCost.size() ? _BuyBorrowCost[_borrow_buy] : _BuyBorrowCost.back();
		if (cost > Own().Res().getCash())return err_cash_not_enough;
		++_borrow_buy;
		--_borrow_use;
		Own().Res().alterCash(-cost);
		_sign_auto();
		return res_sucess;
	}
	void playerBoatBorrow::newBorrowArrows(const int val)
	{
		check_res();
		if (val > _daily_borrow)
		{
			_daily_borrow = val;
			_sign_auto();
		}
		if (val > _max_borrow)
		{
			_max_borrow = val;
			_sign_auto();
		}
	}
	void playerBoatBorrow::alterBorrow(const int val)
	{
		check_res();
		_borrow_use += val;
		_sign_auto();
	}
	void playerBoatBorrow::alterArrows(const int val)
	{
		check_res();
		_arrows += val;
		_arrows = std::max((long long int)0, _arrows);
		_sign_auto();
	}
	bool playerBoatBorrow::rawCheckRes()
	{
		if (raw_check_res())
		{
			_sign_update();
			return true;
		}
		return false;
	}
	void playerBoatBorrow::setBorrowStep(const unsigned step)
	{
		if (step > 31)return;
		if (((0x1 << step) & _step_rewards) == 0x0)
		{
			_step_rewards |= (0x1 << step);
			_sign_auto();
		}
	}
	void playerBoatBorrow::setData(mongo::BSONObj & obj)
	{
		if (obj.isEmpty())return;
		_arrows = obj["ars"].Long();
		_borrow_use = obj["bru"].Int();
		_borrow_buy = obj["brb"].Int();
		_daily_borrow = obj["dba"].Int();
		_borrow_time = obj["brt"].Int();

		//
		_max_borrow = obj["mba"].Int();
		_step_rewards = obj["stp"].Int();
	}
	bool playerBoatBorrow::raw_check_res()
	{
		if (business_sys.getBorrowID() != _borrow_time)
		{
			_arrows = 0;
			_borrow_use = 0;
			_borrow_buy = 0;
			_daily_borrow = 0;
			_borrow_time = business_sys.getBorrowID();
			return true;
		}
		return false;
	}
	void playerBoatBorrow::check_res()
	{
		if (rawCheckRes())
		{
			_sign_auto();
		}
	}
	bool playerBoatBorrow::_auto_save()
	{
		return db_mgr.SaveMongo(DBN::dbPlayerCollection, BSON(strPlayerID << Own().ID()),
			BSON("$set" << BSON("Borrow" << 
				BSON(
					"ars" << _arrows << "bru" << _borrow_buy <<
					"brb" << _borrow_buy << "dba" << _daily_borrow <<
					"brt" << _borrow_time << "mba" << _max_borrow <<
					"stp" << _step_rewards
				)
			))
		);
	}
	void playerBoatBorrow::_auto_update()
	{
		raw_check_res();
		qValue json(qJson::qj_object);
		json.addMember("ars", _arrows)
			.addMember("bru", _borrow_use)
			.addMember("brb", _borrow_buy)
			.addMember("dba", _daily_borrow)
			.addMember("brt", _borrow_time + DAY)
			.addMember("mba", _max_borrow)
			.addMember("stp", _step_rewards);
		qValue send_json(qJson::qj_array);
		send_json.append(res_sucess).append(json);
		Own().sendToClientFillMsg(gate_client::player_borrow_with_boat_update_resp,
			send_json);
	}
}
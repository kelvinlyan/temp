#pragma once

#include "auto_base.h"
#include "mongoDB.h"
#include "kingdomwar_task_def.h"
#include "action_system.h"

namespace gg
{
	class playerData;
	BOOSTSHAREPTR(playerData, playerDataPtr);

	namespace KingdomWar
	{
		class PersonalTaskMgr;

		class PersonalTask
		{
			friend class PersonalTaskMgr;
			public:
				PersonalTask(const Json::Value& info);
				int id() const { return _id; }
				int type() const { return _checker->type(); }
				int init(playerDataPtr d, Task::ParamPtr& param);
				int update(playerDataPtr d, Task::ParamPtr& param, const Json::Value& arg);
				ActionBoxList reward(playerDataPtr d) const;
			private:
				int _id;
				int _weight;
				Task::CheckPtr _checker;
				Json::Value _reward;
				int _reward70;
		};
		BOOSTSHAREPTR(PersonalTask, PersonalTaskPtr);

		class PersonalTaskMgr
		{
			SINGLETON(PersonalTaskMgr);
			STDMAP(int, PersonalTaskPtr, TaskMap);
			public:
				std::vector<PersonalTaskPtr> rand() const;
				PersonalTaskPtr Get(int id) const;
			private:
				PersonalTaskPtr tryGetOne(std::list<PersonalTaskPtr>& task_list) const;
				void eraseType(std::list<PersonalTaskPtr>& task_list, int type) const;
			private:
				TaskMap _task_map;
				unsigned _total_weight;
		};

		class PersonalRecord
		{
			public:
				PersonalRecord(const mongo::BSONElement& obj);
				PersonalRecord(PersonalTaskPtr task_ptr, playerDataPtr d);
				mongo::BSONObj toBSON() const;
				void getInfo(qValue& q) const;
				int id() const;
				int state() const { return _state; }
				int type() const;
				void update(playerDataPtr d, const Json::Value& arg);
				int getReward(playerDataPtr d, Json::Value& r);
			private:
				int target() const;
				int schedule() const;
			private:
				int _state;
				Task::ParamPtr _param;
				mutable PersonalTaskPtr _task_ptr;
		};

		class NationTaskMgr;

		class NationTask
		{
			friend class NationTaskMgr;
			public:
				NationTask(const Json::Value& info);
				int id() const { return _id; }
				int type(int strength) const;
				int init(int nation, int strength, Task::ParamPtr& param);
				int update(int nation, int strength, Task::ParamPtr& param, const Json::Value& arg);
				ActionBoxList reward(playerDataPtr d) const;
			private:
				int _id;
				int _weight;
				std::vector<Task::CheckPtr2> _checker;
				Json::Value _reward;
				int _reward70;
		};
		BOOSTSHAREPTR(NationTask, NationTaskPtr);

		class NationRecord
			: public _auto_meta
		{
			public:
				NationRecord(int nation);
				void loadDB();

				int id() const;
				int state() const { return _state; }
				int nationLv() const { return _nation_lv; }
				int type() const;
				ActionBoxList reward(playerDataPtr d) const;

				void update(int type, const Json::Value& arg);
				void getInfo(playerDataPtr d, qValue& q) const;

				void reset(int strength, const NationTaskPtr& task_ptr);
				void stop(unsigned cur_time);
				void clear();

				int getSchedule();
				int getTarget();

			private:
				virtual bool _auto_save();

			private:
				const int _nation;
				int _state;
				int _strength;
				int _nation_lv;
				Task::ParamPtr _param;
				NationTaskPtr _task_ptr;
		};
		BOOSTSHAREPTR(NationRecord, NationRecordPtr);
		
		class NationTaskMgr
		{
			SINGLETON(NationTaskMgr);
			STDMAP(int, NationTaskPtr, TaskMap);
			public:
				void getInfo(playerDataPtr d, qValue& q) const;
				void update(int type, int nation, const Json::Value& arg = Json::nullValue)
				{
					if (nation < 0 || nation >= _record_list.size())
						return;
					_record_list[nation]->update(type, arg);
				}
				NationRecordPtr getRecord(int nation)
				{
					if (nation < 0 || nation >= _record_list.size())
						return NationRecordPtr();
					return _record_list[nation];
				}
				NationTaskPtr getTask(int id) const
				{
					TaskMap::const_iterator it = _task_map.find(id);
					return it == _task_map.end()? NationTaskPtr() : it->second;
				}

				void reset();
				void clear();
				void start(unsigned cur_time);
				void stop(unsigned cur_time);

				void loadDB();

			private:
				void loadFile();

				NationTaskPtr rand(int type) const;

			private:
				STDVECTOR(NationRecordPtr, RecordList);
				RecordList _record_list;

				STDVECTOR(NationTaskPtr, TaskList);
				TaskList _rand_task[4];
				TaskMap _task_map;
				unsigned _total_weight[4];
		};

		class TaskParamHelper
			: public _auto_meta
		{
			SINGLETON_PTR(TaskParamHelper);
			public:
				int param() const 
				{
					return _player_set.size(); 
				}
				void update(int pid);
				void clear();

			private:
				void loadDB();
				virtual bool _auto_save();

			private:
				std::set<int> _player_set;
		};
	}
}

//###################################
//create by Jim
//2016-05-05
//###################################

#pragma once

#include "auto_do.h"

namespace gg
{
	namespace CUSTOMGIFT
	{
		struct DATA
		{
			DATA(const int id, const unsigned ct) : cID(id), cTime(ct)
			{
				gTimes = 0;
				gCD = 0;
			}
			const int cID;//���ID
			const unsigned cTime;//����ʱ��
			int gTimes;//��ȡ����
			unsigned gCD;//��ȡCD
		};
		BOOSTSHAREPTR(DATA, dataPtr);
	}

	class playerCustom :
		public _auto_player
	{
	public:
		playerCustom(playerData* const own);
		~playerCustom(){}
		void setData(mongo::BSONObj& obj);
		int canGetBox(const int csID, const unsigned createTime, const int maxTimes);
		void tickTimes(const int csID, const unsigned createTime, const unsigned aCD, const int num = 1);
		int getBoxTimes(const int csID, const unsigned createTime);
		unsigned getBoxCD(const int csID, const unsigned createTime);
		void resetTimes();
	private:
		CUSTOMGIFT::dataPtr getData(const int csID, const unsigned create_time);
		virtual bool _auto_save();
		STDMAP(int, CUSTOMGIFT::dataPtr, DATAMAP);
		DATAMAP dataMap;
	};
}
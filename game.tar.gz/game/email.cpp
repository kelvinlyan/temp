#include "email.h"
#include "email_system.h"

namespace gg
{
	void Email::setCommon(int server_id)
	{
		setId(email_sys.getCommonId(server_id));
		data[EmailDef::Common] = true;
	}

	CommonEmail::CommonEmail(int s, EmailPtr& e)
	{
		e->setCommon(s);
		id = e->id();
		time = Common::gameTime();
		type = All;
		data = e;
		server_id = s;
		deleted = false;
	}

	CommonEmail::CommonEmail(int s, const std::vector<std::string>& c, unsigned ot, EmailPtr& e)
	{
		e->setCommon(s);
		id = e->id();
		time = Common::gameTime();
		over_time = ot;
		server_id = s;
		type = Channel;
		ForEachC(std::vector<std::string>, it, c)
			channels.insert(*it);
		data = e;
		deleted = false;
	}

	CommonEmail::CommonEmail(int s, int n, EmailPtr& e)
	{
		e->setCommon(s);
		id = e->id();
		time = Common::gameTime();
		type = Nation;
		nation = n;
		data = e;
		server_id = s;
		deleted = false;
	}

	CommonEmail::CommonEmail(int s, const std::vector<int>& p, EmailPtr& e)
	{
		e->setCommon(s);
		id = e->id();
		time = Common::gameTime();
		type = Part;
		ForEachC(std::vector<int>, it, p)
			parts.insert(*it);
		data = e;
		server_id = s;
		deleted = false;
	}

	CommonEmail::CommonEmail(const mongo::BSONObj& obj)
	{
		id = obj[EmailDef::Id].Int();
		time = obj[EmailDef::Time].Int();
		type = obj[EmailDef::Type].Int();
		checkNotEoo(obj["svr"])
			server_id = obj["svr"].Int();
		else
			server_id = Common::serverID();
		if (type == Part)
		{
			std::vector<mongo::BSONElement> ele = obj["pt"].Array();
			for (unsigned i = 0; i < ele.size(); ++i)
				parts.insert(ele[i].Int());
		}
		else if (type == Nation)
			nation = obj["nt"].Int();
		else if (type == Channel)
		{
			std::vector<mongo::BSONElement> ele = obj["cn"].Array();
			for (unsigned i = 0; i < ele.size(); ++i)
				channels.insert(ele[i].String());
			over_time = obj["ot"].Int();
		}
		data = email_sys.createFromBSON(obj["e"]);
		deleted = false;
	}

	bool CommonEmail::needed(playerDataPtr d)
	{
		if (d->Info().ServerID() != server_id
			|| d->Info().CreateTime() >= time)
			return false;
		switch(type)
		{
			case All:
			{
				return true;
			}
			case Nation:
			{
				return d->Info().Nation() == nation;
			}
			case Part:
			{
				return parts.find(d->ID()) != parts.end();
			}
			case Channel:
			{
				return channels.find(d->Info().CID()) != channels.end();
			}
			default:
				return false;
		}
	}

	
	bool CommonEmail::outOfDate() const
	{
		return Common::gameTime() > time + 60 * DAY;
	}

	void CommonEmail::setDeleted()
	{
		deleted = true;
		data->setDeleted();
		LogI << "Delete Email: " << id << LogEnd;
	}

	CommonEmail::~CommonEmail()
	{
		if (deleted)
			removeDB();
		else
			LogE << "Error Email ID: " << id << LogEnd;
	}

	void CommonEmail::removeDB()
	{
		mongo::BSONObj key = BSON(EmailDef::Id << id);
		db_mgr.RemoveCollection(DBN::dbCommonEmails, key);
	}

	bool CommonEmail::_auto_save()
	{
		if (deleted)
			return true;
		
		mongo::BSONObj key = BSON(EmailDef::Id << id << "svr" << server_id);
		mongo::BSONObjBuilder obj;
		obj << EmailDef::Id << id << EmailDef::Time << time
			<< EmailDef::Type << type << "svr" << server_id;
		if (type == Part)
		{
			mongo::BSONArrayBuilder b;
			ForEach(std::set<int>, it, parts)
				b.append(*it);
			obj << "pt" << b.arr();
		}
		else if (type == Nation)
			obj << "nt" << nation;
		else if (type == Channel)
		{
			mongo::BSONArrayBuilder b;
			ForEachC(std::set<std::string>, it, channels)
				b.append(*it);
			obj << "cn" << b.arr() << "ot" << over_time;
		}
		obj << "e" << data->toJson().toIndentString();
		return db_mgr.SaveMongo(DBN::dbCommonEmails, key, obj.obj());
	}
}

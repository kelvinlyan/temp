#include "player_feod.h"
#include "ownerland_system.h"
#include "task_mgr.h"
#include "ownerland_def.h"

namespace gg
{
	STDMAP(int, DAILY::TYPE, DailyBindMap);
	static DailyBindMap mapBIND;

	//��Ӫ
	static std::vector<int> resetCampCost;
	static std::map< int, std::map< int, LAND::resMap > > returnCampRes;
	void playerBuilds::initData()
	{
		mapBIND[LAND::idx_building_res_silver] = DAILY::gather_silver;
		mapBIND[LAND::idx_building_res_cropland] = DAILY::gather_food;
		mapBIND[LAND::idx_building_res_iron] = DAILY::gather_iron;
		mapBIND[LAND::idx_building_res_wood] = DAILY::gather_wood;

		{//��Ӫ��������
			resetCampCost.clear();
			Json::Value json = Common::loadJsonFile("./instance/onwerland/reset_camp_cost.json");
			for (unsigned i = 0; i < json.size(); ++i)
			{
				resetCampCost.push_back(json[i].asInt());
			}
		};
		{//��Ӫ���÷���
			returnCampRes.clear();
			for (int camp = LAND::idx_building_type_sowar; camp <= LAND::idx_building_type_instrument; ++camp)
			{
				LANDCONFIG::landCFGPtr config = ownerland_sys.getBuildConfig(camp);
				if (!config)abort();//�Ҳ��������ļ�
				LAND::resMap current_res_map;
				for (unsigned level = config->beginLevel + 1; level <= config->endLevel; ++level)
				{
					LANDCONFIG::buildPtr level_config = config->findLV(level - 1);
					const LAND::resMap& check_map = level_config->upCost;
					for (LAND::resMap::const_iterator it = check_map.begin(); it != check_map.end(); ++it)
					{
						current_res_map[it->first] += it->second;
					}
					returnCampRes[camp][level] = current_res_map;
				}
			}
		};
	}

	void playerBuilds::delayUpdateAll(const structTimer& timerData, const int playerID)
	{
		playerDataPtr player = player_mgr.getOnlinePlayer(playerID);
		if (!player)return;
		if (player->Builds().delayUpdate)
		{
			player->Builds().updateAll();
		}
	}

	void playerBuilds::tickDelayUpdate()
	{
		if (!delayUpdate)
		{
			delayUpdate = true;
			Timer::AddEventSeconds(boostBind(playerBuilds::delayUpdateAll, _1, Own().ID()), Inter::event_delay_update_build, 3);//3s ֮���ڴٷ��¼�
		}
	}

	playerBuilds::playerBuilds(playerData* const own) :_auto_player(own)
	{
		delayUpdate = false;
		allHarvestAllTimesZhuCheng = 0;
	}

	unsigned playerBuilds::calMaxOut(const unsigned base, const int relateID)
	{
		return unsigned(base * (1.0 + Own().Research().getResearchData((LAND::HomeType)relateID) / 10000.0));
	}

	int playerBuilds::calPerOut(const int iFeod, const unsigned base, const int relateID)
	{
		double admin_add = 0;
		cfgManPtr config = Own().Admin().getVaildAdmin(iFeod, LAND::idx_adminType_yielder);
		if (config)admin_add = config->addRes / 10000.0;
		return int(base * (1.0 + Own().Research().getResearchData((LAND::HomeType)relateID) / 10000.0 + admin_add));
	}

	int playerBuilds::calPerOutOnly(const int iFeod, const unsigned base, const int relateID)
	{
		double admin_add = 0;
		cfgManPtr config = Own().Admin().getVaildAdmin(iFeod, LAND::idx_adminType_yielder);
		if (config)admin_add = config->addRes / 10000.0;
		return int(base * (Own().Research().getResearchData((LAND::HomeType)relateID) / 10000.0 + admin_add));
	}

	void playerBuilds::tickAllHarvest(int land_id)
	{
		if (land_id == LAND::zhu_cheng)
		{
			++allHarvestAllTimesZhuCheng;
			TaskMgr::update(Own().getOwnDataPtr(), Task::ZhuChengAllHarvestAllTimes);
			_sign_save();
		}
	}

	bool playerBuilds::tryHarvest(const vector<LAND::BuildKey>& buildList, bool all_harvest, int land_id)
	{
		qValue data_json(qJson::qj_array), list_json(qJson::qj_array);
		list_json.append(res_sucess);
		bool change_ok = false;
		for (unsigned i = 0; i < buildList.size(); ++i)
		{
			const LAND::BuildKey& buildAim = buildList[i];
			const int iFeod = buildAim.iFeod;
			const int iType = buildAim.iBuildType;
			const int iPos = buildAim.iBuildPos;
			//��ʼ�����ո��߼�
			FEOD::buildPtr build_ptr = getBuild(iFeod, iType, iPos);
			if (!build_ptr)return false;//Ѱ����Ҹ��˽�������
			LANDCONFIG::landCFGPtr config = ownerland_sys.getBuildConfig(iType);
			if (!config)return false;//Ѱ�������ļ�
			LANDCONFIG::buildPtr level_config = config->findLV(build_ptr->iBuildLv);
			if (!level_config)return false;//Ѱ�Ҷ�Ӧ�ȼ��������ļ�
			//�������
			if (level_config->iOutType <= LAND::idx_building_res_none || level_config->iOutType >= LAND::idx_building_res_end)return false;
			if (level_config->iOutValue <= 0.0)return false;
			//
			const unsigned now = Common::gameTime();
			if (build_ptr->uiOutTime >= now)return false;

			const unsigned times = (now - build_ptr->uiOutTime) / level_config->iOutIntervalTime;//��������
			const unsigned final_times = times > 10000 ? 10000 : times;
			const unsigned leave_time = (now - build_ptr->uiOutTime) % level_config->iOutIntervalTime;//ʱ�䲹λ
			const int max_out = calMaxOut(level_config->iMaxout, level_config->iCapacityRelateID);//������//����
			bool add_ret = false;
			if (final_times > 0)//�н���
			{
				const int base_value = std::min(max_out, (int)(level_config->iOutValue * final_times));
				const int add_value = calPerOutOnly(iFeod, base_value, level_config->iOutRelateID);
				const int total_value = base_value + add_value;
				ownerland_sys.alterResource(Own().getOwnDataPtr(), level_config->iOutType, total_value, true);
				add_ret = true;
				//�����ո���Ϣ
				if (total_value > 0)
				{
					qValue sg_data(qJson::qj_array);
					sg_data.append(iFeod);
					sg_data.append(iType);
					sg_data.append(iPos);
					sg_data.append(level_config->iOutType);
					sg_data.append(total_value);
					sg_data.append(add_value);
					data_json.append(sg_data);
					//�ճ�
					Own().Daily().tickTask(DAILY::land_harvest);
					Own().Daily().tickTask(mapBIND[level_config->iOutType]);
					//log
					Log(DBLOG::strLogBuildHarvest, Own().getOwnDataPtr(), -1, iFeod, iType, iPos, level_config->iBuildLv, level_config->iOutType, total_value, add_value);
				}
			}
			build_ptr->uiOutTime = now - leave_time;
			tickUpdateBuild(iFeod, iType, iPos);
			change_ok = true;
		}
		if (change_ok)
		{
			list_json.append(data_json);
			Own().sendToClientFillMsg(gate_client::building_harvest_resp, list_json);
			_sign_auto();
			if (all_harvest)
				tickAllHarvest(land_id);
		}
		return change_ok;
	}

	std::list<FEOD::buildPtr> playerBuilds::getFreeBuild(const int iFeod, const unsigned containType)
	{
		std::list<FEOD::buildPtr> resList;
		if (iFeod < LAND::FEOD_START || iFeod > LAND::FEOD_END)return resList;
		FEOD::BUILDSORTMAP& checkMap = autoWaitBuilds[iFeod];
		const unsigned limit_level = Own().LV() >= 100 ? 9999999 : Own().LV();//��ҵȼ�
		for (FEOD::BUILDSORTMAP::iterator it = checkMap.begin(); it != checkMap.end(); ++it)
		{
			FEOD::buildPtr build_ptr = it->second;
			if (build_ptr->iBuildLv >= limit_level)continue;
			if (Own().BuildTeam().getCD(build_ptr->iBuildFeod, build_ptr->iBuildType, build_ptr->iBuildPos) > 0)continue;
			if (!ownerland_sys.VaildAutoBuildType(containType, build_ptr->iBuildType))continue;
			resList.push_back(build_ptr);
		}
		return resList;
	}

	bool playerBuilds::tryHarvest(const int iFeod, const int iType, const int iPos)//�����ո�
	{
		FEOD::buildPtr build_ptr = getBuild(iFeod, iType, iPos);
		if (!build_ptr)return false;//Ѱ����Ҹ��˽�������
		LANDCONFIG::landCFGPtr config = ownerland_sys.getBuildConfig(iType);
		if (!config)return false;//Ѱ�������ļ�
		LANDCONFIG::buildPtr level_config = config->findLV(build_ptr->iBuildLv);
		if (!level_config)return false;//Ѱ�Ҷ�Ӧ�ȼ��������ļ�
		//�������
		if (level_config->iOutType <= LAND::idx_building_res_none || level_config->iOutType >= LAND::idx_building_res_end)return false;
		if (level_config->iOutValue <= 0.0)return false;
		//
		const unsigned now = Common::gameTime();
		if (build_ptr->uiOutTime >= now)return false;
		
		const unsigned times = (now - build_ptr->uiOutTime) / level_config->iOutIntervalTime;//��������
		const unsigned final_times = times > 10000 ? 10000 : times;
		const unsigned leave_time = (now - build_ptr->uiOutTime) % level_config->iOutIntervalTime;//ʱ�䲹λ
		const int max_out = calMaxOut(level_config->iMaxout, level_config->iCapacityRelateID);//������//����
		bool add_ret = false;
		if (final_times > 0)//�н���
		{
			const int base_value = std::min(max_out, (int)(level_config->iOutValue * final_times));
			const int add_value = calPerOutOnly(iFeod, base_value, level_config->iOutRelateID);
			const int total_value = base_value + add_value;
			ownerland_sys.alterResource(Own().getOwnDataPtr(), level_config->iOutType, total_value, true);
			add_ret = true;
			//�����ո���Ϣ
			if (total_value > 0)
			{
				qValue sg_data(qJson::qj_array), data_json(qJson::qj_array), list_json(qJson::qj_array);
				list_json.append(res_sucess);
				sg_data.append(iFeod);
				sg_data.append(iType);
				sg_data.append(iPos);
				sg_data.append(level_config->iOutType);
				sg_data.append(total_value);
				sg_data.append(add_value);
				data_json.append(sg_data);
				list_json.append(data_json);
				Own().sendToClientFillMsg(gate_client::building_harvest_resp, list_json);
				//�ճ�
				Own().Daily().tickTask(DAILY::land_harvest);
				Own().Daily().tickTask(mapBIND[level_config->iOutType]);
				//log
				Log(DBLOG::strLogBuildHarvest, Own().getOwnDataPtr(), -1, iFeod, iType, iPos, level_config->iBuildLv, level_config->iOutType, total_value, add_value);
			}
		}
		build_ptr->uiOutTime = now - leave_time;
		tickUpdateBuild(iFeod, iType, iPos);
		_sign_auto();
		return add_ret;
	}

	int playerBuilds::upgradeBuild(const int iFeod, const int iType, const int iPos, const unsigned iLv, const bool initial /* = false */)
	{
		const LAND::BuildKey key(iFeod, iType, iPos);
		FEOD::buildPtr build_ptr = getBuild(iFeod, iType, iPos);
		if (!build_ptr)return err_illedge;
		LANDCONFIG::landCFGPtr config = ownerland_sys.getBuildConfig(iType);
		if (!config || config->staticBuild)return err_illedge;
		unsigned set_lv = iLv > config->endLevel ? config->endLevel : iLv;
		const unsigned max_lv = Own().LV() >= 100 ? config->endLevel : Own().LV();
		set_lv = set_lv > max_lv ? max_lv : set_lv;
		//�ж�����,����ǿ����ո�Ľ���,���ո�
		tryHarvest(iFeod, iType, iPos);
		FEOD::BUILDSORTMAP& sortMap = autoWaitBuilds[iFeod];
		sortMap.erase(FEOD::LVKey(build_ptr->iBuildType, build_ptr->iBuildPos, build_ptr->iBuildLv));//ɾ���ɵ�����
		const unsigned old_buildLV = build_ptr->iBuildLv;
		build_ptr->iBuildLv = set_lv;
		if (config->autoBuild && build_ptr->iBuildLv < config->endLevel)//�½��ȴ�����
		{
			sortMap[FEOD::LVKey(build_ptr->iBuildType, build_ptr->iBuildPos, build_ptr->iBuildLv)] = build_ptr;
		}
		tickUpdateBuild(iFeod, iType, iPos);

		const FEOD::BUILDTYPEMAP& cMap = buildTypeMap[iFeod];
		FEOD::BUILDTYPEMAP::const_iterator it = cMap.find(LAND::BuildTypeKey(iFeod, iType));
		if (it == cMap.end())return false;
		const FEOD::BUILDMAP& checkMap = it->second;
		unsigned total_level = 0;
		for (FEOD::BUILDMAP::const_iterator it = checkMap.begin(); it != checkMap.end(); ++it)
		{
			total_level += it->second->iBuildLv;
		}
		const unsigned num = (0 == config->levelSpace) ?  config->buildMaxNum : (total_level / config->levelSpace + 1);//����һ������
		if (num > checkMap.size())
		{
			const unsigned loop_times = num - checkMap.size();
			for (unsigned n = 0; n < loop_times && (int)checkMap.size() < config->buildMaxNum; ++n)
			{
				FEOD::buildPtr new_build_ptr = Creator<FEOD::BuildData>::Create(
					iFeod,
					iType,
					(int)checkMap.size(),
					config->beginLevel
					);
				insert_build(new_build_ptr);
				tickUpdateBuild(iFeod, iType, new_build_ptr->iBuildPos);
				//��������
				Log(DBLOG::strLogUpgradeBuild, Own().getOwnDataPtr(), 1, iFeod, iType, new_build_ptr->iBuildPos, new_build_ptr->iBuildLv);
			}
		}

		updateTask(iType, set_lv);

		//����
		Log(DBLOG::strLogUpgradeBuild, Own().getOwnDataPtr(), 2, iFeod, iType, build_ptr->iBuildPos, old_buildLV, set_lv);
		// ����
		//Own().TaskData->changeBuildLv(iType, set_lv);
		// ���¼����佫����
		if (!initial && config->relateArms >= 0)//���ǳ�ʼ��//����������Ч
		{
			Own().Man().recalArmsMan(config->relateArms);
		}
		_sign_auto();
		return res_sucess;
	}

	void playerBuilds::classFinal()
	{
		checkNewBuild();
		openBuildAndLand(true);
		//���������ҵ���������
		Own().BuildTeam().clearTeam();//���ί����������
		Own().Admin().clearAdmin();//���ί��ʱ��
	}

	void playerBuilds::setData(mongo::BSONObj& obj)
	{
		if (obj.isEmpty())return;
		vector<mongo::BSONElement> vec = obj["arr"].Array();
		for (unsigned i = 0; i < vec.size(); i++)
		{
			mongo::BSONElement& elem = vec[i];
			FEOD::buildPtr build_ptr = Creator<FEOD::BuildData>::Create(
				elem["if"].Int(),
				elem["ibt"].Int(),
				elem["ibp"].Int(),
				(unsigned)elem["ilv"].Int()
				);
			build_ptr->uiOutTime = (unsigned)elem["ot"].Int();
			checkNotEoo(elem["rs"])build_ptr->resetTimes = elem["rs"].Int();
			LANDCONFIG::landCFGPtr config = ownerland_sys.getBuildConfig(build_ptr->iBuildType);
			if (!config) { continue; }
			if (build_ptr->iBuildPos >= config->buildMaxNum)continue;
			build_ptr->iBuildLv = std::max(config->beginLevel, build_ptr->iBuildLv);//ȡ��������͵ȼ�
			build_ptr->iBuildLv = build_ptr->iBuildLv > config->endLevel ? config->endLevel : build_ptr->iBuildLv;//����ȼ��������õȼ�
// 			if (config->autoBuild && build_ptr->iBuildLv < config->endLevel)
// 			{
// 				autoWaitBuilds[build_ptr->iBuildFeod][FEOD::LVKey(build_ptr->iBuildType, build_ptr->iBuildPos, build_ptr->iBuildLv)] = build_ptr;
// 			}
			insert_build(build_ptr);
		}
		checkNotEoo(obj["ahatzc"])
			allHarvestAllTimesZhuCheng = obj["ahatzc"].Int();
	}

	bool playerBuilds::_auto_save()
	{
		mongo::BSONObj key = BSON(strPlayerID << Own().ID());
		mongo::BSONArrayBuilder arr;
		for (FEOD::BUILDMAP::iterator itr = buildMap.begin(); itr != buildMap.end(); ++itr)
		{
			FEOD::buildPtr build_ptr = itr->second;
			arr << BSON("if" << build_ptr->iBuildFeod << "ibt" << build_ptr->iBuildType <<
				"ibp" << build_ptr->iBuildPos << "ilv" << build_ptr->iBuildLv <<
				"ot" << build_ptr->uiOutTime << "rs" << build_ptr->resetTimes);
		}
		mongo::BSONObj obj = BSON("$set" << BSON("Builds" << 
			BSON("arr" << arr.arr() << "ahatzc" << allHarvestAllTimesZhuCheng)
			));
		return db_mgr.SaveMongo(DBN::dbPlayerCollection, key, obj);
	}

	void playerBuilds::_auto_update()
	{
		bool to_update = false;
		qValue list_json(qJson::qj_array);
		for (std::set<LAND::BuildKey>::iterator it = updateBuilds.begin(); it != updateBuilds.end(); ++it)
		{
			const LAND::BuildKey& buildKey = *it;
			const int iFeod = buildKey.iFeod;
			const int iType = buildKey.iBuildType;
			const int iPos = buildKey.iBuildPos;
			FEOD::buildPtr build_ptr = getBuild(iFeod, iType, iPos);
			if (!build_ptr)continue;

			LANDCONFIG::landCFGPtr config = ownerland_sys.getBuildConfig(iType);
			if (!config)continue;
			LANDCONFIG::buildPtr level_config = config->findLV(build_ptr->iBuildLv);
			if (!level_config)continue;
			LANDCONFIG::buildPtr next_level_config = config->findLV(build_ptr->iBuildLv + 1);

			qValue buidldjson(qJson::qj_array);
			buidldjson.append(iFeod);//(0)���ǻ��߷�ص�ID
			buidldjson.append(iType);//(1)��������
			buidldjson.append(iPos);//(2)������λ��
			buidldjson.append(build_ptr->iBuildLv);//(3)�����ȼ�
			buidldjson.append((build_ptr->iBuildLv < config->endLevel));//(4)�Ƿ�������
			const unsigned nowBuildCD = Own().BuildTeam().getCD(iFeod, iType, iPos);
			buidldjson.append(Own().BuildTeam().getCD(iFeod, iType, iPos));//(5)����CD
			buidldjson.append(Own().BuildTeam().calBuildFinCDTime(level_config->iBuildCD));//(6)��һ������CD
			buidldjson.append(build_ptr->uiOutTime + level_config->iOutIntervalTime);//(7)����ʱ��
			const int per_out = 
				calPerOut(
				iFeod, 
				level_config->iOutValue * 3600 / (level_config->iOutIntervalTime < 1 ? 1 : level_config->iOutIntervalTime), 
				level_config->iOutRelateID
				);
			buidldjson.append(per_out);//(8)ÿСʱ����
			const int next_per_out = next_level_config ? 
				calPerOut(
				iFeod, 
				next_level_config->iOutValue * 3600 / (level_config->iOutIntervalTime < 1 ? 1 : level_config->iOutIntervalTime), 
				next_level_config->iOutRelateID
				) : 0;
			buidldjson.append(next_per_out);//(9)��һ��ÿСʱ����;
			const int max_out = calMaxOut(level_config->iMaxout, level_config->iCapacityRelateID);
			buidldjson.append(max_out);// (10)��ǰ����
			const int next_max_out = (next_level_config ? calMaxOut(next_level_config->iMaxout, next_level_config->iCapacityRelateID) : 0);
			buidldjson.append(next_max_out);// (11)��һ������
			qValue resJson(qJson::qj_array);
			for (LAND::resMap::iterator resItr = level_config->upCost.begin(); resItr != level_config->upCost.end(); ++resItr)
			{
				qValue upRes(qJson::qj_array);
				upRes.append(resItr->first);
				upRes.append(resItr->second);
				resJson.append(upRes);
			}
			buidldjson.append(resJson);//(12)������Դ
			const unsigned max_time = level_config->iOutValue < 1 ? 
				0 : 
				(build_ptr->uiOutTime + (unsigned)std::ceil(max_out / level_config->iOutValue) * level_config->iOutIntervalTime);
			buidldjson.append(max_time);//(13)������������ʱ���
			buidldjson.append(build_ptr->resetTimes);//���ô���
			list_json.append(buidldjson);
			to_update = true;
		}
		if (to_update)
		{
			qValue list_json_send(qJson::qj_array);
			list_json_send.append(res_sucess);
			list_json_send.append(list_json);
			Own().sendToClientFillMsg(gate_client::building_get_building_data_resp, list_json_send);
		}
		updateBuilds.clear();
	}

	int playerBuilds::resetCamp(const int iFeod, const int iType, const int iPos)
	{
		if (iType < LAND::idx_building_type_sowar || iType > LAND::idx_building_type_instrument)return err_illedge;
		FEOD::buildPtr build = getBuild(iFeod, iType, iPos);
		if (!build)return err_illedge;
		const int cost_cash = build->resetTimes < resetCampCost.size() ? resetCampCost[build->resetTimes] : resetCampCost.back();
		if (cost_cash > Own().Res().getCash())return err_cash_not_enough;
		LANDCONFIG::landCFGPtr config = ownerland_sys.getBuildConfig(iType);
		if (!config)return err_illedge;
		if (build->iBuildLv <= config->beginLevel)return err_illedge;
		const unsigned old_lv = build->iBuildLv;
		build->iBuildLv = config->beginLevel;
		Own().Man().recalArmsMan(config->relateArms);
		tickUpdateBuild(iFeod, iType, iPos);
		if (build->resetTimes < resetCampCost.size())++build->resetTimes;
		Own().Res().alterCash(-cost_cash);
		//��Դ����
		const LAND::resMap& use_map = returnCampRes[iType][old_lv];
		ownerland_sys.alterResource(Own().getOwnDataPtr(), use_map, true, 1.0);
		Log(DBLOG::strLogUpgradeBuild, Own().getOwnDataPtr(), 3, iFeod, iType, iPos, old_lv, build->iBuildLv);
		_sign_auto();
		return res_sucess;
	}

	bool playerBuilds::isBuildValid(const int iFeod, const LAND::BuildingType eBuildingType)
	{
		if (iFeod < LAND::FEOD_START || iFeod > LAND::FEOD_END)return false;

		const FEOD::BUILDTYPEMAP& cMap = buildTypeMap[iFeod];
		FEOD::BUILDTYPEMAP::const_iterator it = cMap.find(LAND::BuildTypeKey(iFeod, eBuildingType));
		if (it == cMap.end())return false;
		
		const FEOD::BUILDMAP& checkMap = it->second;
		return (!checkMap.empty());
	}

	void playerBuilds::updateAll()
	{
		bool to_update = false;
		qValue list_json(qJson::qj_array);
		for (FEOD::BUILDMAP::iterator it = buildMap.begin(); it != buildMap.end(); ++it)
		{
			FEOD::buildPtr build_ptr = it->second;
			if (!build_ptr)continue;
			const int iFeod = build_ptr->iBuildFeod;
			const int iType = build_ptr->iBuildType;
			const int iPos = build_ptr->iBuildPos;

			LANDCONFIG::landCFGPtr config = ownerland_sys.getBuildConfig(iType);
			if (!config)continue;
			LANDCONFIG::buildPtr level_config = config->findLV(build_ptr->iBuildLv);
			if (!level_config)continue;
			LANDCONFIG::buildPtr next_level_config = config->findLV(build_ptr->iBuildLv + 1);

			qValue buidldjson(qJson::qj_array);
			buidldjson.append(iFeod);//(0)���ǻ��߷�ص�ID
			buidldjson.append(iType);//(1)��������
			buidldjson.append(iPos);//(2)������λ��
			buidldjson.append(build_ptr->iBuildLv);//(3)�����ȼ�
			buidldjson.append((build_ptr->iBuildLv < config->endLevel));//(4)�Ƿ�������
			const unsigned nowBuildCD = Own().BuildTeam().getCD(iFeod, iType, iPos);
			buidldjson.append(Own().BuildTeam().getCD(iFeod, iType, iPos));//(5)����CD
			buidldjson.append(Own().BuildTeam().calBuildFinCDTime(level_config->iBuildCD));//(6)��һ������CD
			buidldjson.append(build_ptr->uiOutTime + level_config->iOutIntervalTime);//(7)����ʱ��
			const int per_out =
				calPerOut(
				iFeod,
				level_config->iOutValue * 3600 / (level_config->iOutIntervalTime < 1 ? 1 : level_config->iOutIntervalTime),
				level_config->iOutRelateID
				);
			buidldjson.append(per_out);//(8)ÿСʱ����
			const int next_per_out = next_level_config ?
				calPerOut(
				iFeod,
				next_level_config->iOutValue * 3600 / (level_config->iOutIntervalTime < 1 ? 1 : level_config->iOutIntervalTime),
				next_level_config->iOutRelateID
				) : 0;
			buidldjson.append(next_per_out);//(9)��һ��ÿСʱ����;
			const int max_out = calMaxOut(level_config->iMaxout, level_config->iCapacityRelateID);
			buidldjson.append(max_out);// (10)��ǰ����
			const int next_max_out = (next_level_config ? calMaxOut(next_level_config->iMaxout, next_level_config->iCapacityRelateID) : 0);
			buidldjson.append(next_max_out);// (11)��һ������
			qValue resJson(qJson::qj_array);
			for (LAND::resMap::iterator resItr = level_config->upCost.begin(); resItr != level_config->upCost.end(); ++resItr)
			{
				qValue upRes(qJson::qj_array);
				upRes.append(resItr->first);
				upRes.append(resItr->second);
				resJson.append(upRes);
			}
			buidldjson.append(resJson); //(12)������Դ
			const unsigned max_time = level_config->iOutValue < 1 ?
				0 :
				(build_ptr->uiOutTime + (unsigned)std::ceil(max_out / level_config->iOutValue) * level_config->iOutIntervalTime);
			buidldjson.append(max_time);//(13)������������ʱ���
			buidldjson.append(build_ptr->resetTimes);//(14)���ô���
			list_json.append(buidldjson);
			to_update = true;
		}
		if (to_update)
		{
			qValue list_json_send(qJson::qj_array);
			list_json_send.append(res_sucess);
			list_json_send.append(list_json);
			Own().sendToClientFillMsg(gate_client::building_get_building_data_resp, list_json_send);
		}
		delayUpdate = false;
	}

	bool playerBuilds::isBuildValid(const LAND::BuildingType eBuildingType)
	{
		return isBuildValid(LAND::zhu_cheng, eBuildingType);
	}

	void playerBuilds::tickUpdateBuild(const int iFeod, const int iType, const int iPos)
	{
		updateBuilds.insert(LAND::BuildKey(iFeod, iType, iPos));
		_sign_update();
	}

	FEOD::buildPtr playerBuilds::getBuild(const int iFeod, const int iType, const int iPos)
	{
		FEOD::BUILDMAP::iterator it = buildMap.find(LAND::BuildKey(iFeod, iType, iPos));
		if (it == buildMap.end())return FEOD::buildPtr();
		return it->second;
	}

	void playerBuilds::getBuildAttri(const int iType, int* attri)
	{
		for (unsigned i = 0; i < LAND::FEOD_NUM; ++i)
		{
			FEOD::buildPtr build_ptr = getBuild(i, iType, 0);
			if (!build_ptr)continue;//û��ָ������
			LANDCONFIG::landCFGPtr config = ownerland_sys.getBuildConfig(iType);
			if (!config)continue;//Ѱ�������ļ�
			LANDCONFIG::buildPtr level_config = config->findLV(build_ptr->iBuildLv);
			if (!level_config)continue;//Ѱ�Ҷ�Ӧ�ȼ��������ļ�
			for (unsigned n = 0; n < level_config->attriList.size(); ++n)
			{
				const AttriBase& base = level_config->attriList[n];
				attri[base.idx] += base.val;
			}
		}
	}

	void playerBuilds::insert_build(FEOD::buildPtr build_ptr)
	{
// 		FEOD::BUILDMAP buildMap;//����������
// 		FEOD::BUILDMAP buildFeodMap[LAND::FEOD_NUM];//�������� // ���ַ��
// 		FEOD::BUILDTYPEMAP buildTypeMap[LAND::FEOD_NUM];//�������� //���ַ�� //��������

		const LAND::BuildKey key(build_ptr->iBuildFeod, build_ptr->iBuildType, build_ptr->iBuildPos);
		const LAND::BuildTypeKey typeKey(build_ptr->iBuildFeod, build_ptr->iBuildType);

		buildMap[key] = build_ptr;
		buildFeodMap[build_ptr->iBuildFeod][key] = build_ptr;
		buildTypeMap[build_ptr->iBuildFeod][typeKey][key] = build_ptr;
		LANDCONFIG::landCFGPtr config = ownerland_sys.getBuildConfig(build_ptr->iBuildType);
		if (config && 
			!config->staticBuild && 
			config->autoBuild &&
			build_ptr->iBuildLv < config->endLevel)
		{
			autoWaitBuilds[build_ptr->iBuildFeod][FEOD::LVKey(build_ptr->iBuildType, build_ptr->iBuildPos, build_ptr->iBuildLv)] = build_ptr;
		}
	}

	void playerBuilds::openBuildAndLand(const bool initial /* = false */)
	{
		if (invaildBuildMap.empty())return;

		const unsigned playerLV = Own().Info().LV();
//		const int official = Own().Info().Official();
		const int influence = Own().War().lastWinMap();
		const int nation = Own().Info().Nation();

		bool use_save = false;
		for (FEOD::BUILDMAP::iterator it = invaildBuildMap.begin(); it != invaildBuildMap.end();)
		{
			FEOD::buildPtr build_ptr = it->second;
			++it;
			LANDCONFIG::landCFGPtr config = ownerland_sys.getBuildConfig(build_ptr->iBuildType);
			const LANDCONFIG::openBuild& cOpen = config->openLimit[build_ptr->iBuildFeod];//�������ھ��Ǻ���
			if (cOpen.openType == LAND::idx_building_open_role_lv && playerLV < (unsigned)cOpen.openVal)continue;
			//if (cOpen.openType == LAND::idx_building_open_position && official < cOpen.openVal)continue;
			if (cOpen.openType == LAND::idx_building_open_force && influence < cOpen.openVal)continue;//ͨ�������ж�
			if (cOpen.openType == LAND::idx_building_open_nation && (nation <= Kingdom::null || nation >= Kingdom::nation_num))continue;//ͨ�������ж�
			invaildBuildMap.erase(LAND::BuildKey(build_ptr->iBuildFeod, build_ptr->iBuildType, build_ptr->iBuildPos));//ɾ��ָ������
			build_ptr->uiOutTime = Common::gameTime();//�����ʱ����������ʱ��
			insert_build(build_ptr);//���ӵ���ʽ����
			use_save = true;
			Log(DBLOG::strLogUpgradeBuild, Own().getOwnDataPtr(), 1, build_ptr->iBuildFeod, build_ptr->iBuildType, build_ptr->iBuildPos, build_ptr->iBuildLv);
			//���Ӹ���
			if (!initial)tickUpdateBuild(build_ptr->iBuildFeod, build_ptr->iBuildType, build_ptr->iBuildPos);
			updateTask(build_ptr->iBuildType, build_ptr->iBuildLv);
			const FEOD::BUILDTYPEMAP& cMap = buildTypeMap[build_ptr->iBuildFeod];
			FEOD::BUILDTYPEMAP::const_iterator check_it = cMap.find(LAND::BuildTypeKey(build_ptr->iBuildFeod, build_ptr->iBuildType));
			if (check_it == cMap.end())continue;
			const FEOD::BUILDMAP& checkMap = check_it->second;
			unsigned total_level = 0;
			for (FEOD::BUILDMAP::const_iterator it = checkMap.begin(); it != checkMap.end(); ++it)
			{
				total_level += it->second->iBuildLv;
			}
			unsigned num = (0 == config->levelSpace) ? config->buildMaxNum : (total_level / config->levelSpace + 1);//����һ������
			num = num > config->buildMaxNum ? config->buildMaxNum : num;
			for (; (int)checkMap.size() < num;)
			{
				FEOD::buildPtr new_build_ptr = Creator<FEOD::BuildData>::Create(
					build_ptr->iBuildFeod,
					build_ptr->iBuildType,
					(int)checkMap.size(),
					config->beginLevel
				);
				insert_build(new_build_ptr);
				if (!initial)tickUpdateBuild(new_build_ptr->iBuildFeod, new_build_ptr->iBuildType, new_build_ptr->iBuildPos);
				//��������
				Log(DBLOG::strLogUpgradeBuild, Own().getOwnDataPtr(), 1, new_build_ptr->iBuildFeod, new_build_ptr->iBuildType, new_build_ptr->iBuildPos, new_build_ptr->iBuildLv);
				total_level += config->beginLevel;
				num = (0 == config->levelSpace) ? config->buildMaxNum : (total_level / config->levelSpace + 1);//����һ������
				num = num > config->buildMaxNum ? config->buildMaxNum : num;
			}
		}
		if (use_save)
		{
			if (!initial)
				TaskMgr::update(Own().getOwnDataPtr(), Task::FiefNum);
			_sign_save();
		}
	}


	void playerBuilds::checkNewBuild()
	{
		invaildBuildMap.clear();
		const LANDCONFIG::CONFIGMAP& checkMap = ownerland_sys.BuildConfigs;
		for (LANDCONFIG::CONFIGMAP::const_iterator itr = checkMap.begin(); itr != checkMap.end(); ++itr)
		{
			LANDCONFIG::landCFGPtr config = itr->second;
			const std::map<int, LANDCONFIG::openBuild>& OpenList = config->openLimit;
			for (std::map<int, LANDCONFIG::openBuild>::const_iterator open_it = OpenList.begin(); open_it != OpenList.end(); ++open_it)
			{
				const LANDCONFIG::openBuild& cOpen = open_it->second;
				if (!getBuild(cOpen.iFeod, config->buildType, 0))
				{
					invaildBuildMap[LAND::BuildKey(cOpen.iFeod, config->buildType, 0)] =
						Creator<FEOD::BuildData>::Create(cOpen.iFeod, config->buildType, 0, config->beginLevel);
				}
			}
		}
	}

	unsigned playerBuilds::getBuildLv(int type)
	{
		unsigned max = 0;
		for (unsigned i = LAND::FEOD_START; i < LAND::FEOD_NUM; ++i)
		{
			FEOD::BUILDTYPEMAP& type_map = buildTypeMap[i];
			ForEach(FEOD::BUILDTYPEMAP, it, type_map)
			{
				FEOD::BUILDMAP& build_map = it->second;
				ForEach(FEOD::BUILDMAP, itb, build_map)
				{
					FEOD::buildPtr& ptr = itb->second;
					if (ptr->iBuildType == type && ptr->iBuildLv > max)
						max = ptr->iBuildLv;
				}
			}
		}
		return max;
	}

	unsigned playerBuilds::getBuildLvSum(int type)
	{
		unsigned sum = 0;
		for (unsigned i = LAND::FEOD_START; i < LAND::FEOD_NUM; ++i)
		{
			FEOD::BUILDTYPEMAP& type_map = buildTypeMap[i];
			ForEach(FEOD::BUILDTYPEMAP, it, type_map)
			{
				FEOD::BUILDMAP& build_map = it->second;
				ForEach(FEOD::BUILDMAP, itb, build_map)
				{
					FEOD::buildPtr& ptr = itb->second;
					if (ptr->iBuildType == type)
						sum += ptr->iBuildLv;
				}
			}
		}
		return sum;
	}

	unsigned playerBuilds::getBarracksLvSum()
	{
		unsigned sum = 0;
		for (unsigned i = LAND::FEOD_START; i < LAND::FEOD_NUM; ++i)
		{
			FEOD::BUILDTYPEMAP& type_map = buildTypeMap[i];
			ForEach(FEOD::BUILDTYPEMAP, it, type_map)
			{
				FEOD::BUILDMAP& build_map = it->second;
				ForEach(FEOD::BUILDMAP, itb, build_map)
				{
					FEOD::buildPtr& ptr = itb->second;
					if (ptr->iBuildType >= LAND::idx_building_type_sowar
						&& ptr->iBuildType <= LAND::idx_building_type_instrument)
						sum += ptr->iBuildLv;
				}
			}
		}
		return sum;
	}

	unsigned playerBuilds::getFeodNum()
	{
		unsigned sum = 0;
		for (unsigned i = LAND::FEOD_START; i < LAND::FEOD_NUM; ++i)
		{
			FEOD::BUILDTYPEMAP& type_map = buildTypeMap[i];
			if (!type_map.empty())
				++sum;
		}
		return sum;
	}

	void playerBuilds::updateTask(int type, unsigned lv)
	{
		switch(type)
		{
			case LAND::idx_building_type_sowar:
				TaskMgr::update(Own().getOwnDataPtr(), Task::SowarLv, lv);
				TaskMgr::update(Own().getOwnDataPtr(), Task::BarracksLvSum);
				break;
			case LAND::idx_building_type_sapper:
				TaskMgr::update(Own().getOwnDataPtr(), Task::SapperLv, lv);
				TaskMgr::update(Own().getOwnDataPtr(), Task::BarracksLvSum);
				break;
			case LAND::idx_building_type_infantry:
				TaskMgr::update(Own().getOwnDataPtr(), Task::InfantryLv, lv);
				TaskMgr::update(Own().getOwnDataPtr(), Task::BarracksLvSum);
				break; 
			case LAND::idx_building_type_assist:
				TaskMgr::update(Own().getOwnDataPtr(), Task::AssistLv, lv);
				TaskMgr::update(Own().getOwnDataPtr(), Task::BarracksLvSum);
				break;
			case LAND::idx_building_type_adviser:
				TaskMgr::update(Own().getOwnDataPtr(), Task::AdviserLv, lv);
				TaskMgr::update(Own().getOwnDataPtr(), Task::BarracksLvSum);
				break;
			case LAND::idx_building_type_instrument:
				TaskMgr::update(Own().getOwnDataPtr(), Task::InstrumentLv, lv);
				TaskMgr::update(Own().getOwnDataPtr(), Task::BarracksLvSum);
				break;
			case LAND::idx_building_type_dwellings:
				TaskMgr::update(Own().getOwnDataPtr(), Task::DwellingsLv, lv);
				TaskMgr::update(Own().getOwnDataPtr(), Task::DwellingsLvSum, lv);
				TaskMgr::update(Own().getOwnDataPtr(), Task::ZhuChengResourceBuildingLvSum);
				break;
			case LAND::idx_building_type_cropland:
				TaskMgr::update(Own().getOwnDataPtr(), Task::CroplandLv, lv);
				TaskMgr::update(Own().getOwnDataPtr(), Task::CroplandLvSum, lv);
				TaskMgr::update(Own().getOwnDataPtr(), Task::ZhuChengResourceBuildingLvSum);
				break;
			case LAND::idx_building_type_mine:
				TaskMgr::update(Own().getOwnDataPtr(), Task::MineLv, lv);
				TaskMgr::update(Own().getOwnDataPtr(), Task::MineLvSum, lv);
				TaskMgr::update(Own().getOwnDataPtr(), Task::ZhuChengResourceBuildingLvSum);
				break;
			case LAND::idx_building_type_wood:
				TaskMgr::update(Own().getOwnDataPtr(), Task::WoodFarmLv, lv);
				TaskMgr::update(Own().getOwnDataPtr(), Task::WoodFarmLvSum, lv);
				TaskMgr::update(Own().getOwnDataPtr(), Task::ZhuChengResourceBuildingLvSum);
				break;
			default:
				break;
		}
	}

	unsigned playerBuilds::getZCResBuildingLvSum()
	{
		unsigned sum = 0;
		FEOD::BUILDTYPEMAP& type_map = buildTypeMap[LAND::zhu_cheng];
		ForEach(FEOD::BUILDTYPEMAP, it, type_map)
		{
			FEOD::BUILDMAP& build_map = it->second;
			ForEach(FEOD::BUILDMAP, itb, build_map)
			{
				FEOD::buildPtr& ptr = itb->second;
				if (ptr->iBuildType >= LAND::idx_building_type_dwellings 
					&& ptr->iBuildType <= LAND::idx_building_type_wood)
					sum += ptr->iBuildLv;
			}
		}
		return sum;
	}

}

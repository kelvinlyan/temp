#pragma once

#include "task_record.h"
#include "auto_base.h"

namespace gg
{
	class DaysActivityRecord
		: public Task::Record
	{
		public:
			DaysActivityRecord(const mongo::BSONElement& obj);
			DaysActivityRecord(int id, const Task::CheckPtr& ptr, playerDataPtr d);

		private:
			virtual bool getCheckPtr() const;
	};

	class playerDaysActivity
		: public _auto_player
	{
		public:
			playerDaysActivity(playerData* const own);

			virtual bool _auto_save();
			virtual void _auto_update();

			void update();
			void update(int type, int arg1, int arg2);
			void updateRedPoint(bool check);
			
			int getTaskReward(int id);
			int getCountReward(int id);

			void sendEmail();
			void checkAndUpdate();
	
		private:
			virtual void classLoad();
			bool getRedPoint();
			void alterFinishedCount(int n);

		private:
			int _key_id;
			int _days;

			bool _red_point;
			int _finished_count;
			std::vector<int> _target_states;
			Task::RecordMgr<DaysActivityRecord> _record_mgr;
	};
}

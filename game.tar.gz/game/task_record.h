#pragma once

#include "auto_base.h"
#include "mongoDB.h"
#include "task_def.h"

namespace gg
{
	namespace Task
	{
		class ICheck;
		BOOSTSHAREPTR(ICheck, CheckPtr);

		class Record
		{
			public:
				Record(const mongo::BSONElement& obj);
				Record(int id, const CheckPtr& ptr, playerDataPtr d);

				mongo::BSONObj toBSON() const;
				void getInfo(Json::Value& info) const;

				int id() const { return _id; }
				int state() const { return _state; }
				int type() const;
				void setState(int s) { _state = s; }

				bool check(playerDataPtr d, int arg1, int arg2);
				bool recheck(playerDataPtr d);

			protected:
				virtual bool getCheckPtr() const = 0;
				mutable CheckPtr _check_ptr;

				int _id;
				int _value;
				int _state;
		};

		BOOSTSHAREPTR(Record, RecordPtr);
		typedef boost::function<void(const RecordPtr&)> Handler;

		template<typename T>
		class RecordMgr
		{
			public:
				RecordMgr(): _red_point(false){ _running_types.set(); }
				void load(const mongo::BSONElement& obj);
				mongo::BSONArray toBSON() const;

				void getInfo(Json::Value& info) const;
				
				void setState(int id, int state);
				int getState(int id);
				void run(Handler h);

				bool check(playerDataPtr d, int type, int arg1, int arg2);
				void recheck(playerDataPtr d);

				void clear();
				void push(const RecordPtr& r);
				void pop(int id);
				bool empty() const;
				bool taskFinished() const { return _red_point; }
				const std::vector<int>& getFinishedList() const { return _finished_list; }

			private:
				void resetRedPoint();

			private:
				std::bitset<TypeMax> _running_types;

				std::vector<int> _finished_list;
				UNORDERMAP(int, RecordPtr, RecordMap); 			
				RecordMap _records;
				bool _red_point;
		};
		
		template<typename T>
		mongo::BSONArray RecordMgr<T>::toBSON() const
		{
			mongo::BSONArrayBuilder b;
			ForEachC(RecordMap, it, _records)
				b.append(it->second->toBSON());
			return b.arr();
		}
		
		template<typename T>
		void RecordMgr<T>::load(const mongo::BSONElement& obj)
		{
			std::vector<mongo::BSONElement> ele = obj.Array();	
			for (unsigned i = 0; i < ele.size(); ++i)
			{
				RecordPtr r = Creator<T>::Create(ele[i]);
				if (r->type() == Empty)
					continue;
				if (r->state() == Finished)
					_red_point = true;
				_records.insert(make_pair(r->id(), r));
			}
		}

		template<typename T>
		void RecordMgr<T>::getInfo(Json::Value& info) const
		{
			info = Json::arrayValue;
			ForEachC(RecordMap, it, _records)
			{
				Json::Value tmp;
				it->second->getInfo(tmp);
				info.append(tmp);
			}
		}

		template<typename T>
		void RecordMgr<T>::recheck(playerDataPtr d)
		{
			_red_point = false;
			_running_types.reset();
			ForEach(RecordMap, it, _records)
			{
				it->second->recheck(d);
				if (it->second->state() == Running)
					_running_types.set(it->second->type());
				if (it->second->state() == Finished)
					_red_point = true;
			}
		}

		template<typename T>
		bool RecordMgr<T>::check(playerDataPtr d, int type, int arg1, int arg2)
		{
			if (!_running_types.test(type))
				return false;

			bool modified = false;
			bool clear_type = true;
			_finished_list.clear();
			ForEach(RecordMap, it, _records)
			{
				if (it->second->type() == type
					&& it->second->state() == Running)
				{
					if (it->second->check(d, arg1, arg2))
						modified = true;

					if (it->second->state() == Running)
						clear_type = false;
					else
					{
						_finished_list.push_back(it->second->id());
						_red_point = true;
					}
				}
			}
			if (clear_type)
				_running_types.reset(type);

			return modified;
		}

		template<typename T>
		int RecordMgr<T>::getState(int id)
		{
			RecordMap::iterator it = _records.find(id);
			if (it == _records.end())
				return NotExist;
			return it->second->state();
		}

		template<typename T>
		void RecordMgr<T>::setState(int id, int state)
		{
			RecordMap::iterator it = _records.find(id);
			if (it == _records.end())
				return;
			it->second->setState(state);
			if (state == Finished)
				_red_point = true;
			else
				resetRedPoint();
		}

		template<typename T>
		void RecordMgr<T>::clear()
		{
			_red_point = false;
			_running_types.reset();
			_records.clear();
		}
		
		template<typename T>
		void RecordMgr<T>::push(const RecordPtr& r)
		{
			_records.insert(make_pair(r->id(), r));
			if (r->state() == Running)
				_running_types.set(r->type());
			if (r->state() == Finished)
				_red_point = true;
		}

		template<typename T>
		void RecordMgr<T>::pop(int id)
		{
			RecordMap::iterator it = _records.find(id);
			if (it != _records.end())
			{
				_records.erase(it);
				resetRedPoint();
			}
		}

		template<typename T>
		bool RecordMgr<T>::empty() const
		{
			return _records.empty();
		}

		template<typename T>
		void RecordMgr<T>::resetRedPoint()
		{
			_red_point = false;
			ForEachC(RecordMap, it, _records)
			{
				if (it->second->state() == Finished)
				{
					_red_point = true;
					return;
				}
			}
		}

		template<typename T>
		void RecordMgr<T>::run(Handler h)
		{
			ForEachC(RecordMap, it, _records)
				h(it->second);
		}
	}
}

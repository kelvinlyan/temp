/*
#########################
Created by Lin Xing
2016.12.28
#########################
*/
#pragma once
#include "commom.h"

namespace red_paper
{
	namespace channel
	{
		enum Channel
		{
			World = 1,
			Country = 2,
			Person = 3,
			SYS_World = 4,
			SYS_Country = 5,
			SYS_Wu = 6,
			SYS_Shu = 7,
			SYS_Wei = 8,
		};
	}

	typedef struct _red_paper
	{
		int id;
		int total_cash;
		int total_num;
		int channel;
		int cash;
		int num;
		int res_type;//Ԫ������
	} RedPaper;
	BOOSTSHAREPTR(RedPaper, RedPaperPtr);

	typedef struct _paper_config
	{
		std::vector<RedPaperPtr> papers;
	}PaperConfig;

	typedef struct _unit_paper
	{
		int local_id;
		unsigned date;
		int player_id;
		int face_id;
		int nation;//���Һ���������������ڹ���
		int receiver_id;//˽�˺��ʱ�����������ID
		std::string player_name;
		ptrTimerIdentify timer;
		RedPaperPtr raw_paper;
	} UnitPaper;
	BOOSTSHAREPTR(UnitPaper, UnitPaperPtr);

	typedef struct _rob_log
	{
		//UnitPaperPtr paper_ptr;//�������
		int robberID;//���ú�������ID
		int senderID;
		int local_id;
		int face_Id;
		int cash;//���õĽ��
		unsigned date;//����ʱ��
		std::string nickname;//�������
	}Robber;
	BOOSTSHAREPTR(Robber, RobberPtr);
	STDVECTOR(RobberPtr, RobberVec);//һ�������������¼
	STDMAP(int, RobberVec, RobberPlayerList);//һ��������к��������¼�б�

	typedef struct _robbed_user
	{
		int local_id;//���id
		int userID;
		std::string nickname;
		int cash;//���õĽ������
		unsigned date;
		int face_Id;
		int del;
	}RobbedUser;
	BOOSTSHAREPTR(RobbedUser, RobberUserPtr);
	STDMAP(int, RobberUserPtr, PaperRobbedList);

	typedef struct _sent_user
	{
		UnitPaperPtr paper;
		int del;
		unsigned date;
	}Sender;
	BOOSTSHAREPTR(Sender, SenderPtr);

	typedef struct _activity_red_paper
	{
		int id;
		int type;//Ƶ��
		int cash;
		int num;
		int res_type;
	}SpecialRedPaper;

	typedef struct _activity_unit
	{
		unsigned date;
		std::vector<SpecialRedPaper> papers;
	}ActivityUnit;

	typedef struct _activity_complete
	{
		int id;
		unsigned stime;
		unsigned etime;
		std::vector<ActivityUnit> activities;
	} ActivityComplete;
}
STDMAP(int, red_paper::UnitPaperPtr, RedPaperList);
UNORDERMAP(int, RedPaperList, RedPaperSet);
typedef std::multimap<unsigned, red_paper::UnitPaperPtr> MultiRedPaperList;
BOOSTSHAREPTR(RedPaperSet, RedPaperSetPtr);
UNORDERMAP(int, red_paper::RobberPlayerList, RobberPlayerSet);
STDMAP(int, red_paper::RedPaperPtr, RawRedPaperPtrList);

BOOSTSHAREPTR(red_paper::PaperRobbedList, PaperRobbedListPtr);
STDMAP(int, red_paper::SenderPtr, SentPaperList);
BOOSTSHAREPTR(SentPaperList, SentPaperListPtr);
STDMAP(int, red_paper::ActivityComplete, ActivityCompleteList);

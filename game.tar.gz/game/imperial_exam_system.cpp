#include "imperial_exam_system.h"
#include "game_time.h"
#include "email_system.h"

namespace gg
{
	const static std::string strExamID = "eid";
	const static std::string strRank = "rank";
	const static std::string strTime = "tm";

	namespace imperial
	{
		static EventType getRandomType(const std::vector<int>& odds)
		{
			int rnd = Common::randomBetween(0, odds.back());
			int idx = -1;
			for (int i = 1; i < odds.size(); ++i)
			{
				if (rnd <= odds[i])
				{
					idx = i;
					break;
				}
			}
			if (idx == 2)
			{
				return imperial::Suggection;
			}
			else if (idx == 3)
			{
				return imperial::Fight;
			}
			else if (idx == 4)
			{
				return imperial::Purchase;
			}
			else
			{
				return imperial::Answer;
			}
		}

		static ExamEventPtr createEvent(EventType type, AnswerSinglePtr single)
		{
			if (type == imperial::Answer)
			{
				return Creator<exam_answer_event>::Create(single);
			}
			return ExamEventPtr();
		}

		static ExamEventPtr createEvent(EventType type, SuggectionSinglePtr single)
		{
			if (type == imperial::Suggection)
			{
				return Creator<exam_suggection_event>::Create(single);
			}
			return ExamEventPtr();
		}

		static ExamEventPtr createEvent(EventType type, FightSinglePtr single)
		{
			if (type == imperial::Fight)
			{
				return Creator<exam_fight_event>::Create(single);
			}
			return ExamEventPtr();
		}

		static ExamEventPtr createEvent(EventType type, PurchaseSinglePtr single)
		{
			if (type == imperial::Purchase)
			{
				return Creator<exam_purchase_event>::Create(single);
			}
			return ExamEventPtr();
		}
	}

	imperial::ExamConfig ImperialExamSystem::_config;

	int ImperialExamSystem::_id = 0;

	std::map<int, imperial::AnswerGroup> ImperialExamSystem::_player_answer_map;
	std::map<int, imperial::SuggectionGroup> ImperialExamSystem::_player_suggection_map;
	std::map<int, imperial::FightGroup> ImperialExamSystem::_player_fight_map;
	std::map<int, imperial::PurchaseGroup> ImperialExamSystem::_player_purchase_map;

	std::map<int, lx::Sequence> ImperialExamSystem::_answer_ids;
	std::map<int, lx::Sequence> ImperialExamSystem::_suggection_ids;
	std::map<int, lx::Sequence> ImperialExamSystem::_fight_ids;
	std::map<int, lx::Sequence> ImperialExamSystem::_purchase_ids;
	std::map<int, ExamEventPtr> ImperialExamSystem::_player_event_map;

	ImperialExamSystem::MultiOrder ImperialExamSystem::_country_rank;
	ImperialExamSystem::TempleOrder ImperialExamSystem::_temple_rank;
	std::map<int, ImperialExamSystem::TempleOrder > ImperialExamSystem::_top_temple_rank;

	std::vector<imperial::PlayerInfo> ImperialExamSystem::_country_rank_info;
	std::vector<imperial::PlayerInfo> ImperialExamSystem::_temple_rank_info;
	std::map<int, ImperialExamSystem::TopInfo> ImperialExamSystem::_top_rank_info;
	std::map<int, int> ImperialExamSystem::_player_country_rank;
	std::map<int, int> ImperialExamSystem::_player_temple_rank;
	std::map<int, int> ImperialExamSystem::_player_country_rank_r;
	std::map<int, int> ImperialExamSystem::_player_temple_rank_r;
	Json::Value ImperialExamSystem::_country_rank_json;
	Json::Value ImperialExamSystem::_temple_rank_json;

	static Json::Value _country_rank_json;
	static Json::Value _temple_rank_json;

	ImperialExamSystem::ImperialExamSystem()
	{
	}


	ImperialExamSystem::~ImperialExamSystem()
	{
	}

	void ImperialExamSystem::reqImperialExamRedPoint(net::Msg& m, Json::Value& r)
	{
		playerDataPtr player = player_mgr.getPlayer(m.playerID);
		if (!player)Return(r, err_illedge);

		if (player->LV() >= _config.lv && season_sys.getSeason() == SEASON::Winter)
		{
			r[strMsg][0] = 0;
			r[strMsg][0] = 0;
		}
		else
		{
			r[strMsg][0] = 0;
			r[strMsg][0] = 2;
		}
	}

	void ImperialExamSystem::reqImperialExamInfo(net::Msg& m, Json::Value& r)
	{
		playerDataPtr player = player_mgr.getPlayer(m.playerID);
		if (!player)Return(r, err_illedge);

		if (player->LV() < _config.lv)
		{
			Return(r, err_imperial_exam_lv_limit);
		}
		if (season_sys.getSeason() != SEASON::Winter)
		{
			Return(r, err_imperial_exam_season_error);
		}
		int country_grade = player->ImperialExam().getCountryGrade();
		int temple_grade = player->ImperialExam().getTempleGrade();
		imperial::ExamState state = player->ImperialExam().state();
		//
		Json::Value country_reward_json = Json::arrayValue;
		int country_idx = getCountryRewardIdx(country_grade);
		for (int i = 0; i < _config.countryReward.size(); ++i)
		{
			Json::Value single = Json::arrayValue;
			single.append(_config.countryReward[i].lbound);
			single.append(_config.countryReward[i].ubound);
			single.append(_config.countryReward[i].box.jsonBox);
			if (country_grade != i)
			{
				single.append(0);//û����Ӧ�Ľ���
			}
			else if (player->ImperialExam().isExistCountryReward())
			{
				single.append(1);//������ȡ
			}
			else
			{
				single.append(2);//�Ѿ���ȡ
			}
			country_reward_json.append(single);
		}
		//
		Json::Value temple_reward_json = Json::arrayValue;
		int temple_idx = getTempleRewardIdx(temple_grade);
		for (int i = 0; i < _config.templeReward.size(); ++i)
		{
			Json::Value single = Json::arrayValue;
			single.append(_config.templeReward[i].lbound);
			single.append(_config.templeReward[i].ubound);
			single.append(_config.templeReward[i].box.jsonBox);
			if (temple_grade != i)
			{
				single.append(0);//û����Ӧ�Ľ���
			}
			else if (player->ImperialExam().isExistTempleReward())
			{
				single.append(1);//������ȡ
			}
			else
			{
				single.append(2);//�Ѿ���ȡ
			}
			temple_reward_json.append(single);
		}
		r[strMsg][0u] = 0;
		r[strMsg][1u] = (int)state;
		r[strMsg][2u] = country_grade;
		r[strMsg][3u] = temple_grade;
		r[strMsg][4u] = capsuleInfo(player);
		r[strMsg][5u] = country_reward_json;
		r[strMsg][6u] = temple_reward_json;
	}

	void ImperialExamSystem::reqImperialExamSign(net::Msg& m, Json::Value& r)
	{
		playerDataPtr player = player_mgr.getPlayer(m.playerID);
		if (!player)Return(r, err_illedge);

		if (player->LV() < _config.lv)
		{
			Return(r, err_imperial_exam_lv_limit);
		}
		if (season_sys.getSeason() != SEASON::Winter)
		{
			Return(r, err_imperial_exam_season_error);
		}
		if (player->ImperialExam().state() != imperial::StateInit)
		{
			Return(r, err_imperial_exam_has_sign);
		}
		unsigned deadline = Common::gameTime() + _config.times < Common::getNextTimeHMS(5) ? Common::gameTime() + _config.times : Common::getNextTimeHMS(5);
		player->ImperialExam().sign(_config.grade, deadline);
		//���Ӷ�ʱ�������ض�ʱ����û�д��ꡣ������ʱ�������ʱ���Ǵ����賿���
		Return(r, res_sucess);
	}

	void ImperialExamSystem::reqImperialExamCountryNext(net::Msg& m, Json::Value& r)
	{
		playerDataPtr player = player_mgr.getPlayer(m.playerID);
		if (!player)Return(r, err_illedge);

		if (player->LV() < _config.lv)
		{
			Return(r, err_imperial_exam_lv_limit);
		}
		if (season_sys.getSeason() != SEASON::Winter)
		{
			Return(r, err_imperial_exam_season_error);
		}
		if (player->ImperialExam().state() == imperial::StateInit)
		{
			Return(r, 1);//δ�μӱ���
		}
		if (player->ImperialExam().state() != imperial::StateCountryIn)
		{
			Return(r, 2);//�����Ѿ�����
		}
		unsigned start = player->ImperialExam().start();
		unsigned now = Common::gameTime();
		if (now - start >= _config.times)//�������ʱ�䲻�ԣ���Ӧ�ò��������⡣
		{
			player->ImperialExam().setCountryOut();
			Return(r, 2);//�����Ѿ�����
		}
		ExamEventPtr event_ptr;
		createNextTopic(player, imperial::Country, event_ptr);
		if (event_ptr)
		{
			event_ptr->getDetail(r);
		}
		else
		{
			Return(r, 3);//�������ڲ�����
		}
		r[strMsg][2u] = _config.times - (now - start);
	}

	void ImperialExamSystem::reqImperialExamTempleNext(net::Msg& m, Json::Value& r)
	{
		playerDataPtr player = player_mgr.getPlayer(m.playerID);
		if (!player)Return(r, err_illedge);

		if (player->LV() < _config.lv)
		{
			Return(r, err_imperial_exam_lv_limit);
		}
		if (season_sys.getSeason() != SEASON::Winter)
		{
			Return(r, err_imperial_exam_season_error);
		}
		if (player->ImperialExam().state() == imperial::StateInit)
		{
			Return(r, 1);//δ�μӱ���
		}
		if (player->ImperialExam().state() == imperial::StateTempleComplete)
		{
			Return(r, 5);//�������
		}
		if (player->ImperialExam().state() != imperial::StateTempleIn)
		{
			Return(r, 4);//û�е����ʸ�
		}
		ExamEventPtr event_ptr;
		createNextTopic(player, imperial::Temple, event_ptr);
		if (event_ptr)
		{
			event_ptr->getDetail(r);
			player->ImperialExam().addTempleCount(1);
		}
		else
		{
			Return(r, 3);//�������ڲ�����
		}
		r[strMsg][2u] = player->ImperialExam().templeTime();
		player->ImperialExam().setCountryState(imperial::PeddingAnswer);
	}

	void ImperialExamSystem::reqImperialExamCountrySubmit(net::Msg& m, Json::Value& r)
	{
		playerDataPtr player = player_mgr.getPlayer(m.playerID);
		if (!player)Return(r, err_illedge);

		if (player->LV() < _config.lv)
		{
			Return(r, err_imperial_exam_lv_limit);
		}
		if (season_sys.getSeason() != SEASON::Winter)
		{
			Return(r, err_imperial_exam_season_error);
		}
		if (player->ImperialExam().state() == imperial::StateInit)
		{
			Return(r, 1);//δ�μӱ���
		}
		if (player->ImperialExam().state() != imperial::StateCountryIn)
		{
			Return(r, 2);//�����Ѿ�����
		}
		unsigned start = player->ImperialExam().start();
		unsigned now = Common::gameTime();
		if (now - start >= _config.times)
		{
			player->ImperialExam().setCountryOut();
			Return(r, 2);//�����Ѿ�����
		}
		if (_player_event_map.find(player->ID()) == _player_event_map.end() || !_player_event_map[player->ID()])
		{
			Return(r, 3);//�������ڲ�����
		}

		ReadJsonArray;
		int flag = js_msg[0u].asInt();
		//int flag = js_msg[1u].asInt();
		/*
		int score = _player_event_map[player->ID()]->getGrade(flag);
		//�����Ǵ���score��ҵ���߼�
		player->ImperialExam().alterCountryGrade(score);
		int new_grade = player->ImperialExam().getCountryGrade();
		int temple_flag = 0;
		if (new_grade >= _config.grade)
		{
			//player->ImperialExam().addTimeRestCountryGrade();
			temple_flag = 1;
		}
		if (_player_event_map[player->ID()]->Type() == imperial::Answer)
		{
			//�������
			if (flag == 1)
			{
				player->ImperialExam().addCountryCorrect(1);
				if (player->ImperialExam().getCountryCorrect() == _config.cont)
				{
					///����������
					//randomCapsule(player);
					player->ImperialExam().resetCountryCorrect();
				}
			}
			else
			{
				player->ImperialExam().resetCountryCorrect();
			}
		}
		int next_flag = player->ImperialExam().getCountryCount() >= _config.size ? 1 : 0;
		///�������ˣ�ȡ��ʱ�������֪ͨ��ʱ��
		if (temple_flag)
		{
			player->ImperialExam().setState(imperial::StateTempleIn);
			player->ImperialExam().delTimer();
		}
		//û����һ��ͷ�������
		if (!next_flag && !temple_flag)
		{
			
			player->ImperialExam().setState(imperial::StateCountryOut);
			player->ImperialExam().delTimer();
		}
		///����������Ŀ�����ˡ�����ʱ�䣬ǿ�ƽ�����ԡ���ô֪ͨ������
		*/
		
		Json::Value ret_json = handleCountrySubmit(player, flag, 1);
		r[strMsg][0u] = 0;
		r[strMsg][1u] = ret_json[0u];
		r[strMsg][2u] = ret_json[1u];
		r[strMsg][3u] = ret_json[2u];
		r[strMsg][4u] = ret_json[3u];
		//����
		if (player->ImperialExam().state() == imperial::StateCountryOut
			|| player->ImperialExam().state() == imperial::StateTempleIn)
		{
			int grade = player->ImperialExam().getCountryGrade();
			int reward_idx = getCountryRewardIdx(grade);
			if (reward_idx != -1)
			{
				//���ӽ���
				player->ImperialExam().setCountryReward(_config.countryReward[reward_idx].box);
			}
			_country_rank.insert(make_pair(grade, player->ID()));
			//����ʱ��������ǰ100
			updateCountryRank();
			saveCountryRank();
		}
	}

	void ImperialExamSystem::reqImperialExamTempleSubmit(net::Msg& m, Json::Value& r)
	{
		playerDataPtr player = player_mgr.getPlayer(m.playerID);
		if (!player)Return(r, err_illedge);

		if (player->LV() < _config.lv)
		{
			Return(r, err_imperial_exam_lv_limit);
		}
		if (season_sys.getSeason() != SEASON::Winter)
		{
			Return(r, err_imperial_exam_season_error);
		}
		if (player->ImperialExam().state() == imperial::StateTempleComplete)
		{
			Return(r, 5);//�������
		}
		if (player->ImperialExam().state() != imperial::StateTempleIn)
		{
			Return(r, 4);//û�е����ʸ�
		}
		ReadJsonArray;
		int flag = js_msg[0u].asInt();
		if (flag == 1)
		{
			player->ImperialExam().addTempleCorrect(1);
		}
		if (player->ImperialExam().getTempleCorrect() >= _config.must)
		{
			//����÷�
			player->ImperialExam().setTempleGrade();
			player->ImperialExam().setState(imperial::StateTempleComplete);
		}
		//����
		if (player->ImperialExam().state() == imperial::StateTempleComplete)
		{
			int temple_grade = player->ImperialExam().getTempleGrade();
			int country_grade = player->ImperialExam().getCountryGrade();
			if (_temple_rank.find(temple_grade) == _temple_rank.end())
			{
				MultiOrder order;
				order.insert(make_pair(country_grade, player->ID()));
				_temple_rank[temple_grade] = order;
			}
			else
			{
				_temple_rank[temple_grade].insert(make_pair(country_grade, player->ID()));
			}
			int reward_idx = getTempleRewardIdx(temple_grade);
			if (reward_idx != -1)
			{
				player->ImperialExam().setTempleReward(_config.templeReward[reward_idx].box);
			}
			//����ʱ��������ǰ100
			updateTempleRank();
			saveTempleRank();
		}
		r[strMsg][0u] = 0;
		r[strMsg][1u] = _config.must - player->ImperialExam().getTempleCorrect();
		r[strMsg][2u] = player->ImperialExam().state();
		r[strMsg][3u] = player->ImperialExam().getTempleGrade();
	}

	void ImperialExamSystem::reqImperialExamUseCapsule(net::Msg& m, Json::Value& r)
	{
		playerDataPtr player = player_mgr.getPlayer(m.playerID);
		if (!player)Return(r, err_illedge);

		if (player->LV() < _config.lv)
		{
			Return(r, err_imperial_exam_lv_limit);
		}
		if (season_sys.getSeason() != SEASON::Winter)
		{
			Return(r, err_imperial_exam_season_error);
		}
		if (player->ImperialExam().state() != imperial::StateCountryIn)
		{
			Return(r, 6);//�������ԣ��޷�ʹ�ý���
		}
		if (player->ImperialExam().countryState() != imperial::PeddingAnswer)
		{
			Return(r, 7);//����ʹ��ʱ������
		}
		if (_player_event_map.find(player->ID()) == _player_event_map.end() || !_player_event_map[player->ID()])
		{
			Return(r, 3);//�������ڲ�����
		}
		if (_player_event_map[player->ID()]->Type() != imperial::Answer)
		{
			Return(r, 9);//ֻ�д����¼����ܹ�ʹ�ý��ң�
		}
		ReadJsonArray;
		int id = js_msg[0u].asInt();
		int count = 0;
		Json::Value ret_json = Json::arrayValue;
		bool change = true;
		if (id == _config.capsules[0])
		{
			//�޳�����
			count = player->Items().itemNum(id);
			if (count)
			{
				ret_json = handleCountrySubmit(player, 1, 0, 0);
			}
			change = false;
		}
		else if (id == _config.capsules[1])
		{
			//��������
			count = player->Items().itemNum(id);
			if (count)
			{
				ret_json = handleCountrySubmit(player, 1, 0, 0);
			}
			player->ImperialExam().alterCountryCount(-1);//�����Ĳ���������
		}
		else if (id == _config.capsules[2])
		{
			//�ǻ۽���
			count = player->Items().itemNum(id);
			if (count)
			{
				ret_json = handleCountrySubmit(player, 1, 1);
			}
		}
		else if (id == _config.capsules[3])
		{
			//��ԣ����
			count = player->Items().itemNum(id);
			if (count)
			{
				ret_json = handleCountrySubmit(player, 1, 1, 2);
			}
		}
		else
		{
			Return(r, 8);//���ǽ���ID
		}
		if (change)
		{
			player->ImperialExam().setCountryState(imperial::PeddingExam);
		}
		player->Items().removeItem(id);
		r[strMsg][0u] = 0;
		r[strMsg][1u] = ret_json[0u];
		r[strMsg][2u] = ret_json[1u];
		r[strMsg][3u] = ret_json[2u];
		r[strMsg][4u] = ret_json[3u];
	}

	void ImperialExamSystem::reqImperialExamCountryRank(net::Msg& m, Json::Value& r)
	{
		playerDataPtr player = player_mgr.getPlayer(m.playerID);
		if (!player)Return(r, err_illedge);

		if (player->LV() < _config.lv)
		{
			Return(r, err_imperial_exam_lv_limit);
		}
		int rank = -1;
		if (_player_country_rank.find(player->ID()) != _player_country_rank.end()
				&& _player_country_rank_r[_player_country_rank[player->ID()]] == player->ID())
		{
			rank = _player_country_rank[player->ID()];
		}
		r[strMsg][0u] = 0;
		r[strMsg][1u] = rank;
		r[strMsg][2u] = _country_rank_json;
		
	}

	void ImperialExamSystem::reqImperialExamTempleRank(net::Msg& m, Json::Value& r)
	{
		playerDataPtr player = player_mgr.getPlayer(m.playerID);
		if (!player)Return(r, err_illedge);

		if (player->LV() < _config.lv)
		{
			Return(r, err_imperial_exam_lv_limit);
		}
		int rank = -1;
		if (_player_temple_rank.find(player->ID()) != _player_temple_rank.end()
			&& _player_temple_rank_r[_player_temple_rank[player->ID()]] == player->ID())
		{
			rank = _player_temple_rank[player->ID()];
		}
		r[strMsg][0u] = 0;
		r[strMsg][1u] = rank;
		r[strMsg][2u] = _temple_rank_json;
	}

	void ImperialExamSystem::reqImperialExamGetReward(net::Msg& m, Json::Value& r)
	{
		playerDataPtr player = player_mgr.getPlayer(m.playerID);
		if (!player)Return(r, err_illedge);

		if (player->LV() < _config.lv)
		{
			Return(r, err_imperial_exam_lv_limit);
		}
		if (season_sys.getSeason() != SEASON::Winter)
		{
			Return(r, err_imperial_exam_season_error);
		}
		ReadJsonArray;
		int type = js_msg[0u].asInt();
		ActionBoxList list;
		if (type == 100)
		{
			int grade = player->ImperialExam().getCountryGrade();
			int reward_idx = getCountryRewardIdx(grade);
			if (reward_idx == -1 || reward_idx >= _config.countryReward.size())
			{
				Return(r, err_imperial_exam_reward_not_exist);//û����Ӧ�Ľ���
			}
			if (!player->ImperialExam().isExistCountryReward())
			{
				Return(r, err_imperial_exam_reward_has_got);//�����Ѿ���ȡ
			}
			list = _config.countryReward[reward_idx].box.box;
			int res = actionDoBox(player, list, false);
			r[strMsg][0u] = res;
			if (res == res_sucess)
			{
				player->ImperialExam().removeCountryReward();
				r[strMsg][1u] = actionRes();
			}
			else
			{
				r[strMsg][1u] = actionError();
			}
		}
		else
		{
			int grade = player->ImperialExam().getTempleGrade();
			int reward_idx = getTempleRewardIdx(grade);
			if (reward_idx == -1 || reward_idx >= _config.templeReward.size())
			{
				Return(r, err_imperial_exam_reward_not_exist);//û����Ӧ�Ľ���
			}
			if (!player->ImperialExam().isExistTempleReward())
			{
				Return(r, err_imperial_exam_reward_has_got);//�����Ѿ���ȡ
			}
			list = _config.templeReward[reward_idx].box.box;
			int res = actionDoBox(player, list, false);
			r[strMsg][0u] = res;
			if (res == res_sucess)
			{
				player->ImperialExam().removeTempleReward();
				r[strMsg][1u] = actionRes();
			}
			else
			{
				r[strMsg][1u] = actionError();
			}
		}
	}

	int ImperialExamSystem::createGroup(playerDataPtr player, int group_type, int& id)
	{
		int count = player->ImperialExam().getGroupCount(group_type);
		std::map<int, lx::Sequence>::iterator it;
		int rnd;
		switch (group_type)
		{
		case imperial::Answer:
			CREATE_GROUP(_answer_ids, _player_answer_map, _config.answers);
			break;
		case imperial::Suggection:
			CREATE_GROUP(_suggection_ids, _player_suggection_map, _config.suggections);
			break;
		case imperial::Fight:
			CREATE_GROUP(_fight_ids, _player_fight_map, _config.fights);
			break;
		case imperial::Purchase:
			CREATE_GROUP(_purchase_ids, _player_purchase_map, _config.purchases);
			break;
		default:
			return 1;
			break;
		}
		return 0;
	}

	int ImperialExamSystem::createNextTopic(playerDataPtr player, int topic_type, ExamEventPtr& event_ptr)
	{
		imperial::EventType type = imperial::Answer;
		int group_ret, group_id;
		int tc;
		if (topic_type == imperial::Country)
		{
			type = imperial::getRandomType(_config.odds);
			switch (type)
			{
			case imperial::Answer:
				ENSURE_NOT_EMPTY(_player_answer_map);
				player->ImperialExam().alterCountryCount(1);
				break;
			case imperial::Suggection:
				ENSURE_NOT_EMPTY(_player_suggection_map);
				break;
			case imperial::Fight:
				ENSURE_NOT_EMPTY(_player_fight_map);
				break;
			case imperial::Purchase:
				ENSURE_NOT_EMPTY(_player_purchase_map);
				break;
			default:
				return 3;//δ֪����
			}
		}
		else
		{
			ENSURE_NOT_EMPTY(_player_answer_map);
			player->ImperialExam().addTempleCount(1);
		}
		//���������¼�
		switch (type)
		{
		case imperial::Answer:
			CREATE_CONCRETE(_player_answer_map, AnswerSinglePtr);
			break;
		case imperial::Suggection:
			CREATE_CONCRETE(_player_suggection_map, SuggectionSinglePtr);
			break;
		case imperial::Fight:
			CREATE_CONCRETE(_player_fight_map, FightSinglePtr);
			break;
		case imperial::Purchase:
			CREATE_CONCRETE(_player_purchase_map, PurchaseSinglePtr);
			break;
		default:
			return 3;//δ֪����
		}
		return 0;
	}
	
	void ImperialExamSystem::rebuildGroupIds(playerDataPtr player, imperial::EventType type)
	{
		lx::Sequence seq;
		if (type == imperial::Answer)
		{
			for (std::map<int, imperial::AnswerGroup>::iterator it = _config.answers.begin();
				it != _config.answers.end();
				++it)
			{
				seq.push_back(it->first);
			}
			_answer_ids[player->ID()] = seq;
		}
		else if (type == imperial::Suggection)
		{
			for (std::map<int, imperial::SuggectionGroup>::iterator it = _config.suggections.begin();
				it != _config.suggections.end();
				++it)
			{
				seq.push_back(it->first);
			}
			_suggection_ids[player->ID()] = seq;
		}
		else if (type == imperial::Fight)
		{
			for (std::map<int, imperial::FightGroup>::iterator it = _config.fights.begin();
				it != _config.fights.end();
				++it)
			{
				seq.push_back(it->first);
			}
			_fight_ids[player->ID()] = seq;
		}
		else if (type == imperial::Purchase)
		{
			for (std::map<int, imperial::PurchaseGroup>::iterator it = _config.purchases.begin();
				it != _config.purchases.end();
				++it)
			{
				seq.push_back(it->first);
			}
			_purchase_ids[player->ID()] = seq;
		}

	}
	
	Json::Value ImperialExamSystem::handleCountrySubmit(playerDataPtr player, int flag, int action, int times)
	{
		int score = 0;
		if (action == 1)
		{
			ActionBoxList action_box = _player_event_map[player->ID()]->getBox();
			actionDoBox(player, action_box, false);//������Դ
			score = _player_event_map[player->ID()]->getGrade(flag);
			score *= times;
			player->ImperialExam().alterCountryGrade(score);
			if (_player_event_map[player->ID()]->Type() == imperial::Answer)
			{
				//�������
				if (flag == 1)
				{
					player->ImperialExam().addCountryCorrect(1);
					if (player->ImperialExam().getCountryCorrect() == _config.cont)
					{
						///����������
						randomCapsule(player);
						player->ImperialExam().resetCountryCorrect();
					}
				}
				else
				{
					player->ImperialExam().resetCountryCorrect();
				}
			}
		}
		int new_grade = player->ImperialExam().getCountryGrade();
		int temple_flag = 0;
		if (new_grade >= _config.grade)
		{
			player->ImperialExam().addTimeRestCountryGrade(_config.timeScores);
			temple_flag = 1;
		}
		
		int next_flag = player->ImperialExam().getCountryCount() >= _config.size ? 1 : 0;
		///�������ˣ�ȡ��ʱ�������֪ͨ��ʱ��
		if (temple_flag)
		{
			player->ImperialExam().setState(imperial::StateTempleIn);
			player->ImperialExam().delTimer();
		}
		//û����һ��ͷ�������
		if (!next_flag && !temple_flag)
		{

			player->ImperialExam().setState(imperial::StateCountryOut);
			player->ImperialExam().delTimer();
		}
		Json::Value ret_json = Json::arrayValue;
		ret_json[0u] = new_grade;
		ret_json[1u] = temple_flag;
		ret_json[2u] = next_flag;
		ret_json[3u] = player->ImperialExam().state();
		return ret_json;
	}

	void ImperialExamSystem::randomCapsule(playerDataPtr player)
	{
		int rnd = lx::utility_lx::getProbIndex(_config.kOdds, _config.kOdds.back());
		if (player->Items().canAddItem(_config.capsules[rnd]))
		{
			player->Items().addItem(_config.capsules[rnd]);
		}
		Json::Value set = capsuleInfo(player);
		///���Ͼ����Э��
		player_mgr.sendToPlayer(player->ID(), 2, set);
	}

	Json::Value ImperialExamSystem::capsuleInfo(playerDataPtr player)
	{
		Json::Value set = Json::arrayValue;
		unsigned idx = 0;
		for (int i = 0; i < _config.capsules.size(); ++i)
		{
			Json::Value single = Json::arrayValue;
			int count = player->Items().itemNum(_config.capsules[i]);
			single[0u] = _config.capsules[i];
			single[1u] = count;
			set[idx++] = single;
		}
		return set;
	}
	
	void ImperialExamSystem::initRank()
	{
		_country_rank_json = Json::arrayValue;
		_temple_rank_json = Json::arrayValue;
		for (int i = 0; i < _config.rankNum; ++i)
		{
			imperial::PlayerInfo info;
			info.rank = i + 1;
			info.pid = -1;
			info.grade = -1;
			info.name = "";
			info.jsonBox = Json::nullValue;
			_country_rank_info.push_back(info);
			_temple_rank_info.push_back(info);
			_country_rank_json.append(Json::arrayValue);
			_temple_rank_json.append(Json::arrayValue);
		}
	}

	void ImperialExamSystem::updateCountryRank()
	{
		MultiOrder::iterator it = _country_rank.begin();
		unsigned idx = 0;
		std::vector<int> records;
		for (;it != _country_rank.end(); ++it)
		{
			if (idx >= _country_rank_info.size())
			{
				break;
			}
			playerDataPtr player;
			if (_country_rank_info[idx].pid == -1 || _country_rank_info[idx].pid != it->second)
			{
				//δ������//�����Ѿ����
				player = player_mgr.getPlayer(it->second);
				if (player)
				{
					_country_rank_info[idx].pid = player->ID();
					_country_rank_info[idx].rank = idx + 1;
					_country_rank_info[idx].grade = player->ImperialExam().getCountryGrade();
					_country_rank_info[idx].name = player->Name();
					_country_rank_info[idx].jsonBox = _config.countryRankReward[idx].jsonBox;

					_player_country_rank[_country_rank_info[idx].pid] = idx + 1;
					_player_country_rank_r[idx + 1] = _country_rank_info[idx].pid;
				}
				records.push_back(idx);//��¼������±�
			}
			++idx;
		}
		//���±䶯��������������
		for (int i = 0; i < records.size(); ++i)
		{
			_country_rank_json[records[i]][0u] = _country_rank_info[records[i]].rank;
			_country_rank_json[records[i]][1u] = _country_rank_info[records[i]].name;
			_country_rank_json[records[i]][2u] = _country_rank_info[records[i]].grade;
			_country_rank_json[records[i]][3u] = _country_rank_info[records[i]].jsonBox;
		}
	}

	void ImperialExamSystem::updateTempleRank()
	{
		std::map<int, MultiOrder >::iterator fit = _temple_rank.begin();
		unsigned idx = 0;
		std::vector<int> records;
		bool exist_flag = false;
		for (;fit != _temple_rank.end(); ++fit)
		{
			if (exist_flag == true)
			{
				break;
			}
			for (MultiOrder::iterator it = fit->second.begin(); it != fit->second.end(); ++it)
			{
				if (idx >= _temple_rank_info.size())
				{
					exist_flag = true;
					break;
				}
				playerDataPtr player;
				if (_temple_rank_info[idx].pid == -1 || _temple_rank_info[idx].pid != it->second)
				{
					//δ������//�����Ѿ����
					player = player_mgr.getPlayer(it->second);
					if (player)
					{
						_temple_rank_info[idx].pid = player->ID();
						_temple_rank_info[idx].rank = idx + 1;
						_temple_rank_info[idx].grade = player->ImperialExam().getTempleGrade();
						_temple_rank_info[idx].name = player->Name();
						_temple_rank_info[idx].jsonBox = _config.countryRankReward[idx].jsonBox;

						_player_temple_rank[_temple_rank_info[idx].pid] = idx + 1;
						_player_temple_rank_r[idx + 1] = _temple_rank_info[idx].pid;
					}
					records.push_back(idx);//��¼������±�
				}
				++idx;
			}
		}
		//���±䶯��������������
		for (int i = 0; i < records.size(); ++i)
		{
			_temple_rank_json[records[i]][0u] = _temple_rank_info[records[i]].rank;
			_temple_rank_json[records[i]][1u] = _temple_rank_info[records[i]].name;
			_temple_rank_json[records[i]][2u] = _temple_rank_info[records[i]].grade;
			_temple_rank_json[records[i]][3u] = _temple_rank_info[records[i]].jsonBox;
		}
	}
	
	void ImperialExamSystem::saveCountryRank()
	{
		mongo::BSONObj key = BSON(strExamID << _id);

		mongo::BSONArrayBuilder set;
		int rank = 1;
		for (MultiOrder::iterator it = _country_rank.begin(); it != _country_rank.end(); ++it)
		{
			mongo::BSONArrayBuilder single;
			single << rank << it->first << it->second;
			set << single.arr();
			++rank;
		}

		mongo::BSONObj obj = BSON(strExamID << _id
			<< strRank << set.arr()
		);

		db_mgr.SaveMongo(DBN::dbSystemImperialExamCountry, key, obj);
	}

	void ImperialExamSystem::saveTempleRank()
	{
		mongo::BSONObj key = BSON(strExamID << _id);

		mongo::BSONArrayBuilder set;
		int rank = 1;
		bool exist_flag = false;
		std::map<int, MultiOrder >::iterator it = _temple_rank.begin();
		for (;it != _temple_rank.end(); ++it)
		{
			if (exist_flag == true)
			{
				break;
			}
			for (MultiOrder::iterator sit = it->second.begin(); sit != it->second.end(); ++sit)
			{
				if (rank > _config.rankNum)
				{
					exist_flag = true;
					break;
				}
				mongo::BSONArrayBuilder single;
				single << rank << it->first << sit->first << sit->second;
				set << single.arr();
				++rank;
			}
		}

		int top = 1;
		mongo::BSONArrayBuilder top_set; 
		exist_flag = false;
		for (;it != _temple_rank.end(); ++it)
		{
			if (exist_flag == true)
			{
				break;
			}
			for (MultiOrder::iterator sit = it->second.begin(); sit != it->second.end(); ++sit)
			{
				if (top > 4)
				{
					exist_flag = true;
					break;
				}
				mongo::BSONArrayBuilder single;
				single << top << it->first << sit->first << sit->second;
				top_set << single.arr();
				++top;
			}
		}

		mongo::BSONObj obj = BSON(strExamID << _id
			<< strRank << set.arr()
		);

		mongo::BSONObj top_obj = BSON(strExamID << _id
			<< strRank << top_set.arr()
		);

		db_mgr.SaveMongo(DBN::dbSystemImperialExamTemple, key, obj);
		db_mgr.SaveMongo(DBN::dbSystemImperialExamTop, key, top_obj);
	}

	void ImperialExamSystem::reset(const structTimer& timerData)
	{
		int size = _top_temple_rank.size();
		std::map<int, TempleOrder >::iterator it = _top_temple_rank.begin();
		while (it != _top_temple_rank.end() && _top_temple_rank.size() > TOP_LOG_NUM)
		{
			_top_temple_rank.erase(it);
			removeTopSet(it->first);
		}
		//�������ǰ���ɼ�
		_top_temple_rank[_id] = _temple_rank;
		
		//������ʷǰ����Ϣ
		int rank = 1;
		bool top_flag = false;
		TopInfo top_infos;
		for (TempleOrder::iterator it = _temple_rank.begin(); it != _temple_rank.end(); ++it)
		{
			if (top_flag == true)
			{
				break;
			}
			for (MultiOrder::iterator sit = it->second.begin(); sit != it->second.end(); ++sit)
			{
				if (rank > TOP_NUM)
				{
					top_flag = true;
					break;
				}
				playerDataPtr player = player_mgr.getPlayer(sit->second);
				if (player)
				{
					imperial::TopPlayerInfo info;
					info.rank = rank;
					info.name = player->Name();
					info.pid = sit->second;
					info.c_grade = sit->first;
					info.t_grade = it->first;
					top_infos[info.rank] = info;
				}

				++rank;
			}
		}
		std::map<int, TopInfo>::iterator tit = _top_rank_info.begin();
		_top_rank_info[_id] = top_infos;
		
		//����������������������
		rank = 1;
		//������������
		for (MultiOrder::iterator it = _country_rank.begin(); it != _country_rank.end(); ++it)
		{
			if (rank > _config.rankNum)
			{
				break;
			}
			playerDataPtr player = player_mgr.getPlayer(it->second);
			if (player && rank <= _config.countryRankReward.size())
			{
				EmailPtr e = email_sys.createPackage(EmailDef::ImperialCountryRankReward, Json::nullValue, _config.countryRankReward[rank - 1].jsonBox);
				email_sys.sendToPlayer(player->ID(), e);
			}
			++rank;
		}
		top_flag = false;
		rank = 1;
		//������������
		for (TempleOrder::iterator it = _temple_rank.begin(); it != _temple_rank.end(); ++it)
		{
			if (top_flag = true)
			{
				break;
			}
			for (MultiOrder::iterator sit = it->second.begin(); sit != it->second.end(); ++sit)
			{
				if (rank > _config.rankNum)
				{
					top_flag = true;
					break;
				}
				playerDataPtr player = player_mgr.getPlayer(sit->second);
				if (player && rank <= _config.templeRankReward.size())
				{
					EmailPtr e = email_sys.createPackage(EmailDef::ImperialTempleRankReward, Json::nullValue, _config.templeRankReward[rank-1].jsonBox);
					email_sys.sendToPlayer(player->ID(), e);
				}
				++rank;
			}
		}
		
		//���������
		db_mgr.RemoveCollection(DBN::dbSystemImperialExamCountry, BSON(strExamID << _id));
		db_mgr.RemoveCollection(DBN::dbSystemImperialExamTemple, BSON(strExamID << _id));
		//ID����
		++_id;
		_country_rank.clear();
		_temple_rank.clear();
		_country_rank_info.clear();
		_temple_rank_info.clear();
		_player_country_rank.clear();
		_player_temple_rank.clear();
		_player_country_rank_r.clear();
		_player_temple_rank_r.clear();
		_country_rank_json.clear();
		_temple_rank_json.clear();

		unsigned next = Common::gameTime();

		//���Ӷ�ʱ��
		next = season_sys.getNSTime(SEASON::Winter) + DAY;
		Timer::AddEventTickTime(boostBind(ImperialExamSystem::reset, _1), Inter::event_imperial_exam_reset, next);

		//��������
		mongo::BSONObj key = BSON("id" << 1);
		mongo::BSONObj obj = BSON("id" << 1
			<< strExamID << _id
			<< strTime << next
		);
		//�����һ�α��治�ɹ�����ô�����������
		db_mgr.SaveMongo(DBN::dbSystemImperialExamSelf, key, obj);
	}

	void ImperialExamSystem::removeTopSet(int eid)
	{
		mongo::BSONObj key = BSON(strExamID << eid);

		db_mgr.RemoveCollection(DBN::dbSystemImperialExamTop, key);
	}

	int ImperialExamSystem::getCountryRewardIdx(int grade)
	{
		int idx = -1;
		for (int i = 0; i < _config.countryGradeSection.size(); ++i)
		{
			if (_config.countryGradeSection[i].size() != 2)
			{
				continue;
			}
			if (grade >= _config.countryGradeSection[i][0u]
				&& grade <= _config.countryGradeSection[i][1u])
			{
				idx = i;
				break;
			}
		}
		return idx;
	}

	int ImperialExamSystem::getTempleRewardIdx(int grade)
	{
		int idx = -1;
		for (int i = 0; i < _config.templeGradeSection.size(); ++i)
		{
			if (_config.templeGradeSection[i].size() != 2)
			{
				continue;
			}
			if (grade >= _config.templeGradeSection[i][0u]
				&& grade <= _config.templeGradeSection[i][1u])
			{
				idx = i;
				break;
			}
		}
		return idx;
	}

	imperial::GradeReward ImperialExamSystem::getCountryReward(int grade)
	{
		imperial::GradeReward reward;
		reward.idx = -1;
		for (int i = 0; i < _config.countryGradeSection.size(); ++i)
		{
			if (_config.countryGradeSection[i].size() != 2)
			{
				continue;
			}
			if (grade >= _config.countryGradeSection[i][0u]
				&& grade <= _config.countryGradeSection[i][1u])
			{
				reward = _config.countryReward[i];
				break;
			}
		}
		return reward;
	}

	imperial::GradeReward ImperialExamSystem::getTempleReward(int grade)
	{
		imperial::GradeReward reward;
		reward.idx = -1;
		for (int i = 0; i < _config.templeGradeSection.size(); ++i)
		{
			if (_config.templeGradeSection[i].size() != 2)
			{
				continue;
			}
			if (grade >= _config.templeGradeSection[i][0u]
				&& grade <= _config.templeGradeSection[i][1u])
			{
				reward = _config.templeReward[i];
				break;
			}
		}
		return reward;
	}

	void ImperialExamSystem::loadData()
	{
		//�ƾ�������Ϣ
		unsigned now = Common::gameTime();
		objCollection objs = db_mgr.Query(DBN::dbSystemImperialExamSelf);
		ForEachC(objCollection, it, objs)
		{
			const mongo::BSONObj& obj = (*it);
			unsigned time = obj[strTime].Int();//��ʱ����Ӧ��ִ�е�ʱ��
			_id = obj[strExamID].Int();
			if (now >= time)
			{
				Timer::AddEventTickTime(boostBind(ImperialExamSystem::reset, _1), Inter::event_imperial_exam_reset, now);
			}
			else
			{
				unsigned next = season_sys.getNSTime(SEASON::Winter);
				Timer::AddEventTickTime(boostBind(ImperialExamSystem::reset, _1), Inter::event_imperial_exam_reset, next);
			}
		}
		if (_id == 0)
		{
			Timer::AddEventTickTime(boostBind(ImperialExamSystem::reset, _1), Inter::event_imperial_exam_reset, now);
		}

		//country
		objCollection objs1 = db_mgr.Query(DBN::dbSystemImperialExamCountry);
		ForEachC(objCollection, it, objs1)
		{
			const mongo::BSONObj& obj = (*it);
			int eid = obj[strExamID].Int();
			if (eid == _id)
			{
				//��������
				std::map<int, lx::Sequence> rank_list;
				std::vector<mongo::BSONElement> set = obj[strRank].Array();
				for (int i = 0; i < set.size(); ++i)
				{
					std::vector<mongo::BSONElement> single = set[i].Array();
					if (single.size() != 3)
					{
						continue;
					}
					int rank = single[0u].Int();
					int grade = single[1u].Int();
					int pid = single[2u].Int();
					lx::Sequence seq;
					seq.push_back(grade);
					seq.push_back(pid);
					rank_list[rank] = seq;
				}
				//�ָ�
				for (std::map<int, lx::Sequence>::iterator it = rank_list.begin();
					it != rank_list.end();
					++it)
				{
					_country_rank.insert(make_pair(it->second[0u],it->second[1u]));
				}
				break;
			}
		}

		//temple
		objCollection objs2 = db_mgr.Query(DBN::dbSystemImperialExamTemple);
		ForEachC(objCollection, it, objs2)
		{
			const mongo::BSONObj& obj = (*it);
			int eid = obj[strExamID].Int();
			if (eid == _id)
			{
				//��������
				std::map<int, lx::Sequence> rank_list;
				std::vector<mongo::BSONElement> set = obj[strRank].Array();
				for (int i = 0; i < set.size(); ++i)
				{
					std::vector<mongo::BSONElement> single = set[i].Array();
					if (single.size() != 4)
					{
						continue;
					}
					int rank = single[0u].Int();
					int t_grade = single[1u].Int();
					int c_grade = single[2u].Int();
					int pid = single[3u].Int();
					lx::Sequence seq;
					seq.push_back(t_grade);
					seq.push_back(c_grade);
					seq.push_back(pid);
					rank_list[rank] = seq;
				}
				//�ָ�
				for (std::map<int, lx::Sequence>::iterator it = rank_list.begin();
					it != rank_list.end();
					++it)
				{
					if (_temple_rank.find(it->second[0u]) == _temple_rank.end())
					{
						MultiOrder order;
						order.insert(make_pair(it->second[1u], it->second[2u]));
						_temple_rank[it->second[0u]] = order;
					}
					else
					{
						_temple_rank[it->second[0u]].insert(make_pair(it->second[1u], it->second[2u]));
					}
				}
				break;
			}
		}

		//top
		objCollection objs3 = db_mgr.Query(DBN::dbSystemImperialExamTop);
		ForEachC(objCollection, it, objs3)
		{
			const mongo::BSONObj& obj = (*it);
			int eid = obj[strExamID].Int();
			std::map<int, lx::Sequence> rank_list;
			std::vector<mongo::BSONElement> set = obj[strRank].Array();
			for (int i = 0; i < set.size(); ++i)
			{
				std::vector<mongo::BSONElement> single = set[i].Array();
				if (single.size() != 4)
				{
					continue;
				}
				int rank = single[0u].Int();
				int t_grade = single[1u].Int();
				int c_grade = single[2u].Int();
				int pid = single[3u].Int();
				lx::Sequence seq;
				seq.push_back(t_grade);
				seq.push_back(c_grade);
				seq.push_back(pid);
				rank_list[rank] = seq;
			}
			//�ָ�
			TempleOrder temple_rank;
			for (std::map<int, lx::Sequence>::iterator it = rank_list.begin();
				it != rank_list.end();
				++it)
			{
				if (temple_rank.find(it->second[0u]) == temple_rank.end())
				{
					MultiOrder order;
					order.insert(make_pair(it->second[1u], it->second[2u]));
					temple_rank[it->second[0u]] = order;
				}
				else
				{
					temple_rank[it->second[0u]].insert(make_pair(it->second[1u], it->second[2u]));
				}
			}
			_top_temple_rank[eid] = temple_rank;
		}
		//�ָ���ʷǰ������
		//(��������Ӵ�С������)
		std::map<int, TempleOrder >::reverse_iterator it = _top_temple_rank.rbegin();
		int count = 1;
		//it->first is eid;
		for (; it != _top_temple_rank.rend(); ++it)
		{
			if (count > TOP_LOG_NUM)
			{
				break;
			}
			TempleOrder::iterator sit = it->second.begin();
			int rank = 1;
			bool in_flag = false;
			TopInfo top_infos;
			for (;sit != it->second.end(); ++sit)
			{
				if (in_flag == true)
				{
					break;
				}
				for (MultiOrder::iterator tit = sit->second.begin();tit != sit->second.end(); ++tit)
				{
					if (rank > TOP_NUM)
					{
						in_flag = true;//Ӧ���˳���
						break;
					}
					playerDataPtr player = player_mgr.getPlayer(tit->second);
					if (player)
					{
						imperial::TopPlayerInfo info;
						info.rank = rank;
						info.name = player->Name();
						info.pid = tit->second;
						info.c_grade = tit->first;
						info.t_grade = sit->first;
						top_infos[info.rank] = info;
					}
					++rank;
				}
			}
			_top_rank_info[it->first] = top_infos;//
			++count;
		}
	}

	void ImperialExamSystem::initData()
	{}
}

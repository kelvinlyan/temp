#include "red_paper_system.h"
#include "email_system.h"
#include "chat.h"

const static std::string strLocalID = "li";//�������ID
const static std::string strItemID = "ii";//�������ID
const static std::string strCash = "cr";//ʣ����/��ȡ���
const static std::string strNum = "nr";//ʣ����ȡ����
const static std::string strDate = "dt";//�����������
const static std::string strName = "pn";//�������
const static std::string strRobberID = "rpi";//���ID/��ȡ��ID
const static std::string strChannel = "ch";//�������
const static std::string strResType = "rt";//��Դ����
const static std::string strDelete = "de";//ɾ����־
const static std::string strFaceID = "fi";//
const static std::string strNationID = "ni";//
const static std::string strReceiverID = "rc";//
const static std::string strTotalCash = "tc";
const static std::string strTotalNum = "tn";

const static std::string strActiID = "ai";
const static std::string strActivityContent = "ac";
const static std::string strSTime = "st";
const static std::string strETime = "et";

namespace gg
{

	static bool is_time_overlap(unsigned begin_n, unsigned end_n, unsigned begin_o, unsigned end_o)
	{
		//LogS << begin_n << "--" << end_n << "--" << begin_o << "--" << end_o << LogEnd;
		if (begin_n <= begin_o && end_n >= begin_o
			|| begin_n >= begin_o && end_n <= end_o
			|| begin_n <= end_o && end_n >= end_o
			|| begin_n <= begin_o && end_n >= end_o)
		{
			return true;
		}
		return false;
	}

	red_paper_system* const red_paper_system::_Instance = new red_paper_system();
	int red_paper_system::_local_id = 0;
	red_paper_system::TimerIdsMap red_paper_system::_timer_ids_map;
	RedPaperSet red_paper_system::_paper_player_set;
	RobberPlayerSet red_paper_system::_robber_player_set;
	ActivityCompleteList red_paper_system::sys_activity_config;
	MultiRedPaperList red_paper_system::_paper_player_list;

	red_paper_system::red_paper_system()
	{
	}

	//safety
	void red_paper_system::reqSendRedPaper(net::Msg& m, Json::Value& r)
	{
		playerDataPtr player = player_mgr.getPlayer(m.playerID);
		if (!player)Return(r, err_illedge);

		//�ȼ���֤
		if (player->LV() < RED_PAPER_LEVEL_LIMIT)
		{
			Return(r, err_paper_under_the_lv);
		}

		ReadJsonArray;
		int paper_id = js_msg[0].asInt();
		//��֤���ID��Ч��//��֤˽�˺���û���Ч��//������֤
		RawRedPaperPtrList::iterator it = _raw_paper_list.find(paper_id);
		if (it == _raw_paper_list.end())
		{
			Return(r, err_paper_id_not_exist);
		}
		if (it->second->channel == red_paper::channel::Country
			&& player->Info().NationIDX() == Kingdom::nation_invaild_idx)
		{
			Return(r, err_paper_conutry_limit);
		}
		playerDataPtr to_player;
		if (it->second->channel == red_paper::channel::Person)
		{
			if (js_msg.size() == 2 && js_msg[1].isString())
			{
				to_player = player_mgr.getPlayer(js_msg[1].asString());
			}
			if (!to_player)Return(r, err_paper_send_private_name_wrong);
			if (to_player->LV() < RED_PAPER_LEVEL_LIMIT) Return(r, err_paper_private_lv_not_enough);
			if (to_player->ID() == player->ID()) { Return(r, err_paper_private_selt_not_allow); }
		}
		//��ѯ������ݵõ����
		int item_num = player->Items().itemNum(paper_id);
		if (item_num < 1)
		{
			Return(r, err_paper_out_of_capacity);
		}
		//������local_id
		int local_id = player->RedPaper().getPaperCount();
		red_paper::UnitPaperPtr paper_ptr = Creator<red_paper::UnitPaper>::Create();
		paper_ptr->player_id = player->ID();
		paper_ptr->local_id = local_id;
		paper_ptr->player_name = player->Name();
		paper_ptr->face_id = player->Info().Face();
		paper_ptr->date = Common::gameTime();
		paper_ptr->nation = player->Info().NationIDX();
		if (it->second->channel == red_paper::channel::Person)
		{
			paper_ptr->receiver_id = to_player->ID();
		}
		red_paper::RedPaperPtr paper = Creator<red_paper::RedPaper>::Create();
		paper_ptr->raw_paper = paper;
		paper_ptr->raw_paper->id = it->second->id;//
		paper_ptr->raw_paper->res_type = it->second->res_type;
		paper_ptr->raw_paper->channel = it->second->channel;
		paper_ptr->raw_paper->cash = it->second->cash;
		paper_ptr->raw_paper->num = it->second->num;
		paper_ptr->raw_paper->total_cash = it->second->total_cash;
		paper_ptr->raw_paper->total_num = it->second->total_num;
		if (!auto_db(paper_ptr))
		{
			Return(r, err_paper_send_failed);
		}
		//��������ӵ�������
		{

			RedPaperSet::iterator pit = _paper_player_set.find(player->ID());
			if (pit == _paper_player_set.end())
			{
				RedPaperList list;
				list[local_id] = paper_ptr;
				_paper_player_set[player->ID()] = list;
			}
			else
			{
				_paper_player_set[player->ID()][local_id] = paper_ptr;
			}
			_paper_player_list.insert(make_pair(paper_ptr->date, paper_ptr));
		}
		//���ӵ���ʱ��
		if (_raw_s_paper_list.find(paper_ptr->raw_paper->id) == _raw_s_paper_list.end())
		{
			paper_ptr->timer = Timer::AddEventTickTime(boostBind(red_paper_system::settle, _1, paper_ptr), Inter::event_red_paper_settle, paper_ptr->date + EXPIRATION);
		}
		//LogS << "red paper\taction:send\t" << player->Name() << "\tItemID:" << it->second->id << "\tcash:" << paper_ptr->raw_paper->cash << "\tnum:" << paper_ptr->raw_paper->num << LogEnd;
		//�ɹ����ͣ�����������м�ȥ��Ӧ���
		player->Items().removeItem(paper_id);
		//���º�����͵��������
		{
			Json::Value latest = Json::arrayValue;
			latest[0u] = player->ID();
			latest[1u] = player->Name();
			latest[2u] = paper_ptr->local_id;
			latest[3u] = paper_ptr->raw_paper->channel;
			latest[4u] = paper_ptr->raw_paper->total_cash;
			latest[5u] = paper_ptr->raw_paper->num;
			latest[6u] = paper_ptr->face_id;
			latest[7u] = 1;
			latest[8u] = 1;
			Json::Value ret_json;
			ret_json[strMsg][0] = 0;
			ret_json[strMsg][1] = 1;
			ret_json[strMsg][2] = latest;
			switch (paper_ptr->raw_paper->channel)
			{
			case red_paper::channel::World:
				player_mgr.sendToAll(gate_client::req_paper_new_update_resp, ret_json);
				break;
			case red_paper::channel::Country:
				player_mgr.sendToKingdom(player->Info().Nation(), gate_client::req_paper_new_update_resp, ret_json);
				break;
			case red_paper::channel::Person:
				player_mgr.sendToPlayer(to_player->ID(), gate_client::req_paper_new_update_resp, ret_json);
				break;
			default:
				break;
			}
		}
		//���Log
		Log(DBLOG::strLogRedPaperSystem, player, 0, it->second->id, 1);
		Return(r, res_sucess);
	}

	void red_paper_system::reqOpenRedPaper(net::Msg& m, Json::Value& r)
	{
		playerDataPtr player = player_mgr.getPlayer(m.playerID);
		if (!player)Return(r, err_illedge);

		//�ȼ���֤
		if (player->LV() < RED_PAPER_LEVEL_LIMIT)
		{
			Return(r, err_paper_under_the_lv);
		}

		ReadJsonArray;
		int robbedID = js_msg[0].asInt();
		int local_id = js_msg[1].asInt();
		playerDataPtr robbed_player;
		if (robbedID != SYS_PLAYER_ID)
		{
			robbed_player = player_mgr.getPlayer(robbedID);
			if (!robbed_player)Return(r, err_param_error);
		}

		//����Ƿ���ȡͬһ���
		bool is_open = player->RedPaper().isOpenable(robbedID, local_id);
		if (!is_open)
		{
			Return(r, err_paper_get_again_forbidden);
		}

		RedPaperSet::iterator sit = _paper_player_set.find(robbedID);
		if (sit == _paper_player_set.end())
		{
			Return(r, err_paper_id_not_exist);
		}
		RedPaperList::iterator lit = sit->second.find(local_id);//�ҵ������͵ĺ��
		if (lit == sit->second.end())
		{
			Return(r, err_paper_id_not_exist);
		}
		//�Ѿ����ڣ�
		unsigned now = Common::gameTime();
		if (now - lit->second->date > EXPIRATION)
		{
			Return(r, err_red_paper_eliminate);
		}
		//���Һ����
		if (lit->second->raw_paper->channel == red_paper::channel::Country
			&& (lit->second->nation != player->Info().Nation()
				|| player->Info().NationIDX() == Kingdom::nation_invaild_idx))
		{
			Return(r, err_paper_conutry_limit);//δ������һ��߹��Ҳ�ͬ
		}
		if (lit->second->raw_paper->num < 1)
		{
			Return(r, err_paper_out_of_count);
		}
		int res = getRobCash(lit->second->raw_paper->cash, lit->second->raw_paper->num);
		r[strMsg][0u] = 0;
		r[strMsg][1u] = res;
		--lit->second->raw_paper->num;
		lit->second->raw_paper->cash -= res;
		if (lit->second->raw_paper->num < 1 && lit->second->timer)
		{
			lit->second->timer->delTimer();
			lit->second->timer = ptrTimerIdentify();
		}
		if (!auto_db(lit->second))
		{
			//����
			++lit->second->raw_paper->num;
			lit->second->raw_paper->cash += res;
			Return(r, err_paper_open_failed);//���ݿ����/δ֪����
		}
		if (lit->second->raw_paper->num < 1)
		{
			delRedPaper(lit->second);
		}

		//���ӵ������Դ��
		{
			switch (lit->second->raw_paper->res_type)
			{
			case ACTION::gold:
				player->Res().alterGold(res);
				break;
			case ACTION::ticket:
				player->Res().alterTicket(res);
				break;
			case ACTION::cash:
				player->Res().alterCash(res);
				break;
			default:
				break;
			}
		}
		//������ȡ��¼
		{
			red_paper::RobberPtr robber_ptr = Creator<red_paper::Robber>::Create();
			robber_ptr->date = Common::gameTime();
			robber_ptr->nickname = player->Name();
			robber_ptr->senderID = lit->second->player_id;
			robber_ptr->local_id = lit->second->local_id;
			robber_ptr->cash = res;
			robber_ptr->face_Id = player->Info().Face();
			robber_ptr->robberID = player->ID();
			RobberPlayerSet::iterator ro_it = _robber_player_set.find(robbedID);
			if (ro_it == _robber_player_set.end())
			{
				red_paper::RobberPlayerList robber_list;
				red_paper::RobberVec vec;
				robber_list[local_id] = vec;
				_robber_player_set[robbedID] = robber_list;
			}
			else if (ro_it->second.find(local_id) == ro_it->second.end())
			{
				red_paper::RobberVec vec;
				ro_it->second[local_id] = vec;
			}
			_robber_player_set[robbedID][local_id].push_back(robber_ptr);
		}
		save_robber(robbedID, lit->second->local_id);

		//���䶯���͵��������
		{
			Json::Value latest = Json::arrayValue;
			latest[0u] = robbedID;
			latest[1u] = lit->second->player_name;
			latest[2u] = lit->second->local_id;
			latest[3u] = lit->second->raw_paper->channel;
			latest[4u] = lit->second->raw_paper->total_cash;
			latest[5u] = lit->second->raw_paper->num;
			latest[6u] = lit->second->face_id;
			latest[7u] = 2;
			latest[8u] = now - lit->second->date > EXPIRATION ? 0 : 1;
			Json::Value ret_json;
			ret_json[strMsg][0u] = 0;
			ret_json[strMsg][1u] = 2;
			ret_json[strMsg][2u] = latest;
			switch (lit->second->raw_paper->channel)
			{
			case red_paper::channel::SYS_World:
			case red_paper::channel::World:
				player_mgr.sendToAll(gate_client::req_paper_new_update_resp, ret_json);
				break;
			case red_paper::channel::Country:
				player_mgr.sendToKingdom((Kingdom::NATION)lit->second->nation, gate_client::req_paper_new_update_resp, ret_json);
				break;
			case red_paper::channel::SYS_Country:
			case red_paper::channel::SYS_Shu:
			case red_paper::channel::SYS_Wei:
			case red_paper::channel::SYS_Wu:
				player_mgr.sendToKingdom((Kingdom::NATION)lit->second->nation, gate_client::req_paper_new_update_resp, ret_json);
				break;
			case red_paper::channel::Person:
				player_mgr.sendToPlayer(player->ID(), gate_client::req_paper_new_update_resp, ret_json);
				break;
			default:
				break;
			}
		}

		player->RedPaper().addRobbedLog(lit->second->local_id, robbedID, lit->second->date);
		//��ˮ
		Log(DBLOG::strLogRedPaperSystem, player, 1, lit->second->raw_paper->id, robbedID, res);
	}
	
	//safety-pass
	void red_paper_system::reqInfoRedPaper(net::Msg& m, Json::Value& r)
	{
		playerDataPtr player = player_mgr.getPlayer(m.playerID);
		if (!player)Return(r, err_illedge);

		//�ȼ���֤
		if (player->LV() < RED_PAPER_LEVEL_LIMIT)
		{
			Return(r, err_paper_under_the_lv);
		}

		Json::Value info = Json::arrayValue;
		getPaperInfo(info, player);
		r[strMsg][0u] = 0;
		r[strMsg][1u] = info;
	}

	//safety-pass
	void red_paper_system::reqDelHistoryRedPaper(net::Msg& m, Json::Value& r)
	{
		playerDataPtr player = player_mgr.getPlayer(m.playerID);
		if (!player)Return(r, err_illedge);

		//�ȼ���֤
		if (player->LV() < RED_PAPER_LEVEL_LIMIT)
		{
			Return(r, err_paper_under_the_lv);
		}

		ReadJsonArray;
		int local_id = js_msg[0u].asInt();
		int playerID = js_msg[1u].asInt();
		playerDataPtr robbed_player;
		if (playerID != SYS_PLAYER_ID)
		{
			robbed_player = player_mgr.getPlayer(playerID);
			if (!robbed_player) Return(r, err_param_error);
		}
		if (_paper_player_set.find(playerID) != _paper_player_set.end()
			&& _paper_player_set[playerID].find(local_id) != _paper_player_set[playerID].end())
		{
			player->RedPaper().addDelLog(playerID, local_id, _paper_player_set[playerID][local_id]->date);
			Return(r, res_sucess);
		}
		Return(r, err_param_error);

	}

	//safety
	void red_paper_system::reqRobInfo(net::Msg& m, Json::Value& r)
	{
		playerDataPtr player = player_mgr.getPlayer(m.playerID);
		if (!player)Return(r, err_illedge);

		//�ȼ���֤
		if (player->LV() < RED_PAPER_LEVEL_LIMIT)
		{
			Return(r, err_paper_under_the_lv);
		}

		ReadJsonArray;
		int playerID = js_msg[0u].asInt();
		int local_id = js_msg[1u].asInt();
		playerDataPtr robbed_player;
		if (playerID != SYS_PLAYER_ID)
		{
			robbed_player = player_mgr.getPlayer(playerID);
			if (!robbed_player) Return(r, err_param_error);
		}
		//LogS << "red paper\taction:rob info\t" << player->Name() << "\t:-:" << (!robbed_player ? "SYSTEM" : robbed_player->Name()) << "\tlocal_id:" << local_id << LogEnd;
		if (_paper_player_set.find(playerID) != _paper_player_set.end()
			&& _paper_player_set[playerID].find(local_id) != _paper_player_set[playerID].end())
		{
			Json::Value info = Json::arrayValue;
			unsigned idx = 0u;
			bool is_exist = false;
			if (_robber_player_set.find(playerID) != _robber_player_set.end()
				&& _robber_player_set[playerID].find(local_id) != _robber_player_set[playerID].end())
			{
				for (int i = 0; i < _robber_player_set[playerID][local_id].size(); ++i)
				{
					Json::Value unit = Json::arrayValue;
					unit[0u] = _robber_player_set[playerID][local_id][i]->robberID;
					unit[1u] = _robber_player_set[playerID][local_id][i]->nickname;
					unit[2u] = _robber_player_set[playerID][local_id][i]->face_Id;
					unit[3u] = _robber_player_set[playerID][local_id][i]->cash;
					unit[4u] = Common::toStampTime(_robber_player_set[playerID][local_id][i]->date);
					info[idx++] = unit;
				}
				is_exist = true;
			}
			int total_num = _paper_player_set[playerID][local_id]->raw_paper->total_num;
			r[strMsg][0u] = 0;
			r[strMsg][1u] = total_num;
			r[strMsg][2u] = _paper_player_set[playerID][local_id]->raw_paper->num;
			r[strMsg][3u] = _paper_player_set[playerID][local_id]->raw_paper->total_cash;
			r[strMsg][4u] = _paper_player_set[playerID][local_id]->raw_paper->cash;
			if (is_exist = true && _paper_player_set[playerID][local_id]->raw_paper->total_num == _robber_player_set[playerID][local_id].size())
			{
				r[strMsg][5u] = _robber_player_set[playerID][local_id][total_num - 1]->date - _paper_player_set[playerID][local_id]->date;
			}
			else
			{
				r[strMsg][5u] = -1;
			}
			r[strMsg][6u] = info;
		}
		else
		{
			Return(r, err_paper_id_not_exist);
		}
	}

	//safety-pass
	void red_paper_system::reqAssetRedPaper(net::Msg& m, Json::Value& r)
	{
		playerDataPtr player = player_mgr.getPlayer(m.playerID);
		if (!player)Return(r, err_illedge);

		//�ȼ���֤
		if (player->LV() < RED_PAPER_LEVEL_LIMIT)
		{
			Return(r, err_paper_under_the_lv);
		}

		Json::Value ret_json = Json::arrayValue;
		unsigned idx = 0u;
		RawRedPaperPtrList::iterator it = _raw_paper_list.begin();
		for (;it != _raw_paper_list.end(); ++it)
		{
			int count = player->Items().itemNum(it->second->id);
			if (count < 1) continue;
			Json::Value unit = Json::arrayValue;
			unit[0u] = ACTION::item;
			unit[1u] = it->second->id;
			unit[2u] = it->second->channel;
			unit[3u] = it->second->cash;
			unit[4u] = it->second->num;
			unit[5u] = count;
			ret_json[idx++] = unit;
		}
		r[strMsg][0u] = 0;
		r[strMsg][1u] = ret_json;
	}

	//safety-pass
	void red_paper_system::reqPanelTotalRedPaper(net::Msg& m, Json::Value& r)
	{
		playerDataPtr player = player_mgr.getPlayer(m.playerID);
		if (!player)Return(r, err_illedge);

		//�ȼ���֤
		if (player->LV() < RED_PAPER_LEVEL_LIMIT)
		{
			Return(r, err_paper_under_the_lv);
		}

		//ӵ�к����Ϣ
		Json::Value assets = Json::arrayValue;
		unsigned idx = 0u;
		RawRedPaperPtrList::iterator it = _raw_paper_list.begin();
		for (;it != _raw_paper_list.end(); ++it)
		{
			int count = player->Items().itemNum(it->second->id);
			if (count < 1) continue;
			Json::Value unit = Json::arrayValue;
			unit[0u] = it->second->id;
			unit[1u] = it->second->channel;
			unit[2u] = it->second->cash;
			unit[3u] = it->second->num;
			unit[4u] = count;
			assets[idx++] = unit;
		}

		//��Ч�����Ϣ
		Json::Value info = Json::arrayValue;
		getPaperInfo(info, player);
		r[strMsg][0u] = 0;
		r[strMsg][1u] = info;
		r[strMsg][3u] = assets;
	}

	//safety-pass
	void red_paper_system::reqDelete(net::Msg& m, Json::Value& r)
	{
		playerDataPtr player = player_mgr.getPlayer(m.playerID);
		if (!player)Return(r, err_illedge);

		//�ȼ���֤
		if (player->LV() < RED_PAPER_LEVEL_LIMIT)
		{
			Return(r, err_paper_under_the_lv);
		}
		//ɾ��
		MultiRedPaperList::iterator lit = _paper_player_list.find(player->RedPaper().lvDate());
		if (lit == _paper_player_list.end())
		{
			lit = _paper_player_list.begin();
		}
		unsigned now = Common::gameTime();
		for (;lit != _paper_player_list.end(); ++lit)
		{
			if (lit->second->raw_paper->num < 1
				|| !player->RedPaper().isOpenable(lit->second->player_id, lit->second->local_id)
				|| now - lit->second->date >= EXPIRATION)
			{
				player->RedPaper().addDelLog(lit->second->player_id, lit->second->local_id, lit->second->date);
			}
		}
		Json::Value info = Json::arrayValue;
		getPaperInfo(info, player);
		//�����µ������������Ϣ
		r[strMsg][0u] = 0;
		r[strMsg][1u] = info;
	}

	void red_paper_system::getPaperInfo(Json::Value& info, playerDataPtr player)
	{
		if (!player) return;
		//������Ϣ
		unsigned now = Common::gameTime();
		unsigned l = 0u;
		int count = 0;//δ������ĺ��ͳ�Ƹ���
		VID zero_list;//�Ѿ�����ȡ��ĺ��idx�б�
		unsigned limit_date = 1;
		int playerID = -1;
		int local_id = -1;
		player->RedPaper().getLimit(limit_date, playerID, local_id);
		MultiRedPaperList::reverse_iterator uit = _paper_player_list.rbegin();
		for (;uit != _paper_player_list.rend(); ++uit)
		{
			if (uit->second->date == limit_date
				&& uit->second->player_id == playerID
				&& uit->second->local_id == local_id)
			{
				break;
			}
			if ((now > uit->second->date && now - uit->second->date > DEAHLINE)
				|| player->RedPaper().isDel(uit->second->player_id, uit->second->local_id)
				|| !player->RedPaper().isFree(uit->second->date)
				|| (uit->second->raw_paper->channel == red_paper::channel::Country && player->Info().NationIDX() != uit->second->nation)
				|| (uit->second->raw_paper->channel == red_paper::channel::Person && player->ID() != uit->second->receiver_id))
			{
				continue;
			}
			if (zero_list.size() + count < LIST_LIMITATION
				&& (uit->second->raw_paper->num == 0
					|| !player->RedPaper().isOpenable(uit->second->player_id, uit->second->local_id))
				&& (uit->second->raw_paper->channel == red_paper::channel::World
					|| (uit->second->raw_paper->channel == red_paper::channel::Country && player->Info().NationIDX() == uit->second->nation)
					|| (uit->second->raw_paper->channel == red_paper::channel::Person && player->ID() == uit->second->receiver_id)
					)
				)
			{
				HID ele;
				ele.push_back(uit->second->player_id);
				ele.push_back(uit->second->local_id);
				zero_list.push_back(ele);
				continue;
			}
			if (uit->second->raw_paper->num > 0 && player->RedPaper().isOpenable(uit->second->player_id, uit->second->local_id))
			{
				Json::Value unit = Json::arrayValue;
				unit[0u] = uit->second->player_id;
				unit[1u] = uit->second->player_name;
				unit[2u] = uit->second->local_id;
				unit[3u] = uit->second->raw_paper->channel;
				unit[4u] = uit->second->raw_paper->total_cash;
				unit[5u] = uit->second->raw_paper->num;
				unit[6u] = uit->second->face_id;
				unit[7u] = 1;
				unit[8u] = now - uit->second->date > EXPIRATION ? 0 : 1;
				info[l++] = unit;

				++count;
				if (count >= LIST_LIMITATION)
				{
					if (++uit != _paper_player_list.rend())
					{
						player->RedPaper().setLimit(uit->second);
					}
					break;
				}
			}
		}
		if (count < LIST_LIMITATION)
		{
			for (int i = 0; i < zero_list.size(); ++i)
			{
				red_paper::UnitPaperPtr ptr = _paper_player_set[zero_list[i][0u]][zero_list[i][1u]];
				Json::Value unit = Json::arrayValue;
				unit[0u] = ptr->player_id;
				unit[1u] = ptr->player_name;
				unit[2u] = ptr->local_id;
				unit[3u] = ptr->raw_paper->channel;
				unit[4u] = ptr->raw_paper->total_cash;
				unit[5u] = ptr->raw_paper->num;
				unit[6u] = ptr->face_id;
				unit[7u] = player->RedPaper().isOpenable(ptr->player_id, ptr->local_id) == true ? 1 : 0;
				unit[8u] = now - uit->second->date > EXPIRATION ? 0 : 1;
				info[l++] = unit;

				++count;
				if (count >= LIST_LIMITATION)
				{
					break;
				}
			}
		}
		//LogS << "count:" << count << "\tsize:" << zero_list.size() << LogEnd;
	}

	//safety-pass
	void red_paper_system::reqGMRedPaperIdList(net::Msg& m, Json::Value& r)
	{
		unsigned now = Common::gameTime();
		bool is_has = false;
		Json::Value id_list = Json::arrayValue;
		r[strMsg][0u] = -1;
		for (ActivityCompleteList::iterator it = sys_activity_config.begin();
			it != sys_activity_config.end();
			++it)
		{
			if (!is_has && it->second.stime <= now && now <= it->second.etime)
			{
				r[strMsg][0u] = it->second.id;
				is_has = true;
			}
			id_list.append(it->second.id);
		}
		r[strMsg][1u] = id_list;
	}

	//safety-pass
	void red_paper_system::reqGMRedPaperInfo(net::Msg& m, Json::Value& r)
	{
		ReadJsonArray;
		int id = js_msg[0u].asInt();
		ActivityCompleteList::iterator it = sys_activity_config.find(id);
		if (it == sys_activity_config.end())
		{
			Return(r, err_activity_not_found);
		}
		r[strMsg][0u] = id;
		r[strMsg][1u] = it->second.stime == 0 ? 0 : Common::toStampTime(it->second.stime);
		r[strMsg][2u] = it->second.etime == 0 ? 0 : Common::toStampTime(it->second.etime);
		Json::Value activities = Json::arrayValue;
		for (int i = 0; i < it->second.activities.size(); ++i)
		{
			Json::Value acti = Json::arrayValue;
			GMPapers papers;
			acti.append(it->second.activities[i].date == 0 ? 0 : Common::toStampTime(it->second.activities[i].date));
			for (int j = 0; j < it->second.activities[i].papers.size(); ++j)
			{
				if (papers.find(it->second.activities[i].papers[j].id) == papers.end())
				{
					Json::Value paper = Json::arrayValue;
					paper[0u] = it->second.activities[i].papers[j].id;
					paper[1u] = 1;
					papers[it->second.activities[i].papers[j].id] = paper;
				}
				else
				{
					papers[it->second.activities[i].papers[j].id][1u] = papers[it->second.activities[i].papers[j].id][1u].asInt() + 1;
				}
			}
			
			for (GMPapers::iterator it = papers.begin(); it != papers.end(); ++it)
			{
				Json::Value paper = Json::arrayValue;
				paper.append(it->second[0u]);
				paper.append(it->second[1u]);
				acti.append(paper);
			}
			activities.append(acti);
		}
		r[strMsg][3u] = activities;
	}

	//safety-pass
	void red_paper_system::reqGMRedPaperModify(net::Msg& m, Json::Value& r)
	{
		//������Ϣ
		ReadJsonArray;
		int type = js_msg[0u].asInt();
		int id = js_msg[1u].asInt();
		if (id < 1) Return(r, err_invalid_resp_data);
		if (type == 1)
		{
			if (sys_activity_config.find(id) != sys_activity_config.end())
			{
				sys_activity_config.erase(id);
				del_acti(id);
				r[strMsg][0u] = 1;
				if (_timer_ids_map.find(id) != _timer_ids_map.end())
				{
					//ɾ��timerid
					for (int j = 0; j < _timer_ids_map[id].size(); ++j)
					{
						_timer_ids_map[id][j]->delTimer();
					}
				}

			}
			else
			{
				r[strMsg][0u] = 0;
			}
			return;
		}
		unsigned now = Common::gameTime();
		unsigned stime = js_msg[2u].asUInt() == 0 ? 0 : Common::toLocalTime(js_msg[2u].asUInt());
		unsigned etime = js_msg[3u].asUInt() == 0 ? 0 : Common::toLocalTime(js_msg[3u].asUInt());
		if (stime > MAX_TIME || etime > MAX_TIME)
		{
			Return(r, err_param_error);
		}
		if (etime < now || stime >= etime)
		{
			Return(r, err_param_error);
		}
		Json::Value infos = js_msg[4u];
		//LogS << "infos" << infos.toIndentString() << LogEnd;
		red_paper::ActivityComplete complete;
		complete.id = id;
		complete.stime = stime;
		complete.etime = etime;
		for (int i = 0; i < infos.size(); ++i)
		{
			red_paper::ActivityUnit unit;
			Json::Value info = infos[i];
			unsigned date = info[0u].asUInt() == 0 ? 0 : Common::toLocalTime(info[0u].asUInt());
			if (date < stime || date > etime)
			{
				Return(r, err_activity_time_conflict);
			}
			unit.date = date;
			for (int j = 1; j < info.size(); ++j)
			{
				//LogS << "info:" << info[j].toIndentString() << LogEnd;
				if (info[j].size() != 2)
				{
					Return(r, err_param_error);
				}
				red_paper::SpecialRedPaper paper;
				RawRedPaperPtrList::iterator it = _sys_raw_paper_list.find(info[j][0u].asInt());
				if (it == _sys_raw_paper_list.end())
				{
					Return(r, err_paper_id_not_exist);
				}
				paper.id = it->second->id;
				paper.res_type = it->second->res_type;
				paper.type = it->second->channel;
				paper.cash = it->second->cash;
				paper.num = it->second->num;
				for (int i = 0; i < info[j][1u].asInt(); ++i)
				{
					unit.papers.push_back(paper);
				}
			}
			complete.activities.push_back(unit);
		}
		
		//�µĻ�Ƿ񸲸�ԭ�еĻ��(�޸ĻҲ������߼�)
		std::vector<int> records;
		for (ActivityCompleteList::iterator it = sys_activity_config.begin();
			it != sys_activity_config.end();
			++it)
		{
			if (is_time_overlap(complete.stime, complete.etime, it->second.stime, it->second.etime))
			{
				//LogS << "red paper acti time_overlap,complete:" << complete.id << "\texist:" << it->second.id << LogEnd;
				records.push_back(it->first);
			}
		}
		for (int i = 0; i < records.size(); ++i)
		{
			sys_activity_config.erase(records[i]);
			del_acti(records[i]);
			if (_timer_ids_map.find(records[i]) != _timer_ids_map.end())
			{
				//ɾ��timerid
				for (int j = 0; j < _timer_ids_map[records[i]].size(); ++j)
				{
					_timer_ids_map[records[i]][j]->delTimer();
				}
			}
		}
		sys_activity_config[complete.id] = complete;
		if (!save_acti(complete))
		{
			r[strMsg][0u] = 1;
			return;
		}
		start_system_paper(complete);
		r[strMsg][0u] = 0;
	}

	//safety-pass
	int red_paper_system::getRobCash(int rest_cash, int rest_num)
	{
		if (rest_num > rest_cash || rest_num < 1)
		{
			return 0;
		}
		if (rest_num == 1)
		{
			return rest_cash;
		}
		else
		{
			int min = 1;
			int max = rest_cash * 2 / rest_num - 1;
			if (max == 1) return 1;
			int res = Common::randomBetween(min, max);
			//if (res < 1) return 0;
			//if (rest_cash - res <= rest_num - 1)
			//{
			//	res = rest_cash - rest_num;
			//}
			return res;
		}
	}

	//safety-pass
	int red_paper_system::generateLocalPaperId()
	{
		++_local_id;
		save_local_id();
		return _local_id;
	}

	//safety-pass
	void red_paper_system::sendSystemRedPaper(const structTimer& timerData, red_paper::UnitPaperPtr paper)
	{
		if (!paper) return;

		//��������ӵ�������
		{

			RedPaperSet::iterator pit = _paper_player_set.find(SYS_PLAYER_ID);
			if (pit == _paper_player_set.end())
			{
				RedPaperList list;
				list[paper->local_id] = paper;
				_paper_player_set[SYS_PLAYER_ID] = list;
			}
			else
			{
				_paper_player_set[SYS_PLAYER_ID][paper->local_id] = paper;
			}
			_paper_player_list.insert(make_pair(paper->date, paper));
		}
		auto_db(paper);
		//���º�����͵��������
		Json::Value latest = Json::arrayValue;
		latest[0u] = SYS_PLAYER_ID;
		latest[1u] = "system";//��Ч
		latest[2u] = paper->local_id;
		latest[3u] = paper->raw_paper->channel;
		latest[4u] = paper->raw_paper->cash;
		latest[5u] = paper->raw_paper->num;
		latest[6u] = -1;//��Ч
		latest[7u] = 1;
		Json::Value ret_json;
		ret_json[strMsg][0] = 0;
		ret_json[strMsg][1] = 1;
		ret_json[strMsg][2] = latest;
		switch (paper->raw_paper->channel)
		{
		case red_paper::channel::World:
			player_mgr.sendToAll(gate_client::req_paper_new_update_resp, ret_json);
			break;
		case red_paper::channel::Country:
		case red_paper::channel::SYS_Country:
			player_mgr.sendToKingdom((Kingdom::NATION)paper->nation, gate_client::req_paper_new_update_resp, ret_json);
			break;
		default:
			break;
		}
		//LogS << "system paper sent," << "\tloca_id:" << paper->local_id << "\tid:" << paper->raw_paper->id << "\ttimer=" << timerData.tickTime << "\tnow=" << Common::gameTime()<<LogEnd;
	}

	//safety-pass
	void red_paper_system::start_system_paper(const red_paper::ActivityComplete& complete)
	{
		unsigned now = Common::gameTime();
		std::vector<ptrTimerIdentify> _timer_ids;
		_timer_ids_map[complete.id] = _timer_ids;
		for (int i = 0; i < complete.activities.size(); ++i)
		{
			bool is_timer_add = false;
			bool is_wei_add = false;
			bool is_wu_add = false;
			bool is_shu_add = false;
			for (int j = 0; j < complete.activities[i].papers.size(); ++j)
			{
				unsigned date = complete.activities[i].date;
				if (date <= now) continue;
				red_paper::UnitPaperPtr paper_ptr = Creator<red_paper::UnitPaper>::Create();
				paper_ptr->date = date;
				paper_ptr->player_id = SYS_PLAYER_ID;
				paper_ptr->raw_paper = Creator<red_paper::RedPaper>::Create();
				if (complete.activities[i].papers[j].type == red_paper::channel::SYS_Shu)
				{
					paper_ptr->nation = Kingdom::shu;
					paper_ptr->raw_paper->channel = red_paper::channel::Country;
				}
				else if (complete.activities[i].papers[j].type == red_paper::channel::SYS_Wei)
				{
					paper_ptr->nation = Kingdom::wei;
					paper_ptr->raw_paper->channel = red_paper::channel::Country;
				}
				else if (complete.activities[i].papers[j].type == red_paper::channel::SYS_Wu)
				{
					paper_ptr->nation = Kingdom::wu;
					paper_ptr->raw_paper->channel = red_paper::channel::Country;
				}
				else if (complete.activities[i].papers[j].type == red_paper::channel::SYS_World)
				{
					paper_ptr->raw_paper->channel = red_paper::channel::World;
				}
				paper_ptr->local_id = generateLocalPaperId();//����ID
				paper_ptr->raw_paper->id = complete.activities[i].papers[j].id;
				paper_ptr->raw_paper->cash = complete.activities[i].papers[j].cash;
				paper_ptr->raw_paper->total_cash = complete.activities[i].papers[j].cash;
				paper_ptr->raw_paper->num = complete.activities[i].papers[j].num;
				paper_ptr->raw_paper->total_num = complete.activities[i].papers[j].num;
				paper_ptr->raw_paper->res_type = complete.activities[i].papers[j].res_type;
				_timer_ids_map[complete.id].push_back(Timer::AddEventTickTime(boostBind(red_paper_system::sendSystemRedPaper, _1, paper_ptr), Inter::event_red_paper_sys_send, paper_ptr->date));
				//
				if (is_timer_add == false && paper_ptr->raw_paper->channel == red_paper::channel::World)
				{
					//LogS << "red paper activity, time:" << paper_ptr->date << "\tid:" << paper_ptr->raw_paper->id << "\tlocal_id:" << paper_ptr->local_id << LogEnd;
					_timer_ids_map[complete.id].push_back(Timer::AddEventTickTime(boostBind(red_paper_system::notify, _1, (int)CHAT::server_activity_red_paper_ready, 3, paper_ptr), Inter::event_red_paper_ready_min, date - MINUTE));
					_timer_ids_map[complete.id].push_back(Timer::AddEventTickTime(boostBind(red_paper_system::notify, _1, (int)CHAT::server_activity_red_paper_second, 1, paper_ptr), Inter::event_red_paper_ready_second, date - 10 * SECOND));
					//LogS << "red paper activity, timer." << LogEnd;
					is_timer_add = true;
				}
				else if (is_wei_add == false && paper_ptr->raw_paper->channel == red_paper::channel::Country && paper_ptr->nation == Kingdom::wei)
				{
					_timer_ids_map[complete.id].push_back(Timer::AddEventTickTime(boostBind(red_paper_system::notify, _1, (int)CHAT::server_activity_red_paper_ready, 3, paper_ptr), Inter::event_red_paper_ready_min, date - MINUTE));
					_timer_ids_map[complete.id].push_back(Timer::AddEventTickTime(boostBind(red_paper_system::notify, _1, (int)CHAT::server_activity_red_paper_second, 1, paper_ptr), Inter::event_red_paper_ready_second, date - 10 * SECOND));
					is_wei_add = true;
				}
				else if (is_wu_add == false && paper_ptr->raw_paper->channel == red_paper::channel::Country && paper_ptr->nation == Kingdom::wu)
				{
					_timer_ids_map[complete.id].push_back(Timer::AddEventTickTime(boostBind(red_paper_system::notify, _1, (int)CHAT::server_activity_red_paper_ready, 3, paper_ptr), Inter::event_red_paper_ready_min, date - MINUTE));
					_timer_ids_map[complete.id].push_back(Timer::AddEventTickTime(boostBind(red_paper_system::notify, _1, (int)CHAT::server_activity_red_paper_second, 1, paper_ptr), Inter::event_red_paper_ready_second, date - 10 * SECOND));
					is_wu_add = true;
				}
				else if (is_shu_add == false && paper_ptr->raw_paper->channel == red_paper::channel::Country && paper_ptr->nation == Kingdom::shu)
				{
					_timer_ids_map[complete.id].push_back(Timer::AddEventTickTime(boostBind(red_paper_system::notify, _1, (int)CHAT::server_activity_red_paper_ready, 3, paper_ptr), Inter::event_red_paper_ready_min, date - MINUTE));
					_timer_ids_map[complete.id].push_back(Timer::AddEventTickTime(boostBind(red_paper_system::notify, _1, (int)CHAT::server_activity_red_paper_second, 1, paper_ptr), Inter::event_red_paper_ready_second, date - 10 * SECOND));
					is_shu_add = true;
				}

			}
		}
	}
	
	void red_paper_system::notify(const structTimer& timerData, int type, int time, red_paper::UnitPaperPtr ptr)
	{
		Json::Value null_value = Json::arrayValue;
		Json::Value json;
		json["weight"] = 0;
		json["roll"] = time;
		if (ptr->raw_paper->channel == red_paper::channel::World)
		{
			chat_sys.despatchAllSP(type, null_value, json, CHATPOS::chat_windows | CHATPOS::scroll_bar_top);
			//LogS << "notify,type=" << type << "\ttimer=" << timerData.tickTime << "\tnow=" << Common::gameTime() << LogEnd;
		}
		if (ptr->raw_paper->channel == red_paper::channel::Country)
		{
			chat_sys.despatchKingdomSP(type, (Kingdom::NATION)ptr->nation, null_value, json, CHATPOS::chat_windows | CHATPOS::scroll_bar_top);
		}
	}

	void red_paper_system::settle(const structTimer& timerData, red_paper::UnitPaperPtr ptr)
	{
		if (ptr->raw_paper->num == 0 || ptr->raw_paper->cash == 0 || ptr->player_id == SYS_PLAYER_ID)
		{
			return;
		}
		playerDataPtr player = player_mgr.getPlayer(ptr->player_id);
		if (!player)
		{
			return;
		}
		Json::Value box = Json::arrayValue;
		switch (ptr->raw_paper->res_type)
		{
		case ACTION::gold:
			box[0u][0u] = ACTION::gold;
			break;
		case ACTION::ticket:
			box[0u][0u] = ACTION::ticket;
			break;
		case ACTION::cash:
			box[0u][0u] = ACTION::cash;
			break;
		default:
			return;
		}
		box[0u][1u] = ptr->raw_paper->cash;
		LogS << "red paper\tbox:" << box.toIndentString() << LogEnd;
		Json::Value arg = Json::arrayValue;
		arg.append(ptr->raw_paper->cash);
		EmailPtr e = email_sys.createPackage(EmailDef::RedPaperExpiration, arg, box);
		email_sys.sendToPlayer(player->ID(), e);
		
		delRedPaper(ptr);//��ɾ�����ݿ������ݣ������ڴ����ݽ��в���
	}

	void red_paper_system::initData()
	{
		std::cout << "load ./red_paper/* START	" << std::endl;

		Json::Value wor_value = Common::loadJsonFile(std::string("./instance/red_paper/config_1.json"));
		for (int i = 0; i < wor_value.size(); ++i)
		{
			assert(wor_value[i].size() == 4);
			red_paper::RedPaperPtr paper = Creator<red_paper::RedPaper>::Create();
			paper->id = wor_value[i][0].asInt();
			paper->channel = red_paper::channel::World;
			paper->res_type = wor_value[i][1].asInt() == ACTION::ticket ? ACTION::ticket : (wor_value[i][1].asInt() == ACTION::gold ? ACTION::gold : ACTION::cash);
			paper->cash = wor_value[i][2].asInt();
			paper->num = wor_value[i][3].asInt();
			if (paper->cash < paper->num)
			{
				continue;
			}
			paper->total_cash = paper->cash;
			paper->total_num = paper->num;
			_raw_paper_list[paper->id] = paper;
		}

		Json::Value con_value = Common::loadJsonFile(std::string("./instance/red_paper/config_2.json"));
		for (int i = 0; i < con_value.size(); ++i)
		{
			assert(con_value[i].size() == 4);
			red_paper::RedPaperPtr paper = Creator<red_paper::RedPaper>::Create();
			paper->id = con_value[i][0].asInt();
			paper->channel = red_paper::channel::Country;
			paper->res_type = con_value[i][1].asInt() == ACTION::ticket ? ACTION::ticket : (con_value[i][1].asInt() == ACTION::gold ? ACTION::gold : ACTION::cash);
			paper->cash = con_value[i][2].asInt();
			paper->num = con_value[i][3].asInt();
			if (paper->cash < paper->num)
			{
				continue;
			}
			paper->total_cash = paper->cash;
			paper->total_num = paper->num;
			_raw_paper_list[paper->id] = paper;
		}

		Json::Value per_value = Common::loadJsonFile(std::string("./instance/red_paper/config_3.json"));
		for (int i = 0; i < per_value.size(); ++i)
		{
			assert(per_value[i].size() >= 3);
			red_paper::RedPaperPtr paper = Creator<red_paper::RedPaper>::Create();
			paper->id = per_value[i][0].asInt();
			paper->channel = red_paper::channel::Person;
			paper->res_type = per_value[i][1].asInt() == ACTION::ticket ? ACTION::ticket : (per_value[i][1].asInt() == ACTION::gold ? ACTION::gold : ACTION::cash);
			paper->cash = per_value[i][2].asInt();
			paper->num = 1;
			if (paper->cash < paper->num)
			{
				continue;
			}
			paper->total_cash = paper->cash;
			paper->total_num = paper->num;
			_raw_paper_list[paper->id] = paper;
		}

		Json::Value sw_value = Common::loadJsonFile(std::string("./instance/red_paper/config_4.json"));
		for (int i = 0; i < sw_value.size(); ++i)
		{
			assert(sw_value[i].size() == 4);
			red_paper::RedPaperPtr paper = Creator<red_paper::RedPaper>::Create();
			paper->id = sw_value[i][0].asInt();
			paper->channel = red_paper::channel::SYS_World;
			paper->cash = sw_value[i][2].asInt();
			paper->num = sw_value[i][3].asInt();
			if (paper->cash < paper->num)
			{
				continue;
			}
			paper->total_cash = paper->cash;
			paper->total_num = paper->num;
			paper->res_type = sw_value[i][1].asInt() == ACTION::ticket ? ACTION::ticket : (sw_value[i][1].asInt() == ACTION::gold ? ACTION::gold : ACTION::cash);
			_sys_raw_paper_list[paper->id] = paper;
		}

		Json::Value sc_value = Common::loadJsonFile(std::string("./instance/red_paper/config_5.json"));
		for (int i = 0; i < sc_value.size(); ++i)
		{
			assert(sc_value[i].size() == 5);
			red_paper::RedPaperPtr paper = Creator<red_paper::RedPaper>::Create();
			paper->id = sc_value[i][0].asInt();
			paper->channel = sc_value[i][4] == 0 ? red_paper::channel::SYS_Wei : (sc_value[i][4] == 2 ? red_paper::channel::SYS_Wu : red_paper::channel::SYS_Shu);
			paper->cash = sw_value[i][2].asInt();
			paper->num = sw_value[i][3].asInt();
			if (paper->cash < paper->num)
			{
				continue;
			}
			paper->total_cash = paper->cash;
			paper->total_num = paper->num;
			paper->res_type = sc_value[i][1].asInt() == ACTION::ticket ? ACTION::ticket : (sc_value[i][1].asInt() == ACTION::gold ? ACTION::gold : ACTION::cash);
			_sys_raw_paper_list[paper->id] = paper;
		}

		///
		Json::Value t1_value = Common::loadJsonFile(std::string("./instance/red_paper/config_6.json"));
		for (int i = 0; i < t1_value.size(); ++i)
		{
			assert(t1_value[i].size() == 4);
			red_paper::RedPaperPtr paper = Creator<red_paper::RedPaper>::Create();
			paper->id = t1_value[i][0].asInt();
			paper->channel = red_paper::channel::Country;
			paper->res_type = t1_value[i][1].asInt() == ACTION::ticket ? ACTION::ticket : (t1_value[i][1].asInt() == ACTION::gold ? ACTION::gold : ACTION::cash);
			paper->cash = t1_value[i][2].asInt();
			paper->num = t1_value[i][3].asInt();
			if (paper->cash < paper->num)
			{
				continue;
			}
			paper->total_cash = paper->cash;
			paper->total_num = paper->num;
			_raw_s_paper_list[paper->id] = paper;
			_raw_paper_list[paper->id] = paper;
			
		}

		Json::Value t2_value = Common::loadJsonFile(std::string("./instance/red_paper/config_7.json"));
		for (int i = 0; i < t2_value.size(); ++i)
		{
			assert(t2_value[i].size() == 4);
			red_paper::RedPaperPtr paper = Creator<red_paper::RedPaper>::Create();
			paper->id = t2_value[i][0].asInt();
			paper->channel = red_paper::channel::Country;
			paper->res_type = t2_value[i][1].asInt() == ACTION::ticket ? ACTION::ticket : (t2_value[i][1].asInt() == ACTION::gold ? ACTION::gold : ACTION::cash);
			paper->cash = t2_value[i][2].asInt();
			paper->num = t2_value[i][3].asInt();
			if (paper->cash < paper->num)
			{
				continue;
			}
			paper->total_cash = paper->cash;
			paper->total_num = paper->num;
			_raw_s_paper_list[paper->id] = paper;
			_raw_paper_list[paper->id] = paper;
		}

		Json::Value t3_value = Common::loadJsonFile(std::string("./instance/red_paper/config_8.json"));
		for (int i = 0; i < t3_value.size(); ++i)
		{
			assert(t3_value[i].size() == 4);
			red_paper::RedPaperPtr paper = Creator<red_paper::RedPaper>::Create();
			paper->id = t3_value[i][0].asInt();
			paper->channel = red_paper::channel::Country;
			paper->res_type = t3_value[i][1].asInt() == ACTION::ticket ? ACTION::ticket : (t3_value[i][1].asInt() == ACTION::gold ? ACTION::gold : ACTION::cash);
			paper->cash = t3_value[i][2].asInt();
			paper->num = t3_value[i][3].asInt();
			if (paper->cash < paper->num)
			{
				continue;
			}
			paper->total_cash = paper->cash;
			paper->total_num = paper->num;
			_raw_s_paper_list[paper->id] = paper;
			_raw_paper_list[paper->id] = paper;
		}

		std::cout << "load ./red_paper/* NED	" << std::endl;
	}

	void red_paper_system::loadData()
	{
		objCollection objs = db_mgr.Query(DBN::dbSystemSentRedPaper);
		unsigned now = Common::gameTime();
		ForEachC(objCollection, it, objs)
		{
			red_paper::UnitPaperPtr unit = Creator<red_paper::UnitPaper>::Create();
			const mongo::BSONObj& obj = (*it);
			int num = obj[strNum].Int();
			unsigned date = date = obj[strDate].Int();
			if (now > date && now - date > DEAHLINE)
			{
				continue;
			}
			unit->player_id = obj[strPlayerID].Int();
			unit->player_name = obj[strPlayerName].String();
			unit->local_id = obj[strLocalID].Int();
			unit->face_id = obj[strFaceID].Int();
			unit->nation = obj[strNationID].Int();
			unit->receiver_id = obj[strReceiverID].Int();
			unit->date = date;
			red_paper::RedPaperPtr paper_ptr = Creator<red_paper::RedPaper>::Create();
			paper_ptr->id = obj[strItemID].Int();
			paper_ptr->cash = obj[strCash].Int();
			paper_ptr->total_cash = obj[strTotalCash].Int();
			paper_ptr->total_num = obj[strTotalNum].Int();
			paper_ptr->num = num;
			paper_ptr->channel = obj[strChannel].Int();
			paper_ptr->res_type = obj[strResType].Int();
			unit->raw_paper = paper_ptr;
			if (_paper_player_set.find(unit->player_id) == _paper_player_set.end())
			{
				RedPaperList list;
				list[unit->local_id] = unit;
				_paper_player_set[unit->player_id] = list;
			}
			else
			{
				_paper_player_set[unit->player_id][unit->local_id] = unit;
			}
			_paper_player_list.insert(make_pair(unit->date, unit));
			//���ӵ���ʱ��
			if (_raw_s_paper_list.find(unit->raw_paper->id) == _raw_s_paper_list.end())
			{
				unit->timer = Timer::AddEventTickTime(boostBind(red_paper_system::settle, _1, unit), Inter::event_red_paper_settle, unit->date + EXPIRATION);
			}
		}

		//
		objCollection objs2 = db_mgr.Query(DBN::dbSystemGetRedPaper);
		ForEachC(objCollection, it, objs2)
		{
			const mongo::BSONObj& obj = (*it);
			red_paper::RobberPtr robber_ptr = Creator<red_paper::Robber>::Create();
			robber_ptr->senderID = obj[strPlayerID].Int();
			robber_ptr->local_id = obj[strLocalID].Int();
			robber_ptr->robberID = obj[strRobberID].Int();
			robber_ptr->nickname = obj[strName].String();
			robber_ptr->cash = obj[strCash].Int();
			robber_ptr->date = obj[strDate].Int();
			robber_ptr->face_Id = obj[strFaceID].Int();
			if (_robber_player_set.find(robber_ptr->senderID) == _robber_player_set.end())
			{
				red_paper::RobberPlayerList list;
				red_paper::RobberVec vec;
				vec.push_back(robber_ptr);
				list[robber_ptr->local_id] = vec;
				_robber_player_set[robber_ptr->senderID] = list;
			}
			else if (_robber_player_set[robber_ptr->senderID].find(robber_ptr->local_id) == _robber_player_set[robber_ptr->senderID].end())
			{
				red_paper::RobberVec vec;
				vec.push_back(robber_ptr);
				_robber_player_set[robber_ptr->senderID][robber_ptr->local_id] = vec;
			}
			else
			{
				_robber_player_set[robber_ptr->senderID][robber_ptr->local_id].push_back(robber_ptr);
			}
		}

		//
		objCollection objs3 = db_mgr.Query(DBN::dbSystemActivityRedPaperId);
		ForEachC(objCollection, it, objs3)
		{
			const mongo::BSONObj& obj = (*it);
			_local_id = obj[strLocalID].Int();
		}

		//���ػ
		objCollection objs4 = db_mgr.Query(DBN::dbSystemActivityRedPaper);
		now = Common::gameTime();
		ForEachC(objCollection, it, objs4)
		{
			const mongo::BSONObj& obj = (*it);
			red_paper::ActivityComplete acti;
			acti.id = obj[strActiID].Int();
			acti.stime = obj[strSTime].Int();
			acti.etime = obj[strETime].Int();
			std::vector<mongo::BSONElement> infoss = obj[strActivityContent].Array();
			for (int i = 0; i < infoss.size(); ++i)
			{
				red_paper::ActivityUnit unit;
				std::vector<mongo::BSONElement> info = infoss[i].Array();
				unit.date = info[0u].Int();
				//LogS << "load acti date:" << unit.date << LogEnd;
				for (int j = 1; j < info.size(); ++j)
				{
					red_paper::SpecialRedPaper paper;
					std::vector<mongo::BSONElement> paper_arr = info[j].Array();
					RawRedPaperPtrList::iterator it = _sys_raw_paper_list.find(paper_arr[0u].Int());
					if (it == _sys_raw_paper_list.end())
					{
						continue;
					}
					paper.id = it->second->id;
					paper.res_type = it->second->res_type;
					paper.type = it->second->channel;
					paper.cash = paper_arr[2u].Int();
					paper.num = paper_arr[3u].Int();
					unit.papers.push_back(paper);
				}
				acti.activities.push_back(unit);
			}
			sys_activity_config[acti.id] = acti;
			start_system_paper(acti);
		}
	}

	bool red_paper_system::auto_db(red_paper::UnitPaperPtr ptr)
	{
		if (!ptr) return false;
		mongo::BSONObj key = BSON(strPlayerID << ptr->player_id << strLocalID << ptr->local_id);

		mongo::BSONObj obj = BSON(strPlayerID << ptr->player_id
			<< strPlayerName << ptr->player_name
			<< strLocalID << ptr->local_id
			<< strItemID << ptr->raw_paper->id
			<< strCash << ptr->raw_paper->cash
			<< strNum << ptr->raw_paper->num
			<< strDate << ptr->date
			<< strChannel << ptr->raw_paper->channel
			<< strResType << ptr->raw_paper->res_type
			<< strFaceID << ptr->face_id
			<< strNationID << ptr->nation
			<< strReceiverID << ptr->receiver_id
			<< strTotalCash << ptr->raw_paper->total_cash
			<< strTotalNum << ptr->raw_paper->total_num
		);
		return db_mgr.SaveMongo(DBN::dbSystemSentRedPaper, key, obj);
	}

	void red_paper_system::delRedPaper(red_paper::UnitPaperPtr ptr)
	{
		if (!ptr) return;
		mongo::BSONObj key = BSON(strPlayerID << ptr->player_id << strLocalID << ptr->local_id);

		db_mgr.RemoveCollection(DBN::dbSystemSentRedPaper, key);
	}

	bool red_paper_system::save_robber(int playerID, int local_id, int idx/* = -1*/)
	{
		RobberPlayerSet::iterator pit = _robber_player_set.find(playerID);
		if (pit == _robber_player_set.end())
		{
			return false;
		}
		red_paper::RobberPlayerList::iterator rit = pit->second.find(local_id);
		if (rit == pit->second.end())
		{
			return false;
		}

		if (idx == -1)
		{
			idx = rit->second.size() - 1;
		}
		if (idx < 0 || rit->second.size() < 1)
		{
			return false;
		}
		mongo::BSONObj key = BSON(strPlayerID << playerID
			<< strLocalID << local_id
			<< strRobberID << rit->second[idx]->robberID);

		mongo::BSONObj obj = BSON(strPlayerID << playerID
			<< strLocalID << local_id
			<< strRobberID << rit->second[idx]->robberID
			<< strName << rit->second[idx]->nickname
			<< strDate << rit->second[idx]->date
			<< strCash << rit->second[idx]->cash
			<< strFaceID << rit->second[idx]->face_Id
		);

		return db_mgr.SaveMongo(DBN::dbSystemGetRedPaper, key, obj);
	}

	bool red_paper_system::save_acti(const red_paper::ActivityComplete& complete)
	{
		mongo::BSONArrayBuilder activities;
		for (int i = 0; i < complete.activities.size(); ++i)
		{
			mongo::BSONArrayBuilder acti;
			acti << complete.activities[i].date;
			for (int j = 0; j < complete.activities[i].papers.size(); ++j)
			{
				mongo::BSONArrayBuilder paper;
				paper << complete.activities[i].papers[j].id;
				paper << complete.activities[i].papers[j].type;
				paper << complete.activities[i].papers[j].cash;
				paper << complete.activities[i].papers[j].num;
				paper << complete.activities[i].papers[j].res_type;
				acti << paper.arr();
			}
			activities << acti.arr();
		}
		
		mongo::BSONObj key = BSON(strActiID << complete.id);

		mongo::BSONObj val = BSON(strActiID << complete.id
			<< strSTime << complete.stime
			<< strETime << complete.etime
			<< strActivityContent << activities.arr()
		);
		return db_mgr.SaveMongo(DBN::dbSystemActivityRedPaper, key, val);
	}

	void red_paper_system::del_acti(int id)
	{
		mongo::BSONObj key = BSON(strActiID << id);

		db_mgr.RemoveCollection(DBN::dbSystemActivityRedPaper, key);

	}

	bool red_paper_system::save_local_id()
	{
		//mongo::BSONObj key = BSON(strLocalID << _local_id);

		return db_mgr.SaveMongo(DBN::dbSystemActivityRedPaperId, BSON("key" << 1), BSON("key" << 1 << strLocalID << _local_id));
	}

	red_paper_system::~red_paper_system()
	{
	}
}

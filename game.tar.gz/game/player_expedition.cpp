#include "player_expedition.h"
#include "heroparty_system.h"
#include "expedition_system.h"
#include "battle_helper.hpp"
#include "game_time.h"
#include "task_mgr.h"
#include "bv_rank_cache.h"

namespace gg
{
	namespace Expedition
	{
		class BuyReset
		{
			SINGLETON(BuyReset);
			public:
				int maxTimes(playerDataPtr d) const
				{
					if (_times.empty())
						return 0;
					int vip = d->Info().VipLv();
					if (vip >= _times.size())
						vip = _times.size() - 1;
					return _times[vip];
				}
				int cost(int times) const
				{
					if (_cost.empty())
						return 100;
					if (times >= _cost.size())
						times = _cost.size() - 1;
					return _cost[times];
				}
			private:
				void loadFile();
			private:
				STDVECTOR(int, Values);
				Values _times;
				Values _cost;
		};

		BuyReset::BuyReset()
		{
			loadFile();
		}

		void BuyReset::loadFile()
		{
			const Json::Value info = Common::loadJsonFile("./instance/expedition/reset.json");
			const Json::Value& cost = info["cost"];
			ForEachC(Json::Value, it, cost)
				_cost.push_back((*it).asInt());
			const Json::Value& times = info["times"];
			ForEachC(Json::Value, it, times)
				_times.push_back((*it).asInt());
		}
	}

	using namespace Expedition;

	static int GetDamagePercent(sBattlePtr& ptr)
	{
		int max_hp = 0;
		int cur_hp = 0;
		manList& ml = ptr->battleMan;
		for (unsigned i = 0; i < ml.size(); ++i)
		{
			mBattlePtr& mptr = ml[i];
			cur_hp += mptr->currentHP;
			max_hp += mptr->getTotalAttri(idx_hp);
		}
		return ((max_hp - cur_hp) * 10000 / max_hp);
	}

	static int GetNoEqBV(playerDataPtr d)
	{
		return CalNoEqBV(d, d->WarFM().currentFM(), d->WarFM().currentID());
	}
	
	playerExpedition::playerExpedition(playerData* const own)
		: _auto_player(own), _cur_pos(0), _remain_times(1), _match_rank(-1), _match_bv(-1), _first_expedition(true)
		, _max_noeq_bv(0), _season(-1), _buy_times(0), _challenge_times(2), _max_mop_up_pos(-1)
	{
	}

	int playerExpedition::season()
	{
		if (_season == -1)
			_season = season_sys.getSeason();
		return _season;
	}

	const Expedition::ManInfo& playerExpedition::getManInfo(int fid) const
	{
		static Expedition::ManInfo full_info(-1, -1);
		ManInfos::const_iterator it = _man_info.find(fid);
		return it == _man_info.end()? full_info : it->second;
	}

	void playerExpedition::upData()
	{
		if (_next_tick_time != Expedition::DailyRank::shared().nextTickTime())
		{
			_next_tick_time = Expedition::DailyRank::shared().nextTickTime();
			reset();
		}
	}

	void playerExpedition::reset()
	{
		_cur_pos = 0;
		_daily_record.progress = 0;
		_daily_record.percent = 0;
		_daily_record.time = 0;
		_man_info.clear();

		_remain_times = 1;
		_challenge_times = 2;
		_buy_times = 0;
		_max_mop_up_pos = -1;
		
		_reward_state.clear();

		_match_rank = BVRankCache::shared().getRank(Own().ID());
		_match_bv = -1;
		_match_pid.clear();
		_target_hp.clear();

		_sign_auto();
	}

	void playerExpedition::classLoad()
	{
		mongo::BSONObj key = BSON(strPlayerID << Own().ID());
		mongo::BSONObj obj = db_mgr.FindOne(DBN::dbPlayerExpedition, key);
		if (obj.isEmpty())
			return;

		checkNotEoo(obj["hr"])
		{
			std::vector<mongo::BSONElement> ele = obj["hr"].Array();
			for (unsigned i = 0; i < ele.size(); ++i)
			{
				_history_record[i].progress = ele[i]["p"].Int();
				_history_record[i].time = ele[i]["t"].Int();
				checkNotEoo(ele[i]["pr"])
					_history_record[i].percent = ele[i]["pr"].Int();
				else
					_history_record[i].percent = 10000;
			}
		}
		checkNotEoo(obj["dr"])
		{
			_daily_record.progress = obj["dr"]["p"].Int();
			_daily_record.time = obj["dr"]["t"].Int();
			checkNotEoo(obj["dr"]["pr"])
				_daily_record.percent = obj["dr"]["pr"].Int();
			else
				_daily_record.percent = 10000;
		}

		{
			std::vector<mongo::BSONElement> ele = obj["mi"].Array();
			for (unsigned i = 0; i < ele.size(); ++i)
				_man_info.insert(make_pair(ele[i]["i"].Int(), Expedition::ManInfo(ele[i]["h"].Int(), ele[i]["m"].Int())));
		}
		_cur_pos = obj["cp"].Int();
		_remain_times = obj["rt"].Int();
		checkNotEoo(obj["ct"])
			_challenge_times = obj["ct"].Int();
		checkNotEoo(obj["bt"])
			_buy_times = obj["bt"].Int();
		checkNotEoo(obj["mnb"])
			_max_noeq_bv = obj["mnb"].Int();
		checkNotEoo(obj["rs"])
		{
			std::vector<mongo::BSONElement> ele = obj["rs"].Array();
			for (unsigned i = 0; i < ele.size(); ++i)
				_reward_state.push_back(ele[i].Int());
		}
		checkNotEoo(obj["fe"])
			_first_expedition = obj["fe"].Bool();
		checkNotEoo(obj["mb"])
			_match_bv = obj["mb"].Int();
		checkNotEoo(obj["mrk"])
			_match_rank = obj["mrk"].Int();
		checkNotEoo(obj["th"])
		{
			std::vector<mongo::BSONElement> ele = obj["th"].Array();
			for (unsigned i = 0; i < ele.size(); ++i)
				_target_hp.insert(make_pair(ele[i]["i"].Int(), ele[i]["h"].Int()));
		}
		checkNotEoo(obj["mpid"])
		{
			std::vector<mongo::BSONElement> ele = obj["mpid"].Array();
			for (unsigned i = 0; i < ele.size(); ++i)
				_match_pid.insert(make_pair(ele[i]["p"].Int(), ele[i]["i"].Int()));
		}
		checkNotEoo(obj["mmup"])
			_max_mop_up_pos = obj["mmup"].Int();
		checkNotEoo(obj["ntt"])
			_next_tick_time = obj["ntt"].Int();
		else
			_next_tick_time = Own().Tick().stander5();
	}

	int playerExpedition::buy()
	{
		int max_times = BuyReset::shared().maxTimes(Own().getOwnDataPtr());
		if (max_times <= _buy_times)
			return err_illedge;
		int gold = BuyReset::shared().cost(_buy_times);
		if (Own().Res().getCash() < gold)
			return err_gold_not_enough;
		Own().Res().alterCash(0 - gold);
		++_remain_times;
		++_challenge_times;
		++_buy_times;
		update();
		_sign_save();
		return res_sucess;
	}

	bool playerExpedition::_auto_save()
	{
		mongo::BSONObj key = BSON(strPlayerID << Own().ID());
		mongo::BSONObjBuilder obj;
		obj << strPlayerID << Own().ID() << "cp" << _cur_pos << "rt" << _remain_times
			<< "fe" << _first_expedition << "mb" << _match_bv << "mnb" << _max_noeq_bv
			<< "dr" << BSON("p" << _daily_record.progress << "t" << _daily_record.time << "pr" << _daily_record.percent)
			<< "bt" << _buy_times << "ct" << _challenge_times << "ntt" << _next_tick_time
			<< "mrk" << _match_rank << "mmup" << _max_mop_up_pos;
		{
			mongo::BSONArrayBuilder b;
			ForEachC(std::vector<int>, it, _reward_state)
				b.append(*it);
			obj << "rs" << b.arr();
		}
		{
			mongo::BSONArrayBuilder b;
			ForEachC(ManInfos, it, _man_info)
				b.append(BSON("i" << it->first << "h" << it->second.hp << "m" << it->second.mp));
			obj << "mi" << b.arr();
		}
		{
			mongo::BSONArrayBuilder b;
			for (unsigned i = 0; i < 4; ++i)
				b.append(BSON("p" << _history_record[i].progress << "t" << _history_record[i].time << "pr" << _history_record[i].percent));
			obj << "hr" << b.arr();
		}
		{
			mongo::BSONArrayBuilder b;
			for (std::map<int, int>::const_iterator it = _target_hp.begin(); it != _target_hp.end(); ++it)
				b.append(BSON("i" << it->first << "h" << it->second));
			obj << "th" << b.arr();
		}
		{
			mongo::BSONArrayBuilder b;
			for (std::map<int, int>::const_iterator it = _match_pid.begin(); it != _match_pid.end(); ++it)
				b.append(BSON("p" << it->first << "i" << it->second));
			obj << "mpid" << b.arr();
		}
		return db_mgr.SaveMongo(DBN::dbPlayerExpedition, key, obj.obj());
	}

	int playerExpedition::mopUp(int pos)
	{
		if (_max_mop_up_pos == 0
			|| _cur_pos >= _max_mop_up_pos
			|| pos < 1
			|| pos > _max_mop_up_pos - 4
			|| pos <= _cur_pos)
			return err_illedge;
		int item_num = pos - _cur_pos;
		if (item_num < 1)
			return err_illedge;
		//if (Own().Items().itemNum(10001) < item_num)
		//	return err_item_not_enough;
		if (_challenge_times > _remain_times)
			--_challenge_times;
		int tmp = _cur_pos;
		_cur_pos = pos;
		//Own().Items().removeItem(10001, item_num);
		for (int i = tmp + 1; i <= _cur_pos; ++i)
			TaskMgr::update(Own().getOwnDataPtr(), Task::ExpeditionChapterTimes, i, 1);
		_sign_auto();
		return res_sucess;
	}

	void playerExpedition::updateRecord(const Record& r)
	{
		if (r.progress == 0
			&& r.percent == 0)
			return;
		if (r.progress > _daily_record.progress
			|| (r.progress == _daily_record.progress
			&& r.percent > _daily_record.percent))
		{
			RankKey old_key(Own().getOwnDataPtr(), Expedition::DailyKey);
			_daily_record = r;
			Expedition::DailyRank::shared().update(Own().getOwnDataPtr(), old_key);
		}
		int season = Expedition::DailyRank::shared().season();
		if (r.progress > _history_record[season].progress
			|| (r.progress == _history_record[season].progress
			&& r.percent > _history_record[season].percent))
		{
			RankKey old_key(Own().getOwnDataPtr(), Expedition::HistoryKey, season);
			_history_record[season] = r;
			Expedition::HistoryRankMgr::shared().update(Own().getOwnDataPtr(), old_key);
		}
	}

	void playerExpedition::resetTargetHp(sBattlePtr& ptr)
	{
		for (unsigned i = 0; i < ptr->battleMan.size(); ++i)
		{
			const mBattlePtr& m = ptr->battleMan[i];
			_target_hp[m->manID] = m->currentHP;
		}
	}

	void playerExpedition::doneBattle(int resultB, sBattlePtr& ptr, sBattlePtr& target_ptr)
	{
		if (_challenge_times > _remain_times)
			--_challenge_times;
		unsigned cur_time = Common::gameTime();
		if (resultB == resBattle::atk_win)
		{
			++_cur_pos;
			_match_bv = -1;
			_target_hp.clear();
			Record r;
			r.time = cur_time;
			r.progress = _cur_pos;
			r.percent = 10000;
			updateRecord(r);
			TaskMgr::update(Own().getOwnDataPtr(), Task::ExpeditionChapterTimes, _cur_pos, 1);
			Own().Daily().tickTask(DAILY::expedition_process);
			Log(DBLOG::strLogExpedition, Own().getOwnDataPtr(), 0, season_sys.getSeason(), _cur_pos);
			_sign_update();
		}
		else
		{
			_match_bv = matchBV();
			Record r;
			r.time = cur_time;
			r.progress = _cur_pos + 1;
			r.percent = GetDamagePercent(target_ptr);
			updateRecord(r);
			resetTargetHp(target_ptr);
		}
		if (_first_expedition)
		{
			TaskMgr::update(Own().getOwnDataPtr(), Task::FirstExpedition, 1);
			_first_expedition = false;
		}
		resetManInfo(ptr);
		Own().ExpeditionFM().update();
		_sign_save();
	}

	int playerExpedition::getReward(int pos, Json::Value& r)
	{
		r[1u] = Json::arrayValue;
		r[2u] = Json::arrayValue;
		if (pos != 0)
		{
			int res = doGetReward(pos, r[1u]);
			if (res == res_sucess)
				r[2u].append(pos);
			return res;
		}
		else
		{
			for (int i = 1; i <= _cur_pos; ++i)
			{
				Json::Value tmp_r = Json::arrayValue;
				if (doGetReward(i, tmp_r) == res_sucess)
				{
					combineActionRes(tmp_r, r[1u]);
					r[2u].append(i);
				}
			}
			return res_sucess;
		}
	}

	int playerExpedition::doGetReward(int pos, Json::Value& r)
	{
		if (pos < 1 || pos > _cur_pos)
			return err_illedge;
		if (pos <= _reward_state.size()
			&& _reward_state[pos-1] != 0)
			return err_illedge;
		Expedition::MapPtr ptr = MapDataMgr::shared().getMapData(Own().getOwnDataPtr(), pos);
		if (!ptr) return err_illedge;
		const ActionRandomList& rw = ptr->getReward();
		int res = actionDo(Own().getOwnDataPtr(), rw);
		if (res == res_sucess)
		{
			r = actionRes();
			if (pos > _reward_state.size())
				_reward_state.insert(_reward_state.end(), pos - _reward_state.size(), 0);
			_reward_state[pos-1] = 1;
			Log(DBLOG::strLogExpedition, Own().getOwnDataPtr(), 1, season_sys.getSeason(), pos, "", "", "", "", "", r);
			_sign_auto();
		}
		else
		{
			Json::Value error_code = actionError();
			res = error_code[0u][1u].asInt();
		}
		return res;
	}

	int playerExpedition::matchRank()
	{
		if (_match_rank == -1)
			_match_rank = BVRankCache::shared().getRank(Own().ID());
		return _match_rank;
	}

	int playerExpedition::flush()
	{
		if (_remain_times < 1)
			return err_illedge;
		--_remain_times;
		_max_mop_up_pos = _cur_pos;
		_cur_pos = 0;
		_man_info.clear();
		_reward_state.clear();
		_target_hp.clear();
		_match_bv = -1;
		Own().ExpeditionFM().tickAt0500();
		Own().ExpeditionFM().update();
		upManInfo();
		_sign_auto();
		return res_sucess;
	}

	int playerExpedition::setProgress(int pos)
	{
		_cur_pos = pos;
		_match_bv = -1;
		_target_hp.clear();
		Record r;
		r.time = Common::gameTime();
		r.progress = _cur_pos;
		r.percent = 10000;
		updateRecord(r);
		TaskMgr::update(Own().getOwnDataPtr(), Task::ExpeditionChapterTimes, _cur_pos, 1);
		for (unsigned i = 0; i < pos; ++i)
			Own().Daily().tickTask(DAILY::expedition_process);
		Log(DBLOG::strLogExpedition, Own().getOwnDataPtr(), 0, season_sys.getSeason(), _cur_pos);
		_sign_auto();
		return res_sucess;
	}

	void playerExpedition::recalFM()
	{
		int tmp = GetNoEqBV(Own().getOwnDataPtr());
		if (tmp > _max_noeq_bv)
		{
			_max_noeq_bv = tmp;
			Own().Shadow().upMaxBattlePtr();
			_sign_save();
		}
	}

	int playerExpedition::maxNoEqBV()
	{
		if (_max_noeq_bv == 0)
			_max_noeq_bv = GetNoEqBV(Own().getOwnDataPtr());
		return _max_noeq_bv;
	}
	
	int playerExpedition::matchBV()
	{
		if (_match_bv == -1)
			return maxNoEqBV();
		return _match_bv;
	}

	int playerExpedition::getTargetPID(int pos)
	{
		std::map<int, int>::iterator it = _match_pid.find(pos);
		if (it != _match_pid.end())
			return it->second;
		Expedition::MapPtr ptr = MapDataMgr::shared().getMapData(Own().getOwnDataPtr(), pos);
		if (!ptr) return -1;
		Expedition::PtrIPlayer nptr = upCast<Expedition::IPlayer>(ptr);
		if (!nptr) return -1;
		int pid = nptr->randTargetPID(Own().getOwnDataPtr());
		if (pid != -1)
		{
			_match_pid.insert(make_pair(pos, pid));
			_sign_save();
		}
		return pid;
	}

	void playerExpedition::_auto_update()
	{
		update();
	}

	void playerExpedition::resetManInfo(sBattlePtr& ptr)
	{
		manList& ml = ptr->battleMan;
		for (unsigned i = 0; i < ml.size(); ++i)
		{
			gg::playerManPtr mptr = Own().Man().findArmyByMan(ml[i]->manID);
			if (!mptr) continue;
			ManInfos::iterator it = _man_info.find(mptr->uniqueID());
			if (it != _man_info.end())
			{
				it->second.hp = ml[i]->currentHP;
				it->second.mp = ml[i]->irrelateMorale();
			}
			else
			{
				_man_info.insert(make_pair(mptr->uniqueID(), ManInfo(ml[i]->currentHP, ml[i]->irrelateMorale())));
			}
		}
		Own().ExpeditionFM().resetFM();
		upManInfo();
		_sign_save();
	}
	
	sBattlePtr playerExpedition::getBattlePtr()
	{
		return Own().ExpeditionFM().getBattlePtr();
	}

	void playerExpedition::update()
	{
		qValue m;
		m.append(res_sucess);
		qValue q(qJson::qj_object);
		q.addMember("rt", _remain_times);
		q.addMember("cp", _cur_pos);
		qValue rw;
		ForEachC(std::vector<int>, it, _reward_state)
			rw.append(*it);
		q.addMember("rw", rw);
		q.addMember("bt", _buy_times);
		q.addMember("ct", _challenge_times);
		if (_max_mop_up_pos == -1)
			q.addMember("mu", _max_mop_up_pos);
		else
		{
			int tmp = _max_mop_up_pos - 4;
			q.addMember("mu", tmp < 0? 0 : tmp);
		}
		m.append(q);
		Own().sendToClientFillMsg(gate_client::expedition_player_info_resp, m);
	}

	void playerExpedition::upManInfo()
	{
		qValue m;
		m.append(res_sucess);
		qValue q;
		ForEachC(ManInfos, it, _man_info)
		{
			gg::playerManPtr mptr = Own().Man().findArmy(it->first);
			if (!mptr) continue;
			qValue tmp;
			tmp << mptr->armyID() << it->second.hp << it->second.mp;
			q.append(tmp);
		}
		m.append(q);
		Own().sendToClientFillMsg(gate_client::expedition_man_info_resp, m);
	}

	void playerExpedition::upManInfo(sBattlePtr& ptr)
	{
		qValue m;
		m.append(res_sucess);
		qValue q;
		manList& ml = ptr->battleMan;
		for (unsigned i = 0; i < ml.size(); ++i)
		{
			if (!ml[i]) continue;
			gg::playerManPtr mptr = Own().Man().findArmyByMan(ml[i]->manID);
			if (!mptr) continue;
			qValue tmp;
			tmp << mptr->armyID() << ml[i]->currentHP << ml[i]->irrelateMorale();
			q.append(tmp);
		}
		m.append(q);
		Own().sendToClientFillMsg(gate_client::expedition_man_info_resp, m);
	}

	int playerExpedition::challengeLimit(int pos)
	{
		if (pos != _cur_pos + 1)
			return err_illedge;
		return res_sucess;
	}

	bool playerExpedition::dead(int mid) const
	{
		ManInfos::const_iterator it = _man_info.find(mid);
		if (it == _man_info.end())
			return false;
		return it->second.hp < 1;
	}

	playerShadow::playerShadow(playerData* const own)
		: _auto_player(own)
	{
	}

	sBattlePtr playerShadow::getMaxBattlePtr()
	{
		if (!_max_ptr)
			upMaxBattlePtr();
		return _max_ptr;
	}

	sBattlePtr playerShadow::getBattlePtr(playerDataPtr d)
	{
		if (!_cur_ptr)
		{
			_cur_ptr = getMaxBattlePtr();
			_sign_save();
		}
		sBattlePtr ptr = sideBattle::CreateFrom(_cur_ptr);
		const std::map<int, int>& target_hp = d->Expedition().getTargetHp();
		for (unsigned i = 0; i < ptr->battleMan.size(); ++i)
		{
			const mBattlePtr& m = ptr->battleMan[i];
			std::map<int, int>::const_iterator it = target_hp.find(m->manID);
			if (it != target_hp.end())
				m->currentHP = it->second;
		}
		return ptr;
	}

	void playerShadow::tickAt2200()
	{
		_next_ptr = getMaxBattlePtr();
		_sign_save();
	}

	void playerShadow::tickAt0500()
	{
		_cur_ptr = _next_ptr;
		_next_ptr.reset();
		_sign_save();
	}

	bool playerShadow::_auto_save()
	{
		mongo::BSONObj key = BSON(strPlayerID << Own().ID());
		mongo::BSONObjBuilder obj;
		obj << strPlayerID << Own().ID();
		if (_max_ptr)
			obj << "max" << toBSON(_max_ptr);
		if (_cur_ptr)
			obj << "cur" << toBSON(_cur_ptr);
		if (_next_ptr)
			obj << "next" << toBSON(_next_ptr);
		return db_mgr.SaveMongo(DBN::dbPlayerShadow, key, obj.obj());
	}

	sBattlePtr playerShadow::getOwnBattlePtr(double attri_rate, double bv_rate)
	{
		if (!_cur_ptr)
		{
			_cur_ptr = getMaxBattlePtr();
			_sign_save();
		}
		sBattlePtr sb = sideBattle::CreateFrom(_cur_ptr);
		sb->battleValue *= bv_rate;
		for (unsigned i = 0; i < sb->battleMan.size(); ++i)
		{
			mBattlePtr& mbattle = sb->battleMan[i];

			mbattle->battleAttri[idx_hp] *= attri_rate;
			mbattle->battleAttri[idx_phy] *= attri_rate;
			mbattle->battleAttri[idx_phy_def] *= attri_rate;
			mbattle->battleAttri[idx_war] *= attri_rate;
			mbattle->battleAttri[idx_war_def] *= attri_rate;
			mbattle->battleAttri[idx_magic] *= attri_rate;
			mbattle->battleAttri[idx_magic_def] *= attri_rate;

			mbattle->currentHP = mbattle->getTotalAttri(idx_hp);
			mbattle->battleValue *= bv_rate;
		}
		const std::map<int, int>& target_hp = Own().Expedition().getTargetHp();
		for (unsigned i = 0; i < sb->battleMan.size(); ++i)
		{
			const mBattlePtr& m = sb->battleMan[i];
			std::map<int, int>::const_iterator it = target_hp.find(m->manID);
			if (it != target_hp.end())
			{
				m->currentHP = it->second;
			}
		}
		return sb;
	}

	sBattlePtr playerShadow::fromBSON(const mongo::BSONElement& obj)
	{
		sBattlePtr sb = Creator<sideBattle>::Create();
		sb->playerID = obj["pi"].Int();
		sb->playerLevel = obj["lv"].Int();
		sb->playerName = obj["na"].String();
		sb->battleValue = obj["bv"].Int();
		sb->playerFace = obj["fa"].Int();
		sb->playerNation = obj["kid"].Int();
		sb->isPlayer = true;
		vector<mongo::BSONElement> elems = obj["m"].Array();
		for (unsigned n = 0; n < elems.size(); ++n)
		{
			mongo::BSONElement& elem = elems[n];
			mBattlePtr mb = Creator<manBattle>::Create();
			mb->manID = elem["mid"].Int();
			mb->manLevel = elem["lv"].Int();
			mb->currentIdx = (unsigned)elem["idx"].Int();
			mb->currentHP = elem["hp"].Int();
			mb->battleValue = elem["bv"].Int();
			vector<mongo::BSONElement> ias = elem["ias"].Array();
			for (unsigned idx = 0; idx < ias.size(); ++idx)
			{
				mb->initialAttri[idx] = ias[idx].Int();
			}
			vector<mongo::BSONElement> bas = elem["bas"].Array();
			for (unsigned idx = 0; idx < bas.size(); ++idx)
			{
				mb->battleAttri[idx] = bas[idx].Int();
			}
			cfgManPtr config = man_sys.getConfig(mb->manID);
			if (!config)continue;
			if (elem["ski1"].eoo())
				mb->set_skill_1(config->skill_1);
			else
				mb->set_skill_1(elem["ski1"].Int());
			if (elem["ski2"].eoo())
				mb->set_skill_2(config->skill_2);
			else
				mb->set_skill_2(elem["ski2"].Int());
			if (!elem["tal"].eoo())
			{
				std::vector<mongo::BSONElement> ele = elem["tal"].Array();
				for (unsigned i = 0; i < ele.size(); ++i)
					mb->talent.push_back(ele[i].Int());
			}
			else
			{
				for (unsigned i = 0; i < 3; ++i)
					mb->talent.push_back(-1);
			}
			mb->armsType = config->armsType;
			mb->holdMorale = config->holdMorale;
			memcpy(mb->armsModule, config->armsModules, sizeof(mb->armsModule));
			if (sb->battleMan.empty())
			{
				sb->leaderMan = mb;
			}
			sb->battleMan.push_back(mb);
		}
		return sb;
	}

	void playerShadow::getInfo(playerDataPtr d, double attri_rate, double bv_rate, qValue& q)
	{
		if (!_cur_ptr)
		{
			_cur_ptr = getMaxBattlePtr();
			_sign_save();
		}
		sBattlePtr ptr = _cur_ptr;
		if (d->ID() == Own().ID())
		{
			ptr = sideBattle::CreateFrom(_cur_ptr);
			ptr->battleValue *= bv_rate;
			for (unsigned i = 0; i < ptr->battleMan.size(); ++i)
			{
				mBattlePtr& mbattle = ptr->battleMan[i];

				mbattle->battleAttri[idx_hp] *= attri_rate;
				mbattle->battleAttri[idx_phy] *= attri_rate;
				mbattle->battleAttri[idx_phy_def] *= attri_rate;
				mbattle->battleAttri[idx_war] *= attri_rate;
				mbattle->battleAttri[idx_war_def] *= attri_rate;
				mbattle->battleAttri[idx_magic] *= attri_rate;
				mbattle->battleAttri[idx_magic_def] *= attri_rate;

				mbattle->currentHP = mbattle->getTotalAttri(idx_hp);
				mbattle->battleValue *= bv_rate;
			}
		}
		q.addMember("id", ptr->playerID);
		q.addMember("nm", ptr->playerName);
		q.addMember("lv", ptr->playerLevel);
		q.addMember("fa", ptr->playerFace);
		int all_bv = ptr->battleValue;
		qValue ml;
		for (unsigned i = 0; i < ptr->battleMan.size(); ++i)
		{
			const mBattlePtr& m = ptr->battleMan[i];
			qValue tmp;
			tmp << m->manID << m->currentIdx << m->manLevel << m->battleValue
				<< m->currentHP;
			const std::map<int, int>& target_hp = d->Expedition().getTargetHp();
			std::map<int, int>::const_iterator it = target_hp.find(m->manID);
			if (it == target_hp.end())
				tmp << m->currentHP;
			else
			{
				if (it->second < 1)
				{
					all_bv -= m->battleValue;	
					continue;
				}
				tmp << it->second;
			}
			ml << tmp;
		}
		q.addMember("bv", all_bv);
		q.addMember("ml", ml);
	}

	mongo::BSONObj playerShadow::toBSON(const sBattlePtr& ptr)
	{
		mongo::BSONObjBuilder obj_builder;
		mongo::BSONArrayBuilder arr_builder;
		for (unsigned i = 0; i < ptr->battleMan.size(); ++i)
		{
			const mBattlePtr& m = ptr->battleMan[i];
			mongo::BSONArrayBuilder ias_builder, bas_builder, tal_builder;
			for (unsigned idx = 0; idx < characterNum; ++idx)
			{
				ias_builder.append(m->initialAttri[idx]);
				bas_builder.append(m->battleAttri[idx]);
			}
			for (unsigned idx = 0; idx < m->talent.size(); ++idx)
				tal_builder.append(m->talent[idx]);
			arr_builder << BSON("mid" << m->manID << "lv" << m->manLevel << "idx" <<
					m->currentIdx << "ias" << ias_builder.arr() << "bas" << bas_builder.arr() 
					<< "hp" << m->currentHP << "bv" << m->battleValue << "ski1" << m->get_skill_1()
					<< "ski2" << m->get_skill_2() << "tal" << tal_builder.arr());
		}
		obj_builder << strPlayerID << ptr->playerID << "lv" << ptr->playerLevel 
			<< "na" << ptr->playerName << "bv" << ptr->battleValue << "fa" << ptr->playerFace 
			<< "m" << arr_builder.arr() << "kid" << ptr->playerNation;
		return obj_builder.obj();
	}

	void playerShadow::classLoad()
	{
		mongo::BSONObj key = BSON(strPlayerID << Own().ID());
		mongo::BSONObj obj = db_mgr.FindOne(DBN::dbPlayerShadow, key);
		if (obj.isEmpty())
			return;
		checkNotEoo(obj["max"])
			_max_ptr = fromBSON(obj["max"]);
		checkNotEoo(obj["cur"])
			_cur_ptr = fromBSON(obj["cur"]);
		checkNotEoo(obj["next"])
			_next_ptr = fromBSON(obj["next"]);
	}

	void playerShadow::upMaxBattlePtr()
	{
		sBattlePtr sb = Creator<sideBattle>::Create();
		sb->playerID = Own().ID();
		sb->playerName = Own().Name();
		sb->isPlayer = true;
		sb->playerLevel = Own().LV();
		sb->playerNation = Own().Info().Nation();
		sb->playerFace = Own().Info().Face();
		sb->battleValue = GetNoEqBV(Own().getOwnDataPtr());
		manList& ml = sb->battleMan;
		ml.clear();
		vector<gg::playerManPtr> ownMan = Own().WarFM().currentFM();
		for (unsigned i = 0; i < ownMan.size(); i++)
		{
			gg::playerManPtr man = ownMan[i];
			if (!man)continue;
			mBattlePtr mbattle = Creator<manBattle>::Create();
			cfgManPtr config = man_sys.getConfig(man->armyID());
			if (!config)continue;
			mbattle->manID = man->armyID();
			mbattle->battleValue = man->noeqBattleValue();
			mbattle->holdMorale = config->holdMorale;
			mbattle->set_skill_1(man->getSkill_1());
			mbattle->set_skill_2(man->getSkill_2());
			mbattle->armsType = config->armsType;
			mbattle->manLevel = man->LV();
			mbattle->currentIdx = i % 9;
			memcpy(mbattle->armsModule, config->armsModules, sizeof(mbattle->armsModule));
			man->toInitialAttri(mbattle->initialAttri);
			man->toNoEquipAttri(Own().WarFM().currentID(), mbattle->battleAttri);
			mbattle->currentHP = mbattle->getTotalAttri(idx_hp);
			if (0 == i)
				sb->leaderMan = mbattle;
			ml.push_back(mbattle);
		}
		_max_ptr = sb;
		_sign_save();
	}
}

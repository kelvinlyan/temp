#include "patrol_system.h"
#include "chat.h"
#include "card_system.h"
#include "utility_lx.h"

namespace gg
{
	static AQConfigPtr aq_config; //�ʴ��¼�����
	static SleepConfigPtr sleep_config; //�����¼�����
	static EyeConfigPtr eye_config; //���۽��¼�����
	static FishConfigPtr fish_config; //�����¼�����
	static EnjoyFlowerConfigPtr enjoy_flower_config; //�ͻ��¼�����
	static FingerGuessConfigPtr finger_guess_config; //��ȭ�¼�����
	static AnecdoteConfigPtr anecdote_config; //Ѳ����������
	static PokerConfigPtr poker_config; //�ƻ�����
	static EndBoxConfigPtr end_config;
	static std::vector<int> rnd_odds;//����¼�����
	static std::vector<int> ans_points;//�����
	static std::vector<int> slp_points;//���޵�
	static std::vector<int> eye_points;//���۽𾦵�
	static std::vector<int> poker_points;//�ƻ������

	//�¼�����
	class EventFactory
	{
	public:
		static EventPtr createEvent(patrol::EventType type)
		{
			if (type == patrol::AnswerQuestionEvent)
			{
				return Creator<patrol_aq_event>::Create(aq_config);
			}
			else if (type == patrol::SleepEvent)
			{
				return Creator<patrol_sleep_event>::Create(sleep_config);
			}
			else if (type == patrol::FireEyeEvent)
			{
				return Creator<patrol_eye_event>::Create(eye_config);
			}
			else if (type == patrol::FishEvent)
			{
				return Creator<patrol_fish_event>::Create(fish_config);
			}
			else if (type == patrol::EnjoyFlowerEvent)
			{
				return Creator<patrol_flower_event>::Create(enjoy_flower_config);
			}
			else if (type == patrol::FingerGuessEvent)
			{
				return Creator<patrol_finger_event>::Create(finger_guess_config);
			}
			else if (type == patrol::AnecdoteEvent)
			{
				return Creator<patrol_anecdote_event>::Create(anecdote_config);
			}
			else if (type == patrol::PokerEvent)
			{
				return Creator<patrol_poker_event>::Create(poker_config);
			}
			else
			{
				return Creator<patrol_end_event>::Create(end_config);
			}
		}
	};

	patrol_system1::patrol_system1() 
	{
	}

	bool patrol_system1::isAQEvent(int pos)
	{
		return std::find(ans_points.begin(), ans_points.end(), pos) != ans_points.end();
		//return false;
	}

	bool patrol_system1::isSleepEvent(int pos)
	{
		return std::find(slp_points.begin(), slp_points.end(), pos) != slp_points.end();
		//return false;
	}

	bool patrol_system1::isFireEyeEvent(int pos)
	{
		return std::find(eye_points.begin(), eye_points.end(), pos) != eye_points.end();
		//return false;
	}

	bool patrol_system1::isEndBoxEvent(int pos)
	{
		return pos == END_POINT;
	}

	bool patrol_system1::isPokerEvent(int pos)
	{
		return std::find(poker_points.begin(), poker_points.end(), pos) != poker_points.end();
		//return true;
	}

	patrol_system1* const patrol_system1::_Instance = new patrol_system1();

	void patrol_system1::reqPatrolInfo(net::Msg& m, Json::Value& r)
	{
		playerDataPtr player = player_mgr.getPlayer(m.playerID);
		if (!player)Return(r, err_illedge);
		
		if (player->LV() < PATROL_LEVEL_LIMIT)
		{
			Return(r, err_fund_lv_not_enough);
		}
		//���������������ҵ�ǰ�¼����ǵȴ������Ӻ�δ��ʼ��ʱ����Ҫ�ؽ��¼���
		patrol::StateType state = player->Patrol().getState();
		patrol::EventType event_type = player->Patrol().getEventType();
		if (state == patrol::PatrolUninit)
		{
			player->Patrol().setState(patrol::PatrolPenddingDice);
		}
		if (!player->Patrol().isOk()
			&& (state == patrol::PatrolPenddingEvent || state == patrol::PatrolPendingBox))
		{
			//�ؽ��¼�
			if (event_type == patrol::AnswerQuestionEvent)
			{
				player->Patrol().rebuildEvent(aq_config,event_type);
			}
			else if (event_type == patrol::SleepEvent)
			{
				player->Patrol().rebuildEvent(sleep_config, event_type);
			}
			else if (event_type == patrol::FireEyeEvent)
			{
				player->Patrol().rebuildEvent(eye_config, event_type);
			}
			else if (event_type == patrol::FishEvent)
			{
				player->Patrol().rebuildEvent(fish_config, event_type);
			}
			else if (event_type == patrol::EnjoyFlowerEvent)
			{
				player->Patrol().rebuildEvent(enjoy_flower_config, event_type);
			}
			else if (event_type == patrol::FingerGuessEvent)
			{
				player->Patrol().rebuildEvent(finger_guess_config, event_type);
			}
			else if (event_type == patrol::AnecdoteEvent)
			{
				player->Patrol().rebuildEvent(anecdote_config, event_type);
			}
			else if (event_type == patrol::PokerEvent)
			{
				player->Patrol().rebuildEvent(poker_config, event_type);
			}
			/*else
			{
				player->Patrol().rebuildEvent(end_config, event_type);
			}*/
		}
		
		//LogS << "��ŮѲ��-��Ϣ��ȡ--EIndex: " << player->Patrol().getEndBoxIndex()<< LogEnd;
		if (player->Patrol().getEndBoxIndex() == -1)
		{
			//�½��յ��¼�
			//LogS << "�½��յ��¼�" << LogEnd;
			EventPtr ptr = EventFactory::createEvent(patrol::EndBoxEvent);
			player->Patrol().setEvent(ptr);
		}
		if (!player->Patrol().getEndEvent())
		{
			//�ؽ��յ��¼�
			//LogS << "�ؽ��յ��¼�" << LogEnd;
			player->Patrol().rebuildEvent(end_config, event_type);
		}
		r[strMsg][0u] = state;
		r[strMsg][1u] = event_type;
		//getPos()����Ҫ���ؽ��¼��жϺ����
		r[strMsg][2u] = player->Patrol().getPos();
		r[strMsg][3u] = player->Res().getDice();
		r[strMsg][4u] = player->Patrol().getLastDiceNum();
		r[strMsg][5u] = player->Patrol().getEndEvent()->getJson();
	}

	void patrol_system1::reqPatrolThrowDice(net::Msg& m, Json::Value& r)
	{
		playerDataPtr player = player_mgr.getPlayer(m.playerID);
		if (!player)Return(r, err_illedge);

		tm now = Common::toTm(Common::gameTime());
		if (player->Res().getDice() == 0)
		{
			Return(r, err_patrol_dice_not_enough);
		}
		else if (player->Card().isOver(2))
		{
			Return(r, err_patrol_card_full);
		}
		/*else if (now.tm_hour < 10)
		{
			Return(r, err_patrol_beyond_time);
		}*/
		else if (player->Patrol().getState() != patrol::PatrolPenddingDice)
		{
			Return(r, err_patrol_state_error);
		}

		int point = Common::randomBetween(1, 6);
		point = 1;//just for test.
		player->Patrol().setLastDiceNum(point);
		player->Patrol().setPos(point, true);
		player->Res().alterDice(-1);
		player->Daily().tickTask(DAILY::lady_dice_times);
		player->Patrol().incTotalThrowTime();

		//�¼�����
		int pos = player->Patrol().getPos();
		if (isAQEvent(pos))
		{
			player->Patrol().setEventType(patrol::AnswerQuestionEvent);
		}
		else if (isSleepEvent(pos))
		{
			player->Patrol().setEventType(patrol::SleepEvent);
		}
		else if (isFireEyeEvent(pos))
		{
			player->Patrol().setEventType(patrol::FireEyeEvent);
		}
		else if (isEndBoxEvent(pos))
		{
			player->Patrol().setEventType(patrol::EndBoxEvent);
		}
		else if (isPokerEvent(pos))
		{
			player->Patrol().setEventType(patrol::PokerEvent);
		}
		else //����¼�
		{
			//�±�0,1,2,3�ֱ��Ӧ�¼�==>���㡢�ͻ�����ȭ������
			int idx = patrol::getProbIndex(rnd_odds);
			//int idx=2;//just for test.
			//idx = 2;
			if (idx == 0)
			{
				player->Patrol().setEventType(patrol::FishEvent);
			}
			else if (idx == 1)
			{
				player->Patrol().setEventType(patrol::EnjoyFlowerEvent);
			}
			else if (idx == 2)
			{
				player->Patrol().setEventType(patrol::FingerGuessEvent);
			}
			else
			{
				player->Patrol().setEventType(patrol::AnecdoteEvent);
			}
		}
		//�����¼�
		if (player->Patrol().getEventType() != patrol::EndBoxEvent)
		{
			EventPtr eventPtr = EventFactory::createEvent(player->Patrol().getEventType());
			player->Patrol().setEvent(eventPtr);
		}
		else
		{
			if (player->Patrol().getEndBoxIndex() == -1 || !player->Patrol().getEndEvent())
			{
				//��������£������½��յ��¼�
				EventPtr ptr = EventFactory::createEvent(patrol::EndBoxEvent);
				player->Patrol().setEvent(ptr);
			}
		}
		player->Patrol().setState(patrol::PatrolPenddingEvent);

		Return(r, point);
	}
	
	void patrol_system1::reqPatrolGetCurrEvent(net::Msg& m, Json::Value& r)
	{
		playerDataPtr player = player_mgr.getPlayer(m.playerID);
		if (!player)Return(r, err_illedge);

		if (!player->Patrol().isOk() || player->Patrol().getState() == patrol::PatrolPenddingDice || player->Patrol().getState() == patrol::PatrolUninit)
		{
			Return(r, err_patrol_state_error);
		}
		r[strMsg][0u] = player->Patrol().getEventType();
		EventPtr ptr = player->Patrol().getEvent();
		if (!ptr)
		{
			Return(r, err_illedge);
		}
		r[strMsg][1u] = Json::nullValue;
		ptr->getDetail(r[strMsg][1u]);
		player->Patrol().setState(patrol::PatrolPendingBox);
	}

	void patrol_system1::reqPatrolGetReward(net::Msg& m, Json::Value& r)
	{
		playerDataPtr player = player_mgr.getPlayer(m.playerID);
		if (!player)Return(r, err_illedge);

		if (!player->Patrol().isOk() || player->Patrol().getState() != patrol::PatrolPendingBox)
		{
			Return(r, err_patrol_state_error);
		}
		ReadJsonArray;
		int flag = js_msg[0u].asInt();
		EventPtr ptr = player->Patrol().getEvent();
		//ret = actionDoBox(player, _s_event[idx].box_list2, false);
		ActionBoxList box = ptr->getBox(flag);
		patrol::EventType event_type = player->Patrol().getEventType();
		int ret = actionDoBox(player, box, false);
		if (event_type == patrol::EndBoxEvent)
		{
			//�����յ㱦��
			player->Patrol().setEndBoxIndex(-1);
			player->Patrol().setPos(1, false);
		}
		player->Patrol().setState(patrol::PatrolPenddingDice);
		r[strMsg][0u] = ret;
		if (ret == 0)
		{
			r[strMsg][1u] = actionRes();
		}
		else
		{
			r[strMsg][1u] = actionError();
		}
		Log(DBLOG::strLogPlayerCard, player, 9, ptr->getStr(flag), std::string("[[24,1]]"), player->Patrol().getEventType(), ptr->subType());
		//player->Card().getCard(0);
		//�㲥���
		if (event_type == patrol::EnjoyFlowerEvent || event_type == patrol::SleepEvent)
		{
			for (ActionBoxList::iterator it = box.begin();it != box.end(); ++it)
			{
				if (it->actionID == ACTION::lady)
				{
					cfgCardPtr card_cfg = card_sys.getConfig(it->boxData._Item.itemID);
					if (!card_cfg)
					{
						continue;
					}
					if (card_cfg->stars == 4)
					{
						qValue data_json(qJson::qj_array);
						data_json.append(chat_sys.ChatPackageQ(player)).
							append(card_cfg->cardID).append(card_cfg->beginLevel).append(0).append(event_type);
						chat_sys.despatchAll(CHAT::server_patrol_get_four_star_girl, data_json, CHATPOS::chat_windows | CHATPOS::scroll_bar_top);
					}
				}
			}
		}
		//
		if (event_type == patrol::FishEvent || event_type == patrol::EndBoxEvent)
		{
			for (ActionBoxList::iterator it = box.begin();it != box.end(); ++it)
			{
				if (it->actionID == ACTION::gold || it->actionID == ACTION::ticket)
				{
					if (it->boxData._Res.val == 100)
					{
						qValue data_json(qJson::qj_array);
						data_json.append(chat_sys.ChatPackageQ(player)).
							append(it->boxData._Res.val).append(event_type);
						chat_sys.despatchAll(CHAT::server_patrol_get_hundred_gold, data_json, CHATPOS::chat_windows | CHATPOS::scroll_bar_top);
					}
				}
			}
		}
		
	}

	void patrol_system1::reqPatrolBolkTen(net::Msg& m, Json::Value& r)
	{
		playerDataPtr player = player_mgr.getPlayer(m.playerID);
		if (!player)Return(r, err_illedge);

		if (player->LV() < 40)
		{
			Return(r, err_patrol_bolk_not_enough);
		}
		if (player->Res().getCash() < 5)
		{
			Return(r, err_cash_not_enough);
		}
		if (player->Res().getDice() < 10)
		{
			Return(r, err_patrol_dice_not_enough);
		}
		if (player->Patrol().getState() != patrol::PatrolPenddingDice)
		{
			Return(r, err_patrol_state_error);
		}
		if (player->Card().isOver(slp_points.size() * 2 + (10 - slp_points.size())))
		{
			Return(r, err_patrol_card_full);
		}
		player->Res().alterCash(-5);
		//player->Res().alterDice(-10);
		Json::Value detail_set = Json::arrayValue;
		Json::Value boxes_log = Json::arrayValue;
		for (int i = 0; i < 10; ++i)
		{
			Json::Value unit = Json::arrayValue;
			//1.������
			int point = Common::randomBetween(1, 6);
			player->Patrol().setLastDiceNum(point);
			player->Patrol().setPos(point, true);
			player->Res().alterDice(-1);
			player->Daily().tickTask(DAILY::lady_dice_times);
			player->Patrol().incTotalThrowTime();
			unit.append(point);//=>.1

			//2.���õ�ǰ�¼�
			int pos = player->Patrol().getPos();
			{
				if (isAQEvent(pos))
				{
					player->Patrol().setEventType(patrol::AnswerQuestionEvent);
				}
				else if (isSleepEvent(pos))
				{
					player->Patrol().setEventType(patrol::SleepEvent);
				}
				else if (isFireEyeEvent(pos))
				{
					player->Patrol().setEventType(patrol::FireEyeEvent);
				}
				else if (isEndBoxEvent(pos))
				{
					player->Patrol().setEventType(patrol::EndBoxEvent);
				}
				else if (isPokerEvent(pos))
				{
					player->Patrol().setEventType(patrol::PokerEvent);
				}
				else //����¼�
				{
					int idx = patrol::getProbIndex(rnd_odds);
					if (idx == 0)
					{
						player->Patrol().setEventType(patrol::FishEvent);
					}
					else if (idx == 1)
					{
						player->Patrol().setEventType(patrol::EnjoyFlowerEvent);
					}
					else if (idx == 2)
					{
						player->Patrol().setEventType(patrol::FingerGuessEvent);
					}
					else
					{
						player->Patrol().setEventType(patrol::AnecdoteEvent);
					}
				}
				/*�����¼�*/
				if (player->Patrol().getEventType() != patrol::EndBoxEvent)
				{
					EventPtr eventPtr = EventFactory::createEvent(player->Patrol().getEventType());
					player->Patrol().setEvent(eventPtr);
				}
				else
				{
					if (player->Patrol().getEndBoxIndex() == -1 || !player->Patrol().getEndEvent())
					{
						//��������£������½��յ��¼�
						EventPtr ptr = EventFactory::createEvent(patrol::EndBoxEvent);
						player->Patrol().setEvent(ptr);
					}
				}
				player->Patrol().setState(patrol::PatrolPenddingEvent);
			}
			EventPtr ptr = player->Patrol().getEvent();
			if (!ptr)
			{
				continue;//???
			}
			Json::Value detail = Json::nullValue;
			ptr->getDetail(detail);
			player->Patrol().setState(patrol::PatrolPendingBox);
			patrol::EventType event_type = player->Patrol().getEventType();
			unit.append(event_type);//=>.2
			unit.append(detail);//=>.3
			//��ȡ����
			int flag;
			{
				if (event_type == patrol::AnswerQuestionEvent)
				{
					flag = 0;
				}
				else if (event_type == patrol::SleepEvent)
				{
					flag = Common::randomBetween(1, 35);
				}
				else if (event_type == patrol::FireEyeEvent)
				{
					flag = 0;
				}
				else if (event_type == patrol::FishEvent)
				{
					flag = -1;
				}
				else if (event_type == patrol::EnjoyFlowerEvent)
				{
					flag = -1;
				}
				else if (event_type == patrol::FingerGuessEvent)
				{
					flag = 0;
				}
				else if (event_type == patrol::AnecdoteEvent)
				{
					flag = 1;
				}
				else if (event_type == patrol::EndBoxEvent)
				{
					flag = -1;
				}
				else
				{
					flag = 0;
				}
			}
			ActionBoxList box = ptr->getBox(flag);
			int ret = actionDoBox(player, box, false);
			player->Patrol().setState(patrol::PatrolPenddingDice);
			//����
			unit.append(ret);//=>.4
			Json::Value ret_desc;
			if (ret == res_sucess)
			{
				ret_desc = actionRes();
			}
			else
			{
				ret_desc = actionError();
			}
			unit.append(ret_desc);//=>.5
			detail_set.append(unit);
			//������LOG
			Json::Value jsonBox = ptr->getBoxJson(flag);
			combineActionRes(jsonBox, boxes_log);
			//�㲥���
			if (event_type == patrol::EnjoyFlowerEvent || event_type == patrol::SleepEvent)
			{
				for (ActionBoxList::iterator it = box.begin();it != box.end(); ++it)
				{
					if (it->actionID == ACTION::lady)
					{
						cfgCardPtr card_cfg = card_sys.getConfig(it->boxData._Item.itemID);
						if (!card_cfg)
						{
							continue;
						}
						if (card_cfg->stars == 4)
						{
							qValue data_json(qJson::qj_array);
							data_json.append(chat_sys.ChatPackageQ(player)).
								append(card_cfg->cardID).append(card_cfg->beginLevel).append(0).append(event_type);
							chat_sys.despatchAll(CHAT::server_patrol_get_four_star_girl, data_json, CHATPOS::chat_windows | CHATPOS::scroll_bar_top);
						}
					}
				}
			}
			//
			if (event_type == patrol::FishEvent || event_type == patrol::EndBoxEvent)
			{
				for (ActionBoxList::iterator it = box.begin();it != box.end(); ++it)
				{
					if (it->actionID == ACTION::gold || it->actionID == ACTION::ticket)
					{
						if (it->boxData._Res.val == 100)
						{
							qValue data_json(qJson::qj_array);
							data_json.append(chat_sys.ChatPackageQ(player)).
								append(it->boxData._Res.val).append(event_type);
							chat_sys.despatchAll(CHAT::server_patrol_get_hundred_gold, data_json, CHATPOS::chat_windows | CHATPOS::scroll_bar_top);
						}
					}
				}
			}
			if (event_type == patrol::EndBoxEvent)
			{
				//�����յ㱦��
				player->Patrol().setEndBoxIndex(-1);
				player->Patrol().setPos(1, false);
				//break;
			}
		}
		r[strMsg][0u] = 0;
		r[strMsg][1u] = detail_set;
		//LogS << "patrol combine box before:" << boxes_log.toIndentString() << LogEnd;
		lx::utility_lx::switchToLogJson(boxes_log);
		//LogS << "patrol combine box after:" << boxes_log.toIndentString() << LogEnd;

		Log(DBLOG::strLogPlayerCard, player, 10, 5, detail_set.size(), boxes_log.toIndentString());
	}
	
	void patrol_system1::initData()
	{
		aq_config = Creator<patrol::AQConfig>::Create();
		sleep_config = Creator<patrol::SleepConfig>::Create();
		eye_config = Creator<patrol::EyeConfig>::Create();
		fish_config = Creator<patrol::FishConfig>::Create();
		enjoy_flower_config = Creator<patrol::EnjoyFlowerConfig>::Create();
		finger_guess_config = Creator<patrol::FingerGuessConfig>::Create();
		anecdote_config = Creator<patrol::AnecdoteConfig>::Create();
		end_config = Creator<patrol::EndBoxConfig>::Create();
		poker_config = Creator<patrol::PokerConfig>::Create();

		std::cout << "load ./cardconfig/patrol1.json START	" << std::endl;
		Json::Value value = Common::loadJsonFile(std::string("./instance/cardconfig/patrol1.json"));
		Json::Value rnd_odds_json = value["odds"];
		assert(rnd_odds_json.size() == 4);
		rnd_odds.resize(5);
		rnd_odds[0] = 0;
		for (int i = 0; i < rnd_odds_json.size(); ++i)
		{
			rnd_odds[i + 1] = rnd_odds_json[i].asInt();
			rnd_odds[i + 1] += rnd_odds[i];
		}
		assert(rnd_odds.back() == ODDS_SUM);
		//
		Json::Value slp_points_json = value["slp_point"];
		Json::Value ans_points_json = value["ans_point"];
		Json::Value eye_points_json = value["eye_point"];
		Json::Value poker_points_json = value["poker_point"];
		for (int i = 0; i < slp_points_json.size(); ++i)
		{
			slp_points.push_back(slp_points_json[i].asInt());
		}
		for (int i = 0; i < ans_points_json.size(); ++i)
		{
			ans_points.push_back(ans_points_json[i].asInt());
		}
		for (int i = 0; i < eye_points_json.size(); ++i)
		{
			eye_points.push_back(eye_points_json[i].asInt());
		}
		for (int i = 0; i < poker_points_json.size(); ++i)
		{
			poker_points.push_back(poker_points_json[i].asInt());
		}
		//�ʴ��¼�
		Json::Value ans_event_json = value["ans_event"];
		for (int i = 0; i < ans_event_json.size(); ++i)
		{
			patrol::QuestionSingle single;
			single.id = ans_event_json[i]["id"].asInt();
			Json::Value subj = ans_event_json[i]["subject"];
			single.subject.topic = subj["topic"].asString();
			for (int j = 0; j < subj["opt"].size(); ++j)
			{
				single.subject.options.push_back(subj["opt"][j].asString());
			}
			single.subject.ans = subj["ans"].asInt();
			single.box = actionFormatBox(ans_event_json[i]["box"]);
			single.doubleBox = actionFormatBox(ans_event_json[i]["box2"]);
			single.strBox = parseJsonBox(ans_event_json[i]["box"]);
			single.jsonBox = parseJson(ans_event_json[i]["box"]);
			single.strDoubleBox = parseJsonBox(ans_event_json[i]["box2"]);
			single.jsonDoubleBox = parseJson(ans_event_json[i]["box2"]);
			aq_config->questions.push_back(single);
		}

		//���۽�
		Json::Value eye_event_json = value["eye_event"];
		eye_config->odds.resize(eye_event_json.size() + 1);
		eye_config->odds[0] = 0;
		for (int i = 0; i < eye_event_json.size(); ++i)
		{
			patrol::EyeSingle single;
			single.id = eye_event_json[i]["id"].asInt();
			single.box = actionFormatBox(eye_event_json[i]["box"]);
			single.doubleBox = actionFormatBox(eye_event_json[i]["box2"]);
			single.strBox = parseJsonBox(eye_event_json[i]["box"]);
			single.strDoubleBox = parseJsonBox(eye_event_json[i]["box2"]);
			single.jsonBox = parseJson(eye_event_json[i]["box"]);
			single.jsonDoubleBox = parseJson(eye_event_json[i]["box2"]);
			single.weight = eye_event_json[i]["weight"].asInt();
			eye_config->odds[i + 1] = single.weight;
			eye_config->odds[i + 1] += eye_config->odds[i];
		}
		if (eye_event_json.size() > 0)
		{
			assert(eye_config->odds.back() == ODDS_SUM);
		}

		//�����¼�
		Json::Value slp_event_json = value["slp_event"];
		sleep_config->odds.resize(slp_event_json.size() + 1);
		sleep_config->odds[0] = 0;
		for (int i = 0; i < slp_event_json.size(); ++i)
		{
			patrol::BoxSingle single;
			single.id = slp_event_json[i]["id"].asInt();
			single.box = actionFormatBox(slp_event_json[i]["box"]);
			single.strBox = parseJsonBox(slp_event_json[i]["box"]);
			single.jsonBox = parseJson(slp_event_json[i]["box"]);
			single.weight = slp_event_json[i]["weight"].asInt();
			sleep_config->beauty.push_back(single);
			sleep_config->odds[i + 1] = single.weight;
			sleep_config->odds[i + 1] += sleep_config->odds[i];

			sleep_config->rawBox.push_back(slp_event_json[i]["box"]);
		}
		///unit test start.
		/*Json::Value from = sleep_config->rawBox[0];
		Json::Value to = sleep_config->rawBox[1];
		combineJsonBox(from, to);
		std::string aastr = parseJsonBox(to);
		from = sleep_config->rawBox[52];
		to = sleep_config->rawBox[53];
		combineJsonBox(from, to);
		aastr = parseJsonBox(to);*/
		///unit test end.
		assert(sleep_config->odds.back() == ODDS_SUM);
		///���������¼���������flags
		/*sleep_config->flags.resize(7);
		sleep_config->flags[0] = 0;
		int mean = sleep_config->beauty.size() / 6;
		int rest = sleep_config->beauty.size() - mean * 6;
		for (int i = 0; i < 6; ++i)
		{
			sleep_config->flags[i + 1] = mean;
			if (rest > 0)
			{
				sleep_config->flags[i + 1] += 1;
				--rest;
			}
			sleep_config->flags[i + 1] += sleep_config->flags[i];
		}
		assert(sleep_config->flags[6] == sleep_config->beauty.size());*/
		///END
		//�����¼�
		Json::Value fish_event_json = value["fish_event"];
		assert(fish_event_json["odds"].size() == 3);
		fish_config->odds.resize(4);
		fish_config->odds[0] = 0;
		for (int i = 0; i < fish_event_json["odds"].size(); ++i)
		{
			fish_config->odds[i + 1] = fish_event_json["odds"][i].asInt();
			fish_config->odds[i + 1] += fish_config->odds[i];
		}
		assert(fish_config->odds.back() == ODDS_SUM);

		Json::Value luck = fish_event_json["luck"];
		fish_config->oddsLuck.resize(luck.size() + 1);
		fish_config->oddsLuck[0] = 0;
		for (int i = 0; i < luck.size(); ++i)
		{
			patrol::BoxSingle single;
			single.id = luck[i]["id"].asInt();
			single.box = actionFormatBox(luck[i]["box"]);
			single.strBox = parseJsonBox(luck[i]["box"]);
			single.jsonBox = parseJson(luck[i]["box"]);
			single.weight = luck[i]["weight"].asInt();
			fish_config->luck.push_back(single);
			fish_config->oddsLuck[i + 1] = single.weight;
			fish_config->oddsLuck[i + 1] += fish_config->oddsLuck[i];
		}
		assert(fish_config->oddsLuck.back() == ODDS_SUM);

		Json::Value present = fish_event_json["present"];
		fish_config->oddsGift.resize(present.size() + 1);
		fish_config->oddsGift[0] = 0;
		for (int i = 0; i < present.size(); ++i)
		{
			patrol::BoxSingle single;
			single.id = present[i]["id"].asInt();
			single.box = actionFormatBox(present[i]["box"]);
			single.strBox = parseJsonBox(present[i]["box"]);
			single.jsonBox = parseJson(present[i]["box"]);
			single.weight = present[i]["weight"].asInt();
			fish_config->gift.push_back(single);
			fish_config->oddsGift[i + 1] = single.weight;
			fish_config->oddsGift[i + 1] += fish_config->oddsGift[i];
		}
		assert(fish_config->oddsGift.back() == ODDS_SUM);
		Json::Value emptyBox("[]");
		fish_config->emptyBox = actionFormatBox(emptyBox);
		fish_config->strEmptyBox = parseJsonBox(Json::Value("[]"));
		fish_config->jsonEmptyBox = parseJson(Json::Value("[]"));

		//�ͻ��¼�
		Json::Value flower_event_json = value["rose_event"];
		assert(flower_event_json["odds"].size() == 4);
		enjoy_flower_config->odds.resize(5);
		enjoy_flower_config->odds[0] = 0;
		for (int i = 0; i < flower_event_json["odds"].size(); ++i)
		{
			enjoy_flower_config->odds[i + 1] = flower_event_json["odds"][i].asInt();
			enjoy_flower_config->odds[i + 1] += enjoy_flower_config->odds[i];
		}
		assert(enjoy_flower_config->odds.back() == ODDS_SUM);
		/*enjoy_flower_config->boxAgain = actionFormatBox(flower_event_json["again"]);
		enjoy_flower_config->boxMeet = actionFormatBox(flower_event_json["meet"]);
		enjoy_flower_config->boxTalk = actionFormatBox(flower_event_json["talk"]);*/
		enjoy_flower_config->boxPlay = actionFormatBox(emptyBox);
		/*enjoy_flower_config->strAgain = parseJsonBox(flower_event_json["again"]);
		enjoy_flower_config->strMeet = parseJsonBox(flower_event_json["meet"]);
		enjoy_flower_config->strTalk = parseJsonBox(flower_event_json["talk"]);*/
		enjoy_flower_config->strPlay = parseJsonBox(Json::Value("[]"));
		/*enjoy_flower_config->jsonAgain = parseJson(flower_event_json["again"]);
		enjoy_flower_config->jsonMeet = parseJson(flower_event_json["meet"]);
		enjoy_flower_config->jsonTalk = parseJson(flower_event_json["talk"]);*/
		enjoy_flower_config->jsonPlay = parseJson(Json::Value("[]"));

		///ż������
		Json::Value meet_json = flower_event_json["meet"];
		enjoy_flower_config->meetOdds.resize(meet_json.size() + 1);
		enjoy_flower_config->meetOdds[0] = 0;
		for (int i = 0; i < meet_json.size(); ++i)
		{
			patrol::BoxSingle single;
			single.id = meet_json[i]["id"].asInt();
			single.box = actionFormatBox(meet_json[i]["box"]);
			single.jsonBox = parseJson(meet_json[i]["box"]);
			single.strBox = parseJsonBox(meet_json[i]["box"]);
			single.weight = meet_json[i]["weight"].asInt();
			enjoy_flower_config->meetBoxes.push_back(single);
			enjoy_flower_config->meetOdds[i + 1] = single.weight;
			enjoy_flower_config->meetOdds[i + 1] += enjoy_flower_config->meetOdds[i];
		}
		assert(enjoy_flower_config->meetOdds.back() == ODDS_SUM);
		///�黰����
		Json::Value talk_json = flower_event_json["talk"];
		enjoy_flower_config->talkOdds.resize(talk_json.size() + 1);
		enjoy_flower_config->talkOdds[0] = 0;
		for (int i = 0; i < talk_json.size(); ++i)
		{
			patrol::BoxSingle single;
			single.id = talk_json[i]["id"].asInt();
			single.box = actionFormatBox(talk_json[i]["box"]);
			single.jsonBox = parseJson(talk_json[i]["box"]);
			single.strBox = parseJsonBox(talk_json[i]["box"]);
			single.weight = talk_json[i]["weight"].asInt();
			enjoy_flower_config->talkBoxes.push_back(single);
			enjoy_flower_config->talkOdds[i + 1] = single.weight;
			enjoy_flower_config->talkOdds[i + 1] += enjoy_flower_config->talkOdds[i];
		}
		assert(enjoy_flower_config->talkOdds.back() == ODDS_SUM);
		///��������
		Json::Value again_json = flower_event_json["again"];
		enjoy_flower_config->againOdds.resize(again_json.size() + 1);
		enjoy_flower_config->againOdds[0] = 0;
		for (int i = 0; i < again_json.size(); ++i)
		{
			patrol::BoxSingle single;
			single.id = again_json[i]["id"].asInt();
			single.box = actionFormatBox(again_json[i]["box"]);
			single.jsonBox = parseJson(again_json[i]["box"]);
			single.strBox = parseJsonBox(again_json[i]["box"]);
			single.weight = again_json[i]["weight"].asInt();
			enjoy_flower_config->againBoxes.push_back(single);
			enjoy_flower_config->againOdds[i + 1] = single.weight;
			enjoy_flower_config->againOdds[i + 1] += enjoy_flower_config->againOdds[i];
		}
		assert(enjoy_flower_config->againOdds.back() == ODDS_SUM);
		 
		//��ȭ�¼�
		Json::Value finger_event_json = value["guess_event"];
		Json::Value succ_json = finger_event_json["succ"];
		finger_guess_config->succOdds.resize(succ_json.size() + 1);
		finger_guess_config->succOdds[0] = 0;
		for (int i = 0; i < succ_json.size(); ++i)
		{
			patrol::BoxSingle single;
			single.id = succ_json[i]["id"].asInt();
			single.box = actionFormatBox(succ_json[i]["box"]);
			single.strBox = parseJsonBox(succ_json[i]["box"]);
			single.jsonBox = parseJson(succ_json[i]["box"]);
			single.weight = succ_json[i]["weight"].asInt();
			finger_guess_config->succ.push_back(single);
			finger_guess_config->succOdds[i + 1] = single.weight;
			finger_guess_config->succOdds[i + 1] += finger_guess_config->succOdds[i];
		}
		assert(finger_guess_config->succOdds.back() == ODDS_SUM);
		//
		Json::Value fail_json = finger_event_json["fail"];
		finger_guess_config->failOdds.resize(fail_json.size() + 1);
		finger_guess_config->failOdds[0] = 0;
		for (int i = 0; i < fail_json.size(); ++i)
		{
			patrol::BoxSingle single;
			single.id = fail_json[i]["id"].asInt();
			single.box = actionFormatBox(fail_json[i]["box"]);
			single.strBox = parseJsonBox(fail_json[i]["box"]);
			single.jsonBox = parseJson(fail_json[i]["box"]);
			single.weight = fail_json[i]["weight"].asInt();
			finger_guess_config->fail.push_back(single);
			finger_guess_config->failOdds[i + 1] = single.weight;
			finger_guess_config->failOdds[i + 1] += finger_guess_config->failOdds[i];
		}
		assert(finger_guess_config->failOdds.back() == ODDS_SUM);
		
		//Ѳ������
		Json::Value anecdote_event_json = value["appr_event"];
		anecdote_config->odds.resize(anecdote_event_json.size() + 1);
		anecdote_config->odds[0] = 0;
		for (int i = 0; i < anecdote_event_json.size(); ++i)
		{
			patrol::AnecdoteSingle single;
			single.id = anecdote_event_json[i]["id"].asInt();
			Json::Value subj = anecdote_event_json[i]["subject"];
			assert(subj["opt"].size() == subj["boxes"].size());
			single.subject.topic = subj["topic"].asString();
			for (int j = 0; j < subj["opt"].size(); ++j)
			{
				single.subject.options.push_back(subj["opt"][j].asString());
				single.boxes.push_back(actionFormatBox(subj["boxes"][j]));
				single.strBoxes.push_back(parseJsonBox(subj["boxes"][j]));
				single.jsonBoxes.push_back(parseJson(subj["boxes"][j]));
			}
			single.weight = anecdote_event_json[i]["weight"].asInt();
			anecdote_config->anecdotes.push_back(single);
			anecdote_config->odds[i + 1] = single.weight;
			anecdote_config->odds[i + 1] += anecdote_config->odds[i];
		}

		//�ƻ�����
		Json::Value poker_event_json = value["card_event"];
		poker_config->odds.resize(poker_event_json["odds"].size() + 1);
		poker_config->odds[0] = 0;
		for (int i = 0; i < poker_event_json["odds"].size(); ++i)
		{
			poker_config->odds[i + 1] = poker_event_json["odds"][i].asInt();
			poker_config->odds[i + 1] += poker_config->odds[i];
		}
		assert(poker_config->odds.back() == ODDS_SUM);
		poker_config->subOdds.resize(poker_event_json["boxes"].size() + 1);
		poker_config->subOdds[0] = 0;
		for (int i = 0; i < poker_event_json["boxes"].size(); ++i)
		{
			patrol::EyeSingle single;
			single.id = poker_event_json["boxes"][i]["id"].asInt();
			single.box = actionFormatBox(poker_event_json["boxes"][i]["box"]);
			single.doubleBox = actionFormatBox(poker_event_json["boxes"][i]["box2"]);
			single.strBox = parseJsonBox(poker_event_json["boxes"][i]["box"]);
			single.strDoubleBox = parseJsonBox(poker_event_json["boxes"][i]["box2"]);
			single.jsonBox = parseJson(poker_event_json["boxes"][i]["box"]);
			single.jsonDoubleBox = parseJson(poker_event_json["boxes"][i]["box2"]);
			single.weight = poker_event_json["boxes"][i]["weight"].asInt();
			poker_config->subOdds[i + 1] = single.weight;
			poker_config->subOdds[i + 1] += poker_config->subOdds[i];
			poker_config->boxes.push_back(single);
		}
		assert(poker_config->subOdds.back() == ODDS_SUM);

		//�յ㱦��
		Json::Value box_event_json = value["box_event"];
		end_config->odds.resize(box_event_json.size() + 1);
		for (int i = 0; i < box_event_json.size(); ++i)
		{
			patrol::BoxSingle single;
			single.id = box_event_json[i]["id"].asInt();
			single.box = actionFormatBox(box_event_json[i]["box"]);
			single.strBox = parseJsonBox(box_event_json[i]["box"]);
			single.jsonBox = parseJson(box_event_json[i]["box"]);
			single.weight = box_event_json[i]["weight"].asInt();
			end_config->odds[i + 1] = single.weight;
			end_config->odds[i + 1] += end_config->odds[i];
			end_config->boxes.push_back(single);
		}
		assert(end_config->odds.back() == ODDS_SUM);

		std::cout << "load ./cardconfig/patrol1.json END" << std::endl;
	}

	patrol_system1::~patrol_system1() {}
}

/*
namespace gg
{
	patrol_system* const patrol_system::_Instance = new patrol_system();
	STDVECTOR(std::string, logStr);
	STDVECTOR(Json::Value, specialRewardFormat);

	logStr logHalf;
	logStr logAll;
	logStr logEnd;
	specialRewardFormat jsonFormatPre;
	specialRewardFormat jsonFormatLater;

	////��ʼ��ȫ�������������
	//static boost::random::mt19937 gen(Common::gameTime());
	////�ֲ��������������ӳ�䵽[1,6]
	//static const boost::random::uniform_int_distribution<> dist(1, 6);

	patrol_system::patrol_system()
	{
	}


	void patrol_system::initData()
	{
		BOOST_STATIC_ASSERT(EVENT_NUM == 6);
		_r_event[0].id = 1;
		_r_event[0].type = patrol::PatrolOneStar;
		_r_event[1].id = 2;
		_r_event[1].type = patrol::PatrolTwoStar;
		_r_event[2].id = 3;
		_r_event[2].type = patrol::PatrolThreeStar;
		_r_event[3].id = 4;
		_r_event[3].type = patrol::PatrolLadyCoin;
		_r_event[4].id = 5;
		_r_event[4].type = patrol::PatrolDice;
		_r_event[5].id = 6;
		_r_event[5].type = patrol::PatrolNone;

		_odds[0] = 0;
		int i = 0;

		std::cout << "load ./cardconfig/patrol.json" << std::endl;

		Json::Value value = Common::loadJsonFile(std::string("./instance/cardconfig/patrol.json"));
		Json::Value spots = value["s_port"];
		for (i = 0; i < spots.size(); ++i)
		{
			_spot.push_back(spots[i].asInt());
		}

		Json::Value odds = value["odds"];

		std::cout << "odds size:" << odds.size() << std::endl;
		assert(EVENT_NUM == odds.size());//
		
		for (i = 0; i < odds.size(); ++i)
		{
			_odds[i + 1] = odds[i].asInt();
			_odds[i + 1] += _odds[i];
		}
		assert(_odds[i] == ODDS_SUM);

		Json::Value s_event = value["s_event"];
		int j = 0;
		for (i = 0; i < s_event.size(); ++i)
		{
			SpecialEvent se;
			//s_id
			se.id = s_event[i]["s_id"].asInt();
			//subject
			Json::Value subject = s_event[i]["subject"];
			se.subject.topic = subject["topic"].asString();
			for (j = 0; j < subject["opt"].size(); ++j)
			{
				se.subject.option.push_back(subject["opt"][j].asString());
			}
			se.subject.ansIdx = subject["ans"].asInt();
			//box
			se.box_list = actionFormatBox(s_event[i]["box"]);
			//box2
			se.box_list2 = actionFormatBox(s_event[i]["box2"]);
			Json::Value box = s_event[i]["box"];
			jsonFormatPre.push_back(box);
			jsonFormatLater.push_back(box);
			std::string strLog("[");
			std::string strLogA("[");
			for (j = 0; j < box.size(); ++j)
			{
				int id = box[j]["aID"].asInt();
				int v = box[j]["v"].asInt();
				strLog += "[";
				strLog += boost::lexical_cast<std::string>(id);
				strLog += ",";
				strLog += boost::lexical_cast<std::string>(v);
				strLog += "]";
				if (j != box.size() - 1)
				{
					strLog += ",";
				}
				//logA
				strLogA += "[";
				strLogA += boost::lexical_cast<std::string>(id);
				strLogA += ",";
				strLogA += boost::lexical_cast<std::string>(v*2);
				strLogA += "]";
				if (j != box.size() - 1)
				{
					strLogA += ",";
				}
			}
			strLog += "]";
			strLogA += "]";
			logHalf.push_back(strLog);
			logAll.push_back(strLogA);
			//push_back()
			_s_event.push_back(se);
		}

		Json::Value e_box = value["end_box"];
		_e_odds.push_back(0);
		
		for (i = 0; i < e_box.size(); ++i)
		{
			_e_event.push_back(actionFormatBox(e_box[i]["box"]));
			_e_odds.push_back(e_box[i]["weight"].asInt() + _e_odds.back());

			std::string strLogE("[");
			Json::Value box = e_box[i]["box"];
			for (j = 0; j < box.size(); ++j)
			{
				int id = box[j]["aID"].asInt();
				int v = box[j]["v"].asInt();
				strLogE += "[";
				strLogE += boost::lexical_cast<std::string>(id);
				strLogE += ",";
				strLogE += boost::lexical_cast<std::string>(v);
				if (id == 14)
				{
					strLogE += ",";
					strLogE += boost::lexical_cast<std::string>(box[j]["id"].asInt());
				}
				strLogE += "]";
				if (j != box.size() - 1)
				{
					strLogE += ",";
				}
			}
			strLogE += "]";
			logEnd.push_back(strLogE);
		}

		assert(_e_odds.back() == ODDS_SUM);

		_star_id_group.resize(STAR_LEVEL_LIMIT);
		std::cout << "load ./instance/cards/----patrol_system" << std::endl;
		FileJsonSeq vec = Common::loadFileJsonFromDir("./instance/cards/");
		int starLv;
		for (unsigned i = 0; i < vec.size(); ++i)
		{
			Json::Value& json = vec[i];
			starLv = json["stars"].asInt();
			if (starLv > 0 && starLv <= STAR_LEVEL_LIMIT)
			{
				_star_id_group[starLv - 1].push_back(json["cardID"].asInt());
			}
			else
			{
				LogE << "card...star level invalid...in patrol_system" << LogEnd;
			}

		}

	}

	patrol_system::~patrol_system()
	{
	}

	patrol::RandomEvent patrol_system::getRandomEvent()
	{
		int target = Common::randomBetween(0, ODDS_SUM - 1);
		size_t idx = 0;//����¼����±�
		for (int i = 0; i < EVENT_NUM; ++i)
		{
			if (target >= _odds[i] && target < _odds[i + 1])
			{
				idx = i;
				break;
			}
		}

		//patrol::RandomEvent event = _r_event[idx];

		//fillRandomEvent(event);

		return _r_event[idx];
	}

	void patrol_system::fillRandomEvent(patrol::RandomEvent & event)
	{
		if (event.type == patrol::PatrolLadyCoin
			|| event.type == patrol::PatrolNone
			|| event.type == patrol::PatrolDice)
		{
			return;
		}
		if (event.type == patrol::PatrolOneStar)
		{
			//1�ǣ�1��3��
			event.level = Common::randomBetween(1, 3);
			event.cardId = _star_id_group[0][Common::randomBetween(0, _star_id_group[0].size() - 1)];
		}
		if (event.type == patrol::PatrolTwoStar)
		{
			//2�ǣ�4��6��
			event.level = Common::randomBetween(1, 3);
			event.cardId = _star_id_group[1][Common::randomBetween(0, _star_id_group[1].size() - 1)];
		}
		if (event.type == patrol::PatrolThreeStar)
		{
			//3�ǣ�7��9��
			event.level = Common::randomBetween(1, 3);
			event.cardId = _star_id_group[2][Common::randomBetween(0, _star_id_group[2].size() - 1)];
		}
	}

	bool patrol_system::isSpecialSpot(unsigned pos)
	{
		return std::find(_spot.begin(), _spot.end(), pos) != _spot.end();
	}

	void patrol_system::reqPatrolInfo(net::Msg& m, Json::Value& r)
	{
		playerDataPtr player = player_mgr.getPlayer(m.playerID);
		if (!player)Return(r, err_illedge);

		//player->Res().alterDice(20);//just for test
		//tm now = Common::toTm(Common::gameTime());
		//if (now.tm_hour < 10)
		//{
		//	Return(r, err_patrol_beyond_time);
		//}


		Json::Value json = Json::nullValue;
		json[0u] = (int)player->Patrol().getState();
		json[1u] = player->Patrol().getPos();
		int e_id = player->Patrol().getEndPointIdx();
		if (e_id == -1)
		{
			int target = Common::randomBetween(0, ODDS_SUM - 1);
			for (int i = 0; i < _e_odds.size() - 1; ++i)
			{
				if (target >= _e_odds[i] && target < _e_odds[i + 1])
				{
					e_id = i;
					break;
				}
			}
			player->Patrol().setEndPointIdx(e_id);
		}
		json[2u] = e_id;
		json[3u] = player->Res().getDice();
		json[4u] = player->Patrol().getLastDiceNum();

		r[strMsg][0u] = 0;
		r[strMsg][1u] = json;
		if (player->Patrol().getState() == patrol::PatrolUninit)
		{
			player->Patrol().setState(patrol::PatrolPenddingDice);
		}
	}

	void patrol_system::reqPatrolThrowDice(net::Msg& m, Json::Value& r)
	{
		playerDataPtr player = player_mgr.getPlayer(m.playerID);
		if (!player)Return(r, err_illedge);

		tm now = Common::toTm(Common::gameTime());
		if (player->Res().getDice() == 0)
		{
			Return(r, err_patrol_dice_not_enough);
		}
		else if (player->Card().isOver())
		{
			Return(r, err_patrol_card_full);
		}
		else if (now.tm_hour < 10)
		{
			Return(r, err_patrol_beyond_time);
		}
		else if (player->Patrol().getState() != patrol::PatrolPenddingDice)
		{
			Return(r, err_patrol_state_error);
		}

		int point = Common::randomBetween(1, 6);
		player->Patrol().setLastDiceNum(point);
		//int point = 1;
		player->Patrol().setPos(point, true);
		player->Patrol().setState(patrol::PatrolPenddingEvent);
		player->Res().alterDice(-1);
		player->Daily().tickTask(DAILY::lady_dice_times);
		player->Patrol().incTotalThrowTime();
		Return(r, point);
		
	}

	void patrol_system::reqPatrolGetCurrEvent(net::Msg& m, Json::Value& r)
	{
		
		//�Ƿ�������㣿
		//1. �����
		//		�������ñ����ʷ������ñ��еĽ���
		//2. ����¼�
		//		����¼����ͣ���ͬ���¼������в�ͬ�ķ��ؽṹ��
		//			--������Ů�Ǽ���ȡ��Ů������ȼ�
		//3. �յ��¼�
		//		�������ñ����ʷ��ز�ͬ�Ľ������
		
		playerDataPtr player = player_mgr.getPlayer(m.playerID);
		if (!player)Return(r, err_illedge);

		tm now = Common::toTm(Common::gameTime());
		//if (player->Patrol().getState() != patrol::PatrolPenddingEvent)
		//{
		//	Return(r, err_patrol_state_error);
		//}
		//else
		if (now.tm_hour < 10)
		{
			Return(r, err_patrol_beyond_time);
		}


		Json::Value detail = Json::Value::null;
		if (!isSpecialSpot(player->Patrol().getPos()) && player->Patrol().getPos() != END_POINT)
		{
			//����¼�
			r[strMsg][0u] = 1;
			patrol::RandomEvent event;
			if (player->Patrol().getState() == patrol::PatrolPenddingEvent)
			{
				event = getRandomEvent();
				fillRandomEvent(event);
				player->Patrol().setRandomEvent(event);
			}
			else
			{
				//������ǵȴ���ȡ��ǰ�¼�����ô��ֻ���ظ���ȡ��ǰ�¼�����Ϣ��
				event = player->Patrol().getRandomEvent();
			}
			detail["e_id"] = (int)event.type;
			detail["c_id"] = event.cardId;
			detail["lv"] = event.level;
			if (player->Patrol().getState() == patrol::PatrolPenddingEvent)
			{
				//��ȡ����
				if (event.type == patrol::PatrolNone)
				{
					Log(DBLOG::strLogPlayerCard, player, 9, std::string("[]"), std::string("[[24,1]]"));
				}
				else if (event.type == patrol::PatrolDice)
				{
					int oldDiceNum = player->Res().getDice();
					player->Res().alterDice(2);
					Log<int, int>(DBLOG::strLogDice, player, 0, (int)player->Patrol().getState(), oldDiceNum, player->Res().getDice());
					Log(DBLOG::strLogPlayerCard, player, 9, std::string("[[24,2]]"), std::string("[[24,1]]"));
				}
				else if (event.type == patrol::PatrolLadyCoin)
				{
					player->Res().alterLadyCoin(1);
					Log(DBLOG::strLogPlayerCard, player, 9, std::string("[[18,1]]"), std::string("[[24,1]]"));
				}
				else if (event.type == patrol::PatrolOneStar)
				{
					player->Card().addCard(event.cardId, 1, event.level);
					std::string str("[[14,1,");
					str += boost::lexical_cast<std::string>(event.cardId);
					str += std::string("]]");
					Log(DBLOG::strLogPlayerCard, player, 9, str, std::string("[[24,1]]"), 1, event.level);
				}
				else if (event.type == patrol::PatrolTwoStar)
				{
					player->Card().addCard(event.cardId, 1, event.level);
					std::string str("[[14,1,");
					str += boost::lexical_cast<std::string>(event.cardId);
					str += std::string("]]");
					Log(DBLOG::strLogPlayerCard, player, 9, str, std::string("[[24,1]]"), 2, event.level);
				}
				else
				{
					player->Card().addCard(event.cardId, 1, event.level);
					std::string str("[[14,1,");
					str += boost::lexical_cast<std::string>(event.cardId);
					str += std::string("]]");
					Log(DBLOG::strLogPlayerCard, player, 9, str, std::string("[[24,1]]"), 3, event.level);
				}
			}

			player->Patrol().setState(patrol::PatrolPenddingDice);
		}
		else if (player->Patrol().getPos() == END_POINT)
		{
			//�յ㱦�䣨�յ㲻��������¼��������¼���
			r[strMsg][0u] = 3;
			int target = player->Patrol().getEndPointIdx();
			detail["b_id"] = target;
			player->Patrol().setState(patrol::PatrolPenddingBox);
		}
		else
		{
			//�����
			r[strMsg][0u] = 2;
			if (player->Patrol().getState() == patrol::PatrolPenddingEvent)
			{
				int target = Common::randomBetween(0, _s_event.size() - 1);
				player->Patrol().setSpecialEventIndex(target);
			}
			//������ǵȴ���ȡ��ǰ�¼�����ô��ֻ���ظ���ȡ��ǰ�¼�����Ϣ��
			int idx = player->Patrol().getSpecialEventIndex();
			detail["s_id"] = idx;
			detail["sub"] = _s_event[idx].subject.topic;
			for (int i = 0; i < _s_event[idx].subject.option.size(); ++i)
			{
				detail["opt"][i] = _s_event[idx].subject.option[i];
			}
			detail["ans"] = _s_event[idx].subject.ansIdx;
			detail["box1"] = jsonFormatPre[idx];
			detail["box2"] = jsonFormatLater[idx];
			
			player->Patrol().setState(patrol::PatrolPenddingRewardSpecial);

		}
		r[strMsg][1u] = detail;
		return;

	}

	void patrol_system::reqPatrolGetReward(net::Msg& m, Json::Value& r)
	{
		playerDataPtr player = player_mgr.getPlayer(m.playerID);
		if (!player)Return(r, err_illedge);

		tm now = Common::toTm(Common::gameTime());
		if (player->Patrol().getState() == patrol::PatrolPenddingEvent
			|| player->Patrol().getState() == patrol::PatrolPenddingDice
			|| player->Patrol().getState() == patrol::PatrolPenddingRewardRandom
			|| player->Patrol().getState() == patrol::PatrolUninit)
		{
			Return(r, err_patrol_state_error);
		}
		else if (now.tm_hour < 10)
		{
			Return(r, err_patrol_beyond_time);
		}

		int oldDiceNum = player->Res().getDice();

		patrol::PatrolState state = player->Patrol().getState();
		//if (state == patrol::PatrolPenddingRewardRandom)
		//{
		//	//1. ����¼�����
		//	//2. ��ȡ����
		//	//3. ���ؽ����
		//	patrol::RandomEvent event = player->Patrol().getRandomEvent();
		//	if (event.type == patrol::PatrolNone)
		//	{
		//	}
		//	else if (event.type == patrol::PatrolDice)
		//	{
		//		player->Res().alterDice(1);
		//	}
		//	else if (event.type == patrol::PatrolLadyCoin)
		//	{
		//		player->Res().alterLadyCoin(1);
		//	}
		//	else if (event.type == patrol::PatrolOneStar)
		//	{
		//		player->Card().addCard(event.cardId, 1, event.level);
		//	}
		//	else if (event.type == patrol::PatrolTwoStar)
		//	{
		//		player->Card().addCard(event.cardId, 1, event.level);
		//	}
		//	else
		//	{
		//		player->Card().addCard(event.cardId, 1, event.level);
		//	}
		//	player->Patrol().setState(patrol::PatrolPenddingDice);
		//	Return(r, res_sucess);
		//}
		//else 
		if (state == patrol::PatrolPenddingRewardSpecial)
		{
			ReadJsonArray;
			int flag = js_msg[0u].asInt();
			//1. �ر����±�
			//2. ��ý���
			//3. ���ؽ����
			int idx = player->Patrol().getSpecialEventIndex();
			//��ȡ����//һ�뽱����
			int ret = actionDoBox(player, _s_event[idx].box_list, false);
			if (flag == 1 && ret == res_sucess)
			{
				ret = actionDoBox(player, _s_event[idx].box_list2, false);
				Log(DBLOG::strLogPlayerCard, player, 10, logAll[idx], std::string("[[24,1]]"));
			}
			else if(flag != 1 && ret == res_sucess)
			{
				Log(DBLOG::strLogPlayerCard, player, 10, logHalf[idx], std::string("[[24,1]]"));
			}
			player->Patrol().setState(patrol::PatrolPenddingDice);
			
			Return(r, ret);
		}
		else if (state == patrol::PatrolPenddingBox)
		{
			//1. ���ձ����±�
			//2. ��ý���
			//3. ���ؽ����
			int idx = player->Patrol().getEndPointIdx();
			const int ret = actionDoBox(player, _e_event[idx], false);
			player->Patrol().setState(patrol::PatrolPenddingDice);

			//����λ��
			player->Patrol().setPos(1);
			//��һ�ֵ����ձ���
			player->Patrol().setEndPointIdx(Common::randomBetween(0, _e_event.size() - 1));
			Log(DBLOG::strLogPlayerCard, player, 11, logEnd[idx]);
			Return(r, ret);
		}

		//
		Log<int,int>(DBLOG::strLogDice, player, 0, (int)state, oldDiceNum, player->Res().getDice());
	}
}
*/

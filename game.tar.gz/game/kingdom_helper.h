#pragma once

#include "auto_base.h"
#include "dbDriver.h"

namespace gg
{
	struct SalaryState
	{
		SalaryState():state(-1){}
		SalaryState(const mongo::BSONElement& obj);
		mongo::BSONObj toBSON(int pid) const;
		int state;
		int title;
	};

	class KingdomConstructionConf
	{	
		public:
			KingdomConstructionConf(const Json::Value& info);
			
			int _id;
			int _open_lv;
			STDVECTOR(int, Vec);
			Vec _exp;
			Vec _add_num;
	};

	BOOSTSHAREPTR(KingdomConstructionConf, KingdomConstructionConfPtr);
	STDMAP(int, KingdomConstructionConfPtr, KingdomConstructionConfMap);

	class KingdomContributionConf
	{
		public:
			STDVECTOR(int, Vec);

			void load(const Json::Value& info);

			int silverCost(unsigned times) const { return getValue(times, _silver_cost); }
			int silverCon(unsigned times) const { return getValue(times, _silver_con); }
			int silverConSelf(unsigned times) const { return getValue(times, _silver_con_self); }
			int goldCost(unsigned times) const { return getValue(times, _gold_cost); }
			int goldCon(unsigned times) const { return getValue(times, _gold_con); }
			int goldConSelf(unsigned times) const { return getValue(times, _gold_con_self); }
			int getConTimes(int vip) const { return getValue(vip, _actions); }
		
		private:
			int getValue(unsigned times, const Vec& vec) const
			{
				if (vec.empty())
					return 0;
				if (times >= vec.size())
					times = vec.size() - 1;
				return vec[times];
			}

			Vec _silver_cost;
			Vec _silver_con;
			Vec _silver_con_self;
			Vec _gold_cost;
			Vec _gold_con;
			Vec _gold_con_self;
			Vec _actions;
	};

	class KingdomShopConf
	{
		public:
			KingdomShopConf(const Json::Value& info);

			int _id;
			int	_consume_con;
			int _buy_times;
			int	_weight;
			Kingdom::NATION _kingdom_id;
			ActionBoxList _box;
	};

	BOOSTSHAREPTR(KingdomShopConf, KingdomShopConfPtr);
	STDMAP(int, KingdomShopConfPtr, KingdomShopConfMap);
	STDVECTOR(KingdomShopConfPtr, KingdomShopConfList);

	class KingdomConstructionData
	{
		public:
			KingdomConstructionData(int id);
			void load(const mongo::BSONElement& obj);

			mongo::BSONObj toBSON() const;
			void getInfo(Json::Value& info) const;

			int id() const { return _id; }
			int lv() const { return _lv; }
			int addNum() const { return _add_num; }
			bool upgradeAble() const;
			void alterExp(int exp);

		private:
			void init();

		private:
			int _id;
			int _lv;
			int _exp;
			int _total_exp;
			int _add_num;
	};

	BOOSTSHAREPTR(KingdomConstructionData, KingdomConstructionDataPtr);
	STDVECTOR(KingdomConstructionDataPtr, KingdomConstructionDatas);

	class KingdomConInfo
	{
		public:
			KingdomConInfo(playerDataPtr d);
			KingdomConInfo(int pid, int con)
				: _pid(pid), _cons(con){}

			int id() const { return _pid; }
			int value() const { return _cons; } 

			void getInfo(Json::Value& info, int rk) const;

		private:
			int _pid;
			int _cons;
	};

	BOOSTSHAREPTR(KingdomConInfo, KingdomConPtr);

	class KingdomConRank
	{
		public:
			KingdomConRank();
			void load(const mongo::BSONElement& obj);
			std::string toBSON() const;

			const Json::Value& getInfo() const { return _info; }

			void tick();
			void packageInfo(const KingdomConInfo& con);
			void update(playerDataPtr d, int old_con);
			void insert(const KingdomConPtr& ptr);

		private:
			typedef RankList1<KingdomConInfo> ConRank;
			ConRank _rank;
			Json::Value _info;
			// temp
			int _rk;
	};

	class PrisonerMgr;
	BOOSTSHAREPTR(PrisonerMgr, PrisonerMgrPtr);

	class SalaryData;
	BOOSTSHAREPTR(SalaryData, SalaryDataPtr);

	class KingdomInfo
		: public _auto_meta
	{
		public:
			KingdomInfo(Kingdom::NATION n);

			void init();

			void tick();
			int join(playerDataPtr d);
			int setAnnouncement(playerDataPtr d, const std::string& str);
			int setClientParam(playerDataPtr d, int val);
			int playerCon(playerDataPtr d, int id, int type);
			int addConstuctionExp(int id, int con);
			void update(playerDataPtr d, int old_con);
			const SalaryState& getSalaryState(int pid) const;
			int getSalary(playerDataPtr d, Json::Value& r);

			int addPrisoner(playerDataPtr prisoner, playerDataPtr guard, Json::Value& r);
			int freePrisoner(playerDataPtr prisoner, playerDataPtr guard);
			void upPrisonerData(playerDataPtr d);
			void updatePrisoner(playerDataPtr d);
			unsigned isPrisoner(int pid) const;

			unsigned getPlayerNum() const { return _player_num; }
			void getConRank(Json::Value& info) const;
			void getHeroPartyRank(Json::Value& info) const;
			void getConstruction(Json::Value& info) const;
			void getBaseInfo(Json::Value& info) const;
			int getAddNum(int type) const;
			int getLevel() const;
			int getTotalLv() const;
			int getRate() const;

		private:
			virtual bool _auto_save();

			void loadInfo();
			void loadRank();
			void saveInfo();
			void saveRank();
		
			void tickHeroParty();

		private:
			Kingdom::NATION _nation;
			unsigned _player_num;
			std::string _announcement;
			KingdomConstructionDatas _constructions;
			PrisonerMgrPtr _prisoner_mgr;
			SalaryDataPtr _salary_data;
			
			int _strength_rank;
			KingdomConRank _con_rank;
			Json::Value _hero_party_info;
			int _client_param;
	};

	class PrisonerCD
		: public boost::enable_shared_from_this<PrisonerCD>
	{
		public:
			PrisonerCD(int pid, unsigned cd, PrisonerMgrPtr ptr);
			PrisonerCD(const mongo::BSONElement& obj, PrisonerMgrPtr ptr);

			mongo::BSONObj toBSON() const;

			int pid() const { return _pid; }
			unsigned cd() const { return _cd; }
			
		private:
			friend class PrisonerMgr;
			void startTimer();
			void tick();

		private:
			int _pid;
			unsigned _cd;
			PrisonerMgrPtr _prisoner_mgr;
	};
	
	BOOSTSHAREPTR(PrisonerCD, PrisonerCDPtr);
	STDLIST(PrisonerCDPtr, PrisonerCDList);
	
	class Prisoner
		: public boost::enable_shared_from_this<Prisoner>
	{
		public:
			Prisoner(const mongo::BSONElement& obj, PrisonerMgrPtr ptr);
			Prisoner(playerDataPtr prisoner, playerDataPtr guard, unsigned free_time, PrisonerMgrPtr ptr);

			int pid() const { return _prisoner_pid; }
			unsigned cd() const { return _free_time; }

			mongo::BSONObj toBSON() const;
			void getInfo(qValue& q) const;
			void upData(playerDataPtr d);

		private:
			friend class PrisonerMgr;
			void startTimer();
			void stopTimer();

		private:
			int _prisoner_pid;
			unsigned _free_time;
			int _guard_pid;
			
			std::string _prisoner_name;
			int _prisoner_face;
			std::string _guard_name;

			ptrTimerIdentify _timer_id;
			PrisonerMgrPtr _prisoner_mgr;
	};

	BOOSTSHAREPTR(Prisoner, PrisonerPtr);
	STDVECTOR(PrisonerPtr, PrisonerList);
	
	class PrisonerMgr
		: public _auto_meta
	{
		public:
			PrisonerMgr(int nation);

			void loadDB();
			void update(playerDataPtr d);

			int add(playerDataPtr prisoner, playerDataPtr guard, Json::Value& r);
			int free(playerDataPtr prisoner, playerDataPtr guard);
			void removePrisoner(int prisoner_id);
			void removeCD(int pid);
			void upData(playerDataPtr d);

			unsigned isPrisoner(int pid) const;
			bool inProtectedCD(int pid, unsigned& cd) const;

		private:
			virtual bool _auto_save();

		private:
			const int _nation;
			PrisonerList _prisoner_list;
			PrisonerCDList _prisoner_cd;
	};

	class PrisonerHelper
	{
		SINGLETON(PrisonerHelper);
		friend class PrisonerMgr;
		public:
			unsigned check(int pid) const
			{
				std::map<int, unsigned>::const_iterator it = _pid_list.find(pid);
				return it == _pid_list.end()? 0 : it->second;
			}
		private:
			void add(int pid, unsigned cd) { _pid_list.insert(make_pair(pid, cd)); }
			void remove(int pid) { _pid_list.erase(pid); }
		private:
			std::map<int, unsigned> _pid_list;
	};

	class SalaryData
		: public _auto_meta
	{
		friend int KingdomInfo::getSalary(playerDataPtr d, Json::Value& r);
		public:
			SalaryData(int nation);

			void loadDB();
			const SalaryState& getSalaryState(int pid) const
			{
				static SalaryState null;
				PID2SalaryTitle::const_iterator it = _salary_map.find(pid);
				return it == _salary_map.end()? null : it->second;
			}
			void tick();
			void clearSalaryState(int pid);

		private:
			virtual bool _auto_save();
			void removeSalaryTitle(int pid);

		private:
			const int _nation;
			STDMAP(int, SalaryState, PID2SalaryTitle);
			PID2SalaryTitle _salary_map;
	};
}

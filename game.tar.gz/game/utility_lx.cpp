#include "utility_lx.h"


namespace lx
{

	utility_lx::utility_lx()
	{
	}


	utility_lx::~utility_lx()
	{
	}

	/*
	[[aID,id,v],[aID,v]]
	*/
	Json::Value utility_lx::combineArrayBox(const Json::Value& left, const Json::Value& right)
	{
		//LogS << "combine\t" << "left:" << left.toIndentString() << "\tright:" << right.toIndentString() << LogEnd;
		//LogS << "left_length:" << left.size() << "\tright_lenght:" << right.size() << LogEnd;
		int a = left.size();
		int b = right.size();
		if (a == 0 && b == 0)
		{
			return right;
		}
		if (a == 0)
		{
			return right;
		}
		if (b == 0)
		{
			return left;
		}
		Json::Value ret = Json::arrayValue;
		int i = 0, k = 0;
		AList llist, rlist;
		for (; i < a; ++i)
		{
			for (int j = 0; j < b; ++j)
			{
				if (std::find(rlist.begin(), rlist.end(), j) != rlist.end())
				{
					continue;
				}
				int aid = left[i][0u].asInt();
				if (aid == right[j][0u].asInt())
				{
					Json::Value sub = Json::arrayValue;
					if (aid == ACTION::item
						|| aid == ACTION::kingdom_skill_exp
						|| aid == ACTION::lady)
					{
						if (left[i][1u].asInt() == right[j][1u].asInt())
						{
							sub[0u] = left[i][0u].asInt();
							sub[1u] = left[i][1u].asInt();
							sub[2u] = left[i][2u].asInt() + right[j][2u].asInt();
							ret[k++] = sub;
							llist.push_back(i);
							rlist.push_back(j);
							break;
						}
					}
					else
					{
						sub[0u] = aid;
						sub[1u] = left[i][1u].asInt() + right[j][1u].asInt();
						ret[k++] = sub;
						llist.push_back(i);
						rlist.push_back(j);
						break;
					}
				}
			}
		}
		//
		for (int i = 0; i < a; ++i)
		{
			if (std::find(llist.begin(), llist.end(), i) != llist.end())
			{
				continue;
			}
			ret[k++] = left[i];
		}
		for (int i = 0; i < b; ++i)
		{
			if (std::find(rlist.begin(), rlist.end(), i) != rlist.end())
			{
				continue;
			}
			ret[k++] = right[i];
		}
		return ret;
	}
	
	size_t utility_lx::getProbIndex(const std::vector<int>& odds, int sum)
	{
		int target = Common::randomBetween(0, sum - 1);
		for (int i = 0; i < odds.size() - 1; ++i)
		{
			if (target >= odds[i] && target < odds[i + 1])
			{
				return i;
			}
		}
		return 0;
	}

	void utility_lx::combineJsonBox(const Json::Value& from, Json::Value& to)
	{
		int a = from.size();
		int b = to.size();
		if (a == 0 && b == 0)
		{
			return;
		}
		if (a == 0)
		{
			return;
		}
		if (b == 0)
		{
			to = from;
		}
		Json::Value boxes = Json::arrayValue;
		//��ͬ�ĺϲ���ʣ�µĶ��ǻ�����ͬ�ġ�
		std::vector<int> first_done_list;
		std::vector<int> sec_done_list;
		int c = 0;
		for (int i = 0; i < from.size(); ++i)
		{
			int first_aid = from[i]["aID"].asInt();
			for (int j = 0; j < to.size(); ++j)
			{
				if (std::find(sec_done_list.begin(), sec_done_list.end(), j) != sec_done_list.end())
				{
					continue;
				}
				int sec_aid = to[j]["aID"].asInt();
				if (first_aid == sec_aid)
				{
					if ((first_aid == ACTION::item
						|| first_aid == ACTION::kingdom_skill_exp
						|| first_aid == ACTION::lady)
						&& from[i]["id"].asInt() == to[j]["id"].asInt())
					{
						boxes[c]["aID"] = first_aid;
						boxes[c]["id"] = from[i]["id"].asInt();
						boxes[c]["v"] = from[i]["v"].asInt() + to[j]["v"].asInt();
						first_done_list.push_back(i);
						sec_done_list.push_back(j);
						++c;
						break;
					}
					else if ((first_aid == ACTION::item
						|| first_aid == ACTION::kingdom_skill_exp
						|| first_aid == ACTION::lady)
						&& from[i]["id"].asInt() != to[j]["id"].asInt())
					{
						continue;
					}
					else
					{
						boxes[c]["aID"] = first_aid;
						boxes[c]["v"] = from[i]["v"].asInt() + to[j]["v"].asInt();
						first_done_list.push_back(i);
						sec_done_list.push_back(j);
						++c;
						break;
					}
				}

			}

		}
		//������ͬ��
		for (int i = 0; i < from.size(); ++i)
		{
			if (std::find(first_done_list.begin(), first_done_list.end(), i) != first_done_list.end())
			{
				continue;
			}
			else
			{
				boxes[c] = from[i];
				++c;
			}
		}

		for (int j = 0; j < to.size(); ++j)
		{
			if (std::find(sec_done_list.begin(), sec_done_list.end(), j) != sec_done_list.end())
			{
				continue;
			}
			else
			{
				boxes[c] = to[j];
				++c;
			}
		}
		to = boxes;
	}

	std::string utility_lx::parseJsonBox(Json::Value json_box)
	{
		std::string str("[");
		for (int i = 0; i < json_box.size(); ++i)
		{
			str.append("[");
			int aid = json_box[i]["aID"].asInt();
			str.append(boost::lexical_cast<std::string>(aid));//1.==>aID
			str.append(",");
			int v = json_box[i]["v"].asInt();//2.==>v
			str.append(boost::lexical_cast<std::string>(v));
			//����ǵ��ߺ���Ů  �ͻ���id������ID��12����ŮID��14 
			if (aid == ACTION::item
				|| aid == ACTION::kingdom_skill_exp
				|| aid == ACTION::lady)
			{
				int id = json_box[i]["id"].asInt();//3.==>id
				str.append(",");
				str.append(boost::lexical_cast<std::string>(id));
			}
			str.append("]");
			if (i != json_box.size() - 1)
			{
				str.append(",");
			}
		}
		str.append("]");
		return str;
	}

	Json::Value utility_lx::parseJson(Json::Value json_box)
	{
		Json::Value box = Json::arrayValue;
		for (unsigned i = 0; i < json_box.size(); ++i)
		{
			Json::Value ele;
			int aid = json_box[i]["aID"].asInt();
			ele[0u] = aid;
			if (aid == ACTION::item
				|| aid == ACTION::kingdom_skill_exp
				|| aid == ACTION::lady)
			{
				ele[1u] = json_box[i]["id"].asInt();
				ele[2u] = json_box[i]["v"].asInt();
			}
			else
			{
				ele[1u] = json_box[i]["v"].asInt();
			}
			box[i] = ele;
		}
		return box;
	}

	bool utility_lx::is_time_overlap(unsigned begin_n, unsigned end_n, unsigned begin_o, unsigned end_o)
	{
		if (begin_n <= begin_o && end_n >= begin_o
			|| begin_n >= begin_o && end_n <= end_o
			|| begin_n <= end_o && end_n >= end_o
			|| begin_n <= begin_o && end_n >= end_o)
		{
			return true;
		}
		return false;
	}
	
	void utility_lx::switchToLogJson(Json::Value& json_box)
	{
		for (int i = 0; i < json_box.size(); ++i)
		{
			if (json_box[i].size() == 3)
			{
				int last = json_box[i][2u].asInt();
				int first = json_box[i][1u].asInt();
				json_box[i][1u] = last;
				json_box[i][2u] = first;
			}
		}
	}

	//template<typename T>
	//void utility_lx::swapVectorElement(std::vector<T>& vec, int idx1, int idx2)
	//{
	//	if (idx1 == idx2)
	//	{
	//		return;
	//	}
	//	if (idx1 >= vec.size() || idx2 >= vec.size())
	//	{
	//		return;
	//	}
	//	T temp = vec[idx1];
	//	vec[idx1] = vec[idx2];
	//	vec[idx2] = temp;
	//}

	std::vector<int> utility_lx::randomSequence(int lbound, int ubound)
	{
		std::vector<int> origin;
		for (int i = lbound; i <= ubound; ++i)
		{
			origin.push_back(i);
		}
		int len = origin.size();
		std::vector<int> retVec(len);
		int seed;
		while (len)
		{
			seed = Common::randomBetween(1, len);
			retVec.push_back(origin[seed - 1]);
			swapVectorElement(origin, seed - 1, len - 1);
			--len;
		}
		return retVec;
	}

	Json::Value utility_lx::toRawBox(int aID, int v, int id)
	{
		std::string str("[{\"aID\":");
		str += boost::lexical_cast<std::string>(aID);
		if (aID == ACTION::item
			|| aID == ACTION::kingdom_skill_exp
			|| aID == ACTION::lady)
		{
			if (id == -1)
			{
				return Json::nullValue;
			}
			str += ",\"id\":";
			str += boost::lexical_cast<std::string>(id);
			str += ",\"v\":";
			str += boost::lexical_cast<std::string>(v);
			str += "}]";

		}
		else
		{
			str += ",\"v\":";
			str += boost::lexical_cast<std::string>(v);
			str += "}]";
		}
		//LogS << "mystery\ttoRawBox:" << str << LogEnd;
		return Common::string2json(str);
	}

	int utility_lx::randomWeightSequenceConst(const OddsSequence& seq, int& idx, int& odd)
	{
		int left = 0;
		int rnd = Common::randomBetween(1, seq[seq.size() - 1].odd);
		for (int i = 1; i < seq.size() - 1; ++i)
		{
			left += seq[i].odd;
			if (left >= rnd)
			{
				idx = seq[i].idx;
				odd = seq[i].odd;
				return i;
			}
		}
		return -1;
	}

	std::vector<int> utility_lx::randomWeightSequence(OddsSequence seq, int count)
	{
		//assert(seq.size() - count >= 2)
		//�ƶ��Ѿ����ӵĹ�odd
		unsigned int move = 0;
		for (int i = 0; i < seq.size(); ++i)
		{
			if (seq[i].idx == -2)
			{
				seq[seq.size() - 1].odd -= seq[i].odd;
				swapVectorElement(seq, i, seq.size() - 2 - move);
				++move;
			}
		}
		std::vector<int> keys;
		keys.reserve(count);
		for (int i = 0; i < count; ++i)
		{
			int left = seq[0].odd;
			int rnd = Common::randomBetween(0, seq[seq.size() - 1].odd);
			for (int j = 1; j < seq.size() - i - 1 - move; ++j)
			{
				left += seq[j].odd;
				if (rnd <= left)
				{
					keys.push_back(seq[j].idx);
					//��Ȩ�ؼ���
					seq[seq.size() - 1].odd = seq[seq.size() - 1].odd - seq[j].odd;
					//�ƶ�...
					swapVectorElement(seq, j, seq.size() - 2 - i - move);
					break;
				}
			}
		}
		return keys;
	}
}

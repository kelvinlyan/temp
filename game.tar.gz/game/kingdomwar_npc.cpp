#include "dbDriver.h"
#include "kingdomwar_npc.h"
#include "kingdomwar_system.h"

namespace gg
{
	namespace KingdomWar
	{
		NpcData::NpcData(const mongo::BSONObj& obj)
		{
			_dead = false;
			_id = obj[strNpcID].Int();
			_npc_data = kingdomwar_sys.getNpcData(obj["mi"].Int());
			_name = Common::toString(_npc_data->npcList.front().npcID);
			_hp = obj["h"].Int();
			_nation = obj["n"].Int();
			_type = obj["t"].Int();
			std::vector<mongo::BSONElement> ele = obj["mh"].Array();
			for (unsigned i = 0; i < ele.size(); ++i)
				_man_hp.push_back(ele[i].Int());
			_pos.type = obj["p"]["t"].Int();
			_pos.id = obj["p"]["i"].Int();
			_pos.time = obj["p"]["tm"].Int();
			_pos.from_id = obj["p"]["f"].Int();
		}

		NpcData::NpcData(int type, int map_id, int nation, const Position& pos, int hp, const std::vector<int>& man_hp)
		{
			_dead = false;
			_id = NpcIDCreator::shared().get();
			_type = type;
			_npc_data = kingdomwar_sys.getNpcData(map_id);
			_name = Common::toString(_npc_data->npcList.front().npcID);
			_nation = nation;
			_pos = pos;
			_hp = hp;
			_man_hp = man_hp;
		}

		NpcData::~NpcData()
		{
			if (!_dead)
				LogE << "Error Npc ID:" << _id << ", Type:" << _type << LogEnd;
			else
				removeDB();
		}

		void NpcData::removeDB()
		{
			mongo::BSONObj key = BSON(strNpcID << _id);
			db_mgr.RemoveCollection(DBN::dbKingdomWarNpc, key);
		}

		bool NpcData::_auto_save()
		{
			if (_dead)
				return true;
			mongo::BSONObj key = BSON(strNpcID << _id);
			mongo::BSONObjBuilder obj;
			obj << strNpcID << _id << "mi" << _npc_data->mapID << "h" << _hp
				<< "n" << _nation << "t" << _type;
			obj << "p" << BSON("t" << _pos.type << "i" << _pos.id << "tm" << _pos.time << "f" << _pos.from_id);
			{
				mongo::BSONArrayBuilder b;
				ForEachC(std::vector<int>, it, _man_hp)
					b.append(*it);
				obj << "mh" << b.arr();
			}
			return db_mgr.SaveMongo(DBN::dbKingdomWarNpc, key, obj.obj());
		}

		sBattlePtr NpcData::getBattlePtr() const
		{
			sBattlePtr ptr = map_sys.npcSide(_npc_data);
			if (_type != Npc)
			{
				if (_type == ActiveNpc)
					ptr->playerName = _npc_data->mapName2;
				else
					ptr->playerName = _name;
			}
			ptr->playerNation = _nation;
			if (_pos.type == PosCity)
			{
				CityPtr c_ptr = CityMgr::shared().getCity(_pos.id);
				c_ptr->addBuff(ptr, _nation);
			}
			kingdomwar_sys.addHpDebuff(ptr, _hp);
			manList& ml = ptr->battleMan;
			for (unsigned i = 0; i < ml.size(); ++i)
			{
				if (!_man_hp.empty())
					ml[i]->currentHP = _man_hp[i];
			}
			return ptr;
		}
		
		int NpcData::alterHp(int num)
		{
			int pre_hp = _hp;
			_hp += num;
			if (_hp < 0)
				_hp = 0;
			_sign_save();
			return _hp - pre_hp;
		}

		void NpcData::resetManHp(sBattlePtr& ptr)
		{
			manList& ml = ptr->battleMan;
			for (unsigned i = 0; i < ml.size(); ++i)
			{
				if (i < _man_hp.size())
					_man_hp[i] = ml[i]->currentHP;
				else
					_man_hp.push_back(ml[i]->currentHP);
			}

			_sign_save();
		}

		bool NpcData::checkValidAndSave()
		{
			bool is_valid = valid();
			if (is_valid)
				_sign_save();
			return is_valid;
		}

		bool NpcData::isDead() const
		{
			if (_hp <= 0)
				return true;
			if (_man_hp.empty())
				return false;
			ForEachC(std::vector<int>, it, _man_hp)
			{
				if (*it > 0)
					return false;
			}
			return true;
		}

		void NpcData::setPosition(int type, int id, unsigned time)
		{
			if (_pos.type == PosCity)
				_pos.from_id = _pos.id;

			_pos.type = type;
			_pos.id = id;
			_pos.time = time;
			_sign_save();
		}

		void NpcData::setDead(unsigned cur_time, Json::Value& tips)
		{
			_dead = true;
		}

		void NpcData::fmInfo(qValue& q) const
		{
			for (unsigned i = 0; i < _npc_data->npcList.size(); ++i)
			{
				qValue tmp;
				const armyNPC& n = _npc_data->npcList[i];
				tmp << n.npcID << (_man_hp.size() <= i? n.maxHp : _man_hp[i])
					<< n.maxHp << n.npcLevel;
				q.append(tmp);
			}
		}

		int NpcData::manHp() const
		{
			if (_man_hp.empty())
			{
				int sum = 0;
				sBattlePtr ptr = getBattlePtr();
				for (unsigned i = 0; i < ptr->battleMan.size(); ++i)
				{
					mBattlePtr& mb = ptr->battleMan[i];
					sum += mb->currentHP;
				}
				return sum;
			}
			else
			{
				int sum = 0;
				ForEachC(std::vector<int>, it, _man_hp)
					sum += (*it);
				return sum;
			}
		}
		
		void NpcData::getManInfo(qValue& q) const
		{
			for (unsigned i = 0; i < _npc_data->npcList.size(); ++i)
			{
				qValue tmp;
				const armyNPC& n = _npc_data->npcList[i];
				tmp << n.npcID << (_man_hp.size() <= i? n.maxHp : _man_hp[i])
					<< n.maxHp;
				q.append(tmp);
			}
		}

		ShadowNpcData::ShadowNpcData(const mongo::BSONObj& obj)
			: NpcData(obj)
		{
			_own_id = obj["oid"].Int();
			_name = obj["na"].String();
		}

		ShadowNpcData::ShadowNpcData(playerDataPtr d, int map_id, const Position& pos, int hp, const std::vector<int>& man_hp, int type)
			: NpcData(ShadowNpc, map_id, d->Info().Nation(), pos, hp, man_hp)
		{
			_own_id = d->ID();
			if (type == ShadowNpc)
				_name = getShadowName(d, SHADOW::NPC);
			else if (type == ShadowAdvanceNpc)
				_name = getShadowName(d, SHADOW::ADVANCED_NPC);
			else if (type == ShadowDefenseNpc)
				_name = getShadowName(d, SHADOW::DEFENSE_NPC);
			else
				_name = "";
		}

		bool ShadowNpcData::_auto_save()
		{
			if (_dead)
				return true;
			mongo::BSONObj key = BSON(strNpcID << _id);
			mongo::BSONObjBuilder obj;
			obj << strNpcID << _id << "mi" << _npc_data->mapID << "h" << _hp
				<< "n" << _nation << "t" << _type << "oid" << _own_id << "na" << _name;
			obj << "p" << BSON("t" << _pos.type << "i" << _pos.id << "tm" << _pos.time << "f" << _pos.from_id);
			{
				mongo::BSONArrayBuilder b;
				ForEachC(std::vector<int>, it, _man_hp)
					b.append(*it);
				obj << "mh" << b.arr();
			}
			return db_mgr.SaveMongo(DBN::dbKingdomWarNpc, key, obj.obj());
		}

		void ShadowNpcData::setDead(unsigned cur_time, Json::Value& tips)
		{
			NpcData::setDead(cur_time, tips);
			playerDataPtr d = player_mgr.getOnlinePlayer(ownID());
			if (!d || !d->KingDomWar().onMain()) return;
			qValue m;
			m.append(res_sucess);
			qValue q(qJson::qj_object);
			q.addMember("r", qValue(tips.toIndentString().c_str()));
			m.append(q);
			d->sendToClientFillMsg(gate_client::kingdom_war_shadow_dead_resp, m);
		}
	}
}

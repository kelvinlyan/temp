#include "compensate.h"

namespace gg
{
	compensate* const compensate::_Instance = new compensate();

	const static unsigned SingleMax = 1000000000;//10�ڴ�
	struct LevelOpen
	{
		bool isOpen()const
		{
			return (BeenNum > OpenNum);
		}
		unsigned Lower;//�պ���������
		unsigned OpenNum;// > ������� ���Ž���
		unsigned Open;// <= ����ȼ� ���Ի�ý���
		unsigned BeenNum;// �Ѿ����������
	};
	static vector<LevelOpen> LevelTick;
	static unsigned useMaxIDX;
	static vector<ActionBoxList> Boxes;//�����б�

	void compensate::initData()
	{
		cout << "load compensate system ..." << endl;
		{//�ͼ���������
			Json::Value json = Common::loadJsonFile("./instance/gamer/compensate.json");
			for (unsigned i = 0; i < json.size(); ++i)
			{
				Json::Value& sg_json = json[i];
				LevelOpen open;
				open.Lower = sg_json["Limit"].asUInt();
				open.OpenNum = sg_json["OpenNum"].asUInt();
				open.Open = sg_json["Open"].asUInt();
				open.BeenNum = db_mgr.Count(DBN::dbPlayerBase, BSON(strPlayerLV << BSON("$gte" << open.Lower)));
				LevelTick.push_back(open);
			}
			useMaxIDX = 0;
			for (unsigned i = 0; i < LevelTick.size(); ++i)
			{
				const LevelOpen& open = LevelTick[i];
				if (useMaxIDX < open.Open && open.isOpen())
				{
					useMaxIDX = open.Open;
				}
			}
		};

		{//��ҵͼ�������������
			Boxes.clear();
			Json::Value json = Common::loadJsonFile("./instance/gamer/compensate_box.json");
			for (unsigned i = 0; i < json.size(); ++i)
			{
				Json::Value& sg_json = json[i];
				Boxes.push_back(actionFormatBox(sg_json));
			}
		};
	}

	const static int upgradeLevelAction = 1;
	void compensate::tryGetCompenstate(playerDataPtr player, const unsigned from, const unsigned to)
	{
		Json::Value json_from;
		json_from[strMsg][0u] = State::getState();
		if (to <= from)return;
		if (player->isOnline())
		{
			player->sendToClient(gate_client::player_compensate_begin_resp, json_from);
		}
		for (unsigned i = from + 1; i <= to; ++i)
		{
			const bool isCompensate = (i <= useMaxIDX);
			bool isShow = false;
			if (isCompensate)
			{
				const ActionBoxList& box_list = Boxes[i];
				if (false == box_list.empty())
				{
					isShow = true;
					actionDoBox(player, box_list);
				}
			}
			player->Res().alterAction(upgradeLevelAction);//�̶�����1������һ������
			if (player->isOnline())
			{
				Json::Value json;
				Json::Value& data_json = json[strMsg];
				data_json.append(res_sucess);
				data_json.append(i);
				data_json.append(upgradeLevelAction);
				data_json.append(isShow);
				data_json.append(isShow ? actionRes() : Json::arrayValue);
				player->sendToClient(gate_client::player_compensate_resp, json);
			}
		}
		if (player->isOnline())
		{
			player->sendToClient(gate_client::player_compensate_end_resp, json_from);
		}
	}

	void compensate::tickLevel(const unsigned from, const unsigned to)
	{
		if (from == to)return;
		for (unsigned i = 0; i < LevelTick.size(); ++i)
		{
			LevelOpen& open = LevelTick[i];
			if (from > to)//������
			{
				if (from >= open.Lower && to < open.Lower)
				{
					if (open.BeenNum > 0)
					{
						--open.BeenNum;
					}
				}
			}
			else
			{
				if (to >= open.Lower && from < open.Lower)
				{
					if (open.BeenNum < SingleMax)
					{
						++open.BeenNum;
					}
				}
			}
		}

		useMaxIDX = 0;
		for (unsigned i = 0; i < LevelTick.size(); ++i)
		{
			const LevelOpen& open = LevelTick[i];
			if (useMaxIDX < open.Open && open.isOpen())
			{
				useMaxIDX = open.Open;
			}
		}
	}

}
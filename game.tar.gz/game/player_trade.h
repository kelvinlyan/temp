//###################################
//create by Jim
//2016-02-04
//###################################

#pragma once

#include "auto_base.h"
#include "wstar.h"

namespace gg
{
	namespace Business
	{
		extern void initData();
	}

	class playerCarPos :
		public _auto_player
	{
	public:
		playerCarPos(playerData* const own);
		~playerCarPos(){}
		bool toSave();
		
		void newRoute(WSTAR::Pos start_pos, std::vector<WSTAR::Pos>& vec);//����·��
		bool setPos(const int x, const int y);//���õ�ǰλ��
		void stopMove();
		bool canSetStartPos(WSTAR::Pos pos);
		inline unsigned currentX(){ return _current_pos.x; }
		inline unsigned currentY() { return _current_pos.y; }
		inline WSTAR::Pos currentXY() { return _current_pos; }
		inline unsigned aimX() { return aimXY().x; }
		inline unsigned aimY() { return aimXY().y; }
		inline WSTAR::Pos aimXY() { return _move_list.empty() ? _current_pos : _move_list.back(); }
		inline unsigned futureX() { return futureXY().x; }
		inline unsigned futureY() { return futureXY().y; }
		inline WSTAR::Pos futureXY() { return _current_idx >= _move_list.size() ? _current_pos : _move_list[_current_idx]; }
		inline bool isStop(){ return _move_list.empty(); }
		bool isNearlyAim();
		void resetFuture() { _show_idx = _current_idx; }
		void sendFuturePos(const unsigned num = 5);
		void setData(mongo::BSONObj& obj);
	private:
		static void staticLoopRoute(const structTimer& timerData, const int playerID);
		void loopRoute();//��ѯ·��
		void loopMove(const unsigned to_client = true);//����ƶ�
		virtual bool _auto_save();
		void resetMove();
		WSTAR::Pos _current_pos;
		unsigned _show_idx;//��ǰ�Ѿ����͵ĸ���//ǰ��Ԥ��
		unsigned _current_idx;//��ǰ�ƶ����ĸ���
		std::vector<WSTAR::Pos> _move_list;//�ƶ��ĸ���
		bool _is_dirty;//����Ƿ�������
		boost::system_time _star_move_time;//�ڴ�//�ϴμ�¼���ƶ�ʱ���
		unsigned _leave_time;//�ڴ�//�������ڼ����ʱ��
		bool _is_need_timer;//��Ҫ��ʱ��
		std::list<WSTAR::Pos> _history_pos;//��ʷ��¼
	};

	namespace TradeType
	{
		enum Type
		{
			null,
			runing,
			complete,
		};
	}

	namespace TradeBuff
	{
		enum ID
		{
			null,
			fangshui,
			weishe,
			yijia,
		};
	}

	class playerTick;
	class playerBusiness :
		public _auto_player
	{
		friend class playerTick;
	public:
		playerBusiness(playerData* const own);
		~playerBusiness() {}

		int addExp(const unsigned num);
		inline unsigned getLevel() { return _car_level; }
		inline unsigned getExp() { return _car_exp; }
		unsigned getSpeed();
		unsigned getCapacity();
		int getSaleRate();
		double getDurableRate();
		inline int getDurable() { return _car_durable; }//�;�
		unsigned getDurableLimit();//�;öȲ�ֵ
		void fullDurable();//�����;ö�
		void alterDurable(const int num);
		inline unsigned totalTask() { return _cumulative_task; }//����ɴ���
		inline int historyMoney() { return _single_max; }//��ʷ���
		inline long long int historyTotalMoney() { return _cumulative_money; }//��ʷ�ۼ�
		void overCollect(const int money);//�������ͳ��
		//ˮ��boss
		inline void hitBossTick() { ++_boss_hit_times; _sign_auto(); }
		inline unsigned bossHitTimes() { return _boss_hit_times; }
		inline unsigned hitBossCD() { return _boss_hit_cd; }
		inline void nextBossCD() { _boss_hit_cd = Common::gameTime() + 5; _sign_update(); }
		int usefulBossBox(const unsigned id);
		inline unsigned bossBoxSize() { return _boss_box.size(); }
		inline void tickSharkBox(const unsigned id) { _boss_box.insert(id); _sign_save(); }
		//��������
		inline unsigned hitPirate() { return _pirate_hit_times; }
		void tickPirate();

		//��ʷ����
		inline int MaxHistory() { return _single_max; }
		inline int TotalHistory() { return _cumulative_money; }

		//��������
		void setData(mongo::BSONObj& obj);
		virtual void _auto_update();
	private:
		virtual bool _auto_save();
		//��ֻ��Ϣ
		unsigned _car_level;//ȡ���������//ȡ���ۼۼӳ�//ȡ����ֻ�ٶ�
		unsigned _car_exp;
		int _car_durable;
		//ͳ������
		unsigned _boss_hit_times;//��������Ĵ���
		unsigned _pirate_hit_times;//������������
		unsigned _cumulative_task;//�ۼ�����������
		int _single_max;//��Ʊ��ʷ���
		long long int _cumulative_money;//�ۼƸ���
		unsigned _boss_hit_cd;//��������CD
		std::set<unsigned> _boss_box;//���㽱������
	};

	class playerBusinessTask :
		public _auto_player
	{
		friend class playerTick;
	public:
		playerBusinessTask(playerData* const own);
		~playerBusinessTask() {}
		
		//��������
		inline int getMoney() { return _business_money; }
		void alterMoney(const int num);
		inline unsigned getComplete() { return _task_complete; }//�������
		inline unsigned taskTimes() { return _task_times; }//������ɴ���
		inline TradeType::Type taskType() { return _task_type; }//��������
		int acceptTask(const int money, const int target);
		void cancelTask();
		int overTask();
		//ó����Ʒ
		bool checkWare(const int wareID, const unsigned num);
		int addWare(const int wareID, const unsigned num, const int unit_price);
		int removeWare(const int wareID, const unsigned num);
		//��������
		void setData(mongo::BSONObj& obj);
		virtual void _auto_update();
	private:
		virtual bool _auto_save();
		int _business_money;//ó�ױ�
		int _task_complete;//��Ҫ��������
		TradeType::Type _task_type;//����״̬
		unsigned _task_times;//�������
		//��Ʒ��Ϣ
		struct Ware
		{
			Ware()
			{
				wareID = -1;
				wareNum = 0;
				avPrice = 0;
			}
			int wareID;
			unsigned wareNum;
			int avPrice;
		};
		BOOSTSHAREPTR(Ware, playerWarePtr);//��ҵ���
		UNORDERMAP(int, playerWarePtr, WareMap);
		WareMap _ware_bag;
		unsigned _ware_num;
		playerWarePtr getWare(const int wareID);
	};


	class playerBusinessBuff :
		public _auto_player
	{
	public:
		playerBusinessBuff(playerData* const own);
		~playerBusinessBuff(){}
		//buffЧ��
		bool checkBuff(const TradeBuff::ID id);
		bool insertBuff(const TradeBuff::ID id, const unsigned time);
		//��������
		void setData(mongo::BSONObj& obj);
		virtual void _auto_update();
	private:		
		virtual bool _auto_save();
		//ó��buff
		UNORDERMAP(TradeBuff::ID, unsigned, BuffMap);
		BuffMap _business_buff;
	};

	class playerBoatBorrow :
		public _auto_player
	{
	public:
		playerBoatBorrow(playerData* const own);
		~playerBoatBorrow() {}
		long long int getArrows();
		bool allowBorrow();
		int buyBorrow();
		void alterBorrow(const int val);
		void alterArrows(const int val);
		void newBorrowArrows(const int val);
		inline int arrowBorrowMax() { return _max_borrow; }
		inline unsigned borrowStep() { return _step_rewards; }
		void setBorrowStep(const unsigned step);
		bool rawCheckRes();
		void setData(mongo::BSONObj& obj);
		virtual void _auto_update();
	private:
		bool raw_check_res();
		void check_res();
		virtual bool _auto_save();
		//�����õ�
		long long int _arrows;
		int _borrow_use;
		int _borrow_buy;
		int _daily_borrow;
		unsigned _borrow_time;
		//�������õ�
		int _max_borrow;
		unsigned _step_rewards;
	};
}
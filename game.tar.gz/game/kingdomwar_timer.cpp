#include "kingdomwar_timer.h"

namespace gg
{
	namespace KingdomWar
	{
		priority_queue<Timer::Item> Timer::_queue;
	}
}

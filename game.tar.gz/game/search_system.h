//###################################
//motify by Jim
//2016-09-28
//###################################
#pragma once

#include "action_system.h"
#include "broadcast_check.h"
#include "dbDriver.h"
#include "commom.h"

#define search_sys (*gg::search_system::_Instance)

namespace gg
{	
	class search_system
	{
		public:
			STDVECTOR(int, IdList);

			static search_system* const _Instance;
			void initData();
			

			DeclareRegFunction(getData);
			DeclareRegFunction(searchFor_WeiWang);
			DeclareRegFunction(searchFor_Cash);
			DeclareRegFunction(searchFor_WeiWang_Item);
			DeclareRegFunction(searchFor_Cash_Item);
		private:
			void loadFile();

		private:


			ActionRandomList _WeiWangBoxes;
			ActionRandomList _CashBoxes, _80CashBoxes;

			//�ض��佫
			//acPtrList _SPWeiWangBoxes;//����û�бض��佫
			ActionRandomList _SPCashBoxes, _80SPCashBoxes;

			//��������
			std::vector< ActionRandomList > _FirstWWBoxes;
			std::vector< ActionRandomList > _FirstCSBoxes;
	};
}

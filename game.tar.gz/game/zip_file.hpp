//###################################
//create by Jim
//2016-02-18
//###################################

#pragma once

#include "commom.h"
#include "core_helper.h"
#include "quickjson.h"

namespace gg
{
	class zipFile
	{
	public:
		zipFile(const unsigned length = 102400, const int ioID = DangerIO::file_io);//������//100k, �첽д���ʱ��io
		~zipFile();
		void write(const std::string dir, qValue& json);
		void write(const std::string dir, Json::Value& json);
		void write(const std::string dir, const std::string& str);
		void async_write(const std::string dir, qValue& json);
		void async_write(const std::string dir, Json::Value& json);
		void async_write(const std::string dir, const std::string& str);
		std::string read_string(const string dir);
		Json::Value read_json(const string dir);
	private:
		const unsigned _length;
		const int _io_id;
		unsigned char *_buffer_write, *_buffer_read;
		void _impl_write(const std::string& dir, const std::string& str);
		string _impl_read(const std::string& dir);

	};
}

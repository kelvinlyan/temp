#include "player_mystery_area.h"
#include "dbDriver.h"

namespace gg
{

	const static std::string strResetTime = "rt";
	const static std::string strExploreTime = "et";
	const static std::string strCt = "ct";
	const static std::string strIsSet = "f";
	const static std::string strTreasure = "ts";
	const static std::string strAreaList = "al";
	const static std::string strFrt = "frt";
	const static std::string strLevel = "lv";
	const static std::string strBoxList = "bid";
	const static std::string strRestTime = "rst";
	const static std::string strActiId = "aid";
	const static std::string strGroupIds = "gid";
	const static std::string strAllCost = "ac";
	const static std::string strFoc = "foc";
	const static std::string strOdds = "odd";
	const static std::string strBAId = "baid";

	playerMysteryArea::playerMysteryArea(playerData* const own)
		:_auto_player(own),
		_reset_time(1),
		_explore_time(TREASURE_NUM),
		_add_frt_consume(0),
		_acti_id(-1),
		_foc_explore_time(0),
		_flag(1),
		_treasure(Creator<mystery::Treasure>::Create())
	{
		_all_cost.push_back(4);
		_all_cost.push_back(0);
	}

	void playerMysteryArea::addResetTime(int inc)
	{
		_reset_time += inc;
		_auto_save();
	}

	void playerMysteryArea::alterFoc(int alter)
	{
		_foc_explore_time += alter;
		if (_foc_explore_time < 0)
		{
			_foc_explore_time = 0;
		}
		_auto_save();
	}

	void playerMysteryArea::addExploreTime(int inc) 
	{
		_explore_time += inc;
		_auto_save();
	}

	bool playerMysteryArea::isExplored(int area_id)
	{
		return _area_list.find(area_id) != _area_list.end();
	}
	
	void playerMysteryArea::reset()
	{
		_explore_time = 1;
		_area_list.clear();
		_box_list.clear();
		_box_area_id.clear();
		_auto_save();
	}

	void playerMysteryArea::start(int acti_id)
	{
		_acti_id = acti_id;
		_foc_explore_time = FOC_TIMES;
		_reset_time = 1;
		//LogS << "msytery==>reset_time reset,action=start,acti_id=" << acti_id <<"\tpid=" << Own().ID() << LogEnd;
		_explore_time = 1;
		_area_list.clear();
		_box_list.clear();
		_group_list.clear();
		_box_area_id.clear();
		_add_frt_consume = 0;
		_auto_save();
	}

	void playerMysteryArea::restart()
	{
		//_acti_id = -1;
		_flag = 1;
		_reset_time = 1;
		_foc_explore_time = FOC_TIMES;
		//LogS << "msytery==>reset_time reset,action=restart,pid=" << Own().ID() << LogEnd;
		_explore_time = 1;
		_area_list.clear();
		_box_list.clear();
		_group_list.clear();
		_box_area_id.clear();
		//_add_frt_consume = 0;
		_auto_save();
	}

	void playerMysteryArea::setNewTreasure(mystery::TreasurePtr treasure)
	{
		_treasure = treasure;
		_treasure->areaVec.clear();
		_treasure->odds.clear();
		_treasure->boxIdToIdxMap.clear();
		_treasure->odds.reserve(_treasure->areaBoxMap.size() + 2);
		lx::OddUnit odd;
		odd.idx = -1;
		odd.odd = 0;
		_treasure->odds.push_back(odd);
		unsigned idx = 0u;
		int sum = 0;
		//��������Ϣ���浽�����ط�
		for (mystery::AreaBoxMap::iterator it = _treasure->areaBoxMap.begin();
			it != _treasure->areaBoxMap.end();
			++it)
		{
			lx::OddUnit unit;
			unit.idx = idx;
			unit.odd = it->second.weight;
			sum += unit.odd;
			_treasure->odds.push_back(unit);
			_treasure->areaVec.push_back(it->second);
			++idx;
		}
		odd.odd = sum;
		_treasure->odds.push_back(odd);
		for (int i = 0; i < _treasure->areaVec.size(); ++i)
		{
			_treasure->boxIdToIdxMap[_treasure->areaVec[i].boxId] = i;
		}

		//�����������顣����
		for (int i = 0; i < _treasure->groupIds.size(); ++i)
		{
			if (_group_list.find(_treasure->groupIds[i]) == _group_list.end())
			{
				_group_list[_treasure->groupIds[i]] = 1;
			}
		}
		_flag = 2;
		_auto_save();
	}

	void playerMysteryArea::getRewardBoxDesc(int id, Json::Value& json_box, int& flag, int& level)
	{

		std::map<int, int>::iterator it = _treasure->boxIdToIdxMap.find(id);
		if (it == _treasure->boxIdToIdxMap.end())
		{
			json_box = Json::nullValue;
			flag = 0;
			//LogS << "mystery\tbox:null box.\tid:" << id << LogEnd;
		}
		else
		{
			int idx = it->second;
			//json_box = _treasure->areaBoxMap[id].box->jsonBox;
			json_box = _treasure->areaVec[idx].box->jsonBox;
			//flag = _area_list.find(id) == _area_list.end() ? 1 : 0;
			flag = _box_list.find(_treasure->areaVec[idx].boxId) == _box_list.end() ? 1 : 0;
			//level = _treasure->areaBoxMap[id].level;
			level = _treasure->areaVec[idx].level;
		}
		//LogS << "mystery\tbox:" << json_box.toIndentString() << LogEnd;
	}

	mystery::Sequence playerMysteryArea::getAllCost()
	{
		return _all_cost;
	}

	void playerMysteryArea::setAllCost(const mystery::Sequence& cost)
	{
		_all_cost = cost;
		_auto_save();
	}

	void playerMysteryArea::alterAllCost(int alter)
	{
		_all_cost[1] += alter;
		if (_all_cost[1] < 0)
		{
			_all_cost[1] = 0;
		}
		_auto_save();
	}

	int playerMysteryArea::doExplore(int area_id, mystery::BoxSinglePtr& box, int& box_id, int& box_level)
	{
		mystery::AreaBoxMap::iterator it = _treasure->areaBoxMap.find(area_id);
		//LogS << "mystery\tdoExplore==>area_id:" << area_id << LogEnd;
		if (it == _treasure->areaBoxMap.end())
		{
			LogS << "mystery:doExplore==>area_id not exist:" << area_id << LogEnd;
			return 1;
		}
		int target_odd = 0;
		int idx = 0;
		int move_idx = lx::utility_lx::randomWeightSequenceConst(_treasure->odds, idx, target_odd);
		LogS << "mystery==>doExplore:idx=" << idx << "\tpid=" << Own().ID() << LogEnd;
		if (idx == -1 || idx >= _treasure->areaVec.size())
		{
			return idx;
		}
		//�ƶ�����Ȩ�ؼ�С
		lx::utility_lx::swapVectorElement(_treasure->odds, move_idx, _treasure->odds.size() - 2 - _area_list.size());
		_treasure->odds[_treasure->odds.size() - 1].odd -= target_odd;
		//box = it->second.box;
		//box_id = it->second.boxId;
		//box_level = it->second.level;
		box = _treasure->areaVec[idx].box;
		box_id = _treasure->areaVec[idx].boxId;
		box_level = _treasure->areaVec[idx].level;
		_area_list[area_id] = 1;
		_box_list[box_id] = 1;//
		_box_area_id[area_id] = box_id;
		_auto_save();
		return 0;
	}

	int playerMysteryArea::doExploreAll(mystery::BoxList& box_list, mystery::Sequence& levels, mystery::Sequence& area_ids)
	{
		int box_id;
		mystery::AreaBoxMap::iterator it = _treasure->areaBoxMap.begin();
		for (; it != _treasure->areaBoxMap.end(); ++it)
		{
			if (_area_list.find(it->second.areaId) == _area_list.end())
			{
				int level;
				mystery::BoxSinglePtr box;
				int ret = doExplore(it->second.areaId, box, box_id, level);
				if (ret == 0)
				{
					area_ids.push_back(it->second.areaId);
					levels.push_back(level);
					box_list.push_back(box);
				}
			}
		}

		return 0;
	}

	void playerMysteryArea::getCompleteInfo(Json::Value& info)
	{
		for (std::map<int, int>::iterator it = _box_area_id.begin(); it != _box_area_id.end(); ++it)
		{
			Json::Value unit = Json::arrayValue;
			unit.append(it->first);
			unit.append(it->second);
			info.append(unit);
		}
	}

	bool playerMysteryArea::isGroupSet(int group_id)
	{
		return _group_list.find(group_id) != _group_list.end();
	}

	void playerMysteryArea::addFrtConsume(int inc)
	{
		_add_frt_consume += inc;
		_auto_save();
	}

	bool playerMysteryArea::_auto_save()
	{
		mongo::BSONObj key = BSON(strPlayerID << Own().ID());

		mongo::BSONArrayBuilder treasure, area_list, group_ids, all_cost, odds, box_list, ba_list;
		
		for (std::map<int, int>::iterator it = _area_list.begin();it != _area_list.end(); ++it)
		{
			area_list << it->first;
		}
		for (std::map<int, int>::iterator git = _group_list.begin(); git != _group_list.end(); ++git)
		{
			group_ids << git->first;
		}
		mystery::AreaBoxMap::iterator ait = _treasure->areaBoxMap.begin();
		for (; ait != _treasure->areaBoxMap.end(); ++ait)
		{
			treasure << ait->second.areaId << ait->second.level << ait->second.box->rawBox.toIndentString();
		}
		int rank = 1;
		for (int i = 0; i < _treasure->odds.size(); ++i)
		{
			odds << rank << _treasure->odds[i].idx << _treasure->odds[i].odd;
			++rank;
		}
		for (int i = 0; i < _all_cost.size(); ++i)
		{
			all_cost << _all_cost[i];
		}
		for (std::map<int, int>::iterator it = _box_list.begin(); it != _box_list.end(); ++it)
		{
			box_list << it->first;
		}
		for (std::map<int, int>::iterator it = _box_area_id.begin(); it != _box_area_id.end(); ++it)
		{
			ba_list << it->first << it->second;
		}

		mongo::BSONObj obj = BSON("$set" << BSON("MysteryArea" <<
			BSON(strResetTime << _reset_time
			<< strExploreTime << _explore_time
			<< strActiId << _acti_id
			<< strTreasure << treasure.arr()
			<< strAreaList << area_list.arr()
			<< strFrt << _add_frt_consume
			<< strAllCost << all_cost.arr()
			<< strGroupIds << group_ids.arr()
			<< strFoc << _foc_explore_time
			<< strOdds << odds.arr()
			<< strBoxList << box_list.arr()
			<< strBAId << ba_list.arr()
			<< strIsSet << _flag
			)
		));

		return db_mgr.SaveMongo(DBN::dbPlayerCollection, key, obj);
	}

	void playerMysteryArea::setData(mongo::BSONObj& obj)
	{
		if (obj.isEmpty())
		{
			return;
		}
		_reset_time = obj[strResetTime].Int();
		//LogS << "mystery==>player load reset_time=" << _reset_time << LogEnd;
		_explore_time = obj[strExploreTime].Int();
		_acti_id = obj[strActiId].Int();
		_add_frt_consume = obj[strFrt].Int();
		_flag = obj[strIsSet].Int();
		std::vector<mongo::BSONElement> area_list = obj[strAreaList].Array();
		for (int i = 0; i < area_list.size(); ++i)
		{
			_area_list[area_list[i].Int()] = 1;
		}
		if (!obj[strBoxList].eoo())
		{
			std::vector<mongo::BSONElement> box_list = obj[strBoxList].Array();
			for (int i = 0; i < box_list.size(); ++i)
			{
				_box_list[box_list[i].Int()] = 1;
			}
		}
		if (!obj[strAllCost].eoo())
		{
			std::vector<mongo::BSONElement> all_cost = obj[strAllCost].Array();
			_all_cost[0] = all_cost[0].Int();
			_all_cost[1] = all_cost[1].Int();
		}
		if (!obj[strFoc].eoo())
		{
			_foc_explore_time = obj[strFoc].Int();
		}

		std::vector<mongo::BSONElement> group_list = obj[strGroupIds].Array();
		for (int i = 0; i < group_list.size(); ++i)
		{
			_group_list[group_list[i].Int()] = 1;
		}
		std::vector<mongo::BSONElement> ts = obj[strTreasure].Array();
		for (int i = 0; i < ts.size(); i += 3)
		{
			mystery::Area area;
			area.areaId = area.boxId = ts[i].Int();
			area.level = ts[i+1].Int();
			mystery::BoxSinglePtr single = Creator<mystery::BoxSingle>::Create();
			single->rawBox = Common::string2json(ts[i + 2].String());
			single->load();
			area.box = single;
			_treasure->areaBoxMap[area.areaId] = area;
		}
		//�����������
		for (mystery::AreaBoxMap::iterator it = _treasure->areaBoxMap.begin();
			it != _treasure->areaBoxMap.end();
			++it)
		{
			_treasure->areaVec.push_back(it->second);
		}
		//��map�����
		for (int i = 0; i < _treasure->areaVec.size(); ++i)
		{
			_treasure->boxIdToIdxMap[_treasure->areaVec[i].boxId] = i;
		}
		if (!obj[strBAId].eoo())
		{
			std::vector<mongo::BSONElement> ba_list = obj[strBAId].Array();
			for (int i = 0; i < ba_list.size(); i += 2)
			{
				_box_area_id[ba_list[i].Int()] = ba_list[i + 1].Int();
			}
		}
		if (!obj[strOdds].eoo())
		{
			_treasure->odds.reserve(_treasure->areaVec.size() + 2);
			/*lx::OddUnit odd;
			odd.idx = -1;
			odd.odd = 0;
			_treasure->odds.push_back(odd);*/
			std::vector<mongo::BSONElement> odds_list = obj[strOdds].Array();
			std::map<int, lx::Sequence> odds_rank;
			for (int i = 0; i < odds_list.size(); i += 3)
			{
				lx::Sequence seq;
				seq.push_back(odds_list[i + 1].Int());//idx
				seq.push_back(odds_list[i + 2].Int());
				odds_rank[odds_list[i].Int()] = seq;
			}
			int sum;
			for (std::map<int, lx::Sequence>::iterator it = odds_rank.begin(); it != odds_rank.end(); ++it)
			{
				lx::OddUnit unit;
				unit.idx = it->second[0];
				unit.odd = it->second[1];
				sum += unit.odd;
				_treasure->odds.push_back(unit);
			}
			/*odd.odd = sum;
			_treasure->odds.push_back(odd);*/
		}
	}

	playerMysteryArea::~playerMysteryArea()
	{
	}

}

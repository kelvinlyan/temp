#include "player_rescue.h"
#include "rescue_system.h"
#include "kingdom_system.h"

namespace gg
{
	static std::vector<int> rwLimit;
	int playerRescue::getLimit()
	{
		//const int level = kingdom_sys.getCountryLevel(Own().Info().Nation());
		const KingdomPtr ptr = kingdom_sys.getData(Own().Info().Nation());
		int level = ptr? ptr->getLevel() : 0;
		if (level < 0 || level >= (int)rwLimit.size())return 0;
		return rwLimit[level];
	}

	static std::vector<int> rwGetLimit;
	int playerRescue::getSingleReward()
	{
		const unsigned size = rwGetLimit.size();
		if (size == 0)return 25;
		if (rewardTimes >= size)return rwGetLimit.back();
		return rwGetLimit[rewardTimes];
	}

	void playerRescue::initData()
	{
		{
			rwLimit.clear();
			Json::Value json = Common::loadJsonFile("./instance/rescue/reward_limit.json");
			for (unsigned i = 0; i < json.size(); ++i)
			{
				rwLimit.push_back(json[i].asInt());
			}
		};
		{
			rwGetLimit.clear();
			Json::Value json = Common::loadJsonFile("./instance/rescue/single_reward_limit.json");
			for (unsigned i = 0; i < json.size(); ++i)
			{
				rwGetLimit.push_back(json[i].asInt());
			}
		};
	}

	void playerRescue::setData(mongo::BSONObj& obj)
	{
		if (obj.isEmpty())return;
		rewardNum = obj["rn"].Int();
		rewardTimes = obj["rts"].eoo() ? 0 : obj["rts"].Int();
	}

	int playerRescue::tickReward()
	{
		const int num = getSingleReward();
		if (num < 1)return 0;
		int con_num = num;
		const int max_today = getLimit();
		if ((rewardNum + num) > max_today)
		{
			con_num = max_today - rewardNum;
			rewardNum = max_today;
		}
		else
		{
			rewardNum += num;
		}
		++rewardTimes;
		Own().Res().alterContribution(con_num);
		_sign_auto();
		return con_num;
	}

	playerRescue::playerRescue(playerData* const own) :_auto_player(own)
	{
		rewardNum = 0;
		rewardTimes = 0;
	}

	void playerRescue::_auto_update()
	{
		Json::Value json;
		json[strMsg][0u] = res_sucess;
		Json::Value& dataJson = json[strMsg][1u];
		dataJson["rn"] = rewardNum;
		dataJson["rts"] = rewardTimes;
		Own().sendToClient(gate_client::player_rescue_update_resp, json);
	}

	bool playerRescue::_auto_save()
	{
		mongo::BSONObj  key = BSON(strPlayerID << Own().ID());
		mongo::BSONObj  obj = BSON("$set" << BSON("Rescue" <<
			BSON("rn" << rewardNum << "rts" << rewardTimes)
			));
		return db_mgr.SaveMongo(DBN::dbPlayerCollection, key, obj);
	}
}

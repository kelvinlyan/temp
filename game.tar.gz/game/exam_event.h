#pragma once

#ifndef EXAM_EVENT_H
#define EXAM_EVENT_H

#include "action_system.h"
#include "commom.h"
#include <vector>
#include <string>
#include <boost/shared_ptr.hpp>
#include "utility_lx.h"

namespace gg
{

	namespace imperial
	{
		enum EventType
		{
			Answer = 1,
			Suggection = 2,
			Fight = 4,
			Purchase = 8,
			AllGroup = 16,
		};

		//��Ҳμӿƾٵ�״̬
		enum ExamState
		{
			StateInit = 1001,//��ʼ״̬
			StateCountryIn = 1002,//�μ�����״̬
			StateCountryOut = 1003,//�����б���̭
			StateTempleIn = 1004,//�μӵ���״̬
			StateTempleComplete = 1005,//��ɵ���
			//???
		};

		enum CountryState
		{
			PeddingExam,//�ȴ��������
			PeddingAnswer,//�ȴ����ش�
		};

		//�����¼�
		typedef struct _answer
		{
			std::string title;
			std::vector<std::string> options;
			int pos; //��ȷ��λ�ã���1��ʼ
			int grade;
		}AnswerSingle;

		//�ṩ���
		typedef struct _suggection
		{
			std::string title;
			std::vector<std::string> options;
			std::vector<int> grades;
		}SuggectionSingle;

		//ս���¼�
		typedef struct _fight
		{
			std::string title;
			std::string name;
			std::vector<std::string> options;
			std::vector<int> grades;
		}FightSingle;

		//֧������
		typedef struct _purchase
		{
			std::string title;
			std::vector<std::string> options;
			std::vector<lx::BoxSingle> consumes;
			std::vector<int> grades;
		}PurchaseSingle;

		//�÷ֽ���
		typedef struct _grade_reward
		{
			int idx;//������Ӧ���±꣬-1����Ч��
			int lbound;
			int ubound;
			lx::BoxSingle box;
		}GradeReward;

		BOOSTSHAREPTR(AnswerSingle, AnswerSinglePtr);
		BOOSTSHAREPTR(SuggectionSingle, SuggectionSinglePtr);
		BOOSTSHAREPTR(FightSingle, FightSinglePtr);
		BOOSTSHAREPTR(PurchaseSingle, PurchaseSinglePtr);
	}

	class exam_event;
	class exam_answer_event;
	class exam_suggection_event;
	class exam_fight_event;
	class exam_purchase_event;

	BOOSTSHAREPTR(exam_event, ExamEventPtr);
	BOOSTSHAREPTR(exam_answer_event, ExamAnswerEventPtr);
	BOOSTSHAREPTR(exam_suggection_event, ExamSuggectionEventPtr);
	BOOSTSHAREPTR(exam_fight_event, ExamFightEventPtr);
	BOOSTSHAREPTR(exam_purchase_event, ExamPurchaseEventPtr);

	class exam_event
	{
	public:
		exam_event(imperial::EventType type);
		virtual imperial::EventType Type() { return _type; }
		virtual ActionBoxList getBox(int flag = 0) = 0;//��ñ���
		virtual void getDetail(Json::Value& r) = 0;//ǰ�����
		virtual std::string getStr(int flag = 0) = 0;//Log��� 
		virtual int getGrade(int flag = 0) = 0;//������Ӧ����
		virtual ~exam_event();
	protected:
		imperial::EventType _type;

	};

	class exam_answer_event : public exam_event
	{
	public:
		exam_answer_event(imperial::AnswerSinglePtr);
		virtual ActionBoxList getBox(int flag = 0);
		virtual void getDetail(Json::Value& r);
		virtual std::string getStr(int flag = 0);
		virtual int getGrade(int flag = 0);
		virtual ~exam_answer_event();
	private:
		imperial::AnswerSinglePtr _config;
	};

	class exam_suggection_event : public exam_event
	{
	public:
		exam_suggection_event(imperial::SuggectionSinglePtr);
		virtual ActionBoxList getBox(int flag = 0);
		virtual void getDetail(Json::Value& r);
		virtual std::string getStr(int flag = 0);
		virtual int getGrade(int flag = 0);
		virtual ~exam_suggection_event();
	private:
		imperial::SuggectionSinglePtr _config;
	};

	class exam_fight_event : public exam_event
	{
	public:
		exam_fight_event(imperial::FightSinglePtr);
		virtual ActionBoxList getBox(int flag = 0);
		virtual void getDetail(Json::Value& r);
		virtual std::string getStr(int flag = 0);
		virtual int getGrade(int flag = 0);
		virtual ~exam_fight_event();
	private:
		imperial::FightSinglePtr _config;
	};

	class exam_purchase_event : public exam_event
	{
	public:
		exam_purchase_event(imperial::PurchaseSinglePtr);
		virtual ActionBoxList getBox(int flag = 0);
		virtual void getDetail(Json::Value& r);
		virtual std::string getStr(int flag = 0);
		virtual int getGrade(int flag = 0);
		virtual ~exam_purchase_event();
	private:
		imperial::PurchaseSinglePtr _config;
	};

}

#endif


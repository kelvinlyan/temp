#include "action_system.h"
#include "playerManager.h"

namespace gg
{
//��ʽ��
	typedef boost::function<void(LIMIT::cltLimit&, Json::Value&)> LimitFunction;
	UNORDERMAP(LIMIT::Condition, LimitFunction, LimitMap);
	static LimitMap mapLimit;

	void lmInt(LIMIT::cltLimit& lm, Json::Value& json)
	{
		lm._Int._val = json["value"].asInt();
	}

	void lmUInt(LIMIT::cltLimit& lm, Json::Value& json)
	{
		lm._UInt._val = json["value"].asUInt();
	}

	void lmItem(LIMIT::cltLimit& lm, Json::Value& json)
	{
		lm._Item._id = json["id"].asInt();
		lm._Item._num = json["num"].asUInt();
	}

//ִ����
	const static unsigned JudgeTimes = LIMIT::operate_num;
	typedef boost::function<bool(const LIMIT::cltLimit&, playerDataPtr)> JudgeFunction;
	UNORDERMAP(LIMIT::Condition, JudgeFunction, JudgeMap);
	static JudgeMap mapJudge;

#define JudegeHelper(LogicSession)\
	{\
		if((LogicSession)){\
			res = true;break;\
		}\
	}

	bool judgePlayerLevel(const LIMIT::cltLimit& lm, playerDataPtr player)
	{
		bool res = false;
		unsigned op = lm._Base._operate;
		for (unsigned i = 0; i < JudgeTimes; ++i)
		{
			const unsigned opr = (0x0001 << i) & op;
			if (opr == LIMIT::greater)
			{
				JudegeHelper(player->LV() > lm._UInt._val);
			}
			else if (opr == LIMIT::less)
			{
				JudegeHelper(player->LV() < lm._UInt._val);
			}
			else if (opr == LIMIT::equal)
			{
				JudegeHelper(player->LV() == lm._UInt._val);
			}
		}
		return res;
	}

	bool judgePlayerKingdom(const LIMIT::cltLimit& lm, playerDataPtr player)
	{
		bool res = false;
		unsigned op = lm._Base._operate & LIMIT::equal;
		if (op == LIMIT::equal)
		{
			if (player->Info().Nation() == lm._Int._val)
			{
				res = true;
			}
		}
		else if (op == (LIMIT::greater | LIMIT::less))
		{
			if (player->Info().Nation() != lm._Int._val)
			{
				res = true;
			}
		}
		return res;
	}

	bool judgePlayerWar(const LIMIT::cltLimit& lm, playerDataPtr player)
	{
		bool res = false;
		unsigned op = lm._Base._operate & LIMIT::equal;
		if (op == LIMIT::equal)
		{
			if (player->War().isChallengeMap(lm._Int._val))
			{
				res = true;
			}
		}
		else if (op == (LIMIT::greater | LIMIT::less))
		{
			if (!player->War().isChallengeMap(lm._Int._val))
			{
				res = true;
			}
		}
		return res;
	}

	bool judgePlayerItem(const LIMIT::cltLimit& lm, playerDataPtr player)
	{
		bool res = false;
		unsigned op = lm._Base._operate;
		for (unsigned i = 0; i < JudgeTimes; ++i)
		{
			const unsigned opr = (0x0001 << i) & op;
			if (opr == LIMIT::greater)
			{
				JudegeHelper(player->Items().itemNum(lm._Item._id, itemDef::pos_bag | itemDef::pos_man) > lm._Item._num);
			}
			else if (opr == LIMIT::less)
			{
				JudegeHelper(!player->Items().overItem(lm._Item._id, lm._Item._num));
			}
			else if (opr == LIMIT::equal)
			{
				JudegeHelper(player->Items().itemNum(lm._Item._id, itemDef::pos_bag | itemDef::pos_man) == lm._Item._num);
			}
		}
		return res;
	}

	bool judgePlayerCard(const LIMIT::cltLimit& lm, playerDataPtr player)
	{
		bool res = false;
		unsigned op = lm._Base._operate;
		for (unsigned i = 0; i < JudgeTimes; ++i)
		{
			const unsigned opr = (0x0001 << i) & op;
			if (opr == LIMIT::greater)
			{
				JudegeHelper(player->Card().cardNum(lm._Item._id) > lm._Item._num);
			}
			else if (opr == LIMIT::less)
			{
				JudegeHelper(player->Card().cardNum(lm._Item._id) < lm._Item._num);
			}
			else if (opr == LIMIT::equal)
			{
				JudegeHelper(player->Card().cardNum(lm._Item._id) == lm._Item._num);
			}
		}
		return res;
	}

	bool judgePlayerMan(const LIMIT::cltLimit& lm, playerDataPtr player)
	{
		bool res = false;
		unsigned op = lm._Base._operate & LIMIT::equal;
		if (op == LIMIT::equal)
		{
			if (player->Man().findArmy(lm._Int._val))
			{
				res = true;
			}
		}
		else if (op == (LIMIT::greater | LIMIT::less))
		{
			if (!player->Man().findArmy(lm._Int._val))
			{
				res = true;
			}
		}
		return res;
	}



	void initLimit()
	{
		//��ʽ��
		mapLimit[LIMIT::player_level] = boostBind(lmUInt, _1, _2);
		mapLimit[LIMIT::player_kingdom] = boostBind(lmInt, _1, _2);
		mapLimit[LIMIT::player_man] = boostBind(lmInt, _1, _2);
		mapLimit[LIMIT::player_item] = boostBind(lmItem, _1, _2);
		mapLimit[LIMIT::player_card] = boostBind(lmItem, _1, _2);
		mapLimit[LIMIT::player_officer] = boostBind(lmInt, _1, _2);
		mapLimit[LIMIT::player_war] = boostBind(lmInt, _1, _2);

		//ִ����
		mapJudge[LIMIT::player_level] = boostBind(judgePlayerLevel, _1, _2);
		mapJudge[LIMIT::player_kingdom] = boostBind(judgePlayerKingdom, _1, _2);
		mapJudge[LIMIT::player_man] = boostBind(judgePlayerMan, _1, _2);
		mapJudge[LIMIT::player_item] = boostBind(judgePlayerItem, _1, _2);
		mapJudge[LIMIT::player_card] = boostBind(judgePlayerCard, _1, _2);
		//mapJudge[LIMIT::player_officer] = boostBind(judgePlayerOffical, _1, _2);
		mapJudge[LIMIT::player_war] = boostBind(judgePlayerWar, _1, _2);
	}

	LIMIT::valLimit toLimitData(Json::Value& json)
	{
		LIMIT::valLimit lm;
		lm._pick = json["pick"].asUInt();
		lm._logic = (LIMIT::Logic)json["logic"].asUInt();
		lm._logic = lm._logic >= LIMIT::logic_end ? LIMIT::logic_or : lm._logic;
		lm._limits.clear();
		for (unsigned i = 0; i < json["limits"].size(); ++i)
		{
			Json::Value& json_sglm = json["limits"][i];
			LIMIT::cltLimit sglm;
			sglm._Base._condition = (LIMIT::Condition)json_sglm["condition"].asUInt();
			sglm._Base._condition = sglm._Base._condition >= LIMIT::condition_end ? LIMIT::player_level : sglm._Base._condition;
			sglm._Base._operate = json_sglm["operate"].asUInt();
			LimitMap::iterator it = mapLimit.find(sglm._Base._condition);
			if (it == mapLimit.end())continue;
			it->second(sglm, json_sglm);
			lm._limits.push_back(sglm);
		}
		return lm;
	}

	bool resLimitPass(playerDataPtr player, const LIMIT::valLimit& limit)
	{
		const LIMIT::pLimitList& vec = limit._limits;
		if (vec.empty())return true;
		if (limit._logic == LIMIT::logic_and)
		{
			for (unsigned i = 0; i < vec.size(); ++i)
			{
				const LIMIT::cltLimit& lm = vec[i];
				JudgeMap::iterator it = mapJudge.find(lm._Base._condition);
				if (it == mapJudge.end())continue;
				if (!it->second(lm, player))
				{
					return false;
				}
			}
			return true;
		}
		else
		{
			for (unsigned i = 0; i < vec.size(); ++i)
			{
				const LIMIT::cltLimit& lm = vec[i];
				JudgeMap::iterator it = mapJudge.find(lm._Base._condition);
				if (it == mapJudge.end())continue;
				if (it->second(lm, player))
				{
					return true;
				}
			}
			return false;
		}
	}
}
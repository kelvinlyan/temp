#include "kingdomwar_task_def.h"
#include "kingdomwar_task.h"
#include "task_def.h"
#include "playerData.h"
#include "kingdomwar_city.h"
#include "heroparty_system.h"

namespace gg
{
	namespace KingdomWar
	{
		namespace Task
		{
			int CBattleTimes::update(playerDataPtr d, ParamPtr& param_ptr, const Json::Value& arg)
			{
				int val = arg.asInt();
				IntArray& param = *(upCast<IntArray>(param_ptr));
				param[0] += val;
				if (param[0] > _args[0u])
					param[0] = _args[0u];
				return param[0] >= _args[0u]? gg::Task::Finished : gg::Task::Running;
			}

			int CBattleTimes::init(playerDataPtr d, ParamPtr& param_ptr)
			{
				param_ptr = Creator<IntArray>::Create();
				IntArray& param = *(upCast<IntArray>(param_ptr));
				param._values.push_back(0);
				return param[0] >= _args[0u]? gg::Task::Finished : gg::Task::Running;
			}

			int CWinStreakTimes::update(playerDataPtr d, ParamPtr& param_ptr, const Json::Value& arg)
			{
				IntArray& param = *(upCast<IntArray>(param_ptr));
				int army_id = arg[0u].asInt();
				int action = arg[1u].asInt();
				unsigned idx = army_id + 1;
				if (action == 0)
					param[idx] = 0;
				else
					++param[idx];
				if (param[idx] == _args[1u])
					++param[0];
				if (param[0] > _args[0u])
					param[0] = _args[0u];
				return param[0] >= _args[0u]? gg::Task::Finished : gg::Task::Running;
			}

			int CWinStreakTimes::init(playerDataPtr d, ParamPtr& param_ptr)
			{
				param_ptr = Creator<IntArray>::Create();
				IntArray& param = *(upCast<IntArray>(param_ptr));
				param._values.push_back(0);
				param._values.push_back(0);
				param._values.push_back(0);
				param._values.push_back(0);
				return param[0] >= _args[0u]? gg::Task::Finished : gg::Task::Running;
			}

			int CGetExploit::update(playerDataPtr d, ParamPtr& param_ptr, const Json::Value& arg)
			{
				IntArray& param = *(upCast<IntArray>(param_ptr));
				int val = arg.asInt();
				param[0] += val;
				if (param[0] > param[1])
					param[0] = param[1];
				return param[0] >= param[1]? gg::Task::Finished : gg::Task::Running;
			}

			int CGetExploit::init(playerDataPtr d, ParamPtr& param_ptr)
			{
				param_ptr = Creator<IntArray>::Create();
				IntArray& param = *(upCast<IntArray>(param_ptr));
				param._values.push_back(0);
				param._values.push_back(_args[0u] * d->LV() + _args[1u]);
				return param[0] >= param[1]? gg::Task::Finished : gg::Task::Running;
			}

			int CUseFood::update(playerDataPtr d, ParamPtr& param_ptr, const Json::Value& arg)
			{
				IntArray& param = *(upCast<IntArray>(param_ptr));
				int val = arg.asInt();
				param[0] += val;
				if (param[0] > param[1])
					param[0] = param[1];
				return param[0] >= param[1]? gg::Task::Finished : gg::Task::Running;
			}

			int CUseFood::init(playerDataPtr d, ParamPtr& param_ptr)
			{
				param_ptr = Creator<IntArray>::Create();
				IntArray& param = *(upCast<IntArray>(param_ptr));
				param._values.push_back(0);
				param._values.push_back(_args[0u] * d->LV() + _args[1u]);
				return param[0] >= param[1]? gg::Task::Finished : gg::Task::Running;
			}

			int CUseItemTimes::update(playerDataPtr d, ParamPtr& param_ptr, const Json::Value& arg)
			{
				int item_id = arg[0u].asInt();
				int num = arg[1u].asInt();
				if (item_id != _args[1u])
					return gg::Task::Running;
				IntArray& param = *(upCast<IntArray>(param_ptr));
				param[0] += num;
				if (param[0] > _args[0u])
					param[0] = _args[0u];
				return param[0] >= _args[0u]? gg::Task::Finished : gg::Task::Running;
			}

			int CUseItemTimes::init(playerDataPtr d, ParamPtr& param_ptr)
			{
				param_ptr = Creator<IntArray>::Create();
				IntArray& param = *(upCast<IntArray>(param_ptr));
				param._values.push_back(0);
				return param[0] >= _args[0u]? gg::Task::Finished : gg::Task::Running;
			}

			int CKillNum::update(playerDataPtr d, ParamPtr& param_ptr, const Json::Value& arg)
			{
				IntArray& param = *(upCast<IntArray>(param_ptr));
				int val = arg.asInt();
				if (val != param[1u])
					return gg::Task::Running;
				++param[0];
				if (param[0] > _args[0u])
					param[0] = _args[0u];
				return param[0] >= _args[0u]? gg::Task::Finished : gg::Task::Running;
			}

			int CKillNum::init(playerDataPtr d, ParamPtr& param_ptr)
			{
				param_ptr = Creator<IntArray>::Create();
				IntArray& param = *(upCast<IntArray>(param_ptr));
				param._values.push_back(0);
				int nation = d->Info().Nation();
				int add = Common::randomBetween(0, 1) == 0? 1 : 2;
				nation += add;
				param[1] = nation % Kingdom::nation_num;
				return param[0] >= _args[0u]? gg::Task::Finished : gg::Task::Running;
			}

			int COccupySpecified::update(int nation, ParamPtr& param, const Json::Value& arg)
			{
				const IDList& id_list = _args[nation];
				IntArrayPtr param_ptr = upCast<IntArray>(param);
				if (arg.isInt()) // start or stop
				{
					int action = arg.asInt();
					if (action == 1) // start
					{
						ForEachC(IDList, it, id_list)
						{
							CityPtr ptr = CityMgr::shared().getCity(*it);
							if (ptr && ptr->nation() == nation)
								param_ptr->_values.push_back(*it);
						}
						return gg::Task::Running;
					}
					else // stop
					{
						return param_ptr->_values.size() >= id_list.size()? 
							gg::Task::Finished : gg::Task::Running;
					}
				}

				int id = arg[0u].asInt();
				int action = arg[1u].asInt();
				ForEachC(IDList, it, id_list)
				{
					if (*it == id)
					{
						if (action == 1)
							param_ptr->_values.push_back(id);
						else
						{
							ForEach(IDList, itp, param_ptr->_values)
							{
								if (*itp == id)
								{
									param_ptr->_values.erase(itp);
									break;
								}
							}
						}
						return gg::Task::Running;
					}
				}
				return gg::Task::NoChanged;
			}

			int COccupySpecified::init(int nation, ParamPtr& param)
			{
				param = Creator<IntArray>::Create();
				return gg::Task::Running;
			}

			int CGetExploit2::update(int nation, ParamPtr& param_ptr, const Json::Value& arg)
			{
				int val = arg.asInt();
				IntArray& param = *(upCast<IntArray>(param_ptr));
				param[0] += val;
				if (param[0] > param[1])
					param[0] = param[1];
				return param[0] >= param[1]? gg::Task::Finished : gg::Task::Running;
			}

			int CGetExploit2::init(int nation, ParamPtr& param_ptr)
			{
				param_ptr = Creator<IntArray>::Create();
				IntArray& param = *(upCast<IntArray>(param_ptr));
				param._values.push_back(0);
				param._values.push_back(_args[0] * heroparty_sys.getKingdomWarTaskParam() * TaskParamHelper::shared().param() + _args[1]);
				return param[0] >= param[1]? gg::Task::Finished : gg::Task::Running;
			}

			int COccupyNum::update(int nation, ParamPtr& param_ptr, const Json::Value& arg)
			{
				int action = arg.asInt();
				IntArray& param = *(upCast<IntArray>(param_ptr));
				if (action == 1)
				{
					param[0] = CityCounter::shared().num(nation);
					if (param[0] > param[1])
						param[0] = param[1];
					return gg::Task::Running;
				}
				else
				{
					return param[0] >= param[1]? gg::Task::Finished : gg::Task::Running;
				}
			}

			int COccupyNum::init(int nation, ParamPtr& param_ptr)
			{
				int num = CityCounter::shared().num(nation);
				param_ptr = Creator<IntArray>::Create();
				IntArray& param = *(upCast<IntArray>(param_ptr));
				param._values.push_back(0);
				param._values.push_back(num + _args[0]);
				if (param[1] > CityMgr::shared().size() - 2)
					param[1] = CityMgr::shared().size() - 2;
				return gg::Task::Running;
			}

			ICheckFactory::ICheckFactory()
			{
				_creator_map[BattleTimes] = boostBind(CBattleTimes::create, _1);
				_creator_map[GetExploit] = boostBind(CGetExploit::create, _1);
				_creator_map[WinStreakTimes] = boostBind(CWinStreakTimes::create, _1);
				_creator_map[UseFood] = boostBind(CUseFood::create, _1);
				_creator_map[CallAttackNpc] = boostBind(CCallAttackNpc::create, _1);
				_creator_map[CallDefenseNpc] = boostBind(CCallDefenseNpc::create, _1);
				_creator_map[CallAdvancedNpc] = boostBind(CCallAdvancedNpc::create, _1);
				_creator_map[UseItemTimes] = boostBind(CUseItemTimes::create, _1);
				_creator_map[KillNum] = boostBind(CKillNum::create, _1);

				_creator_map2[OccupySpecified] = boostBind(COccupySpecified::create, _1);
				_creator_map2[GetExploit2] = boostBind(CGetExploit2::create, _1);
				_creator_map2[OccupyNum1] = boostBind(COccupyNum1::create, _1);
				_creator_map2[OccupyNum2] = boostBind(COccupyNum2::create, _1);
			}

			CheckPtr ICheckFactory::Get(const Json::Value& info)
			{
				int type = info["type"].asInt();
				if (type <= Empty || type >= PTMax)
					return _creator_map[Empty](info);
				return _creator_map[type](info);
			}

			CheckPtr2 ICheckFactory::Get2(const Json::Value& info)
			{
				int type = info["type"].asInt();
				if (type <= Empty || type >= NTMax)
					return _creator_map2[Empty](info);
				return _creator_map2[type](info);
			}

			ParamPtr GetParam(const mongo::BSONElement& obj)
			{
				std::vector<mongo::BSONElement> ele = obj.Array();
				int type = ele[0u].Int();
				switch (type)
				{
					case (INT_ARRAY - 1):
					case INT_ARRAY:
						return Creator<IntArray>::Create(obj);
					default:
						return ParamPtr();
				}
			}
		}
	}
}


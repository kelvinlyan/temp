//###################################
//create by Jim
//2016-10-26
//###################################

#pragma once

#include "auto_do.h"

namespace gg
{
	namespace PLAYERSHOP
	{
		enum
		{
			search_shop = 0,
			fame_shop,
			hero_shop,
			kingdom_shop,
			kingdom_war_shop,
			expedition_shop,
			inter_shop,
			reputation_shop,
			shop_num,
		};

		struct Record
		{
			Record(int id, int buy_times)
				: _id(id), _buy_times(buy_times) {}

			int _id;
			int _buy_times;
		};

		STDVECTOR(Record, ListReord);

		class Data :
			public _auto_player
		{
		public:
			Data(playerData* const own, const int type);
			~Data() {}
			void update();
			int buy(const int pos, const int id, Json::Value& r);
			int flush();
			void reset();
			const int ShopType;//�̵�����ID
			virtual void classLoad();
		private:
			void check();
			virtual void _auto_update();
			virtual bool _auto_save();
			ListReord _records;
			unsigned _flush_times;
		};
		BOOSTSHAREPTR(Data, ptrData);
	}

	class playerShops :
		public _auto_player
	{
	public:
		playerShops(playerData* const own);
		~playerShops() {}
		virtual void classLoad();
		void dailyReset();
		void update(const int type);
		int buy(const int type, const int pos, const int id, Json::Value& r);
		int flush(const int type);
	private:
		std::vector<PLAYERSHOP::ptrData> _shops;
	};
}

#include "game_server.h"
#include "core_helper.h"
#include <boost/lexical_cast.hpp>
#include "common_protocol.h"
#include "service_config.h"
#include "mongoDB.h"
#include "timmer.hpp"
#include "auto_base.h"
#include "gm_tools.h"
#include "game_inter_protocol.h"
#include "inter_game.h"

namespace gg
{
	boost::asio::deadline_timer& deadlineTimer()
	{
		static boost::asio::deadline_timer dt(IOMgr.otherIO(gg::DangerIO::logic_io));
		return dt;
	}

	game::this_ptr game::getInstance()
	{
		static this_ptr p(new game());
		return p;
	}

	game::game()
	{
		tick = boost::get_system_time();
		been_initial = false;
		is_run = true;
	}

	game::~game()
	{

	}

	void game::async_send_to_inter(net::Msg& mj)
	{
		inter_connect->write_buffer(mj);
	}


	void game::async_send_to_db(net::Msg& mj)
	{
#if !(defined(_WIN32) || defined(_WIN64))
		log_connect->write_buffer(mj);
#endif
	}

// 	void game::async_send_to_gate(const short protocol, Json::Value& msg, const int netID, const int playerID)
// 	{
// 		string str = msg.toIndentString();
// 		net::Msg mj(protocol, str);
// 		mj.playerID = playerID;
// 		mj.netID = netID;
// 		async_send_to_gate(mj);
// 	}

	void game::async_send_to_gate(net::Msg& mj)
	{
		ClientMap::iterator it = _clients.find(service::process_id::GATE_NET_ID);
		if (it != _clients.end())
		{
//			LogI << "s2c: (" << mj.playerID << ") (" << mj.protocolID << ") " << mj.strUTF8 << LogEnd;
			it->second->write_buffer(mj);
		}
	}

	void game::start_accept()
	{	
		net::linkLocalPtr link =
			net::localLink::Create(IOMgr.netIO(),
			service::process_id::GATE_NET_ID);
		_ap->async_accept(link->socket(),
			boost::bind(&game::handle_accept, this, link,
			boost::asio::placeholders::error));
	}

	bool game::is_go_on_accept()
	{
		//if(_clients.size() >= game_data.client_limit)return false;
		return true; 
	}

	void game::begin_on_accept(net::linkLocalPtr conn_ptr)
	{
		if (conn_ptr->netID == service::process_id::GATE_NET_ID)
		{
			net::ptrMsg msg_ptr = Creator<net::Msg>::Create(-1, service::process_id::SERVER_ROOT_ID, (short)game_protocol::comomon::gate_restart_req);
			addMsg(msg_ptr);
		}
	}
	void game::end_on_accept(net::linkLocalPtr conn_ptr)
	{
		if (conn_ptr->netID == service::process_id::GATE_NET_ID)
		{
			if (!been_initial)
			{
				net::Msg mj(-1, service::process_id::SERVER_ROOT_ID, (short)game_protocol::comomon::game_process_restart_resp);
				been_initial = true;
				conn_ptr->write_buffer(mj);
			}
		}
	}

	void game::stop()
	{
		IOMgr.stop();
		is_run = false;
	}

	void game::initial()
	{
		Json::Value game_json = Common::loadJsonFile("./server/game_cfg.json");
		Json::Value common_json = Common::loadJsonFile("./server/common_cfg.json");
		game_data.client_limit = game_json["client_limit"].asUInt();
		game_data.port = game_json["port"].asInt();
		game_data._mongoDB = game_json["mongodb"].asString();
		game_data._sql_ip = game_json["sql_ip"].asString();
		game_data._sql_port = game_json["sql_port"].asString();

		if (!db_mgr.InitialMongo(game_data._mongoDB.c_str()))
		{
			LogE << "can not link mongodb..." << LogEnd;
			Common::sleep(3800000);
			abort();
			return;
		}
		

		IOMgr.start(DangerIO::gg_count, 200000);

		_ap = LocalAcceptor(new boost::asio::ip::tcp::acceptor(IOMgr.netIO(),
			boost::asio::ip::tcp::endpoint(boost::asio::ip::tcp::v4(), game_data.port)));
		start_accept();

		//TODO: init here
		initCommon();
		int step = Common::random() % 1000;
		for (int i = 0; i < step; ++i)NumberCounter::Step();
		State::setState(-1);

		{//ʱ��ƫ��
			mongo::BSONObj key = BSON("key" << 1);
			mongo::BSONObj obj = db_mgr.FindOne(DBN::dbTimeTable, key);
			if (!obj.isEmpty())
			{
				Common::setTimeDev(unsigned(obj["dev"].Int()));
			}
		};

		game_handler = handler::pointer(new handler());
		LogS << "try to connect log svr..." << LogEnd;
		log_connect = net::localLink::Create(IOMgr.netIO(), 
			service::process_id::DB_NET_ID);
		connect_log_svr();
		inter_connect = net::localLink::Create(IOMgr.netIO(),
			service::process_id::INTER_NET_ID);

		//TODO
		InitialGame();
		
		Timer::StartTimer();
		LogicPost(boost::bind(&game::on_update,this));
		LogI << color_green("game server start..") << LogEnd;
	}

	void game::delay_reconnect_inter_svr()
	{
		inter_connect->stop_link();
		deadlineTimer().expires_from_now(boost::posix_time::seconds(5));
		deadlineTimer().async_wait(boost::bind(&InterGame::connect_inter_server, InterGame::_Instance));
	}

	void game::connect_inter_svr(const string ip, const string port)
	{
		connect(inter_connect, ip.c_str(), port.c_str());
	}

	void game::connect_log_svr()
	{
#if !(defined(_WIN32) || defined(_WIN64))
		connect(log_connect, game_data._sql_ip.c_str(), game_data._sql_port.c_str());
#endif
	}

	void game::connect(net::linkLocalPtr connector, const char* ip_str, const char* port_str)
	{
		if(connector->get_link_state() > net::gs_null)return;
		connector->set_link_state(net::gs_connect);
		boost::asio::ip::tcp::resolver resolver(connector->socket().get_io_service());
		boost::asio::ip::tcp::resolver::query query(ip_str, port_str);
		boost::asio::ip::tcp::resolver::iterator iterator = resolver.resolve(query);

		boost::asio::async_connect(connector->socket(), iterator,
			boost::bind(&game::handle_connect,this,connector,
			boost::asio::placeholders::error));
	}

	void game::handle_connect(net::linkLocalPtr connector, const boost::system::error_code& error)
	{
		if(!is_run)return;
		boost::mutex::scoped_lock lock(_mutex);
		if (!error)
		{	
				connector->start_link(shared_from_this());
				connector->set_link_state(net::gs_run);
				if(connector == log_connect)
				{
					LogI<<  "log / db  server connected ..." <<LogEnd;
				}
				else if (connector == inter_connect)
				{
					LogI << "inter game server connected ..." << LogEnd;
					const static string pubVerHead = "sKSNomIpOUoHP7oEu55J4JI+kU2sDJaDe03bwc8QRMu93VOXiD3VBytBvjCqg2CzbftR0jBq / bKazCkT1cJMABy7hVqXgzL2S + Lamx8DsUpbbZ5YVK";
					const static string pubVerTail = "vfEugS3CUtRoxXH9HnXiYSz7uv + CtVXJcPEl8 / l9gzQs3pYGyCq5i99qEFv4 / yIwPEOHJ1NaKBzYZ0XDQEpcjL + Hoc8Ncq7Z60FhuOJ8fsIzZN1Vd62yfBTxHuqdmOtxqCTPNsp3Yha + Db";
					const int serverID = Common::serverID();
					const string md5_str = pubVerHead + Common::toString(serverID) + pubVerTail;
					MD5 md5(md5_str);
					string ver_info = md5.md5();
					inter_connect->write_buffer(net::Msg(serverID, service::process_id::INTER_NET_ID, inter_game::identity_verification_req, ver_info));
					inter_svr.on_connect_sucess();
				}
		}
		else
		{
// 			if(error == boost::asio::error::would_block)
// 			{
// 				LogE <<  "************* server is blocking, id:\t" << connector->netID << "  *********" << LogEnd;
// 				return;
// 			}
			connector->set_link_state(net::gs_null);
			if(connector->netID == service::process_id::DB_NET_ID)
			{
				LogE << error << LogEnd;
				LogE <<  "************* can not connect to db server *********" <<LogEnd;
				deadlineTimer().expires_from_now(boost::posix_time::seconds(5));
				deadlineTimer().async_wait(boost::bind(&game::connect_log_svr, this));
			}
			else if (connector->netID == service::process_id::INTER_NET_ID)
			{
				LogE << error << LogEnd;
				LogE << "************* can not connect to inter server *********" << LogEnd;
				deadlineTimer().expires_from_now(boost::posix_time::seconds(5));
				deadlineTimer().async_wait(boost::bind(&InterGame::connect_inter_server, InterGame::_Instance));
			}
		}
	}

	void game::on_update()
	{
		if (!is_run)return;
		boost::system_time tmp = boost::get_system_time();
		while(true)
		{
			// lock lock lock
			boost::mutex::scoped_lock lock(_qmutex);
			if(!_msgs.empty()){
				net::ptrMsg p = _msgs.front();
				_msgs.pop();
				// unlock
				lock.unlock();
				std::string logstr = "[NID:";
				logstr += boost::lexical_cast<string,int>(p->netID);
				logstr += "] [PID:";
				logstr += boost::lexical_cast<string,int>(p->playerID);
				logstr += "] [TYPE:";
				logstr += boost::lexical_cast<string,short>(p->protocolID);
				logstr += "]";
				time_logger l(logstr.c_str());
				on_recv_msg(p);
			}else{
				break;
			}

			boost::system_time now = boost::get_system_time();
			if ((now - tmp).total_milliseconds() >= 100){
				break;
			}
		}

		if((tmp - tick).total_milliseconds() > 300000)
		{
			tick = tmp;
			checkkick(tmp);
			sendheartbeat();
		}

		Common::sleep(1);
		LogicPost(boost::bind(&game::on_update, this));
	}

	void game::sendheartbeat()
	{
		net::Msg mj(-1, service::process_id::GAME_NET_ID, game_protocol::comomon::keep_alive_req);
		if(log_connect->get_link_state() == net::gs_run)log_connect->write_buffer(mj);
		if (inter_connect->get_link_state() == net::gs_run)inter_connect->write_buffer(mj);
	}

	void game::socket_error(net::linkLocalPtr session, int error_value)
	{
		if(session == log_connect)
		{
			if (session->get_link_state() != net::gs_connect)
				log_connect->stop_link();
			else
				return;
			deadlineTimer().expires_from_now(boost::posix_time::seconds(5));
			deadlineTimer().async_wait(boost::bind(&game::connect_log_svr, this));
		}
		else if (session == inter_connect)
		{
			if (session->get_link_state() != net::gs_connect)
				inter_connect->stop_link();
			else
				return;
			deadlineTimer().expires_from_now(boost::posix_time::seconds(5));
			deadlineTimer().async_wait(boost::bind(&InterGame::connect_inter_server, InterGame::_Instance));
		}
		else
		{
			queue_server::socket_error(session, error_value);
		}
	}

	void game::on_recv_msg(const net::ptrMsg recv_msg_ptr)
	{
		int netID = recv_msg_ptr->netID;
		if(netID == service::process_id::DB_NET_ID){
			game_handler->recv_client_handler(log_connect, *recv_msg_ptr);
		}else
		if (netID == service::process_id::INTER_NET_ID) {
			game_handler->recv_local_handler(inter_connect, *recv_msg_ptr);
		}else
		if(gm_mgr.is_from_gm_http(netID))
		{
			boost::mutex::scoped_lock l(_mutex);
			ClientMap::iterator it = _clients.find(service::process_id::GATE_NET_ID);
			if (it == _clients.end())return;
			game_handler->recv_local_handler(it->second, *recv_msg_ptr);
		}else
		if (netID == service::process_id::INVAILD_PLAYER_ID)
		{
			if(recv_msg_ptr->playerID <= 0)
			{
				LogE << "vaild netID with a invaild playerID : " << recv_msg_ptr->playerID <<
					"\tmsg type : " << recv_msg_ptr->protocolID << LogEnd;
				return;
			}
			boost::mutex::scoped_lock l(_mutex);
			ClientMap::iterator it = _clients.find(service::process_id::GATE_NET_ID);
			if (it == _clients.end())return;
			game_handler->recv_client_handler(it->second, *recv_msg_ptr);
		}else
		if (netID == service::process_id::SERVER_ROOT_ID)
		{
			boost::mutex::scoped_lock l(_mutex);
			ClientMap::iterator it = _clients.find(service::process_id::GATE_NET_ID);
			if (it == _clients.end())return;
			game_handler->recv_client_handler(it->second, *recv_msg_ptr);
		}else
		if(netID == service::process_id::ACCOUNT_NET_ID)
		{
			boost::mutex::scoped_lock l(_mutex);
			ClientMap::iterator it = _clients.find(service::process_id::GATE_NET_ID);
			if (it == _clients.end())return;
			game_handler->recv_local_handler(it->second, *recv_msg_ptr);
		}
		else
		{
		}
	}

	void game::checkkick(boost::system_time& now)
	{
		boost::mutex::scoped_lock lock(_mutex);
		ClientMap::iterator ite = _clients.begin();
		for (; ite != _clients.end();)
		{
			net::linkLocalPtr session = ite->second;
			++ite;//!!!cause the ite may earse in the follow function -> kick_client() -> _client.erase() so it must plus plus first!!!
			if(!session->is_alive(300000)){
				kick(session, false);			
				continue;
			}
		}
	}

	void game::kick(net::linkLocalPtr session, bool notify /* = false */)
	{
		_clients.erase(session->netID);
		if(notify)
		{	
			LogS << "Online:\t" << color_green(_clients.size()) << LogEnd;
		}
		session->stop_link();
	}

	void game::kick_async(net::linkLocalPtr session)
	{
		boost::mutex::scoped_lock l(_mutex);
		kick(session);
	}
}

#include "activity_player.h"

namespace gg
{
	ActivityPlayer* const ActivityPlayer::_Instance = new ActivityPlayer();

	void ActivityPlayer::initData()
	{
		_last_activity = 0;
		_now_activity = 0;
		mongo::BSONObj obj = db_mgr.FindOne(DBN::dbActivityPlayer, BSON("key" << 1));
		if (!obj.isEmpty())
		{
			_last_activity = obj["last"].Int();
			_now_activity = obj["now"].Int();
		}
	}

	void ActivityPlayer::tickActivityPlayer()
	{
		const static unsigned MaxActivityPlayerValue = 0x0FFFFFFF;
		if ((++_now_activity) > MaxActivityPlayerValue)
		{
			_now_activity = MaxActivityPlayerValue;
			return;
		}
		save();
	}

	void ActivityPlayer::on5ClockUpdate()
	{
		_last_activity = _now_activity;
		_now_activity = 0;
		save();
	}

	void ActivityPlayer::save()
	{
		db_mgr.SaveMongo(DBN::dbActivityPlayer,
			BSON("key" << 1),
			BSON("key" << 1 << "last" << _last_activity << "now" << _now_activity)
		);
	}
}
//###################################
//create by Jim
//2016-11-07
//###################################

#pragma once

#include "dbDriver.h"

#define map_war_rank (*gg::MapWarRank::_Instance)

namespace gg
{
	namespace NSWarRank
	{
		struct Rankey
		{
			Rankey()
			{
				playerID = -1;
				passTime = 0;
				lastWinMap = 0;
			}
			Rankey(playerDataPtr player)
			{
				playerID = player->ID();
				passTime = player->War().lastWinMapTime();
				lastWinMap = player->War().lastWinMap();
			}
			bool operator<(const Rankey& other)const
			{
				if (lastWinMap != other.lastWinMap)return lastWinMap > other.lastWinMap;
				if (passTime != other.passTime)return passTime < other.passTime;
				return playerID < other.playerID;
			}
			bool operator>(const Rankey& other)const
			{
				return *this < other;
			}
			int playerID;
			unsigned passTime;
			int lastWinMap;
		};

		struct RankData
		{
			Rankey Key()
			{
				Rankey key;
				key.playerID = playerID;
				key.passTime = passTime;
				key.lastWinMap = lastWinMap;
				return key;
			}
			RankData()
			{
				playerID = -1;
				playerName = "";
				passTime = 0;
				lastWinMap = 0;
				rankNo = 0;
			}
			RankData(playerDataPtr player)
			{
				setNewData(player);
				rankNo = 0;
			}
			void setNewData(playerDataPtr player)
			{
				playerID = player->ID();
				playerName = player->Name();
				passTime = player->War().lastWinMapTime();
				lastWinMap = player->War().lastWinMap();
			}
			bool isNull()
			{
				return playerID < 0 || lastWinMap < 0;
			}
			int playerID;
			string playerName;
			unsigned passTime;
			int lastWinMap;
			int rankNo;
		};

		BOOSTSHAREPTR(RankData, ptrRankData);

		STDMAP(Rankey, ptrRankData, RankMap);
		STDMAP(int, ptrRankData, PlayerMap);
	}

	class MapWarRank
	{
	public:
		MapWarRank() { isInitial = false; }
		static MapWarRank* const _Instance;
		void initData();
		DeclareRegFunction(RankList);
	public:
		inline NSWarRank::RankMap getRankMap() { return Rank; }
		void updatePlayer(playerDataPtr player);
		void sendLog();
	private:
		NSWarRank::ptrRankData getData(const int playerID);
		int getRank(const int playerID);

		NSWarRank::RankMap Rank;
		NSWarRank::PlayerMap Player;

		bool isInitial;
	};
}

#include "player_treasure.h"
#include "playerManager.h"
#include "treasure_system.h"

namespace gg
{
	enum
	{
		ATTRI = 0,
		Skill,

		Unvalid_Skill = -2,

		Talent1 = 1,
		Talent2,
		OwnTalent,

		VALUE = 0,
		RATE,
	};

	struct AttriItem
	{
		AttriItem(const Json::Value& info)
		{
			idx = info[0u].asInt();
			val = info[1u].asInt();
		}
		int idx;
		int val;
	};

	STDVECTOR(AttriItem, AttriList);

	struct AttriItem2
	{
		AttriItem2(const Json::Value& info)
		{
			type = info[0u].asInt();
			idx = info[1u].asInt();
			if (type == 0)
				val = info[2u].asInt();
			else
				rate = info[2u].asDouble();
		}
		int type;
		int idx;
		union{
			int val;
			double rate;
		};
	};

	STDVECTOR(AttriItem2, AttriList2);

	struct ResItem
	{
		ResItem(const Json::Value& info)
		{
			id = info[1u].asInt();
			num = info[2u].asInt();
		}
		int id;
		int num;
	};

	STDVECTOR(ResItem, ResItemList);

	static bool itemEnough(playerDataPtr d, const ResItemList& rl)
	{
		ForEachC(ResItemList, it, rl)
		{
			if (d->Items().itemNum(it->id) < it->num)
				return false;
		}
		return true;
	}

	static Json::Value removeItem(playerDataPtr d, const ResItemList& rl)
	{
		Json::Value res_json = Json::arrayValue;
		ForEachC(ResItemList, it, rl)
		{
			d->Items().removeItem(it->id, it->num);
			Json::Value tmp;
			tmp.append(ACTION::item);
			tmp.append(it->id);
			tmp.append(it->num);
			res_json.append(tmp);
		}
		return res_json;
	}

	class Talent;
	BOOSTSHAREPTR(Talent, TalentPtr);

	struct Talent
	{
		Talent(const Json::Value& info)
		{
			id = info["id"].asInt();
			const Json::Value& tmp = info["attribute"];
			ForEachC(Json::Value, it, tmp)
				attri.push_back(AttriItem2(*it));
			skill_id = info["skill_id"].asInt();
			cost = info["cost"].asInt();
			talent_type = info["talent_type"].asInt();
			const Json::Value& ml = info["man_list"];
			ForEachC(Json::Value, it, ml)
				man_list.insert((*it).asInt());
			extra_bv = info["battle_value"].asInt();
			lv_limit = info["lv_limit"].asInt();
		}

		int id;
		int skill_id;
		AttriList2 attri;
		int talent_type;
		TalentPtr higher_one;
		TalentPtr lower_one;
		std::set<int> man_list;
		int cost;
		int extra_bv;
		int lv_limit;
	};

	STDVECTOR(TalentPtr, TalentS);

	class TreasureConfMgr;

	struct TreasureConf 
	{
		STDMAP(std::string, TalentPtr, Attri4Map);
		TreasureConf(const Json::Value& info);
		TalentPtr getBelongTalent3(int lv, int man_id) const;
		TalentPtr getBelongTalent4(TalentPtr talent1, TalentPtr talent3) const
		{
			ostringstream os;
			os << talent1->id << talent3->id;
			Attri4Map::const_iterator it = attri4.find(os.str());
			return it == attri4.end()? TalentPtr() : it->second;
		}
		const AttriList& getAttri0(int lv) const { return attri0[lv-1]; }

		int id;
		AttriList attri_base;
		std::vector<AttriList> attri0;
		std::vector<ResItemList> attri0_cost;
		std::vector<TalentS> attri3;
		std::vector<int> belong_man;
		Attri4Map attri4;
	};
	
	BOOSTSHAREPTR(TreasureConf, TreasureConfPtr);

	class TalentMgr
	{
		STDMAP(int, TalentPtr, TalentMap);
		SINGLETON(TalentMgr);
		public:
			const TalentPtr GetTalent(int id) const
			{
				TalentMap::const_iterator it = _talent_map.find(id);
				return it == _talent_map.end()? TalentPtr() : it->second;
			}
		private:
			TalentMap _talent_map;
	};

	TalentMgr::TalentMgr()
	{
		const Json::Value info = Common::loadJsonFile("./instance/treasure/talent.json");
		ForEachC(Json::Value, it, info)
		{
			TalentPtr ptr = Creator<Talent>::Create(*it);
			_talent_map.insert(make_pair(ptr->id, ptr));
		}

		ForEachC(Json::Value, it, info)
		{
			int id = (*it)["id"].asInt();
			int higher_talent = (*it)["higher_talent"].asInt();
			TalentMap::iterator itt = _talent_map.find(id);
			TalentPtr lower_ptr = itt->second;
			lower_ptr->higher_one = GetTalent(higher_talent);
			if (lower_ptr->higher_one)
				lower_ptr->higher_one->lower_one = lower_ptr;
		}
	}

	class TreasureConfMgr
	{
		SINGLETON(TreasureConfMgr);
		STDMAP(int, TreasureConfPtr, TreasureConfMap);
		public:
			const TreasureConfPtr GetConf(int id) const
			{
				TreasureConfMap::const_iterator it = _conf_map.find(id);
				return it == _conf_map.end()? TreasureConfPtr() : it->second;
			}
			int OpenLv() const { return _open_lv; }
			int Talent1Low() const { return _talent1_low; }
			int Talent1High() const { return _talent1_high; }
			int Talent2Low() const { return _talent2_low; }
			int Talent2High() const { return _talent2_high; }
			int Talent3Low() const { return _talent3_low; }
			int Talent3High() const { return _talent3_high; }
		private:
			TreasureConfMap _conf_map;

			int _open_lv;
			int _talent1_low;
			int _talent1_high;
			int _talent2_low;
			int _talent2_high;
			int _talent3_low;
			int _talent3_high;
	};

	TreasureConf::TreasureConf(const Json::Value& info)
	{
		id = info["id"].asInt();
		const Json::Value& attri_info = info["attribute"];
		ForEachC(Json::Value, it, attri_info)
		{
			attri_base.push_back(AttriItem(*it));
		}
		const Json::Value& attri0_info = info["attribute0"];
		ForEachC(Json::Value, it, attri0_info)
		{
			AttriList al;
			const Json::Value& tmp = *it;
			ForEachC(Json::Value, ita, tmp)
				al.push_back(AttriItem(*ita));
			attri0.push_back(al);
		}
		const Json::Value& info_cost = info["cost"];
		ForEachC(Json::Value, it, info_cost)
		{
			ResItemList rl;
			const Json::Value& tmp = *it;
			ForEachC(Json::Value, itr, tmp)
				rl.push_back(ResItem(*itr));
			attri0_cost.push_back(rl);
		}
		const Json::Value& attri3_info = info["attribute3_id"];
		ForEachC(Json::Value, it, attri3_info)
		{
			TalentS ts;
			const Json::Value& tmp = *it;
			ForEachC(Json::Value, itt, tmp)
			{
				TalentPtr ptr = TalentMgr::shared().GetTalent((*itt).asInt());
				ts.push_back(ptr);
			}
			attri3.push_back(ts);
		}
		const Json::Value& belong_info = info["attribute_belong"];
		ForEachC(Json::Value, it, belong_info)
			belong_man.push_back((*it).asInt());
		const Json::Value& attri4_info = info["attribute4_id"];
		ForEachC(Json::Value, it, attri4_info)
		{
			const Json::Value& tmp = *it;
			ostringstream os;
			os << tmp[0u].asInt() << tmp[1u].asInt();
			TalentPtr ptr = TalentMgr::shared().GetTalent(tmp[2u].asInt());
			attri4.insert(make_pair(os.str(), ptr));
		}
	}

	TalentPtr TreasureConf::getBelongTalent3(int lv, int man_id) const
	{
		for (unsigned i = 0; i < belong_man.size(); ++i)
		{
			if (belong_man[i] == man_id)
			{
				TalentPtr ptr = attri3[1u][i];
				if (lv >= ptr->lv_limit)
					return ptr;
				ptr = attri3[0u][i];
				if (lv >= ptr->lv_limit)
					return ptr;
				return TalentPtr();
			}
		}
		return TalentPtr();
	}

	TreasureConfMgr::TreasureConfMgr()
	{
		{
			const Json::Value info = Common::loadJsonFile("./instance/treasure/treasure.json");
			ForEachC(Json::Value, it, info)
			{
				TreasureConfPtr ptr = Creator<TreasureConf>::Create(*it);
				_conf_map.insert(make_pair(ptr->id, ptr));
			}
		}
		{
			const Json::Value info = Common::loadJsonFile("./instance/treasure/param.json");
			_open_lv = info["open_lv"].asInt();
			_talent1_low = info["talent1_low"].asInt();
			_talent1_high = info["talent1_high"].asInt();
			_talent2_low = info["talent2_low"].asInt();
			_talent2_high = info["talent2_high"].asInt();
			_talent3_low = info["talent3_low"].asInt();
			_talent3_high = info["talent3_high"].asInt();
		}
	}
	
	playerTreasure::playerTreasure(playerData* const own, int id)
		: _auto_player(own), _lv(0), _wear_man(-1), _attri_valid(false), _skill_id(Unvalid_Skill)
	{
		_conf = TreasureConfMgr::shared().GetConf(id);
	}

	playerTreasure::playerTreasure(playerData* const own, const mongo::BSONObj& obj)
		: _auto_player(own), _attri_valid(false), _wear_man(-1), _skill_id(Unvalid_Skill)
	{
		int id = obj["id"].Int();
		_lv = obj["lv"].Int();
		_conf = TreasureConfMgr::shared().GetConf(id);
	}

	int playerTreasure::id() const
	{
		return _conf->id;
	}

	void playerTreasure::getGMInfo(Json::Value& info)
	{
		info = Json::arrayValue;
		info.append(id());
		info.append(_lv);
		info.append(_wear_man);
		info.append(_talent1? _talent1->id : -1);
		info.append(_talent2? _talent2->id : -1);
		playerManPtr man = Own().Man().findArmy(_wear_man);
		if (!man)
			info.append(-1);
		else
		{
			TalentPtr talent3 = _conf->getBelongTalent3(_lv, man->armyRawID());
			info.append(talent3? talent3->id : -1);
		}
	}

	bool playerTreasure::_auto_save()
	{
		mongo::BSONObj key = BSON(strPlayerID << Own().ID() << "id" << _conf->id);
		mongo::BSONObj obj = BSON(strPlayerID << Own().ID() << "id" << _conf->id << "lv" << _lv); 
		return db_mgr.SaveMongo(DBN::dbPlayerTreasure, key, obj);
	}

	void playerTreasure::_auto_update()
	{
		qValue m;
		m.append(res_sucess);
		qValue q;
		getInfo(q);
		m.append(q);
		Own().sendToClientFillMsg(gate_client::player_treasure_update_resp, m);
	}

	void playerTreasure::getInfo(qValue& q) const
	{
		q << id() << _lv << (_talent1? _talent1->id : -1) << (_talent2? _talent2->id : -1) << _wear_man;
	}

	int playerTreasure::skillID()
	{
		if (_skill_id == Unvalid_Skill)
			_skill_id = recalSkillID();
		return _skill_id;
	}

	int playerTreasure::recalSkillID()
	{
		playerManPtr man = Own().Man().findArmy(_wear_man);
		if (!man) return -1;
		TalentPtr talent3 = _conf->getBelongTalent3(_lv, man->armyRawID());
		if (!talent3 || talent3->skill_id == -1)
		{
			if (!_talent1)
				return -1;
			else
				return _talent1->skill_id;
		}
		else
		{
			if (!_talent1 || _talent1->skill_id == -1)
				return talent3->skill_id;
			else
			{
				TalentPtr t4 = _conf->getBelongTalent4(_talent1, talent3);
				if (!t4)
					LogE << "talent1: " << _talent1->id << ", talent3: " << talent3->id << LogEnd;
				return t4? t4->skill_id : -1;
			}
		}
	}

	int playerTreasure::extraBV()
	{
		if (!_attri_valid)
			recalAttri();
		return _extra_bv;
	}

	const int* playerTreasure::attri()
	{
		if (!_attri_valid)
			recalAttri();
		return _attri;
	}

	const double* playerTreasure::attriRate()
	{
		if (!_attri_valid)
			recalAttri();
		return _attri_rates;
	}

	void playerTreasure::recalAttri()
	{
		memset(_attri, 0x0, sizeof(_attri));
		for (unsigned i = 0; i < characterNum; ++i)
			_attri_rates[i] = 1.0;
		_extra_bv = 0;
		playerManPtr man = Own().Man().findArmy(_wear_man);
		if (!man) return;
		const AttriList& attri_base = _conf->attri_base;
		ForEachC(AttriList, it, attri_base)
			_attri[it->idx] += it->val;
		const AttriList& attri0 = _conf->getAttri0(_lv);
		ForEachC(AttriList, it, attri0)
			_attri[it->idx] += it->val;
		if (_talent1)
		{
			_extra_bv += _talent1->extra_bv;
			ForEachC(AttriList2, it, _talent1->attri)
			{
				if (it->type == VALUE)
					_attri[it->idx] += it->val;
				else
					_attri_rates[it->idx] += it->rate;
			}
		}
		if (_talent2)
		{
			_extra_bv += _talent2->extra_bv;
			ForEachC(AttriList2, it, _talent2->attri)
			{
				if (it->type == VALUE)
					_attri[it->idx] += it->val;
				else
					_attri_rates[it->idx] += it->rate;
			}
		}
		TalentPtr talent3 = _conf->getBelongTalent3(_lv, man->armyRawID());
		if (talent3)
		{
			_extra_bv += talent3->extra_bv;
			ForEachC(AttriList2, it, talent3->attri)
			{
				if (it->type == VALUE)
					_attri[it->idx] += it->val;
				else
					_attri_rates[it->idx] += it->rate;
			}
		}
		_attri_valid = true;
	}

	int playerTreasure::upgrade(int type)
	{
		if (Own().LV() < TreasureConfMgr::shared().OpenLv())
			return err_illedge;
		TreasureConfPtr ptr = TreasureConfMgr::shared().GetConf(id());
		if (!ptr) return err_illedge;
		unsigned times = type == 0? 1 : 10;
		unsigned suc_times = 0;
		int break_reason = res_sucess;
		for (unsigned i = 0; i < times; ++i)
		{
			if (_lv >= ptr->attri0.size())
			{
				break_reason = err_treasure_reach_max_lv;
				break;
			}
			int cost_idx = _lv;
			if (cost_idx >= ptr->attri0_cost.size())
				cost_idx = ptr->attri0_cost.size() - 1;
			if (!itemEnough(Own().getOwnDataPtr(), ptr->attri0_cost[cost_idx]))
			{
				break_reason = err_item_not_enough;
				break;
			}
			Json::Value res_json = removeItem(Own().getOwnDataPtr(), ptr->attri0_cost[cost_idx]);
			++_lv;
			++suc_times;
			if (_lv == 1)
				Log(DBLOG::strLogTreasure, Own().getOwnDataPtr(), 0, id(), "", "", "", "", "", "", res_json.toIndentString());
			else
				Log(DBLOG::strLogTreasure, Own().getOwnDataPtr(), 1, id(), _lv, "", "", "", "", "", res_json.toIndentString());
		}
		if (suc_times > 0)
		{
			_skill_id = Unvalid_Skill;
			_attri_valid = false;
			switchTalent();
			tickManAttri();
			_sign_auto();
			return res_sucess;
		}
		else
		{
			return break_reason;
		}
	}

	void playerTreasure::tickManAttri()
	{
		if (_wear_man == -1)
			return;
		playerManPtr man = Own().Man().findArmy(_wear_man);
		if (!man)
			return;
		man->recalExtraAttri();
	}

	int playerTreasure::talentEnabled(TalentPtr ptr)
	{
		if (_wear_man == -1)
			return err_illedge;
		playerManPtr man = Own().Man().findArmy(_wear_man);
		if (!man) return err_illedge;
		if (ptr->man_list.find(man->armyRawID()) == ptr->man_list.end())
			return err_treasure_man_not_match;
		if (Own().Res().getCash() < ptr->cost)
			return err_cash_not_enough;
		if (ptr->higher_one && _lv < ptr->lv_limit)
			return err_illedge;
		if (ptr->lower_one && _lv < ptr->lower_one->lv_limit)
			return err_illedge;
		return res_sucess;
	}

	int playerTreasure::activeTalent(int type, int tid)
	{
		if (Own().LV() < TreasureConfMgr::shared().OpenLv())
			return err_illedge;
		playerManPtr man = Own().Man().findArmy(_wear_man);
		if (!man) return err_illedge;
		const TalentPtr ptr = TalentMgr::shared().GetTalent(tid);
		if (!ptr) return err_illedge;
		if (type < 1 || type > 2 || type != ptr->talent_type)
			return err_illedge;
		int res = talentEnabled(ptr);
		if (res != res_sucess)
			return res;
		int prev_id, cur_id;
		Own().Res().alterCash(0-ptr->cost);
		if (type == 1)
		{
			prev_id = _talent1? _talent1->id : -1;
			_talent1 = getCorrectTalent(ptr->id);
			cur_id = _talent1? _talent1->id : -1;
			man->setTalent1(_talent1->id);
		}
		else
		{
			prev_id = _talent2? _talent2->id : -1;
			_talent2 = getCorrectTalent(ptr->id);
			cur_id = _talent2? _talent2->id : -1;
			man->setTalent2(_talent2->id);
		}
		_attri_valid = false;
		_skill_id = Unvalid_Skill;
		tickManAttri();
		_sign_update();
		Log(DBLOG::strLogTreasure, Own().getOwnDataPtr(), 2, prev_id, cur_id, ptr->cost, _wear_man, "", "", "", "");
		return res_sucess;
	}

	int playerTreasure::initFromMan(int man_id, int tid1, int tid2)
	{
		if (_wear_man != -1)
			return err_illedge;
		_wear_man = man_id;
		_talent1 = getCorrectTalent(tid1);
		_talent2 = getCorrectTalent(tid2);
		return res_sucess;
	}

	int playerTreasure::wear(int man_id)
	{
		if (Own().LV() < TreasureConfMgr::shared().OpenLv())
			return err_illedge;
		if (_wear_man == man_id)
			return err_illedge;
		_attri_valid = false;
		playerManPtr from, to;
		if (_wear_man != -1)
		{
			from = Own().Man().findArmy(_wear_man);
			if (!from) return err_illedge;
			from->unloadTreasure();
		}
		to = Own().Man().findArmy(man_id);
		if (!to) return err_illedge;
		_wear_man = man_id;
		_skill_id = Unvalid_Skill;
		_talent1 = getCorrectTalent(to->talent1());
		_talent2 = getCorrectTalent(to->talent2());
		to->wearTreasure(upCast<playerTreasure>(shared_from_this()));
		_sign_update();
		return res_sucess;
	}

	int playerTreasure::unload(int man_id)
	{
		if (_wear_man != man_id)
			return err_illedge;
		playerManPtr man = Own().Man().findArmy(_wear_man);
		if (!man) return err_illedge;
		_wear_man = -1;
		man->unloadTreasure();
		_sign_update();
		return res_sucess;
	}

	void playerTreasure::clear(int man_id)
	{
		if (man_id == _wear_man)
		{
			_wear_man = -1;
			_sign_update();
		}
	}

	TalentPtr playerTreasure::getCorrectTalent(int id)
	{
		TalentPtr ptr = TalentMgr::shared().GetTalent(id);
		if (!ptr) return TalentPtr();
		if (_lv < ptr->lv_limit)
		{
			if (ptr->lower_one && _lv >= ptr->lower_one->lv_limit)
				return ptr->lower_one;
			return TalentPtr();
		}
		else
		{
			if (ptr->higher_one && _lv >= ptr->higher_one->lv_limit)
				return ptr->higher_one;
			return ptr;
		}
	}

	void playerTreasure::switchTalent()
	{
		playerManPtr man = Own().Man().findArmy(_wear_man);
		if (!man) return;
		bool modified = false;
		if (!_talent1)
		{
			if (man->talent1() != -1)
			{
				_talent1 = getCorrectTalent(man->talent1());
				if (_talent1)
					modified = true;
			}
		}
		else
		{
			if (_talent1->higher_one && _lv >= _talent1->higher_one->lv_limit)
			{
				_talent1 = _talent1->higher_one;
				modified = true;
			}
		}
		if (!_talent2)
		{
			if (man->talent2() != -1)
			{
				_talent2 = getCorrectTalent(man->talent2());
				if (_talent2)
					modified = true;
			}
		}
		else
		{
			if (_talent2->higher_one && _lv >= _talent2->higher_one->lv_limit)
			{
				_talent2 = _talent2->higher_one;
				modified = true;
			}
		}
		if (modified)
		{
			_attri_valid = false;
			_skill_id = Unvalid_Skill;
			_sign_auto();
		}
	}

	std::vector<int> playerTreasure::getTalentList()
	{
		playerManPtr man = Own().Man().findArmy(_wear_man);
		if (!man) return std::vector<int>(3, -1);
		TalentPtr ptr = _conf->getBelongTalent3(_lv, man->armyRawID());
		std::vector<int> id_list;
		id_list.push_back(_talent1? _talent1->id : -1);
		id_list.push_back(_talent2? _talent2->id : -1);
		id_list.push_back(ptr? ptr->id : -1);
		return id_list;
	}

	void playerTreasure::modifyLv(int lv)
	{
		_lv = lv;
		switchTalent();
		_attri_valid = false;
		tickManAttri();
		_sign_auto();
	}

	playerTreasureMgr::playerTreasureMgr(playerData* const own)
		: _auto_player(own)
	{}

	void playerTreasureMgr::classLoad()
	{
		mongo::BSONObj key = BSON(strPlayerID << Own().ID());
		objCollection objs = db_mgr.Query(DBN::dbPlayerTreasure, key);
		for (unsigned i = 0; i < objs.size(); ++i)
		{
			TreasurePtr ptr = Creator<playerTreasure>::Create(_Own, objs[i]);
			_treasure_map.insert(make_pair(ptr->id(), ptr));
		}
	}

	void playerTreasureMgr::update()
	{
		qValue m;
		m.append(res_sucess);
		qValue q;
		ForEachC(TreasureMap, it, _treasure_map)
		{
			qValue tmp;
			it->second->getInfo(tmp);
			q.append(tmp);
		}
		m.append(q);
		Own().sendToClientFillMsg(gate_client::player_treasure_info_resp, m);
	}
	
	int playerTreasureMgr::activeTalent(int id, int type, int talent_id)
	{
		TreasurePtr ptr = getTreasure(id);
		if (!ptr) return err_illedge;
		return ptr->activeTalent(type, talent_id);
	}

	int playerTreasureMgr::upgrade(int id, int type)
	{
		TreasurePtr ptr = getTreasure(id);
		bool is_new = false;
		if (!ptr)
		{
			TreasureConfPtr conf = TreasureConfMgr::shared().GetConf(id);
			if (!conf)
				return err_illedge;
			ptr = Creator<playerTreasure>::Create(_Own, id);
			is_new = true;
		}
		int res = ptr->upgrade(type);
		if (is_new && res == res_sucess)
			_treasure_map.insert(make_pair(id, ptr));
		return res;
	}

	int playerTreasureMgr::wear(int id, int mid)
	{
		TreasurePtr ptr = getTreasure(id);
		if (!ptr) return err_illedge;
		return ptr->wear(mid);
	}

	void playerTreasureMgr::getGMInfo(Json::Value& info)
	{
		info = Json::arrayValue;
		ForEach(TreasureMap, it, _treasure_map)
		{
			Json::Value tmp;
			it->second->getGMInfo(tmp);
			info.append(tmp);
		}
	}

	int playerTreasureMgr::unload(int id, int mid)
	{
		TreasurePtr ptr = getTreasure(id);
		if (!ptr) return err_illedge;
		return ptr->unload(mid);
	}

	int playerTreasureMgr::modifyLv(int id, int lv)
	{
		TreasurePtr ptr = getTreasure(id);
		if (!ptr) return err_illedge;
		ptr->modifyLv(lv);
		return res_sucess;
	}

	void treasure_system::initData()
	{
		TalentMgr::shared();
		TreasureConfMgr::shared();
	}
}

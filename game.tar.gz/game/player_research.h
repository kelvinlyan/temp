//###################################
//create by Jim
//2016-04-21
//###################################

#pragma once

#include "auto_do.h"
#include "man_def.h"
#include "ownerland_def.h"

//�Ƽ���д

namespace gg
{
	namespace RESEARCH
	{
		STDMAP(int, unsigned, MilitaryTechMap);
	}

	struct militaryTech;
	BOOSTSHAREPTR(militaryTech, militaryTechPtr);

	class playerResearch :
		public _auto_player
	{
	public:
		playerResearch(playerData* const own);
		~playerResearch(){}
		static void initData();
		void getForAttr(const int iID, int* attri);// ��ȡָ���Ƽ�����
		const unsigned getForLV(const int iID);//�Ƽ��ȼ�
		inline const int* getWarAttri(){ return warAttri; }
		void sendResearch();// ���;������Ƽ����ݸ�ǰ��
		int researchUpgrade(const int iID, unsigned& iTimes);// �������Ƽ�����
		int getResearchData(const LAND::HomeType eHomeType);// ��ȡ�Ƽ�������
		int techReset();

		int getLvSum(int type = -1);
		int getMaxLv(int type = -1);
		int getTechNum(int type = -1);
		void updateTask(militaryTechPtr ptr);
		inline unsigned techResetTimes() { return techReseted; }
		Json::Value jsonTechData();
		void motifyTechByGM(const int id, const unsigned lv);
		void setData(mongo::BSONObj& obj);
	private:
		virtual bool _auto_save();
		virtual void _auto_update();
		RESEARCH::MilitaryTechMap militaryTechList;// �Ƽ�
		int warAttri[characterNum]; // �佫ͨ������
		int homeAttr[LAND::idx_home_type_num];// ��������
		unsigned techReseted;
	};
}

#pragma once

namespace gg
{
	namespace PASSIVE
	{
		enum//����ʱ��
		{
			_passive_tick_initial = 0,//��ʼ����ʱ��
			_passive_tick_on_add_power = 1,//����ʿ����ʱ��

			_passive_tick_num
		};

		enum//�����¼�
		{
			_passive_event_add_power = 0,//����ʿ��//ʵ��Ч��

			_passive_event_num
		};
		const static int DISPART = 1000;
		const static int MINEVENT = 0;
		const static int MAXEVENT = (_passive_event_num - 1) * DISPART + (_passive_tick_num - 1);
		static bool VaildEvent(const int id)
		{
			return (id >= MINEVENT && id <= MAXEVENT);
		}
		static int PassiveID2TickID(const int id)
		{
			return id % DISPART;
		}
		static int PassiveID2EventID(const int id)
		{
			return id / DISPART;
		}
		static int Combine2PassiveID(const int tick_id, const int event_id)
		{
			return (tick_id + event_id * DISPART);
		}
	}

	struct passiveBase
	{
		int _passive_id;//�������ͺʹ���ʱ��
	};

	struct passiveMP : public passiveBase
	{
		int _value;
	};

	union passiveData
	{
		passiveMP _passiveMP;
	};
	const static unsigned LenPassiveData = sizeof(passiveData);

	//��������//����������
	template<class type>
	struct interfaceIDResolve
	{
		type& _data;
		interfaceIDResolve(type& data) : _data(data) {}
		inline const int passive_id() const { return ((passiveBase*)(&_data))->_passive_id; }
		inline const int tick_id() const { return PASSIVE::PassiveID2TickID(passive_id()); }
		inline const int event_id() const { return PASSIVE::PassiveID2EventID(passive_id()); }
		inline const bool vaild_data() const { return PASSIVE::VaildEvent(passive_id()); }
	};
	//������������
	template<int type> struct passiveResolve {
		inline bool vaild_data() const { return false; }
	};
	template<>
	struct passiveResolve<0> :
		public interfaceIDResolve<passiveData>
	{
		const static int S_EVENT_TYPE = 0;
		typedef passiveResolve<0> _Type;
		passiveResolve(passiveData& data) : interfaceIDResolve<passiveData>(data) {}
		bool combine_passive(const _Type& other)
		{
			if (other.passive_id() != passive_id())return false;
			_data._passiveMP._value += other._data._passiveMP._value;
			return true;
		}
		const passiveMP& type_data() { return *((passiveMP*)&_data); }
		inline int get_value() { return _data._passiveMP._value; }
	};
	typedef passiveResolve<0>::_Type MP_1_Resolve;
}
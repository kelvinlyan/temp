#include "treasure_system.h"

namespace gg
{
	treasure_system* const treasure_system::_Instance = new treasure_system();

	void treasure_system::Info(net::Msg& m, Json::Value& r)
	{
		playerDataPtr player = player_mgr.getPlayer(m.playerID);
		if (!player)Return(r, err_illedge);
		player->Treasure().update();
	}

	void treasure_system::Upgrade(net::Msg& m, Json::Value& r)
	{
		playerDataPtr player = player_mgr.getPlayer(m.playerID);
		if (!player)Return(r, err_illedge);
		ReadJsonArray;
		int id = js_msg[0u].asInt();
		int type = js_msg[1u].asInt();
		int res = player->Treasure().upgrade(id, type);
		Return(r, res);
	}

	void treasure_system::ActiveTalent(net::Msg& m, Json::Value& r)
	{
		playerDataPtr player = player_mgr.getPlayer(m.playerID);
		if (!player)Return(r, err_illedge);
		ReadJsonArray;
		int id = js_msg[0u].asInt();
		int type = js_msg[1u].asInt();
		int tid = js_msg[2u].asInt();
		int res = player->Treasure().activeTalent(id, type, tid);
		Return(r, res);
	}

	void treasure_system::Wear(net::Msg& m, Json::Value& r)
	{
		playerDataPtr player = player_mgr.getPlayer(m.playerID);
		if (!player)Return(r, err_illedge);
		ReadJsonArray;
		int id = js_msg[0u].asInt();
		int mid = js_msg[1u].asInt();
		int res = player->Treasure().wear(id, mid);
		Return(r, res);
	}

	void treasure_system::GMInfo(net::Msg& m, Json::Value& r)
	{
		playerDataPtr player = player_mgr.getPlayer(m.playerID);
		if (!player)Return(r, err_illedge);
		player->Treasure().getGMInfo(r[strMsg][1u]);
		Return(r, res_sucess);
	}

	void treasure_system::GMModifyLV(net::Msg& m, Json::Value& r)
	{
		playerDataPtr player = player_mgr.getPlayer(m.playerID);
		if (!player)Return(r, err_illedge);
		ReadJsonArray;
		int id = js_msg[0u].asInt();
		int lv = js_msg[1u].asInt();
		int res = player->Treasure().modifyLv(id, lv);
		Return(r, res);
	}

	void treasure_system::Unload(net::Msg& m, Json::Value& r)
	{
		playerDataPtr player = player_mgr.getPlayer(m.playerID);
		if (!player)Return(r, err_illedge);
		ReadJsonArray;
		int id = js_msg[0u].asInt();
		int mid = js_msg[1u].asInt();
		int res = player->Treasure().unload(id, mid);
		Return(r, res);
	}
}

//###################################
//create by Jim
//2015-11-12
//###################################

#pragma once

#include "auto_do.h"

#define DICE_MAX	30	//���������

namespace gg
{
	typedef long long int LargerRes;

	class playerTick;

	class playerResource :
		public _auto_player
	{
		friend class playerTick;
	public:
		playerResource(playerData* const own);
		~playerResource(){}
		inline LargerRes getGold(){ return Gold; }//���
		inline LargerRes getTicket(){ return Ticket;}//��ȯ
		inline LargerRes getCash(){ return Gold + Ticket; }//���+��ȯ
		inline LargerRes getSilver(){ return Silver;/* +getCash() * 100;*/ }//����
		inline LargerRes getFood(){ return Food; }//��ʳ
		inline LargerRes getWood(){ return Wood; }//ľ
		inline LargerRes getIron(){ return Iron; }//��
		inline LargerRes getMerit(){ return Merit; }//����
		inline LargerRes getFame(){ return Fame; }//����
		inline LargerRes getRechargeNum() { return RechargeNum; }//��ֵ����/����
		inline LargerRes getAction(){ return Action; }//����//�ж�����
		inline LargerRes getHeroCoin(){ return HeroPartyMoney; }//ȺӢ����
		inline LargerRes getLadyCoin(){ return LadyCoin; }//����
		inline LargerRes getReportShare(){ return ReportShare; }
		inline LargerRes getSearchPoints(){ return SearchPoints; }
		inline LargerRes getExpeditionCoin(){ return ExpeditionCoin; }
		inline LargerRes getReputation(){ return Reputation; }
		inline LargerRes getDice() { return Dice; }
		inline LargerRes getRechargeCoin() { return RechargeCoin; }
		inline LargerRes getGameShare() { return GameShare; }
		inline LargerRes getGameSharePoint() { return GameSharePoint; }
		inline LargerRes getInterPoint() { return InterPoint; }

		int getExploit();
		int getContribution();
		inline bool getSupplyNoon() { return SupplyNoon; }
		inline bool getSupplyNight() { return SupplyNight; }

		//motify
		LargerRes alterGold(const int val, const bool isConsume = true);
		LargerRes alterTicket(const int val, const bool isConsume = true);
		LargerRes alterCash(const int val, const bool isConsume = true);
		LargerRes alterSilver(const int val);
		LargerRes alterFood(const int val);
		LargerRes alterWood(const int val);
		LargerRes alterIron(const int val);
		LargerRes alterMerit(const int val);
		LargerRes alterFame(const int val);
		LargerRes alterAction(const int val);
		LargerRes alterHeroCoin(const int val);
		LargerRes alterLadyCoin(const int val);
		LargerRes alterReportShare(const int val);
		LargerRes alterSearchPoints(const int val);
		LargerRes alterDice(const int val);
		LargerRes alterRechargeCoin(const int val);
		LargerRes alterExpeditionCoin(const int val);
		LargerRes alterReputation(const int val);
		LargerRes alterGameShare(const int val);
		LargerRes alterGameSharePoint(const int val);
		LargerRes alterInterPoint(const int val);

		void resetSupply();
		void setNoonTrue();
		void setNightTrue();
		int alterContribution(const int val);
		void addRechargeNum(const int num);
		void alterExploit(const int val);

		//other
		void setData(mongo::BSONObj& obj);
		virtual void _auto_update();
	private:
		void onAlterGold(const LargerRes old_val);
		void onAlterTicket(const LargerRes old_val);
		void onAlterAction(const LargerRes old_val);
		void onAlterContribution(const int alter_val);
		virtual bool _auto_save();
		void initial();
		LargerRes Gold;//���
		LargerRes Ticket;//���ͽ��
		LargerRes Silver;//����
		LargerRes Food;//��ʳ
		LargerRes Wood;//ľ��
		LargerRes Iron;//��
		LargerRes Merit;//����
		LargerRes Fame;//����
		LargerRes Action;//�ж���//����
		LargerRes HeroPartyMoney;//ȺӢ����
		LargerRes LadyCoin;//����
		LargerRes ReportShare;//ս����������
		LargerRes SearchPoints;//Ѱ�û���
		LargerRes RechargeNum;//��ֵ����
		LargerRes Dice;//��������
		LargerRes RechargeCoin;//��ֵ�ۿ۲���
		LargerRes ExpeditionCoin;//Զ����
		LargerRes Reputation;//����
		LargerRes GameShare;//��Ϸ����
		LargerRes GameSharePoint;//��Ϸ��������
		LargerRes InterPoint;//�������

		bool SupplyNoon;
		bool SupplyNight;
	};
}

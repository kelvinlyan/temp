#include "secondary_compensation_system.h"
//#include "action_def.h"

namespace gg
{
	
	secondary_cps::SecondaryCompensationConfig config;

	static int getGirlsIndex(int idx)
	{
		if (idx > -1)
		{
			return idx;
		}
		return lx::utility_lx::getProbIndex(config.Odds, config.Odds.back());
	}

	secondary_compensation_system* const secondary_compensation_system::_Instance = new secondary_compensation_system();

	secondary_compensation_system::secondary_compensation_system()
	{
	}

	void secondary_compensation_system::reqSecondaryInfo(net::Msg& m, Json::Value& r)
	{
		playerDataPtr player = player_mgr.getPlayer(m.playerID);
		if (!player)Return(r, err_illedge);

		TIME_T past = player->SecondaryCompensation().Begin();
		TIME_T now = Common::gameTime();
		//LogS << "now:" << now << "\tpast:" << past << "\tday-minus:" << DAY << "-" << now - past << LogEnd;
		if (past > now || now - past > DAY)
		{
			Return(r, err_secondary_compensation_out_of_date);
		}
		int reward_flag = player->SecondaryCompensation().Flag();
		if (reward_flag == 1)
		{
			Return(r, err_secondary_compensation_has_got_reward);
		}
		int gold = player->SecondaryCompensation().getGold();
		int flag = reward_flag == 2 ? 1 : 0;
		//if (flag == 1 && reward_flag != 2)
		//{
		//	player->SecondaryCompensation().setFlag(2);
		//}
		int time_rest = DAY - ((now - past) / SECOND);
		r[strMsg][0] = 0;
		r[strMsg][1] = player->SecondaryCompensation().getCardIDFirst();
		r[strMsg][2] = player->SecondaryCompensation().getCardIDSecond();
		r[strMsg][3] = flag;
		r[strMsg][4] = gold;
		r[strMsg][5] = config.gold;
		r[strMsg][6] = time_rest;
	}

	void secondary_compensation_system::reqSecondaryGetReward(net::Msg& m, Json::Value& r)
	{
		playerDataPtr player = player_mgr.getPlayer(m.playerID);
		if (!player)Return(r, err_illedge);

		if (player->Card().isOver(2))
		{
			Return(r, err_patrol_card_full);
		}
		if (player->SecondaryCompensation().Flag() != 2 || player->SecondaryCompensation().getCardIDFirst() < 0)
		{
			Return(r, err_action_is_not_allowed);
		}
		int id1 = player->SecondaryCompensation().getCardIDFirst();
		int id2 = player->SecondaryCompensation().getCardIDSecond();
		player->Card().addCard(id1, 1, 0);
		player->Card().addCard(id2, 1, 0);
		player->SecondaryCompensation().setFlag(1);
		Json::Value json = Json::arrayValue;
		json[0u] = ACTION::lady;
		json[1u] = 1;
		json[2u] = id1;
		Json::Value json2 = Json::arrayValue;
		json2[0u] = ACTION::lady;
		json2[1u] = 1;
		json2[2u] = id2;
		Json::Value json_log = Json::arrayValue;
		json_log[0u] = json;
		json_log[1u] = json2;
		Log(DBLOG::strLogSecondaryDay, player, 1, json_log.toIndentString(), player->SecondaryCompensation().getGold());

		Return(r, res_sucess);
	}

	void secondary_compensation_system::reqSecondaryRedPoint(net::Msg& m, Json::Value& r)
	{
		playerDataPtr player = player_mgr.getPlayer(m.playerID);
		if (!player)Return(r, err_illedge);

		//
		int cardID = player->SecondaryCompensation().getCardIDFirst();
		if (cardID == INVALID_CARDID)
		{
			int idx = getGirlsIndex(cardID);
			player->SecondaryCompensation().setCardIDFirst(config.pairs[idx].girls[0].cardID);
			player->SecondaryCompensation().setCardIDSecond(config.pairs[idx].girls[1].cardID);
		}
		//

		player->SecondaryCompensation()._auto_update();
	}

	void secondary_compensation_system::initData()
	{
		std::cout << "load ./secondary_day/girls.json START	" << std::endl;
		Json::Value girls = Common::loadJsonFile(std::string("./instance/secondary_day/girls.json"));
		config.gold = girls["gold"].asInt();
		config.Odds.resize(girls["girls"].size() + 1);
		config.Odds[0] = 0;
		for (int i = 0; i < girls["girls"].size(); ++i)
		{
			secondary_cps::Pairs pairs;
			pairs.girls[0].cardID = girls["girls"][i][0].asInt();
			pairs.girls[1].cardID = girls["girls"][i][1].asInt();
			config.pairs.push_back(pairs);
			config.Odds[i + 1] = girls["girls"][i][2].asInt();
			config.Odds[i + 1] += config.Odds[i];
		}

		std::cout << "load ./secondary_day/girls.json END	" << std::endl;
	}


	secondary_compensation_system::~secondary_compensation_system()
	{
	}
}

#pragma once

#include "auto_base.h"
#include "mongoDB.h"
#include "kingdomwar_report.h"

namespace gg
{
	namespace KingdomWar
	{
		enum
		{
			//reason
			Clear,
			Battle,
			UpManHp,
			GM,
			Others,
		};
	}

	class playerKingdomWar
		: public _auto_player
	{
		public:
			playerKingdomWar(playerData* const own);

			virtual void classLoad();
			virtual bool _auto_save();
			virtual void _auto_update();

			void updateParam();
			void updateReport();
			void updateRedPoint();
			void alterRedPoint(bool rp);

			int manHp(int man_id) const;
			void setManHp(int man_id, int hp);
			bool isDead(int army_id);
			
			std::string getReportID();
			void addReport(qValue& rep, int result, int state, int army_id);
			void addShadowReport(qValue& rep, int result);
			int useHpItem(int army_id);
			int buyHpItem(int num);
			int getBox(Json::Value& r);
			int getLoseExploit(int army_id);

			void tryUpHp(int army_id);

			int getExploit() const { return _exploit; } 
			int getTotalExploit() const { return _total_exploit; }
			int historyExploit();
			int alterExploit(int num);
			void clearExploit();
			void alterDailyExploit(int num);
			void sendExploitBox2();

			int alterArmyHp(int army_id, int num);
			void fillArmyHp(int army_id);
			int armyHp(int army_id, unsigned cur_time = 0, bool recal = false);
			bool armyHpFilled(int army_id);
			void resetArmyHp(int army_id, unsigned cur_time);

			void attach(int id);
			void detach(int id);

			unsigned winTimes() const { return _win_times; }
			unsigned battleTimes() const { return _battle_times; }
			unsigned siegeTimes() const { return _siege_times; }
			void clearWinStreak(int army_id);
			int winStreak(int army_id) const { return _win_streak[army_id]; } 
			unsigned useHpItemTimes() const { return _use_hp_item_times; }
			void dailyTick();

			bool onMain() const { return _attach_main; }
			void setUpHpState(int army_id, int s) { _up_hp_state[army_id] = s; }
			int getUpHpState(int army_id) const { return _up_hp_state[army_id]; }
			int repRP() const { return _red_point? 1 : 0; }

			static int ExploitReason;
		private:
			void sendExploitBox();

		private:
			STDMAP(int, int, Man2HpMap);
			Man2HpMap _man_hp;

			KingdomWar::ReportMgr _rep_mgr;
			unsigned _report_id;
			bool _red_point;
			unsigned _siege_times;
			unsigned _use_hp_item_times;

			int _exploit;
			int _total_exploit;
			int _history_exploit;
			unsigned _record_time;
			unsigned _clear_time;
			unsigned _battle_times;
			std::vector<unsigned> _win_streak;

			int _daily_exploit;
			int _daily_box;

			int _attach_city;
			bool _attach_main;

			STDVECTOR(int, ArmyHp);
			ArmyHp _army_hp;
			ArmyHp _army_hp_base;
			
			ArmyHp _up_hp_state; // 1 use food 2 use hp item

			unsigned _win_times;
	};
}

#include "man_battle_rank.h"
#include "man_system.h"

namespace gg
{
	ManBattleRank* const ManBattleRank::_Instance = new ManBattleRank();

	using namespace NSManRank;
	ptrRankData ManBattleRank::getData(const int playerID, const int fatherID)
	{
		PlayerMap::const_iterator it = Player.find(FindKey(playerID, fatherID));
		if (it == Player.end())return ptrRankData();
		return it->second;
	}

	void ManBattleRank::initData()
	{
		if (isInitial)return;
		cout << "initial man battle rank list ..." << endl;
		Rank.clear();
		Player.clear();
		mongo::Query find_query(BSON("cbv" << BSON("$gt" << 0)));
		find_query.sort(BSON("cbv" << -1 << "lv" << -1 << "q" << -1 << "mid" << 1 << strPlayerID << 1));
		objCollection objs = db_mgr.Query(DBN::dbPlayerArmy, find_query, 200);
		std::set<int> same_member;
		for (unsigned i = 0; i < objs.size(); ++i)
		{
			mongo::BSONObj& obj = objs[i];
			const int playerID = obj[strPlayerID].Int();
			if (same_member.insert(playerID).second)
			{
				playerDataPtr now_player = player_mgr.getPlayer(playerID);
				if (!now_player)break;
				now_player->Man();
			}
		}
		cout << "man battle rank size:" << Rank.size() << "\t" << Player.size() << endl;
		isInitial = true;
	}

	void ManBattleRank::ManDetail(net::Msg& m, Json::Value& r)
	{
		playerDataPtr player = player_mgr.getPlayer(m.playerID);
		if (!player)Return(r, err_illedge);//�Ƿ�����
		ReadJsonArray;
		const int id = js_msg[0u].asInt();
		const int mid = js_msg[1u].asInt();
		cfgManPtr config = man_sys.getConfig(mid);
		if (!config)Return(r, err_illedge);
		ptrRankData ptr = getData(id, config->fatherID);
		qValue json(qJson::qj_array);
		if (ptr)
		{
			json.
				append(res_sucess).
				append(ptr->manID).
				append(ptr->manLV).
				append(ptr->battleValue).
				append(ptr->toAttriJson())
				;
			player->sendToClientFillMsg(gate_client::player_man_rank_detail_resp, json);
			return;
		}
		Return(r, err_illedge);
	}

	void ManBattleRank::RankList(net::Msg& m, Json::Value& r)
	{
		playerDataPtr player = player_mgr.getPlayer(m.playerID);
		if (!player)Return(r, err_illedge);//�Ƿ�����
		qValue json(qJson::qj_array);
		ptrRankData ownData;
		int rankNo = -1;
		int rankNow = 0;
		for (NSManRank::RankMap::const_iterator it = Rank.begin(); it != Rank.end(); ++it)
		{
			ptrRankData ptr = it->second;
			json.append(
				qValue(qJson::qj_array).
				append(ptr->playerID).
				append(ptr->playerName).
				append(ptr->manID).
				append(ptr->manLV).
				append(ptr->battleValue)
			);
			++rankNow;
			if (!ownData && ptr->playerID == player->ID())
			{
				ownData = ptr;
				rankNo = rankNow;
			}
			if (100 == rankNow)
			{
				break;
			}
		}
		player->sendToClientFillMsg(gate_client::player_man_battle_rank_resp,
			qValue(qJson::qj_array).
			append(res_sucess).
			append(json).
			append(rankNo).
			append(-1).
			append(0)
		);
	}

	void ManBattleRank::updateInfo(playerDataPtr player)
	{
		for (NSManRank::RankMap::const_iterator it = Rank.begin(); it != Rank.end(); ++it)
		{
			ptrRankData ptr = it->second;
			if (ptr->playerID == player->ID())
			{
				ptr->playerName = player->Name();
			}
		}
	}

	void ManBattleRank::updatePlayer(playerDataPtr player, playerManPtr man)
	{
		updatePlayer(player, *man);
	}

	void ManBattleRank::updatePlayer(playerDataPtr player, playerMan& man)
	{
		ptrRankData ptr = getData(player->ID(), man.uniqueID());
		if (ptr)
		{
			Rankey old_key = ptr->Key();
			Rank.erase(old_key);
			ptr->setNewData(player, man);
			Rankey new_key = ptr->Key();
			Rank[new_key] = ptr;
		}
		else
		{
			ptr = Creator<RankData>::Create(player, man);
			if (ptr->isNull())return;
			Rankey new_key = ptr->Key();
			Rank[new_key] = ptr;
			Player[FindKey(ptr->playerID, man.uniqueID())] = ptr;
			if(Rank.size() > 200)
			{//remove
				ptrRankData remove_ptr = Rank.rbegin()->second;
				Rank.erase(remove_ptr->Key());
				Player.erase(FindKey(remove_ptr->playerID, remove_ptr->uniqueID()));
			};
		}
	}

}

#include "shop_mgr.h"
#include "playerManager.h"

namespace gg
{
	namespace SHOP
	{
		Data::Data(const Json::Value& info)
		{
			_id = info["id"].asInt();
			_type_price = info["ctype"].asInt();
			_price_num = info["price"].asInt();
			_buy_num = info["buynum"].asInt();
			_nation = info["nation"].asInt();
			_nation = (_nation < 0 || _nation >= Kingdom::nation_num) ? Kingdom::nation_invaild_idx : _nation;
			_base_weight = info["weight"].asInt();
			_add_weight = info["wmodule"].asInt();
			_max_weight = info["mweight"].asInt();
			_type = info["index"].asUInt();
			_need_man = info["man"].asInt();
			Json::Value box = info["box"];
			_box = actionFormatBox(box);
		}

		Manager::Manager(const int type):Type(type)
		{
			_shop_random.resize(Kingdom::nation_total);
			initFile();
		}

		void Manager::initFile()
		{
			Json::Value info = Common::loadJsonFile("./instance/convert_shops/shop_" + Common::toString(Type) + ".json");
			_flush_limit = info["flush"].asInt();//-1 �������޴�
			_flush_costs.clear();
			for (unsigned i = 0; i < info["cost"].size(); ++i)
			{
				_flush_costs.push_back(info["cost"][i].asInt());
			}
			_allot.clear();
			for (unsigned i = 0; i < info["allot"].size(); ++i)
			{
				_allot.push_back(info["allot"][i].asUInt());
			}
			const unsigned allot_size = _allot.size();
			for (unsigned i = 0; i < _shop_random.size(); ++i)
			{
				_shop_random[i].resize(allot_size);
			}
			for (unsigned i = 0; i < info["goods"].size(); ++i)
			{
				ptrData ptr = Creator<Data>::Create(info["goods"][i]);
				if (ptr->_type >= allot_size)continue;
				_shop_map[ptr->_id] = ptr;
				if (ptr->_nation >= 0 && ptr->_nation < Kingdom::nation_num)
				{
					_shop_random[ptr->_nation][ptr->_type].push_back(ptr);
				}
				else
				{
					for (unsigned i = 0; i <= Kingdom::nation_num; ++i)
						_shop_random[i][ptr->_type].push_back(ptr);
				}
			}
		}

		bool Manager::flushLimit(unsigned times)
		{
			return times >= _flush_limit;//����
		}

		int Manager::getFlushCost(unsigned times)
		{
			if (times >= _flush_costs.size())
				times = _flush_costs.size() - 1;
			return _flush_costs[times];
		}

		ptrData Manager::getShopData(const int id)
		{
			MapData::iterator it = _shop_map.find(id);
			return it != _shop_map.end() ? it->second : ptrData();
		}

		vector<ptrData> Manager::getShopList(playerDataPtr player)
		{
			vector<ptrData> shop_list;
			const int nation = player->Info().NationIDX();
			const vector< vector<ptrData> >& nation_list = _shop_random[nation];
			for (unsigned type = 0; type < nation_list.size(); ++type)
			{
				const vector<ptrData>& rd_vec = nation_list[type];
				int total_weight = 0;
				MapData tmp_map;
				for (unsigned i = 0; i < rd_vec.size(); ++i)
				{
					ptrData ptr = rd_vec[i];
					if (ptr->_need_man > 0 && !player->Man().findArmy(ptr->_need_man))continue;
					ptr->_tmp_weight = ptr->_base_weight + player->LV() * ptr->_add_weight;
					if (ptr->_tmp_weight > ptr->_max_weight)
						ptr->_tmp_weight = ptr->_max_weight;
					if (ptr->_tmp_weight > 0)
					{
						total_weight += ptr->_tmp_weight;
						tmp_map[total_weight] = ptr;
					}
				}
				for (unsigned i = 0; i < _allot[type]; ++i)
				{
					if (total_weight < 1)break;
					int rd_num = Common::randomBetween(0, total_weight - 1);
					std::pair<MapData::iterator, bool> ret = tmp_map.insert(make_pair(rd_num, ptrData()));
					MapData::iterator it = ret.first;
					if (ret.second)
						tmp_map.erase(it++);
					else
						++it;
					total_weight -= it->second->_tmp_weight;
					shop_list.push_back(it->second);
					tmp_map.erase(it);
				}
			}
			return shop_list;
		}
	}

	WorldShop* const WorldShop::_Instance = new WorldShop();

	//���ݴ���
	Resource WorldShop::ResolveObjectJson(Json::Value& json)
	{
		Resource res;
		res.Base.typeID = json["type"].asInt();
		if (res.Base.typeID == ACTION::item)
		{
			res.Item.itemID = json["id"].asInt();
			res.Item.itemNum = json["num"].asUInt();
		}
		else
		{
			res.Res.resNum = json["num"].asInt();
		}
		return res;
	}
	Resource WorldShop::ResolveArrayJson(Json::Value& json)
	{
		Resource res;
		res.Base.typeID = json[0u].asInt();
		if (res.Base.typeID == ACTION::item)
		{
			res.Item.itemID = json[1u].asInt();
			res.Item.itemNum = json[2u].asUInt();
		}
		else
		{
			res.Res.resNum = json[1u].asInt();
		}
		return res;
	}

	Resource WorldShop::PackageData(const int type, const int num)
	{
		Resource data;
		data.Base.typeID = type;
		data.Res.resNum = num;
		return data;
	}
	Resource WorldShop::PackageData(const int type, const int itemID, const int num)
	{
		Resource data;
		data.Base.typeID = type;
		data.Item.itemID = itemID;
		data.Item.itemNum = num;
		return data;
	}

	//��Դ���
	typedef boost::function<int(playerDataPtr, const Resource&)> CheckFunc;
	UNORDERMAP(int, CheckFunc, ResCheckMap);
	static ResCheckMap CheckList;
	//��Դ����
	typedef boost::function<void(playerDataPtr, const Resource&)> DealFunc;
	UNORDERMAP(int, DealFunc, ResDealMap);
	static ResDealMap DealList;

	//��⺯��
#define CheckRegister(FUNC, CALL, CODE)\
	static int FUNC(playerDataPtr player, const Resource& data)\
	{\
		if(player->Res().CALL() < data.Res.resNum)return CODE;\
		return res_sucess;\
	}

	CheckRegister(check_silver, getSilver, err_silver_not_enough);
	CheckRegister(check_ticket, getTicket, err_ticket_not_enough);
	CheckRegister(check_gold, getGold, err_gold_not_enough);
	CheckRegister(check_cash, getCash, err_cash_not_enough);
	CheckRegister(check_food, getFood, err_food_not_enough);
	CheckRegister(check_wood, getWood, err_wood_not_enough);
	CheckRegister(check_iron, getIron, err_iron_not_enough);
	CheckRegister(check_merit, getMerit, err_merit_not_enough);
	CheckRegister(check_fame, getFame, err_fame_not_enough);
	static int check_item(playerDataPtr player, const Resource& data)
	{
		if (player->Items().overItem(data.Item.itemID, data.Item.itemNum))return res_sucess;
		return err_item_not_enough;
	}
	CheckRegister(check_contribute, getContribution, err_kingdom_con_not_enough);
	CheckRegister(check_hero_coin, getHeroCoin, err_heroparty_money_not_enough);
	CheckRegister(check_lady_coin, getLadyCoin, err_lady_coin_not_enough);
	static int check_point(playerDataPtr player, const Resource& data)
	{
		return res_sucess;
	}
	CheckRegister(check_search_point, getSearchPoints, err_search_point_not_enough);
	CheckRegister(check_exploit_coin, getExploit, err_exploit_coin_not_enough);
	CheckRegister(check_recharge_coin, getRechargeCoin, err_recharge_coin_not_enough);
	CheckRegister(check_expedition_coin, getExpeditionCoin, err_expedition_coin_not_enough);
	CheckRegister(check_reputation, getReputation, err_reputation_not_enough);
	CheckRegister(check_inter_point, getInterPoint, err_inter_point_not_enough);

#define DealRegister(FUNC, CALL)\
	static void FUNC(playerDataPtr player, const Resource& data)\
	{\
		player->Res().CALL(-data.Res.resNum);\
	}

	DealRegister(deal_silver, alterSilver);
	DealRegister(deal_ticket, alterTicket);
	DealRegister(deal_gold, alterGold);
	DealRegister(deal_cash, alterCash);
	DealRegister(deal_food, alterFood);
	DealRegister(deal_wood, alterWood);
	DealRegister(deal_iron, alterIron);
	DealRegister(deal_merit, alterMerit);
	DealRegister(deal_fame, alterFame);
	static void deal_item(playerDataPtr player, const Resource& data)
	{
		player->Items().removeItem(data.Item.itemID, data.Item.itemNum);
	}
	DealRegister(deal_contribute, alterContribution);
	DealRegister(deal_hero_coin, alterHeroCoin);
	DealRegister(deal_lady_coin, alterLadyCoin);
	static void deal_point(playerDataPtr player, const Resource& data)
	{
	}
	DealRegister(deal_search_point, alterSearchPoints);
	DealRegister(deal_exploit_coin, alterExploit);
	DealRegister(deal_recharge_coin, alterRechargeCoin);
	DealRegister(deal_expedition_coin, alterExpeditionCoin);
	DealRegister(deal_reputation, alterReputation);
	DealRegister(deal_inter_point, alterInterPoint);

	void WorldShop::initData()
	{
		cout << "loading shops config ..." << endl;
		ManagerShops.clear();
		for (unsigned i = 0; i < PLAYERSHOP::shop_num; ++i)
		{
			ManagerShops.push_back(Creator<SHOP::Manager>::Create(i));
		}

		//regist
		CheckList[ACTION::silver] = boostBind(check_silver, _1, _2);
		CheckList[ACTION::ticket] = boostBind(check_ticket, _1, _2);
		CheckList[ACTION::gold] = boostBind(check_gold, _1, _2);
		CheckList[ACTION::cash] = boostBind(check_cash, _1, _2);
		CheckList[ACTION::food] = boostBind(check_food, _1, _2);
		CheckList[ACTION::wood] = boostBind(check_wood, _1, _2);
		CheckList[ACTION::iron] = boostBind(check_iron, _1, _2);
		CheckList[ACTION::merit] = boostBind(check_merit, _1, _2);
		CheckList[ACTION::fame] = boostBind(check_fame, _1, _2);
		CheckList[ACTION::item] = boostBind(check_item, _1, _2);
		CheckList[ACTION::contribution] = boostBind(check_contribute, _1, _2);
		CheckList[ACTION::heroes_coin] = boostBind(check_hero_coin, _1, _2);
		CheckList[ACTION::lady_coin] = boostBind(check_lady_coin, _1, _2);
		CheckList[ACTION::points] = boostBind(check_point, _1, _2);
		CheckList[ACTION::search_points] = boostBind(check_search_point, _1, _2);
		CheckList[ACTION::exploit_coin] = boostBind(check_exploit_coin, _1, _2);
		CheckList[ACTION::recharge_coin] = boostBind(check_recharge_coin, _1, _2);
		CheckList[ACTION::expedition_coin] = boostBind(check_expedition_coin, _1, _2);
		CheckList[ACTION::reputation] = boostBind(check_reputation, _1, _2);
		CheckList[ACTION::inter_point] = boostBind(check_inter_point, _1, _2);

		//��������
		DealList[ACTION::silver] = boostBind(deal_silver, _1, _2);
		DealList[ACTION::ticket] = boostBind(deal_ticket, _1, _2);
		DealList[ACTION::gold] = boostBind(deal_gold, _1, _2);
		DealList[ACTION::cash] = boostBind(deal_cash, _1, _2);
		DealList[ACTION::food] = boostBind(deal_food, _1, _2);
		DealList[ACTION::wood] = boostBind(deal_wood, _1, _2);
		DealList[ACTION::iron] = boostBind(deal_iron, _1, _2);
		DealList[ACTION::merit] = boostBind(deal_merit, _1, _2);
		DealList[ACTION::fame] = boostBind(deal_fame, _1, _2);
		DealList[ACTION::item] = boostBind(deal_item, _1, _2);
		DealList[ACTION::contribution] = boostBind(deal_contribute, _1, _2);
		DealList[ACTION::heroes_coin] = boostBind(deal_hero_coin, _1, _2);
		DealList[ACTION::lady_coin] = boostBind(deal_lady_coin, _1, _2);
		DealList[ACTION::points] = boostBind(deal_point, _1, _2);
		DealList[ACTION::search_points] = boostBind(deal_search_point, _1, _2);
		DealList[ACTION::exploit_coin] = boostBind(deal_exploit_coin, _1, _2);
		DealList[ACTION::recharge_coin] = boostBind(deal_recharge_coin, _1, _2);
		DealList[ACTION::expedition_coin] = boostBind(deal_expedition_coin, _1, _2);
		DealList[ACTION::reputation] = boostBind(deal_reputation, _1, _2);
		DealList[ACTION::inter_point] = boostBind(deal_inter_point, _1, _2);
	}

	SHOP::ptrData WorldShop::getShopData(const int type, const int id)
	{
		if (type < 0 || type >= PLAYERSHOP::shop_num)return SHOP::ptrData();
		return ManagerShops[type]->getShopData(id);
	}

	vector<SHOP::ptrData> WorldShop::getShopList(const int type, playerDataPtr player)
	{
		if (type < 0 || type >= PLAYERSHOP::shop_num)return vector<SHOP::ptrData>();
		return ManagerShops[type]->getShopList(player);
	}

	bool WorldShop::flushLimit(const int type, unsigned times)
	{
		if (type < 0 || type >= PLAYERSHOP::shop_num)return true;
		return ManagerShops[type]->flushLimit(times);
	}

	int WorldShop::getFlushCost(const int type, unsigned times)
	{
		if (type < 0 || type >= PLAYERSHOP::shop_num)return 0;
		return ManagerShops[type]->getFlushCost(times);
	}

	int WorldShop::checkRes(const int type, const int num, playerDataPtr player)
	{
		ResCheckMap::iterator it = CheckList.find(type);
		if(it == CheckList.end())return res_sucess;
		return it->second(player, PackageData(type, num));
	}

	int WorldShop::checkItem(const int type, const int itemID, const int num, playerDataPtr player)
	{
		ResCheckMap::iterator it = CheckList.find(type);
		if (it == CheckList.end())return res_sucess;
		return it->second(player, PackageData(type, itemID, num));
	}

	void WorldShop::cutRes(const int type, const int num, playerDataPtr player)
	{
		ResDealMap::iterator it = DealList.find(type);
		if (it == DealList.end())return;
		it->second(player, PackageData(type, num));
	}

	void WorldShop::cutItem(const int type, const int itemID, const int num, playerDataPtr player)
	{
		ResDealMap::iterator it = DealList.find(type);
		if (it == DealList.end())return;
		it->second(player, PackageData(type, itemID, num));
	}

	int WorldShop::checkCommon(const Resource& data, playerDataPtr player)
	{
		ResCheckMap::iterator it = CheckList.find(data.Base.typeID);
		if (it == CheckList.end())return res_sucess;
		return it->second(player, data);
	}

	void WorldShop::cutCommon(const Resource& data, playerDataPtr player)
	{
		ResDealMap::iterator it = DealList.find(data.Base.typeID);
		if (it == DealList.end())return;
		it->second(player, data);
	}

	void WorldShop::shopInfo(net::Msg& m, Json::Value& r)
	{
		playerDataPtr player = player_mgr.getPlayer(m.playerID);
		if (!player) Return(r, err_illedge);
		ReadJsonArray;
		const int type = js_msg[0u].asInt();
		player->Shops().update(type);
	}

	void WorldShop::buy(net::Msg& m, Json::Value& r)
	{
		playerDataPtr player = player_mgr.getPlayer(m.playerID);
		if (!player) Return(r, err_illedge);
		ReadJsonArray;
		const int type = js_msg[0u].asInt();
		const int pos = js_msg[1u].asInt();
		const int id = js_msg[2u].asInt();
		const int res = player->Shops().buy(type, pos, id, r[strMsg][1u] = Json::arrayValue);
		Return(r, res);
	}

	void WorldShop::flush(net::Msg& m, Json::Value& r)
	{
		playerDataPtr player = player_mgr.getPlayer(m.playerID);
		if (!player) Return(r, err_illedge);
		ReadJsonArray;
		const int type = js_msg[0u].asInt();
		const int res = player->Shops().flush(type);
		Return(r, res);
	}
}

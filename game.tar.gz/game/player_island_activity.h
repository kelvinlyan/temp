#pragma once

#include "auto_base.h"
#include "action_system.h"

namespace gg
{
	class playerIslandActivity
		: public _auto_player
	{
		public:
			playerIslandActivity(playerData* const own);

			void sendBase();
			void sendRecord();

			int turnTable(int type, int times_type, Json::Value& r);
			int openBox(Json::Value& r);

			ActionBoxList getTreasurePieceByAction(int num);
			ActionBoxList getTreasurePieceByGold(int num);

			void dailyTick();
			void setData(mongo::BSONObj& obj);
			void update();

		private:
			virtual bool _auto_save();


		private:
			int _key_id;
			int _treasure_pieces_limit_by_action;
			int _treasure_pieces_limit_by_gold;
			std::list<std::string> _record_list;
	};
}

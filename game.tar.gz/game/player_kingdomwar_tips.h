#pragma once

#include "auto_base.h"

namespace gg
{
	namespace KingdomWar
	{
		enum
		{
			TIPS_BEGIN = 0,
			REP_RP = TIPS_BEGIN,
			REWARD_RP,
			STATE_TIPS,
			SUP_RATE,
			NATION_TASK_RP,
			PERSON_TASK_RP,
			GREAT_EVENT_RP,
			TIPS_MAX
		};
	}

	class playerKingdomWarTips
		: public _auto_player
	{
		public:
			playerKingdomWarTips(playerData* const own);
			void add(int type)
			{
				if (_client_tips.none())
					_sign_update();
				_client_tips.set(type);
			}
			void updateAll();
		private:	
			virtual void _auto_update();
			void getInfo(int type, qValue& q);
		private:
			std::bitset<KingdomWar::TIPS_MAX> _client_tips;
	};
}

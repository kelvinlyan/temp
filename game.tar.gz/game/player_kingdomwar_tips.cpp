#include "player_kingdomwar_tips.h"
#include "playerManager.h"
#include "kingdomwar_system.h"

using namespace KingdomWar;

namespace gg
{
	playerKingdomWarTips::playerKingdomWarTips(playerData* const own)
		: _auto_player(own)
	{}

	void playerKingdomWarTips::updateAll()
	{
		if (Own().Info().Nation() == Kingdom::null)
			return;
		Own().KingDomWarTask().resetRedPoint();
		_client_tips.set();
		_auto_update();
	}

	void playerKingdomWarTips::_auto_update()
	{
		if (Own().Info().Nation() == Kingdom::null)
			return;
		qValue m;
		m.append(res_sucess);
		qValue q;
		for (unsigned i = TIPS_BEGIN; i < TIPS_MAX; ++i)
		{
			if (_client_tips.test(i))
			{
				qValue tmp;
				getInfo(i, tmp);
				q.append(tmp);
			}
		}
		m.append(q);
		Own().sendToClientFillMsg(gate_client::kingdom_war_red_point_resp, m);
		_client_tips.reset();
	}

	void playerKingdomWarTips::getInfo(int type, qValue& q)
	{
		switch(type)
		{
			case REP_RP:
				q << type << Own().KingDomWar().repRP(); break;
			case REWARD_RP:
				q << type << Own().KingDomWarBox().rpState(); break;
			case STATE_TIPS:
				q << type << (int)KingdomWar::State::shared().get(); break;
			case SUP_RATE:
				q << type << kingdomwar_sys.supRate(); break;
			case NATION_TASK_RP:
				q << type << Own().KingDomWarTask().nationTaskRP(); break;
			case PERSON_TASK_RP:
				q << type << Own().KingDomWarTask().personTaskRP(); break;
			case GREAT_EVENT_RP:
				q << type << Own().KingDomWarBox().greatEventRP(); break;
			default:
				break;
		}
	}
}

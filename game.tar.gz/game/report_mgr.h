#pragma once

#include "commom.h"
#include "mongoDB.h"

namespace gg
{
	template<typename T>
	class ReportMgr
	{
		public:
			BOOSTSHAREPTR(T, ReportPtr);
			STDLIST(ReportPtr, ReportList);

			typedef boost::function<void(const ReportPtr&)> Handler;

			ReportMgr(int max);

			void load(const mongo::BSONElement& obj);
			mongo::BSONArray toBSON() const;

			void getInfo(Json::Value& info) const;
			void push(const ReportPtr& r);
			void clear();
			void run(Handler h);

		private:
			ReportList _rep_list;
			unsigned _max_size;
	};

	template<typename T>
	ReportMgr<T>::ReportMgr(int max)
		: _max_size(max)
	{
	}

	template<typename T>
	void ReportMgr<T>::load(const mongo::BSONElement& obj)
	{
		std::vector<mongo::BSONElement> ele = obj.Array();
		for (unsigned i = 0; i < ele.size(); ++i)
			_rep_list.push_back(Creator<T>::Create(ele[i]));
		while(_rep_list.size() > _max_size)
			_rep_list.pop_back();
	}

	template<typename T>
	mongo::BSONArray ReportMgr<T>::toBSON() const
	{
		mongo::BSONArrayBuilder b;
		ForEachC(typename ReportMgr<T>::ReportList, it, _rep_list)
			b.append((*it)->toBSON());
		return b.arr();
	}

	template<typename T>
	void ReportMgr<T>::getInfo(Json::Value& info) const
	{
		info = Json::arrayValue;
		ForEachC(typename ReportMgr<T>::ReportList, it, _rep_list)
		{
			Json::Value tmp;
			(*it)->getInfo(tmp);
			info.append(tmp);
		}
	}

	template<typename T>
	void ReportMgr<T>::push(const ReportPtr& r)
	{
		_rep_list.push_front(r);
		while (_rep_list.size() > _max_size)
			_rep_list.pop_back();
	}

	template<typename T>
	void ReportMgr<T>::clear()
	{
		_rep_list.clear();
	}

	template<typename T>
	void ReportMgr<T>::run(Handler h)
	{
		ForEachC(typename ReportMgr<T>::ReportList, it, _rep_list)
			h(*it);
	}
}

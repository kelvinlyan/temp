#include "mystery_area_system.h"
#include "chat.h"

namespace gg
{

	const static std::string strSTime = "st";
	const static std::string strETime = "et";
	const static std::string strConfigId = "cid";
	const static std::string strResetDiscount = "rd";
	const static std::string strExploreDiscount = "ed";
	const static std::string strTimeStamp = "ts";
	const static std::string strActiId = "id";
	const static std::string strTimes = "t";
	const static std::string strBoxes = "box";

#define KEY_TIMES 3

	MysteryAreaSystem* const MysteryAreaSystem::_Instance = new MysteryAreaSystem();
	mystery::MysteryConfig MysteryAreaSystem::_config;
	mystery::ActiUTMap MysteryAreaSystem::_users_top_records;
	int MysteryAreaSystem::_add_foc_reset_time = 0;
	std::map<int, mystery::PlayerJsonList> MysteryAreaSystem::_users_top_rewards;
	mystery::MysteryConfigList MysteryAreaSystem::_configList;
	mystery::MysteryConfigList MysteryAreaSystem::_preConfigList;
	std::map<int, ptrTimerIdentify> MysteryAreaSystem::_etimer;
	std::map<int, ptrTimerIdentify> MysteryAreaSystem::_stimer;

	MysteryAreaSystem::MysteryAreaSystem()
	{
		initConfig();
	}

	void MysteryAreaSystem::reqGMMysteryAreaIdList(net::Msg& m, Json::Value& r)
	{
		Json::Value ret_json = Json::arrayValue;
		unsigned idx = 0u;
		ret_json[idx++] = _config.actiId;
		mystery::MysteryConfigList::iterator it = _preConfigList.begin();
		for (; it != _preConfigList.end(); ++it)
		{
			if (it->second.actiId != _config.actiId)
			{
				ret_json[idx++] = it->second.actiId;
			}
		}
		r[strMsg] = ret_json;
	}

	void MysteryAreaSystem::reqGMMysteryAreaConfigInfo(net::Msg& m, Json::Value& r)
	{
		Json::Value ret_json = Json::arrayValue;
		unsigned idx = 0u;
		for (mystery::MysteryConfigList::iterator it = _configList.begin(); 
			it != _configList.end();
			++it)
		{
			Json::Value ret = Json::arrayValue;
			ret[0u] = it->second.configId;
			ret[1u] = it->second.configName;
			ret_json[idx++] = ret;
		}
		r[strMsg] = ret_json;
	}

	void MysteryAreaSystem::reqGMMysteryAreaInfo(net::Msg& m, Json::Value& r)
	{
		ReadJsonArray;

		int acti_id = js_msg[0u].asInt();
		mystery::MysteryConfigList::iterator it = _preConfigList.find(acti_id);
		if (it == _preConfigList.end())
		{
			Return(r, err_mystery_area_acti_not_fund);//�����ڸû��
		}
		Json::Value ret_json = Json::arrayValue;
		ret_json[0u] = it->second.actiId;
		ret_json[1u] = it->second.configId;
		//ret_json[3u] = it->second.configName;
		ret_json[2u] = it->second.stime == 0 ? 0 : Common::toStampTime(it->second.stime);
		ret_json[3u] = it->second.etime == 0 ? 0 : Common::toStampTime(it->second.etime);
		ret_json[4u] = it->second.resetDiscount;
		ret_json[5u] = it->second.exploreDiscount;

		r[strMsg] = ret_json;
	}

	void MysteryAreaSystem::reqGMMysteryAreaModify(net::Msg& m, Json::Value& r)
	{
		ReadJsonArray;

		int action = js_msg[0u].asInt();
		int acti_id = js_msg[1u].asInt();
		
		mystery::MysteryConfigList::iterator it = _preConfigList.find(acti_id);
		if (it == _configList.end())
		{
			Return(r, err_mystery_area_acti_format_wrong);//����������ʽ����
		}

		if (action == 2)
		{
			int config_id = js_msg[2u].asUInt();
			unsigned stime = js_msg[3u].asUInt();
			unsigned etime = js_msg[4u].asUInt();
			int reset_discount = js_msg[5u].asInt();
			int explore_discount = js_msg[6u].asInt();
			if (reset_discount < 1 || reset_discount > 100
				|| explore_discount < 1 || explore_discount > 100)
			{
				Return(r, err_mystery_area_acti_format_wrong);//�ۿۣ���������ʽ����
			}
			mystery::MysteryConfig config;
			config.configId = config_id;
			config.stime = stime == 0 ? 0 : Common::toLocalTime(stime);
			config.etime = etime == 0 ? 0 : Common::toLocalTime(etime);
			config.resetDiscount = reset_discount;
			config.exploreDiscount = explore_discount;
			config.actiId = acti_id;
			_preConfigList[config.actiId] = config;

			bool flag = saveActi(config);
			if (!flag)
			{
				_preConfigList.erase(config.actiId);
				Return(r, 1);
			}
			_config.actiId = -1;//����������ѡ��
			//����ҷ��ͻ��������-----------------
			_stimer[acti_id] = Timer::AddEventTickTime(boostBind(MysteryAreaSystem::ActivityBegin, _1), Inter::event_activity_begin, config.stime);
			_etimer[acti_id] = Timer::AddEventTickTime(boostBind(MysteryAreaSystem::ActivityOver, _1), Inter::event_activity_over, config.etime);
		}
		else if (action == 1)
		{
			//��������ҷ��ͻ�ر�����----------------
			delActi(acti_id);
			_preConfigList.erase(acti_id);
			if (_stimer.find(acti_id) != _stimer.end())
			{
				_stimer[acti_id]->delTimer();
			}
			if (_etimer.find(acti_id) != _etimer.end())
			{
				_etimer[acti_id]->delTimer();
			}
			//����رյ��ǵ�ǰ�
			if (acti_id == _config.actiId)
			{
				_config.actiId = -1;
				Json::Value json;
				json[strMsg][0u] = 0;
				json[strMsg][1u] = 2;
				player_mgr.sendToAll(gate_client::mystery_area_activity_over_resp, json);
			}
		}
		else
		{
			Return(r, err_mystery_area_acti_format_wrong);//����������ʽ����
		}
		selectActi();

		Return(r, 0);
	}

	void MysteryAreaSystem::reqMysteryAreaRedPoint(net::Msg& m, Json::Value& r)
	{
		playerDataPtr player = player_mgr.getPlayer(m.playerID);
		if (!player)Return(r, err_illedge);

		r[strMsg][0u] = 0;
		if (_config.actiId == -1)
		{
			selectActi();
		}
		if (_config.actiId == -1 || player->LV() < LV_LIMIT)
		{
			r[strMsg][1u] = 2;
		}
		else
		{
			r[strMsg][1u] = 0;
		}
	}

	//--safety-done--
	void MysteryAreaSystem::reqMysteryAreaInfo(net::Msg& m, Json::Value& r)
	{
		playerDataPtr player = player_mgr.getPlayer(m.playerID);
		if (!player)Return(r, err_illedge);

		if (player->LV() < LV_LIMIT)
		{
			Return(r, err_mystery_area_lv_not_enough);
		}
		unsigned now = Common::gameTime();
		if (_config.actiId == -1 || _config.stime > now || _config.etime < now)
		{
			Return(r, err_mystery_area_acti_empty);
		}
		//�Ƿ�ʼ��һ���µĻ
		int acti_id = player->MysteryArea().actiId();
		if (acti_id != _config.actiId)
		{
			player->MysteryArea().start(_config.actiId);
			resetPlayerArea(player);//�»�ĵ�һ�ο�����Ҫ���û��
			//init(false);
		}
		else if (!player->MysteryArea().isSet())
		{
			resetPlayerArea(player);//ÿ�������
		}

		Json::Value info = Json::arrayValue;
		getCommonInfo(player, info);

		//info[6u] = _config.stime == 0 ? 0 : Common::toStampTime(_config.stime);
		//info[7u] = _config.etime == 0 ? 0 : Common::toStampTime(_config.etime);
		//Json::Value c_info = Json::arrayValue;
		//player->MysteryArea().getCompleteInfo(c_info);//���
		//info[8u] = c_info;

		r[strMsg][0u] = 0;
		r[strMsg][1u] = info;
	}

	//--safety-done--
	void MysteryAreaSystem::reqMysteryAreaReset(net::Msg& m, Json::Value& r)
	{
		playerDataPtr player = player_mgr.getPlayer(m.playerID);
		if (!player)Return(r, err_illedge);

		if (player->LV() < LV_LIMIT)
		{
			Return(r, err_mystery_area_lv_not_enough);
		}
		unsigned now = Common::gameTime();
		if (_config.actiId == -1 || _config.stime > now || _config.etime < now)
		{
			Return(r, err_mystery_area_acti_empty);
		}
		if (!player->MysteryArea().isSet())
		{
			Return(r, err_mystery_area_reflesh_error);
		}
		int foc = player->MysteryArea().foc();
		//����ʹ��frt
		bool foc_flag = (foc > 0);//���������
		bool frt_flag = _add_foc_reset_time > player->MysteryArea().frtConsume();
		int reset_time = player->MysteryArea().resetTime();
		int reset_type = 3;
		Json::Value cost_unit = Json::arrayValue;
		if (foc_flag == false && frt_flag == false)
		{
			reset_type = 2;
			int cost_key = getResetKey(reset_time);//�������Ƿ�����һ����Ч�Ĺؼ�����
			mystery::IntSeqMap::iterator it = _config.reset.find(cost_key);
			if (it == _config.reset.end())
			{
				Return(r, err_mystery_area_unknown_error);//δ֪����
			}
			else
			{
				//��Դ��֤
				cost_unit[0u] = it->second[0];
				cost_unit[1u] = it->second[1];
				int retval = validateRes(player, it->second, _config.resetDiscount);
				if (retval != 0)
				{
					Return(r, err_mystery_area_resource_not_enough);
				}
			}
			consumeRes(player, it->second, _config.resetDiscount);//����
		}
		Json::Value json_cost = Json::arrayValue;
		json_cost.append(cost_unit);
		resetPlayerArea(player, reset_type, json_cost);//����
		if (frt_flag == true)
		{
			player->MysteryArea().addFrtConsume(1);
		}
		else if(foc_flag ==true)
		{
			player->MysteryArea().alterFoc(-1);
		}
		else
		{
			player->MysteryArea().addResetTime(1);
		}
		/*Json::Value info = Json::arrayValue;
		getCommonInfo(player, info);*/
		r[strMsg][0u] = 0;
		//������Ϣ
		Json::Value update_info = Json::arrayValue;
		getCommonInfo(player, update_info);
		//update_info[6u] = _config.stime == 0 ? 0 : Common::toStampTime(_config.stime);
		//update_info[7u] = _config.etime == 0 ? 0 : Common::toStampTime(_config.etime);
		//Json::Value c_info = Json::arrayValue;
		//player->MysteryArea().getCompleteInfo(c_info);//���
		//update_info[8u] = c_info;

		Json::Value update_r = Json::nullValue;
		update_r[strMsg][0u] = 0;
		update_r[strMsg][1u] = update_info;
		player_mgr.sendToPlayer(player->ID(), gate_client::mystery_area_info_resp, update_r);
	}

	//--safety-done--
	void MysteryAreaSystem::reqMysteryAreaExplore(net::Msg& m, Json::Value& r)
	{
		playerDataPtr player = player_mgr.getPlayer(m.playerID);
		if (!player)Return(r, err_illedge);

		if (player->LV() < LV_LIMIT)
		{
			Return(r, err_mystery_area_lv_not_enough);
		}
		unsigned now = Common::gameTime();
		if (_config.actiId == -1 || _config.stime > now || _config.etime < now)
		{
			Return(r, err_mystery_area_acti_empty);
		}
		if (!player->MysteryArea().isSet())
		{
			Return(r, err_mystery_area_reflesh_error);
		}
		ReadJsonArray;
		int area_id = js_msg[0u].asInt();
		if (_config.mIdsMap.find(area_id) == _config.mIdsMap.end())
		{
			Return(r, err_mystery_area_map_id_unknown);
		}
		if (player->MysteryArea().isExplored(area_id))
		{
			Return(r, err_mystery_area_explored);
		}
		///
		mystery::IntSeqMap::iterator it;
		int explore_time = player->MysteryArea().exploreTime();//�����explore_time�ǵ�N��̽��
		it = _config.explore.find(explore_time);
		if (it == _config.explore.end())
		{
			Return(r, err_mystery_area_unknown_error);//δ֪����
		}
		else
		{
			//��Դ��֤
			int retval = validateRes(player, it->second, _config.exploreDiscount);
			if (retval != 0)
			{
				Return(r, err_mystery_area_resource_not_enough);
			}
		}
		mystery::BoxSinglePtr box;
		int box_id;
		int level;
		int retval = player->MysteryArea().doExplore(area_id, box, box_id, level);
		int pid = player->ID();
		if (retval != 0)
		{
			Return(r, err_mystery_area_unknown_error);
		}
		handleLevel(level, player, box->jsonBox, area_id, _config.names[area_id]);
		int ret = actionDoBox(player, box->box, false);
		r[strMsg][0u] = ret;
		if (ret != 0)
		{
			r[strMsg][1u] = actionError();
		}
		else
		{
			r[strMsg][1u] = actionRes();
			consumeRes(player, it->second, _config.exploreDiscount);//������Դ
		}
		r[strMsg][2u] = box_id;
		player->MysteryArea().addExploreTime(1);
		player->MysteryArea().alterAllCost(-it->second[1]);//��ȥȫ�����Ľ��
		//��������һ��̽������ô�Զ������ؾ�
		//int times = player->MysteryArea().exploreTime();
		if (explore_time == TREASURE_NUM)
		{
			resetPlayerArea(player, 1);
		}
		Json::Value json_cost = Json::arrayValue;
		Json::Value cost_unit = Json::arrayValue;
		cost_unit[0u] = it->second[0];
		cost_unit[1u] = it->second[1]*_config.exploreDiscount/100;
		json_cost.append(cost_unit);
		Log(DBLOG::strLogMysteryArea, player, 2, json_cost.toIndentString(), box->strBox);

		//������Ϣ
		Json::Value update_info = Json::arrayValue;
		getCommonInfo(player, update_info);
		//update_info[6u] = _config.stime == 0 ? 0 : Common::toStampTime(_config.stime);
		//update_info[7u] = _config.etime == 0 ? 0 : Common::toStampTime(_config.etime);
		//Json::Value c_info = Json::arrayValue;
		//player->MysteryArea().getCompleteInfo(c_info);//���
		//update_info[8u] = c_info;

		Json::Value update_r = Json::nullValue;
		update_r[strMsg][0u] = 0;
		update_r[strMsg][1u] = update_info;
		player_mgr.sendToPlayer(player->ID(), gate_client::mystery_area_info_resp, update_r);
	}

	//--saft-done--
	void MysteryAreaSystem::reqMysteryAreaExploreAll(net::Msg& m, Json::Value& r)
	{
		playerDataPtr player = player_mgr.getPlayer(m.playerID);
		if (!player)Return(r, err_illedge);

		if (player->LV() < LV_LIMIT)
		{
			Return(r, err_mystery_area_lv_not_enough);
		}
		unsigned now = Common::gameTime();
		if (_config.configId == -1 || _config.stime > now || _config.etime < now)
		{
			Return(r, err_mystery_area_acti_empty);
		}
		if (!player->MysteryArea().isSet())
		{
			Return(r, err_mystery_area_reflesh_error);
		}
		int rest = _config.mIds.size() - player->MysteryArea().exploredAreaCount();
		int discount = _config.exploreDiscount;
		if (rest >= _config.restPiece)
		{
			discount = _config.restDiscount;
		}
		//��Դ��֤
		mystery::Sequence all_cost = player->MysteryArea().getAllCost();
		int retval = validateRes(player, all_cost, discount);
		if (retval != 0)
		{
			Return(r, err_mystery_area_resource_not_enough);
		}

		mystery::BoxList boxes;
		mystery::Sequence level, area_list;
		Json::Value ids_list = Json::arrayValue;
		retval = player->MysteryArea().doExploreAll(boxes, level, area_list);
		if (retval != 0)
		{
			Return(r, err_mystery_area_unknown_error);
		}
		int pid = player->ID();
		for (unsigned i = 0; i < level.size(); ++i)
		{
			handleLevel(level[i], player, boxes[i]->jsonBox, area_list[i], _config.names[area_list[i]]);
			ids_list[i] = area_list[i];
		}
		mystery::BoxSingle box;
		for (int i = 0; i < boxes.size(); ++i)
		{
			lx::utility_lx::combineJsonBox(boxes[i]->rawBox, box.rawBox);
		}
		box.load();///
		int ret = actionDoBox(player, box.box, false);
		r[strMsg][0u] = ret;
		if (ret != 0)
		{
			r[strMsg][1u] = actionError();
		}
		else
		{
			//r[strMsg][1u] = actionRes();
			Json::Value reward_desc = Json::arrayValue;
			for (int i = 0; i < boxes.size(); ++i)
			{
				Json::Value reward_single = Json::arrayValue;
				reward_single.append(boxes[i]->jsonBox);
				reward_single.append(level[i]);
				reward_desc.append(reward_single);
			}
			r[strMsg][1u] = reward_desc;
			consumeRes(player, all_cost, discount);//������Դ
		}
		r[strMsg][2u] = ids_list;
		//�Զ������ؾ�
		resetPlayerArea(player, 1);
		Json::Value json_cost = Json::arrayValue;
		Json::Value cost_unit = Json::arrayValue;
		cost_unit[0u] = all_cost[0];
		cost_unit[1u] = all_cost[1]*discount/100;
		json_cost.append(cost_unit);
		Log(DBLOG::strLogMysteryArea, player, 3, json_cost.toIndentString(), box.strBox);

		//������Ϣ
		Json::Value update_info = Json::arrayValue;
		getCommonInfo(player, update_info);
		//update_info[6u] = _config.stime == 0 ? 0 : Common::toStampTime(_config.stime);
		//update_info[7u] = _config.etime == 0 ? 0 : Common::toStampTime(_config.etime);
		//Json::Value c_info = Json::arrayValue;
		//player->MysteryArea().getCompleteInfo(c_info);//���
		//update_info[8u] = c_info;

		Json::Value update_r = Json::nullValue;
		update_r[strMsg][0u] = 0;
		update_r[strMsg][1u] = update_info;
		player_mgr.sendToPlayer(player->ID(), gate_client::mystery_area_info_resp, update_r);
	}

	//--saft-done--
	void MysteryAreaSystem::reqMysteryAreaTopRewardInfo(net::Msg& m, Json::Value& r)
	{
		playerDataPtr player = player_mgr.getPlayer(m.playerID);
		if (!player)Return(r, err_illedge);

		if (player->LV() < LV_LIMIT)
		{
			Return(r, err_mystery_area_lv_not_enough);
		}
		unsigned now = Common::gameTime();
		if (_config.actiId == -1 || _config.stime > now || _config.etime < now)
		{
			Return(r, err_mystery_area_acti_empty);
		}

		Json::Value my_reward = Json::arrayValue;
		Json::Value other_reward = Json::arrayValue;
		std::map<int, mystery::PlayerJsonList>::iterator pit = _users_top_rewards.find(_config.actiId);
		if (pit != _users_top_rewards.end())
		{//��ǰ���������Ӧ�Ľ�����¼
			mystery::PlayerJsonList::iterator it = pit->second.begin();
			for (;it != pit->second.end(); ++it)
			{
				//LogS << "REQ-mystery reward:pid=" << player->ID() << LogEnd;
				if (it->first == player->ID())
				{
					mystery::JsonList& list = it->second;
					for (int i = 0; i < list.size(); ++i)
					{
						Json::Value unit = Json::arrayValue;
						unit.append(list[i].jsonBox);
						unit.append(list[i].aid);
						my_reward.append(unit);
					}
				}
				else
				{
					mystery::JsonList& list = it->second;
					for (int i = 0; i < list.size(); ++i)
					{
						Json::Value unit = Json::arrayValue;
						unit.append(list[i].name);
						unit.append(list[i].jsonBox);
						unit.append(list[i].aid);
						other_reward.append(unit);
					}
				}
			}
		}
		else
		{
			//LogS << "REQ-mystery==>acti not exist acti_id=" << _config.actiId << LogEnd;
		}
		r[strMsg][0u] = 0;
		r[strMsg][1u] = my_reward;
		r[strMsg][2u] = other_reward;
		//LogS << "REQ-mystery==>my:" << my_reward.toIndentString() << "\tother:" << other_reward.toIndentString() << LogEnd;
	}

	//safety-done--
	void MysteryAreaSystem::reqMysteryAreaServerConfig(net::Msg& m, Json::Value& r)
	{
		playerDataPtr player = player_mgr.getPlayer(m.playerID);
		if (!player)Return(r, err_illedge);

		if (_config.actiId == -1)
		{
			selectActi();
		}

		r[strMsg][0u] = 0;
		r[strMsg][1u] = _config.configId;
	}

	//--done--
	void MysteryAreaSystem::getCommonInfo(playerDataPtr player, Json::Value& json)
	{
		Json::Value area_info = _fixedAreaInfo;
		for (int i = 0; i < area_info.size(); ++i)
		{
			bool flag = player->MysteryArea().isExplored(area_info[i][0u].asInt());
			area_info[i][1u] = flag ? 0 : 1;
		}
		json.append(area_info);
		Json::Value box_info = _fixedRewardBoxInfo;
		for (int i = 0; i < _fixedRewardBoxInfo.size(); ++i)
		{
			Json::Value desc = Json::nullValue;
			int flag, level;
			player->MysteryArea().getRewardBoxDesc(_fixedBoxId[i], desc, flag, level);
			box_info[i][1u] = desc;
			box_info[i][2u] = flag;
			box_info[i][3u] = level;
		}
		json.append(box_info);
		//Json::Value c_info = Json::arrayValue;
		//player->MysteryArea().getCompleteInfo(c_info);//���
		//json.append(c_info);
		int explore = player->MysteryArea().exploreTime();
		json.append(getExploreCost(explore));
		json.append(getResetCost(player));
		int rest = _config.mIds.size() - player->MysteryArea().exploredAreaCount();
		int discount = _config.exploreDiscount;
		if (rest >= _config.restPiece)
		{
			discount = _config.restDiscount;
		}
		Json::Value all_cost_json = getExploreAllCost(player->MysteryArea().getAllCost(), discount);
		LogS << "mystery==>all_cost=" << all_cost_json.toIndentString() << LogEnd;
		json.append(all_cost_json);
		LogS << "mystery==>getinfo:add foc=" << _add_foc_reset_time << "\tpid=" << player->MysteryArea().frtConsume() << "\tpid=" << player->ID() << LogEnd;
		int foc = _add_foc_reset_time - player->MysteryArea().frtConsume() >= 0 ? _add_foc_reset_time - player->MysteryArea().frtConsume() : 0;;
		json.append(foc);
		unsigned stime = _config.stime == 0 ? 0 : Common::toStampTime(_config.stime);
		json.append(stime);
		unsigned etime = _config.etime == 0 ? 0 : Common::toStampTime(_config.etime);
		json.append(etime);
		Json::Value c_info = Json::arrayValue;
		player->MysteryArea().getCompleteInfo(c_info);//���
		json.append(c_info);
		//LogS << "mystery==>pid=" << player->ID() << "\tadd_foc=" << _add_foc_reset_time << "\tp_add_foc=" << player->MysteryArea().frtConsume() << LogEnd;
		//LogS << "mystery:info==>" << json.toIndentString() << LogEnd;
	}

	//--done--
	mystery::TreasurePtr MysteryAreaSystem::generateTreasure(playerDataPtr player, int reset_times)
	{
		mystery::TreasurePtr treasure = Creator<mystery::Treasure>::Create();
		int rest = TREASURE_NUM;
		int box_id = 1;
		//LogS << "mystery:zero Pool" << LogEnd;
		mystery::ZeroPool::iterator it = _config.zeroPool.find(reset_times);
		for (;it != _config.zeroPool.end(); ++it)
		{
			//���ɱ���
			if (it->second.must != reset_times)
			{
				break;
			}
			generateReward(treasure,it->second, box_id);
			--rest;
			if (rest == 0)
			{
				break;
			}
			++box_id;
		}
		lx::OddsSequence odds = _config.pool.odds;
		//LogS << "mystery:must Pool" << LogEnd;
		///����Ȩ�أ����Ǳ�����
		std::multimap<int, int>::iterator dit = _config.pool.musts.find(reset_times);
		for (; dit != _config.pool.musts.end(); ++dit)
		{
			if (dit->first != reset_times)
			{
				break;
			}
			if (!player->MysteryArea().isGroupSet(_config.pool.groups[dit->second].id))
			{
				LogS << "mystery==>groups.size=" << _config.pool.groups.size() << "\tidx=" << dit->second << LogEnd;
				generateReward(treasure, _config.pool.groups[dit->second], box_id);
				//һЩ��������odds���±���Ϊ-2�����Ϊ�ƶ�
				odds[dit->second + 1].idx = -2;
				--rest;
				if (rest == 0)
				{
					break;
				}
				++box_id;
			}
		}
		//LogS << "mystery:normal Pool" << LogEnd;
		//���������������
		mystery::Sequence rest_pg = lx::utility_lx::randomWeightSequence(odds, rest);//�ӽ����и���Ȩ�س�ȡ����
		for (int i = 0; i < rest_pg.size(); ++i)
		{
			LogS << "mystery==>groups.size=" << _config.pool.groups.size() << "\tidx=" << rest_pg[i] << LogEnd;
			/*if (rest_pg[i] < 0 || rest_pg[i] >= _config.pool.groups.size())
			{
				rest_pg[i] = Common::randomBetween(0, _config.pool.groups.size() - 1);
			}*/
			generateReward(treasure, _config.pool.groups[rest_pg[i]], box_id);
			++box_id;
		}
		return treasure;
	}

	//--done--
	void MysteryAreaSystem::generateReward(mystery::TreasurePtr ptr, const mystery::PoolGroup& pg, int box_id)
	{
		//���ɱ���
		int aID, id, v, level, weight;
		mystery::BoxSinglePtr single = Creator<mystery::BoxSingle>::Create();
		//LogS << "mystery==>reset area:generateReward:box_id:" << box_id << LogEnd;
		getReward(pg, aID, id, v, level, weight);
		single->rawBox = lx::utility_lx::toRawBox(aID, v, id);
		//LogS << "mystery\t" << "level:" << level <<"\trawBox:" << rawBox.toIndentString() << LogEnd;
		//single->rawBox = rawBox;
		single->load();

		mystery::Area area;
		area.areaId = box_id;
		area.boxId = box_id;
		area.level = level;
		area.box = single;
		area.weight = weight;
		ptr->areaBoxMap[area.areaId] = area;
		ptr->groupIds.push_back(pg.id);
	}

	//--done--
	int MysteryAreaSystem::getReward(const mystery::PoolGroup& pg, int& aID, int& id, int& v, int& level, int& weight)
	{
		LogS << "mystery==>reset area-getReward-odds.size=" << pg.poolList.odds.size() << LogEnd;
		int idx = lx::utility_lx::getProbIndex(pg.poolList.odds, pg.poolList.odds.back());
		aID = pg.poolList.list[idx].reward.aID;
		level = pg.poolList.list[idx].level;
		id = pg.poolList.list[idx].reward.id;
		weight = pg.poolList.list[idx].pWeight;
		if (aID == ACTION::item
			|| aID == ACTION::kingdom_skill_exp
			|| aID == ACTION::lady
			//|| aID == ACTION::man
			)
		{
			v = pg.poolList.list[idx].reward.v;
		}
		else
		{
			v = Common::randomBetween(pg.poolList.list[idx].lbound, pg.poolList.list[idx].ubound);
			int divisor = pg.poolList.list[idx].minUnit;
			if (pg.poolList.list[idx].minUnit <= 0)
			{
				divisor = 1;
			}
			int remainder = v % divisor;
			int add = remainder == 0 ? 0 : 1;
			int quotients = v / divisor;
			if (pg.poolList.list[idx].dir == 1)
			{
				//����ȡ��
				v = (quotients + add) * divisor;
			}
			else
			{
				v = v - remainder;
			}
		}
		return 0;
	}

	int MysteryAreaSystem::getResetKey(int normal)
	{
		for (int i = 1; i < _config.resetKeys.size(); ++i)
		{
			if (normal < _config.resetKeys[i])
			{
				return _config.resetKeys[i - 1];
			}
		}
		if (normal >= _config.resetKeys.back())
		{
			return _config.resetKeys.back();
		}
		return _config.resetKeys.front();
	}

	int MysteryAreaSystem::getExploreKey(int normal)
	{
		for (int i = 1; i < _config.exploreKeys.size(); ++i)
		{
			if (normal < _config.exploreKeys[i])
			{
				return _config.exploreKeys[i - 1];
			}
		}
		if (normal >= _config.exploreKeys.back())
		{
			return _config.exploreKeys.back();
		}
		return _config.exploreKeys.front();
	}

	/*
	int MysteryAreaSystem::getNormalKey(int flag)
	{
		for (int i = 1; i < _config.keyTimesSeq.size(); ++i)
		{
			if (flag >= _config.keyTimesSeq[i - 1] && flag < _config.keyTimesSeq[i])
			{
				return _config.keyTimesSeq[i - 1];
			}
		}
		return _config.keyTimesSeq.back();
	}

	int MysteryAreaSystem::getLevel(int pro_group_id)
	{
		mystery::Sequence pros = _config.proGroups[pro_group_id];
		int rnd = Common::randomBetween(pros[0], pros[pros.size() - 1]);
		for (int i = 1; i < pros.size(); ++i)
		{
			if (rnd >= pros[i - 1] && rnd < pros[i])
			{
				return i;
			}
		}
		return 1;//������͵���
	}

	int MysteryAreaSystem::getIdAndV(int aID, int level, int& id)
	{
		mystery::MysteryUnitPtr unit = _config.detail[aID];
		mystery::Sequence section = unit->reward[level];
		int v;
		if (aID == ACTION::item
			|| aID == ACTION::kingdom_skill_exp
			|| aID == ACTION::lady)
		{
			v = section[1];
			id = section[0];
		}
		else
		{
			v = Common::randomBetween(section[0], section[1]);
			//ȡ��
			int remainder = v % unit->minUnit;
			int quotients = v / unit->minUnit;
			if (unit->direction == 0)
			{
				v = quotients*unit->minUnit;
			}
			else
			{
				v = v - remainder;
			}

		}
		return v;
	}
	*/

	void MysteryAreaSystem::resetPlayerArea(playerDataPtr player, int type, Json::Value cost)
	{
		int reset_time = player->MysteryArea().resetTime();
		//LogS << "mystery:reset area" << LogEnd;
		mystery::TreasurePtr treasure = generateTreasure(player, reset_time);
		player->MysteryArea().reset();
		player->MysteryArea().setNewTreasure(treasure);
		player->MysteryArea().setAllCost(_config.allCost);
		Json::Value boxes = Json::arrayValue;
		for (mystery::AreaBoxMap::iterator it = treasure->areaBoxMap.begin();
			it != treasure->areaBoxMap.end();
			++it)
		{
			combineJsonBox(it->second.box->strBox, boxes);
		}
		Log(DBLOG::strLogMysteryArea, player, type, cost.toIndentString(), boxes.toIndentString());
	}

	void MysteryAreaSystem::broadcast(int type, int time, const std::string& pn, const Json::Value& pinfo, const std::string& area_name, Json::Value json_box)
	{
		Json::Value null_value = Json::arrayValue;
		Json::Value json;
		json["weight"] = 0;
		json["roll"] = time;
		LogS << "mystery:broadcast==>type:" << type << "\tname:" << pn << LogEnd;
		if (type == CHAT::server_activity_mystery_area_add_explore)
		{
			null_value.append(pn);
			null_value.append(pinfo);
			chat_sys.despatchAllSP(type, null_value, json, CHATPOS::chat_windows);
		}
		else if(type == CHAT::server_activity_mystery_area_get_high)
		{
			null_value.append(pn);
			null_value.append(area_name);
			null_value.append(json_box);
			null_value.append(pinfo);
			chat_sys.despatchAllSP(type, null_value, json, CHATPOS::chat_windows | CHATPOS::scroll_bar_top);
		}
	}

	void MysteryAreaSystem::handleLevel(int level, playerDataPtr player, const Json::Value& json_box, int area_id, const std::string& area_name)
	{
		int pid = player->ID();
		if (level == _config.keyLevel)
		{
			Json::Value pinfo = chat_sys.ChatPackage(player);
			broadcast(CHAT::server_activity_mystery_area_get_high, 1, player->Name(), pinfo, area_name, json_box);
			insertRecord(_config.actiId, pid, 1);
			int r = _users_top_records[_config.actiId][pid] % _config.keyTime;
			if (r == 0)
			{
				LogS << "mystery==>handle:aid=" << _config.actiId << "\tpid=" << pid << "\ttime=" << _users_top_records[_config.actiId][pid] << LogEnd;
				LogS << "mystery==>add free time. pid=" << player->ID() << LogEnd;
				++_add_foc_reset_time;
				//===============================�㲥��Ϣ
				Json::Value ret_json = Json::nullValue;
				ret_json[strMsg][0u] = 0;
				ret_json[strMsg][1u] = 1;
				player_mgr.sendToAll(gate_client::mystery_area_foc_explore_add_resp, ret_json);
				broadcast(CHAT::server_activity_mystery_area_add_explore, 1, player->Name(), pinfo);
				//_users_top_records[_config.actiId][pid] = 0;//���ô���
			}

			insertReward(_config.actiId, json_box, pid, player->Name(), area_id);
			updateRecord(pid);
			updateReward(pid);
		}
	}

	void MysteryAreaSystem::insertRecord(int acti_id, int pid, int times)
	{
		mystery::ActiUTMap::iterator ait = _users_top_records.find(acti_id);
		if (ait == _users_top_records.end())
		{
			//�µ�һ���
			mystery::UserTimesMap ut;
			ut[pid] = times;
			_users_top_records[_config.actiId] = ut;
			//LogS << "msytery==>acti Record new:pid=" << pid << "\ttimes=" << _users_top_records[acti_id][pid] << LogEnd;
		}
		else
		{
			mystery::UserTimesMap::iterator uit = ait->second.find(pid);
			if (uit == ait->second.end())
			{
				ait->second[pid] = times;
				//LogS << "msytery==>Record new:pid=" << pid << "\ttimes=" << ait->second[pid] << LogEnd;
			}
			else
			{
				++ait->second[pid];
				//LogS << "msytery==>Record add:pid=" << pid << "\ttimes=" << ait->second[pid] << LogEnd;
			}
		}
		//updateRecord(pid);
	}

	void MysteryAreaSystem::insertReward(int acti_id, const Json::Value& json_box, int pid, const std::string& pn, int area_id)
	{
		mystery::PlayerInfo infos;
		infos.jsonBox = json_box;
		infos.pid = pid;
		infos.name = pn;
		infos.aid = area_id;
		std::map<int, mystery::PlayerJsonList>::iterator pit = _users_top_rewards.find(acti_id);
		if (pit == _users_top_rewards.end())
		{
			//LogS << "INSERT-mystery==>acti not exist. add acti_id=" << acti_id << LogEnd;
			//�����û�д��ڹ�
			mystery::PlayerJsonList pjl;
			mystery::JsonList jsons;
			jsons.push_back(infos);
			pjl[pid] = jsons;
			_users_top_rewards[_config.actiId] = pjl;
		}
		else
		{
			mystery::PlayerJsonList::iterator jit = pit->second.find(pid);
			if (jit == pit->second.end())
			{
				//LogS << "INSERT-mystery==>player not exist. add pid=" << pid << LogEnd;
				mystery::JsonList jsons;
				pit->second[pid] = jsons;
			}
			pit->second[pid].push_back(infos);
		}
		//LogS << "INSERT-mystery==>insert Reward: total player=" << _users_top_rewards[acti_id].size() << LogEnd;
		//updateReward(pid);
	}

	void MysteryAreaSystem::init(bool isReboot)
	{
		if (!isReboot)
		{
			//������������ô�����¿���ĳ�ʼ��
			_users_top_records.clear();
			_add_foc_reset_time = 0;
			_users_top_rewards.clear();
		}
		for (int i = 0; i < TREASURE_NUM; ++i)
		{
			_fixedBoxId.push_back(i + 1);
			Json::Value reward_json = Json::arrayValue;
			reward_json.append(i + 1);//����ID
			reward_json.append(Json::arrayValue);
			reward_json.append(1);//Ĭ�Ͽ�ˢ��
			reward_json.append(0);//
			_fixedRewardBoxInfo[i] = reward_json;

			Json::Value area_json = Json::arrayValue;
			area_json.append(i + 1);//�ؾ�ID
			area_json.append(1);
			_fixedAreaInfo[i] = area_json;
		}
	}

	int MysteryAreaSystem::validateRes(playerDataPtr player, const mystery::Sequence& res, int discount)
	{
		if (res.size() != 2)
		{
			//LogS << "mystery==>validateRes:res.size != 2" << LogEnd;
			return 1;//��������
		}
		int aid = res[0];
		int num = res[1];
		num = (discount * num) / 100;
		//LogS << "mystery==>validateRes:aid=" << aid << "\tnum=" << num << "\tdiscount=" << discount << LogEnd;
		if (aid == ACTION::gold)
		{
			if (player->Res().getGold() >= num)
			{
				return 0;
			}
			else
			{
				//LogS << "mystery==>validateRes:gold NOT ENOUGH" << num << LogEnd;
				return 1;
			}
		}
		else if (aid == ACTION::ticket)
		{
			if (player->Res().getTicket() >= num)
			{
				return 0;
			}
			else
			{
				//LogS << "mystery==>validateRes:ticket NOT ENOUGH" << num << LogEnd;
				return 1;
			}
		}
		else if (aid == ACTION::cash)
		{
			if (player->Res().getCash() >= num)
			{
				
				return 0;
			}
			else
			{
				//LogS << "mystery==>validateRes:cash NOT ENOUGH" << num << LogEnd;
				return 1;
			}
		}
		else if (aid == ACTION::exploit_coin)
		{
			if (player->Res().getExploit() >= num)
			{
				return 0;
			}
			else
			{
				//LogS << "mystery==>validateRes:exploit_coin NOT ENOUGH" << num << LogEnd;
				return 1;
			}
		}
		else if (aid == -1)
		{
			return 0;
		}
		else
		{
			return 1;
		}
	}

	void MysteryAreaSystem::consumeRes(playerDataPtr player, const mystery::Sequence& res, int discount)
	{
		if (res.size() != 2)
		{
			return;//��������
		}
		int aid = res[0];
		int num = res[1];
		num = (discount * num) / 100;
		if (aid == ACTION::gold)
		{
			player->Res().alterGold(-num);
		}
		else if (aid == ACTION::ticket)
		{
			player->Res().alterTicket(-num);
		}
		else if (aid == ACTION::cash)
		{
			player->Res().alterCash(-num);
		}
		else if (aid == ACTION::exploit_coin)
		{
			player->Res().alterExploit(-num);
		}
	}

	Json::Value MysteryAreaSystem::getExploreCost(int times)
	{
		//int key = getExploreKey(times);
		mystery::IntSeqMap::iterator it = _config.explore.find(times);
		if (it == _config.explore.end())
		{
			return Json::nullValue;
		}
		else
		{
			int aid = it->second[0];
			int num = it->second[1];
			Json::Value json = Json::arrayValue;
			json[0u][0u] = aid;
			json[0u][1u] = num;
			json[1u] = _config.exploreDiscount;
			return json;
		}
	}

	Json::Value MysteryAreaSystem::getExploreAllCost(const mystery::Sequence& allCost, int discount)
	{
		Json::Value cost = Json::arrayValue;
		cost[0] = allCost[0];
		cost[1] = allCost[1];
		Json::Value json = Json::arrayValue;
		json[0u] = cost;
		json[1u] = _config.restPiece;
		json[2u] = discount;
		//LogS << "mystery\tall_cost:" << json.toIndentString() << LogEnd;
		return json;
	}

	Json::Value MysteryAreaSystem::getResetCost(playerDataPtr player)
	{
		int times = player->MysteryArea().resetTime();
		int key = getResetKey(times);
		times -= 1;
		mystery::IntSeqMap::iterator it = _config.reset.find(key);
		if (it == _config.reset.end())
		{
			return Json::nullValue;
		}
		else
		{
			int aid = it->second[0];
			int num = it->second[1];
			Json::Value json = Json::arrayValue;
			json[0u][0u] = aid;
			json[0u][1u] = num;
			json[1u] = _config.resetDiscount;
			json[2u] = player->MysteryArea().foc();
			//LogS << "mystery\treset cost json:" << json.toIndentString() << LogEnd;
			return json;
		}
	}

	void MysteryAreaSystem::ActivityBegin(const structTimer& timerData)
	{
		Json::Value json;
		json[strMsg][0u] = 0;
		json[strMsg][1u] = 0;
		player_mgr.sendToAll(gate_client::mystery_area_activity_begin_resp, json);
	}

	void MysteryAreaSystem::ActivityOver(const structTimer& timerData)
	{
		Json::Value json;
		json[strMsg][0u] = 0;
		json[strMsg][1u] = 2;
		_config.actiId = -1;
		player_mgr.sendToAll(gate_client::mystery_area_activity_over_resp, json);
		//dropRecord();
		//dropReward();
	}

	void MysteryAreaSystem::selectActi()
	{
		unsigned now = Common::gameTime();
		//initConfig();
		//ѡ��һ������Ļ��Ϊ��ǰ�
		mystery::MysteryConfigList::reverse_iterator rit = _preConfigList.rbegin();
		for (;rit != _preConfigList.rend(); ++rit)
		{
			if (rit->second.actiId != _config.actiId
				&& now > rit->second.stime && rit->second.etime > now
				&& _configList.find(rit->second.configId) != _configList.end())
			{
				//�����µĻ
				init(false);
				_config = _configList[rit->second.configId];
				_config.stime = rit->second.stime;
				_config.etime = rit->second.etime;
				_config.actiId = rit->second.actiId;
				_config.resetDiscount = rit->second.resetDiscount;
				_config.exploreDiscount = rit->second.exploreDiscount;
				int total = _config.exploreDiscount*_config.restDiscount;
				_config.restDiscount = total / 100;
				int r = total % 100;
				if (r != 0)
				{
					_config.restDiscount = _config.restDiscount + 1 > 100 ? 100 : _config.restDiscount;
				}
				/*_add_foc_reset_time = 0;
				_users_top_records.clear();
				_users_top_rewards.clear();*/
				LogS << "mystery\t" << "acti_id:" << _config.actiId << LogEnd;
				return;
			}
		}
	}

	void MysteryAreaSystem::initConfig()
	{
		_config.actiId = -1;
		_config.configId = -1;
		_config.stime = 1;
		_config.keyTime = KEY_TIMES;
	}

	void MysteryAreaSystem::loadData()
	{
		objCollection objs = db_mgr.Query(DBN::dbSystemActivityMysteryArea);
		unsigned now = Common::gameTime();
		ForEachC(objCollection, it, objs)
		{
			const mongo::BSONObj& obj = (*it);
			unsigned id = obj[strActiId].Int();
			unsigned etime = obj[strETime].Int();
			if (now > etime)
			{
				delActi(id);
				continue;
			}
			mystery::MysteryConfig config;
			config.stime = obj[strSTime].Int();
			config.etime = etime;
			config.configId = obj[strConfigId].Int();
			config.actiId = id;
			config.resetDiscount = obj[strResetDiscount].Int();
			config.exploreDiscount = obj[strExploreDiscount].Int();
			_preConfigList[config.actiId] = config;
			_stimer[config.actiId] = Timer::AddEventTickTime(boostBind(MysteryAreaSystem::ActivityBegin, _1), Inter::event_activity_begin, config.stime);
			_etimer[config.actiId] = Timer::AddEventTickTime(boostBind(MysteryAreaSystem::ActivityOver, _1), Inter::event_activity_over, config.etime);
		}
		selectActi();

		///
		objCollection objs2 = db_mgr.Query(DBN::dbSystemActivityMysteryAreaRecord);
		ForEachC(objCollection, it, objs2)
		{
			const mongo::BSONObj& obj = (*it);
			int times = obj[strTimes].Int();
			int pid = obj[strPlayerID].Int();
			int aid = obj[strActiId].Int();
			int inc = times / _config.keyTime;
			LogS << "mystery==>load:aid=" << aid << "\tpid=" << pid << "\ttime=" << times << LogEnd;
			if (aid == _config.actiId)
			{
				_add_foc_reset_time += inc;
			}
			else
			{
				insertRecord(aid, pid, times);
			}
		}
		LogS << "add foc=" << _add_foc_reset_time << LogEnd;

		objCollection objs3 = db_mgr.Query(DBN::dbSystemActivityMysteryAreaReward);
		ForEachC(objCollection, it, objs3)
		{
			const mongo::BSONObj& obj = (*it);
			int pid = obj[strPlayerID].Int();
			int aid = obj[strActiId].Int();
			std::vector<mongo::BSONElement> boxes = obj[strBoxes].Array();
			mystery::JsonList list;
			for (int i = 0; i < boxes.size(); i += 3)
			{
				int area_id = boxes[i].Int();
				std::string name = boxes[i + 1].String();
				Json::Value json_box = Common::string2json(boxes[i + 2].String());
				insertReward(aid, json_box, pid, name, area_id);
			}
		}
	}

	bool MysteryAreaSystem::saveActi(const mystery::MysteryConfig& config)
	{
		mongo::BSONObj key = BSON(strActiId << config.actiId);

		mongo::BSONObj obj = BSON(strActiId << config.actiId
		<< strConfigId << config.configId
		<< strSTime << config.stime
		<< strETime << config.etime
		<< strExploreDiscount << config.exploreDiscount
		<< strResetDiscount << config.resetDiscount);

		return db_mgr.SaveMongo(DBN::dbSystemActivityMysteryArea, key, obj);
	}

	void MysteryAreaSystem::delActi(int acti_id)
	{
		mongo::BSONObj key = BSON(strActiId << acti_id);

		db_mgr.RemoveCollection(DBN::dbSystemActivityMysteryArea, key);
	}

	void MysteryAreaSystem::updateRecord(int pid)
	{
		mystery::ActiUTMap::iterator ait = _users_top_records.find(_config.actiId);
		if (ait == _users_top_records.end())
		{
			return;
		}

		std::map<int, int>::iterator it = ait->second.find(pid);
		if (it == ait->second.end())
		{
			return;
		}
		mongo::BSONObj key = BSON(strActiId << _config.actiId << strPlayerID << pid);

		mongo::BSONObj obj = BSON(strActiId << _config.actiId 
			<< strPlayerID << pid
			<< strTimes << it->second
		);

		db_mgr.SaveMongo(DBN::dbSystemActivityMysteryAreaRecord, key, obj);
	}

	void MysteryAreaSystem::updateReward(int pid)
	{
		std::map<int, mystery::PlayerJsonList>::iterator ait = _users_top_rewards.find(_config.actiId);
		if (ait == _users_top_rewards.end())
		{
			return;
		}
		std::map<int, mystery::JsonList>::iterator it = ait->second.find(pid);
		if (it == ait->second.end())
		{
			return;
		}
		mongo::BSONObj key = BSON(strActiId << _config.actiId << strPlayerID << pid);

		mystery::JsonList json_list = it->second;
		mongo::BSONArrayBuilder boxes;
		for (int i = 0; i < json_list.size(); ++i)
		{
			//boxes << json_list[i].pid << json_list[i].name << json_list[i].aid << json_list[i].jsonBox.toIndentString();
			boxes << json_list[i].aid << json_list[i].name << json_list[i].jsonBox.toIndentString();
		}
		mongo::BSONObj obj = BSON(strActiId << _config.actiId 
			<< strPlayerID << pid
			<< strBoxes << boxes.arr()
		);

		db_mgr.SaveMongo(DBN::dbSystemActivityMysteryAreaReward, key, obj);
	}

	void MysteryAreaSystem::dropRecord()
	{
		//db_mgr.DropTable(DBN::dbSystemActivityMysteryAreaRecord);
	}

	void MysteryAreaSystem::dropReward()
	{
		//db_mgr.DropTable(DBN::dbSystemActivityMysteryAreaReward);
	}

	void MysteryAreaSystem::initData()
	{
		std::cout << "load ./mystery_area/mystery.json START	" << std::endl;
		//mystery_area/
		Json::Value config_json = Common::loadJsonFile(std::string("./instance/mystery_area/mystery.json"));

		for (int j = 0; j < config_json.size(); ++j)
		{
			mystery::MysteryConfig config;
			config.configId = config_json[j]["id"].asInt();
			assert(config.configId > 0);

			config.lv = config_json[j]["lv"].asInt();
			assert(config.lv > 0);

			config.keyLevel = config_json[j]["key_level"].asInt();
			assert(config.keyLevel > 1);
			config.keyTime = config_json[j]["key_time"].asInt();
			assert(config.keyTime > 1);

			config.configName = config_json[j]["desc"].asString();
			Json::Value& mid = config_json[j]["mid"];
			for (int i = 0; i < mid.size(); ++i)
			{
				config.mIds.push_back(mid[i].asInt());
				config.mIdsMap[mid[i].asInt()] = 1;
			}
			Json::Value& m_names = config_json[j]["m_name"];
			assert(config.mIds.size() == m_names.size());
			for (int i = 0; i < m_names.size(); ++i)
			{
				config.names[config.mIds[i]] = m_names[i].asString();
			}

			Json::Value& discount = config_json[j]["discount"];
			config.restPiece = discount[0].asInt();
			config.restDiscount = discount[1].asInt();
			assert(config.restDiscount > 0 && config.restDiscount < 101);

			Json::Value& explore = config_json[j]["explore"];
			assert(explore.size() == TREASURE_NUM);
			config.allCost.push_back(explore[0][1u].asInt());
			config.allCost.push_back(0);
			for (int i = 0; i < explore.size(); ++i)
			{
				int times = explore[i][0u].asInt();
				mystery::Sequence seq;
				seq.push_back(explore[i][1u].asInt());
				if (seq[0] != -1
					&& seq[0] != ACTION::gold
					&& seq[0] != ACTION::ticket
					&& seq[0] != ACTION::cash
					&& seq[0] != ACTION::exploit_coin)
				{
					assert(0 != 0);
				}
				seq.push_back(explore[i][2u].asInt());
				config.allCost[1] += seq.back();//
				config.explore[times] = seq;
				config.exploreKeys.push_back(times);
			}
			for (int i = 1; i < config.exploreKeys.size(); ++i)
			{
				assert(config.exploreKeys[i] > config.exploreKeys[i - 1]);
			}

			Json::Value& reset = config_json[j]["reset"];
			for (int i = 0; i < reset.size(); ++i)
			{
				int times = reset[i][0u].asInt();
				mystery::Sequence seq;
				seq.push_back(reset[i][1u].asInt());
				if (seq[0] != -1
					&& seq[0] != ACTION::gold
					&& seq[0] != ACTION::ticket
					&& seq[0] != ACTION::cash
					&& seq[0] != ACTION::exploit_coin)
				{
					assert(0 != 0);
				}
				seq.push_back(reset[i][2u].asInt());
				config.reset[times] = seq;
				config.resetKeys.push_back(times);
				if (seq.back() == 0)
				{
					++config.focResetTime;
				}
			}
			for (int i = 1; i < config.resetKeys.size(); ++i)
			{
				assert(config.resetKeys[i] > config.resetKeys[i - 1]);
			}

			_configList[config.configId] = config;
		}

		std::string name_suffix = ".json";
		mystery::MysteryConfigList::iterator it = _configList.begin();
		for (; it != _configList.end(); ++it)
		{
			std::string config_file_name = "./instance/mystery_area/pool_";
			config_file_name += boost::lexical_cast<std::string>(it->first);
			config_file_name += name_suffix;
			Json::Value pool_json = Common::loadJsonFile(config_file_name);
			lx::OddUnit odd_unit_start;
			odd_unit_start.idx = -1;
			odd_unit_start.odd = 0;
			it->second.pool.odds.push_back(odd_unit_start);
			int sum = 0;
			for (int i = 0; i < pool_json.size(); ++i)
			{
				mystery::PoolGroup group;
				group.id = pool_json[i]["group"].asInt();
				group.weight = pool_json[i]["weight"].asInt();
				assert(group.weight >= 0);
				group.must = pool_json[i]["must"].asInt();
				Json::Value& units = pool_json[i]["pool"];
				group.poolList.odds.reserve(units.size() + 1);
				group.poolList.odds.push_back(0);
				//construct poolUnitList(poolList)
				for (int j = 0; j < units.size(); ++j)
				{
					mystery::PoolUnit pool_unit;
					pool_unit.id = units[j]["ID"].asInt();
					pool_unit.weight = units[j]["weight"].asInt();
					if (pool_unit.weight <= 0)
					{
						continue;
					}
					pool_unit.reward.aID = units[j]["aId"].asInt();
					pool_unit.reward.id = units[j]["id"].asInt();
					pool_unit.reward.v = units[j]["v"].asInt();
					if (pool_unit.reward.aID == ACTION::item
						|| pool_unit.reward.aID == ACTION::kingdom_skill_exp
						|| pool_unit.reward.aID == ACTION::lady)
					{
						assert(pool_unit.reward.id != -1);
						assert(pool_unit.reward.v != -1);
					}
					else
					{
						assert(pool_unit.reward.id == -1);
						assert(pool_unit.reward.v == -1);
					}
					pool_unit.ubound = units[j]["upper"].asInt();
					pool_unit.lbound = units[j]["floor"].asInt();
					pool_unit.minUnit = units[j]["min_unit"].asInt();
					pool_unit.pWeight = units[j]["weight_p"].asInt();
					assert(pool_unit.pWeight > 0);
					if (pool_unit.ubound < 1) pool_unit.ubound = 1;
					if (pool_unit.lbound < 1) pool_unit.lbound = 1;
					if (pool_unit.minUnit < 1) pool_unit.minUnit = 1;
					//assert(pool_unit.ubound >= 1 && pool_unit.lbound >= 1 && pool_unit.minUnit >= 1);
					pool_unit.dir = units[j]["dir"].asInt();
					pool_unit.level = units[j]["level"].asInt();
					group.poolList.odds.push_back(group.poolList.odds.back() + pool_unit.weight);
					group.poolList.list.push_back(pool_unit);
				}
				assert(group.poolList.list.size() > 0 && group.poolList.odds.size() > 0);
				if (group.weight == 0)
				{
					it->second.zeroPool.insert(make_pair(group.must, group));
					continue;
				}
				it->second.pool.groups.push_back(group);
				it->second.pool.musts.insert(make_pair(group.must, it->second.pool.groups.size() - 1));
				lx::OddUnit odd_unit;
				//odd_unit.idx = i;//�����i���ܱ���Ȩ��Ϊ����飩����
				odd_unit.idx = it->second.pool.groups.size() - 1;
				odd_unit.odd = group.weight;
				it->second.pool.odds.push_back(odd_unit);
				sum += group.weight;
			}
			assert(it->second.pool.groups.size() >= 12);
			lx::OddUnit odd_unit_end;
			odd_unit_end.idx = -3;//idx can't be -2, or it will be an error.
			odd_unit_end.odd = sum;
			it->second.pool.odds.push_back(odd_unit_end);
		}

		std::cout << "load ./mystery_area/mystery.json END	" << std::endl;

		init(true);
		//�������
		/*for (mystery::MysteryConfigList::iterator it = _configList.begin();
			it != _configList.end();
			++it)
		{
			for (mystery::ZeroPool::iterator sit = it->second.zeroPool.begin();
				sit != it->second.zeroPool.end();
				++sit)
			{
				for (int i = 0; i < sit->second.poolList.list.size(); ++i)
				{
					LogS << "minUnit:" << sit->second.poolList.list[i].minUnit << LogEnd;
				}
			}
			LogS << "pool" << LogEnd;
			for (int i = 0; i < it->second.pool.groups.size(); ++i)
			{
				for (int j = 0; j < it->second.pool.groups[i].poolList.list.size(); ++j)
				{
					LogS << "minUnit:" << it->second.pool.groups[i].poolList.list[j].minUnit << LogEnd;
				}
			}
		}*/
	}

	MysteryAreaSystem::~MysteryAreaSystem()
	{
	}

}

#include "business_single_rank.h"

namespace gg
{
	BusinessSingleRank* const BusinessSingleRank::_Instance = new BusinessSingleRank();

	using namespace NSBusinessSingleRank;

	ptrRankData BusinessSingleRank::getData(const int playerID)
	{
		PlayerMap::const_iterator it = Player.find(playerID);
		if (it == Player.end())return ptrRankData();
		return it->second;
	}
	int BusinessSingleRank::getRank(const int playerID)
	{
		ptrRankData ptr = getData(playerID);
		return ptr ? ptr->rankNo : -1;
	}


	void BusinessSingleRank::initData()
	{
		if (isInitial)return;
		cout << "initial business singlelist ..." << endl;
		Rank.clear();
		Player.clear();
		mongo::Query find_query(BSON("hm" << BSON("$gt" << 0)));
		find_query.sort(strPlayerID, 1).sort("hm", -1);
		objCollection objs = db_mgr.QueryCustom(DBN::dbPlayerTrade, find_query, 100);
		for (unsigned i = 0; i < objs.size(); ++i)
		{
			mongo::BSONObj& obj = objs[i];
			const int playerID = obj[strPlayerID].Int();
			playerDataPtr now_player = player_mgr.getPlayer(playerID);
			if (!now_player)break;
			ptrRankData ptr = Creator<RankData>::Create(now_player);
			Rank[ptr->Key()] = ptr;
			Player[ptr->playerID] = ptr;
		}
		unsigned rank_begin = 0;
		for (RankMap::iterator it = Rank.begin(); it != Rank.end(); ++it)
		{
			it->second->rankNo = (++rank_begin);
		}
		cout << "business singlesize:" << Rank.size() << "\t" << Player.size() << endl;
		isInitial = true;
	}

	void BusinessSingleRank::RankList(net::Msg& m, Json::Value& r)
	{
		playerDataPtr player = player_mgr.getPlayer(m.playerID);
		if (!player)Return(r, err_illedge);//�Ƿ�����
		qValue json(qJson::qj_array);
		for (RankMap::const_iterator it = Rank.begin(); it != Rank.end(); ++it)
		{
			ptrRankData ptr = it->second;
			json.append(
				qValue(qJson::qj_array).
				append(ptr->playerID).
				append(ptr->playerName).
				append(ptr->playerNation).
				append(ptr->businessMoney)
			);
		}
		ptrRankData ownData = getData(m.playerID);
		player->sendToClientFillMsg(gate_client::player_business_single_rank_resp,
			qValue(qJson::qj_array).
			append(res_sucess).
			append(json).
			append(ownData ? ownData->rankNo : -1).
			append(ownData ? ownData->businessMoney : player->Trade().historyMoney())
		);
	}

	void BusinessSingleRank::updatePlayer(playerDataPtr player)
	{
		if (false == isInitial)return;
		if (player->Trade().historyMoney() < 1)return;
		Rankey new_key(player);
		ptrRankData ptr = getData(player->ID());
		if (ptr)//�ȸ��·ǹ�Ҫ����
		{
			ptr->playerName = player->Name();
			ptr->playerNation = player->Info().Nation();
			//���key�Ƿ���������ļ�ֵ
			Rankey old_key = ptr->Key();
			if (!(new_key > old_key))return;
			ptr->setNewData(player);
		}
		else
		{
			ptr = Creator<RankData>::Create(player);
		}
		RankMap::iterator insert_it = Rank.insert(RankMap::value_type(ptr->Key(), ptr)).first;
		RankMap::iterator check_it = insert_it;
		++check_it;
		if (check_it == Rank.end())
		{
			ptr->rankNo = Rank.size();
			if (ptr->rankNo > 100)
			{
				Rank.erase(insert_it);
				return;
			}
			Player[ptr->playerID] = ptr;
			return;
		}
		else
		{
			ptr->rankNo = check_it->second->rankNo;
		}
		if (ptr->rankNo > 100)
		{
			Rank.erase(insert_it);
			return;
		}
		Player[ptr->playerID] = ptr;
		int begin_rank = ptr->rankNo;
		for (; check_it != Rank.end();)
		{
			ptrRankData it_ptr = check_it->second;
			if (it_ptr->playerID == ptr->playerID)
			{
				Rank.erase(check_it);
				break;
			}
			it_ptr->rankNo = (++begin_rank);
			if (it_ptr->rankNo > 100)
			{
				Rank.erase(check_it++);
				Player.erase(it_ptr->playerID);
				continue;
			}
			++check_it;
		}
	}

}
#include "business_daily_rank.h"
#include "dbDriver.h"

namespace gg
{
	BusinessDailyRank* const BusinessDailyRank::_Instance = new BusinessDailyRank();

	using namespace NSBusinessDailyRank;

	ptrRankData BusinessDailyRank::getData(const int playerID)
	{
		PlayerMap::const_iterator it = Player.find(playerID);
		if (it == Player.end())return ptrRankData();
		return it->second;
	}
	int BusinessDailyRank::getRank(const int playerID)
	{
		ptrRankData ptr = getData(playerID);
		return ptr ? ptr->rankNo : -1;
	}


	void BusinessDailyRank::initData()
	{
		if (isInitial)return;
		cout << "initial business daily list ..." << endl;
		Rank.clear();
		Player.clear();
		mongo::Query find_query;
		find_query.sort(strPlayerID, 1).sort("m", -1);
		objCollection objs = db_mgr.QueryCustom(DBN::dbBusinessDailyRank, find_query, 100);
		for (unsigned i = 0; i < objs.size(); ++i)
		{
			mongo::BSONObj& obj = objs[i];
			const int playerID = obj[strPlayerID].Int();
			playerDataPtr now_player = player_mgr.getPlayer(playerID);
			if (!now_player)break;
			ptrRankData ptr = Creator<RankData>::Create(now_player);
			ptr->businessMoney = obj["m"].Int();
			Rank[ptr->Key()] = ptr;
			Player[ptr->playerID] = ptr;
		}
		unsigned rank_begin = 0;
		for (RankMap::iterator it = Rank.begin(); it != Rank.end(); ++it)
		{
			it->second->rankNo = (++rank_begin);
		}
		cout << "business daily size:" << Rank.size() << "\t" << Player.size() << endl;
		isInitial = true;
	}

	void BusinessDailyRank::RankList(net::Msg& m, Json::Value& r)
	{
		playerDataPtr player = player_mgr.getPlayer(m.playerID);
		if (!player)Return(r, err_illedge);//�Ƿ�����
		qValue json(qJson::qj_array);
		for (RankMap::const_iterator it = Rank.begin(); it != Rank.end(); ++it)
		{
			ptrRankData ptr = it->second;
			json.append(
				qValue(qJson::qj_array).
				append(ptr->playerID).
				append(ptr->playerName).
				append(ptr->playerNation).
				append(ptr->businessMoney)
			);
		}
		ptrRankData ownData = getData(m.playerID);
		player->sendToClientFillMsg(gate_client::player_business_daily_rank_resp,
			qValue(qJson::qj_array).
			append(res_sucess).
			append(json).
			append(ownData ? ownData->rankNo : -1)
		);
	}

	void BusinessDailyRank::clearAllData()
	{
		Rank.clear();
		Player.clear();
		db_mgr.RemoveCollection(DBN::dbBusinessDailyRank);
	}

	void BusinessDailyRank::updateInfo(playerDataPtr player)
	{
		ptrRankData ptr = getData(player->ID());
		if (ptr)
		{
			ptr->playerName = player->Name();
			ptr->playerNation = player->Info().Nation();
		}
	}

	void BusinessDailyRank::saveData(NSBusinessDailyRank::ptrRankData data)
	{
		mongo::BSONObj key = BSON(strPlayerID << data->playerID);
		mongo::BSONObj obj = BSON(strPlayerID << data->playerID << "m" << data->businessMoney);
		db_mgr.SaveMongo(DBN::dbBusinessDailyRank, key, obj);
	}

	void BusinessDailyRank::delData(const int playerID)
	{
		mongo::BSONObj key = BSON(strPlayerID << playerID);
		db_mgr.RemoveCollection(DBN::dbBusinessDailyRank, key);
	}

	void BusinessDailyRank::updatePlayer(playerDataPtr player, const int money)
	{
		if (false == isInitial)return;
		if (money < 1)return;
		Rankey new_key;
		new_key.playerID = player->ID();
		new_key.businessMoney = money;
		ptrRankData ptr = getData(player->ID());
		if (ptr)//�ȸ��·ǹ�Ҫ����
		{
			ptr->playerName = player->Name();
			ptr->playerNation = player->Info().Nation();
			//���key�Ƿ���������ļ�ֵ
			Rankey old_key = ptr->Key();
			if (!(new_key > old_key))return;
			ptr->setNewData(player);
		}
		else
		{
			ptr = Creator<RankData>::Create(player);
		}
		ptr->businessMoney = money;
		RankMap::iterator insert_it = Rank.insert(RankMap::value_type(ptr->Key(), ptr)).first;
		RankMap::iterator check_it = insert_it;
		++check_it;
		if (check_it == Rank.end())
		{
			ptr->rankNo = Rank.size();
			if (ptr->rankNo > 100)
			{
				Rank.erase(insert_it);
				return;
			}
			Player[ptr->playerID] = ptr;
			return;
		}
		else
		{
			ptr->rankNo = check_it->second->rankNo;
		}
		if (ptr->rankNo > 100)
		{
			Rank.erase(insert_it);
			return;
		}
		Player[ptr->playerID] = ptr;
		int begin_rank = ptr->rankNo;
		for (; check_it != Rank.end();)
		{
			ptrRankData it_ptr = check_it->second;
			if (it_ptr->playerID == ptr->playerID)
			{
				Rank.erase(check_it);
				break;
			}
			it_ptr->rankNo = (++begin_rank);
			if (it_ptr->rankNo > 100)
			{
				Rank.erase(check_it++);
				Player.erase(it_ptr->playerID);
				delData(it_ptr->playerID);
				continue;
			}
			++check_it;
		}

		if (getData(player->ID()))
		{
			saveData(ptr);
		}
	}

}
#pragma once

#include "task_checker.h"
#include "dbDriver.h"
#include "action_system.h"

#define task_sys (*gg::task_system::_Instance)

namespace gg
{
	struct TaskConfig
	{
		TaskConfig(const Json::Value& info);

		int _id;
		int _follow_id;
		int _prev_id;
		int _open_lv;
		Task::CheckPtr _check_ptr;
		ActionBoxList _reward;
	};

	BOOSTSHAREPTR(TaskConfig, TaskConfigPtr);
	UNORDERMAP(int, TaskConfigPtr, TaskConfigMap);

	struct TaskLine
	{
		TaskLine(const Json::Value& info);

		int _id;
		int _open_lv;
	};

	BOOSTSHAREPTR(TaskLine, TaskLinePtr);
	STDVECTOR(TaskLinePtr, TaskLineVec);

	class task_system
	{
		public:
			static task_system* const _Instance;

			task_system();
			void initData();

			unsigned getVersionId() const
			{
				return _version_id;
			}

			DeclareRegFunction(playerInfoReq);
			DeclareRegFunction(getRewardReq);
			DeclareRegFunction(redPointReq);

			TaskConfigPtr getMainTask(int id);
			TaskConfigPtr getBranchTask(int id);

			void openStartTask(playerDataPtr d);
			void checkUnopenedTask(playerDataPtr d);
			void update(playerDataPtr d, int type, int arg1 = -1, int arg2 = -1);

			Json::Value& param() { return _param; }

		private:
			void loadFile();
			void checkAndUpdateVersion(const std::string& config_str);

		private:
			unsigned _version_id;

			TaskConfigMap _main_task_map;
			TaskConfigMap _branch_task_map;

			STDVECTOR(int, TaskIdList);
			TaskIdList _main_start_tasks;
			TaskIdList _branch_start_tasks;

			Json::Value _param;
	};
}

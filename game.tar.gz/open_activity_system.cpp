#include "open_activity_system.h"
#include "game_time.h"

namespace gg
{
	enum
	{
		OpenActivityKeyID = 10086,
	};

	open_activity_system* const open_activity_system::_Instance = new open_activity_system;

	open_activity_system::open_activity_system()
		: _version_id(10)
	{
	}

	void open_activity_system::initData()
	{
		loadFile();
	}

	void open_activity_system::activityInfoReq(net::Msg& m, Json::Value& r)
	{
		playerDataPtr d = player_mgr.getPlayer(m.playerID);
		if (!d) Return(r, err_illedge);

		r[strMsg][1u]["kid"] = d->OpenActivity().getKeyID();
		r[strMsg][1u]["ot"] = d->OpenActivity().openTime();
		Return(r, res_sucess);
	}
		
	void open_activity_system::playerInfoReq(net::Msg& m, Json::Value& r)
	{
		playerDataPtr d = player_mgr.getPlayer(m.playerID);
		if (!d || d->OpenActivity().getKeyID() == -1)
			Return(r, err_illedge);

		d->OpenActivity().update();
	}

	void open_activity_system::getRewardReq(net::Msg& m, Json::Value& r)
	{
		playerDataPtr d = player_mgr.getPlayer(m.playerID);
		if (!d || d->OpenActivity().getKeyID() == -1)
			Return(r, err_illedge);
		
		ReadJsonArray;
		int type = js_msg[0u].asInt();
		int id = js_msg[1u].asInt();

		int res;

		if (type == 0)
			res = d->OpenActivity().getTaskReward(id, r);
		else
			res = d->OpenActivity().getCountReward(id, r);
			
		Return(r, res);
	}

	void open_activity_system::redPointReq(net::Msg& m, Json::Value& r)
	{
		playerDataPtr d = player_mgr.getPlayer(m.playerID);
		if (!d || d->OpenActivity().getKeyID() == -1)
			Return(r, err_illedge);
		
		d->OpenActivity().updateRedPoint(false);
	}
	
	void open_activity_system::update(playerDataPtr d, int type, int arg1, int arg2)
	{
		if (d->OpenActivity().getKeyID() == -1)
			return;
		d->OpenActivity().update(type, arg1, arg2);
	}

	void open_activity_system::loadFile()
	{
		Json::Value info = Common::loadJsonFile("./instance/days_activity/config.json");
		Json::Value& al = info["al"];
		_name = info["kna"].asString();
		_task_lists.assign(al.size(), DayTaskList());
		int task_count = 0;
		for (unsigned i = 0; i < al.size(); ++i)
		{
			Json::Value& type2task = al[i];
			for(unsigned j = 0; j < type2task.size(); ++j)
			{
				Json::Value& task = type2task[j]["tl"];
				for (unsigned k = 0; k < task.size(); ++k)
				{
					DayTaskPtr ptr = Creator<DayTask>::Create(task[k]);
					_task_map[ptr->_id] = ptr;
					_task_lists[i].push_back(ptr);
					++task_count;
				}
			}
		}
		Json::Value& tl = info["tl"];
		for (unsigned i = 0; i < tl.size(); ++i)
			_targets.push_back(Creator<DayTarget>::Create(tl[i]));
		Json::Value& ar = info["ar"];
		Json::Value tmp;
		tmp["cn"] = task_count;
		tmp["rw"] = ar["ty"].asInt() == 2? ar["rw"] : Json::arrayValue;
		_targets.push_back(Creator<DayTarget>::Create(tmp));
		_task_day = info["day1"].asInt();
		_reward_day = info["day2"].asInt();

		std::string config_str = info.toIndentString();

		mongo::BSONObj key = BSON("key" << "open_activity");
		mongo::BSONObj obj = db_mgr.FindOne(DBN::dbConfigBackup, key);
		if (obj.isEmpty())
		{
			++_version_id;
			db_mgr.SaveMongo(DBN::dbConfigBackup, key
				, BSON("key" << "open_activity" << "version_id" << _version_id << "value" << config_str));	
			return;
		}

		_version_id = obj["version_id"].Int();

		if (obj["value"].String() != config_str)
		{
			++_version_id;
			db_mgr.SaveMongo(DBN::dbConfigBackup, key
				, BSON("key" << "open_activity" << "version_id" << _version_id << "value" << config_str));	
		}
	}
}

#include "game_time.h"

namespace gg
{
	season* const season::_Instance = new season();

	void season::serverInfoReq(net::Msg& m, Json::Value& r)
	{
		r = serverPackage();
	}

	void season::sendServerInfo(playerDataPtr player)
	{
		if (!player)return;
		Json::Value r = serverPackage();
		player->sendToClient(gate_client::server_info_resp, r);
	}

	Json::Value season::serverPackage()
	{
		Json::Value updateJson;
		updateJson[strMsg][0u] = 0;
		updateJson[strMsg][1u] = serverOpenTime;
		updateJson[strMsg][2u] = Common::timeZone();
		updateJson[strMsg][3u] = Common::gameTime();
		updateJson[strMsg][4u] = getSeason();
		updateJson[strMsg][5u] = Common::serverUrl();
		return updateJson;
	}

	void season::initData()
	{
		mongo::BSONObj key = BSON("key" << "season");
		mongo::BSONObj obj = db_mgr.FindOne(DBN::dbSeason, key);
		if (obj.isEmpty()){
			serverOpenTime = Common::getLastTime(5);
			mongo::BSONObj obj = BSON("key" << "season" << "open" << serverOpenTime);
			db_mgr.SaveMongo(DBN::dbSeason, key, obj);
			return;
		}
		serverOpenTime = (unsigned)obj["open"].Int();
	}

	SEASON::Quarter season::getSeason()
	{
		unsigned now = Common::gameTime();
		return getSeason(now);
	}

	SEASON::Quarter season::getSeason(const unsigned stamp)
	{
		return SEASON::Quarter( (stamp - serverOpenTime) / 86400 % 4 );
	}

	//��ȡ��ǰ���ڵĿ�ʼʱ��
	unsigned season::getTSTime()
	{
		unsigned now = Common::gameTime();
		unsigned tar = Common::timeZero(now) + 5 * HOUR;
		while (tar > now)
		{
			tar -= DAY;
		}
		return tar;
	}

	//��ȡ�������һ�����ڵ�ʱ���
	unsigned season::getNSTime(SEASON::Quarter q)
	{
		unsigned now = getTSTime();
		SEASON::Quarter cur = getSeason(now);
		int limit = int(cur - q);
		limit = limit == 0 ? 4 : limit;
		unsigned tar = now + limit * DAY;
		while (tar <= now)
		{
			tar += 4 * DAY;
		}
		return tar;
	}

	unsigned season::getNrAndNSTime(SEASON::Quarter q)
	{
		unsigned now = getTSTime();
		SEASON::Quarter cur = getSeason(now);
		int limit = int(cur - q);
		limit = limit == 0 ? 4 : limit;
		unsigned tar = now + limit * DAY;
		while (tar < now)
		{
			tar += 4 * DAY;
		}
		return tar;
	}

	//��ȡ�������һ�����ڵ�ʱ���
	unsigned season::getLSTime(SEASON::Quarter q)
	{
		unsigned now = getTSTime();
		SEASON::Quarter cur = getSeason(now);
		int limit = int(cur - q);
		limit = limit == 0 ? 4 : limit;
		unsigned tar = now + limit * DAY;
		while (tar >= now)
		{
			tar -= 4 * DAY;
		}
		return tar;
	}

	unsigned season::getNrAndLSTime(SEASON::Quarter q)
	{
		unsigned now = getTSTime();
		SEASON::Quarter cur = getSeason(now);
		int limit = int(cur - q);
		limit = limit == 0 ? 4 : limit;
		unsigned tar = now + limit * DAY;
		while (tar > now)
		{
			tar -= 4 * DAY;
		}
		return tar;
	}

	unsigned season::getNSTimeHMS(SEASON::Quarter q, int hour, int min, int sec)
	{
		unsigned now = Common::gameTime();
		return getNSTimeHMS(now, q, hour, min, sec);
	}

	unsigned season::getNSTimeHMS(unsigned now, SEASON::Quarter quarter, int hour, int min, int sec)
	{
		unsigned next = Common::getNextTimeHMS(now, hour, min, sec);
		int next_quarter = getSeason(next);
		if (next_quarter == quarter)
			return next;
		else if (next_quarter > quarter)
			return next + (quarter + 4 - next_quarter) * DAY;
		else
			return next + (quarter - next_quarter) * DAY;
	}

}

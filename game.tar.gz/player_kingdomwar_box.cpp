#include "player_kingdomwar_box.h"
#include "kingdomwar_data.h"
#include "playerManager.h"

namespace gg
{
	namespace KingdomWar
	{
		enum
		{
			InitGreatEventBoxNum = 10,
		};

		struct BoxData
		{	
			BoxData(const Json::Value& info)
			{
				_target = info["target"].asInt();
				Json::Value box = info["reward"];
				_box = actionFormatBox(box);
			}

			int _target;
			ACTION::BoxList _box;
		};

		BOOSTSHAREPTR(BoxData, BoxDataPtr);
		STDVECTOR(BoxDataPtr, BoxDataMap);

		static BoxDataPtr getBoxData(int id)
		{
			static BoxDataMap box_map;
			if (box_map.empty())
			{
				Json::Value json = Common::loadJsonFile("./instance/kingdom_war/box_reward.json");
				ForEach(Json::Value, it, json)
					box_map.push_back(Creator<BoxData>::Create(*it));
				if (box_map.empty())
					LogE << "kingdom war box_reward.json error" << LogEnd;
			}
			if (id < 0 || id >= box_map.size())
			{
				LogE << "kingdom war box data index out of range: " << id << LogEnd;
				return BoxDataPtr();
			}
			return box_map[id];
		}
	}

	playerKingdomWarBox::playerKingdomWarBox(playerData* const own)
		: _auto_player(own), _max_box_time(0)
	{
		_box_state.assign(5, 0);
		_rp_state = -1;
		_ge_rp_state = -1;
	}

	void playerKingdomWarBox::classLoad()
	{
		mongo::BSONObj key = BSON(strPlayerID << Own().ID());
		mongo::BSONObj obj = db_mgr.FindOne(DBN::dbPlayerKingdomWarBox, key);
		
		if (obj.isEmpty()) 
			return;

		{
			std::vector<mongo::BSONElement> ele = obj["bx"].Array();
			for (unsigned i = 0; i < ele.size(); ++i)
				_box_state[i] = ele[i].Int();
		}

		checkNotEoo(obj["mbt"])
			_max_box_time = obj["mbt"].Int();

		checkNotEoo(obj["bn"])
		{
			std::vector<mongo::BSONElement> ele = obj["bn"].Array();
			for (unsigned i = 0; i < ele.size(); ++i)
				_box_num.insert(make_pair(ele[i]["t"].Int(), ele[i]["n"].Int()));
		}
		checkNotEoo(obj["gbn"])
			_gold_box_num = obj["gbn"].Int();
		checkNotEoo(obj["sbn"])
			_silver_box_num = obj["sbn"].Int();
		checkNotEoo(obj["hbn"])
			_home_box_num = obj["hbn"].Int();
	}

	bool playerKingdomWarBox::_auto_save()
	{
		mongo::BSONObj key = BSON(strPlayerID << Own().ID());
		mongo::BSONObjBuilder obj;
		obj << strPlayerID << Own().ID();
		{
			mongo::BSONArrayBuilder b;
			for (unsigned i = 0; i < 5; ++i)
				b.append(_box_state[i]);
			obj << "bx" << b.arr();
		}
		{
			mongo::BSONArrayBuilder b;
			ForEachC(GreatEventBoxNum, it, _box_num)
				b.append(BSON("t" << it->first << "n" << it->second));
			obj << "bn" << b.arr();
		}
		obj << "mbt" << _max_box_time << "gbn" << _gold_box_num << "sbn" << _silver_box_num 
			<< "hbn" << _home_box_num;
		return db_mgr.SaveMongo(DBN::dbPlayerKingdomWarBox, key, obj.obj());
	}

	void playerKingdomWarBox::initGreatEventBox()
	{
		KingdomWar::GreatEventMgr::shared().newerGreatEvent(_max_box_time);
		_sign_save();
	}

	unsigned playerKingdomWarBox::numBox(unsigned idx)
	{
		unsigned time = KingdomWar::GreatEventMgr::shared().time(idx);
		KingdomWar::GreatEventList e = KingdomWar::GreatEventMgr::shared().newerGreatEvent(_max_box_time);
		if (!e.empty())
		{
			ForEachC(KingdomWar::GreatEventList, it, e)
				_box_num.insert(make_pair((*it)->time(), (unsigned)KingdomWar::InitGreatEventBoxNum));
			_sign_save();
		}
		
		GreatEventBoxNum::iterator it = _box_num.find(time);
		return it == _box_num.end()? 0 : it->second;
	}

	void playerKingdomWarBox::_auto_update()
	{
		update();
	}

	void playerKingdomWarBox::update()
	{
		qValue m;
		m.append(res_sucess);
		qValue q;
		ForEachC(std::vector<int>, it, _box_state)
			q.append(*it);
		m.append(q);
		Own().sendToClientFillMsg(gate_client::kingdom_war_box_reward_resp, m);
	}

	void playerKingdomWarBox::clear()
	{
		_box_state.clear();
		_box_state.assign(5, 0);
		_rp_state = -1;
		resetRpStateAndUpdate();
		_sign_save();
	}

	int playerKingdomWarBox::rpState()
	{
		if (_rp_state == -1)
			resetRpState();
		return _rp_state == 2? 0 : _rp_state;
	}

	void playerKingdomWarBox::resetRpStateAndUpdate()
	{
		if (_rp_state == 2)
			return;
		int tmp = _rp_state;
		resetRpState();
		if (tmp != _rp_state)
			Own().KingDomWar().updateRedPoint();
	}

	void playerKingdomWarBox::resetRpState()
	{
		for (int id = 0; id < 5; ++id)
		{
			if (_box_state[id] == 1)
				continue;
			KingdomWar::BoxDataPtr ptr = KingdomWar::getBoxData(id);
			if (!ptr)
			{
				_rp_state = 0;
				return;
			}
			if (Own().KingDomWar().getExploit() >= ptr->_target)
			{
				_rp_state = 1;
				return;
			}
			else
			{
				_rp_state = 0;
				return;
			}
		}
		_rp_state = 2;
	}

	int playerKingdomWarBox::getReward(int id, Json::Value& r)
	{
		KingdomWar::BoxDataPtr ptr = KingdomWar::getBoxData(id);
		if (!ptr)
			return err_illedge;

		if (Own().KingDomWar().getExploit() < ptr->_target
			|| _box_state[id] != 0)
			return err_illedge;

		int res = actionDoBox(Own().getOwnDataPtr(), ptr->_box, false);
		if (res == res_sucess)
		{
			r = actionRes();
			_box_state[id] = 1;
			resetRpStateAndUpdate();
			_sign_auto();
		}
		else
		{
			Json::Value error_code = actionError();
			res = error_code[0u][1u].asInt();
		}

		return res_sucess;
	}
	
	int playerKingdomWarBox::getGreatEventReward(int idx, Json::Value& r)
	{
		unsigned time = KingdomWar::GreatEventMgr::shared().time(idx);
		if (numBox(idx) == 0)
			return err_illedge;

		const acPtrList& rw = KingdomWar::GreatEventMgr::shared().getReward(idx, Own().Info().Nation());
		int res = actionDo(Own().getOwnDataPtr(), rw, 1, false);
		if (res == res_sucess)
		{
			GreatEventBoxNum::iterator it = _box_num.find(time);
			--it->second;
			r[strMsg][1u] = actionRes();
			Log(DBLOG::strLogKingdomWar, Own().getOwnDataPtr(), 12, "", "", "", "", "", "", "", r[strMsg][1u].toIndentString());
			resetGreatEventRPAndUpdate();
			_sign_save();
		}
		else
		{
			Json::Value error_code = actionError();
			res = error_code[0u][1u].asInt();
		}
		return res;
	}

	int playerKingdomWarBox::greatEventRP()
	{
		//if (_ge_rp_state == -1)
		_ge_rp_state = resetGreatEventRP();
		return _ge_rp_state;
	}

	int playerKingdomWarBox::resetGreatEventRP()
	{
		numBox(1);
		ForEachC(GreatEventBoxNum, it, _box_num)
		{
			if (it->second > 0)
				return 1;
		}
		return 0;
	}

	void playerKingdomWarBox::resetGreatEventRPAndUpdate()
	{
		int tmp = _ge_rp_state;
		_ge_rp_state = resetGreatEventRP();
		if (tmp != _ge_rp_state)
			Own().KingDomWar().updateRedPoint();
	}

	void playerKingdomWarBox::numBoxInfo(qValue& q)
	{
		numBox(1);	
		for (GreatEventBoxNum::const_reverse_iterator it = _box_num.rbegin();
			it != _box_num.rend(); ++it)
			q.append(it->second);
	}

	int playerKingdomWarBox::goldBoxLimit()
	{
		int limit = KingdomWar::BoxLimit::shared().goldBoxTimes(Own().LV());
		return _gold_box_num > limit? 0 : limit - _gold_box_num;
	}

	int playerKingdomWarBox::silverBoxLimit()
	{
		int limit = KingdomWar::BoxLimit::shared().silverBoxTimes(Own().LV());
		return _silver_box_num > limit? 0 : limit - _silver_box_num;
	}

	int playerKingdomWarBox::homeBoxLimit()
	{
		int limit = KingdomWar::BoxLimit::shared().homeBoxTimes(Own().LV());
		return _home_box_num > limit? 0 : limit - _home_box_num;
	}

	void playerKingdomWarBox::alterGoldBoxNum(int num)
	{
		_gold_box_num += num;
		_sign_save();
	}

	void playerKingdomWarBox::alterSilverBoxNum(int num)
	{
		_silver_box_num += num;
		_sign_save();
	}

	void playerKingdomWarBox::alterHomeBoxNum(int num)
	{
		_home_box_num += num;
		_sign_save();
	}

	void playerKingdomWarBox::dailyTick()
	{
		_gold_box_num = 0;
		_silver_box_num = 0;
		_home_box_num = 0;
		_sign_save();
	}
}

#include "player_kingdomwar_output.h"
#include "kingdomwar_system.h"

namespace gg
{
	playerKingdomWarOutput::playerKingdomWarOutput(playerData* const own)
		: _auto_player(own), _next_output_time(0)
	{
	}

	void playerKingdomWarOutput::classLoad()
	{
		mongo::BSONObj key = BSON(strPlayerID << Own().ID());
		mongo::BSONObj obj = db_mgr.FindOne(DBN::dbPlayerKingdomWarOutput, key);
		
		if (obj.isEmpty()) 
			return;

		checkNotEoo(obj["o"])
		{
			std::vector<mongo::BSONElement> ele = obj["o"].Array();
			for (unsigned i = 0; i < ele.size(); ++i)
				_output.push_back(ele[i].Int());
		}
		checkNotEoo(obj["t"])
			_next_output_time = obj["t"].Int();
	}

	bool playerKingdomWarOutput::_auto_save()
	{
		mongo::BSONObj key = BSON(strPlayerID << Own().ID());
		mongo::BSONObjBuilder obj;
		obj << strPlayerID << Own().ID() << "t" << _next_output_time;
		{
			mongo::BSONArrayBuilder b;
			ForEachC(Output, it, _output)
				b.append(*it);
			obj << "o" << b.arr();
		}
		return db_mgr.SaveMongo(DBN::dbPlayerKingdomWarOutput, key, obj.obj());
	}

	void playerKingdomWarOutput::_auto_update()
	{
		update();
	}

	void playerKingdomWarOutput::init()
	{
		if (_next_output_time == 0)
			_next_output_time = KingdomWar::State::shared().next5MinTime();

		while (_output.size() < kingdomwar_sys.citySize())
		{
			KingdomWar::CityPtr ptr = kingdomwar_sys.getCity(_output.size());
			_output.push_back(ptr->getOutput(Own().Info().Nation()));
			_sign_save();
		}
	}

	void playerKingdomWarOutput::update()
	{
		init();

		qValue m;
		m.append(res_sucess);
		qValue q(qJson::qj_object);
		q.addMember("t", KingdomWar::State::shared().next5MinTime());
		if (!outputEmpty())
		{
			qValue tmp;
			for (unsigned i = 0; i < _output.size(); ++i)
				tmp.append(kingdomwar_sys.getCity(i)->getOutput(Own().Info().Nation()) > _output[i]? 1 : 0);
			q.addMember("l", tmp);
		}
		m.append(q);
		Own().sendToClientFillMsg(gate_client::kingdom_war_output_info_resp, m);
	}

	inline bool playerKingdomWarOutput::outputEmpty() const
	{
		return _next_output_time >= KingdomWar::State::shared().next5MinTime();
	}

	int playerKingdomWarOutput::getOutput(int id, Json::Value& r)
	{
		if (outputEmpty())
			return err_illedge;
		
		r.append(id);
		Json::Value o;
		if (id >= 0)
			o.append(doGetOutput(id));
		else
		{
			for (unsigned i = 0; i < _output.size(); ++i)
				o.append(doGetOutput(i));
			_next_output_time = KingdomWar::State::shared().next5MinTime();
		}
		r.append(o);
		_sign_auto();
		return res_sucess;
	}

	int playerKingdomWarOutput::doGetOutput(int id)
	{
		KingdomWar::CityPtr ptr = kingdomwar_sys.getCity(id);
		if (!ptr) 
			return 0;
		if (id >= _output.size())
			return 0;

		int val = ptr->getOutput(Own().Info().Nation()) - _output[id];
		if (val <= 0)
			return 0;
		if (val >= ptr->maxOutput())
			val = ptr->maxOutput();

		val = doGetOutput(ptr->outputType(), val);
		_output[id] = ptr->getOutput(Own().Info().Nation());
		return val;
	}

	int playerKingdomWarOutput::doGetOutput(int type, int val)
	{
		switch(type)
		{
			case 0:
				return Own().Res().alterCash(val);
			case 1:
				return Own().Res().alterSilver(val);
			case 2:
				return Own().Res().alterFame(val);
			case 3:
				return Own().Res().alterMerit(val);
			default:
				return 0;
		}
	}
}

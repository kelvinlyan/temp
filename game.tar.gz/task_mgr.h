#pragma once

#include "auto_base.h"
#include "task_def.h"

namespace gg
{
	class TaskMgr
	{
		public:
			static void update(playerDataPtr d, int type, int arg1 = -1, int arg2 = -1);
	};
}

#include "broadcast_check.h"
#include "channel.h"

namespace gg
{
	void actionResCheck::CheckItemMatch(playerDataPtr player, const Json::Value& json)
	{
		const int itemID = json[1u].asInt();
		CHECKMAP::const_iterator it = itemCheck.find(itemID);
		if (it == itemCheck.end())return;
		onItemBroadcast(player, it->second, json);
	}
	void actionResCheck::CheckManMatch(playerDataPtr player, const Json::Value& json)
	{
		const int manID = json[1u].asInt();
		CHECKMAP::const_iterator it = manCheck.find(manID);
		if (it == manCheck.end())return;
		onManBroadcast(player, it->second, json);
	}
	void actionResCheck::CheckLadyMatch(playerDataPtr player, const Json::Value& json)
	{
		const int ladyID = json[1u].asInt();
		CHECKMAP::const_iterator it = ladyCheck.find(ladyID);
		if (it == ladyCheck.end())return;
		onLadyBroadcast(player, it->second, json);
	}

	actionResCheck::actionResCheck()
	{
		beenInitial = false;
	}

	void actionResCheck::initialCheck(const string& file_name)
	{
		if (beenInitial)return;
		cout << "initial broadcast checking system ...." << file_name << endl;
		Json::Value idx_json = Common::loadJsonFile("./instance/broadcast_idx/" + file_name);
		const int item_idx = idx_json["item"].asInt();
		if (item_idx > 0)
		{
			Json::Value json = Common::loadJsonFile("./instance/broadcast/" + Common::toString(item_idx) + ".json");
			for (unsigned i = 0; i < json.size(); ++i)
			{
				Json::Value& sg_json = json[i];
				const unsigned channel_id = sg_json[1u].asUInt();
				if (channel_id >= CHAT::user_channel)continue;
				itemCheck[sg_json[0u].asInt()] = channel_id;
			}
		}
		const int man_idx = idx_json["man"].asInt();
		if (man_idx > 0)
		{
			Json::Value json = Common::loadJsonFile("./instance/broadcast/" + Common::toString(man_idx) + ".json");
			for (unsigned i = 0; i < json.size(); ++i)
			{
				Json::Value& sg_json = json[i];
				const unsigned channel_id = sg_json[1u].asUInt();
				if (channel_id >= CHAT::user_channel)continue;
				manCheck[sg_json[0u].asInt()] = channel_id;
			}
		}
		const int lady_idx = idx_json["lady"].asInt();
		if (lady_idx > 0)
		{
			Json::Value json = Common::loadJsonFile("./instance/broadcast/" + Common::toString(lady_idx) + ".json");
			for (unsigned i = 0; i < json.size(); ++i)
			{
				Json::Value& sg_json = json[i];
				const unsigned channel_id = sg_json[1u].asUInt();
				if (channel_id >= CHAT::user_channel)continue;
				ladyCheck[sg_json[0u].asInt()] = channel_id;
			}
		};

		FuncMap[ACTION::item] = boostBind(actionResCheck::CheckItemMatch, this, _1, _2);
		FuncMap[ACTION::man] = boostBind(actionResCheck::CheckManMatch, this, _1, _2);
		FuncMap[ACTION::lady] = boostBind(actionResCheck::CheckLadyMatch, this, _1, _2);
		beenInitial = true;
	}

	void actionResCheck::beginCheck(playerDataPtr player, const Json::Value& check_json)
	{
		for (unsigned i = 0; i < check_json.size(); ++i)
		{
			try
			{
				const Json::Value& sg_json = check_json[i];
				const int actionID = sg_json[0u].asInt();
				CheckFuncMap::iterator it = FuncMap.find(actionID);
				if (it == FuncMap.end())continue;
				it->second(player, sg_json);
			}
			catch (std::exception& e)
			{
				cout << e.what() << endl;
			}
		}
	}
}
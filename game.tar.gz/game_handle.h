#pragma once

#include "local_tcp.h"
#include <json/json.h>
#include <boost/function.hpp>
#include <boost/unordered_map.hpp>
#include "gate_game_protocol.h"

namespace gg
{
	class helper;
	class handler
	{		
	public:
		typedef boost::function< void (net::Msg&, Json::Value&) >	handler_function;	
		typedef	boost::shared_ptr<gg::handler>	pointer;
		struct CallFunction{
			CallFunction();
			handler_function f_;
			short resp_;
		};
		typedef std::map< short, CallFunction >	function_keeper;

		handler();
		~handler();

		void recv_client_handler(net::linkLocalPtr session, net::Msg& m);
		void recv_local_handler(net::linkLocalPtr session, net::Msg& m);
		void logShowState(const bool state);
	protected:
		void Regist();
		void reg_func(const short command_id, const short response_id, handler_function func);
		void despatch(net::Msg& m);
		function_keeper func_keeper;
	};
}


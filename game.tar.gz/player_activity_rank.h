//###################################
//create by Jim
//2016-11-29
//###################################
#pragma once

#include "auto_do.h"
#include "activity_rank_def.h"

namespace gg
{

	class playerActivityRank :
		public _auto_player
	{
	public:
		playerActivityRank(playerData* const own);
		~playerActivityRank() {}
		int get_value(const int type);
		void update_all();
		void check_process();
		void add_process(const int type, const int value);
		void set_process(const int type, const int value);
		void over_box_type(const int type);
		int get_reach_box(const int type, const int reach);
		void send_type_data(const int type);
	private:
		void over_box();
		virtual void classLoad();
		virtual void classFinal();
		virtual void _auto_update();
		virtual bool _auto_save();
		struct Data
		{
			Data()
			{
				reset();
				_is_dirty = false;
			}
			void reset()
			{
				_create = 0;
				_value = 0;
				_box.clear();
				_been_clean = false;
				_is_dirty = true;
			}
			unsigned _create;
			int _value;
			UNORDERSET(int, _box_filter_type);
			_box_filter_type _box;
			bool _been_clean;
			bool _is_dirty;
		};
		Data _data_list[ActivityRankEnum::activity_rank_num];
	};
}

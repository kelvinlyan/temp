#include "player_research.h"
#include "ownerland_system.h"
#include "task_mgr.h"

namespace gg
{

	using namespace RESEARCH;

	playerResearch::playerResearch(playerData* const own) 
		: _auto_player(own)
	{
		memset(warAttri, 0x0, sizeof(warAttri));//���Գ�ʼ��
		memset(homeAttr, 0x0, sizeof(homeAttr));//�������Գ�ʼ��
	}

	void playerResearch::getForAttr(const int iID, int* attri)
	{
		const unsigned iLV = getForLV(iID);
		militaryTechPtr militaryTechPtr_ptr = ownerland_sys.getMilitaryTechData(iID, iLV);
		if (!militaryTechPtr_ptr)return;
		const vector<AttriBase>& attriList = militaryTechPtr_ptr->warAttri;
		for (unsigned i = 0; i < attriList.size(); ++i)
		{
			const AttriBase& base = attriList[i];
			attri[base.idx] += base.val;
		}
	}

	const unsigned playerResearch::getForLV(const int iID)
	{
		MilitaryTechMap::iterator itr = militaryTechList.find(iID);
		if (itr == militaryTechList.end())return 0;
		return itr->second;
	}

	void playerResearch::classLoad()
	{
		militaryTechList.clear();

		mongo::BSONObj keyFind = BSON(strPlayerID << Own().ID());
		mongo::BSONObj objFind = db_mgr.FindOne(DBN::dbPlayerResearch, keyFind);
		if (objFind.isEmpty())return;

		vector<mongo::BSONElement> vec = objFind["rech"].Array();
		for (unsigned i = 0; i < vec.size(); i++)
		{
			mongo::BSONElement& elem = vec[i];
			int	iID = elem["id"].Int();
			unsigned	iLv = elem["lv"].Int();
			militaryTechList[iID] = iLv;
			militaryTechPtr militaryTechPtr_ptr = ownerland_sys.getMilitaryTechData(iID, iLv);
			if (!militaryTechPtr_ptr) { continue; }
			if (militaryTechPtr_ptr->eType != LAND::idx_tech_type_formation)
			{
				{//�佫ͨ������
					const vector<AttriBase>& attriList = militaryTechPtr_ptr->warAttri;
					for (unsigned i = 0; i < attriList.size(); ++i)
					{
						const AttriBase& base = attriList[i];
						warAttri[base.idx] += base.val;
					}
				};
				{//��������
					const vector<militaryAdd>& attriList = militaryTechPtr_ptr->homeAttri;
					for (unsigned n = 0; n < attriList.size(); ++n)
					{
						const militaryAdd& base = attriList[n];
						homeAttr[base.idx] += base.val;
					}
				};
			}
		}
	}

	bool playerResearch::_auto_save()
	{
		mongo::BSONObj key = BSON(strPlayerID << Own().ID());
		mongo::BSONArrayBuilder militarTechysarray;
		for (MilitaryTechMap::iterator itr = militaryTechList.begin(); itr != militaryTechList.end(); ++itr)
		{
			militarTechysarray.append(
				BSON("id" << itr->first <<
				"lv" << itr->second)
				);
		}
		mongo::BSONObj obj = BSON(strPlayerID << Own().ID() <<
			"rech" << militarTechysarray.arr());

		return db_mgr.SaveMongo(DBN::dbPlayerResearch, key, obj);
	}

	void playerResearch::_auto_update()
	{
		sendResearch();
	}

	int playerResearch::getResearchData(const LAND::HomeType eHomeType)
	{
		if (eHomeType < LAND::idx_home_type_begin || eHomeType > LAND::idx_home_type_end)return 0;
		return homeAttr[eHomeType];
	}

	int playerResearch::researchUpgrade(const int iID, unsigned& iTimes)
	{
		const unsigned uTimes = iTimes;
		iTimes = 0;
		if (uTimes < 1 || uTimes > 10)return err_illedge;
		if (!Own().Builds().isBuildValid(LAND::idx_building_type_military)) { return err_illedge; }//������û�п���

		//�ж�����
		const unsigned cLv = getForLV(iID);//��ǰ�ȼ�
		const unsigned playerLV = Own().LV();
		if(cLv >= playerLV)return err_tech_lv_over;
		const unsigned iLv = std::min(cLv + uTimes, playerLV);//׼�������ĵȼ�
		militaryTechPtr militaryTechPtr_ptr = ownerland_sys.getMilitaryTechData(iID, cLv + 1);//Ŀ��ȼ������ļ�
		LAND::resMap buildUpgradeMAP;//���ĵ���Դ
		for (unsigned begin_lv = cLv + 1; begin_lv <= iLv; begin_lv++)
		{
			militaryTechPtr cur_militaryTechPtr_ptr = ownerland_sys.getMilitaryTechData(iID, begin_lv);
			if (!cur_militaryTechPtr_ptr)break;
			if (cur_militaryTechPtr_ptr->iOpenLv > 0 && cur_militaryTechPtr_ptr->iOpenLv > playerLV)break;
			if (cur_militaryTechPtr_ptr->iPreLv > getForLV(cur_militaryTechPtr_ptr->iPreID))break;
			LAND::resMap curRes = buildUpgradeMAP;
			for (LAND::resMap::iterator it = cur_militaryTechPtr_ptr->buildUpgradeMAP.begin(); 
				it != cur_militaryTechPtr_ptr->buildUpgradeMAP.end(); ++it)
			{
				curRes[it->first] += it->second;
			}
			const int result = ownerland_sys.checkResource(Own().getOwnDataPtr(), curRes);//��Դ����
			if (result != res_sucess)break;
			//ȫ��У��ͨ��
			militaryTechPtr_ptr = cur_militaryTechPtr_ptr;
			buildUpgradeMAP = curRes;//���ĸ�ֵ
			++iTimes;//�ɹ�����+1
		}
		if (iTimes < 1)
		{
			if (!militaryTechPtr_ptr) { return err_military_tech_max; }//�����Ƽ�
			if (militaryTechPtr_ptr->iOpenLv > 0 && militaryTechPtr_ptr->iOpenLv > playerLV) { return err_tech_lv_not_enough; }//��ҵȼ�����
			if (militaryTechPtr_ptr->iPreLv > getForLV(militaryTechPtr_ptr->iPreID)) { return err_pre_tech_lv; }//ǰ�õȼ�����
		}
		//�۳���Դ
		ownerland_sys.alterResource(Own().getOwnDataPtr(), buildUpgradeMAP, false);


		bool home_alter = false;
		//���پɿƼ�����
		const militaryTechPtr old_militaryTechPtr_ptr = ownerland_sys.getMilitaryTechData(iID, cLv);
		if (old_militaryTechPtr_ptr && old_militaryTechPtr_ptr->eType != LAND::idx_tech_type_formation)
		{
			{//�ɿƼ� �佫����
				const vector<AttriBase>& attriList = old_militaryTechPtr_ptr->warAttri;
				for (unsigned n = 0; n < attriList.size(); ++n)
				{
					const AttriBase& base = attriList[n];
					warAttri[base.idx] -= base.val;
				}
			};
			{//�ɿƼ� ��������
				const vector<militaryAdd>& attriList = old_militaryTechPtr_ptr->homeAttri;
				for (unsigned n = 0; n < attriList.size(); ++n)
				{
					const militaryAdd& base = attriList[n];
					homeAttr[base.idx] -= base.val;
					home_alter = true;
				}
			};
		}

		if (militaryTechPtr_ptr->eType != LAND::idx_tech_type_formation)
		{//��ǰ�Ƽ�����
			{//�佫����
				const vector<AttriBase>& attriList = militaryTechPtr_ptr->warAttri;
				for (unsigned n = 0; n < attriList.size(); ++n)
				{
					const AttriBase& base = attriList[n];
					warAttri[base.idx] += base.val;
				}
			};
			{//��������
				const vector<militaryAdd>& attriList = militaryTechPtr_ptr->homeAttri;
				for (unsigned n = 0; n < attriList.size(); ++n)
				{
					const militaryAdd& base = attriList[n];
					homeAttr[base.idx] += base.val;
					home_alter = true;
				}
			};
		}

		//�����µĵȼ�
		militaryTechList[iID] = cLv + iTimes;
		updateTask(militaryTechPtr_ptr->eType, iLv);
		_sign_auto();

		if (home_alter)
		{
			Own().Builds().tickDelayUpdate();
		}
		Own().Man().recalMan();
		Log(DBLOG::strLogMilitaryUpgrade, Own().getOwnDataPtr(), -1, iID, cLv, iLv);

		return res_sucess;
	}


	void playerResearch::sendResearch()
	{
		qValue json(qJson::qj_array), data_json(qJson::qj_array);

		MilitaryTechMap tmpList;
		for (MilitaryTechMap::iterator itr = militaryTechList.begin(); itr != militaryTechList.end(); ++itr) { tmpList[itr->first] = itr->second; }

		for (ConfigMilitaryTechLVOneMap::const_iterator const_itr = ownerland_sys.mapMilitaryTechLVOne.begin(); const_itr != ownerland_sys.mapMilitaryTechLVOne.end(); ++const_itr)
		{
			if ((unsigned int)const_itr->second->iOpenLv > Own().Info().LV()) { continue; }
			if (const_itr->second->iPreID > 0)
			{
				if (militaryTechList.find(const_itr->second->iPreID) == militaryTechList.end()) { continue; }
				if (militaryTechList[const_itr->second->iPreID] < const_itr->second->iPreLv) { continue; }
			}
			if (tmpList.find(const_itr->first) != tmpList.end()) { continue; }
			tmpList[const_itr->first] = 0;
		}

		int maxTechLv = 0;
		for (MilitaryTechMap::iterator itr = tmpList.begin(); itr != tmpList.end(); ++itr)
		{
			qValue tmp(qJson::qj_array);
			tmp.append(itr->first);
			tmp.append(itr->second);
			if (itr->second > maxTechLv)
				maxTechLv = itr->second;
			data_json.append(tmp);
		}
		json.append(res_sucess).append(data_json);
		Own().sendToClientFillMsg(gate_client::building_tech_base_data_resp, json);
	}

	int playerResearch::getLvSum(int type)
	{
		int sum = 0;
		ForEachC(RESEARCH::MilitaryTechMap, it, militaryTechList)
		{
			if (type == -1)
				sum += it->second;
			else
			{
				militaryTechPtr ptr = ownerland_sys.getMilitaryTechData(it->first, it->second);
				if (ptr && ptr->eType == type)
					sum += it->second;
			}
		}
		return sum;
	}

	int playerResearch::getMaxLv(int type)
	{
		int max = 0;
		ForEachC(RESEARCH::MilitaryTechMap, it, militaryTechList)
		{
			if (type == -1)
			{
				if (max < it->second)
					max = it->second;
			}
			else
			{
				militaryTechPtr ptr = ownerland_sys.getMilitaryTechData(it->first, it->second);
				if (ptr && ptr->eType == type && max < it->second)
					max = it->second;
			}
		}
		return max;
	}

	int playerResearch::getTechNum(int type)
	{
		if (type == -1)
			return militaryTechList.size();
		else
		{
			int sum = 0;
			ForEach(RESEARCH::MilitaryTechMap, it, militaryTechList)
			{
				const militaryTechPtr ptr = ownerland_sys.getMilitaryTechData(it->first, it->second);
				if (ptr && ptr->eType == type)
					++sum;
			}
			return sum;
		}
	}
	
	void playerResearch::updateTask(int type, int lv)
	{
		TaskMgr::update(Own().getOwnDataPtr(), Task::MilitaryTechLvSum);
		TaskMgr::update(Own().getOwnDataPtr(), Task::MilitaryTechMaxLv, lv);

		switch(type)
		{
			case LAND::idx_tech_type_war:
				TaskMgr::update(Own().getOwnDataPtr(), Task::WarTechLvSum);
				TaskMgr::update(Own().getOwnDataPtr(), Task::WarTechNum);
				break;
			case LAND::idx_tech_type_home:
				TaskMgr::update(Own().getOwnDataPtr(), Task::HomeTechLvSum);
				TaskMgr::update(Own().getOwnDataPtr(), Task::HomeTechNum);
				break;
			case LAND::idx_tech_type_formation:
				TaskMgr::update(Own().getOwnDataPtr(), Task::FormationTechLvSum);
				TaskMgr::update(Own().getOwnDataPtr(), Task::FormationTechNum);
				break;
			default:
				break;
		}
	}
}

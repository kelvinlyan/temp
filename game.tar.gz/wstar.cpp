﻿#include "wstar.h"
#include <cassert>
#include <cstring>
#include <algorithm>

WStar::~WStar()
{
	clear();
}

void WStar::clear()
{
	_openList.clear();
	_maps.clear();
}

bool WStar::isValidParam()
{
	return (publicReach &&
		publicStart != publicEnd &&
		publicReach(publicStart.x, publicStart.y) &&
		publicReach(publicEnd.x, publicEnd.y)
		);
}

inline unsigned WStar::calculGValue(Node *parent_node, const WSTAR::Pos &current_pos)
{
	unsigned g_value = (current_pos - parent_node->pos) >= 2 ? publicOblique : publicStep;
	return g_value += parent_node->g;
}

inline unsigned WStar::calculHValue(const WSTAR::Pos &current_pos, const WSTAR::Pos &end_pos)
{
	if (publicCorner)
	{
		const int x_value = std::abs(end_pos.x - current_pos.x);
		const int y_value = std::abs(end_pos.y - current_pos.y);
		const int same_length = std::min(x_value, y_value);
		const int diffrent_length = std::abs(x_value - y_value);
		return same_length * publicOblique + diffrent_length * publicStep;
	}
	unsigned h_value = end_pos - current_pos;
 	return h_value * publicStep;
}

inline bool WStar::findInOpenList(const WSTAR::Pos &pos, Node *&out)
{
	XMap& checkMap = _maps[pos.x];
	XMap::iterator it = checkMap.find(pos.y);
	if (it == checkMap.end())return false;
	if (IN_OPENLIST == it->second.state)
	{
		out = &(it->second);
		return true;
	}
	return false;
}

inline bool WStar::isInCloseList(const WSTAR::Pos &pos)
{
	XMap& checkMap = _maps[pos.x];
	XMap::iterator it = checkMap.find(pos.y);
	if (it == checkMap.end())return false;
	return it->second.state == IN_CLOSELIST;
}

void WStar::findNearlyPos(const WSTAR::Pos &current_pos, bool corner, std::vector<WSTAR::Pos> &nearly_pos)
{
	WSTAR::Pos target_pos;
	nearly_pos.clear();
	const int left_bottom_x = current_pos.x - 1 < 0 ? 0 : current_pos.x - 1;
	const int left_bottom_y = current_pos.y - 1 < 0 ? 0 : current_pos.y - 1;

	const int right_top_x = current_pos.x + 1;
	const int right_top_y = current_pos.y + 1;

	for (int x = left_bottom_x; x <= right_top_x; x++)
	{
		for (int y = left_bottom_y; y <= right_top_y; y++)
		{
			target_pos.setXY(x, y);
			if(isInCloseList(target_pos))continue;//在不考虑列表中
			if (publicReach(x, y))
			{
				const int val = target_pos - current_pos;
				if (val == 1)//正行
				{
					nearly_pos.push_back(target_pos);
				}
				else if (corner && val != 0)//斜行
				{
					if (publicReach(target_pos.x, current_pos.y) && publicReach(current_pos.x, target_pos.y))
					{
						nearly_pos.push_back(target_pos);
					}
				}
			}
		}
	}

}

void WStar::handleInOpenNode(Node *current_node, Node *target_node)
{
	unsigned int g_value = calculGValue(current_node, target_node->pos);
	if (g_value < target_node->g)
	{
		std::pair<multiList::iterator, multiList::iterator> find_range =
			_openList.equal_range(target_node);

		for (multiList::iterator iIDX = find_range.first; 
			iIDX != find_range.second; iIDX++)
		{
			if (*target_node == *(*iIDX))
			{
				_openList.erase(iIDX);
				break;
			}
		}

		target_node->g = g_value;
		target_node->parent = current_node;
		_openList.insert(target_node);//重新排序
	}
}

void WStar::handleNotInOpenNode(Node *current_node, Node *target_node, const WSTAR::Pos &end_pos)
{
	target_node->parent = current_node;
	target_node->h = calculHValue(target_node->pos, end_pos);
	target_node->g = calculGValue(current_node, target_node->pos);
	target_node->state = IN_OPENLIST;
	_openList.insert(target_node);
}

std::vector<WSTAR::Pos> WStar::find()
{
	std::vector<WSTAR::Pos> paths;
	if (!isValidParam())
	{
		return paths;
	}
	else
	{
		_maps[publicStart.x][publicStart.y] = Node(publicStart);//起点节点

		//重设周围最多可以行走的物件格
		std::vector<WSTAR::Pos> nearby_nodes;
		nearby_nodes.reserve(publicCorner ? 8 : 4);

		_openList.insert(&_maps[publicStart.x][publicStart.y]);//所有实体的节点都是从map中生成
		(*_openList.begin())->state = IN_OPENLIST;//设置到open列表

		while (!_openList.empty())
		{
			Node *current_node = *_openList.begin();
			_openList.erase(_openList.begin());
			current_node->state = IN_CLOSELIST;

			//寻找附近的节点
			findNearlyPos(current_node->pos, publicCorner, nearby_nodes);

			for (unsigned index = 0; index < nearby_nodes.size(); index++)
			{
				Node *new_node = NULL;
				const WSTAR::Pos& index_pos = nearby_nodes[index];
				if (findInOpenList(index_pos, new_node))//如果新找到的下一个路径, 已经是在open列中
				{
					handleInOpenNode(current_node, new_node);//看大小是否需要重新连接当前节点的父节点
				}
				else
				{
					//不会有闭合列表和开列表的坐标点//所以到这步骤位置, 必定是没有创建实例的地图点
					new_node = &(_maps[index_pos.x][index_pos.y] = Node(index_pos));
					handleNotInOpenNode(current_node, new_node, publicEnd);

					if (index_pos == publicEnd)
					{
						while (new_node->parent)
						{
							paths.push_back(new_node->pos);
							new_node = new_node->parent;
						}
						std::reverse(paths.begin(), paths.end());
						goto __end__;
					}
				}
			}
		}
	}

__end__:
	clear();
	return paths;
}
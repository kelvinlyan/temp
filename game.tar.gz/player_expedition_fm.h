#pragma once

#include "auto_base.h"
#include "mongoDB.h"
#include "battle_def.h"

namespace gg
{
	class playerMan;

	namespace Expedition
	{
		BOOSTSHAREPTR(playerMan, playerManPtr);
		STDVECTOR(playerManPtr, ManList);
	};

	class playerExpeditionSGFM
		: public _auto_player
	{
		public:
			playerExpeditionSGFM(int season, playerData* const own);

			void load(const mongo::BSONObj& obj);

			void tickAt0500();

			void getInfo(qValue& q);
			sBattlePtr getBattlePtr();

			void resetFM();
			int curFMID();

			int changeFormation(int fm_id);
			int setFormation(const std::vector<int>& fm);
			
			void recalBV() { _bv = -1; }

			int bv();

		private:
			virtual bool _auto_save(); 
			void initFM();
			int calBV();

		private:
			const int _season;
			int _bv;

			int _cur_fm_id;
			Expedition::ManList _cur_fm;

			int _last_fm_id;
			Expedition::ManList _last_fm;
	};

	class playerExpeditionFM
		: public _auto_player
	{
		public:
			playerExpeditionFM(playerData* const own);

			void classLoad();
			void update();

			int changeFormation(int fm_id);
			int setFormation(const std::vector<int>& fm);

			void tickAt0500();
			void recalFM();
			void resetFM();

			sBattlePtr getBattlePtr();

		private:
			virtual void _auto_update();

			int season();
			
		private:
			BOOSTSHAREPTR(playerExpeditionSGFM, FMPTR);
			STDVECTOR(FMPTR, FMList);
			FMList _fm_list;
			int _cur_season;
	};
}

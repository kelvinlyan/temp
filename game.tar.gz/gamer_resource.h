//###################################
//create by Jim
//2015-11-12
//###################################

#pragma once

#include "auto_do.h"

#define DICE_MAX	30	//���������

namespace gg
{
	typedef long long int LargerRes;

	class playerTick;

	class playerResource :
		public _auto_player
	{
		friend class playerTick;
	public:
		playerResource(playerData* const own);
		~playerResource(){}
		inline int getGold(){ return Gold; }//���
		inline int getTicket(){ return Ticket;}//��ȯ
		inline int getCash(){ return Gold + Ticket; }//���+��ȯ
		inline LargerRes getSilver(){ return Silver;/* +getCash() * 100;*/ }//����
		inline LargerRes getTroops(){ return Troops; }//���ñ���
		inline LargerRes getFood(){ return Food; }//��ʳ
		inline LargerRes getWood(){ return Wood; }//ľ
		inline LargerRes getIron(){ return Iron; }//��
		inline LargerRes getMerit(){ return Merit; }//����
		inline LargerRes getFame(){ return Fame; }//����
		inline int getAction(){ return Action; }//����//�ж�����
		inline int getHeroPartyMoney(){ return HeroPartyMoney; }//ȺӢ����
		inline int getLadyCoin(){ return LadyCoin; }//����
		inline int getShare(){ return shareTimes; }
		inline int getPaper(){ return RedPaper; }
		inline int getPoints(){ return Points; }
		inline int getSearchPoints(){ return SearchPoints; }
		int getExploit();
		int getContribution();
		inline int getDice() { return Dice; }


		//motify
		int alterGold(const int val, const bool isConsume = true);
		int alterTicket(const int val, const bool isConsume = true);
		int alterCash(const int val, const bool isConsume = true);
		LargerRes alterSilver(const LargerRes val);
		LargerRes alterTroops(const LargerRes val);
		LargerRes alterFood(const LargerRes val);
		LargerRes alterWood(const LargerRes val);
		LargerRes alterIron(const LargerRes val);
		LargerRes alterMerit(const LargerRes val);
		LargerRes alterFame(const LargerRes val);
		int alterAction(const int val);
		int alterContribution(const int val);
		int alterHeroPartyMoney(const int val);
		int alterLadyCoin(const int val);
		int alterShareTimes(const int val);
		int alterPaper(const int val);
		int alterPoints(const int val);
		int alterSearchPoints(const int val);
		void addRechargeNum(const int num);
		void alterExploit(const int val);
		int alterDice(const int val);

		//other
		virtual void _auto_update();
	private:
		virtual void classLoad();
		void onAlterGold(const int old_val);
		void onAlterTicket(const int old_val);
		void onAlterAction(const int old_val);
		void onAlterContribution(const int alter_val);
		virtual bool _auto_save();
		void initial();
		int Gold;//���
		int Ticket;//���ͽ��
		LargerRes Silver;//����
		LargerRes Troops;//����
		LargerRes Food;//��ʳ
		LargerRes Wood;//ľ��
		LargerRes Iron;//��
		LargerRes Merit;//����
		LargerRes Fame;//����
		int Action;//�ж���//����
		//int Contribution;//���ҹ���ֵ
		int HeroPartyMoney;//ȺӢ����
		int LadyCoin;//����
		int shareTimes;//ս����������
		int RedPaper;//�����
		int Points;//����
		int SearchPoints;//Ѱ�û���
		unsigned RechargeNum;//��ֵ����
		unsigned Dice;//��������
	};
}

#include "player_team.h"
#include "dbDriver.h"
#include "team_war.h"
#include "task_mgr.h"

namespace gg
{
	playerTeam::playerTeam(playerData* const own) : _auto_player(own)
	{
		buyToday = 0;
		challengeTimes = 0;
		teamID = -1;
		challengeData.resize(team_war.TeamSize(), '0');
	}

	bool playerTeam::_auto_save()
	{
		mongo::BSONObj key = BSON(strPlayerID << Own().ID());
		mongo::BSONObj obj = BSON(strPlayerID << Own().ID() <<
			"clt" << challengeTimes <<  "d" << challengeData <<
			"b" << buyToday);
		return db_mgr.SaveMongo(DBN::dbPlayerTeam, key , obj);
	}

	void playerTeam::_auto_update()
	{
		Json::Value json;
		json[strMsg][0u] = res_sucess;
		Json::Value& data_json = json[strMsg][1u] = Json::objectValue;
		data_json["c"] = MaxTeamWarTimes - challengeTimes;
		data_json["b"] = buyToday;
		data_json["d"] = challengeData;
		data_json["tid"] = teamID;
		data_json["cd"] = Own().TeamCD;
		Own().sendToClient(gate_client::player_team_update_resp, json);
	}

	void playerTeam::classLoad()
	{
		mongo::BSONObj key = BSON(strPlayerID << Own().ID());
		mongo::BSONObj obj = db_mgr.FindOne(DBN::dbPlayerTeam, key);
		if (obj.isEmpty())return;
		challengeTimes = obj["clt"].eoo() ? 0 : obj["clt"].Int();
		buyToday = (unsigned)obj["b"].Int();
		std::string db_data = obj["d"].String();
		if (challengeData.size() > db_data.size())
		{
			memmove((void*)challengeData.c_str(), db_data.c_str(), db_data.size());
		}
		else
		{
			challengeData = db_data;
		}
	}

	void playerTeam::leaveTeam()
	{
		team_war.leave_team(Own().getOwnDataPtr());
		//_sign_update();
	}

	void playerTeam::alterHitTimes(const int num)
	{
		challengeTimes += num;
		//challengeTimes = challengeTimes < 0 ? 0 : challengeTimes;
		_sign_auto();
	}

	void playerTeam::alterBuyTimes(const unsigned num)
	{
		buyToday += num;
		TaskMgr::update(Own().getOwnDataPtr(), Task::TeamWarShopTimes, num);
		_sign_auto();
	}

	void playerTeam::tickWin(const unsigned idx)
	{
		if (idx >= challengeData.size())return;
		if ('1' == challengeData[idx])return;
		challengeData[idx] = '1';
		_sign_auto();
	}

	bool playerTeam::beenWin(const unsigned idx)
	{
		if (idx >= challengeData.size())return true;
		if ('1' == challengeData[idx])return true;
		return false;
	}

}
